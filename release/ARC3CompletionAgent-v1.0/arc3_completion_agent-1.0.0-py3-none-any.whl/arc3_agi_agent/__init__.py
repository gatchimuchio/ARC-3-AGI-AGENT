"""Minimal official GenericAGIRuntime package."""
__all__: list[str] = []
