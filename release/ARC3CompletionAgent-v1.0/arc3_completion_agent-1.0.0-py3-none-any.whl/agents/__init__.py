from .agent import Agent
from .templates.arc3_completion_agent import ARC3CompletionAgent
AVAILABLE_AGENTS = {'arc3completion': ARC3CompletionAgent}
__all__ = ['AVAILABLE_AGENTS', 'ARC3CompletionAgent', 'Agent']
