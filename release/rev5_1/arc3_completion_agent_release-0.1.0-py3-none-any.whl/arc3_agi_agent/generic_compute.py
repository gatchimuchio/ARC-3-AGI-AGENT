"""Relational Layer-0 and subordinate compute subject for GenericAGIRuntime."""

from __future__ import annotations

import math
from collections import Counter, deque
from dataclasses import dataclass, field
from functools import lru_cache
from typing import Protocol, Sequence

from .authority_state import AuthorityState
from .evidence_binding import (
    TypedCandidateProvenance,
    bind_candidate_records,
    build_evidence_binding_key,
    record_matches_binding_prefix,
)
from .generic_memory import (
    SemanticMemoryQuery,
    SemanticMemoryQueryResult,
    SemanticRecord,
)
from .generic_types import (
    ActionDescriptor,
    ActionEffectRecord,
    GenericCandidate,
    GenericComputeCommand,
    GenericComputeResult,
    GenericHypothesis,
    GenericObservation,
    GenericPlan,
    GenericPlanStep,
    GenericPrediction,
    Layer0StageTrace,
    ObjectRole,
    RelationalRepresentation,
)
from .local_capability import (
    LOCAL_CAPABILITY_VERSION,
    development_hypotheses,
    enrich_development_predictions,
)
from .p_ir_types import PIRProgram
from .schema import digest_object
from .taint import COORDINATE_PROVENANCE_CURRENT_RENDER

GENERIC_COMPUTE_VERSION = "arc3-generic-compute-v2"
GENERIC_P_REMOVAL_WITNESS = "GENERIC_EXECUTABLE_INSTRUCTION_BODY_REQUIRED"
GENERIC_SERIAL_DEPTH_WITNESS = "GENERIC_EFFECTIVE_SERIAL_DEPTH_REMOVED"


def _bounded(value: float) -> float:
    return max(0.0, min(1.0, value))


def _sigmoid(value: float) -> float:
    if value >= 0.0:
        inverse = math.exp(-value)
        return 1.0 / (1.0 + inverse)
    direct = math.exp(value)
    return direct / (1.0 + direct)


@dataclass(frozen=True, slots=True)
class _OnlinePlanContext:
    phase: str
    revision_reason: str
    predecessor_plan_id: str
    invalidated_hypothesis_refs: tuple[str, ...]
    history_ref: str


def _online_plan_context(
    action_history: tuple[ActionEffectRecord, ...],
) -> _OnlinePlanContext:
    if not action_history:
        return _OnlinePlanContext(
            phase="INITIAL_MECHANISM_IDENTIFICATION",
            revision_reason="INITIAL_ONLINE_PLAN",
            predecessor_plan_id="",
            invalidated_hypothesis_refs=(),
            history_ref="",
        )
    last = action_history[-1]
    invalidated = (
        last.hypothesis_refs
        if last.outcome_category in {"FAILURE", "NO_EFFECT"}
        else ()
    )
    if last.compatibility_reset:
        phase = "POST_ROLLBACK_REIDENTIFICATION"
        reason = "ROLLBACK_RECOVERY_REPLAN"
    elif last.outcome_category == "FAILURE":
        phase = "HAZARD_RECOVERY"
        reason = "FAILED_HYPOTHESIS_INVALIDATED"
    elif last.outcome_category == "NO_EFFECT":
        phase = "MECHANISM_DISCRIMINATION"
        reason = "NO_EFFECT_PLAN_REVISED"
    elif last.outcome_category == "PROGRESS":
        phase = "SUBGOAL_ADVANCEMENT"
        reason = "SUBGOAL_ADVANCED"
    else:
        phase = "EFFECT_VERIFICATION"
        reason = "EFFECT_MODEL_UPDATED"
    return _OnlinePlanContext(
        phase=phase,
        revision_reason=reason,
        predecessor_plan_id=last.plan_id,
        invalidated_hypothesis_refs=tuple(sorted(set(invalidated))),
        history_ref="bounded-action-effect-memory:" + digest_object(action_history),
    )


def _plan_representation_refs(
    observation: GenericObservation,
    representation: RelationalRepresentation,
) -> tuple[str, ...]:
    return tuple(
        sorted(
            {
                representation.digest_value,
                "render-sequence:" + digest_object(observation.rendered_layers),
                "action-surface:"
                + digest_object(observation.available_actions),
            }
        )
    )


def _goal_and_subgoal(prediction: GenericPrediction) -> tuple[str, str]:
    effects = tuple(sorted(set(prediction.predicted_effects)))
    if "LEVEL_PROGRESS" in effects:
        goal = "increase-level-progress-or-reach-win"
    elif "VISIBLE_STATE_CHANGE" in effects:
        goal = "produce-and-verify-state-transition"
    else:
        goal = "discriminate-current-mechanism"
    return goal, "cause-and-verify:" + "+".join(effects)


def _candidate_plan(
    *,
    candidate_id: str,
    operation: str,
    prediction: GenericPrediction,
    hypotheses: Sequence[GenericHypothesis],
    observation: GenericObservation,
    representation: RelationalRepresentation,
    action_history: tuple[ActionEffectRecord, ...],
    memory_refs: tuple[str, ...],
) -> GenericPlan:
    context = _online_plan_context(action_history)
    current_hypothesis_refs = tuple(
        sorted(
            hypothesis.hypothesis_id
            for hypothesis in hypotheses
            if hypothesis.hypothesis_id
            not in context.invalidated_hypothesis_refs
        )
    )
    goal, subgoal = _goal_and_subgoal(prediction)
    plan_memory_refs = tuple(
        sorted({*memory_refs, context.history_ref} - {""})
    )
    mode = "ACTION_PLAN" if operation == "ACTION" else "PROBE_PLAN"
    steps = (
        GenericPlanStep(
            step_index=0,
            operation=operation,
            completion_predicate="one HDS-authorized legal action is emitted",
            failure_transition="veto hazard or request bounded rollback",
        ),
        GenericPlanStep(
            step_index=1,
            operation="REOBSERVE",
            completion_predicate="action-complete rendered observation is received",
            failure_transition="suspend on observation or action-surface error",
        ),
        GenericPlanStep(
            step_index=2,
            operation="VERIFY",
            completion_predicate="effect is attributed to progress hazard or no-effect",
            failure_transition="invalidate the unsupported mechanism hypothesis",
        ),
        GenericPlanStep(
            step_index=3,
            operation="REPLAN",
            completion_predicate="next subgoal plan is committed or WIN is confirmed",
            failure_transition="ask the next HDS question without another action",
        ),
    )
    plan_id = "plan:generic:" + digest_object(
        {
            "candidate": candidate_id,
            "phase": context.phase,
            "goal": goal,
            "subgoal": subgoal,
            "hypotheses": current_hypothesis_refs,
            "predecessor": context.predecessor_plan_id,
            "revision": context.revision_reason,
            "invalidated": context.invalidated_hypothesis_refs,
        }
    )[:24]
    return GenericPlan(
        plan_id=plan_id,
        candidate_id=candidate_id,
        mode=mode,
        phase=context.phase,
        goal_predicate=goal,
        subgoal=subgoal,
        hypothesis_refs=current_hypothesis_refs,
        representation_refs=_plan_representation_refs(
            observation,
            representation,
        ),
        memory_refs=plan_memory_refs,
        steps=steps,
        revision_reason=context.revision_reason,
        predecessor_plan_id=context.predecessor_plan_id,
        invalidated_hypothesis_refs=(
            context.invalidated_hypothesis_refs
        ),
    )


def _rollback_plan(
    *,
    hypotheses: Sequence[GenericHypothesis],
    observation: GenericObservation,
    representation: RelationalRepresentation,
    action_history: tuple[ActionEffectRecord, ...],
) -> GenericPlan:
    context = _online_plan_context(action_history)
    current_hypothesis_refs = tuple(
        sorted(
            hypothesis.hypothesis_id
            for hypothesis in hypotheses
            if hypothesis.hypothesis_id
            not in context.invalidated_hypothesis_refs
        )
    )
    revision_reason = (
        "FAILURE_TRIGGERED_ROLLBACK"
        if observation.terminal_state == "GAME_OVER"
        else "MODEL_REQUESTED_ROLLBACK"
    )
    steps = (
        GenericPlanStep(
            step_index=0,
            operation="ROLLBACK",
            completion_predicate="one HDS-authorized level reset is executed",
            failure_transition="stop on unavailable or failed rollback",
        ),
        GenericPlanStep(
            step_index=1,
            operation="REOBSERVE",
            completion_predicate="a non-terminal action-complete render is received",
            failure_transition="classify rollback as failed",
        ),
        GenericPlanStep(
            step_index=2,
            operation="VERIFY",
            completion_predicate="the failed plan is absent from the active model",
            failure_transition="retain hazard evidence and stop",
        ),
        GenericPlanStep(
            step_index=3,
            operation="REPLAN",
            completion_predicate="a revised post-rollback subgoal plan is committed",
            failure_transition="suspend for unresolved mechanism evidence",
        ),
    )
    plan_id = "plan:rollback:" + digest_object(
        {
            "observation": observation.digest(),
            "hypotheses": current_hypothesis_refs,
            "predecessor": context.predecessor_plan_id,
            "invalidated": context.invalidated_hypothesis_refs,
            "revision": revision_reason,
        }
    )[:24]
    return GenericPlan(
        plan_id=plan_id,
        candidate_id=None,
        mode="ROLLBACK_PLAN",
        phase="HAZARD_RECOVERY",
        goal_predicate="restore-actionable-non-game-over-level-state",
        subgoal="rollback-once-reobserve-and-reidentify-mechanism",
        hypothesis_refs=current_hypothesis_refs,
        representation_refs=_plan_representation_refs(
            observation,
            representation,
        ),
        memory_refs=tuple(sorted({context.history_ref} - {""})),
        steps=steps,
        revision_reason=revision_reason,
        predecessor_plan_id=context.predecessor_plan_id,
        invalidated_hypothesis_refs=(
            context.invalidated_hypothesis_refs
        ),
    )


def _component_shape(
    cells: Sequence[tuple[int, int]],
) -> tuple[str, int, int, int]:
    ys = [item[0] for item in cells]
    xs = [item[1] for item in cells]
    height = max(ys) - min(ys) + 1
    width = max(xs) - min(xs) + 1
    cell_set = set(cells)
    perimeter = sum(
        1
        for y, x in cells
        for dy, dx in ((-1, 0), (1, 0), (0, -1), (0, 1))
        if (y + dy, x + dx) not in cell_set
    )
    ordered_dimensions = tuple(sorted((height, width)))
    density_bucket = round(len(cells) / float(height * width), 1)
    signature = (
        f"a{len(cells)}:"
        f"d{ordered_dimensions[0]}x{ordered_dimensions[1]}:"
        f"p{perimeter}:q{density_bucket:.1f}"
    )
    return signature, height, width, perimeter


def _components(
    matrix: tuple[tuple[int, ...], ...],
) -> tuple[tuple[tuple[int, int], ...], ...]:
    if not matrix:
        return ()
    height = len(matrix)
    width = len(matrix[0])
    background = Counter(cell for row in matrix for cell in row).most_common(1)[0][0]
    visited: set[tuple[int, int]] = set()
    output: list[tuple[tuple[int, int], ...]] = []
    for y in range(height):
        for x in range(width):
            color = matrix[y][x]
            if color == background or (y, x) in visited:
                continue
            queue: deque[tuple[int, int]] = deque([(y, x)])
            visited.add((y, x))
            cells: list[tuple[int, int]] = []
            while queue:
                current_y, current_x = queue.popleft()
                cells.append((current_y, current_x))
                for dy, dx in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                    next_y = current_y + dy
                    next_x = current_x + dx
                    if (
                        0 <= next_y < height
                        and 0 <= next_x < width
                        and (next_y, next_x) not in visited
                        and matrix[next_y][next_x] == color
                    ):
                        visited.add((next_y, next_x))
                        queue.append((next_y, next_x))
            ordered_cells = tuple(sorted(cells))
            if all(
                cell_y in {0, height - 1} or cell_x in {0, width - 1}
                for cell_y, cell_x in ordered_cells
            ):
                # Border-only components are rendered interface evidence, not
                # board affordances. They remain observable through effects.
                continue
            output.append(ordered_cells)
    output.sort(
        key=lambda item: (
            -len(item),
            _component_shape(item)[0],
            round(sum(y for y, _ in item) / len(item), 4),
            round(sum(x for _, x in item) / len(item), 4),
        )
    )
    return tuple(output)


def _relative_band(value: float) -> str:
    if value < 1.0 / 3.0:
        return "low"
    if value > 2.0 / 3.0:
        return "high"
    return "middle"


def _frame_change_count(
    left: tuple[tuple[int, ...], ...],
    right: tuple[tuple[int, ...], ...],
) -> int:
    """Return a bounded structural delta for two temporal camera renders."""

    if len(left) != len(right) or any(
        len(left_row) != len(right_row) for left_row, right_row in zip(left, right)
    ):
        return max(
            sum(len(row) for row in left),
            sum(len(row) for row in right),
        )
    return sum(
        left_cell != right_cell
        for left_row, right_row in zip(left, right)
        for left_cell, right_cell in zip(left_row, right_row)
    )


def represent_observation(
    observation: GenericObservation,
    *,
    goal_tokens: Sequence[str],
) -> RelationalRepresentation:
    """Build color-name-free role and relation features from current render."""

    failures = observation.validate()
    if failures:
        raise ValueError(";".join(failures))
    matrix = observation.composited_view
    raw_components = _components(matrix)
    height = len(matrix) if matrix else 1
    width = len(matrix[0]) if matrix else 1
    roles: list[ObjectRole] = []
    centroids: list[tuple[float, float]] = []
    for index, cells in enumerate(raw_components[:32]):
        centroid_y = sum(y for y, _ in cells) / len(cells)
        centroid_x = sum(x for _, x in cells) / len(cells)
        centroids.append((centroid_y, centroid_x))
        shape_signature, _, _, _ = _component_shape(cells)
        area = len(cells)
        # The center of a rendered component is a stronger generic pointer
        # affordance than an arbitrary colored edge cell.  It also remains
        # role-relative when the component is hollow or multicolored.
        target_y = round(centroid_y)
        target_x = round(centroid_x)
        if area == 1:
            area_bucket = "point"
        elif area <= 4:
            area_bucket = "small"
        elif area <= 64:
            area_bucket = "medium"
        else:
            area_bucket = "large"
        roles.append(
            ObjectRole(
                role_id=f"role:{index:02d}:{area_bucket}:{shape_signature}",
                area_rank=index,
                area_bucket=area_bucket,
                shape_signature=shape_signature,
                relative_vertical=_relative_band(centroid_y / max(1, height - 1)),
                relative_horizontal=_relative_band(centroid_x / max(1, width - 1)),
                neighbor_count=0,
                target_x=max(0, min(width - 1, target_x)),
                target_y=max(0, min(height - 1, target_y)),
            )
        )
    neighbor_counts = [0 for _ in roles]
    relations: set[str] = set()
    for left in range(len(roles)):
        for right in range(left + 1, len(roles)):
            left_y, left_x = centroids[left]
            right_y, right_x = centroids[right]
            vertical = "above" if left_y < right_y else "below"
            horizontal = "left-of" if left_x < right_x else "right-of"
            relations.add(f"{roles[left].role_id}:{vertical}:{roles[right].role_id}")
            relations.add(f"{roles[left].role_id}:{horizontal}:{roles[right].role_id}")
            distance = abs(left_y - right_y) + abs(left_x - right_x)
            if distance <= max(2.0, min(height, width) / 8.0):
                neighbor_counts[left] += 1
                neighbor_counts[right] += 1
                relations.add(f"{roles[left].role_id}:near:{roles[right].role_id}")
    roles = [
        ObjectRole(
            role_id=role.role_id,
            area_rank=role.area_rank,
            area_bucket=role.area_bucket,
            shape_signature=role.shape_signature,
            relative_vertical=role.relative_vertical,
            relative_horizontal=role.relative_horizontal,
            neighbor_count=neighbor_counts[index],
            target_x=role.target_x,
            target_y=role.target_y,
        )
        for index, role in enumerate(roles)
    ]
    relations.update(observation.frame_relations)
    for index in range(1, observation.action_frame_count):
        change_count = _frame_change_count(
            observation.rendered_action_frames[index - 1],
            observation.rendered_action_frames[index],
        )
        relations.add(
            f"action-frame:{index - 1}:changed-cells:{change_count}:"
            f"action-frame:{index}"
        )
    history_repeat_count = observation.observation_history.count(observation.signature)
    topology_tokens = {
        f"object-count:{len(roles)}",
        f"relation-count:{len(relations)}",
        f"action-count:{len(observation.available_actions)}",
        f"control-action-count:{len(observation.control_actions)}",
        f"legal-action-count:{len(observation.legal_action_surface)}",
        f"terminal:{observation.terminal_state.casefold()}",
        f"progress-count:{observation.progress_count}",
        f"win-level-count:{observation.win_level_count}",
        f"action-frame-count:{observation.action_frame_count}",
        f"animation-observed:{str(observation.animation_observed).casefold()}",
        f"action-complete:{str(observation.action_complete).casefold()}",
        f"full-reset:{str(observation.full_reset).casefold()}",
        f"last-action:{observation.last_action_id}",
        f"history-length:{len(observation.observation_history)}",
        f"current-signature-repeat-count:{history_repeat_count}",
    }
    topology_tokens.update(
        f"action-frame:{index}:palette-size:"
        f"{len({cell for row in action_frame for cell in row})}"
        for index, action_frame in enumerate(observation.rendered_action_frames)
    )
    topology_tokens.update(
        f"payload-schema:{action_id}:{','.join(fields)}"
        for action_id, fields in observation.action_payload_schema
    )
    topology_tokens.update(token for role in roles for token in role.semantic_tokens())
    role_tuple = tuple(roles)
    relation_tuple = tuple(sorted(relations))
    topology_tuple = tuple(sorted(topology_tokens))
    goal_tuple = tuple(sorted(set(goal_tokens)))
    digest_value = "generic-representation:" + digest_object(
        {
            "observation_signature": observation.signature,
            "roles": role_tuple,
            "relations": relation_tuple,
            "topology_tokens": topology_tuple,
            "goal_tokens": goal_tuple,
        }
    )
    representation = RelationalRepresentation(
        observation_signature=observation.signature,
        roles=role_tuple,
        relations=relation_tuple,
        topology_tokens=topology_tuple,
        goal_tokens=goal_tuple,
        digest_value=digest_value,
    )
    representation_failures = representation.validate()
    if representation_failures:
        raise ValueError(";".join(representation_failures))
    return representation


_POINTER_CANDIDATE_LIMIT = 112
_POINTER_CATEGORY_SCHEDULE = (
    "object",
    "object",
    "cell",
    "object",
    "region",
    "boundary",
    "path",
    "object",
    "ui",
    "candidate-position",
)


def _pointer_candidate_groups(
    matrix: tuple[tuple[int, ...], ...],
    representation: RelationalRepresentation,
) -> dict[str, list[tuple[str, int, int, str]]]:
    """Build bounded, current-render-derived spatial affordance groups."""

    height = len(matrix) if matrix else 64
    width = len(matrix[0]) if matrix else 64
    components = _components(matrix)[:32]
    groups: dict[str, list[tuple[str, int, int, str]]] = {
        category: [] for category in dict.fromkeys(_POINTER_CATEGORY_SCHEDULE)
    }

    def add(
        category: str,
        label: str,
        x: int,
        y: int,
        target_role: str,
    ) -> None:
        groups[category].append(
            (
                label,
                max(0, min(width - 1, x)),
                max(0, min(height - 1, y)),
                target_role,
            )
        )

    ordered_roles = tuple(
        sorted(
            representation.roles,
            key=lambda role: (
                {
                    "medium": 0,
                    "small": 1,
                    "point": 2,
                    "large": 3,
                }.get(role.area_bucket, 4),
                role.area_rank,
                -role.neighbor_count,
                role.role_id,
            ),
        )
    )
    for role in ordered_roles[:32]:
        cells = components[role.area_rank] if role.area_rank < len(components) else ()
        if cells:
            centroid_y = sum(y for y, _ in cells) / len(cells)
            centroid_x = sum(x for _, x in cells) / len(cells)
            nearest_y, nearest_x = min(
                cells,
                key=lambda item: (
                    (item[0] - centroid_y) ** 2 + (item[1] - centroid_x) ** 2,
                    item[0],
                    item[1],
                ),
            )
        else:
            nearest_x = role.target_x
            nearest_y = role.target_y
        semantic_role = ":".join(role.semantic_tokens())
        for anchor, x, y in (
            ("center", role.target_x, role.target_y),
            ("interior", nearest_x, nearest_y),
            ("north-adjacent", role.target_x, role.target_y - 1),
            ("south-adjacent", role.target_x, role.target_y + 1),
            ("west-adjacent", role.target_x - 1, role.target_y),
            ("east-adjacent", role.target_x + 1, role.target_y),
        ):
            add(
                "object",
                f"{semantic_role}:anchor:{anchor}",
                x,
                y,
                role.role_id,
            )

    for vertical_index in (1, 2, 3):
        for horizontal_index in (1, 2, 3):
            y = round(vertical_index * (height - 1) / 4)
            x = round(horizontal_index * (width - 1) / 4)
            vertical = _relative_band(y / max(1, height - 1))
            horizontal = _relative_band(x / max(1, width - 1))
            add(
                "cell",
                f"grid:{vertical}:{horizontal}",
                x,
                y,
                f"affordance:cell:{vertical}:{horizontal}",
            )

    background = (
        Counter(cell for row in matrix for cell in row).most_common(1)[0][0]
        if matrix
        else 0
    )
    for vertical_index in (1, 3, 5):
        for horizontal_index in (1, 3, 5):
            y = round(vertical_index * (height - 1) / 6)
            x = round(horizontal_index * (width - 1) / 6)
            if matrix and matrix[y][x] != background:
                continue
            vertical = _relative_band(y / max(1, height - 1))
            horizontal = _relative_band(x / max(1, width - 1))
            add(
                "region",
                f"background:{vertical}:{horizontal}",
                x,
                y,
                f"affordance:region:{vertical}:{horizontal}",
            )

    for label, x, y in (
        ("north-west", 0, 0),
        ("north", width // 2, 0),
        ("north-east", width - 1, 0),
        ("west", 0, height // 2),
        ("east", width - 1, height // 2),
        ("south-west", 0, height - 1),
        ("south", width // 2, height - 1),
        ("south-east", width - 1, height - 1),
    ):
        add("boundary", label, x, y, f"affordance:boundary:{label}")

    role_pairs = tuple(zip(ordered_roles[:8], ordered_roles[1:9]))
    if role_pairs:
        for left, right in role_pairs:
            midpoint_x = round((left.target_x + right.target_x) / 2)
            midpoint_y = round((left.target_y + right.target_y) / 2)
            add(
                "path",
                "between-role-centers",
                midpoint_x,
                midpoint_y,
                "affordance:path:between-roles",
            )
            add(
                "path",
                "manhattan-elbow-horizontal-first",
                right.target_x,
                left.target_y,
                "affordance:path:elbow",
            )
    else:
        add(
            "path",
            "board-diagonal-first-third",
            (width - 1) // 3,
            (height - 1) // 3,
            "affordance:path:board-diagonal",
        )
        add(
            "path",
            "board-diagonal-second-third",
            2 * (width - 1) // 3,
            2 * (height - 1) // 3,
            "affordance:path:board-diagonal",
        )

    inner_left = min(1, width - 1)
    inner_right = max(0, width - 2)
    inner_top = min(1, height - 1)
    inner_bottom = max(0, height - 2)
    for label, x, y in (
        ("north-strip", width // 2, inner_top),
        ("south-strip", width // 2, inner_bottom),
        ("west-strip", inner_left, height // 2),
        ("east-strip", inner_right, height // 2),
        ("north-west-control", inner_left, inner_top),
        ("south-east-control", inner_right, inner_bottom),
    ):
        add("ui", label, x, y, f"affordance:ui:{label}")

    for component_index, cells in enumerate(components[:16]):
        min_y = min(y for y, _ in cells)
        max_y = max(y for y, _ in cells)
        min_x = min(x for _, x in cells)
        max_x = max(x for _, x in cells)
        for label, x, y in (
            ("north-of-object", (min_x + max_x) // 2, min_y - 1),
            ("south-of-object", (min_x + max_x) // 2, max_y + 1),
            ("west-of-object", min_x - 1, (min_y + max_y) // 2),
            ("east-of-object", max_x + 1, (min_y + max_y) // 2),
        ):
            add(
                "candidate-position",
                label,
                x,
                y,
                f"affordance:candidate-position:rank:{component_index}",
            )
    if not groups["candidate-position"]:
        add(
            "candidate-position",
            "near-board-center",
            width // 2 + 1,
            height // 2,
            "affordance:candidate-position:board-center",
        )
    return groups


def _pointer_descriptors(
    *,
    observation: GenericObservation,
    representation: RelationalRepresentation,
    action_id: int,
    surface_ordinal: int,
) -> tuple[ActionDescriptor, ...]:
    matrix = observation.composited_view
    groups = _pointer_candidate_groups(matrix, representation)
    indexes = {category: 0 for category in groups}
    seen_coordinates: set[tuple[int, int]] = set()
    descriptors: list[ActionDescriptor] = []
    while len(descriptors) < _POINTER_CANDIDATE_LIMIT:
        appended = False
        for category in _POINTER_CATEGORY_SCHEDULE:
            candidates = groups[category]
            while indexes[category] < len(candidates):
                label, x, y, target_role = candidates[indexes[category]]
                indexes[category] += 1
                if (x, y) in seen_coordinates:
                    continue
                seen_coordinates.add((x, y))
                descriptors.append(
                    ActionDescriptor(
                        action_id=action_id,
                        surface_ordinal=surface_ordinal,
                        semantic_key=(
                            f"surface:{surface_ordinal}:category:{category}:{label}"
                        ),
                        payload_items=(("x", x), ("y", y)),
                        target_role=target_role,
                        coordinate_provenance=(COORDINATE_PROVENANCE_CURRENT_RENDER),
                        coordinate_observation_digest=observation.digest(),
                    )
                )
                appended = True
                break
            if len(descriptors) >= _POINTER_CANDIDATE_LIMIT:
                break
        if not appended:
            break
    return tuple(descriptors)


def action_descriptors(
    observation: GenericObservation,
    representation: RelationalRepresentation,
) -> tuple[ActionDescriptor, ...]:
    """Bind every legal action to a bounded current-render affordance."""

    payload_schema = dict(observation.action_payload_schema)
    descriptors: list[ActionDescriptor] = []
    for ordinal, action_id in enumerate(observation.available_actions):
        fields = payload_schema.get(action_id, ())
        if set(fields) == {"x", "y"}:
            descriptors.extend(
                _pointer_descriptors(
                    observation=observation,
                    representation=representation,
                    action_id=action_id,
                    surface_ordinal=ordinal,
                )
            )
        else:
            descriptors.append(
                ActionDescriptor(
                    action_id=action_id,
                    surface_ordinal=ordinal,
                    semantic_key=f"surface:{ordinal}:untargeted",
                )
            )
    if not descriptors:
        raise ValueError("GENERIC_LEGAL_ACTION_DESCRIPTOR_MISSING")
    return tuple(descriptors)


class SemanticMemoryReader(Protocol):
    @property
    def version(self) -> int: ...

    def query(self, query: SemanticMemoryQuery) -> SemanticMemoryQueryResult: ...


@dataclass(frozen=True, slots=True)
class InstructionBodyResult:
    predictions: tuple[GenericPrediction, ...]
    query_digest: str
    selected_instruction_refs: tuple[str, ...]
    control_operation: str = ""
    control_instruction_refs: tuple[str, ...] = ()


class GenericInstructionBody(Protocol):
    def format_id(self) -> str: ...

    def body_version(self) -> str: ...

    def provenance_digest(self) -> str: ...

    def digest(self) -> str: ...

    def validate(self) -> tuple[str, ...]: ...

    def query(
        self,
        representation: RelationalRepresentation,
        descriptors: tuple[ActionDescriptor, ...],
        records: tuple[SemanticRecord, ...],
        *,
        observation: GenericObservation | None = None,
        action_history: tuple[ActionEffectRecord, ...] = (),
    ) -> InstructionBodyResult: ...


def _record_statistics(
    descriptor: ActionDescriptor,
    records: Sequence[SemanticRecord],
    *,
    representation: RelationalRepresentation,
) -> tuple[float, float, float, float, float, tuple[str, ...]]:
    successes = 0.0
    hazards = 0.0
    no_effects = 0.0
    visible_changes = 0.0
    refs: list[str] = []
    binding_prefix = build_evidence_binding_key(
        topology_tokens=representation.topology_tokens,
        relations=representation.relations,
        descriptor_semantic_key=descriptor.semantic_key,
        action_id=descriptor.action_id,
        target_role=descriptor.target_role,
        payload_fields=tuple(key for key, _ in descriptor.payload_items),
        # Statistics consume records already emitted by a prediction.  The
        # action-relation key binds the expected-effect class while the exact
        # effect set remains isolated in predicted_effect_digest.
        predicted_effects=("EXPECTED_EFFECT_FAMILY",),
    )
    for record in records:
        if descriptor.semantic_key not in record.semantic_tokens:
            continue
        if not record_matches_binding_prefix(record, binding_prefix):
            continue
        refs.append(record.memory_id)
        payload = record.payload()
        for key, target in (
            ("success_count", "success"),
            ("hazard_count", "hazard"),
            ("no_effect_count", "no_effect"),
            ("visible_change_count", "visible_change"),
        ):
            value = payload.get(key, 0)
            if isinstance(value, int) and not isinstance(value, bool):
                if target == "success":
                    successes += value
                elif target == "hazard":
                    hazards += value
                elif target == "no_effect":
                    no_effects += value
                else:
                    visible_changes += value
    total = successes + hazards + no_effects + visible_changes
    if total <= 0:
        return 0.0, 0.0, 0.0, 0.0, 0.0, tuple(sorted(set(refs)))
    return (
        successes / total,
        hazards / total,
        no_effects / total,
        visible_changes / total,
        total,
        tuple(sorted(set(refs))),
    )


def _memory_effects(
    records: Sequence[SemanticRecord],
    record_ids: set[str],
) -> tuple[str, ...]:
    effects: set[str] = set()
    for record in records:
        if record.memory_id not in record_ids:
            continue
        value = record.payload().get("learned_effects", ())
        if isinstance(value, (str, bytes)) or not isinstance(value, Sequence):
            continue
        effects.update(str(item) for item in value if isinstance(item, str) and item)
    return tuple(sorted(effects))


@dataclass(frozen=True, slots=True)
class SymbolicRelationalInstructionBody:
    """Non-neural P-A based on reusable relation/action-effect instructions."""

    version: str = "generic-symbolic-relational-v1"
    provenance: str = "hand-audited-generic-prior:no-environment-identity"

    def format_id(self) -> str:
        return "generic-symbolic-relational"

    def body_version(self) -> str:
        return self.version

    @lru_cache(maxsize=128)
    def provenance_digest(self) -> str:
        return "generic-p-provenance:" + digest_object(self.provenance)

    @lru_cache(maxsize=128)
    def digest(self) -> str:
        return "generic-symbolic-p:" + digest_object(self)

    @lru_cache(maxsize=128)
    def validate(self) -> tuple[str, ...]:
        failures: list[str] = []
        if not self.version or not self.provenance:
            failures.append("GENERIC_SYMBOLIC_P_METADATA_MISSING")
        lowered = self.provenance.casefold()
        if any(
            term in lowered
            for term in ("game_id", "level_id", "task_id", "replay", "answer")
        ):
            failures.append("GENERIC_SYMBOLIC_P_IDENTITY_CONTAMINATED")
        return tuple(sorted(set(failures)))

    def query(
        self,
        representation: RelationalRepresentation,
        descriptors: tuple[ActionDescriptor, ...],
        records: tuple[SemanticRecord, ...],
        *,
        observation: GenericObservation | None = None,
        action_history: tuple[ActionEffectRecord, ...] = (),
    ) -> InstructionBodyResult:
        predictions: list[GenericPrediction] = []
        for descriptor in descriptors:
            (
                success,
                hazard,
                no_effect,
                visible_change,
                sample_count,
                memory_refs,
            ) = _record_statistics(
                descriptor,
                records,
                representation=representation,
            )
            observed = success + hazard + no_effect + visible_change > 0.0
            continue_visible_effect = (
                visible_change > 0.0
                and hazard == 0.0
                and no_effect == 0.0
                and sample_count <= 4.0
            )
            progress = _bounded(0.15 + 0.75 * success - 0.2 * no_effect)
            risk = _bounded(0.08 + 0.85 * hazard)
            information = _bounded(
                0.9
                if not observed
                else 1.0
                if continue_visible_effect
                else (
                    0.2
                    + no_effect * 0.3
                    + visible_change * 0.65 / math.sqrt(sample_count)
                )
            )
            prior = _bounded(0.3 + 0.45 * progress + 0.2 * information - 0.35 * risk)
            effects = {"VISIBLE_STATE_CHANGE"}
            if progress >= 0.5:
                effects.add("LEVEL_PROGRESS")
            if risk >= 0.5:
                effects.add("IRREVERSIBLE_FAILURE")
            if no_effect >= 0.5:
                effects.add("NO_VISIBLE_CHANGE")
            predictions.append(
                GenericPrediction(
                    descriptor=descriptor,
                    predicted_effects=tuple(sorted(effects)),
                    progress_likelihood=progress,
                    hazard_likelihood=risk,
                    information_gain=information,
                    prior=prior,
                    uncertainty=_bounded(0.8 if not observed else 0.25),
                    instruction_refs=(
                        self.digest(),
                        "rule:novel-action-as-bounded-probe",
                        "rule:reuse-progress-avoid-hazard",
                    ),
                    memory_refs=memory_refs,
                )
            )
        query_digest = "generic-symbolic-query:" + digest_object(
            {
                "representation": representation.digest_value,
                "descriptors": descriptors,
                "records": tuple(record.citation() for record in records),
                "predictions": predictions,
            }
        )
        return InstructionBodyResult(
            predictions=tuple(predictions),
            query_digest=query_digest,
            selected_instruction_refs=(
                "rule:novel-action-as-bounded-probe",
                "rule:reuse-progress-avoid-hazard",
            ),
        )


@dataclass(frozen=True, slots=True)
class ParametricRelationalInstructionBody:
    """P-B: shared action scorer with a nonlinear hidden state."""

    version: str = "generic-parametric-relational-v1"
    provenance: str = "deterministic-generic-prior:no-environment-identity"
    hidden_weights: tuple[tuple[float, ...], ...] = (
        (0.7, -0.2, 0.1, 0.4, 1.2, -1.0, -0.3, 0.8),
        (-0.4, 0.8, 0.2, 0.3, 0.9, -1.4, -0.5, 1.0),
        (0.2, 0.1, 0.7, -0.2, 1.4, -1.2, -0.6, 0.6),
        (0.1, -0.3, 0.4, 0.8, 1.0, -1.6, -0.4, 0.9),
    )
    progress_weights: tuple[float, ...] = (1.1, 0.7, 0.5, 0.9)
    hazard_weights: tuple[float, ...] = (-0.6, -0.9, -0.7, -1.0)
    information_weights: tuple[float, ...] = (0.8, 1.0, 0.9, 0.7)
    action_bias_items: tuple[tuple[str, float], ...] = ()

    def format_id(self) -> str:
        return "generic-parametric-relational"

    def body_version(self) -> str:
        return self.version

    @lru_cache(maxsize=128)
    def provenance_digest(self) -> str:
        return "generic-p-provenance:" + digest_object(self.provenance)

    @lru_cache(maxsize=128)
    def digest(self) -> str:
        return "generic-parametric-p:" + digest_object(self)

    @lru_cache(maxsize=128)
    def validate(self) -> tuple[str, ...]:
        failures: list[str] = []
        if len(self.hidden_weights) < 2:
            failures.append("GENERIC_PARAMETRIC_P_NONLINEAR_DEPTH_MISSING")
        if any(len(row) != 8 for row in self.hidden_weights):
            failures.append("GENERIC_PARAMETRIC_P_HIDDEN_WIDTH_INVALID")
        hidden = len(self.hidden_weights)
        if any(
            len(values) != hidden
            for values in (
                self.progress_weights,
                self.hazard_weights,
                self.information_weights,
            )
        ):
            failures.append("GENERIC_PARAMETRIC_P_OUTPUT_WIDTH_INVALID")
        if tuple(key for key, _ in self.action_bias_items) != tuple(
            sorted(set(key for key, _ in self.action_bias_items))
        ):
            failures.append("GENERIC_PARAMETRIC_P_BIAS_INVALID")
        lowered = self.provenance.casefold()
        if any(
            term in lowered
            for term in ("game_id", "level_id", "task_id", "replay", "answer")
        ):
            failures.append("GENERIC_PARAMETRIC_P_IDENTITY_CONTAMINATED")
        return tuple(sorted(set(failures)))

    def _features(
        self,
        representation: RelationalRepresentation,
        descriptor: ActionDescriptor,
        records: tuple[SemanticRecord, ...],
        descriptor_count: int,
    ) -> tuple[tuple[float, ...], tuple[str, ...]]:
        (
            success,
            hazard,
            no_effect,
            visible_change,
            sample_count,
            memory_refs,
        ) = _record_statistics(
            descriptor,
            records,
            representation=representation,
        )
        observed = 1.0 if success + hazard + no_effect + visible_change > 0.0 else 0.0
        continue_visible_effect = (
            visible_change > 0.0
            and hazard == 0.0
            and no_effect == 0.0
            and sample_count <= 4.0
        )
        ordinal = descriptor.surface_ordinal / max(1, descriptor_count - 1)
        return (
            (
                ordinal,
                1.0 if descriptor.target_role is not None else 0.0,
                min(1.0, len(representation.roles) / 16.0),
                min(1.0, len(representation.relations) / 64.0),
                success,
                hazard,
                no_effect,
                max(
                    1.0 if continue_visible_effect else 0.0,
                    1.0 - observed,
                ),
            ),
            memory_refs,
        )

    def query(
        self,
        representation: RelationalRepresentation,
        descriptors: tuple[ActionDescriptor, ...],
        records: tuple[SemanticRecord, ...],
        *,
        observation: GenericObservation | None = None,
        action_history: tuple[ActionEffectRecord, ...] = (),
    ) -> InstructionBodyResult:
        failures = self.validate()
        if failures:
            raise ValueError(";".join(failures))
        action_bias = dict(self.action_bias_items)
        predictions: list[GenericPrediction] = []
        for descriptor in descriptors:
            features, memory_refs = self._features(
                representation, descriptor, records, len(descriptors)
            )
            hidden = tuple(
                math.tanh(sum(weight * value for weight, value in zip(row, features)))
                for row in self.hidden_weights
            )
            progress = _sigmoid(
                sum(
                    weight * value
                    for weight, value in zip(self.progress_weights, hidden)
                )
                - 1.2
                + action_bias.get(descriptor.semantic_key, 0.0)
            )
            hazard = _sigmoid(
                sum(
                    weight * value for weight, value in zip(self.hazard_weights, hidden)
                )
                - 2.0
            )
            information = _sigmoid(
                sum(
                    weight * value
                    for weight, value in zip(self.information_weights, hidden)
                )
                - 0.5
            )
            prior = _bounded(
                0.55 * progress + 0.35 * information - 0.45 * hazard + 0.25
            )
            effects = {"VISIBLE_STATE_CHANGE"}
            if progress >= 0.5:
                effects.add("LEVEL_PROGRESS")
            if hazard >= 0.5:
                effects.add("IRREVERSIBLE_FAILURE")
            predictions.append(
                GenericPrediction(
                    descriptor=descriptor,
                    predicted_effects=tuple(sorted(effects)),
                    progress_likelihood=progress,
                    hazard_likelihood=hazard,
                    information_gain=information,
                    prior=prior,
                    uncertainty=_bounded(1.0 - max(progress, hazard)),
                    instruction_refs=(
                        self.digest(),
                        "shared-action-embedding",
                        "nonlinear-hidden-transform",
                        "legal-action-mask",
                    ),
                    memory_refs=memory_refs,
                )
            )
        query_digest = "generic-parametric-query:" + digest_object(
            {
                "representation": representation.digest_value,
                "descriptors": descriptors,
                "records": tuple(record.citation() for record in records),
                "predictions": predictions,
            }
        )
        return InstructionBodyResult(
            predictions=tuple(predictions),
            query_digest=query_digest,
            selected_instruction_refs=(
                "shared-action-embedding",
                "nonlinear-hidden-transform",
                "legal-action-mask",
            ),
        )

    def with_action_bias(
        self,
        *,
        version: str,
        action_bias: dict[str, float],
        provenance: str,
    ) -> ParametricRelationalInstructionBody:
        return ParametricRelationalInstructionBody(
            version=version,
            provenance=provenance,
            hidden_weights=self.hidden_weights,
            progress_weights=self.progress_weights,
            hazard_weights=self.hazard_weights,
            information_weights=self.information_weights,
            action_bias_items=tuple(sorted(action_bias.items())),
        )


@dataclass(frozen=True, slots=True)
class HybridRelationalInstructionBody:
    symbolic: SymbolicRelationalInstructionBody = field(
        default_factory=SymbolicRelationalInstructionBody
    )
    parametric: ParametricRelationalInstructionBody = field(
        default_factory=ParametricRelationalInstructionBody
    )
    version: str = "generic-hybrid-relational-v1"

    def format_id(self) -> str:
        return "generic-hybrid-relational"

    def body_version(self) -> str:
        return self.version

    @lru_cache(maxsize=128)
    def provenance_digest(self) -> str:
        return "generic-p-provenance:" + digest_object(
            (self.symbolic.provenance_digest(), self.parametric.provenance_digest())
        )

    @lru_cache(maxsize=128)
    def digest(self) -> str:
        return "generic-hybrid-p:" + digest_object(self)

    @lru_cache(maxsize=128)
    def validate(self) -> tuple[str, ...]:
        return tuple(
            sorted(
                set(
                    (
                        *self.symbolic.validate(),
                        *self.parametric.validate(),
                    )
                )
            )
        )

    def query(
        self,
        representation: RelationalRepresentation,
        descriptors: tuple[ActionDescriptor, ...],
        records: tuple[SemanticRecord, ...],
        *,
        observation: GenericObservation | None = None,
        action_history: tuple[ActionEffectRecord, ...] = (),
    ) -> InstructionBodyResult:
        symbolic = self.symbolic.query(
            representation,
            descriptors,
            records,
            observation=observation,
            action_history=action_history,
        )
        parametric = self.parametric.query(
            representation,
            descriptors,
            records,
            observation=observation,
            action_history=action_history,
        )
        symbolic_by_key = {
            item.descriptor.semantic_key: item for item in symbolic.predictions
        }
        predictions: list[GenericPrediction] = []
        for item in parametric.predictions:
            other = symbolic_by_key[item.descriptor.semantic_key]
            predictions.append(
                GenericPrediction(
                    descriptor=item.descriptor,
                    predicted_effects=tuple(
                        sorted(
                            set(
                                (
                                    *item.predicted_effects,
                                    *other.predicted_effects,
                                )
                            )
                        )
                    ),
                    progress_likelihood=(
                        item.progress_likelihood + other.progress_likelihood
                    )
                    / 2.0,
                    hazard_likelihood=max(
                        item.hazard_likelihood, other.hazard_likelihood
                    ),
                    information_gain=(item.information_gain + other.information_gain)
                    / 2.0,
                    prior=(item.prior + other.prior) / 2.0,
                    uncertainty=max(item.uncertainty, other.uncertainty),
                    instruction_refs=tuple(
                        sorted(set((*item.instruction_refs, *other.instruction_refs)))
                    ),
                    memory_refs=tuple(
                        sorted(set((*item.memory_refs, *other.memory_refs)))
                    ),
                )
            )
        return InstructionBodyResult(
            predictions=tuple(predictions),
            query_digest="generic-hybrid-query:"
            + digest_object(
                {
                    "symbolic": symbolic.query_digest,
                    "parametric": parametric.query_digest,
                    "predictions": predictions,
                }
            ),
            selected_instruction_refs=tuple(
                sorted(
                    set(
                        (
                            *symbolic.selected_instruction_refs,
                            *parametric.selected_instruction_refs,
                        )
                    )
                )
            ),
        )


@dataclass(frozen=True, slots=True)
class ComputeAblation:
    selective_retrieval: bool = True
    effective_serial_depth: bool = True
    counter_hypothesis: bool = True
    candidate_diversity: bool = True


@dataclass(slots=True)
class GenericComputeSubject:
    """C: executes L0+P but owns no final judgment or side effect."""

    authority_state: AuthorityState = field(repr=False)

    @property
    def authority_token(self) -> object:
        """Compatibility view; capability state remains session-owned."""

        return self.authority_state.live_token

    def _require_command(
        self,
        command: GenericComputeCommand,
        observation: GenericObservation,
        memory_version: int,
    ) -> None:
        self.authority_state.require_live_token(
            command._authority_token,
            error="GENERIC_COMPUTE_COMMAND_NOT_HDS_AUTHORIZED",
        )
        if command.observation_signature != observation.signature:
            raise PermissionError("GENERIC_COMPUTE_OBSERVATION_BINDING_INVALID")
        if command.memory_version != memory_version:
            raise RuntimeError("GENERIC_COMPUTE_MEMORY_VERSION_CONFLICT")
        binding_digest = digest_object(
            {
                "purpose": command.purpose,
                "goal_tokens": command.goal_tokens,
                "required_outputs": command.required_outputs,
                "observation_signature": command.observation_signature,
                "memory_version": command.memory_version,
            }
        )
        self.authority_state.consume(
            command.command_id,
            kind="HDS_COMPUTE",
            binding_digest=binding_digest,
            unknown_error="GENERIC_COMPUTE_COMMAND_NOT_HDS_AUTHORIZED",
            reused_error="GENERIC_COMPUTE_COMMAND_REUSED",
            binding_error="GENERIC_COMPUTE_COMMAND_BINDING_INVALID",
        )

    def compute(
        self,
        *,
        command: GenericComputeCommand,
        observation: GenericObservation,
        memory: SemanticMemoryReader,
        instruction_body: GenericInstructionBody | None,
        p_ir_program: PIRProgram | None = None,
        action_history: tuple[ActionEffectRecord, ...] = (),
        ablation: ComputeAblation | None = None,
    ) -> GenericComputeResult:
        from .p_ir import compatibility_p_ir_program
        from .p_ir_interpreter import (
            FixedL0PIRInterpreter,
            PIRExecutionContext,
        )

        selected_ablation = ablation or ComputeAblation()
        self._require_command(command, observation, memory.version)
        if instruction_body is None:
            raise RuntimeError(GENERIC_P_REMOVAL_WITNESS)
        body_failures = instruction_body.validate()
        if body_failures:
            raise RuntimeError(
                GENERIC_P_REMOVAL_WITNESS + ":" + ",".join(body_failures)
            )
        if not selected_ablation.effective_serial_depth:
            raise RuntimeError(GENERIC_SERIAL_DEPTH_WITNESS)
        history_failures = tuple(
            failure for record in action_history for failure in record.validate()
        )
        if history_failures:
            raise ValueError(";".join(sorted(set(history_failures))))

        selected_program = p_ir_program or compatibility_p_ir_program()
        interpreter = FixedL0PIRInterpreter()
        representation_execution = interpreter.execute_representation(
            selected_program,
            PIRExecutionContext(
                observation=observation,
                goal_tokens=command.goal_tokens,
            ),
        )
        representation = representation_execution.representation
        stages: list[Layer0StageTrace] = [
            Layer0StageTrace(
                stage="represent",
                input_digest=observation.digest(),
                output_digest=representation.digest_value,
                selected_refs=(
                    selected_program.program_id,
                    representation_execution.trace.graph_id,
                    *representation_execution.trace.ordered_node_ids,
                ),
            )
        ]
        pre_retrieval_execution = interpreter.execute(
            selected_program,
            PIRExecutionContext(
                observation=observation,
                goal_tokens=command.goal_tokens,
            ),
            representation_execution=representation_execution,
        )
        if pre_retrieval_execution.representation != representation:
            raise RuntimeError("P_IR_REPRESENTATION_REEXECUTION_MISMATCH")
        preliminary_descriptors = pre_retrieval_execution.action_bindings

        query_tokens = tuple(
            sorted(
                set(
                    (
                        *command.goal_tokens,
                        *representation.topology_tokens,
                        *representation.relations,
                        *(
                            descriptor.semantic_key
                            for descriptor in preliminary_descriptors
                        ),
                    )
                )
            )
        )
        if selected_ablation.selective_retrieval:
            memory_query = memory.query(
                SemanticMemoryQuery(
                    query_id="memory-query:"
                    + digest_object(
                        {
                            "command": command.command_id,
                            "tokens": query_tokens,
                            "version": memory.version,
                        }
                    )[:24],
                    semantic_tokens=query_tokens,
                    limit=128,
                )
            )
            records = memory_query.records
            memory_query_digest = memory_query.digest
        else:
            records = ()
            memory_query_digest = "semantic-memory-query:ABLATION_DISABLED"
        citations = tuple(record.citation() for record in records)
        p_ir_execution = interpreter.execute(
            selected_program,
            PIRExecutionContext(
                observation=observation,
                goal_tokens=command.goal_tokens,
                memory_records=records,
            ),
            representation_execution=representation_execution,
        )
        if p_ir_execution.representation != representation:
            raise RuntimeError("P_IR_REPRESENTATION_REEXECUTION_MISMATCH")
        descriptors = p_ir_execution.action_bindings
        stages.append(
            Layer0StageTrace(
                stage="retrieve",
                input_digest=representation.digest_value,
                output_digest=memory_query_digest,
                selected_refs=tuple(item.memory_id for item in citations),
            )
        )

        instruction_result = instruction_body.query(
            representation,
            descriptors,
            records,
            observation=observation,
            action_history=action_history,
        )
        enriched_predictions = enrich_development_predictions(
            instruction_result.predictions,
            records,
            observation,
        )
        if enriched_predictions != instruction_result.predictions:
            capability_instruction_refs = tuple(
                sorted(
                    {
                        ref
                        for prediction in enriched_predictions
                        for ref in prediction.instruction_refs
                        if ref.startswith(
                            ("active-capability:", "probation-capability:")
                        )
                    }
                )
            )
            instruction_result = InstructionBodyResult(
                predictions=enriched_predictions,
                query_digest="generic-local-capability-query:"
                + digest_object(
                    {
                        "base_query": instruction_result.query_digest,
                        "local_capability_version": LOCAL_CAPABILITY_VERSION,
                        "predictions": enriched_predictions,
                    }
                ),
                selected_instruction_refs=tuple(
                    sorted(
                        {
                            *instruction_result.selected_instruction_refs,
                            *capability_instruction_refs,
                        }
                    )
                ),
                control_operation=instruction_result.control_operation,
                control_instruction_refs=(
                    instruction_result.control_instruction_refs
                ),
            )
        descriptor_order: dict[ActionDescriptor, int] = {
            descriptor: index for index, descriptor in enumerate(descriptors)
        }
        for prediction in instruction_result.predictions:
            descriptor_failures = prediction.descriptor.validate(observation)
            if descriptor_failures:
                raise ValueError(";".join(descriptor_failures))
            if prediction.descriptor not in descriptor_order:
                descriptor_order[prediction.descriptor] = len(descriptor_order)
        ranked_predictions = tuple(
            sorted(
                instruction_result.predictions,
                key=lambda item: (
                    -item.prior,
                    item.hazard_likelihood,
                    -item.information_gain,
                    descriptor_order[item.descriptor],
                ),
            )
        )
        plan_context = _online_plan_context(action_history)
        hypothesis_revision_digest = digest_object(
            {
                "phase": plan_context.phase,
                "revision": plan_context.revision_reason,
                "predecessor": plan_context.predecessor_plan_id,
                "invalidated": plan_context.invalidated_hypothesis_refs,
                "history": plan_context.history_ref,
            }
        )
        if instruction_result.control_operation:
            if (
                instruction_result.control_operation != "ROLLBACK"
                or not instruction_result.control_instruction_refs
            ):
                raise RuntimeError("GENERIC_P_CONTROL_OPERATION_INVALID")
            control_hypotheses = (
                GenericHypothesis(
                    hypothesis_id="hypothesis:rollback:baseline:"
                    + digest_object(
                        (observation.digest(), hypothesis_revision_digest)
                    )[:20],
                    model_type="baseline",
                    statement=(
                        "The observed terminal failure requires one HDS-authorized "
                        "level rollback followed by reobservation."
                    ),
                    predictions=("LEVEL_RESET", "SAFE_REOBSERVATION"),
                    falsification_conditions=(
                        "the reset observation remains GAME_OVER",
                    ),
                    supporting_evidence=(
                        observation.digest(),
                        *instruction_result.control_instruction_refs,
                    ),
                    confidence=0.999,
                ),
                GenericHypothesis(
                    hypothesis_id="hypothesis:rollback:counter:"
                    + digest_object(
                        (
                            instruction_result.query_digest,
                            hypothesis_revision_digest,
                        )
                    )[:20],
                    model_type="counter_hypothesis",
                    statement=(
                        "The rollback may fail to restore an actionable level state."
                    ),
                    predictions=("RESET_FAILURE",),
                    falsification_conditions=(
                        "reset yields a non-terminal observation with legal actions",
                    ),
                    contradicting_evidence=(observation.digest(),),
                    confidence=0.001,
                ),
            )
            stages.extend(
                (
                    Layer0StageTrace(
                        stage="model",
                        input_digest=memory_query_digest,
                        output_digest="generic-model-set:"
                        + digest_object(control_hypotheses),
                        selected_refs=tuple(
                            item.hypothesis_id for item in control_hypotheses
                        ),
                    ),
                    Layer0StageTrace(
                        stage="predict",
                        input_digest=instruction_result.query_digest,
                        output_digest="generic-predictions:"
                        + digest_object(()),
                        selected_refs=(
                            instruction_result.selected_instruction_refs
                        ),
                    ),
                    Layer0StageTrace(
                        stage="candidate",
                        input_digest="generic-predictions:"
                        + digest_object(()),
                        output_digest="generic-candidates:"
                        + digest_object(()),
                        selected_refs=(),
                    ),
                )
            )
            return GenericComputeResult(
                command_id=command.command_id,
                representation=representation,
                memory_citations=citations,
                hypotheses=control_hypotheses,
                predictions=(),
                candidates=(),
                stages=tuple(stages),
                instruction_body_format=instruction_body.format_id(),
                instruction_body_version=instruction_body.body_version(),
                instruction_body_digest=instruction_body.digest(),
                p_ir_logical_digest=p_ir_execution.program_logical_digest,
                p_ir_execution_digest=p_ir_execution.execution_digest,
                l0_abi_version=selected_program.l0_abi_version,
                uncertainty=0.001,
                provenance=(
                    instruction_body.provenance_digest(),
                    memory_query_digest,
                    p_ir_execution.program_logical_digest,
                    p_ir_execution.execution_digest,
                    GENERIC_COMPUTE_VERSION,
                ),
                control_operation=instruction_result.control_operation,
                control_instruction_refs=(
                    instruction_result.control_instruction_refs
                ),
                control_plan=_rollback_plan(
                    hypotheses=control_hypotheses,
                    observation=observation,
                    representation=representation,
                    action_history=action_history,
                ),
            )
        if not ranked_predictions:
            raise RuntimeError("GENERIC_P_PREDICTION_MISSING")
        primary = ranked_predictions[0]
        alternative = (
            ranked_predictions[1]
            if len(ranked_predictions) > 1
            else ranked_predictions[0]
        )
        hypotheses = [
            GenericHypothesis(
                hypothesis_id="hypothesis:baseline:"
                + digest_object((primary, hypothesis_revision_digest))[:20],
                model_type="baseline",
                statement=(
                    "The highest supported legal action relation can advance "
                    "the current goal."
                ),
                predictions=primary.predicted_effects,
                falsification_conditions=tuple(
                    sorted(
                        (
                            "selected action repeatedly produces no effect",
                            "selected action produces irreversible failure",
                        )
                    )
                ),
                supporting_evidence=tuple(
                    sorted(set((*primary.instruction_refs, *primary.memory_refs)))
                ),
                confidence=primary.prior,
            ),
            GenericHypothesis(
                hypothesis_id="hypothesis:alternative:"
                + digest_object((alternative, hypothesis_revision_digest))[:20],
                model_type="alternative",
                statement=(
                    "A different legal action or role binding explains the "
                    "transition better."
                ),
                predictions=alternative.predicted_effects,
                falsification_conditions=(
                    "alternative action has lower observed information and progress",
                ),
                supporting_evidence=tuple(
                    sorted(
                        set((*alternative.instruction_refs, *alternative.memory_refs))
                    )
                ),
                confidence=alternative.prior,
            ),
        ]
        if selected_ablation.counter_hypothesis:
            hypotheses.extend(
                (
                    GenericHypothesis(
                        hypothesis_id="hypothesis:counter:"
                        + digest_object(
                            (
                                tuple(
                                    item.hazard_likelihood
                                    for item in ranked_predictions
                                ),
                                hypothesis_revision_digest,
                            )
                        )[:20],
                        model_type="counter_hypothesis",
                        statement=(
                            "The apparent progress prior may be a hazard or "
                            "non-causal visual change."
                        ),
                        predictions=(
                            "IRREVERSIBLE_FAILURE",
                            "NO_VISIBLE_CHANGE",
                        ),
                        falsification_conditions=(
                            "bounded probes repeatedly produce safe progress",
                        ),
                        contradicting_evidence=tuple(
                            sorted(
                                {
                                    ref
                                    for item in ranked_predictions
                                    for ref in item.memory_refs
                                }
                            )
                        ),
                        confidence=max(
                            item.hazard_likelihood for item in ranked_predictions
                        ),
                    ),
                    GenericHypothesis(
                        hypothesis_id="hypothesis:null:"
                        + digest_object(
                            (
                                representation.digest_value,
                                hypothesis_revision_digest,
                            )
                        )[:20],
                        model_type="null_model",
                        statement=(
                            "No legal action has yet been shown to cause progress; "
                            "observation error or delayed effect remains possible."
                        ),
                        predictions=(
                            "DELAYED_EFFECT",
                            "NO_VISIBLE_CHANGE",
                            "OBSERVATION_ERROR",
                        ),
                        falsification_conditions=(
                            "one action has reproducible immediate progress",
                        ),
                        confidence=max(item.uncertainty for item in ranked_predictions),
                    ),
                )
            )
        hypotheses.extend(
            development_hypotheses(
                records,
                observation,
                include_counter_hypotheses=(
                    selected_ablation.counter_hypothesis
                ),
            )
        )
        stages.append(
            Layer0StageTrace(
                stage="model",
                input_digest=memory_query_digest,
                output_digest="generic-model-set:" + digest_object(hypotheses),
                selected_refs=tuple(item.hypothesis_id for item in hypotheses),
            )
        )
        stages.append(
            Layer0StageTrace(
                stage="predict",
                input_digest=instruction_result.query_digest,
                output_digest="generic-predictions:"
                + digest_object(ranked_predictions),
                selected_refs=instruction_result.selected_instruction_refs,
            )
        )

        execute_eligible_memory_refs = {
            record.memory_id
            for record in records
            if (
                record.state not in {"PROPOSED", "PROBATION"}
                and record.payload().get("execute_eligibility") is True
            )
        }
        candidates: list[GenericCandidate] = []
        for prediction in ranked_predictions:
            evidence_binding_key = build_evidence_binding_key(
                topology_tokens=representation.topology_tokens,
                relations=representation.relations,
                descriptor_semantic_key=prediction.descriptor.semantic_key,
                action_id=prediction.descriptor.action_id,
                target_role=prediction.descriptor.target_role,
                payload_fields=tuple(
                    key for key, _ in prediction.descriptor.payload_items
                ),
                predicted_effects=prediction.predicted_effects,
            )
            evidence_bindings = bind_candidate_records(
                key=evidence_binding_key,
                records=records,
            )
            prediction_ref = "prediction:" + digest_object(prediction)
            memory_binding_refs = tuple(
                sorted({binding.record_digest for binding in evidence_bindings})
            )
            counter_evidence_refs = tuple(
                sorted(
                    {
                        binding.record_digest
                        for binding in evidence_bindings
                        if (
                            binding.hazard_count > 0
                            or binding.contradiction_count > 0
                            or not binding.precondition_match
                            or not binding.effect_compatible
                            or not binding.scope_applicable
                        )
                    }
                )
            )
            bound_record_ids = {binding.record_id for binding in evidence_bindings}
            memory_effects = _memory_effects(
                records,
                bound_record_ids,
            )
            operation = (
                "ACTION"
                if prediction.progress_likelihood >= 0.55
                and prediction.hazard_likelihood <= 0.25
                and any(
                    ref in execute_eligible_memory_refs
                    for ref in prediction.memory_refs
                )
                else "BOUNDED_PROBE"
            )
            candidate_id = "candidate:generic:" + digest_object(
                {
                    "command": command.command_id,
                    "descriptor": prediction.descriptor,
                }
            )[:24]
            plan = _candidate_plan(
                candidate_id=candidate_id,
                operation=operation,
                prediction=prediction,
                hypotheses=hypotheses,
                observation=observation,
                representation=representation,
                action_history=action_history,
                memory_refs=memory_binding_refs,
            )
            candidates.append(
                GenericCandidate(
                    candidate_id=candidate_id,
                    descriptor=prediction.descriptor,
                    operation=operation,
                    expected_progress=prediction.progress_likelihood,
                    expected_information_gain=prediction.information_gain,
                    expected_risk=prediction.hazard_likelihood,
                    uncertainty=prediction.uncertainty,
                    prediction_refs=(prediction_ref,),
                    provenance=(
                        instruction_body.digest(),
                        instruction_result.query_digest,
                        representation.digest_value,
                        p_ir_execution.program_logical_digest,
                        LOCAL_CAPABILITY_VERSION,
                        GENERIC_COMPUTE_VERSION,
                    ),
                    evidence_binding_key=evidence_binding_key,
                    evidence_bindings=evidence_bindings,
                    typed_provenance=TypedCandidateProvenance(
                        p_instruction_refs=tuple(
                            sorted(set(prediction.instruction_refs))
                        ),
                        representation_refs=(representation.digest_value,),
                        prediction_refs=(prediction_ref,),
                        memory_binding_refs=memory_binding_refs,
                        counter_evidence_refs=counter_evidence_refs,
                        runtime_version=GENERIC_COMPUTE_VERSION,
                    ),
                    plan=plan,
                    memory_effects=memory_effects,
                )
            )
        if not selected_ablation.candidate_diversity:
            candidates = candidates[:1]
        stages.append(
            Layer0StageTrace(
                stage="candidate",
                input_digest="generic-predictions:" + digest_object(ranked_predictions),
                output_digest="generic-candidates:" + digest_object(candidates),
                selected_refs=tuple(item.candidate_id for item in candidates),
            )
        )
        result = GenericComputeResult(
            command_id=command.command_id,
            representation=representation,
            memory_citations=citations,
            hypotheses=tuple(hypotheses),
            predictions=ranked_predictions,
            candidates=tuple(candidates),
            stages=tuple(stages),
            instruction_body_format=instruction_body.format_id(),
            instruction_body_version=instruction_body.body_version(),
            instruction_body_digest=instruction_body.digest(),
            p_ir_logical_digest=p_ir_execution.program_logical_digest,
            p_ir_execution_digest=p_ir_execution.execution_digest,
            l0_abi_version=selected_program.l0_abi_version,
            uncertainty=max(item.uncertainty for item in ranked_predictions),
            provenance=(
                instruction_body.provenance_digest(),
                memory_query_digest,
                p_ir_execution.program_logical_digest,
                p_ir_execution.execution_digest,
                LOCAL_CAPABILITY_VERSION,
                GENERIC_COMPUTE_VERSION,
            ),
            control_operation=instruction_result.control_operation,
            control_instruction_refs=(instruction_result.control_instruction_refs),
        )
        return result


__all__ = [
    "ComputeAblation",
    "GENERIC_COMPUTE_VERSION",
    "GENERIC_P_REMOVAL_WITNESS",
    "GENERIC_SERIAL_DEPTH_WITNESS",
    "GenericComputeSubject",
    "GenericInstructionBody",
    "HybridRelationalInstructionBody",
    "InstructionBodyResult",
    "ParametricRelationalInstructionBody",
    "SemanticMemoryReader",
    "SymbolicRelationalInstructionBody",
    "action_descriptors",
    "represent_observation",
]
