import sys,json,collections,copy
from pathlib import Path
P=Path(__file__).parent;sys.path[:0]=[str(P),str(P.parent),str(P.parent/'reidentification_v1')]
import learn_persistence as lp
import audit_all_plans as audit
from reidentify import all_decompositions,selected_hypotheses,normalize
from experiment import HDS学習系統

def canonical_parts(parts):return sorted((tuple(sorted(normalize(p))),tuple(sorted(p)))for p in parts)
def selected_key(hyp,axes):
 role,idx=hyp['selected'];return (role,tuple(sorted(hyp['parts'][idx])))if role=='body'else(role,axes[idx]['方向'],axes[idx]['位置'])

def filter_history(hyps,axes,memory):
 if memory is None:return list(hyps)
 matches=[]
 for h in hyps:
  for pred in memory['全予測']:
   if canonical_parts(h['parts'])==canonical_parts(pred['parts'])and[(a['方向'],a['位置'])for a in axes]==[(a['方向'],a['位置'])for a in pred['axes']]and selected_key(h,axes)==selected_key(pred,pred['axes']):matches.append(h);break
 return matches

def main():
 audit.H=HDS学習系統.読み込む(P/'unified_with_persistence_state.json');audit.cache.clear();fixtures=json.load(open(P.parent/'reidentification_v1/frozen_observation_fixtures.json'));old=json.load(open(P.parent/'reidentification_v1/all46_reidentification_audit.json'));results=[];counts=collections.Counter();previous_holds=[]
 for fixture,oldplan in zip(fixtures,old):
  memory=None;records=[]
  for index,s in enumerate(fixture['全前観測']):
   obs=s['前観測'];parts,domain=all_decompositions(obs['黒占有'],fixture['既観測形状']);visible_hyps=selected_hypotheses(parts,obs['白標識'],obs['黄目標'],obs['軸'],obs['可視選択軸索引']);hyps=list(visible_hyps);history=None
   if memory is not None:
    matches=filter_history(hyps,obs['軸'],memory)
    hyps=matches;history={'直前作用':memory['作用'],'直前段':memory['段'],'観測で確定した前選択仮説':memory['前選択仮説'],'選択保持/選択作用の支持':memory['支持'],'全事後仮説':memory['全予測'],'現在黒占有/軸との再照合後':len(matches),'予定対象/未実行の次操作で絞らない':True}
   effects=[audit.effect(h,obs['軸'],s['作用'])for h in hyps];keys=set();holds=[];newmemory=[];support=[]
   if not hyps:holds.append('現在可視選択候補と、観測・既経過作用の支持された履歴が整合しない')
   for h,ef in zip(hyps,effects):
    if 'HOLD'in ef:holds.append(ef['HOLD']);continue
    for o in ef['候補']:keys.add(json.dumps(o['効果'],ensure_ascii=False,sort_keys=True,default=lambda z:sorted(z)))
    if s['作用']['id']in audit.e.D:
     o={'全選択仮説':[h],'軸':obs['軸']};f,reason=lp.facts(o,s['作用']);q=audit.query(audit.e.encode(f,True),lp.BOUNDARY,lp.RESULT)if f else None;support.append({'種類':'方向後の同一選択対象保持','照会':q,'前観測のみの前提':f})
     if not q or q['値']is not True:holds.append('方向後の選択保持が同じHDSに支持されないため履歴を持ち越さない')
     else:newmemory.extend(o['次仮説']for o in ef['候補'])
    else:
     # クリック/軸循環の直後選択は既存の明示的な後選択教師から得る。
     support.append({'種類':'既存の後選択/軸循環結果','照会':ef['照会']});newmemory.extend(o['次仮説']for o in ef['候補'])
   if len(keys)!=1:holds.append('全仮説の作用/占有delta/次選択効果が一致しない')
   status='HOLD'if holds else'全観測・学習済み履歴仮説で支持効果一致';counts[status]+=1
   prevhold=oldplan['全段'][index]['監査']['状態']=='HOLD'
   record={'手':s['手'],'作用':s['作用'],'前観測だけの分解数':len(parts),'前観測だけの選択仮説数':len(visible_hyps),'履歴gate後の全仮説':hyps,'履歴照会':history,'現在作用の全HDS照会効果':effects,'次観測へ保持する支持':support,'状態':status,'HOLD':holds,'旧再識別gateHOLD':prevhold,'旧固定条件':s['旧固定条件'],'実行許可':False};records.append(record)
   if prevhold:previous_holds.append({'資料':fixture['資料'],'開始':fixture['開始'],'候補番号':fixture['候補番号'],'手':s['手'],'新状態':status,'旧選択候補数':len(visible_hyps),'履歴後候補数':len(hyps),'支持':history})
   memory={'全予測':newmemory,'作用':s['作用'],'段':s['手'],'前選択仮説':hyps,'支持':support}if status!='HOLD'else None
  results.append({'資料':fixture['資料'],'開始':fixture['開始'],'候補番号':fixture['候補番号'],'全段':records,'全段gate成立':all(r['状態']!='HOLD'for r in records),'実行許可':False,'条件':'live未観測。二軸・D4空像同値・全応答相の条件は維持。'})
 lp.save('all46_history_gate_review.json',results);lp.save('old18_history_admission.json',previous_holds);lp.save('history_gate_queries.json',audit.cache);summary={'全手順':len(results),'全段':sum(counts.values()),'段採否':dict(counts),'全段gate成立手順':sum(r['全段gate成立']for r in results),'旧18段採否':dict(collections.Counter(r['新状態']for r in previous_holds)),'履歴由来':'直前までの可視選択候補、既経過作用、学習済み選択保持、現在黒占有/軸の再照合。未来の目標や予定対象IDを使わない。','合成fixtureでありlive実測ではない':True,'二軸/D4空像条件は維持':True};lp.save('history_gate_summary.json',summary);print(summary,flush=True)
if __name__=='__main__':main()
