import sys,json,collections,itertools,copy,hashlib
from pathlib import Path
P=Path(__file__).parent;sys.path[:0]=[str(P.parent),str(P.parent/'reidentification_v1')]
import experiment as e,observation_v3 as v
from reidentify import all_decompositions,selected_hypotheses,normalize
BOUNDARY='公開鏡像:可視対応による作用後の選択対象保持';RESULT='作用後も同一対象選択'
def save(n,x):(P/n).write_text(json.dumps(x,ensure_ascii=False,indent=2,default=lambda x:sorted(x)if isinstance(x,(set,frozenset))else str(x)))
def observed(frame,shapes,expected_axes):
 s=v.scene(frame);B=s['本体'];blocked=s['目標']|{p for p in B if any(p[a['方向']]==a['位置']for a in s['軸'])};W={p for p in B-blocked if s['セル'][p]['中心']==0};axsel=[i for i,a in enumerate(s['軸'])if a['選択']];ds,domain=all_decompositions(B,shapes);hs=selected_hypotheses(ds,W,s['目標'],s['軸'],axsel[0]if len(axsel)==1 else None);reason=[]
 if s['不明']or len(s['軸'])!=expected_axes:reason.append('セル/軸の知覚不確定')
 if len(axsel)>1:reason.append('選択軸の一意性不成立')
 if len(hs)!=1:reason.append('前観測だけで分解/選択対応が一意ではない')
 if hs and hs[0]['selected'][0]=='body'and not W:reason.append('白標識なし。候補一つでも明示選択証拠と数えない')
 if not W and not axsel:reason.append('明示的な選択標識を観測できない')
 return {'観測':e.compact(s),'白標識':W,'軸':s['軸'],'分解探索':domain,'全選択仮説':hs,'HOLD':reason}
def subject(obs):
 h=obs['全選択仮説'][0];role,i=h['selected']
 if role=='axis':return ('軸',obs['軸'][i]['方向'])
 sig=normalize(h['parts'][i]);matches=[j for j,p in enumerate(h['parts'])if normalize(p)==sig]
 return ('形',tuple(sorted(sig)))if len(matches)==1 else None

def facts(obs,action):
 h=obs['全選択仮説'][0];role,idx=h['selected'];act=action['id'];other=False
 if act in e.D:kind='方向候補1-4'
 elif act==5:kind='循環候補5'
 elif act==6:
  kind='座標候補6';point=(action['data']['x']//3,action['data']['y']//3);hits=[i for i,p in enumerate(h['parts'])if point in p]
  if len(hits)>1:return None,'クリックが複数対象に重複し包含対応不確定'
  # 軸包含クリックは別の未学習作用として保留する。
  if not hits and any(point[a['方向']]==a['位置']and a['可動']for a in obs['軸']):return None,'可動軸包含クリック効果は未同定'
  other=bool(hits)and(role!='body'or hits[0]!=idx)
 else:return None,'方向/循環/座標以外。取消等の選択履歴前提を未同定'
 return {'作用クラス':kind,'前選択役割':'本体'if role=='body'else'鏡軸','選択可能対象が複数':len(h['parts'])+sum(a['可動']for a in obs['軸'])>1,'クリックは別対象固有領域':other},None

def main():
 prov=json.load(open(e.OUT/'provenance.json'));data=[];allrows=[]
 for kind in('success','failure'):
  rows=[json.loads(l)['data']for l in open(prov['公開資料'][kind]['path'])];limit=prov['原票区間']['success'][2]['終了']if kind=='success'else len(rows)-1;init=v.scene(rows[0]['frame'][-1]);shapes=[normalize(o['点'])for o in init['対象']];na=len(init['軸'])
  for n in range(1,limit+1):
   a,b=rows[n-1],rows[n];src={'資料':kind,'前行':n-1,'後行':n}
   if not a.get('frame')or not b.get('frame'):allrows.append({**src,'HOLD':['非frame終端集計'],'原票':b});continue
   pre=observed(a['frame'][-1],shapes,na);post=observed(b['frame'][0],shapes,na);record={**src,'作用':b['action_input'],'前観測':pre,'後観測':post,'HOLD':pre['HOLD']+post['HOLD'],'hidden_delta':'公開未観測'}
   if b['score']!=a['score']or b['state']!=a['state']or b.get('full_reset')or b['action_input']['id']==0:record['HOLD'].append('得点/状態/RESET境界は同一対象保持の支持へ入れない')
   if not record['HOLD']:
    x,y=subject(pre),subject(post);f,reason=facts(pre,b['action_input'])
    if x is None or y is None:record['HOLD'].append('同形対象が複数で前後同一性を観測から確定できない')
    elif reason:record['HOLD'].append(reason)
    else:
     label=x==y;record['教師']={**f,RESULT:label};record['前同一性記述']=x;record['後同一性記述']=y;data.append({'前提':f,'ラベル':label,'出所':src,'前後一意証拠':record})
   allrows.append(record)
   if b['score']>a['score']or b['action_input']['id']==0:
    init=v.scene(b['frame'][-1]);shapes=[normalize(o['点'])for o in init['対象']];na=len(init['軸'])
 save('all_observed_candidates.json',allrows);save('raw_teachers.json',data)
 print('teachers',len(data),'labels',collections.Counter(x['ラベル']for x in data),'HOLD',sum(bool(x['HOLD'])for x in allrows),flush=True)
 groups=collections.defaultdict(list)
 for x in data:groups[json.dumps(x['前提'],ensure_ascii=False,sort_keys=True)].append(x)
 sequence=[]
 while any(groups.values()):
  for key in sorted(groups):
   if groups[key]:sequence.append(groups[key].pop(0))
 save('exact_input_order.json',sequence)
 h=e.HDS学習系統.読み込む(e.OUT/'unified_expanded_state.json');logs=[]
 for x in sequence:logs.append(e.teach(h,{**e.encode(x['前提'],True),RESULT:x['ラベル']},BOUNDARY,x['出所']))
 save('teachers_actual_results.json',logs);h.保存する(P/'unified_with_persistence_state.json');queries=[]
 for x in data:queries.append(e.ask(h,e.encode(x['前提'],True),BOUNDARY,RESULT))
 old=json.load(open(e.OUT/'unified_all_boundary_queries.json'));oldchecks=[]
 keys={e.GOAL:'成功遷移',e.LINK:'鏡映予測複製と実測が一致',e.MOVE:'実測局所変位',e.SELECT:'後選択','公開鏡像:可視性別D4候補':'複製と観測整合','公開鏡像:軸からの選択循環':'後選択役割'}
 for x in old:
  q=e.ask(h,x['照会']['入力'],x['境界'],keys[x['境界']]);oldchecks.append({'旧':x,'新':q,'一致':q['値']==x['期待']})
 save('all_queries.json',queries);save('old44_regression.json',oldchecks);summary={'選択保持教師数':len(data),'保持True':sum(x['ラベル']for x in data),'変更False':sum(not x['ラベル']for x in data),'候補HOLD保持数':sum(bool(x['HOLD'])for x in allrows),'選択保持照会一致':sum(q['値']==x['ラベル']for q,x in zip(queries,data)),'選択保持HOLD':sum(q['値']is None for q in queries),'誤り':sum(q['値']not in(None,x['ラベル'])for q,x in zip(queries,data)),'旧44一致':sum(x['一致']for x in oldchecks),'新規機構/中核変更':False};save('summary.json',summary);print(summary,flush=True)
if __name__=='__main__':main()
