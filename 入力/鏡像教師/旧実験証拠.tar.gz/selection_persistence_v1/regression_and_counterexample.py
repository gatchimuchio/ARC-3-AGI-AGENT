import sys,json,collections,hashlib
from pathlib import Path
P=Path(__file__).parent;sys.path[:0]=[str(P),str(P.parent),str(P.parent/'reidentification_v1')]
import learn_persistence as lp
import audit_all_plans as audit
import validate_public_observations as oldraw
from experiment import HDS学習系統,外部入力

def main():
 audit.H=HDS学習系統.読み込む(P/'unified_with_persistence_state.json');audit.cache.clear();(P/'occupancy_regression').mkdir(exist_ok=True);oldraw.save=lambda n,x:lp.save('occupancy_regression/'+n,x);oldraw.main()
 prov=json.load(open(lp.e.OUT/'provenance.json'));records=[];queries={};counts=collections.Counter()
 for kind,m in prov['公開資料'].items():
  rows=[json.loads(l)['data']for l in open(m['path'])];initial=lp.v.scene(rows[0]['frame'][-1]);shapes=[lp.normalize(o['点'])for o in initial['対象']];na=len(initial['軸'])
  for n in range(1,len(rows)):
   a,b=rows[n-1],rows[n];r={'資料':kind,'前行':n-1,'後行':n}
   if not a.get('frame')or not b.get('frame'):r.update({'状態':'HOLD','理由':['非frame終端']});counts['HOLD']+=1;records.append(r);continue
   # 成功遷移を保持支持にしない。非進行作用は全応答完了後の末尾で確認。
   pre=lp.observed(a['frame'][-1],shapes,na);post=lp.observed(b['frame'][-1],shapes,na);r.update({'作用':b['action_input'],'前観測':pre,'後観測':post,'応答相数':len(b['frame'])});holds=pre['HOLD']+post['HOLD']
   if b['score']!=a['score']or b['state']!=a['state']or b.get('full_reset')or b['action_input']['id']==0:holds.append('問題/状態/RESET境界')
   if not holds:
    subjbefore,subjafter=lp.subject(pre),lp.subject(post);f,reason=lp.facts(pre,b['action_input'])
    if subjbefore is None or subjafter is None:holds.append('同形対象で同一性を確定できない')
    elif reason:holds.append(reason)
    else:
     key=json.dumps(f,ensure_ascii=False,sort_keys=True)
     if key not in queries:queries[key]=lp.e.ask(audit.H,lp.e.encode(f,True),lp.BOUNDARY,lp.RESULT)
     q=queries[key];actual=subjbefore==subjafter;r.update({'前提':f,'実測同一対象保持':actual,'照会':q,'状態':'HOLD'if q['値']is None else'一致'if q['値']==actual else'反証'});counts[r['状態']]+=1
   if holds:r.update({'状態':'HOLD','理由':holds});counts['HOLD']+=1
   records.append(r)
   if b['score']>a['score']or b['action_input']['id']==0:
    initial=lp.v.scene(b['frame'][-1]);shapes=[lp.normalize(o['点'])for o in initial['対象']];na=len(initial['軸'])
 lp.save('all_public_persistence_checks.json',records);lp.save('persistence_development_queries.json',queries);lp.save('persistence_development_summary.json',{'全遷移':len(records),'集計':dict(counts),'前後一意の実観測だけで比較':True,'後は非進行作用の末尾frame':True,'未見最終評価':False})
 # 新関係を反証した別stateが旧/新境界すべてをHOLDすることを検査。
 bad=HDS学習系統.読み込む(P/'unified_with_persistence_state.json');source=next(x for x in json.load(open(P/'raw_teachers.json'))if x['前提']['作用クラス']=='方向候補1-4'and x['前提']['前選択役割']=='本体'and x['前提']['選択可能対象が複数']);counter=lp.e.teach(bad,{**lp.e.encode(source['前提'],True),lp.RESULT:False},lp.BOUNDARY,{'資料':'人工反証・本番へ混ぜない','目的':'新しい保持原理への矛盾でも全境界HOLDを維持'});old=json.load(open(lp.e.OUT/'unified_all_boundary_queries.json'));keys={lp.e.GOAL:'成功遷移',lp.e.LINK:'鏡映予測複製と実測が一致',lp.e.MOVE:'実測局所変位',lp.e.SELECT:'後選択','公開鏡像:可視性別D4候補':'複製と観測整合','公開鏡像:軸からの選択循環':'後選択役割'};qs=[{'境界':x['境界'],'照会':lp.e.ask(bad,x['照会']['入力'],x['境界'],keys[x['境界']])}for x in old]+[{'境界':lp.BOUNDARY,'照会':lp.e.ask(bad,lp.e.encode(x['前提'],True),lp.BOUNDARY,lp.RESULT)}for x in json.load(open(P/'raw_teachers.json'))];lp.save('synthetic_new_relation_counterexample.json',{'入力':counter,'全旧新照会':qs});bad.保存する(P/'synthetic_counterexample_state.json')
 oldorder=json.load(open(lp.e.OUT/'final_all_input_order.json'));neworder=json.load(open(P/'teachers_actual_results.json'));order=list(oldorder)
 for i,x in enumerate(neworder):order.append({'全順序':len(order)+1,'段階':'selection_persistence_v1/teachers_actual_results.json','段階内順':i+1,'境界':x['境界'],'教師':x['教師'],'出所':x['出所'],'経験参照':x['追跡'].get('経験参照')})
 lp.save('final_all_input_order.json',order);core=json.load(open(lp.e.OUT/'core_hashes.json'));assert all(hashlib.sha256((lp.e.ROOT/p).read_bytes()).hexdigest()==sha for p,sha in core.items());summary={'旧44一致':sum(x['一致']for x in json.load(open(P/'old44_regression.json'))),'占有再検証':json.load(open(P/'occupancy_regression/public_summary.json')),'選択保持開発照合':dict(counts),'人工新原理反証で全旧新照会HOLD':all(q['照会']['値']is None for q in qs),'全入力数':len(order),'中核不変':True,'fresh成功':False};lp.save('regression_summary.json',summary);print(summary,flush=True)
if __name__=='__main__':main()
