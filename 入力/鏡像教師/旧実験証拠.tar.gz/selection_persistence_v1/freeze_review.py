import json,hashlib,collections
from pathlib import Path
P=Path(__file__).parent
load=lambda n:json.load(open(P/n))
manifest={'版':'選択対象保持の公開教師学習と履歴gate別版v1','前版':'../reidentification_v1/review_manifest.json','前版42/4と18HOLDは全digest不変':load('checks.json')['前版42/4の凍結全digest不変'],'教える関係':'方向/循環/座標候補と明示的な前後選択対応から同一観測対象の保持/変更をHDSへ学習','学習':load('summary.json'),'履歴gate':load('history_gate_summary.json'),'回帰':load('regression_summary.json'),'負例':load('history_negative_controls.json'),'旧固定条件':{'二軸合成':{'手順':22,'段':968,'HDS単軸からの直接一般化とはしない':True},'D4空像同値':{'手順':12,'段':82,'候補を一意へ潰さない':True}},'future観測fixture':'保守的合成応答。live未観測。予定対象ID/完成答えをgateへ渡さず、既経過作用の支持結果と現在占有を再照合','actual_HDS':'unified_with_persistence_state.json','actual_HDS_sha256':hashlib.sha256((P/'unified_with_persistence_state.json').read_bytes()).hexdigest(),'人工反証state':'synthetic_counterexample_state.json','実行許可':False,'fresh成功':False,'独立レビュー入口':['learn_persistence.py','raw_teachers.json','all_observed_candidates.json','exact_input_order.json','history_gate_review.py','all46_history_gate_review.json','old18_history_admission.json','regression_summary.json','synthetic_new_relation_counterexample.json','checks.json'],'中核/権限/currentstate/remote変更':False}
(P/'review_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
hashes={str(p.relative_to(P)):hashlib.sha256(p.read_bytes()).hexdigest()for p in P.rglob('*')if p.is_file()and p.suffix!='.log'and '__pycache__'not in str(p)and p.name!='frozen_hashes.json'}
(P/'frozen_hashes.json').write_text(json.dumps(hashes,ensure_ascii=False,indent=2));assert manifest['回帰']['人工新原理反証で全旧新照会HOLD']and manifest['履歴gate']['全段gate成立手順']==46
print('Frozen for independent review:',len(hashes),'files',flush=True)
