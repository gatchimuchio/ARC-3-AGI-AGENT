import json,copy,hashlib,collections
import learn_persistence as lp
import audit_all_plans as audit
from history_gate_review import filter_history
from reidentify import all_decompositions,selected_hypotheses
P=lp.P
audit.H=lp.e.HDS学習系統.読み込む(P/'unified_with_persistence_state.json');audit.cache.clear()
obs={'黒占有':[(0,0),(1,0),(4,0),(5,0)],'白標識':[],'黄目標':[(0,0),(1,0),(4,0),(5,0)],'軸':[{'方向':0,'位置':10,'可動':False}],'可視選択軸索引':None};shape=[[(0,0),(1,0)],[(0,0),(1,0)]];decs,_=all_decompositions(obs['黒占有'],shape);hyps=selected_hypotheses(decs,obs['白標識'],obs['黄目標'],obs['軸'],None)
unknown={'全予測':[{'parts':h['parts'],'selected':h['selected'],'axes':obs['軸']}for h in hyps]};retained=filter_history(hyps,obs['軸'],unknown);assert len(retained)==len(hyps)
keys=set()
for h in retained:
 r=audit.effect(h,obs['軸'],{'id':4,'data':{}})
 for o in r['候補']:keys.add(json.dumps(o['効果'],ensure_ascii=False,sort_keys=True,default=lambda x:sorted(x)))
assert len(keys)>1
wrong=copy.deepcopy(unknown)
for p in wrong['全予測']:p['parts']=tuple(frozenset((x,y+1)for x,y in pts)for pts in p['parts'])
assert not filter_history(hyps,obs['軸'],wrong)
# 新保持原理があっても、未観測の初期選択を勝手に選べない。違う占有履歴も適合させない。
control={'初期選択曖昧を持つ履歴':{'前候補数':len(hyps),'保持候補数':len(retained),'相異作用効果':len(keys),'採否':'HOLD'},'現在占有と矛盾する履歴':{'整合候補数':0,'採否':'HOLD'},'新保持原理でも不明選択を一つにしない':True}
lp.save('history_negative_controls.json',control)
summary=json.load(open(P/'regression_summary.json'));assert summary['旧44一致']==44 and summary['占有再検証']['集計']['占有一致']==2694 and summary['人工新原理反証で全旧新照会HOLD'];assert summary['選択保持開発照合'].get('反証',0)==0
hist=json.load(open(P/'history_gate_summary.json'));assert hist['全段gate成立手順']==46 and sum(hist['段採否'].values())==1524
newh=lp.e.HDS学習系統.読み込む(P/'unified_with_persistence_state.json');assert lp.e.ask(newh,{'黄標識全被覆':True},lp.e.GOAL,'成功遷移')['値']is True
hashes=json.load(open(lp.e.OUT/'reidentification_v1/frozen_hashes.json'));old_hash_ok=all(hashlib.sha256((lp.e.OUT/'reidentification_v1'/n).read_bytes()).hexdigest()==sha for n,sha in hashes.items());assert old_hash_ok
lp.save('checks.json',{'結果':'PASS','新保持原理の単独強制選択を禁止':True,'矛盾履歴はHOLD':True,'旧2694/44維持':True,'人工新原理反証で全境界HOLD':True,'前版42/4の凍結全digest不変':old_hash_ok,'46手順条件付きgate成立':True,'fresh成功':False})
print('PASS')
