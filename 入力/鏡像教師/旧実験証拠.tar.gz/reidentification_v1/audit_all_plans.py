import sys,json,copy,itertools,collections,hashlib,ast
from pathlib import Path
P=Path(__file__).parent;sys.path.insert(0,str(P.parent))
import experiment as e,observation_v3 as v
from reidentify import all_decompositions,selected_hypotheses,normalize
H=e.HDS学習系統.読み込む(e.OUT/'unified_expanded_state.json');cache={}
def save(n,x):(P/n).write_text(json.dumps(x,ensure_ascii=False,indent=2,default=lambda x:sorted(x)if isinstance(x,(set,frozenset))else str(x)))
def query(f,b,k):
 key=json.dumps([f,b,k],ensure_ascii=False,sort_keys=True)
 if key not in cache:cache[key]=e.ask(H,f,b,k)
 return cache[key]

def effect(hyp,axes,action):
 parts=hyp['parts'];role,idx=hyp['selected'];act=action['id'];ax=copy.deepcopy(axes);q=[];outs=[]
 if act in e.D:
  sc={'選択':{'役割':'本体','対象':{'点':parts[idx]}}if role=='body'else{'役割':'鏡軸','対象':ax[idx]}}
  facts=e.facts(sc,act);qq=query(e.encode(facts,True),e.MOVE,'実測局所変位');q.append(qq)
  if qq['値']is None:return {'HOLD':'局所作用未支持','照会':q}
  dx,dy=ast.literal_eval(qq['値']);new=list(parts)
  if role=='body':new[idx]=frozenset((x+dx,y+dy)for x,y in parts[idx])
  else:ax[idx]['位置']+=(dx,dy)[ax[idx]['方向']]
  outs=[{'parts':tuple(new),'selected':(role,idx),'axes':ax}]
 elif act==6:
  point=(action['data']['x']//3,action['data']['y']//3);clicked=[i for i,p in enumerate(parts)if point in p]
  if not clicked:return {'HOLD':'未学習クリック包含外','照会':[]}
  for i in clicked:
   f={'対象役割':'本体','クリック包含':True,'前選択':role=='body'and i==idx,'クリックは選択可能領域':True};qq=query(e.encode(f,True),e.SELECT,'後選択');q.append(qq)
   if qq['値']is not True:return {'HOLD':'本体選択未支持','照会':q}
   outs.append({'parts':parts,'selected':('body',i),'axes':ax})
 elif act==5:
  if role!='axis':return {'HOLD':'本体からの選択循環は未学習','照会':[]}
  f={'現選択軸方向':ax[idx]['方向'],'可動軸数':sum(a['可動']for a in ax)};qq=query(e.encode(f,True),'公開鏡像:軸からの選択循環','後選択役割');q.append(qq)
  if qq['値']is None:return {'HOLD':'軸循環未支持','照会':q}
  if qq['値']=='本体':outs=[{'parts':parts,'selected':('body',i),'axes':ax}for i in range(len(parts))]
  elif qq['値'].startswith('軸方向'):
   indices=[i for i,a in enumerate(ax)if a['方向']==int(qq['値'][-1])];outs=[{'parts':parts,'selected':('axis',i),'axes':ax}for i in indices]
  else:return {'HOLD':'循環後役割が語彙外','照会':q}
 else:return {'HOLD':'未学習作用','照会':[]}
 outputs=[]
 B=set().union(*parts);C=e.visible(e.orbit(B,axes))-B
 for out in outs:
  NB=set().union(*out['parts']);NC=e.visible(e.orbit(NB,out['axes']))-NB;nr,ni=out['selected'];sel={'役割':nr,'点':sorted(out['parts'][ni])}if nr=='body'else{'役割':nr,'方向':out['axes'][ni]['方向'],'位置':out['axes'][ni]['位置']}
  outputs.append({'次仮説':out,'効果':{'本体追加':NB-B,'本体除去':B-NB,'複製追加':NC-C,'複製除去':C-NC,'次軸':[(a['方向'],a['位置'])for a in out['axes']],'次選択対応':sel}})
 return {'照会':q,'候補':outputs}

def gate(obs,shapes,action):
 decomps,domain=all_decompositions(obs['黒占有'],shapes);hyps=selected_hypotheses(decomps,obs['白標識'],obs['黄目標'],obs['軸'],obs['可視選択軸索引']);effects=[effect(h,obs['軸'],action)for h in hyps];keys=set();bad=[]
 for i,r in enumerate(effects):
  if 'HOLD'in r:bad.append({'仮説':i,'理由':r['HOLD']});continue
  for o in r['候補']:keys.add(json.dumps(o['効果'],ensure_ascii=False,sort_keys=True,default=lambda v:sorted(v)))
 holds=bad+([]if hyps else[{'理由':'選択対応または分解なし'}])+([]if len(keys)==1 else[{'理由':'全仮説の占有delta/次選択対応が一致しない','相異効果数':len(keys)}])
 return {'状態':'HOLD'if holds else'全観測仮説で支持効果一致','分解探索':domain,'全分解':decomps,'選択仮説':hyps,'作用照会と効果':effects,'相異効果数':len(keys),'HOLD':holds,'実行許可':False}

def main():
 provenance=json.load(open(e.OUT/'provenance.json'));rows={k:[json.loads(l)['data']for l in open(m['path'])]for k,m in provenance['公開資料'].items()};review=json.load(open('/workspace/scratch/a94ff513b3af/arc-parent-audits/ar25-all46-plan-review.json'));fixtures=[];generation=[]
 # 観測fixtureの生成とgateを分離して一度保存。fixtureは実環境でなく仮想応答。
 # 参照個体集合からは黒unionだけを使い、予定対象/未来操作/完成答えを分解に渡さない。
 for plan in review['plans']:
  initial=v.scene(rows[plan['資料']][plan['開始']]['frame'][-1]);parts=tuple(frozenset(o['点'])for o in initial['対象']);axes=copy.deepcopy(initial['軸']);sel=initial['選択'];selected=('body',next(i for i,o in enumerate(initial['対象'])if o['点']==sel['対象']['点']))if sel['役割']=='本体'else('axis',next(i for i,a in enumerate(axes)if a['方向']==sel['対象']['方向']));physical={'parts':parts,'selected':selected,'axes':axes};steps=[]
  for step in plan['全手']:
   B=set().union(*(set(map(tuple,c))for c in step['前可視8近傍成分']));assert B==set().union(*physical['parts']);ax=physical['axes'];role,idx=physical['selected'];blocked=initial['目標']|{p for p in B if any(p[a['方向']]==a['位置']for a in ax)}
   # 重複の描画優先順を有利に仮定しない。全重複で選択白点が遮蔽された保守的fixture。
   W=physical['parts'][idx]-set().union(*(p for j,p in enumerate(physical['parts'])if j!=idx))-blocked if role=='body'else set()
   obs={'黒占有':B,'白標識':W,'黄目標':initial['目標'],'軸':ax,'可視選択軸索引':idx if role=='axis'else None,'由来':'初期実観測と過去作用から作る保守的合成前観測。live画像ではない。'}
   steps.append({'手':step['手'],'前観測':copy.deepcopy(obs),'作用':step['作用'],'旧再識別HOLD':any('分節' in x for x in step['固定条件']),'旧固定条件':step['固定条件']})
   r=effect(physical,ax,step['作用']);assert 'HOLD'not in r and len(r['候補'])==1;physical=r['候補'][0]['次仮説']
  fixtures.append({'資料':plan['資料'],'開始':plan['開始'],'候補番号':plan['候補番号'],'既観測形状':[normalize(o['点'])for o in initial['対象']],'全前観測':steps})
 save('frozen_observation_fixtures.json',fixtures)
 del fixtures,physical,initial,parts,review,rows
 # ここからgateは保存済みの前観測と既観測形状/要求作用のみ。
 fixtures=json.load(open(P/'frozen_observation_fixtures.json'));results=[];counts=collections.Counter();oldcounts=collections.Counter()
 for f in fixtures:
  records=[]
  for s in f['全前観測']:
   r=gate(s['前観測'],f['既観測形状'],s['作用']);counts[r['状態']]+=1
   if s['旧再識別HOLD']:oldcounts[r['状態']]+=1
   records.append({'手':s['手'],'作用':s['作用'],'旧再識別HOLD':s['旧再識別HOLD'],'旧固定条件':s['旧固定条件'],'監査':r})
  results.append({'資料':f['資料'],'開始':f['開始'],'候補番号':f['候補番号'],'全段':records,'観測gate全段成立':all(r['監査']['状態']!='HOLD'for r in records),'実行許可':False,'継続条件':'二軸合成・D4空像同値・合成応答で未実測という旧条件を保持'})
 save('all46_reidentification_audit.json',results)
 # 意図的な選択曖昧反例。二本の同形棒は双方とも目標に覆われ白点なし。
 obs={'黒占有':[(0,0),(1,0),(4,0),(5,0)],'白標識':[],'黄目標':[(0,0),(1,0),(4,0),(5,0)],'軸':[{'方向':0,'位置':10,'可動':False}],'可視選択軸索引':None};ctrl=gate(obs,[[(0,0),(1,0)],[(0,0),(1,0)]],{'id':4,'data':{}});save('ambiguous_selection_control.json',ctrl);assert ctrl['状態']=='HOLD'
 save('query_cache.json',cache);summary={'全手順':len(results),'全段':sum(counts.values()),'段採否':dict(counts),'旧98段採否':dict(oldcounts),'全段gate成立手順':sum(r['観測gate全段成立']for r in results),'選択曖昧人工対照HOLD':True,'初期形状と現在黒占有だけで全分解列挙':True,'重複許容':True,'予定対象ID/完成答えをgateへ渡さない':True,'元成果不変':True,'実行許可':False,'fresh成功':False,'注意':'合成前観測は未実測。二軸22手順968段/D4空像同値12手順82段/応答途中相の条件を解消していない。'};save('summary.json',summary);print(summary,flush=True)
if __name__=='__main__':main()
