import json,hashlib,collections
from pathlib import Path
from audit_all_plans import e,v,save
P=Path(__file__).parent
rs=json.load(open(P/'all46_reidentification_audit.json'));condition_counts=collections.Counter();condition_plans=collections.Counter();planmanifest=[]
for r in rs:
 conditions=set();holds=[]
 for s in r['全段']:
  for c in s['旧固定条件']:
   if '分節'in c:continue
   condition_counts[c]+=1;conditions.add(c)
  if s['監査']['状態']=='HOLD':holds.append(s['手'])
 for c in conditions:condition_plans[c]+=1
 planmanifest.append({'資料':r['資料'],'開始':r['開始'],'候補番号':r['候補番号'],'全段数':len(r['全段']),'再識別gate':'全段条件付き成立'if not holds else'未採用','観測HOLD段':holds,'残固定条件':sorted(conditions),'live実行許可':False,'全因果が無条件に成立したとの主張':False})
# 新規全相記録は旧親15作用48相をすべて含み、旧HOLDだった2遷移6相も保持する。
old=json.load(open('/workspace/scratch/a94ff513b3af/arc-parent-audits/ar25-multiphase-review.json'));new=json.load(open(P/'all_multiphase_responses.json'));oldkeys={(r['資料'],r['後行'])for r in old};newkeys={(r['資料'],r['後行'])for r in new};assert oldkeys<=newkeys
raw={(r['資料'],r['後行']):r for r in json.load(open(P/'all_public_observation_gate.json'))};phasechecks=[]
for r in new:
 g=raw[r['資料'],r['後行']].get('観測gate');pred=None
 if g and g['状態']!='HOLD':
  out=g['作用照会と効果'][0]['候補'][0]['次仮説'];B=set().union(*(set(map(tuple,p))for p in out['parts']));C=e.visible(e.orbit(B,out['axes']))-B;pred=B,C
 records=[]
 for phase in r['全相']:
  s=v.scene(phase['frame']);same=bool(pred)and s['本体']==pred[0]and s['複製']==pred[1];records.append({'相':phase['相'],'知覚不明数':len(s['不明']),'先頭定常予測との占有一致':same,'判定':'観測HOLD:知覚文法外'if s['不明']else'先頭占有一致'if same else'得点遷移後の別問題/演出候補。旧問題作用と同一視しない'if r['後score']>r['前score']else'観測HOLD:同一問題の途中相不一致'})
 phasechecks.append({'資料':r['資料'],'後行':r['後行'],'前score':r['前score'],'後score':r['後score'],'旧親監査に含まれる':(r['資料'],r['後行'])in oldkeys,'全相':records})
save('all_multiphase_checks.json',phasechecks)
core=json.load(open(e.OUT/'core_hashes.json'));assert all(hashlib.sha256((e.ROOT/p).read_bytes()).hexdigest()==h for p,h in core.items())
manifest={'版':'再識別gate別版v1・旧成果を上書きしない','対応要求':'前観測と既観測形状から重複を許した全分解/選択候補、全HDS支持効果一致gate','全手順':46,'全段':1524,'観測gate全段条件付き成立':42,'観測gate未採用':4,'観測HOLD段':18,'全手順採否':planmanifest,'固定条件段数':dict(condition_counts),'固定条件手順数':dict(condition_plans),'作用照合母集団':json.load(open(P/'public_summary.json')),'全相':{'旧親15作用48相を保持':True,'今回全17作用54相':True,'追加作用':[{'資料':k,'後行':n}for k,n in sorted(newkeys-oldkeys)]},'HDS状態':'../unified_expanded_state.json','HDS状態sha256':hashlib.sha256((e.OUT/'unified_expanded_state.json').read_bytes()).hexdigest(),'HDS再学習/中核変更':False,'既存選択対象保持支持':'見つからず、18HOLDを履歴による内部ID持越しで解除しない','実行許可':False,'fresh成功':False,'独立レビュー入口':['reidentify.py','audit_all_plans.py','all46_reidentification_audit.json','history_support_audit.json','all_public_observation_gate.json','all_multiphase_checks.json','ambiguous_selection_control.json'],'再現コマンド':['python reidentification_v1/audit_all_plans.py','python reidentification_v1/validate_public_observations.py','python reidentification_v1/history_support_audit.py','python reidentification_v1/freeze_review.py']}
save('review_manifest.json',manifest)
hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in P.iterdir()if p.is_file()and p.suffix!='.log'and p.name not in('frozen_hashes.json',)};save('frozen_hashes.json',hashes)
print({'42条件付き/4未採用':True,'固定条件段数':dict(condition_counts),'固定条件手順数':dict(condition_plans),'旧15/48+追加2/6':'全保存','core不変':True},flush=True)
