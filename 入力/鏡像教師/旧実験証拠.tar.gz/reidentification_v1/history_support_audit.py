import json,collections
from audit_all_plans import e,query,save,H
rs=json.load(open(e.OUT/'reidentification_v1/all46_reidentification_audit.json'));fixtures=json.load(open(e.OUT/'reidentification_v1/frozen_observation_fixtures.json'));inp=json.load(open(e.OUT/'final_all_input_order.json'));records=[]
for plan,fix in zip(rs,fixtures):
 for i,s in enumerate(plan['全段']):
  if s['監査']['状態']!='HOLD':continue
  prev=plan['全段'][i-1]if i else None;previous_action=prev['作用']if prev else None;context=fix['全前観測'][i-1]['前観測']if prev else None;qs=[]
  if prev:
   for hyp in prev['監査']['選択仮説']:
    role,idx=hyp['selected'];sc={'選択':{'役割':'本体','対象':{'点':set(map(tuple,hyp['parts'][idx]))}}if role=='body'else{'役割':'鏡軸','対象':context['軸'][idx]}}
    if previous_action['id']in e.D:
     facts=e.facts(sc,previous_action['id']);qs.append(query(e.encode(facts,True),e.MOVE,'作用後も同一対象選択'))
  records.append({'資料':plan['資料'],'開始':plan['開始'],'候補番号':plan['候補番号'],'手':s['手'],'直前実行済み扱いの作用':previous_action,'履歴は合成応答でありlive実行記録ではない':True,'直前選択仮説数':len(prev['監査']['選択仮説'])if prev else None,'現在選択仮説数':len(s['監査']['選択仮説']),'保持命題照会':qs,'現在採否':'HOLD保持','理由':'方向作用の実測局所変位は既習だが、作用後も同一選択対象を保持するという結果経路の支持がない。過去作用主体と現在選択の同一性を内部ID持越しで補わない。'})
assert len(records)==18 and all(all(q['値']is None for q in r['保持命題照会'])for r in records)
fields=collections.Counter((r['境界'],tuple(sorted(r['教師'].keys())))for r in inp)
save('history_support_audit.json',{'残18段':records,'既存全入力の出力語彙監査':[{'境界':b,'入力出力欄':keys,'件数':n}for (b,keys),n in fields.items()],'結論':'既存支持では18段を解除しない。選択対象保持の新しい教師/原理を作らずHOLD維持。','全42成立/4未採用維持':True});print('18 HOLD retained; no existing selected-object-persistence result support')
