import json,collections,copy
from audit_all_plans import e,v,gate,save,cache,normalize

def main():
 p=json.load(open(e.OUT/'provenance.json'));allrecords=[];counts=collections.Counter();phases=[]
 for kind,m in p['公開資料'].items():
  rows=[json.loads(l)['data']for l in open(m['path'])];initial=v.scene(rows[0]['frame'][-1]);shapes=[normalize(o['点'])for o in initial['対象']];initial_axes=len(initial['軸'])
  for n in range(1,len(rows)):
   a,b=rows[n-1],rows[n]
   if not a.get('frame')or not b.get('frame'):allrecords.append({'資料':kind,'後行':n,'状態':'HOLD','理由':'非frame終端集計'});counts['非frame']+=1;continue
   s=v.scene(a['frame'][-1]);act=b['action_input'];B=s['本体'];blocked=s['目標']|{p for p in B if any(p[ax['方向']]==ax['位置']for ax in s['軸'])};W={p for p in B-blocked if s['セル'][p]['中心']==0};selected_axes=[i for i,ax in enumerate(s['軸'])if ax['選択']];obs={'黒占有':B,'白標識':W,'黄目標':s['目標'],'軸':s['軸'],'可視選択軸索引':selected_axes[0]if len(selected_axes)==1 else None,'由来':'公開原票の実前frame末尾。解答/予定/内部IDなし'};record={'資料':kind,'前行':n-1,'後行':n,'作用':act,'応答相数':len(b['frame']),'前観測':obs,'hidden_delta':'公開未観測'}
   if len(b['frame'])>1:
    phase=[]
    for fi,f in enumerate(b['frame']):
     sc=v.scene(f);phase.append({'相':fi,'frame':f,'知覚':e.compact(sc),'画素delta':[(x,y,u,z)for y,(ar,br)in enumerate(zip(a['frame'][-1],f))for x,(u,z)in enumerate(zip(ar,br))if u!=z],'同一問題の定常作用後と確定しない':fi>0 and b['score']>a['score']})
    phases.append({'資料':kind,'後行':n,'前score':a['score'],'後score':b['score'],'全相':phase})
   if act['id']not in e.D or b.get('full_reset'):record.update({'状態':'HOLD','理由':'非方向またはresetを保持'});counts['非方向']+=1
   elif s['不明']or len(selected_axes)>1 or len(s['軸'])!=initial_axes:record.update({'状態':'HOLD','理由':'前観測のセル/軸/選択文法が未確定'});counts['前知覚HOLD']+=1
   else:
    g=gate(obs,shapes,act);record['観測gate']=g
    if g['状態']=='HOLD':record['状態']='HOLD';counts['gateHOLD']+=1
    else:
     t=v.scene(b['frame'][0]);out=g['作用照会と効果'][0]['候補'][0]['次仮説'];NB=set().union(*(set(x)for x in out['parts']));NC=e.visible(e.orbit(NB,out['axes']))-NB;match=NB==t['本体']and NC==t['複製'];record.update({'状態':'占有一致'if match else'反証','本体残差':NB^t['本体'],'複製残差':NC^t['複製']});counts[record['状態']]+=1
   allrecords.append(record)
   if b['score']>a['score']or act['id']==0:
    initial=v.scene(b['frame'][-1]);shapes=[normalize(o['点'])for o in initial['対象']];initial_axes=len(initial['軸'])
 save('all_public_observation_gate.json',allrecords);save('all_multiphase_responses.json',phases);save('public_query_cache.json',cache);summary={'全遷移':len(allrecords),'集計':dict(counts),'複数応答作用':len(phases),'全応答相':sum(len(x['全相'])for x in phases),'形状出所':'各実問題の開始観測だけ','完成答え/予定/内部IDで分解しない':True,'live未実行':True};save('public_summary.json',summary);print(summary,flush=True)
if __name__=='__main__':main()
