import resource
resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912))
import runpy
from pathlib import Path
runpy.run_path(str(Path(__file__).with_name('goal6_query_independent_v1.py')),run_name='__main__')
