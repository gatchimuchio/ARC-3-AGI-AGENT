# Goal6 Query6 回帰 checkpoint

## 目的と対象
既存6教示例の作用前条件だけを使う6照会で、学習済み共同キー対応を回帰確認した。旧学習checkpointそのもの1fileと、Q/AQの全保存物を収録する。未確定の原票chain作業は含まない。

## previous / current / delta / regression
previousはTeach6後の凍結標準状態。currentは同じ6例へのQuery6を通常APIで実行し、全返答保存後に外部採点した結果。Teach0、新支持0。
correct6、wrong0、missing0、extra0、HOLD0。全台帳・原理履歴は不変、照会/学習判定counterのみ各+6。全12前後標準状態と13journalを独立監査しPASS。
元75520はroot ACK後にactualexit0、実UTCEND 2026-10-13T09:23:39.655256+00:00。独立監査の最終工具を含め、Q/AQ両writer停止後にcutoffを固定した。

## 限界
これは元6教示例への回帰であり、未見Action/色/条件への転用や新規ゲーム成功ではない。共同キーの可逆固定表現を使った対応であり、AND因果構造を学習した証明ではない。core変更0。after教師は照会入力に流入させず、全返答と採点を保存している。
旧学習archiveにある旧audit FAIL、未閉鎖native29489、失敗fixture18870等も不変に保持する。今回は旧ownerを操作していない。件数やarchive作成を能力改善とは扱わない。

## 保存と検証
旧 goal6-checkpoint.tar.gz は635597B、SHA256 52bd271ff10bf5e12fdfff6205215f94240a85e7e90cda02444b633545118563 のまま1memberとして収録する。その内部に素材・学習・独立監査・回収repo subset・Owner原文・原票参照manifestが入る。元の公開原票3本全体は旧archive README記載の救出archiveを参照する。
query-manifest.jsonに今回全原本のpath、byte数、SHA、regular type、identity、member順を記録。全memberを読み戻しbytes/SHA/type/orderを比較し、元集合とdevice/inode/size/mode/mtime_ns/ctime_nsとSHAの不変を確認する。読取で変わるatimeは除外する。これは保存byte列の完全性検証で、新しいHDS実行や意味監査再実行ではない。
