"""Sets audit address-space limit before importing audit source; no native imports."""
import resource, runpy
resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912))
runpy.run_path(__file__.replace('goal6_independent_outer_v2.py','goal6_independent_v2.py'),run_name='__main__')
