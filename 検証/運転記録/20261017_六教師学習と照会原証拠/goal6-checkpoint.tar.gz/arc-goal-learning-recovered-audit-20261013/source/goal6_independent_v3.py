"""Independent saved-evidence audit. Standard tagged JSON only; no HDS imports/APIs."""
import ast, hashlib, json, lzma, math, os, pathlib, resource, signal, stat, sys, time, traceback
BASE=pathlib.Path('/workspace/scratch/a94ff513b3af')
ROOT=BASE/'arc-goal-learning-recovered-audit-20261013'
NATIVE=BASE/'arc-goal-learning-recovered-20261013'
TEACHER=BASE/'arc-goal-teacher-recovered-20261013'
REPO=BASE/'arc-recovery-main-20261013/repository'
M=1048576
CAPS={'source':196608,'prep_tools':131072,'detail':4*M,'reports':65536,'tools':131072,'failure':M}
TOTAL=6*M
RAM=(768+768+512+512+128)*M
FIELDS=('不足対象は全て修復見込み','既充足対象は全て保存見込み','公開進捗が増加')
KEY='作用前の修復保全条件組'
BOUNDARY='公開100対象・広域塗布・固定幾何上書き仮説の修復保全条件組と公開進捗'
MBOUNDARY='公開100対象・広域塗布・固定幾何上書き仮説と公開進捗'
SELECTION=((0,65,66),(0,74,75),(0,92,93),(2,23,24),(2,60,61),(2,141,142))
ADMISSIONS=[]
READS=[]
DEADLINE=None
TYPES={}
ENUMS={}
def need(v,why):
    if not v:raise AssertionError(why)
def sha(b):return hashlib.sha256(b).hexdigest()
def wire(x):return json.dumps(x,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()
def equal(a,b):
    if type(a) is not type(b):return False
    if isinstance(a,Record):return a.name==b.name and equal(a.fields,b.fields)
    if isinstance(a,EnumValue):return a.name==b.name and equal(a.value,b.value)
    if type(a) is dict:return len(a)==len(b) and all(equal(k,l) and equal(a[k],b[l]) for k,l in zip(a,b))
    if type(a) in (tuple,list):return len(a)==len(b) and all(equal(x,y) for x,y in zip(a,b))
    if type(a) is float:return a.hex()==b.hex()
    return a==b
def parse(b):
    def pairs(xs):
        d={}
        for k,v in xs:
            need(k not in d,'duplicate JSON key');d[k]=v
        return d
    return json.loads(b,object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
class Record:
    def __init__(self,name,fields):self.name=name;self.fields=fields
class EnumValue:
    def __init__(self,name,value):self.name=name;self.value=value
def enc(x):
    if isinstance(x,Record):return {'__データ型__':x.name,'値':{k:enc(v) for k,v in x.fields.items()}}
    if isinstance(x,EnumValue):return {'__列挙__':x.name,'値':x.value}
    if type(x) is dict:return {'__辞書__':[[enc(k),enc(v)] for k,v in x.items()]}
    if type(x) is tuple:return {'__組__':[enc(v) for v in x]}
    if type(x) is list:return [enc(v) for v in x]
    need(type(x) in (type(None),bool,int,float,str),'unsupported scalar')
    if type(x) is float:need(math.isfinite(x),'nonfinite')
    return x
def dec(x):
    if type(x) is list:return [dec(v) for v in x]
    if type(x) is not dict:
        need(type(x) in (type(None),bool,int,float,str),'JSON scalar')
        if type(x) is float:need(math.isfinite(x),'finite')
        return x
    keys=list(x)
    if keys==['__組__']:
        need(type(x['__組__']) is list,'tuple tag');return tuple(dec(v) for v in x['__組__'])
    if keys==['__辞書__']:
        need(type(x['__辞書__']) is list,'dict tag');d={}
        for p in x['__辞書__']:
            need(type(p) is list and len(p)==2,'dictionary pair')
            k,v=dec(p[0]),dec(p[1]);need(k not in d,'duplicate decoded key');d[k]=v
        return d
    if keys==['__データ型__','値']:
        need(x['__データ型__'] in TYPES and type(x['値']) is dict,'known dataclass')
        need(tuple(x['値'])==TYPES[x['__データ型__']],'all dataclass fields and order')
        return Record(x['__データ型__'],{k:dec(v) for k,v in x['値'].items()})
    if keys==['__列挙__','値']:
        need(x['__列挙__'] in ENUMS and x['値'] in ENUMS[x['__列挙__']],'known enum')
        return EnumValue(x['__列挙__'],x['値'])
    raise ValueError('unknown standard tag')
def rec(x,name):
    need(isinstance(x,Record) and x.name==name,'record '+name);return x.fields
def ev(x):
    need(isinstance(x,EnumValue),'enum required');return x.value
def asdict_tree(x):
    if isinstance(x,Record):return {k:asdict_tree(v) for k,v in x.fields.items()}
    if type(x) is dict:return {asdict_tree(k):asdict_tree(v) for k,v in x.items()}
    if type(x) is tuple:return tuple(asdict_tree(v) for v in x)
    if type(x) is list:return [asdict_tree(v) for v in x]
    return x
def usage(root,caps,total):
    u={k:0 for k in caps}
    if root.exists():
        need(not root.is_symlink(),'scope symlink')
        for p in root.rglob('*'):
            s=p.lstat();need(not stat.S_ISLNK(s.st_mode),'symlink evidence')
            if stat.S_ISDIR(s.st_mode):continue
            rel=p.relative_to(root).parts
            need(len(rel)==2 and rel[0] in caps and stat.S_ISREG(s.st_mode) and s.st_nlink==1,'flat regular classified evidence')
            u[rel[0]]+=s.st_size
    need(all(u[k]<=caps[k] for k in caps) and sum(u.values())<=total,'scope capacity')
    return u
def admit(category=None,n=0):
    if DEADLINE is not None:need(time.monotonic()<DEADLINE,'finite audit deadline')
    u=usage(ROOT,CAPS,TOTAL)
    usage(NATIVE,{'source':327680,'prep_tools':131072,'states':12*M,'journal':4*M,'reports':262144,'failure':2*M},20*M)
    usage(TEACHER,{'source':131072,'prep':262144,'producer':4*M,'reader':4*M,'logs':262144,'failure':2*M},12*M)
    if category is not None:need(type(n) is int and n>=0 and u[category]+n<=CAPS[category],'prospective write')
    s=os.statvfs(BASE);free=s.f_bavail*s.f_frsize
    mem=int(next(t.split()[1] for t in pathlib.Path('/proc/meminfo').read_text().splitlines() if t.startswith('MemAvailable:')))*1024
    need(free>=1024*M+(TOTAL-sum(u.values()))+32*M,'physical floor plus all scopes future')
    need(mem>=2048*M+RAM,'full concurrent RAM floors')
    a={'usage':u,'disk_free':free,'disk_required':1024*M+TOTAL-sum(u.values())+32*M,'MemAvailable':mem,'memory_required':2048*M+RAM}
    ADMISSIONS.append(a);return a
def checked(r,cap):
    need(type(r) is dict and set(r)=={'path','bytes','sha256'},'exact FileRef')
    need(type(r['bytes']) is int and 0<=r['bytes']<=cap,'input cap')
    p=pathlib.Path(r['path']);need(p.is_absolute() and p.resolve()==p and not p.is_symlink(),'canonical input')
    s=p.stat();need(stat.S_ISREG(s.st_mode) and s.st_size==r['bytes'],'input size')
    b=p.read_bytes();need(sha(b)==r['sha256'],'input SHA')
    t=p.stat();need((s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)==(t.st_dev,t.st_ino,t.st_size,t.st_mtime_ns,t.st_ctime_ns),'immutable read')
    READS.append(r);return b
def plain(r,cap=M):return parse(checked(r,cap))
def typed(r,cap):
    raw=checked(r,cap);tree=parse(raw);value=dec(tree)
    need(equal(enc(value),tree),'tag roundtrip type/order')
    need(wire(enc(value))==raw,'compact typed canonical bytes');return value
def standard(r):
    raw=checked(r,M);tree=parse(raw);value=dec(tree)
    need(json.dumps(enc(value),ensure_ascii=False,indent=2).encode()==raw,'standard full byte roundtrip')
    need(type(value) is dict and tuple(value)==('形式版','最小支持数','最大条件数','識別子状態','台帳','状態履歴','原理履歴'),'full standard keys/order')
    for k,v in (('形式版',3),('最小支持数',3),('最大条件数',2)):
        need(type(value[k]) is int and value[k]==v,'standard setting '+k)
    return raw,value
def load_types(ref):
    tree=ast.parse(checked(ref,131072))
    for node in tree.body:
        if not isinstance(node,ast.ClassDef):continue
        if any(isinstance(x,ast.Name) and x.id=='Enum' for x in node.bases):
            vals=[]
            for n in node.body:
                if isinstance(n,ast.Assign) and isinstance(n.value,ast.Constant):vals.append(n.value.value)
            ENUMS[node.name]=vals
        elif any(isinstance(x,ast.Call) and isinstance(x.func,ast.Name) and x.func.id=='dataclass' for x in node.decorator_list):
            TYPES[node.name]=tuple(n.target.id for n in node.body if isinstance(n,ast.AnnAssign))
    need('実行結果' in TYPES and '外部入力' in TYPES and '原理状態' in ENUMS,'fixed type declarations')
def unpack_material(ref):
    need(set(ref)=={'path','bytes','sha256','raw_bytes','raw_sha256'},'packet FileRef')
    blob=checked({k:ref[k] for k in ('path','bytes','sha256')},4*M)
    d=lzma.LZMADecompressor(format=lzma.FORMAT_XZ,memlimit=32*M)
    raw=d.decompress(blob,max_length=16*M+1)
    need(d.eof and not d.unused_data and d.check==lzma.CHECK_CRC64 and len(raw)<=16*M,'packet CRC64/EOF/bound')
    need(len(raw)==ref['raw_bytes'] and sha(raw)==ref['raw_sha256'],'packet raw pins')
    x=dec(parse(raw));need(wire(enc(x))==raw,'whole material type/order');return x
def joint(case):
    t=case['teacher'];q=case['query_input']
    need(type(t) is dict and tuple(t)==FIELDS and all(type(v) is bool for v in t.values()),'three strict measured bools')
    need(type(q) is dict and tuple(q)==FIELDS[:2] and equal(q,{k:t[k] for k in FIELDS[:2]}),'all before inputs')
    pair=[q[k] for k in FIELDS[:2]]
    key=json.dumps(pair,separators=(',',':'),ensure_ascii=False)
    need(equal(parse(key),pair) and all(type(v) is bool for v in parse(key)),'joint reversible strict pair')
    return {KEY:key,FIELDS[2]:t[FIELDS[2]]}
def observations(content):
    # Source-bound 最小吸気系 for this exact two-leaf dictionary only.
    result=[Record('観測事実',{'経路':('@HDS:構造',),'値':'辞書','値型':'構造','推論対象':False}),
            Record('観測事実',{'経路':('@HDS:要素数',),'値':2,'値型':'整数','推論対象':False})]
    for k in sorted(content):
        v=content[k];result.append(Record('観測事実',{'経路':(k,),'値':v,'値型':'真偽' if type(v) is bool else '文字列','推論対象':True}))
    return tuple(result)
def material_closure(c):
    pr=plain(c['producer_receipt'],16384);ar=plain(c['audit'],16384)
    amendment=plain(c['contract'],32768)
    mc=plain(amendment['base_contract'],32768)
    checked(amendment['outer'],131072);checked(amendment['full_diff'],131072)
    need(amendment['schema']==mc['schema']=='goal6-recovered-contract-v1','material contract schemas')
    known={pathlib.Path(x['path']).name:x for x in mc['source_refs']}
    for r in mc['source_refs']+mc['dependency_refs']+mc['authority_refs']:checked(r,131072)
    need(pr['schema']=='goal6-producer-receipt-v1' and pr['status']=='complete' and pr['complete'] is True and pr['errors']==[],'producer complete')
    need(equal(pr['packet'],c['material']) and pr['case_count']==6 and pr['phase_count']==112 and pr['eligible_teacher_count']==6,'material count refs')
    flags={'all_six_cases','all_112_phases','all_12_original_rows','full_type_order','before_only_two_conditions','all_100_targets_per_eligible_case','independent_public_progress','all_unknowns_preserved','new_support_zero'}
    need(ar['schema']=='goal6-reader-receipt-v1' and ar['status']=='PASS' and ar['complete'] is True and ar['errors']==[],'material audit PASS')
    need(set(ar['verified'])==flags and all(v is True for v in ar['verified'].values()),'all material checks')
    need(equal(ar['producer_receipt'],c['producer_receipt']) and equal(ar['material'],c['material']),'material audit joins')
    for mode,r,ref in (('producer',pr,c['producer_receipt']),('reader',ar,c['audit'])):
        need(equal(r['source'],known['goal6_'+mode+'_v1.py']) and equal(r['outer'],amendment['outer']),'material code pins')
        log=plain(r['admission_log'],131072)
        need(log['schema']=='goal6-admission-log-v1' and log['mode']==mode and log['nonce']==r['nonce'] and type(log['count']) is int and log['count']==len(log['records'])==r['admission_log_count'] and log['includes_final_receipt_and_log_admission'] is True,'complete material admission log')
        ack=plain(c[mode+'_ACK'],16384);cl=plain(c[mode+'_closure'],65536);gate=plain(r['gate'],16384)
        need(ack['schema']=='goal6-recovered-root-ack-v1' and ack['mode']==mode and ack['nonce']==r['nonce'] and ack['decision']=='ACK' and equal(ack['receipt'],ref),'material ACK')
        if mode=='producer':need(equal(ack['independent_audit'],c['audit']) and equal(cl['reader_closure'],c['reader_closure']),'reader closure join')
        need(cl['schema']=='goal6-material-closed-tools-v1' and cl['mode']==mode and cl['nonce']==r['nonce'],'closed schema')
        for k,v in (('source',r['source']),('outer',r['outer']),('gate',r['gate']),('receipt',ref),('ACK',c[mode+'_ACK']),('audit',c['audit'])):need(equal(cl[k],v),'closure ref '+k)
        need(type(cl['session_id']) is int and cl['session_id']==c[mode+'_session']==cl['launch']['session_id'],'session closure')
        need(sha(cl['command'].encode())==cl['command_sha256']==c[mode+'_command_sha256'],'command SHA')
        need(cl['actual_exit_observed'] is True and type(cl['actual_tool']['exit_code']) is int and cl['actual_tool']['exit_code']==0,'actual exit')
        need(gate['nonce']==r['nonce'] and gate['mode']==mode and equal(gate['source'],r['source']) and equal(gate['outer'],r['outer']) and equal(gate['contract'],c['contract']),'release refs')
    m=unpack_material(c['material'])
    need(m['schema']=='goal6-measured-material-v1' and m['nonce']==pr['nonce'] and m['complete'] is True and m['errors']==[],'full measured material')
    need(equal(m['selection'],SELECTION) and len(m['cases'])==6 and m['all_phase_count']==112,'all material cases')
    need(type(m['HDS_API']) is int and m['HDS_API']==0 and type(m['new_independent_support']) is int and m['new_independent_support']==0,'measurement support')
    phases=0
    for i,case in enumerate(m['cases']):
        need(type(case['ordinal']) is int and case['ordinal']==i and equal(case['selection'],SELECTION[i]),'material order')
        need(case['boundary']==MBOUNDARY and case['completed'] is True and case['holds']==[] and case['pair_error'] is None,'eligible measured teacher')
        joint(case)
        need(sha(wire(enc((case['before_hypothesis'],case['query_input']))))==case['before_frozen_sha256'],'before frozen pin')
        phases+=len(case['before_phases'])+len(case['after_phases'])
    need(phases==112,'all phases retained')
    return m
def prefix(before,after,label):
    need(type(before) is type(after) and type(before) in (tuple,list),'sequence '+label)
    need(len(after)>=len(before) and equal(before,after[:len(before)]),'append-only '+label)
def current(state):
    history=state['原理履歴'];current_map=state['状態履歴'][-1];allids={};active=[];isolated=[]
    for lineage,versions in history.items():
        need(type(versions) is list and versions,'full lineage list')
        for version in versions:
            p=rec(version,'原理記録');need(p['系譜識別子']==lineage,'lineage binding')
            need(p['原理識別子'] not in allids,'unique principle ID');allids[p['原理識別子']]=version
    for lineage,pid in current_map.items():
        need(pid in allids,'current ID exists');v=allids[pid];p=v.fields
        need(p['系譜識別子']==lineage,'current lineage')
        if ev(p['状態'])=='適用範囲付き暫定原理' and ev(p['採用状態'])=='有効':active.append(v)
        if ev(p['採用状態'])=='隔離' or ev(p['状態'])=='係争中':isolated.append(v)
    return tuple(active),tuple(isolated),allids
def exhaust(raw):
    r=rec(raw,'実行結果');learn=rec(r['学習過程'],'学習過程記録')
    state='断定保留' if (r['競合群'] or r['係争中原理群'] or r['追加観測要求群'] or r['識別不能群'] or ev(learn['学習成立状態']) in ('未確認','不成立確認')) else '出力'
    content={'学習成立状態':ev(learn['学習成立状態']),'現在状態版':r['現在状態版']}
    for k in ('予測群','競合群','追加観測要求群','識別不能群'):content[k]=[asdict_tree(x) for x in r[k]]
    content['有効原理群']=[]
    for x in r['有効原理群']:
        p=rec(x,'原理記録')
        content['有効原理群'].append({'原理識別子':p['原理識別子'],'版':p['版'],'状態':ev(p['状態']),'採用状態':ev(p['採用状態']),'関係型':p['関係型'],'条件経路群':p['条件経路群'],'結果経路':p['結果経路'],'適用範囲':dict(p['適用範囲']),'親原理参照':p['親原理参照'],'改訂理由':p['改訂理由'],'除外反証参照群':list(p['除外反証参照群'])})
    content['係争中原理群']=[]
    for x in r['係争中原理群']:
        p=rec(x,'原理記録')
        content['係争中原理群'].append({'原理識別子':p['原理識別子'],'版':p['版'],'状態':ev(p['状態']),'採用状態':ev(p['採用状態']),'関係型':p['関係型'],'条件経路群':p['条件経路群'],'結果経路':p['結果経路'],'支持参照群':list(p['根拠参照群']),'反証参照群':list(p['反証参照群']),'改訂理由':p['改訂理由']})
    content['断定保留理由群']=list(r['断定保留理由群'])
    return Record('外部出力',{'状態':state,'内容':content,'追跡情報':dict(r['追跡情報'])})
def verify_evidence_events(al,ids,exps):
    # The only three append shapes in fixed 実行系.py166,192,401.
    exids=tuple(rec(x,'経験記録')['経験識別子'] for x in exps)
    candidates={}
    candidate_keys=('候補参照','経験参照群','懐疑参照群','関係型','条件経路群','結果経路','生成条件','時点')
    skepticism={rec(x,'懐疑記録')['懐疑識別子']:x for x in al.get('懐疑台帳',())}
    for item in al.get('推論記録台帳',()):
        need(type(item) is dict and tuple(item)==candidate_keys,'candidate record full schema/order')
        cid=item['候補参照'];need(type(cid) is str and cid not in candidates,'unique candidate ID')
        need(type(item['経験参照群']) is tuple and all(x in exids for x in item['経験参照群']),'candidate experience refs')
        need(type(item['懐疑参照群']) is tuple and all(x in skepticism for x in item['懐疑参照群']),'candidate skepticism refs')
        candidates[cid]=item
    evidence_seen=set();joins=[]
    for event in al.get('証拠台帳',()):
        need(type(event) is dict,'evidence dictionary')
        keys=tuple(event)
        if keys==('候補参照','判定','理由','支持参照群','反証参照群','時点'):
            cid=event['候補参照'];need(cid in candidates and cid not in evidence_seen,'candidate evidence unique binding')
            evidence_seen.add(cid);candidate=candidates[cid]
            need(event['時点']==candidate['時点'],'candidate verification time')
            need(event['判定'] in ('適合','断定保留','失敗') and type(event['理由']) is str,'candidate verification outcome')
            judgments=[x for x in al.get('判断台帳',()) if type(x) is dict and tuple(x)==('候補参照','採否','判定','時点') and x['候補参照']==cid]
            expected={'候補参照':cid,'採否':'試行採用' if event['判定']=='適合' else '保留または隔離','判定':event['判定'],'時点':event['時点']}
            need(len(judgments)==1 and equal(judgments[0],expected),'full candidate decision join')
            join={'kind':'candidate_verification','evidence':event,'candidate':candidate,'decision':judgments[0]}
        elif keys==('原理参照','状態','支持参照群','反証参照群','注意','時点'):
            pid=event['原理参照'];need(pid in ids,'principle evidence binding')
            p=ids[pid].fields
            need(ev(p['採用状態'])=='隔離' or ev(p['状態'])=='係争中','evidence references isolated version')
            if event['状態']=='係争中':
                need(event['注意']=='反例を自動的にノイズ扱いしない' and event['時点']==p['時点'],'initial dispute provenance')
                need(equal(event['支持参照群'],p['根拠参照群']) and equal(event['反証参照群'],p['反証参照群']),'initial dispute fixed evidence')
                kind='initial_dispute'
            elif event['状態']=='係争中・証拠更新':
                need(event['注意']=='証拠更新のみ。原理版・現行状態は変更しない','later evidence meaning')
                need(not(equal(event['支持参照群'],p['根拠参照群']) and equal(event['反証参照群'],p['反証参照群'])),'later evidence actual increment')
                kind='isolated_evidence_update'
            else:raise AssertionError('unknown principle evidence status')
            join={'kind':kind,'evidence':event,'fixed_principle_version':ids[pid]}
        else:raise AssertionError('unknown evidence schema/order')
        for k in ('支持参照群','反証参照群'):
            refs=event[k]
            need(type(refs) is tuple and len(set(refs))==len(refs) and all(x in exids for x in refs),'full evidence experience refs')
            need(tuple(x for x in exids if x in refs)==refs,'evidence experience order')
        need(not set(event['支持参照群']).intersection(event['反証参照群']),'disjoint support/refutation')
        need(type(event['時点']) is str,'evidence time')
        joins.append(join)
    need(evidence_seen==set(candidates),'all candidates have retained verification events')
    return joins

def verify_step(i,b,a,intent,reply,case,material_ref):
    content=joint(case)
    expected_input=Record('外部入力',{'内容':content,'対象系境界':BOUNDARY,'主体':None,'対象':None,'目的':None,'文脈':{}})
    expected={'index':i,'source_material':material_ref,'selection':case['selection'],'whole_measured_case':case,'material_boundary':MBOUNDARY,'input':expected_input}
    need(equal(intent,expected),'whole intent including original case')
    need(type(reply) is dict and tuple(reply)==('raw_execution_result','external_reply'),'whole reply schema')
    raw=reply['raw_execution_result'];r=rec(raw,'実行結果');external=reply['external_reply']
    need(equal(exhaust(raw),external),'all external output fields from raw result')
    bc=b['識別子状態'];ac=a['識別子状態']
    need(bc.get('経験',0)==i and ac.get('経験',0)==i+1 and ac.get('学習',0)==i+1,'one experience/learning')
    need(bc.get('照会',0)==ac.get('照会',0)==0 and bc.get('学習判定',0)==ac.get('学習判定',0)==0,'Query0 counters')
    need(all(type(v) is int and v>=0 for v in ac.values()),'strict counters')
    need(all(k in ac and ac[k]>=v for k,v in bc.items()),'monotonic counters')
    bl=b['台帳'];al=a['台帳']
    need(list(al)[:len(bl)]==list(bl),'ledger family order')
    for k,v in bl.items():need(k in al,'ledger missing');prefix(v,al[k],k)
    prefix(b['状態履歴'],a['状態履歴'],'state history')
    need(list(a['原理履歴'])[:len(b['原理履歴'])]==list(b['原理履歴']),'lineage order')
    for k,v in b['原理履歴'].items():prefix(v,a['原理履歴'][k],'principle versions')
    exps=al.get('観測台帳',());need(type(exps) is tuple and len(exps)==i+1,'all experience count')
    e=rec(exps[-1],'経験記録')
    expected_e={'経験識別子':'経験-'+str(i+1).zfill(6),'対象系境界':BOUNDARY,'原入力':content,'観測群':observations(content),'主体':None,'対象':None,'目的':None,'時点':e['時点']}
    need(type(e['時点']) is str and equal(e,expected_e),'new full experience/observation')
    learn=rec(r['学習過程'],'学習過程記録')
    need(equal(al['学習過程台帳'][-1],r['学習過程']) and len(al['学習過程台帳'])==i+1,'learning record exact')
    need(learn['経験参照']==e['経験識別子'] and learn['学習識別子']=='学習-'+str(i+1).zfill(6),'learning refs')
    need(learn['学習前状態版']==len(b['状態履歴'])-1 and learn['学習後状態版']==len(a['状態履歴'])-1==r['現在状態版'],'state version')
    need(equal(learn['学習前状態スナップショット'],b['状態履歴'][-1]),'previous map')
    need(equal(learn['保持記憶参照群'],tuple(rec(x,'経験記録')['経験識別子'] for x in exps)),'all memory refs')
    need(learn['対象系境界']==BOUNDARY and learn['主体参照'] is None and learn['時点']==e['時点'],'learning boundary/time')
    expected_track={'経験参照':e['経験識別子'],'対象系境界':BOUNDARY,'台帳件数':{k:len(v) for k,v in al.items()}}
    need(equal(r['追跡情報'],expected_track),'full ledger count trace')
    active,isolated,ids=current(a)
    need(equal(r['有効原理群'],active) and equal(r['係争中原理群'],isolated),'current selection and isolation')
    exids={rec(x,'経験記録')['経験識別子'] for x in exps}
    for v in ids.values():
        p=v.fields
        need(p['対象系境界']==BOUNDARY,'principle boundary')
        for k in ('根拠参照群','反証参照群','除外反証参照群'):need(all(z in exids for z in p[k]),'all principle evidence refs')
    evidence_joins=verify_evidence_events(al,ids,exps)
    for k in ('予測群','競合群','追加観測要求群','識別不能群'):
        for v in r[k]:
            p=v.fields
            refs=(p['原理参照'],) if '原理参照' in p else p.get('原理参照群',())
            need(all(z in ids for z in refs),'output principle refs')
    return {'index':i,'native_content':content,'raw_reply':reply,'counters_before':bc,'counters_after':ac,
            'all_ledger_deltas':{k:v[len(bl.get(k,())):] for k,v in al.items()},
            'new_state_history':a['状態履歴'][len(b['状態履歴']):],
            'all_history_deltas':{k:v[len(b['原理履歴'].get(k,())):] for k,v in a['原理履歴'].items()},
            'current_map':a['状態履歴'][-1],'active':active,'isolated':isolated,
            'latest_evidence_ledger':al.get('証拠台帳',()),'all_evidence_joins':evidence_joins,'HOLD':rec(external,'外部出力')['状態']=='断定保留'}
def write(category,name,data,preadmitted=False):
    if not preadmitted:admit(category,len(data))
    folder=ROOT/category;folder.mkdir(exist_ok=True)
    p=folder/name;need(p.name==name,'basename')
    with p.open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
    for d in (folder,ROOT):
        fd=os.open(d,os.O_RDONLY|os.O_DIRECTORY)
        try:os.fsync(fd)
        finally:os.close(fd)
    need(p.read_bytes()==data,'saved full bytes')
    return {'path':str(p),'bytes':len(data),'sha256':sha(data)}
def run(gate,source_ref):
    global DEADLINE
    admit();contract=plain(gate['contract'],131072)
    need(contract['schema']=='goal6-native-independent-contract-v1','audit contract')
    need(equal(gate['source'],contract['source']) and equal(gate['outer'],contract['outer']),'audit source/outer contract')
    checked(gate['outer'],131072)
    for pin in contract['pins']:checked(pin,131072)
    load_types(contract['type_source'])
    r=plain(gate['receipt'],65536);ng=plain(gate['native_gate'],65536)
    need(r['schema']=='goal6-native-completion-v1' and r['status']=='complete' and r['errors']==[],'native complete')
    need(r['nonce']==gate['nonce']==ng['nonce'],'nonce binding')
    for k in ('Teach_attempted','Teach_returned','completed'):need(type(r[k]) is int and r[k]==6,'six native calls')
    need(type(r['Query_attempted']) is int and r['Query_attempted']==0 and r['new_independent_support']==0,'no query or new support')
    need(equal(r['source'],contract['native_source']) and equal(r['source'],ng['source']) and equal(r['guard'],ng['guard']),'native source guard')
    need(equal(ng['audit_source'],source_ref) and ng['operation']=='fresh_Teach6_Query0' and ng['support']==3 and ng['conditions']==2 and ng['boundary']==BOUNDARY,'native release')
    need(equal(ng['material_closure'],r['material_closure']) and equal(ng['selection'],[list(x) for x in SELECTION]),'release material selection')
    for k in ('source','guard','outer','contract'):checked(ng[k],131072)
    pinmap={p['path']:p for p in contract['pins']}
    for k in ('source','guard','outer','contract'):need(equal(ng[k],pinmap[ng[k]['path']]),'fixed native reference '+k)
    need(equal(r['material_closure']['contract'],contract['material_contract']),'fixed material amendment')
    events=r['profile_events'];restores=r['profile_restorations']
    need(type(events) is list and type(restores) is list and len(events)==len(restores)==6,'all six observer events/restorations')
    exhaust_pin=next(p for p in contract['pins'] if p['path'].endswith('/排気系.py'))
    tree=ast.parse(checked(exhaust_pin,131072))
    klass=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='最小排気系')
    method=next(n for n in klass.body if isinstance(n,ast.FunctionDef) and n.name=='排出する')
    for i,(event,restore) in enumerate(zip(events,restores)):
        need(equal(event,{'event':'call','filename':exhaust_pin['path'],'firstlineno':method.lineno,'function':'排出する','exact_code_and_receiver':True,'ordinal':i}),'exact original exhaust event')
        need(equal(restore,{'prior_was_none':True,'own_callback_at_exit':True,'restored_previous':True}),'profile restored')
    m=material_closure(r['material_closure'])
    need(len(r['snapshots'])==6 and len(r['journals'])==12,'complete sequence')
    refs=[x for s in r['snapshots'] for x in (s['before'],s['after'])]+r['journals']
    need(len({x['path'] for x in refs})==24,'unique state and journal files')
    detail={'schema':'goal6-native-independent-detail-v1','receipt':gate['receipt'],'native_gate':gate['native_gate'],'steps':[],'standard_refs':r['snapshots'],'journal_refs':r['journals'],'material_closure':r['material_closure'],'profile_events':events,'profile_restorations':restores}
    previous=None
    for i,s in enumerate(r['snapshots']):
        admit();need(type(s['index']) is int and s['index']==i and tuple(s)==('index','before','after'),'snapshot order')
        br,b=standard(s['before']);ar,a=standard(s['after'])
        if previous is not None:need(br==previous,'adjacent entire standard bytes')
        else:need(equal(b,{'形式版':3,'最小支持数':3,'最大条件数':2,'識別子状態':{},'台帳':{},'状態履歴':({},),'原理履歴':{}}),'full fresh initial')
        intent=typed(r['journals'][2*i],524288);reply=typed(r['journals'][2*i+1],262144)
        detail['steps'].append(verify_step(i,b,a,intent,reply,m['cases'][i],r['material_closure']['material']))
        previous=ar
    detail['final_full_standard']=a
    detail['all_checked_refs']=READS.copy()
    signal.alarm(120);DEADLINE=time.monotonic()+120
    raw=wire(enc(detail));need(len(raw)<=32*M,'full detail raw32MiB; no truncation')
    blob=lzma.compress(raw,format=lzma.FORMAT_XZ,check=lzma.CHECK_CRC64,preset=0);need(len(blob)<=4*M,'full detail XZ4MiB')
    d=lzma.LZMADecompressor(format=lzma.FORMAT_XZ,memlimit=32*M);back=d.decompress(blob,max_length=32*M+1)
    need(d.eof and not d.unused_data and d.check==lzma.CHECK_CRC64 and back==raw,'full detail CRC64/EOF/bytes')
    ref=write('detail',gate['nonce']+'.typed.json.xz',blob);ref.update(raw_bytes=len(raw),raw_sha256=sha(raw))
    summary={'schema':'goal6-native-independent-completion-v1','nonce':gate['nonce'],'status':'PASS','errors':[],'source':source_ref,'receipt':gate['receipt'],'gate':gate['_self_ref'],'detail':ref,
      'verified':{'all_six_original_teachers':True,'all_before_after_standard_states':True,'all_returns_ledgers_histories':True},
      'counts':{'teachers':6,'queries':0,'states':12,'journals':12,'experiences':len(a['台帳']['観測台帳']),'HOLD':sum(s['HOLD'] for s in detail['steps']),'active_principles':len(current(a)[0]),'isolated_principles':len(current(a)[1])},
      'limitations':['joint condition is fixed reversible encoding, not learned AND','no queryability or game success asserted','principle version evidence and later evidence ledger separately preserved','all raw original files retained via exact refs; no API/restore/import'],
      'admissions':ADMISSIONS}
    reserved=len(wire(summary))+2048
    need(reserved<=65536,'summary plus final admission bound')
    admit('reports',reserved)
    data=wire(summary);need(len(data)<=reserved,'actual summary including final admission fits reserved bytes')
    return write('reports',gate['nonce']+'.json',data,preadmitted=True)
def main(path,digest):
    global DEADLINE
    resource.setrlimit(resource.RLIMIT_AS,(512*M,512*M))
    signal.signal(signal.SIGALRM,lambda s,f:(_ for _ in ()).throw(TimeoutError('fixed audit stage deadline')))
    signal.alarm(600);DEADLINE=time.monotonic()+600
    gate=None
    try:
        admit();p=pathlib.Path(path);b=p.read_bytes();need(len(b)<=65536 and sha(b)==digest,'gate exact SHA')
        gate=parse(b);need(gate['schema']=='goal6-native-independent-release-v1' and gate['enabled'] is True,'root release')
        need(gate['limits']=={'AS':512*M,'compute_seconds':600,'save_seconds':120},'fixed limits')
        sr=gate['source'];checked(sr,131072);need(pathlib.Path(sr['path'])==pathlib.Path(__file__),'audit source identity')
        gate['_self_ref']={'path':str(p),'bytes':len(b),'sha256':sha(b)}
        result=run(gate,sr);signal.alarm(0);print(json.dumps({'status':'PASS','report':result},ensure_ascii=False),flush=True)
        return 0
    except BaseException as exc:
        trace=traceback.format_exc();print(trace,flush=True)
        signal.alarm(120);DEADLINE=time.monotonic()+120
        try:
            value={'schema':'goal6-native-independent-failure-v1','status':'FAIL','gate':gate,'error':{'type':type(exc).__name__,'repr':repr(exc),'traceback':trace},'admissions':ADMISSIONS,'read_refs':READS}
            data=wire(value);need(len(data)<=M,'failure1MiB')
            name=(gate['nonce'] if gate else 'preflight')+'_v3.json'
            ref=write('failure',name,data);print(json.dumps({'status':'FAIL','failure':ref},ensure_ascii=False),flush=True)
        except BaseException:print(traceback.format_exc(),flush=True)
        finally:signal.alarm(0)
        return 1
if __name__=='__main__':sys.exit(main(sys.argv[1],sys.argv[2]))
