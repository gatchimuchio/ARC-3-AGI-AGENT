"""Pure fixture retained entry; candidate measurement entry is never called."""
import resource
resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912))
import pathlib,hashlib,types,json,signal,time,traceback,sys
sys.dont_write_bytecode=True
ROOT=pathlib.Path('/workspace/scratch/a94ff513b3af/arc-goal-teacher-recovered-20261013')
FIXTURE_SHA='53d50dfadae6590e8baeaa5d2d0374a119518703e82a3ea16163afec4b09a76a'
STATE={'module':None,'exception':None,'traceback':None,'secondary':[],'result':None,'receipt':None}

def need(v,msg):
    if not v:raise AssertionError(msg)

def timeout(*_):raise TimeoutError('goal6 pure fixture finite deadline')

def main(gate_path,gate_sha):
    signal.signal(signal.SIGALRM,timeout);signal.alarm(120)
    try:
        p=pathlib.Path(gate_path)
        need(p.parent==ROOT/'logs' and p.stat().st_size<=16384 and not p.is_symlink(),'fixture gate')
        raw=p.read_bytes();need(hashlib.sha256(raw).hexdigest()==gate_sha,'gate SHA')
        gate=json.loads(raw)
        need(gate['schema']=='goal6-pure-fixture-release-v1' and gate['enabled'] is True and
             gate['AS']==536870912 and gate['compute_seconds']==120 and gate['save_seconds']==120,'limits')
        nonce=gate['nonce'];need(type(nonce) is str and len(nonce)==32 and all(x in '0123456789abcdef' for x in nonce),'nonce')
        fp=ROOT/'source/goal6_pure_fixture_v1.py';source=fp.read_bytes()
        need(hashlib.sha256(source).hexdigest()==FIXTURE_SHA and gate['fixture_sha256']==FIXTURE_SHA,'fixture pin')
        op=pathlib.Path(__file__);need(hashlib.sha256(op.read_bytes()).hexdigest()==gate['outer_sha256'],'outer pin')
        m=types.ModuleType('owned_goal6_fixture');m.__file__=str(fp);STATE['module']=m
        exec(compile(source,str(fp),'exec'),m.__dict__)
        result=m.run();STATE['result']=result
        signal.alarm(120);C=m.C;C.admit()
        need(result['complete'] is True and result['errors']==[],'fixture complete')
        blob,rawref=C.pack(result,STATE);need(len(blob)<=131072,'fixture XZ128KiB')
        ref=C.save_bytes('goal6_pure_fixture_'+nonce+'.json.xz',blob,'prep');ref.update(rawref)
        need(C.equal(C.unpack(C.checked(ref,131072),STATE),result),'disk typed fixture')
        receipt={'schema':'goal6-pure-fixture-receipt-v1','nonce':nonce,'complete':True,'errors':[],
          'case_count':result['case_count'],'packet':ref,'source_sha256':FIXTURE_SHA,
          'gate':C.file_ref(p,raw),'producer_normal_closure':False,'HDS_API':0,'raw_measurement':0}
        rb=C.wire(receipt);need(len(rb)<=8192,'fixture receipt8KiB')
        rr=C.save_bytes('goal6_pure_fixture_'+nonce+'.receipt.json',rb,'prep')
        STATE['receipt']=rr;signal.alarm(0)
        print(json.dumps({'stage':'await_root_ack','receipt':rr,'packet':ref}),flush=True)
        ap=ROOT/'logs'/('root_ack_goal6_fixture_'+nonce+'.json')
        while True:
            if ap.exists():
                try:
                    need(ap.stat().st_size<=8192 and not ap.is_symlink(),'ACK cap')
                    ack=C.parse(ap.read_bytes())
                    need(ack['schema']=='goal6-pure-fixture-root-ack-v1' and ack['nonce']==nonce and
                         ack['decision']=='ACK' and C.equal(ack['receipt'],rr),'root ACK')
                    STATE['ACK']=ack
                    return
                except BaseException as exc:STATE['secondary'].append(exc)
            time.sleep(5)
    except BaseException as exc:
        signal.alarm(0);STATE['exception']=exc
        STATE['traceback']=''.join(traceback.format_exception(type(exc),exc,exc.__traceback__))
        print(json.dumps({'stage':'fixture_failed_retained','type':type(exc).__name__,'repr':repr(exc),
                          'traceback':STATE['traceback']}),flush=True)
        while True:time.sleep(60)

if __name__=='__main__':main(*sys.argv[1:])
