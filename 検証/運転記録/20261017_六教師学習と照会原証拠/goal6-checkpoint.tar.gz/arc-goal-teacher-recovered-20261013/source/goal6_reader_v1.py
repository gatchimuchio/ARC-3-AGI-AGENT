"""Independent full original-row/phase audit; producer semantic functions not used."""
import hashlib, pathlib, types, traceback
COMMON_SHA = 'c4f693f1a9106b43bd7a2fffb8775042de6925854807fe3ba784641b2af58697'
HERE = pathlib.Path(__file__).resolve().parent
OWNER={'started':False,'complete':False,'rows':{},'source_closures':[],
       'cases':[],'exceptions':[],'modules':[],'errors':[],'pending':None,'trace_pairs':[]}
C=None

def load():
    global C
    path=HERE/'goal6_common_v1.py';raw=path.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=COMMON_SHA:raise AssertionError('common pin')
    C=types.ModuleType('independent_goal6_transport');C.__file__=str(path)
    OWNER['modules'].append(C);exec(compile(raw,str(path),'exec'),C.__dict__)
    C.admit()
    pure,refs=C.load_pure()
    OWNER['pure']=pure;OWNER['dependency_refs']=refs
    return pure

def compare_error(saved,independent,label):
    C.need(type(saved) is dict and list(saved)==['type','repr','traceback'],'error schema')
    C.need(saved['type']==independent['type'] and saved['repr']==independent['repr'],'exception signature')
    C.need(type(saved['traceback']) is str and saved['traceback'].startswith('Traceback (most recent call last):'),'full saved traceback text')
    OWNER['trace_pairs'].append({'label':label,'saved':saved,'independent':independent})
    return saved

def pair_check(before,after):
    for row in (before,after):
        for key in ('guid','game_id'):
            if type(row.get(key)) is not str or not row[key]:
                raise ValueError('strict nonempty identity string: '+key)
    action=after['action_input']
    if type(action) is not dict or type(action.get('id')) is not int or action['id']!=5:
        raise ValueError('whole-scope public wide-paint Action5 required')
    for row in (before,after):
        if type(row.get('full_reset')) is not bool or row['full_reset']:
            raise ValueError('non-reset pair required')
    if any(before[k]!=after[k] for k in ('guid','game_id')):
        raise ValueError('same public identity required')

def phases(rawrow,saved,pure,action,label):
    C.need(len(saved)==len(rawrow['data']['frame']),'full phase count')
    output=[]
    for index,frame in enumerate(rawrow['data']['frame']):
        C.admit()
        item={'ordinal':index,'frame_sha256':C.sha(C.wire(frame)),
              'status':'pending','observation':None,'role':None,'error':None}
        output.append(item)
        OWNER['pending']={'label':label,'index':index,'rawrow':rawrow,'completed':output}
        try:
            item['observation']=pure['read'](frame)
            item['role']=pure['classify'](item['observation'],action)
            item['status']='measured'
        except (ValueError,TypeError,KeyError,IndexError) as exc:
            OWNER['exceptions'].append(exc);item['status']='unknown'
            item['error']=compare_error(saved[index]['error'],C.error(exc),(label,index))
        C.need(C.equal(item,saved[index]),'all phase observation/role/order/unknown fields')
    return output

def hypothesis(ob,pure,saved):
    C.need(type(ob['大きさ']) is int and ob['大きさ']==10,'100 target grammar')
    goals=ob['参照'];current=ob['対象']
    C.need(type(goals) is list and type(current) is list and len(goals)==len(current)==10 and
           all(type(row) is list and len(row)==10 for m in (goals,current) for row in m),'100 matrices')
    direction=ob['方向']
    C.need(type(direction) is list and len(direction)==2 and
           all(type(v) is int and v in (-1,0,1) for v in direction) and direction!=[0,0],
           'exact nonzero public unit direction')
    tool=ob['器具色'];targets=[];repair=[];preserve=[]
    for ordinal in range(100):
        x=ordinal%10;y=ordinal//10;goal=goals[y][x];before=current[y][x]
        covered=None;err=None
        try:covered=pure['membership'](direction,x,y,10,'広域塗布')
        except (ValueError,TypeError,KeyError,IndexError) as exc:
            OWNER['exceptions'].append(exc)
            err=compare_error(saved['targets'][ordinal]['geometry_error'],C.error(exc),('geometry',ordinal))
        strict=type(covered) is bool and all(type(v) is int and 0<=v<=15 for v in (goal,before,tool))
        was=(before==goal) if type(before) is int and type(goal) is int else None
        predicted=(tool if covered else before) if strict else None
        fit=(predicted==goal) if strict else None
        targets.append({'target':[x,y],'goal':goal,'before_color':before,'tool_color':tool,
          'geometry_candidate':covered,'predicted_color':predicted,'satisfied_before':was,
          'predicted_goal_match':fit,'geometry_error':err})
        # Independent S/M/C aggregation, rather than producer's predicted-fit grouping.
        if was is False:repair.append((covered and tool==goal) if strict else None)
        elif was is True:preserve.append((not covered or tool==goal) if strict else None)
        else:repair.append(None);preserve.append(None)
    def total(values):
        if any(type(v) is not bool for v in values):return None
        return not any(v is False for v in values)
    return {'public_reference':goals,'before_target':current,'tool_color':tool,
      'direction':direction,'reference_rectangle':ob['参照矩形'],'target_rectangle':ob['対象矩形'],
      'targets':targets,'deficit_count':len(repair),'satisfied_count':len(preserve),
      'all_repair':total(repair),'all_preserve':total(preserve),
      'empty_group_semantics':'empty universal is True; counts retained',
      'fixed_prior_hypothesis':True,'operation_permission':None}

def verify_case(index,rows,pure,saved):
    si,b,a=C.SELECTION[index];before=rows[(si,b)];after=rows[(si,a)]
    bd,ad=before['data'],after['data'];holds=[];pair_error=None
    try:pair_check(bd,ad)
    except (ValueError,TypeError,KeyError,IndexError) as exc:
        OWNER['exceptions'].append(exc)
        pair_error=compare_error(saved['pair_error'],C.error(exc),('pair',index))
        holds.append('invalid public pair')
    bp=phases(before,saved['before_phases'],pure,ad.get('action_input'),('before',index))
    last=bp[-1];hyp=None;query=None
    if last['status']=='measured' and last['role']=={'役割':'広域塗布','番号':5}:
        try:hyp=hypothesis(last['observation'],pure,saved['before_hypothesis'])
        except (ValueError,TypeError,KeyError,IndexError,AssertionError) as exc:
            OWNER['exceptions'].append(exc)
            matching=[x for x in saved['holds'] if type(x) is dict and 'before_hypothesis_error' in x]
            C.need(len(matching)==1,'one hypothesis error')
            held=compare_error(matching[0]['before_hypothesis_error'],C.error(exc),('hypothesis',index))
            holds.append({'before_hypothesis_error':held})
    else:holds.append('last before binding or wide-paint role unknown')
    if hyp is not None and all(type(hyp[k]) is bool for k in ('all_repair','all_preserve')):
        query={C.INPUT_KEYS[0]:hyp['all_repair'],C.INPUT_KEYS[1]:hyp['all_preserve']}
    else:holds.append('before hypothesis undefined')
    # Comparison happens before after phases are decoded by perception.
    C.need(C.equal(hyp,saved['before_hypothesis']) and C.equal(query,saved['query_input']),'before-only reconstruction')
    frozen=C.sha(C.wire(C.ENC((hyp,query))))
    ap=phases(after,saved['after_phases'],pure,ad.get('action_input'),('after',index))
    bs,as_=bd.get('score'),ad.get('score')
    progress=(as_>bs) if type(bs) is int and type(as_) is int else None
    if progress is None:holds.append('public progress unknown')
    public={'before_score':bs,'after_score':as_,'increased':progress,
      'before_state':bd.get('state'),'after_state':ad.get('state'),
      'before_win_score':bd.get('win_score'),'after_win_score':ad.get('win_score'),
      'definition':'strict public score endpoint increase; no hidden state inference'}
    bindings=[];origin=last['observation'] if last['status']=='measured' else None
    for p in ap:
        same=None
        if origin is not None and p['status']=='measured':
            same=all(C.equal(origin[k],p['observation'][k]) for k in ('参照','参照矩形','対象矩形'))
        bindings.append({'ordinal':p['ordinal'],'status':p['status'],
          'same_reference_and_rectangles':same,'new_problem_confirmed_by_geometry':False,
          'continuous_preservation_confirmed':False})
    teacher=None
    if not holds and query is not None and type(progress) is bool:
        teacher=dict(query);teacher[C.RESULT_KEY]=progress
    expected={'ordinal':index,'selection':C.SELECTION[index],
      'before_row_ref':before['ref'],'after_row_ref':after['ref'],
      'before_metadata':{k:v for k,v in bd.items() if k!='frame'},
      'after_metadata':{k:v for k,v in ad.items() if k!='frame'},
      'original_action':ad.get('action_input'),'pair_error':pair_error,
      'before_phases':bp,'before_hypothesis':hyp,'query_input':query,
      'before_frozen_sha256':frozen,'after_phases':ap,'public_progress':public,
      'after_bindings':bindings,'holds':holds,'teacher':teacher,'boundary':C.BOUNDARY,
      'completed':True,'new_independent_support':0}
    C.need(C.equal(expected,saved),'entire case type/order/value equality')
    OWNER['cases'].append(expected);OWNER['pending']=None

def run(gate):
    pure=load();OWNER['started']=True
    receipt_raw=C.checked(gate['producer_receipt'],16384);receipt=C.parse(receipt_raw)
    C.need(receipt['schema']=='goal6-producer-receipt-v1' and receipt['complete'] is True and
           receipt['nonce']==gate['producer_nonce'],'successful producer receipt')
    blob=C.checked(receipt['packet'],4194304);packet=C.unpack(blob,OWNER)
    C.need(C.sha(OWNER['readback_raw'])==receipt['packet']['raw_sha256'] and
           len(OWNER['readback_raw'])==receipt['packet']['raw_bytes'],'full raw checksum')
    C.need(list(packet)==['schema','nonce','complete','selection','rows','source_closures',
      'dependencies','cases','errors','all_phase_count','new_independent_support','HDS_API',
      'fixed_prior_not_learned_mask','heap_alias_claim'],'full packet schema')
    C.need(packet['schema']=='goal6-measured-material-v1' and packet['nonce']==gate['producer_nonce']
      and packet['complete'] is True and packet['errors']==[],'complete packet')
    C.need(C.equal(packet['selection'],C.SELECTION) and len(packet['cases'])==6,'all6 selection order')
    C.need(C.equal(packet['dependencies'],OWNER['dependency_refs']),'all fixed dependency pins')
    rows=C.raw_rows(OWNER)
    C.need(C.equal(rows,packet['rows']),'full original raw UTF8/parsed row/metadata/type/order')
    for i in range(6):
        C.need((len(packet['cases'][i]['before_phases']),len(packet['cases'][i]['after_phases']))==C.PHASE_COUNTS[i],'all indexed phases')
        verify_case(i,rows,pure,packet['cases'][i])
    C.close_sources(OWNER)
    C.need(C.equal(OWNER['source_closures'],packet['source_closures']),'full source closure')
    C.need(type(packet['all_phase_count']) is int and packet['all_phase_count']==112 and
      type(packet['new_independent_support']) is int and packet['new_independent_support']==0 and
      type(packet['HDS_API']) is int and packet['HDS_API']==0 and
      packet['fixed_prior_not_learned_mask'] is True and packet['heap_alias_claim'] is False,'all fixed scope fields')
    return {'schema':'goal6-independent-detail-v1','nonce':gate['nonce'],
      'producer_nonce':gate['producer_nonce'],'status':'PASS','producer_receipt':gate['producer_receipt'],
      'material':receipt['packet'],'cases':OWNER['cases'],'source_closures':OWNER['source_closures'],
      'trace_pairs':OWNER['trace_pairs'],'errors':[],
      'verified':{'all_six_cases':True,'all_112_phases':True,'all_12_original_rows':True,
        'full_type_order':True,'before_only_two_conditions':True,'all_100_targets_per_eligible_case':True,
        'independent_public_progress':True,'all_unknowns_preserved':True,'new_support_zero':True},
      'HDS_API':0,'new_independent_support':0}
