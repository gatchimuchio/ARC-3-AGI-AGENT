"""Goal6 direct public-frame measurement; no learning or action dispatch."""
import hashlib, pathlib, types, json, signal, time, traceback, sys
COMMON_SHA = 'c4f693f1a9106b43bd7a2fffb8775042de6925854807fe3ba784641b2af58697'
HERE = pathlib.Path(__file__).resolve().parent
OWNER = {'started':False,'complete':False,'cases':[],'rows':{},'source_closures':[],
         'exceptions':[],'modules':[],'pending':None,'errors':[],'result_ref':None}
C = None

def load():
    global C
    p=HERE/'goal6_common_v1.py';raw=p.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=COMMON_SHA:raise AssertionError('common pin')
    C=types.ModuleType('owned_goal6_common');C.__file__=str(p)
    OWNER['modules'].append(C)
    exec(compile(raw,str(p),'exec'),C.__dict__)
    C.admit()
    pure,refs=C.load_pure()
    OWNER['pure']=pure;OWNER['dependency_refs']=refs
    return pure

def strict_pair(before,after):
    for row in (before,after):
        for key in ('guid','game_id'):
            if type(row.get(key)) is not str or not row[key]:
                raise ValueError('strict nonempty identity string: '+key)
    action=after['action_input']
    if type(action) is not dict or type(action.get('id')) is not int or action['id']!=5:
        raise ValueError('whole-scope public wide-paint Action5 required')
    for row in (before,after):
        if type(row.get('full_reset')) is not bool or row['full_reset']:
            raise ValueError('non-reset pair required')
    if any(before[k]!=after[k] for k in ('guid','game_id')):
        raise ValueError('same public identity required')
    return action

def phase_values(row,out,pure,side,case):
    frames=row['data']['frame']
    for ordinal,frame in enumerate(frames):
        C.admit()
        value={'ordinal':ordinal,'frame_sha256':C.sha(C.wire(frame)),
               'status':'pending','observation':None,'role':None,'error':None}
        out.append(value)
        OWNER['pending']={'case':case['ordinal'],'side':side,'row':row,
                          'phase':ordinal,'frame':frame,'remaining_phase_start':ordinal+1}
        try:
            observation=pure['read'](frame)
            value['observation']=observation
            value['role']=pure['classify'](observation,case['original_action'])
            value['status']='measured'
        except (ValueError,TypeError,KeyError,IndexError) as exc:
            OWNER['exceptions'].append(exc)
            value['status']='unknown';value['error']=C.error(exc)
        # MemoryError/Timeout/SystemExit propagate; incomplete value and raw suffix remain owned.

def before_hypothesis(observation,pure):
    C.need(type(observation['大きさ']) is int and observation['大きさ']==10,'100 target grammar')
    goals=observation['参照'];current=observation['対象']
    C.need(type(goals) is list and type(current) is list and len(goals)==len(current)==10 and
           all(type(row) is list and len(row)==10 for m in (goals,current) for row in m),'100 matrices')
    direction=observation['方向']
    C.need(type(direction) is list and len(direction)==2 and
           all(type(v) is int and v in (-1,0,1) for v in direction) and direction!=[0,0],
           'exact nonzero public unit direction')
    tool=observation['器具色'];targets=[];repair=[];preserve=[]
    for y in range(10):
        for x in range(10):
            goal=goals[y][x];color=current[y][x]
            geometry=None;err=None
            try:
                geometry=pure['membership'](observation['方向'],x,y,10,'広域塗布')
            except (ValueError,TypeError,KeyError,IndexError) as exc:
                OWNER['exceptions'].append(exc);err=C.error(exc)
            known=type(geometry) is bool and all(type(v) is int and 0<=v<=15 for v in (goal,color,tool))
            satisfied=(color==goal) if type(color) is int and type(goal) is int else None
            predicted=(tool if geometry else color) if known else None
            fit=(predicted==goal) if known else None
            targets.append({'target':[x,y],'goal':goal,'before_color':color,'tool_color':tool,
                 'geometry_candidate':geometry,'predicted_color':predicted,
                 'satisfied_before':satisfied,'predicted_goal_match':fit,'geometry_error':err})
            if satisfied is True:preserve.append(fit)
            elif satisfied is False:repair.append(fit)
            else:repair.append(None);preserve.append(None)
    aggregate=lambda values:all(values) if all(type(v) is bool for v in values) else None
    return {'public_reference':goals,'before_target':current,'tool_color':tool,
       'direction':observation['方向'],'reference_rectangle':observation['参照矩形'],
       'target_rectangle':observation['対象矩形'],'targets':targets,
       'deficit_count':len(repair),'satisfied_count':len(preserve),
       'all_repair':aggregate(repair),'all_preserve':aggregate(preserve),
       'empty_group_semantics':'empty universal is True; counts retained',
       'fixed_prior_hypothesis':True,'operation_permission':None}

def case_measure(index,rows,pure):
    si,br,ar=C.SELECTION[index];before=rows[(si,br)];after=rows[(si,ar)]
    bd,ad=before['data'],after['data']
    case={'ordinal':index,'selection':C.SELECTION[index],
          'before_row_ref':before['ref'],'after_row_ref':after['ref'],
          'before_metadata':{k:v for k,v in bd.items() if k!='frame'},
          'after_metadata':{k:v for k,v in ad.items() if k!='frame'},
          'original_action':ad.get('action_input'),'pair_error':None,
          'before_phases':[],'before_hypothesis':None,'query_input':None,
          'before_frozen_sha256':None,'after_phases':[],'public_progress':None,
          'after_bindings':[],'holds':[],'teacher':None,'boundary':C.BOUNDARY,
          'completed':False,'new_independent_support':0}
    OWNER['cases'].append(case)
    try:strict_pair(bd,ad)
    except (ValueError,TypeError,KeyError,IndexError) as exc:
        OWNER['exceptions'].append(exc);case['pair_error']=C.error(exc);case['holds'].append('invalid public pair')
    phase_values(before,case['before_phases'],pure,'before',case)
    C.need(len(case['before_phases'])==C.PHASE_COUNTS[index][0],'all before phases')
    last=case['before_phases'][-1]
    if last['status']=='measured' and last['role']=={'役割':'広域塗布','番号':5}:
        try:case['before_hypothesis']=before_hypothesis(last['observation'],pure)
        except (ValueError,TypeError,KeyError,IndexError,AssertionError) as exc:
            OWNER['exceptions'].append(exc)
            case['holds'].append({'before_hypothesis_error':C.error(exc)})
    else:case['holds'].append('last before binding or wide-paint role unknown')
    hypothesis=case['before_hypothesis']
    if hypothesis is not None and all(type(hypothesis[k]) is bool for k in ('all_repair','all_preserve')):
        case['query_input']={C.INPUT_KEYS[0]:hypothesis['all_repair'],C.INPUT_KEYS[1]:hypothesis['all_preserve']}
    else:case['holds'].append('before hypothesis undefined')
    frozen=C.wire(C.ENC((case['before_hypothesis'],case['query_input'])))
    case['before_frozen_sha256']=C.sha(frozen)
    phase_values(after,case['after_phases'],pure,'after',case)
    C.need(len(case['after_phases'])==C.PHASE_COUNTS[index][1],'all after phases')
    C.need(C.wire(C.ENC((case['before_hypothesis'],case['query_input'])))==frozen,'before immutable across after')
    bs,as_=bd.get('score'),ad.get('score')
    increased=as_>bs if type(bs) is int and type(as_) is int else None
    case['public_progress']={'before_score':bs,'after_score':as_,'increased':increased,
       'before_state':bd.get('state'),'after_state':ad.get('state'),
       'before_win_score':bd.get('win_score'),'after_win_score':ad.get('win_score'),
       'definition':'strict public score endpoint increase; no hidden state inference'}
    if increased is None:case['holds'].append('public progress unknown')
    origin=last['observation'] if last['status']=='measured' else None
    for phase in case['after_phases']:
        same=None
        if origin is not None and phase['status']=='measured':
            same=all(C.equal(origin[k],phase['observation'][k]) for k in ('参照','参照矩形','対象矩形'))
        case['after_bindings'].append({'ordinal':phase['ordinal'],'status':phase['status'],
          'same_reference_and_rectangles':same,'new_problem_confirmed_by_geometry':False,
          'continuous_preservation_confirmed':False})
    if not case['holds'] and case['query_input'] is not None and type(increased) is bool:
        case['teacher']=dict(case['query_input']);case['teacher'][C.RESULT_KEY]=increased
    case['completed']=True;OWNER['pending']=None
    return case

def run(gate):
    pure=load()
    OWNER['started']=True
    rows=C.raw_rows(OWNER)
    for index in range(6):case_measure(index,rows,pure)
    C.close_sources(OWNER)
    C.need(sum(len(v['before_phases'])+len(v['after_phases']) for v in OWNER['cases'])==112,'all112 phases')
    packet={'schema':'goal6-measured-material-v1','nonce':gate['nonce'],'complete':True,
      'selection':C.SELECTION,'rows':rows,'source_closures':OWNER['source_closures'],
      'dependencies':OWNER['dependency_refs'],'cases':OWNER['cases'],
      'errors':[],'all_phase_count':112,'new_independent_support':0,'HDS_API':0,
      'fixed_prior_not_learned_mask':True,'heap_alias_claim':False}
    OWNER['packet']=packet
    return packet
