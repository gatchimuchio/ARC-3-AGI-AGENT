"""Finite read-only measurement transport. No HDS API or legacy runtime."""
import ast
import dataclasses
import enum
import hashlib
import json
import lzma
import os
import pathlib
import resource
import shutil
import signal
import time
import traceback
from collections import Counter, deque
from typing import Any

BASE = pathlib.Path('/workspace/scratch/a94ff513b3af')
ROOT = BASE / 'arc-goal-teacher-recovered-20261013'
REPO = BASE / 'arc-recovery-main-20261013/repository'
RAW = BASE / 'arc-recovery-main-20261013/public-recordings'
CAPS = {'source':131072, 'prep':262144, 'producer':4194304,
        'reader':4194304, 'logs':262144, 'failure':2097152}
TOTAL = 12582912
RAW_CAP = 16777216
SELECTION = ((0,65,66),(0,74,75),(0,92,93),(2,23,24),(2,60,61),(2,141,142))
PHASE_COUNTS = ((1,15),(1,15),(1,15),(15,15),(1,16),(1,16))
SOURCES = {
 0:('130512d8-1d1b-4ee4-ab4b-9e0397fa6af8.recording.jsonl',6485013,'712c5f13f53714bddd0b234e0539660f6a6d6fe9b6a2c4c80196044a30801923'),
 2:('33f6b2f7-9e0d-41c5-ab94-5f929cdb85c1.recording.jsonl',15995704,'d53d72ae638453542fb01556ecb2235eb5b884bd9fda9e96f7e317a6d7004833')}
PINS = {
 '接続/ARC3境界.py':'ed95bb80f2326827c3f1237537a3df33203af8cac7881e46fd8b4d17e439d358',
 '接続/図式観測.py':'417269f9e94ec548c7f727c3e263efe952bbae21cf601021bcfd4d89b1a786d2',
 '接続/配色内部/知覚.py':'24cf101fe67f8dd15c928751c8b63e8e79d33dadecd39655bf7745ec1154c950',
 '接続/配色内部/関係.py':'29860d6afbd34cef8a835fbc5b7fab815146e8f717f104a4e2b3983fa72d3349',
 'HDS/学習系統/v0.4.2/hds学習系統/永続化.py':'8aa431b3012424fd8347c5b3d93a5fbf2218d35020836f5d40abb427f9d6da0d'}
INPUT_KEYS = ('不足対象は全て修復見込み','既充足対象は全て保存見込み')
RESULT_KEY = '公開進捗が増加'
BOUNDARY = '公開100対象・広域塗布・固定幾何上書き仮説と公開進捗'
ENC = DEC = None
ADMISSIONS = []
NAMESPACES = []

def need(value, message):
    if not value:
        raise AssertionError(message)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def wire(value):
    return json.dumps(value, ensure_ascii=False, separators=(',',':'), allow_nan=False).encode()

def parse(raw):
    def pairs(items):
        result = {}
        for key,value in items:
            need(key not in result, 'duplicate JSON key')
            result[key] = value
        return result
    return json.loads(raw, object_pairs_hook=pairs)

def equal(a,b):
    if type(a) is not type(b):
        return False
    if type(a) is dict:
        return len(a)==len(b) and all(equal(x,y) and equal(a[x],b[y]) for x,y in zip(a,b))
    if type(a) in (list,tuple):
        return len(a)==len(b) and all(equal(x,y) for x,y in zip(a,b))
    return a==b

def identity(path):
    s=path.stat()
    return (s.st_dev,s.st_ino,s.st_size,s.st_mode,s.st_mtime_ns,s.st_ctime_ns)

def digest(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()

def file_ref(path, raw):
    return {'path':str(path),'bytes':len(raw),'sha256':sha(raw)}

def checked(ref, cap):
    p=pathlib.Path(ref['path'])
    need(type(ref['bytes']) is int and 0<=ref['bytes']<=cap, 'FileRef cap')
    need(p.is_file() and not p.is_symlink() and p.stat().st_size==ref['bytes'], 'FileRef regular size')
    raw=p.read_bytes()
    need(sha(raw)==ref['sha256'], 'FileRef SHA')
    return raw

def error(exc):
    return {'type':type(exc).__module__+'.'+type(exc).__qualname__,
            'repr':repr(exc), 'traceback':''.join(traceback.format_exception(type(exc),exc,exc.__traceback__))}

def admit():
    # Local category caps and full38MiB cross-scope disk future; RAM768+512+512+128MiB.
    started=time.monotonic()
    used={}
    for category,cap in CAPS.items():
        directory=ROOT/category
        total=0
        if directory.exists():
            for path in directory.iterdir():
                need(path.is_file() and not path.is_symlink(), 'flat regular output files only')
                total+=path.stat().st_size
        need(total<=cap, 'category capacity: '+category)
        used[category]=total
    remaining=sum(CAPS[k]-used[k] for k in CAPS)
    need(sum(used.values())+remaining<=TOTAL, 'all finite future total')
    frees={str(p):shutil.disk_usage(p).free for p in (BASE,pathlib.Path('/tmp'),pathlib.Path('/'))}
    need(min(frees.values())>=1073741824+39845888, 'physical floor plus all future')
    mem=int(next(x.split()[1] for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
    need(mem>=2147483648+2013265920+39845888, 'memory floor plus full producer/reader/preparation futures')
    value={'ordinal':len(ADMISSIONS),'used':used,'remaining':remaining,'free':frees,
           'MemAvailable':mem,'full_parallel_future_bytes':2013265920,'all_scopes_disk_future_bytes':39845888,'elapsed_seconds':time.monotonic()-started}
    ADMISSIONS.append(value)
    return value

def save_bytes(name, raw, category):
    need('/' not in name and name not in ('.','..'), 'flat output basename')
    admit()
    directory=ROOT/category
    directory.mkdir(exist_ok=True)
    need(sum(p.stat().st_size for p in directory.iterdir())+len(raw)<=CAPS[category], 'write future cap')
    p=directory/name
    with p.open('xb') as f:
        f.write(raw);f.flush();os.fsync(f.fileno())
    for d in (directory,ROOT):
        fd=os.open(d,os.O_RDONLY|os.O_DIRECTORY)
        try:os.fsync(fd)
        finally:os.close(fd)
    need(p.read_bytes()==raw, 'full write readback')
    return file_ref(p,raw)

def load_pure():
    global ENC,DEC
    env={'Any':Any,'Mapping':dict,'Counter':Counter,'deque':deque,
         'Enum':enum.Enum,'is_dataclass':dataclasses.is_dataclass,'fields':dataclasses.fields,
         '_型表':lambda:{}}
    NAMESPACES.append(env)
    groups=(
      ('接続/ARC3境界.py',('境界違反','_列','_整数','_盤面列')),
      ('接続/図式観測.py',('成分群',)),
      ('接続/配色内部/知覚.py',('bbox','connected','read','classify')),
      ('接続/配色内部/関係.py',('membership',)),
      ('HDS/学習系統/v0.4.2/hds学習系統/永続化.py',('_符号化','_復号')))
    refs=[]
    for rel,names in groups:
        p=REPO/rel;raw=p.read_bytes();need(sha(raw)==PINS[rel], 'fixed dependency pin')
        tree=ast.parse(raw)
        nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in names]
        need(tuple(n.name for n in nodes)==names, 'exact pure AST declarations')
        exec(compile(ast.Module(body=nodes,type_ignores=[]),str(p)+'::pure','exec'),env)
        refs.append(file_ref(p,raw))
    ENC,DEC=env['_符号化'],env['_復号']
    return env,refs

def validate_tags(value):
    if type(value) in (type(None),bool,int,str):
        return
    if type(value) is float:
        need(value==value and abs(value)!=float('inf'), 'finite float')
        return
    if type(value) is list:
        for item in value:validate_tags(item)
        return
    need(type(value) is dict and len(value)==1, 'known single native tag')
    key=next(iter(value))
    need(key in ('__組__','__辞書__') and type(value[key]) is list, 'plain-value native tags only')
    if key=='__組__':
        for item in value[key]:validate_tags(item)
    else:
        keys=[]
        for pair in value[key]:
            need(type(pair) is list and len(pair)==2,'dictionary pair')
            validate_tags(pair[0]);validate_tags(pair[1])
            decoded=DEC(pair[0])
            need(not any(decoded==old for old in keys),'duplicate decoded dictionary key')
            keys.append(decoded)

def plain_value(value, active=None):
    if active is None:active=set()
    if type(value) in (type(None),bool,int,str):return
    if type(value) is float:
        need(value==value and abs(value)!=float('inf'),'finite scalar');return
    need(type(value) in (dict,list,tuple),'unsupported native-codec leaf')
    need(id(value) not in active,'cycle in material projection')
    active.add(id(value))
    if type(value) is dict:
        for k,v in value.items():plain_value(k,active);plain_value(v,active)
    else:
        for v in value:plain_value(v,active)
    active.remove(id(value))

def pack(value, owner):
    owner['serialization']={'original':value}
    plain_value(value)
    encoded=ENC(value);owner['serialization']['encoded']=encoded
    raw=wire(encoded);owner['serialization']['raw']=raw
    need(len(raw)<=RAW_CAP,'raw16MiB')
    blob=lzma.compress(raw,format=lzma.FORMAT_XZ,check=lzma.CHECK_CRC64,preset=0)
    owner['serialization']['blob']=blob
    need(len(blob)<=4194304,'XZ4MiB')
    back=unpack(blob,owner)
    need(equal(value,back),'whole original type/order readback')
    return blob,{'raw_bytes':len(raw),'raw_sha256':sha(raw)}

def unpack(blob, owner):
    d=lzma.LZMADecompressor(format=lzma.FORMAT_XZ,memlimit=33554432)
    raw=d.decompress(blob,max_length=RAW_CAP+1)
    need(len(raw)<=RAW_CAP and d.eof and not d.unused_data and d.check==lzma.CHECK_CRC64,'single CRC64 EOF/raw cap')
    owner['readback_raw']=raw
    encoded=parse(raw);validate_tags(encoded)
    decoded=DEC(encoded);owner['readback_decoded']=decoded
    need(equal(ENC(decoded),encoded) and wire(ENC(decoded))==raw,'native tag whole-byte/type/order roundtrip')
    return decoded

def raw_rows(owner):
    rows={};owner['rows']=rows
    closures=[];owner['source_closures']=closures
    for si,(name,size,expected) in SOURCES.items():
        admit()
        p=RAW/name;before=identity(p)
        need(before[2]==size and digest(p)==expected,'whole source before')
        selected=sorted({row for s,b,a in SELECTION if s==si for row in (b,a)})
        closure={'source_index':si,'source':{'path':str(p),'bytes':size,'sha256':expected},
                 'identity_before':before,'selected_rows':selected,'prefix_rows':max(selected)+1}
        closures.append(closure)
        with p.open('rb') as f:
            for row in range(max(selected)+1):
                offset=f.tell();line=f.readline(2097153)
                need(line and len(line)<=2097152,'bounded prefix line')
                if row not in selected:continue
                admit()
                original=parse(line);data=original.get('data',original)
                need(type(data) is dict and type(data.get('frame')) is list,'full row/frame')
                rows[(si,row)]={'ref':{'source_index':si,'row':row,'physical_line_1based':row+1,
                  'byte_offset':offset,'bytes':len(line),'sha256':sha(line)},
                  'raw_utf8':line.decode('utf-8'),'original':original,'data':data}
        admit()
        closure['identity_after_read']=identity(p)
        closure['sha256_after_read']=digest(p)
        need(closure['identity_after_read']==before and closure['sha256_after_read']==expected,'source read closure')
    need(len(rows)==12 and sum(v['ref']['bytes'] for v in rows.values())==1421779,'all12 exact byte count')
    return rows

def close_sources(owner):
    for closure in owner['source_closures']:
        admit()
        path=pathlib.Path(closure['source']['path'])
        closure['identity_after_measure']=identity(path)
        closure['sha256_after_measure']=digest(path)
        need(closure['identity_after_measure']==closure['identity_before'] and
             closure['sha256_after_measure']==closure['source']['sha256'],'source final closure')
