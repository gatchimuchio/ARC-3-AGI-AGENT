"""Synthetic goal6 boundary tests. No original frames or HDS execution."""
import pathlib, hashlib, types, copy, json, traceback
ROOT=pathlib.Path('/workspace/scratch/a94ff513b3af/arc-goal-teacher-recovered-20261013')
PINS={'goal6_common_v1.py': 'c4f693f1a9106b43bd7a2fffb8775042de6925854807fe3ba784641b2af58697', 'goal6_producer_v1.py': 'd26f08cb59588670be2fa8abd493efe7678c3a421a036ffaf1e54db8d290a979', 'goal6_reader_v1.py': '80714ea32922b5f246c4d87d86ff35dc5a97b41dc3793d8926f4751aa2e94e54', 'goal6_outer_v2.py': 'c6d79f3a417fcbe6255a94b9ec28cac76b00f3444d3022a62fa041aae3665f17'}
OWNER={'modules':[],'cases':[],'exceptions':[],'current':None,'complete':False,'errors':[]}
P=R=C=O=None

def need(v,m):
    if not v:raise AssertionError(m)

def load(name):
    path=ROOT/'source'/name;raw=path.read_bytes()
    need(hashlib.sha256(raw).hexdigest()==PINS[name],'fixture dependency pin')
    module=types.ModuleType('fixture_'+name.replace('.','_'));module.__file__=str(path)
    OWNER['modules'].append(module)
    exec(compile(raw,str(path),'exec'),module.__dict__)
    return module

def check(label,fn):
    record={'label':label,'status':'started','value':None,'error':None}
    OWNER['cases'].append(record);OWNER['current']=record
    try:
        record['value']=fn();record['status']='PASS'
    except BaseException as exc:
        OWNER['exceptions'].append(exc)
        record['status']='FAIL';record['error']=C.error(exc)
        raise

def expect_error(fn,kind,fragment):
    try:fn()
    except kind as exc:
        OWNER['exceptions'].append(exc)
        need(fragment in str(exc),'exact expected failure reason')
        return C.error(exc)
    raise AssertionError('expected exception missing')

def observation():
    return {'大きさ':10,'参照':[[1]*10 for _ in range(10)],
      '対象':[[0 if x>=5 else 1 for x in range(10)] for _ in range(10)],
      '器具色':1,'方向':[1,0],'参照矩形':[1,1,11,11],'対象矩形':[20,20,30,30],
      '色見本':[{'色':1,'矩形':[40,1,45,6],'クリック':[42,3]}],
      '装置画素':[(0,0,'枠')],'背景色':7,'器具矩形':[31,20,36,30],'小器具矩形群':[]}

def data(score,frames):
    return {'guid':'synthetic-guid','game_id':'synthetic-public-game','full_reset':False,
      'action_input':{'id':5,'data':{}},'score':score,'state':'NOT_FINISHED',
      'win_score':3,'extra_metadata':{'preserved':True},'frame':frames}

def rawrow(row,datum):
    raw=C.wire({'data':datum})+b'\n'
    return {'ref':{'source_index':0,'row':row,'physical_line_1based':row+1,
      'byte_offset':row*100,'bytes':len(raw),'sha256':C.sha(raw)},
      'raw_utf8':raw.decode(),'original':{'data':datum},'data':datum}

def reset():
    P.OWNER['cases']=[];P.OWNER['exceptions']=[];P.OWNER['pending']=None
    R.OWNER['cases']=[];R.OWNER['exceptions']=[];R.OWNER['trace_pairs']=[]
    C.ADMISSIONS.clear()

def mock_pure(ob,fail_at=None,error_type=ValueError):
    counter={'calls':0}
    def read(frame):
        i=counter['calls'];counter['calls']+=1
        if i==fail_at:raise error_type('synthetic phase failure')
        return copy.deepcopy(ob)
    return {'read':read,'classify':lambda view,action:{'役割':'広域塗布','番号':5},
            'membership':FIXED['membership']},counter

def case_once(after_score,fail_at=None,error_type=ValueError):
    reset();ob=observation();pure,counter=mock_pure(ob,fail_at,error_type)
    rows={(0,65):rawrow(65,data(2,[[[0]]])),
          (0,66):rawrow(66,data(after_score,[[[i%16]] for i in range(15)]))}
    value=P.case_measure(0,rows,pure)
    return value,rows,counter

def aggregate_grid():
    values=[]
    for direction in ([1,0],[-1,0],[0,1],[1,1]):
        for tool in (0,1,2):
            for pattern in ('mixed','all_satisfied','none_satisfied'):
                ob=observation();ob['方向']=direction;ob['器具色']=tool
                if pattern=='all_satisfied':ob['対象']=[[1]*10 for _ in range(10)]
                if pattern=='none_satisfied':ob['対象']=[[0]*10 for _ in range(10)]
                a=P.before_hypothesis(ob,FIXED);b=R.hypothesis(ob,FIXED,a)
                need(C.equal(a,b),'independent S/M/C equivalence')
                need(len(a['targets'])==100 and a['deficit_count']+a['satisfied_count']==100,'100 complete targets')
                values.append({'direction':direction,'tool':tool,'pattern':pattern,'result':a})
    return values

class EndHold(BaseException):pass

class FakePath:
    def __init__(self,raw):self.raw=raw
    def __truediv__(self,name):return self
    def exists(self):return True
    def is_symlink(self):return False
    def stat(self):return types.SimpleNamespace(st_size=len(self.raw))
    def read_bytes(self):return self.raw

def ack_test(mutation):
    receipt={'path':'synthetic-receipt','bytes':1,'sha256':'a'}
    audit={'schema':'goal6-reader-receipt-v1','status':'PASS','complete':True,
      'producer_receipt':receipt,'material':{'path':'packet'},'source':{'sha256':O.SOURCES['reader'][1]},
      'verified':dict.fromkeys(['all_six_cases','all_112_phases','all_12_original_rows','full_type_order',
        'before_only_two_conditions','all_100_targets_per_eligible_case','independent_public_progress',
        'all_unknowns_preserved','new_support_zero'],True)}
    ack={'schema':'goal6-recovered-root-ack-v1','mode':'producer','nonce':'a'*32,
         'decision':'ACK','receipt':receipt,'independent_audit':{'synthetic':True}}
    O.STATE={'complete':True,'exception':None,'receipt_ref':receipt,
             'receipt':{'packet':{'path':'packet'}},'secondary':[]}
    mutation(ack,audit,O.STATE)
    original=(O.ROOT,O.time,O.bounded_json)
    O.ROOT=FakePath(C.wire(ack))
    O.time=types.SimpleNamespace(sleep=lambda _:(_ for _ in ()).throw(EndHold()))
    O.bounded_json=lambda ref,cap:audit
    try:
        try:O.acknowledge(C,'producer','a'*32)
        except EndHold:
            need(O.STATE['secondary'],'actual ACK rejection retained')
            return {'rejected':True,'exceptions':[C.error(x) for x in O.STATE['secondary']]}
        return {'rejected':False}
    finally:O.ROOT,O.time,O.bounded_json=original

def run():
    global P,R,C,O,FIXED
    C=load('goal6_common_v1.py');P=load('goal6_producer_v1.py')
    R=load('goal6_reader_v1.py');O=load('goal6_outer_v2.py')
    P.C=R.C=C
    FIXED,refs=C.load_pure()
    OWNER['pure_dependencies']=refs
    real_admit=C.admit
    C.admit=lambda:C.ADMISSIONS.append({'synthetic':True})
    try:
        good=data(0,[[[0]]])
        check('strict_valid',lambda:(P.strict_pair(good,good),R.pair_check(good,good)))
        for label,change,fragment in (
          ('identity_before_action',lambda b,a:(b.update(guid=None),a['action_input'].update(id=True)),'strict nonempty'),
          ('bool_action',lambda b,a:a['action_input'].update(id=True),'Action5'),
          ('reset_before_identity',lambda b,a:(b.update(full_reset=True),a.update(guid='other')),'non-reset'),
          ('same_identity',lambda b,a:a.update(guid='other'),'same public')):
            def test(change=change,fragment=fragment):
                b=copy.deepcopy(good);a=copy.deepcopy(good);change(b,a)
                x=expect_error(lambda:P.strict_pair(b,a),ValueError,fragment)
                y=expect_error(lambda:R.pair_check(b,a),ValueError,fragment)
                need((x['type'],x['repr'])==(y['type'],y['repr']),'reject type/repr/order')
                return [x,y]
            check(label,test)
        check('aggregate_all36_grids',aggregate_grid)
        for label,direction in (('zero_direction',[0,0]),('bool_direction',[True,0]),('nonunit_direction',[2,0])):
            def test(direction=direction):
                ob=observation();ob['方向']=direction
                return expect_error(lambda:P.before_hypothesis(ob,FIXED),AssertionError,'unit direction')
            check(label,test)
        def before_independent():
            a,rows,_=case_once(2);b,_,_=case_once(3);c,_,_=case_once(1)
            need(C.equal(a['query_input'],b['query_input']) and C.equal(a['query_input'],c['query_input']),'after cannot modify before')
            need(a['teacher'][C.RESULT_KEY] is False and b['teacher'][C.RESULT_KEY] is True and c['teacher'][C.RESULT_KEY] is False,'both progress outcomes retained')
            return [a,b,c]
        check('after_label_isolation',before_independent)
        def unknown_before():
            value,rows,counter=case_once(3,0)
            need(counter['calls']==16 and value['before_hypothesis'] is None and value['teacher'] is None,'unknown last before no after backfill')
            need(len(value['after_phases'])==15,'all after phases retained')
            return value
        check('unknown_final_before',unknown_before)
        def bool_score():
            value,rows,_=case_once(True)
            need(value['teacher'] is None and value['public_progress']['increased'] is None
                 and value['query_input'] is not None,'bool score is unknown without corrupting before')
            return value
        check('bool_score_not_int',bool_score)
        def unknown_geometry():
            ob=observation();pure=dict(FIXED);pure['membership']=lambda *args:None
            a=P.before_hypothesis(ob,pure);b=R.hypothesis(ob,pure,a)
            need(C.equal(a,b) and a['all_repair'] is None and a['all_preserve'] is None and
                 len(a['targets'])==100,'unknown geometry is not False')
            return a
        check('geometry_None_preserved',unknown_geometry)
        def middle_unknown():
            value,rows,counter=case_once(3,7)
            need(counter['calls']==16 and value['after_phases'][6]['status']=='unknown','middle unknown preserved')
            need(value['teacher'] is not None and all(x['continuous_preservation_confirmed'] is False for x in value['after_bindings']),'endpoint eligibility separate')
            return value
        check('unknown_middle_endpoint_scope',middle_unknown)
        def independent_case():
            value,rows,_=case_once(3)
            pure,counter=mock_pure(observation())
            R.verify_case(0,rows,pure,value)
            changed=copy.deepcopy(value)
            changed['query_input'][C.INPUT_KEYS[0]]=not changed['query_input'][C.INPUT_KEYS[0]]
            pure,counter=mock_pure(observation())
            err=expect_error(lambda:R.verify_case(0,rows,pure,changed),AssertionError,'before-only')
            return {'original':value,'tampered':changed,'rejection':err}
        check('independent_full_case_and_tamper',independent_case)
        for kind in (TimeoutError,MemoryError):
            def fatal(kind=kind):
                reset();pure,counter=mock_pure(observation(),3,kind)
                rows={(0,65):rawrow(65,data(2,[[[0]]])),(0,66):rawrow(66,data(3,[[[0]] for _ in range(15)]))}
                err=expect_error(lambda:P.case_measure(0,rows,pure),kind,'synthetic phase failure')
                case=P.OWNER['cases'][0]
                need(case['completed'] is False and len(case['after_phases'])==3 and
                     case['after_phases'][-1]['status']=='pending' and
                     P.OWNER['pending']['remaining_phase_start']==3,'fatal complete prefix/pending/suffix')
                need(P.OWNER['pending']['row'] is rows[(0,66)],'raw suffix remains owned')
                return {'case':case,'pending':P.OWNER['pending'],'exception':err}
            check('fatal_'+kind.__name__,fatal)
        def full_phase_order():
            records=[]
            for i,(nb,na) in enumerate(C.PHASE_COUNTS):
                reset();si,br,ar=C.SELECTION[i]
                rows={(si,br):rawrow(br,data(1,[[[0]] for _ in range(nb)])),
                      (si,ar):rawrow(ar,data(2,[[[0]] for _ in range(na)]))}
                pure,counter=mock_pure(observation())
                case=P.case_measure(i,rows,pure)
                need(counter['calls']==nb+na and [p['ordinal'] for p in case['before_phases']]==list(range(nb)),'all indexed duplicates')
                records.append(case)
            need(sum(len(c['before_phases'])+len(c['after_phases']) for c in records)==112,'112 retained')
            return records
        check('all112_phases',full_phase_order)
        def codec():
            value={'tuple':(False,0,True,1),'ordered':{'z':[None,'x'],'a':[]}}
            held={};blob,ref=C.pack(value,held)
            need(C.equal(value,C.unpack(blob,held)),'codec exact tuple/types/order')
            return {'value':value,'ref':ref,'blob_hex':blob.hex()}
        check('codec_type_order',codec)
        check('codec_opaque_rejected',lambda:expect_error(lambda:C.plain_value({1,2}),AssertionError,'unsupported'))
        check('codec_duplicate_tag_key',lambda:expect_error(lambda:C.validate_tags({'__辞書__':[['x',1],['x',2]]}),AssertionError,'duplicate'))
        check('codec_mixed_tag',lambda:expect_error(lambda:C.validate_tags({'__組__':[],'extra':1}),AssertionError,'single native tag'))
        check('codec_trailing_XZ',lambda:expect_error(lambda:C.unpack(C.pack({'a':1},{})[0]+b'x',{}),AssertionError,'single CRC64'))
        for label,mutation in (
          ('failed_owner',lambda a,b,s:s.update(complete=False)),
          ('wrong_nonce',lambda a,b,s:a.update(nonce='b'*32)),
          ('wrong_receipt',lambda a,b,s:a.update(receipt={})),
          ('false_verified',lambda a,b,s:b['verified'].update(before_only_two_conditions=False)),
          ('empty_verified',lambda a,b,s:b.update(verified={})),
          ('wrong_material',lambda a,b,s:b.update(material={}))):
            def negative(mutation=mutation):
                result=ack_test(mutation);need(result['rejected'] is True,'negative ACK');return result
            check('ACK_'+label,negative)
        def positive_ack():
            value=ack_test(lambda *args:None)
            need(value['rejected'] is False,'valid ACK accepted')
            return value
        check('ACK_valid',positive_ack)
        OWNER['complete']=True
        return {'schema':'goal6-pure-fixture-v1','complete':True,'cases':OWNER['cases'],
          'case_count':len(OWNER['cases']),'errors':[],'original_raw_measurements':0,'HDS_API':0,
          'limits':'Synthetic observations/phase read seam; real fixed membership, hypothesis, codec and ACK predicates. OS durability and actual raw perception are not exercised.'}
    finally:
        C.admit=real_admit
