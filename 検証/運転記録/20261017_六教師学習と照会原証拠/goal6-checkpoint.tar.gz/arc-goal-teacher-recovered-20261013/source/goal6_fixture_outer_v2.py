"""Pure fixture v2 pin/name only; retained outer behavior unchanged."""
import resource
resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912))
import pathlib,hashlib
_BASE=pathlib.Path('/workspace/scratch/a94ff513b3af/arc-goal-teacher-recovered-20261013/source/goal6_fixture_outer_v1.py')
_RAW=_BASE.read_bytes()
assert hashlib.sha256(_RAW).hexdigest()=='3dc21868f150c0d83e20b5f544d60541e70b5901a2d60a33aa51268aae67c1f4'
PATCHES=[("FIXTURE_SHA='53d50dfadae6590e8baeaa5d2d0374a119518703e82a3ea16163afec4b09a76a'", "FIXTURE_SHA='dffab137a8236e34ad465adbfc18a727efc49fc086bb1be4d480b80bcd24017e'"), ('source/goal6_pure_fixture_v1.py', 'source/goal6_pure_fixture_v2.py')]
_EFFECTIVE=_RAW.decode()
for _old,_new in PATCHES:
    assert _EFFECTIVE.count(_old)==1
    _EFFECTIVE=_EFFECTIVE.replace(_old,_new)
assert hashlib.sha256(_EFFECTIVE.encode()).hexdigest()=='172d867a05416337126f1ad8b8c109952cf9acc4ba678340a45e501478a9643b'
exec(compile(_EFFECTIVE,str(_BASE)+"::fixture-v2","exec"),globals())
