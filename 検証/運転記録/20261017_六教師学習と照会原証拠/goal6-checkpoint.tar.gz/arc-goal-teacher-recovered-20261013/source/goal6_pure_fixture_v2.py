"""Preserve all synthetic case owners across resets; no test meaning changes."""
import pathlib, hashlib
_BASE=pathlib.Path('/workspace/scratch/a94ff513b3af/arc-goal-teacher-recovered-20261013/source/goal6_pure_fixture_v1.py')
_RAW=_BASE.read_bytes()
assert hashlib.sha256(_RAW).hexdigest()=='53d50dfadae6590e8baeaa5d2d0374a119518703e82a3ea16163afec4b09a76a'
PATCHES=[['def reset():\n', "def retain_previous_state(reason):\n    # Strong references preserve original objects; copies retain fields about to be replaced.\n    OWNER.setdefault('retained_states', []).append({\n        'reason': reason,\n        'producer_owner_object': P.OWNER,\n        'producer_fields': dict(P.OWNER),\n        'reader_owner_object': R.OWNER,\n        'reader_fields': dict(R.OWNER),\n        'admissions_object': C.ADMISSIONS,\n        'admission_contents': list(C.ADMISSIONS),\n    })\n\ndef reset():\n    retain_previous_state('before_reset')\n"], ["    O.STATE={'complete':True,'exception':None,'receipt_ref':receipt,", "    OWNER.setdefault('retained_ACK_states', []).append({\n        'stage': 'before_replacement', 'state': O.STATE,\n    })\n    O.STATE={'complete':True,'exception':None,'receipt_ref':receipt,"], ['    finally:O.ROOT,O.time,O.bounded_json=original', "    finally:\n        OWNER['retained_ACK_states'].append({\n            'stage': 'after_attempt', 'state': O.STATE, 'ACK': ack, 'audit': audit,\n        })\n        O.ROOT,O.time,O.bounded_json=original"]]
_EFFECTIVE=_RAW.decode()
for _old,_new in PATCHES:
    assert _EFFECTIVE.count(_old)==1
    _EFFECTIVE=_EFFECTIVE.replace(_old,_new)
assert hashlib.sha256(_EFFECTIVE.encode()).hexdigest()=='b45c4d519ce47e9d881c9621b6daa1e94acaa52621bad0d57ba23056ad48cc93'
exec(compile(_EFFECTIVE,str(_BASE)+"::retention-v2","exec"),globals())
