"""Own module before import and retain originals until exact root ACK."""
import resource
resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912))
import pathlib, hashlib, types, sys, signal, time, json, traceback
sys.dont_write_bytecode=True
ROOT=pathlib.Path('/workspace/scratch/a94ff513b3af/arc-goal-teacher-recovered-20261013')
SOURCES={'producer': ('goal6_producer_v1.py', 'd26f08cb59588670be2fa8abd493efe7678c3a421a036ffaf1e54db8d290a979'), 'reader': ('goal6_reader_v1.py', '80714ea32922b5f246c4d87d86ff35dc5a97b41dc3793d8926f4751aa2e94e54')}
STATE={'module':None,'gate':None,'exception':None,'traceback':None,'secondary':[],
       'packet':None,'blob':None,'receipt':None,'receipt_ref':None,'complete':False,
       'failure_ref':None,'stage':'not_started'}

def require(v,msg):
    if not v:raise AssertionError(msg)

def bounded_json(ref,cap):
    p=pathlib.Path(ref['path'])
    require(type(ref['bytes']) is int and 0<=ref['bytes']<=cap and p.is_file() and
            not p.is_symlink() and p.stat().st_size==ref['bytes'],'bounded gate FileRef')
    raw=p.read_bytes()
    require(hashlib.sha256(raw).hexdigest()==ref['sha256'],'gate FileRef SHA')
    def pairs(items):
        d={}
        for k,v in items:
            require(k not in d,'duplicate gate key');d[k]=v
        return d
    return json.loads(raw,object_pairs_hook=pairs)

def deadline(*_):
    raise TimeoutError('goal6 finite compute/save deadline')

def acknowledge(C,mode,nonce):
    path=ROOT/'logs'/('root_ack_'+mode+'_'+nonce+'.json')
    while True:
        if path.exists():
            try:
                require(path.stat().st_size<=16384 and not path.is_symlink(),'ACK bound')
                raw=path.read_bytes();ack=C.parse(raw)
                require(STATE['complete'] and STATE['exception'] is None,'failed owner cannot ACK')
                require(ack['schema']=='goal6-recovered-root-ack-v1' and ack['mode']==mode and
                        ack['nonce']==nonce and ack['decision']=='ACK','ACK identity')
                require(C.equal(ack['receipt'],STATE['receipt_ref']),'ACK exact receipt')
                if mode=='producer':
                    audit=bounded_json(ack['independent_audit'],16384)
                    require(audit['schema']=='goal6-reader-receipt-v1' and audit['status']=='PASS'
                      and C.equal(audit['producer_receipt'],STATE['receipt_ref'])
                      and C.equal(audit['material'],STATE['receipt']['packet'])
                      and audit['complete'] is True
                      and audit['source']['sha256']==SOURCES['reader'][1]
                      and set(audit['verified'])=={'all_six_cases','all_112_phases','all_12_original_rows',
                        'full_type_order','before_only_two_conditions','all_100_targets_per_eligible_case',
                        'independent_public_progress','all_unknowns_preserved','new_support_zero'}
                      and all(v is True for v in audit['verified'].values()),'independent audit join')
                STATE['ACK']=ack;STATE['stage']='root_acknowledged'
                return
            except BaseException as exc:
                STATE['secondary'].append(exc)
                print(json.dumps({'stage':'ACK_rejected','type':type(exc).__name__,'repr':repr(exc)}),flush=True)
        time.sleep(5)

def main(gate_path,gate_sha):
    start=time.monotonic();signal.signal(signal.SIGALRM,deadline);signal.alarm(1800)
    try:
        path=pathlib.Path(gate_path)
        require(path.parent==ROOT/'logs' and path.is_file() and not path.is_symlink()
                and path.stat().st_size<=16384,'gate fixed logs path')
        raw=path.read_bytes();require(hashlib.sha256(raw).hexdigest()==gate_sha,'gate SHA')
        gate=bounded_json({'path':str(path),'bytes':len(raw),'sha256':gate_sha},16384)
        STATE['gate']=gate
        require(gate['schema']=='goal6-recovered-release-v1' and gate['enabled'] is True
          and type(gate['AS']) is int and gate['AS']==536870912
          and type(gate['compute_seconds']) is int and gate['compute_seconds']==1800
          and type(gate['save_seconds']) is int and gate['save_seconds']==300,'gate limits')
        nonce=gate['nonce'];require(type(nonce) is str and len(nonce)==32 and
                                  all(c in '0123456789abcdef' for c in nonce),'nonce')
        mode=gate['mode'];require(mode in SOURCES,'mode')
        name,digest=SOURCES[mode]
        source=ROOT/'source'/name;data=source.read_bytes()
        require(hashlib.sha256(data).hexdigest()==digest,'source pin')
        require(gate['source']=={'path':str(source),'bytes':len(data),'sha256':digest},'gate source')
        own=pathlib.Path(__file__).resolve();ownraw=own.read_bytes()
        require(gate['outer']=={'path':str(own),'bytes':len(ownraw),
                               'sha256':hashlib.sha256(ownraw).hexdigest()},'outer pin')
        contract=bounded_json(gate['contract'],131072)
        require(contract['schema']=='goal6-recovered-contract-v1' and
                contract['source_only_until_root_gate'] is True,'contract')
        module=types.ModuleType('owned_goal6_'+mode);module.__file__=str(source)
        STATE['module']=module
        exec(compile(data,str(source),'exec'),module.__dict__)
        STATE['stage']='measurement' if mode=='producer' else 'independent_readback'
        packet=module.run(gate);STATE['packet']=packet
        # Separate bounded save phase; no calculation continues after this boundary.
        elapsed=time.monotonic()-start
        require(elapsed<=1800,'compute endpoint deadline')
        signal.alarm(300);STATE['stage']='saving'
        C=module.C;C.admit()
        blob,rawref=C.pack(packet,STATE);STATE['blob']=blob
        name='goal6_'+mode+'_'+nonce+'.typed.json.xz'
        ref=C.save_bytes(name,blob,mode);ref.update(rawref)
        reread=C.checked(ref,4194304);decoded=C.unpack(reread,STATE)
        require(C.equal(decoded,packet),'disk full packet type/order')
        receipt={'schema':'goal6-'+mode+'-receipt-v1','nonce':nonce,
          'complete':True,'status':'PASS' if mode=='reader' else 'complete',
          'packet':ref,'source':gate['source'],'outer':gate['outer'],
          'gate':{'path':str(path),'bytes':len(raw),'sha256':gate_sha},
          'compute_elapsed_seconds':elapsed,
          'admissions_before_receipt':len(C.ADMISSIONS),
          'final_receipt_admission_additional':1,
          'admission_log':C.ADMISSIONS,'errors':[],'HDS_API':0,
          'new_independent_support':0,'producer_normal_closure':False}
        # Full admission log is retained in the live owner, not duplicated into small receipt.
        receipt['admission_log_count']=len(receipt.pop('admission_log'))
        if mode=='reader':
            receipt.update({'producer_receipt':gate['producer_receipt'],
              'material':packet['material'],'verified':packet['verified']})
        else:
            receipt.update({'case_count':6,'phase_count':112,
              'eligible_teacher_count':sum(x['teacher'] is not None for x in packet['cases'])})
        receipt_raw=C.wire(receipt);require(len(receipt_raw)<=16384,'receipt16KiB')
        STATE['receipt']=receipt
        STATE['receipt_ref']=C.save_bytes('goal6_'+mode+'_'+nonce+'.receipt.json',receipt_raw,'logs')
        STATE['complete']=True;module.OWNER['complete']=True
        signal.alarm(0);STATE['stage']='await_root_ack'
        print(json.dumps({'stage':STATE['stage'],'receipt':STATE['receipt_ref'],'packet':ref},ensure_ascii=False),flush=True)
        acknowledge(C,mode,nonce)
    except BaseException as exc:
        signal.alarm(300)
        STATE['exception']=exc
        STATE['traceback']=''.join(traceback.format_exception(type(exc),exc,exc.__traceback__))
        STATE['stage']='failed_retained'
        try:
            module=STATE['module'];C=getattr(module,'C',None)
            if C is not None:
                failure={'schema':'goal6-recovered-failure-v1','complete':False,
                  'gate':STATE['gate'],'type':type(exc).__name__,'repr':repr(exc),
                  'traceback':STATE['traceback'],'pending':module.OWNER.get('pending'),
                  'rows':module.OWNER.get('rows'),'cases':module.OWNER.get('cases'),
                  'source_closures':module.OWNER.get('source_closures'),
                  'exception_descriptions':[C.error(x) for x in module.OWNER.get('exceptions',[])],
                  'heap_alias_claim':False}
                STATE['failure_projection']=failure
                blob,rawref=C.pack(failure,STATE)
                require(len(blob)<=2097152,'failure reserve2MiB')
                nonce=STATE['gate']['nonce'] if STATE['gate'] else 'unbound'
                STATE['failure_ref']=C.save_bytes('goal6_failure_'+nonce+'.xz',blob,'failure')
                STATE['failure_ref'].update(rawref)
        except BaseException as secondary:
            STATE['secondary'].append(secondary)
        finally:
            signal.alarm(0)
        print(json.dumps({'stage':STATE['stage'],'type':type(exc).__name__,'repr':repr(exc),
                          'traceback':STATE['traceback'],'failure_ref':STATE['failure_ref']},
                         ensure_ascii=False),flush=True)
        while True:time.sleep(60)

if __name__=='__main__':
    main(*sys.argv[1:])
