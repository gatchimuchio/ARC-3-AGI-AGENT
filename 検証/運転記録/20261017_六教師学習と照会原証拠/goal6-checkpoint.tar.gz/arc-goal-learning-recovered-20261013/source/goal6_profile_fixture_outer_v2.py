import resource
resource.setrlimit(resource.RLIMIT_AS,(134217728,134217728))
import pathlib,hashlib,importlib.util,sys,time,traceback,json,datetime
MODULE=None
RETURN=None
ERRORS=[]
SOURCE={'path': '/workspace/scratch/a94ff513b3af/arc-goal-learning-recovered-20261013/source/goal6_profile_fixture_v2.py', 'bytes': 13532, 'sha256': '4ba5622f9abde1a392a8b94c022ae2b81582ec3e82295ae3a64f7c9019446c8e'}
if __name__=="__main__":
    try:
        raw=pathlib.Path(SOURCE["path"]).read_bytes()
        if len(raw)!=SOURCE["bytes"] or hashlib.sha256(raw).hexdigest()!=SOURCE["sha256"]:
            raise PermissionError("fixture exact source pin")
        spec=importlib.util.spec_from_file_location("goal6_profile_fixture",SOURCE["path"])
        MODULE=importlib.util.module_from_spec(spec)
        spec.loader.exec_module(MODULE)
        RETURN=MODULE.run(sys.argv[1],sys.argv[2])
        if RETURN.get("stage") not in ("closed_after_root_ack","failed_closed_after_root_ack"):
            raise RuntimeError("nonclosed fixture return retained")
        print(json.dumps(RETURN,ensure_ascii=False),flush=True)
        print("UTCEND "+datetime.datetime.now(datetime.timezone.utc).isoformat(),flush=True)
        EXIT_CODE=1 if RETURN["stage"]=="failed_closed_after_root_ack" else 0
    except BaseException as exc:
        ERRORS.append((exc,traceback.format_exc()));print(ERRORS[-1][1],flush=True)
        while True:time.sleep(5)

if __name__=="__main__":
    sys.exit(EXIT_CODE)
