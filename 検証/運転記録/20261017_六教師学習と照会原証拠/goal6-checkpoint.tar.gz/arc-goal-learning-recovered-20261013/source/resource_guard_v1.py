"""Fresh explicit resource contract. No historic epoch or reservation authority."""
from pathlib import Path
import hashlib, json, os, stat
MiB = 1048576
ROOT = Path("/workspace/scratch/a94ff513b3af/arc-goal-learning-recovered-20261013")
BASE = ROOT.parent
CAPS = {"source":131072,"prep_tools":131072,"states":12*MiB,
        "journal":4*MiB,"reports":262144,"failure":2*MiB}
TOTAL = 20*MiB
PEER_DISK = 18*MiB
PHYSICAL_FLOOR = 1024*MiB
MEMORY_FLOOR = 2048*MiB
# Full slots: native owner, material worker, native auditor, controller/preparation.
RESERVED_RAM = (768+512+512+128)*MiB

def sha(b):
    return hashlib.sha256(b).hexdigest()

def safe(path):
    p = Path(path)
    if not p.is_absolute() or p != Path(os.path.abspath(p)):
        raise ValueError("absolute canonical path required")
    if p != ROOT and ROOT not in p.parents:
        raise PermissionError("outside fresh learning scope")
    q = p
    while q != BASE:
        if q.exists() or q.is_symlink():
            s = q.lstat()
            if stat.S_ISLNK(s.st_mode):
                raise PermissionError("symlink forbidden")
            if s.st_dev != BASE.stat().st_dev:
                raise PermissionError("device mismatch")
        q = q.parent
    return p

def usage():
    safe(ROOT)
    out = dict.fromkeys(CAPS, 0)
    if ROOT.exists():
        for p in ROOT.rglob("*"):
            safe(p)
            s = p.lstat()
            if stat.S_ISDIR(s.st_mode):
                continue
            if not stat.S_ISREG(s.st_mode) or s.st_nlink != 1:
                raise PermissionError("nonregular or hardlinked evidence")
            rel = p.relative_to(ROOT)
            if len(rel.parts) < 2 or rel.parts[0] not in CAPS:
                raise PermissionError("unclassified evidence")
            out[rel.parts[0]] += s.st_size
    for k, n in out.items():
        if n > CAPS[k]:
            raise MemoryError("category cap: " + k)
    return out

def guard(category=None, additional=0):
    if type(additional) is not int or additional < 0:
        raise ValueError("invalid admission size")
    u = usage()
    if category is not None and (category not in CAPS or u[category]+additional > CAPS[category]):
        raise MemoryError("prospective category cap")
    if category is None and additional:
        raise ValueError("category required")
    used = sum(u.values())
    if used+additional > TOTAL:
        raise MemoryError("total cap")
    fs = os.statvfs(BASE)
    free = fs.f_bavail*fs.f_frsize
    # Actual bytes already reduce physical free. Own unspent counted once.
    # Peer full 18 MiB is conservatively kept even after its writes.
    disk_need = PHYSICAL_FLOOR + TOTAL-used + PEER_DISK
    mem = {}
    for line in Path("/proc/meminfo").read_text().splitlines():
        a = line.split()
        if len(a) >= 2:
            mem[a[0].rstrip(":")] = int(a[1])*1024
    mem_need = MEMORY_FLOOR + RESERVED_RAM
    if free < disk_need or mem.get("MemAvailable", 0) < mem_need:
        raise MemoryError("physical or full reservation memory floor")
    return {"usage":u,"used":used,"free":free,"disk_required":disk_need,
            "MemAvailable":mem["MemAvailable"],"memory_required":mem_need,
            "own_unspent":TOTAL-used,"peer_disk_full":PEER_DISK}

def dirsync(p):
    fd = os.open(str(p), os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)

def mkdir(category):
    if category not in CAPS:
        raise ValueError("category")
    guard()
    p = safe(ROOT/category)
    p.mkdir(exist_ok=True)
    dirsync(ROOT)
    return p

def ref(p):
    p = safe(p)
    b = p.read_bytes()
    return {"path":str(p),"bytes":len(b),"sha256":sha(b)}

def write_new(category, name, data):
    if type(data) is not bytes or Path(name).name != name:
        raise TypeError("bytes and basename required")
    guard(category, len(data))
    parent = mkdir(category)
    p = safe(parent/name)
    fd = os.open(str(p), os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW, 0o600)
    try:
        with os.fdopen(fd,"wb") as f:
            if f.write(data) != len(data):
                raise OSError("short write")
            f.flush()
            os.fsync(f.fileno())
        dirsync(parent)
        if p.read_bytes() != data:
            raise OSError("full readback mismatch")
    except BaseException:
        # Partial output is never removed or overwritten.
        raise
    guard()
    return ref(p)

def file_ref(r, cap):
    if type(r) is not dict or set(r) != {"path","bytes","sha256"}:
        raise ValueError("exact FileRef required")
    if type(r["bytes"]) is not int or not 0 <= r["bytes"] <= cap:
        raise ValueError("FileRef size")
    p = Path(r["path"])
    if not p.is_absolute() or p.resolve() != p:
        raise PermissionError("immutable input path")
    q = p
    while q != q.parent:
        if q.is_symlink():
            raise PermissionError("input symlink")
        q = q.parent
    s = p.stat()
    if not stat.S_ISREG(s.st_mode) or s.st_size != r["bytes"]:
        raise ValueError("input size")
    b = p.read_bytes()
    if sha(b) != r["sha256"]:
        raise ValueError("input SHA")
    return b
