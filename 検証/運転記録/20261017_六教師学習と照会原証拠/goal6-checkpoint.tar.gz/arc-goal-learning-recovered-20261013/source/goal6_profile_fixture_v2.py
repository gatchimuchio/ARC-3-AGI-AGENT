"""Three synthetic calls of the exact AST-extracted invoke_one. No HDS imports."""
import ast, hashlib, importlib.util, json, signal, sys, time, traceback
from pathlib import Path
from types import SimpleNamespace
ROOT=Path("/workspace/scratch/a94ff513b3af/arc-goal-learning-recovered-20261013")
SOURCE={"path":str(ROOT/"source/goal6_teach_once_v2.py"),"bytes":32321,"sha256":"6396b07c0575e4d028474cecf836e0d11a3240037195522dea11adacefa5c999"}
GUARD={"path":str(ROOT/"source/resource_guard_v2.py"),"bytes":5181,"sha256":"9d4c2ec09e3768d3e2ce882efbe28a9f15a7a6c0b8f4ec721427427976fd6ab3"}
CORE=ROOT.parent/"arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統"
PINS=[{'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/排気系.py', 'bytes': 2779, 'sha256': '2ba7ceb8d0d6c784d092f91fe484477127f044e50f68c54c977374b17f2f6361'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/系統.py', 'bytes': 1951, 'sha256': 'f57e34fcab9249ad7fef72d7b9088fbb440c01afcd4313c9447b7a31427bd4a5'}]
OWNER={"modules":[],"cases":[],"result":None,"exception":None,"trace":None,"pending":None,"stage":"not_started"}

def checked(r):
    p=Path(r["path"]);b=p.read_bytes()
    if p.is_symlink() or p.resolve()!=p or len(b)!=r["bytes"] or hashlib.sha256(b).hexdigest()!=r["sha256"]:
        raise PermissionError("exact source pin")
    return b

def need(ok,message):
    if not ok:raise AssertionError(message)

def no_hds():
    need(not any(n=="hds学習系統" or n.startswith("hds学習系統.") for n in sys.modules),"HDS module absent")

def same(a,b):
    if type(a) is not type(b):return False
    if type(a) is dict:return len(a)==len(b) and all(ka==kb and same(a[ka],b[kb]) for ka,kb in zip(a,b))
    if type(a) is list:return len(a)==len(b) and all(same(x,y) for x,y in zip(a,b))
    return a==b

def deadline(*_):
    raise TimeoutError("profile pure fixture finite deadline")

class SyntheticExhaust:
    def __init__(self,fail):
        self.calls=0;self.inputs=[];self.failure=ValueError("synthetic exhaust failure") if fail else None
        self.return_value={"synthetic_return":[False,7],"claim":"not a native answer"}
    def 排出する(self,結果):
        self.calls+=1;self.inputs.append(結果)
        if self.failure is not None:raise self.failure
        return self.return_value

class SyntheticMachine:
    def __init__(self,fail):
        self.排気系=SyntheticExhaust(fail);self.calls=0;self.inputs=[]
        self.raw={"synthetic_raw":[True,False,7],"claim":"not HDS evidence"}
    def 処理する(self,external):
        self.calls+=1;self.inputs.append(external)
        return self.排気系.排出する(self.raw)

def snapshot(x):
    if type(x) in (str,int,bool,type(None)):return x
    if type(x) is list:return [snapshot(v) for v in x]
    if type(x) is dict:return {k:snapshot(v) for k,v in x.items()}
    if isinstance(x,BaseException):
        return {"exception_type":type(x).__name__,"repr":repr(x),"args_as_list":list(x.args),"args_type":"tuple",
                "trace":"".join(traceback.format_exception(type(x),x,x.__traceback__))}
    if type(x) in (SimpleNamespace,SyntheticMachine,SyntheticExhaust):
        return {"object_type":type(x).__name__,"all_fields":snapshot(vars(x))}
    raise TypeError("undeclared snapshot field type "+type(x).__name__)

def tests(g):
    no_hds()
    need(sys.getprofile() is None,"fixture starts without external profiler")
    source=checked(SOURCE).decode()
    tree=ast.parse(source)
    cls=[n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=="Owner"]
    need(len(cls)==1,"unique Owner AST")
    nodes=[n for n in cls[0].body if isinstance(n,ast.FunctionDef) and n.name=="invoke_one"]
    need(len(nodes)==1 and nodes[0].decorator_list==[],"unique unmodified method AST")
    method=nodes[0]
    environment={"sys":sys}
    exec(compile(ast.Module(body=[method],type_ignores=[]),SOURCE["path"],"exec"),environment)
    invoke=environment["invoke_one"];OWNER["method_environment"]=environment
    # Core is parsed only, never imported or called.
    trees={Path(r["path"]).name:ast.parse(checked(r).decode()) for r in PINS}
    exhaust=[n for n in trees["排気系.py"].body if isinstance(n,ast.ClassDef) and n.name=="最小排気系"][0]
    em=[n for n in exhaust.body if isinstance(n,ast.FunctionDef) and n.name=="排出する"][0]
    need([a.arg for a in em.args.args]==["self","結果"],"real exhaust argument contract")
    system=[n for n in trees["系統.py"].body if isinstance(n,ast.ClassDef) and n.name=="HDS学習系統"][0]
    sm=[n for n in system.body if isinstance(n,ast.FunctionDef) and n.name=="処理する"][0]
    calls=[ast.unparse(n.func) for n in ast.walk(sm) if isinstance(n,ast.Call)]
    need(calls==["self.吸気系.取り込む","self.エンジン.実行","self.排気系.排出する"],"static public Teach call chain")
    for mode in ("normal","exhaust_exception","existing_profile"):
        g.guard()
        machine=SyntheticMachine(mode=="exhaust_exception")
        owner=SimpleNamespace(machine=machine,raw_results=[],profile_events=[],profile_restorations=[],attempted=0)
        external={"synthetic_input":[True,False],"provenance":"fixture-only"}
        case={"mode":mode,"owner":owner,"external":external,"return":None,"exception":None,"checks":{}}
        OWNER["cases"].append(case);OWNER["pending"]=case
        original_exhaust=machine.排気系
        before=snapshot(external)
        sentinel=lambda frame,event,arg:None
        old=sys.getprofile()
        if mode=="existing_profile":sys.setprofile(sentinel)
        try:
            try:
                case["return"]=invoke(owner,external)
            except BaseException as exc:
                case["exception"]=exc
                case["trace"]=traceback.format_exc()
            case["profile_after_is_expected"]=sys.getprofile() is (sentinel if mode=="existing_profile" else old)
        finally:
            sys.setprofile(old)
        need(machine.排気系 is original_exhaust,"same exhaust instance")
        need(snapshot(external)==before,"external input unchanged")
        need(case["profile_after_is_expected"] and sys.getprofile() is old,"exact original profiler restoration")
        if mode=="normal":
            need(case["exception"] is None and case["return"] is machine.排気系.return_value,"same original return object")
        elif mode=="exhaust_exception":
            need(type(case["exception"]) is ValueError and case["exception"] is machine.排気系.failure and str(case["exception"])=="synthetic exhaust failure","exact original exception propagated")
        else:
            need(type(case["exception"]) is PermissionError and str(case["exception"])=="existing profile observer is not displaced","exact existing-profile rejection")
        expected=0 if mode=="existing_profile" else 1
        need(owner.attempted==machine.calls==machine.排気系.calls==expected,"one call or zero before rejection")
        need(len(owner.raw_results)==len(owner.profile_events)==len(owner.profile_restorations)==expected,"exact capture and restore counts")
        if expected:
            need(owner.raw_results[0] is machine.raw and machine.排気系.inputs[0] is machine.raw,"same raw object captured and forwarded")
            need(machine.inputs[0] is external,"same input forwarded")
            need(owner.profile_events[0]["exact_code_and_receiver"] is True,"exact code receiver evidence")
            need(owner.profile_restorations[0]=={"prior_was_none":True,"own_callback_at_exit":True,"restored_previous":True},"restoration full record")
        case["checks"]={"same_exhaust_instance":True,"input_unchanged":True,"expected_return_or_exception":True,
                        "exact_call_counts":True,"exact_capture_counts":True,"profile_preserved":True}
        OWNER["pending"]=None
    no_hds()
    result={"schema":"goal6-profile-pure-result-v1","status":"PASS","errors":[],
            "source":SOURCE,"core_static_refs":PINS,"method_source":ast.get_source_segment(source,method),
            "cases":snapshot(OWNER["cases"]),"case_count":3,"native_API":0,"material_reads":0,
            "limits":"Synthetic Python call observation only; no native restore, learning, or heap identity persistence proof."}
    OWNER["result"]=result
    return result

def run(gate_path,gate_sha):
    signal.signal(signal.SIGALRM,deadline);signal.alarm(120)
    g=None
    nonce=hashlib.sha256((str(gate_path)+str(gate_sha)).encode()).hexdigest()[:32]
    OWNER["gate_input"]={"path":str(gate_path),"sha256":str(gate_sha)}
    OWNER["failure_saved"]=False
    try:
        p=Path(gate_path);b=p.read_bytes()
        need(p.parent==ROOT/"reports" and not p.is_symlink() and len(b)<=16384 and hashlib.sha256(b).hexdigest()==gate_sha,"root gate")
        gate=json.loads(b);OWNER["root_gate"]=gate
        need(gate["schema"]=="goal6-profile-pure-release-v1" and gate["operation"]=="three_synthetic_profile_cases","pure release")
        nonce=gate["nonce"];need(type(nonce) is str and len(nonce)==32 and all(c in "0123456789abcdef" for c in nonce),"nonce")
        need(gate["AS"]==134217728 and gate["compute_seconds"]==120 and gate["save_seconds"]==120,"finite fixture contract")
        need(checked(gate["source"])==Path(__file__).read_bytes() and gate["source"]["path"]==str(Path(__file__)),"fixture source")
        need(gate["guard"]==GUARD,"fixed guard")
        checked(GUARD);spec=importlib.util.spec_from_file_location("goal6_profile_guard",GUARD["path"])
        g=importlib.util.module_from_spec(spec);OWNER["modules"].append(g);spec.loader.exec_module(g)
        g.guard();OWNER["stage"]="running"
        result=tests(g);result["nonce"]=nonce
        signal.alarm(120)
        raw=json.dumps(result,ensure_ascii=False,separators=(",",":")).encode()
        need(len(raw)<=65536,"full synthetic evidence64KiB")
        need(same(json.loads(raw),result),"full JSON type/value/order readback")
        receipt=g.write_new("journal","profile_fixture_"+nonce+".json",raw)
        need(g.file_ref(receipt,65536)==raw,"exact evidence readback")
        OWNER["receipt"]=receipt;OWNER["stage"]="complete";signal.alarm(0)
        print(json.dumps({"stage":"complete","receipt":receipt},ensure_ascii=False),flush=True)
    except BaseException as exc:
        signal.alarm(0);OWNER["exception"]=exc;OWNER["trace"]=traceback.format_exc();OWNER["stage"]="failed_held"
        print(OWNER["trace"],flush=True)
        try:
            signal.alarm(120)
            if g is None:
                checked(GUARD)
                spec=importlib.util.spec_from_file_location("goal6_profile_failure_guard",GUARD["path"])
                g=importlib.util.module_from_spec(spec);OWNER["modules"].append(g);spec.loader.exec_module(g)
            g.guard()
            failure={"schema":"goal6-profile-pure-failure-v1","nonce":nonce,"status":"FAIL",
                     "gate_input":OWNER["gate_input"],"root_gate":OWNER.get("root_gate"),"source":SOURCE,"guard":GUARD,"core_static_refs":PINS,
                     "error":snapshot(exc),"trace":OWNER["trace"],"cases":snapshot(OWNER["cases"]),
                     "pending":snapshot(OWNER["pending"]),"partial_result":snapshot(OWNER["result"]),
                     "prior_receipt":OWNER.get("receipt"),
                     "method_reconstruction":"Exact pinned Owner.invoke_one AST only; globals sys/builtins.",
                     "HDS_API":0,"material_reads":0}
            raw=json.dumps(failure,ensure_ascii=False,separators=(",",":")).encode()
            need(len(raw)<=65536 and same(json.loads(raw),failure),"full failure64KiB/type/order")
            OWNER["receipt"]=g.write_new("failure","profile_fixture_"+nonce+"_failure.json",raw)
            need(g.file_ref(OWNER["receipt"],65536)==raw,"full failure readback")
            OWNER["failure_saved"]=True
            print(json.dumps({"stage":"failed_held","receipt":OWNER["receipt"],"failure_saved":True},ensure_ascii=False),flush=True)
        except BaseException as secondary:
            OWNER["secondary"]=(secondary,traceback.format_exc())
            print(OWNER["secondary"][1],flush=True)
        finally:
            signal.alarm(0)
    while True:
        eligible=OWNER["stage"]=="complete" or (OWNER["stage"]=="failed_held" and OWNER["failure_saved"])
        if eligible:
            ackpath=ROOT/"reports"/("root_ack_profile_fixture_"+nonce+".json")
            if ackpath.exists():
                try:
                    need(not ackpath.is_symlink() and ackpath.stat().st_size<=8192,"root ACK bounds")
                    ack=json.loads(ackpath.read_bytes())
                    decision="ACK" if OWNER["stage"]=="complete" else "ACK_FAILURE"
                    need(ack["schema"]=="goal6-profile-pure-root-ack-v1" and ack["nonce"]==nonce
                         and ack["decision"]==decision and same(ack["receipt"],OWNER["receipt"]),"root exact ACK")
                    failed=OWNER["stage"]=="failed_held"
                    OWNER["stage"]="failed_closed_after_root_ack" if failed else "closed_after_root_ack"
                    return {"stage":OWNER["stage"],"receipt":OWNER["receipt"],
                            "errors":[snapshot(OWNER["exception"])] if failed else []}
                except BaseException as exc:
                    OWNER["ACK_exception"]=(exc,traceback.format_exc())
        time.sleep(5)
