"""Source-only candidate: single-owner fresh public Teach6, no query or restore."""
import hashlib, importlib.util, json, lzma, os, resource, signal, stat, sys, time, traceback
from pathlib import Path
ROOT = Path("/workspace/scratch/a94ff513b3af/arc-goal-learning-recovered-20261013")
REPO = ROOT.parent/"arc-recovery-main-20261013/repository"
HDS = REPO/"HDS/学習系統/v0.4.2"
FIELDS = ("不足対象は全て修復見込み","既充足対象は全て保存見込み","公開進捗が増加")
MATERIAL_BOUNDARY = "公開100対象・広域塗布・固定幾何上書き仮説と公開進捗"
BOUNDARY = "公開100対象・広域塗布・固定幾何上書き仮説の修復保全条件組と公開進捗"
SELECTION = ((0,65,66),(0,74,75),(0,92,93),(2,23,24),(2,60,61),(2,141,142))
MIB = 1048576
STATE_CAP = MIB
OWNER = None
DEPENDENCIES = [{'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/README.md', 'bytes': 622, 'sha256': 'fcb579bf30bf51a3d45d1935ba6c58c79baeef9c2c95df3c27046641e6f176d6'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/__init__.py', 'bytes': 527, 'sha256': 'eaed97760656afc40088ad7e0d85a02fbd59a0d0034054956e9ead63319fba57'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/台帳.py', 'bytes': 2815, 'sha256': 'a6cab8fca7cb591c42fa7444f9678fe0003da69faafcce852598286dceb522e2'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/吸気系.py', 'bytes': 3061, 'sha256': '50c48e5a9a8aa39158d0cdaacc0501608a829486960d41cb2fea6cb02e5660a4'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/型.py', 'bytes': 6575, 'sha256': 'aa1241708655280b36564f5e3ff6968849b4d09790b8932aabad1570cbca302c'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/実行系.py', 'bytes': 34178, 'sha256': '11d253705181873bcc22e312a0d0a2198fe16a82e3d7289ea8746fdc14695429'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/懐疑.py', 'bytes': 3392, 'sha256': 'bb7e85c2dbafbd430f1b7733bf3a2d307dc24e3227e79994b491cf711322f715'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/排気系.py', 'bytes': 2779, 'sha256': '2ba7ceb8d0d6c784d092f91fe484477127f044e50f68c54c977374b17f2f6361'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/推論.py', 'bytes': 11404, 'sha256': '315dd0d23a9682cdf14be71346341976cbdbcd2cbd924a250afc4ad53058dba6'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/検証.py', 'bytes': 2696, 'sha256': 'e23f271d38e1f52d75557dbf3342abf7b59a85fbdc315a06c0040fd7ca204eb3'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/永続化.py', 'bytes': 3125, 'sha256': '8aa431b3012424fd8347c5b3d93a5fbf2218d35020836f5d40abb427f9d6da0d'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/系統.py', 'bytes': 1951, 'sha256': 'f57e34fcab9249ad7fef72d7b9088fbb440c01afcd4313c9447b7a31427bd4a5'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/適応.py', 'bytes': 10139, 'sha256': 'c74797d49472646010ed0b37bd17dfa602084ba3347ac9386dec265e78a797ac'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/pyproject.toml', 'bytes': 173, 'sha256': 'c0d318c4a533f7ad7a2fe6f141cc44480a718def8c9794caf4a866e89b63961e'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/接続/配色内部/関係.py', 'bytes': 1224, 'sha256': '29860d6afbd34cef8a835fbc5b7fab815146e8f717f104a4e2b3983fa72d3349'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-authority-20261013/Owner指示書原文_20261009.md', 'bytes': 12787, 'sha256': 'd884388625d41e761ec845130c8ee3d7930992586973d461306b7d9b8218db9f'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-authority-20261013/Owner追加指示原文_20261010T1907.md', 'bytes': 778, 'sha256': '2cc8cbc8ab2ed802ab970ecce65b1942c92ee5db975f4f8deb6306f52766a576'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-authority-20261013/Owner追加指示原文_20261011T1904.md', 'bytes': 560, 'sha256': 'd24cfd49b3a45b92356e77af890d193a97f27f33acf81fd6e331ef8955b6634c'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/AGENTS.md', 'bytes': 1627, 'sha256': 'dff057d8f6ac88c688ec1d950640dc88b706d5ed9184119deda226d0109a8d42'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/運用/権限順序.md', 'bytes': 948, 'sha256': 'fdcef65a4b6ffc2179f76036f52aa2a4c47c69b8298f42678a47c245414bb4a3'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/制御/現在状態.json', 'bytes': 358, 'sha256': '0e4b29319d727896e244fe32f9726f0933f63fe007f59480272e76d46508c93c'}]
MATERIAL_CONTRACT = {'path': '/workspace/scratch/a94ff513b3af/arc-goal-teacher-recovered-20261013/source/goal6_contract_v2.json', 'bytes': 4294, 'sha256': 'ca43331b94cc30c9f4fb5c6a143f5c3c5cc5127591f3e7e90b1f465729ae3cf0'}

def eq(a,b):
    if type(a) is not type(b):
        return False
    if isinstance(a,dict):
        return len(a)==len(b) and all(eq(ka,kb) and eq(a[ka],b[kb]) for ka,kb in zip(a,b))
    if isinstance(a,(list,tuple)):
        return len(a)==len(b) and all(eq(x,y) for x,y in zip(a,b))
    return a==b

def sig(x):return json.dumps(x,separators=(',',':'),ensure_ascii=False)

def native_content(case):
    # Existing TURN compact JSON condition composition; no answer computation.
    teacher=case["teacher"]
    pair=[teacher[FIELDS[0]],teacher[FIELDS[1]]]
    if any(type(x) is not bool for x in pair) or type(teacher[FIELDS[2]]) is not bool:
        raise TypeError("strict measured booleans required")
    key=sig(pair)
    decoded=json.loads(key)
    if not eq(decoded,pair):
        raise ValueError("joint before key full type/order reversibility")
    return {"作用前の修復保全条件組":key,FIELDS[2]:teacher[FIELDS[2]]}

def timeout(signum,frame):
    raise TimeoutError("finite stage deadline exceeded")

def jbytes(x):
    return json.dumps(x,ensure_ascii=False,separators=(",",":")).encode()

class Owner:
    def __init__(self):
        self.stage="created"; self.module_refs=[]; self.machine=None
        self.inputs=[]; self.returns=[]; self.raw_results=[]; self.snapshots=[]; self.journals=[];
        self.profile_events=[]; self.profile_restorations=[];
        self.attempted=0; self.returned=0; self.completed=0
        self.primary_exception=None; self.failure_trace=None; self.secondary=[]
        self.pending=None; self.receipt=None; self.gate=None; self.material=None
        self.control_failure=None; self.last_admission=None

    def admit(self,category=None,n=0):
        self.last_admission=self.g.guard(category,n)
        return self.last_admission

    def read_json(self,r,cap=MIB):
        return json.loads(self.g.file_ref(r,cap))

    def preflight(self,gate_path,gate_sha):
        self.stage="preflight"
        p=Path(gate_path)
        if p.parent != ROOT/"reports" or p.is_symlink():
            raise PermissionError("root gate reports path required")
        raw=p.read_bytes()
        if len(raw)>65536 or hashlib.sha256(raw).hexdigest()!=gate_sha:
            raise PermissionError("root gate pin")
        self.gate=json.loads(raw)
        r=self.gate
        if r["schema"]!="goal6-native-release-v1" or r["operation"]!="fresh_Teach6_Query0":
            raise PermissionError("exact operation release required")
        if type(r["nonce"]) is not str or len(r["nonce"])!=32 or any(c not in "0123456789abcdef" for c in r["nonce"]):
            raise PermissionError("nonce")
        if r["limits"]!={"AS":768*MIB,"preflight_seconds":120,"teach_seconds":600,
                         "save_seconds":120,"failure_save_seconds":180}:
            raise PermissionError("fixed finite limits")
        if r["support"]!=3 or type(r["support"]) is not int or r["conditions"]!=2 or type(r["conditions"]) is not int:
            raise PermissionError("unchanged core settings")
        if r["boundary"]!=BOUNDARY or not eq(r["selection"],[list(x) for x in SELECTION]):
            raise PermissionError("ordered evidence selection")
        # Own all modules before their body executes.
        pins={x["path"]:x for x in DEPENDENCIES}
        for ref in DEPENDENCIES:
            data=Path(ref["path"]).read_bytes()
            if len(data)!=ref["bytes"] or hashlib.sha256(data).hexdigest()!=ref["sha256"]:
                raise PermissionError("fixed dependency pin: "+ref["path"])
        own=Path(__file__).read_bytes()
        if r["source"]["path"]!=str(Path(__file__)) or r["source"]["bytes"]!=len(own) or r["source"]["sha256"]!=hashlib.sha256(own).hexdigest():
            raise PermissionError("caller source pin")
        gp=r["guard"]
        if gp["path"]!=str(ROOT/"source/resource_guard_v2.py"):
            raise PermissionError("guard path")
        gb=Path(gp["path"]).read_bytes()
        if len(gb)!=gp["bytes"] or hashlib.sha256(gb).hexdigest()!=gp["sha256"]:
            raise PermissionError("guard pin")
        spec=importlib.util.spec_from_file_location("goal6_resource_guard",gp["path"])
        mod=importlib.util.module_from_spec(spec); self.module_refs.append(mod)
        spec.loader.exec_module(mod); self.g=mod
        self.admit()
        if r["contract"]["path"]!=str(ROOT/"source/goal6_contract_v2.json"):
            raise PermissionError("contract path")
        contract=self.read_json(r["contract"])
        if contract["schema"]!="goal6-single-owner-source-contract-v1" or not eq(contract["source"],r["source"]) or not eq(contract["guard"],r["guard"]) or not eq(contract["outer"],r["outer"]):
            raise PermissionError("contract schema/source bindings")
        self.g.file_ref(r["outer"],131072)
        self.g.file_ref(r["audit_source"],131072)
        if any(n=="hds学習系統" or n.startswith("hds学習系統.") for n in sys.modules):
            raise PermissionError("fresh HDS module required")
        sys.path.insert(0,str(HDS))
        import hds学習系統
        from hds学習系統.永続化 import _符号化,_復号
        self.module_refs.append(hds学習系統)
        self.hds=hds学習系統; self.enc=_符号化; self.dec=_復号
        for name,module in tuple(sys.modules.items()):
            if name=="hds学習系統" or name.startswith("hds学習系統."):
                if str(Path(module.__file__)) not in pins:
                    raise PermissionError("unexpected HDS dependency")
        self.validate_material(r["material_closure"])
        self.planned_intents=[]
        for index,case in enumerate(self.material["cases"]):
            external=self.hds.外部入力(内容=native_content(case),対象系境界=BOUNDARY)
            intent={"index":index,"source_material":self.gate["material_closure"]["material"],
                    "selection":case["selection"],"whole_measured_case":case,
                    "material_boundary":MATERIAL_BOUNDARY,"input":external}
            data=jbytes(self.enc(intent))
            if len(data)>524288:
                raise MemoryError("whole measured intent exceeds512KiB before Teach")
            self.planned_intents.append((external,intent,len(data)))
        self.admit("journal",sum(x[2] for x in self.planned_intents)+6*262144)
        self.machine=self.hds.HDS学習系統(最小支持数=3,最大条件数=2)
        # No saved model is loaded. Initial standard state proves fresh provenance.

    def validate_material(self,c):
        if type(c) is not dict or set(c)!={"material","producer_receipt","audit","producer_ACK","reader_ACK",
                "producer_closure","reader_closure","contract","producer_session","reader_session",
                "producer_command_sha256","reader_command_sha256"}:
            raise PermissionError("complete material closure gate required")
        if not eq(c["contract"],MATERIAL_CONTRACT):
            raise PermissionError("fixed measured material contract pin")
        amendment=self.read_json(c["contract"])
        mc=self.read_json(amendment["base_contract"])
        if mc["schema"]!="goal6-recovered-contract-v1" or amendment["schema"]!="goal6-recovered-contract-v1":
            raise PermissionError("material contract")
        known={Path(x["path"]).name:x for x in mc["source_refs"]}
        known["goal6_outer_v2.py"]=amendment["outer"]
        self.g.file_ref(amendment["outer"],131072)
        self.g.file_ref(amendment["full_diff"],131072)
        for rr in mc["source_refs"]+mc["dependency_refs"]+mc["authority_refs"]:
            self.g.file_ref(rr,131072)
        pr=self.read_json(c["producer_receipt"],16384)
        ar=self.read_json(c["audit"],16384)
        pa=self.read_json(c["producer_ACK"],16384)
        ra=self.read_json(c["reader_ACK"],16384)
        if pr["schema"]!="goal6-producer-receipt-v1" or pr["status"]!="complete" or pr["complete"] is not True or pr["errors"]!=[]:
            raise PermissionError("material producer incomplete")
        if not eq(pr["source"],known["goal6_producer_v1.py"]) or not eq(pr["outer"],known["goal6_outer_v2.py"]):
            raise PermissionError("producer source closure")
        if not eq(pr["packet"],c["material"]) or pr["case_count"]!=6 or pr["phase_count"]!=112 or pr["eligible_teacher_count"]!=6:
            raise PermissionError("all six eligible teachers required")
        flags={"all_six_cases","all_112_phases","all_12_original_rows","full_type_order",
               "before_only_two_conditions","all_100_targets_per_eligible_case",
               "independent_public_progress","all_unknowns_preserved","new_support_zero"}
        if ar["schema"]!="goal6-reader-receipt-v1" or ar["status"]!="PASS" or ar["complete"] is not True or ar["errors"]!=[]:
            raise PermissionError("independent material PASS required")
        if set(ar["verified"])!=flags or not all(v is True for v in ar["verified"].values()):
            raise PermissionError("all material independent comparisons")
        if not eq(ar["producer_receipt"],c["producer_receipt"]) or not eq(ar["material"],c["material"]) or not eq(ar["source"],known["goal6_reader_v1.py"]):
            raise PermissionError("independent material exact joins")
        for mode,ack,receipt,receipt_ref in (("producer",pa,pr,c["producer_receipt"]),("reader",ra,ar,c["audit"])):
            if ack["schema"]!="goal6-recovered-root-ack-v1" or ack["mode"]!=mode or ack["decision"]!="ACK" or ack["nonce"]!=receipt["nonce"] or not eq(ack["receipt"],receipt_ref):
                raise PermissionError("root material ACK exact join")
        if not eq(pa["independent_audit"],c["audit"]):
            raise PermissionError("producer ACK independent audit")
        self.material_admission_logs=[]
        for receipt in (pr,ar):
            log=self.read_json(receipt["admission_log"],131072)
            mode="producer" if receipt is pr else "reader"
            if log["schema"]!="goal6-admission-log-v1" or log["nonce"]!=receipt["nonce"] or log["mode"]!=mode or type(log["count"]) is not int or log["count"]!=len(log["records"]) or log["count"]!=receipt["admission_log_count"] or log["includes_final_receipt_and_log_admission"] is not True:
                raise PermissionError("durable complete material admission log")
            self.material_admission_logs.append(log)
        for mode,receipt,receipt_ref,ack_ref in (
            ("producer",pr,c["producer_receipt"],c["producer_ACK"]),
            ("reader",ar,c["audit"],c["reader_ACK"])):
            close=self.read_json(c[mode+"_closure"],65536)
            if close["schema"]!="goal6-material-closed-tools-v1" or close["mode"]!=mode or close["nonce"]!=receipt["nonce"]:
                raise PermissionError("material actual closure schema")
            for key,expected in (("source",receipt["source"]),("outer",receipt["outer"]),("gate",receipt["gate"]),
                                 ("receipt",receipt_ref),("ACK",ack_ref),("audit",c["audit"])):
                if not eq(close[key],expected):
                    raise PermissionError("material closure exact "+key)
            if type(c[mode+"_session"]) is not int or close["session_id"]!=c[mode+"_session"] or close["launch"]["session_id"]!=c[mode+"_session"]:
                raise PermissionError("material launch session")
            command=close["command"]
            if type(command) is not str or hashlib.sha256(command.encode()).hexdigest()!=c[mode+"_command_sha256"] or close["command_sha256"]!=c[mode+"_command_sha256"]:
                raise PermissionError("material full launch command")
            tool=close["actual_tool"]
            if close["actual_exit_observed"] is not True or type(tool["exit_code"]) is not int or tool["exit_code"]!=0 or type(tool["output"]) is not str:
                raise PermissionError("actual material exit0 required")
            gate=self.read_json(receipt["gate"],16384)
            if gate["nonce"]!=receipt["nonce"] or gate["mode"]!=mode or not eq(gate["source"],receipt["source"]) or not eq(gate["outer"],receipt["outer"]) or not eq(gate["contract"],c["contract"]):
                raise PermissionError("material originating release")
            if mode=="producer" and not eq(close["reader_closure"],c["reader_closure"]):
                raise PermissionError("reader actual closure required")
        r=c["material"]
        if set(r)!={"path","bytes","sha256","raw_bytes","raw_sha256"} or type(r["raw_bytes"]) is not int or not 0<=r["raw_bytes"]<=16*MIB:
            raise ValueError("material packet reference")
        blob=self.g.file_ref({k:r[k] for k in ("path","bytes","sha256")},4*MIB)
        self.material_blob=blob
        d=lzma.LZMADecompressor(format=lzma.FORMAT_XZ,memlimit=32*MIB)
        raw=d.decompress(blob,max_length=16*MIB+1); self.material_raw=raw
        if len(raw)!=r["raw_bytes"] or hashlib.sha256(raw).hexdigest()!=r["raw_sha256"] or not d.eof or d.unused_data or d.check!=lzma.CHECK_CRC64:
            raise ValueError("material CRC64 single EOF/raw full pin")
        encoded=json.loads(raw); self.material=self.dec(encoded)
        if not eq(self.enc(self.material),encoded) or jbytes(self.enc(self.material))!=raw:
            raise ValueError("full material typed order bytes roundtrip")
        m=self.material
        if m["schema"]!="goal6-measured-material-v1" or m["nonce"]!=pr["nonce"] or m["complete"] is not True or m["errors"]!=[]:
            raise PermissionError("whole measured material")
        if not eq(m["selection"],SELECTION) or type(m["cases"]) is not list or len(m["cases"])!=6:
            raise PermissionError("six original ordered actions")
        if type(m["HDS_API"]) is not int or m["HDS_API"]!=0 or type(m["new_independent_support"]) is not int or m["new_independent_support"]!=0:
            raise PermissionError("material is measurement, not prior learning")
        phase_total=0
        for i,case in enumerate(m["cases"]):
            if type(case["ordinal"]) is not int or case["ordinal"]!=i or not eq(case["selection"],SELECTION[i]):
                raise PermissionError("ordered case identity")
            if case["boundary"]!=MATERIAL_BOUNDARY or case["completed"] is not True or case["holds"]!=[] or case["pair_error"] is not None:
                raise PermissionError("unknown or invalid teacher HOLD")
            t=case["teacher"]; q=case["query_input"]
            if type(t) is not dict or tuple(t)!=FIELDS or any(type(v) is not bool for v in t.values()):
                raise TypeError("measured teacher three strict bools in original order")
            if type(q) is not dict or tuple(q)!=FIELDS[:2] or any(type(v) is not bool for v in q.values()) or not eq(q,{k:t[k] for k in FIELDS[:2]}):
                raise TypeError("before-only exact two bools")
            frozen=jbytes(self.enc((case["before_hypothesis"],q)))
            if hashlib.sha256(frozen).hexdigest()!=case["before_frozen_sha256"]:
                raise ValueError("saved before freeze exact pin")
            phase_total+=len(case["before_phases"])+len(case["after_phases"])
            native_content(case)
        if phase_total!=112 or m["all_phase_count"]!=112:
            raise ValueError("all phase evidence retained")
        self.material_closure_objects={"producer":pr,"audit":ar,"producer_ACK":pa,"reader_ACK":ra}
        # Values and expected progress are never guessed or filtered by equality.

    def save_typed(self,name,value,cap=262144):
        self.pending={"kind":"typed","name":name,"value":value}
        data=jbytes(self.enc(value))
        if len(data)>cap:
            raise MemoryError("full journal record cap")
        if not eq(self.dec(json.loads(data)),value):
            raise ValueError("typed journal roundtrip")
        ref=self.g.write_new("journal",name,data)
        self.journals.append(ref); self.pending=None
        return ref

    def standard(self,index,side,category="states"):
        self.stage="standard_"+side
        name=self.gate["nonce"]+"_"+str(index)+"_"+side+".json"
        self.admit(category,STATE_CAP)
        vm={}
        for line in Path("/proc/self/status").read_text().splitlines():
            a=line.split()
            if a and a[0] in ("VmSize:","VmRSS:"):
                vm[a[0]]=int(a[1])*1024
        if vm.get("VmSize:",768*MIB)+STATE_CAP*12+96*MIB>704*MIB or vm.get("VmRSS:",768*MIB)>640*MIB:
            raise MemoryError("standard serializer prospective workspace")
        folder=self.g.mkdir(category); p=self.g.safe(folder/name)
        fd=os.open(str(p),os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
        s=os.fstat(fd); os.close(fd); self.g.dirsync(folder)
        self.pending={"kind":"standard","path":str(p),"inode":s.st_ino,"side":side,"index":index}
        oldlimit=resource.getrlimit(resource.RLIMIT_FSIZE)
        oldhandler=signal.signal(signal.SIGXFSZ,lambda a,b: (_ for _ in ()).throw(OSError("standard raw 1 MiB file cap")))
        try:
            resource.setrlimit(resource.RLIMIT_FSIZE,(STATE_CAP,oldlimit[1]))
            # Unmodified public standard persistence, not a substitute serializer.
            self.machine.保存する(p)
        finally:
            resource.setrlimit(resource.RLIMIT_FSIZE,oldlimit)
            signal.signal(signal.SIGXFSZ,oldhandler)
        fd=os.open(str(p),os.O_RDONLY|os.O_NOFOLLOW)
        try:
            now=os.fstat(fd)
            if not stat.S_ISREG(now.st_mode) or now.st_ino!=s.st_ino or now.st_dev!=s.st_dev or now.st_size>STATE_CAP:
                raise OSError("reserved standard file identity/size")
            os.fsync(fd)
        finally:
            os.close(fd)
        self.g.dirsync(folder)
        raw=p.read_bytes()
        decoded=self.dec(json.loads(raw))
        expected={"形式版","最小支持数","最大条件数","識別子状態","台帳","状態履歴","原理履歴"}
        if set(decoded)!=expected or decoded["形式版"]!=3 or decoded["最小支持数"]!=3 or decoded["最大条件数"]!=2:
            raise ValueError("standard schema")
        if json.dumps(self.enc(decoded),ensure_ascii=False,indent=2).encode()!=raw:
            raise ValueError("full standard typed/order/byte roundtrip")
        count=index if side=="before" else index+1
        if category=="states" and decoded["識別子状態"].get("経験",0)!=count:
            raise ValueError("exact experience prefix count")
        if category=="states" and side=="before" and index==0:
            if decoded["識別子状態"]!={} or decoded["台帳"]!={} or decoded["原理履歴"]!={} or not eq(decoded["状態履歴"],({},)):
                raise ValueError("fresh initial whole standard required")
        if category=="states" and decoded["識別子状態"].get("照会",0)!=0:
            raise ValueError("Query0")
        if category=="states":
            experiences=decoded["台帳"].get("観測台帳",())
            if len(experiences)!=count:
                raise ValueError("whole experience ledger count")
            for k,exp in enumerate(experiences):
                if exp.対象系境界!=BOUNDARY or not eq(exp.原入力,native_content(self.material["cases"][k])):
                    raise ValueError("whole original teacher prefix")
        ref=self.g.ref(p)
        if category=="states" and side=="before" and index:
            prev=self.snapshots[-1]["after"]
            if ref["bytes"]!=prev["bytes"] or ref["sha256"]!=prev["sha256"]:
                raise ValueError("successive whole standard state changed between calls")
        self.pending=None
        return ref

    def invoke_one(self,external):
        previous=sys.getprofile()
        if previous is not None:
            raise PermissionError("existing profile observer is not displaced")
        target=self.machine.排気系.排出する
        code=target.__func__.__code__
        receiver=target.__self__
        start=len(self.raw_results)
        event_start=len(self.profile_events)
        def observe(frame,event,arg):
            if event=="call" and frame.f_code is code and frame.f_locals.get("self") is receiver:
                # Read only: same result object, no frame/local/value writes.
                result=frame.f_locals["結果"]
                self.raw_results.append(result)
                self.profile_events.append({"event":"call","filename":code.co_filename,
                    "firstlineno":code.co_firstlineno,"function":code.co_name,
                    "exact_code_and_receiver":True,"ordinal":len(self.raw_results)-1})
        sys.setprofile(observe)
        try:
            self.attempted+=1
            result=self.machine.処理する(external)
        finally:
            installed=sys.getprofile() is observe
            sys.setprofile(previous)
            self.profile_restorations.append({"prior_was_none":True,
                "own_callback_at_exit":installed,"restored_previous":sys.getprofile() is previous})
        if not installed or sys.getprofile() is not previous or len(self.raw_results)-start!=1 or len(self.profile_events)-event_start!=1:
            raise RuntimeError("exact one raw-result observation and profile restoration")
        return result

    def run(self):
        for index,case in enumerate(self.material["cases"]):
            # Stage deadlines are not extended after a failure.
            signal.alarm(120)
            before=self.standard(index,"before")
            self.snapshots.append({"index":index,"before":before})
            external,intent,_size=self.planned_intents[index]
            self.inputs.append(external)
            self.save_typed(self.gate["nonce"]+"_intent_"+str(index)+".json",intent,cap=524288)
            self.stage="Teach"; self.admit()
            signal.alarm(600)
            reply=self.invoke_one(external)
            self.returns.append(reply); self.returned+=1
            signal.alarm(120)
            if len(self.raw_results)!=self.returned:
                raise ValueError("exact raw result observation count")
            self.save_typed(self.gate["nonce"]+"_reply_"+str(index)+".json",
                            {"raw_execution_result":self.raw_results[-1],"external_reply":reply})
            after=self.standard(index,"after")
            self.snapshots[-1]["after"]=after
            self.completed+=1
            signal.alarm(0)
            # HOLD is a returned observation, not an exception and not rewritten.
        self.stage="complete"
        signal.alarm(120)
        value={"schema":"goal6-native-completion-v1","nonce":self.gate["nonce"],
               "status":"complete","errors":[],"Teach_attempted":self.attempted,
               "Teach_returned":self.returned,"Query_attempted":0,"completed":self.completed,
               "material_closure":self.gate["material_closure"],
               "source":self.gate["source"],"guard":self.gate["guard"],
               "snapshots":self.snapshots,"journals":self.journals,
               "profile_events":self.profile_events,"profile_restorations":self.profile_restorations,
               "new_independent_support":0,"standard_full_ledger_history":True}
        data=jbytes(value)
        if len(data)>65536:
            raise MemoryError("receipt cap")
        self.receipt=self.g.write_new("reports",self.gate["nonce"]+"_receipt.json",data)
        signal.alarm(0)
        print(json.dumps({"stage":self.stage,"receipt":self.receipt},ensure_ascii=False),flush=True)

    def fail(self,exc):
        signal.alarm(0)
        self.failure_pending=self.pending
        self.primary_exception=exc; self.failure_trace=traceback.format_exc()
        self.stage="failed_held"
        print(self.failure_trace,flush=True)
        try:
            signal.alarm(180)
            data=jbytes({"schema":"goal6-native-failure-v1","nonce":None if not self.gate else self.gate["nonce"],
                         "type":type(exc).__name__,"repr":repr(exc),"trace":self.failure_trace,
                         "attempted":self.attempted,"returned":self.returned,"completed":self.completed,
                         "snapshots":self.snapshots,"journals":self.journals,
                         "pending_path":self.pending.get("path") if isinstance(self.pending,dict) else None})
            self.g.write_new("failure","failure_"+(self.gate["nonce"] if self.gate else "preflight")+".json",data)
            if self.machine is not None:
                self.standard(self.completed,"failed_current","failure")
        except BaseException as secondary:
            self.secondary.append(secondary)
            print(traceback.format_exc(),flush=True)
        finally:
            signal.alarm(0)
            self.stage="failed_held"
        # Primary exception, frames, machine, raw returns and pending values remain owned.

    def hold(self):
        while True:
            if self.stage=="complete":
                p=ROOT/"reports"/("control_"+self.gate["nonce"]+".json")
                if p.exists():
                    try:
                        b=p.read_bytes()
                        if len(b)>65536:
                            raise ValueError("ACK read cap")
                        a=json.loads(b)
                        if a["command"]!="ack_close" or a["nonce"]!=self.gate["nonce"] or not eq(a["receipt"],self.receipt):
                            raise PermissionError("root ACK exact receipt")
                        audit=self.read_json(a["independent_audit"])
                        if audit["schema"]!="goal6-native-independent-completion-v1" or audit["nonce"]!=self.gate["nonce"] or audit["status"]!="PASS" or audit["errors"]!=[]:
                            raise PermissionError("independent audit PASS")
                        if not eq(audit["source"],self.gate["audit_source"]) or not eq(audit["receipt"],self.receipt) or not all(audit["verified"].get(k) is True for k in
                              ("all_six_original_teachers","all_before_after_standard_states","all_returns_ledgers_histories")):
                            raise PermissionError("independent full scope")
                        self.control_failure=None; self.stage="closed_after_root_ack"
                        return {"stage":self.stage,"receipt":self.receipt,"errors":[]}
                    except BaseException as exc:
                        self.control_failure=(exc,traceback.format_exc())
            time.sleep(5)

def main(gate_path,gate_sha):
    global OWNER
    OWNER=Owner()
    signal.signal(signal.SIGALRM,timeout)
    try:
        signal.alarm(120)
        OWNER.preflight(gate_path,gate_sha)
        signal.alarm(0)
        OWNER.run()
    except BaseException as exc:
        OWNER.fail(exc)
    return OWNER.hold()
