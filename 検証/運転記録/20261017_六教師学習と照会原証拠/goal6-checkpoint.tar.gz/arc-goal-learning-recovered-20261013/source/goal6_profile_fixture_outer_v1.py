import resource
resource.setrlimit(resource.RLIMIT_AS,(134217728,134217728))
import pathlib,hashlib,importlib.util,sys,time,traceback,json,datetime
MODULE=None
RETURN=None
ERRORS=[]
SOURCE={'path': '/workspace/scratch/a94ff513b3af/arc-goal-learning-recovered-20261013/source/goal6_profile_fixture_v1.py', 'bytes': 11198, 'sha256': '48b3c94dbabca334ea16f1209185d2cc1969eecb7e7db01e6795087826362c6c'}
if __name__=="__main__":
    try:
        raw=pathlib.Path(SOURCE["path"]).read_bytes()
        if len(raw)!=SOURCE["bytes"] or hashlib.sha256(raw).hexdigest()!=SOURCE["sha256"]:
            raise PermissionError("fixture exact source pin")
        spec=importlib.util.spec_from_file_location("goal6_profile_fixture",SOURCE["path"])
        MODULE=importlib.util.module_from_spec(spec)
        spec.loader.exec_module(MODULE)
        RETURN=MODULE.run(sys.argv[1],sys.argv[2])
        if RETURN.get("stage")!="closed_after_root_ack" or RETURN.get("errors")!=[]:
            raise RuntimeError("nonclosed fixture return retained")
        print(json.dumps(RETURN,ensure_ascii=False),flush=True)
        print("UTCEND "+datetime.datetime.now(datetime.timezone.utc).isoformat(),flush=True)
    except BaseException as exc:
        ERRORS.append((exc,traceback.format_exc()));print(ERRORS[-1][1],flush=True)
        while True:time.sleep(5)
