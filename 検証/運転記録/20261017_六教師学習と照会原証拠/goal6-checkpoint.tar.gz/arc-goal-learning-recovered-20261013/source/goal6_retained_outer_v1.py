"""Native execution requires a separate exact root gate. Source preparation imports nothing."""
import resource
resource.setrlimit(resource.RLIMIT_AS,(805306368,805306368))
import datetime, hashlib, importlib.util, json, sys, time, traceback
from pathlib import Path
MODULE=None
RETURN=None
ERRORS=[]
SOURCE={'path': '/workspace/scratch/a94ff513b3af/arc-goal-learning-recovered-20261013/source/goal6_teach_once_v1.py', 'bytes': 30061, 'sha256': '4a7dab3dc0ad6d6e599ef88f59237b76bd64cd4b783e083746bd423150adff82'}
if __name__=="__main__":
    print("UTCSTART "+datetime.datetime.now(datetime.timezone.utc).isoformat(),flush=True)
    try:
        raw=Path(SOURCE["path"]).read_bytes()
        if len(raw)!=SOURCE["bytes"] or hashlib.sha256(raw).hexdigest()!=SOURCE["sha256"]:
            raise PermissionError("exact native source pin")
        spec=importlib.util.spec_from_file_location("goal6_single_owner",SOURCE["path"])
        MODULE=importlib.util.module_from_spec(spec)
        spec.loader.exec_module(MODULE)
        RETURN=MODULE.main(sys.argv[1],sys.argv[2])
        if not isinstance(RETURN,dict) or RETURN.get("stage")!="closed_after_root_ack" or RETURN.get("errors")!=[] or not RETURN.get("receipt"):
            raise RuntimeError("nonclosed return retained")
        print(json.dumps(RETURN,ensure_ascii=False),flush=True)
        print("UTCEND "+datetime.datetime.now(datetime.timezone.utc).isoformat(),flush=True)
    except BaseException as exc:
        ERRORS.append((exc,traceback.format_exc()))
        print(ERRORS[-1][1],flush=True)
        while True:
            time.sleep(5)
