# Goal6 公開観測教師・学習 checkpoint

## 目的
ゲームのクリア目的から操作条件を整理し、公開観測の教師を通常 Learning Machine へ接続する。原票の再測定、固定測定仮説、HDS実学習、監査、閉鎖を区別して保存する。

## 観測と教師
元の0起算 source0 Action66/75/93（直前65/74/92）、source2 Action24/61/142（直前23/60/141）の6例。全12選択行の元UTF8 byte列、全metadata、全112応答相、各beforeの100対象、unknownと例外を素材packetへ保存した。
beforeのみの固定幾何上書き仮説「不足対象は全て修復見込み」「既充足対象は全て保存見込み」と、独立のafter公開進捗増加を分離。観測値は順に FF/F、FF/F、TF/F、FT/F、TT/T、TT/T。後結果による前提補完や成功例だけの選別はない。
幾何仮説は操作可能性や真の必要前提そのものではない。中間unknownから全期間の保全成立を主張しない。

## 学習・再現・閉鎖
既存TURNの可逆共同キー表現でbefore2boolを結合し、公開進捗の対応を通常HDSへ教示。新native再現 nonce 7fe7332cb9f2afcae9c1dd6c59e018c2 はTeach6、Query0。独立v3監査PASS、root ACK後の88376実exit0を保存した。
学習は1系譜3版、外部返答HOLD0、隔離0。原理版の支持は経験1–5までで、6件目の支持は候補証拠台帳側に保存される。原理版に支持6が追記されたとは読み替えない。
run2は同一6教材のfresh再現であり、新しい独立支持の加算は0。共同キーから結果への対応を学習したのであって、ANDの因果構造を獲得した証明ではない。

## previous / current / delta / regression
previousは復旧した公開原票・既存知覚・固定関係コード。currentは全6例の測定閉包と、同一教材で再現した通常Teach6の全state/journal/返答/採否/支持反証/履歴、および独立監査・閉鎖証拠。
deltaは目標修復・保全の固定測定条件と公開進捗を通常教師へ接続した運転記録。純fixture、素材独立監査、全標準state・台帳の独立監査は保存済み。件数増加を能力改善とは扱わない。

## 失敗と保持境界
旧v2独立audit FAILの全失敗記録を収録する。旧native29489は未閉鎖のまま、fixture18870は起動失敗後の保持状態であり、これらを成功・終了としない。旧nativeや失敗ownerへの操作は行っていない。
新しい成功再現で旧失敗を消さない。全scopeの旧版、差分、未実行草稿、失敗工具も収録し、runtime採用とは区別する。RAM内の原owner全heapをarchive化したとは主張しない。

## 限界
Query0、新規ゲームclear0、ゲーム間転用未検証、HDS core無変更。実環境での新しいAction実行や攻略達成は本checkpointの結果ではない。ID・row・hashは証拠参照であり解法選択条件ではない。

## 収録・参照・検証
M/L/A、回収repository subset、Owner原文3本とmanifest、公開原票回収manifestを全収録。原票3本全体は既配布 arc-recovery-20261013-evidence.tar.gz に保存済み（3920259B、SHA256 64199f3f35772f39f0849f254ac6f3a1c9e52807ea476dbf542c1ff39c571ed9）なので重複収録しない。今回の12選択原票は素材packetに全byte列を保持。
manifest.jsonは各原本の絶対path、archive member、byte数、SHA、regular type、device/inode/size/mode/mtime_ns/ctime_nsを保存する。atimeは読取自身で変わるため同一性条件から除外する。
tar.gz全memberを順番に読み戻し、名前・regular type・byte数・全bytes・SHAを原本と比較し、原本集合とidentity/hashを再確認する。これは可逆なbyte保存検証であり、新たな学習実行・意味監査の再実行ではない。
