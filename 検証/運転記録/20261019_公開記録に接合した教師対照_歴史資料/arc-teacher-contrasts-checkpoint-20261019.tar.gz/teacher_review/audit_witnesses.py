import ast,collections,hashlib,json,lzma,pathlib,resource,tarfile
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
B=pathlib.Path('/workspace/scratch/a94ff513b3af');R=B/'arc-teacher-contrasts-20261019';O=B/'arc-teacher-review-20261019'
def sha(x):return hashlib.sha256(x).hexdigest()
def read(p):return json.loads(p.read_bytes())
def dec(x):
 if isinstance(x,list):return [dec(v) for v in x]
 if isinstance(x,dict):
  if '__辞書__'in x:return {dec(k):dec(v) for k,v in x['__辞書__']}
  if '__組__'in x:return tuple(dec(v) for v in x['__組__'])
  return {k:dec(v) for k,v in x.items()}
 return x
report={};man=read(R/'MANIFEST.json');bad=[]
for x in man['files']:
 p=R/x['path'];b=p.read_bytes()
 if len(b)!=x['bytes'] or sha(b)!=x['sha256']:bad.append(x['path'])
assert not bad;report['manifest_verified_files']=len(man['files'])
p=next((R/'pinned').glob('*/producer/*'));packet=dec(json.loads(lzma.decompress(p.read_bytes())))
# Inspect and execute only pure, pinned AST declarations, never imports or native APIs.
groups={'接続/ARC3境界.py':('境界違反','_列','_整数','_盤面列'),'接続/図式観測.py':('成分群',),'接続/配色内部/知覚.py':('bbox','connected','read','classify'),'接続/配色内部/関係.py':('membership',)}
sources={}
with tarfile.open(B/'arc-preservation-recovery-20261019/archives/goal6-checkpoint.tar.gz','r|gz') as t:
 for m in t:
  for name in groups:
   if m.name.endswith('/repository/'+name):sources[name]=t.extractfile(m).read()
from typing import Any
env={'Counter':collections.Counter,'deque':collections.deque,'Any':Any,'Mapping':dict}
for name,names in groups.items():
 raw=sources[name];ref=next(x for x in packet['dependencies'] if x['path'].endswith(name));assert sha(raw)==ref['sha256']
 nodes=[x for x in ast.parse(raw).body if isinstance(x,(ast.FunctionDef,ast.ClassDef)) and x.name in names]
 assert tuple(x.name for x in nodes)==names
 exec(compile(ast.Module(body=nodes,type_ignores=[]),name+'::pure','exec'),env)
# Whole original corpus row-by-row comparisons, including byte offsets and closure hash.
closures=read(R/'source_closure_checks.json');checked=[]
with tarfile.open(B/'arc-preservation-recovery-20261019/remaining/arc-recovery-20261013-evidence.tar.gz','r|gz') as t:
 for m in t:
  cs=next((x for x in closures if x['archive_member']==m.name),None)
  if not cs:continue
  h=hashlib.sha256();offset=0;found=[]
  for i,line in enumerate(t.extractfile(m)):
   h.update(line)
   match=[(k,v) for k,v in packet['rows'].items() if k[1]==i and v['ref']['sha256']==sha(line)]
   for (si,ri),v in match:
    assert v['ref']['byte_offset']==offset and v['raw_utf8'].encode()==line
    assert (R/f'witnesses/source{si}_row{ri}.json').read_bytes()==line;found.append(ri)
   offset+=len(line)
  assert offset==cs['bytes'] and h.hexdigest()==cs['sha256'] and found==cs['all_selected_rows_byte_equal'];checked.append(found)
assert len(checked)==2
teachers=read(R/'goal6_teachers.runtime.json');queries=read(R/'goal6_matched_queries.runtime.json');counts=collections.Counter();cases=[]
for i,c in enumerate(packet['cases']):
 si,br,ar=c['selection'];before=packet['rows'][si,br]['data'];after=packet['rows'][si,ar]['data']
 for side,row in [('before',before),('after',after)]:
  assert len(row['frame'])==len(c[side+'_phases'])
  for frame,phase in zip(row['frame'],c[side+'_phases']):
   try:obs=env['read'](frame)
   except (ValueError,TypeError,KeyError,IndexError):assert phase['status']=='unknown';counts['unknown']+=1
   else:assert obs==phase['observation'] and phase['status']=='measured';counts['measured']+=1
 obs=env['read'](before['frame'][-1]);hyp=c['before_hypothesis'];repair=[];preserve=[]
 for y in range(10):
  for x in range(10):
   goal=obs['参照'][y][x];old=obs['対象'][y][x];mask=env['membership'](obs['方向'],x,y,10,'広域塗布');pred=obs['器具色'] if mask else old
   (preserve if old==goal else repair).append(pred==goal)
   q=hyp['targets'][y*10+x];assert q['geometry_candidate']==mask and q['predicted_color']==pred and q['goal']==goal and q['before_color']==old
 pair=[all(repair),all(preserve)];assert pair==[hyp['all_repair'],hyp['all_preserve']]
 outcome=after['score']>before['score'];assert teachers[i]['内容']=={'作用前の修復保全条件組':json.dumps(pair,separators=(',',':')),'公開進捗が増加':outcome}
 assert queries[i]['内容']=={'作用前の修復保全条件組':json.dumps(pair,separators=(',',':'))}
 intent=dec(read(sorted((R/'pinned').glob('arc-goal-learning*/journal/7fe*intent*'))[i]));assert intent['input']['値']==teachers[i]
 qi=dec(read(sorted((R/'pinned').glob('arc-goal-query*/journal/*intent*'))[i]));assert qi['input']['値']==queries[i]
 cases.append({'pair':pair,'score':[before['score'],after['score']],'outcome':outcome,'phases':[len(before['frame']),len(after['frame'])]})
assert counts=={'measured':35,'unknown':77};report['goal6']={'raw_source_closures_verified':checked,'phase_interpretations_recomputed':dict(counts),'cases':cases,'exact_historical_teachers_queries':True}
# Control: independently recompute precondition eligibility and teacher meanings from full public-derived goal sets.
pack=read(R/'control/goalset_teacher_pack_v2.json');env2={}
names=('exact','slots','skeleton','hit','decide','project');src=(R/'control/goalset_pack_v2.py').read_bytes();nodes=[x for x in ast.parse(src).body if isinstance(x,ast.FunctionDef) and x.name in names]
env2.update(X=pack['X'],Y=pack['Y']);exec(compile(ast.Module(body=nodes,type_ignores=[]),'control::pure','exec'),env2)
cv=read(R/'control_source_verification.json');refs={x['row']:x for x in cv['all59_rows']};eligible=[];phases=0
for r,ref in refs.items():
 b=(R/ref['file']).read_bytes();assert len(b)==ref['bytes'] and sha(b)==ref['sha256']
for c in pack['all58_before_decisions_and_observations']:
 n=c['row'];bef=read(R/refs[n-1]['file'])['data'];aft=read(R/refs[n]['file'])['data'];out=env2['project'](c['before'],c['after'])
 assert out['decision']==c['decision'] and out['teacher']==c['teacher']
 if out['teacher'] is not None:eligible.append(n)
 assert c['after']['metadata']=={k:v for k,v in aft.items() if k!='frame'} and c['after']['before_metadata']=={k:v for k,v in bef.items() if k!='frame'}
 assert sha(bytes(v for row in bef['frame'][-1] for v in row))==c['before']['phase']['画素SHA256']
 assert len(aft['frame'])==len(c['after']['phases'])
 for f,p in zip(aft['frame'],c['after']['phases']):assert sha(bytes(v for row in f for v in row))==p['reference']['画素SHA256'];phases+=1
assert eligible==[169,171,173,190]
# Verify entire public corpus again; all retained rows exactly join.
with tarfile.open(B/'ARC3_目標相対操作学習_20261013_v2.tar.gz','r|gz') as t:
 found=False
 for m in t:
  if not m.name.endswith('/public-recording-v2.jsonl'):continue
  found=True;h=hashlib.sha256();off=0
  for i,line in enumerate(t.extractfile(m)):
   h.update(line)
   if i in refs:assert line==(R/refs[i]['file']).read_bytes() and off==refs[i]['offset']
   off+=len(line)
  assert h.hexdigest()==cv['whole_original_sha256'] and off==cv['whole_original_bytes']
 assert found
statep=B/'arc-native-query-20261019/query_retry02/poststate.json';state=dec(read(statep));obs=[x['値'] for x in state['台帳']['観測台帳']];assert len(obs)==183
for i,t in enumerate(read(R/'existing_four_row_teachers.runtime.json')):
 old=next(x for x in obs if x['経験識別子']==f'経験-{130+i:06}');assert t['内容']==old['原入力'] and t['対象系境界']==old['対象系境界']
assert all(x['対象系境界']!=teachers[0]['対象系境界'] for x in obs)
report['control']={'raw_rows':len(refs),'all_decisions_recomputed':len(pack['all58_before_decisions_and_observations']),'eligible_rows':eligible,'after_phases_hashed':phases,'existing_experiences':[130,131,132,133]}
report['state']={'bytes':statep.stat().st_size,'sha256':sha(statep.read_bytes()),'experiences':len(obs),'goal6_exact_boundary_absent':True}
report['resources']={'AS_limit_bytes':512*1024**2,'max_RSS_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'native_calls':0,'SDK_calls':0,'Action_calls':0}
(O/'witness_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2))
