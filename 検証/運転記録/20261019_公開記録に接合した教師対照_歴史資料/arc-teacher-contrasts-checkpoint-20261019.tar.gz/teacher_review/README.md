# Independent witness / teacher-contract review

## Verdict

Bounded PASS for the prepared historical witness correspondence, exact payload provenance, and narrow teacher interpretation. This is NOT admission for native learning or runtime Action use. Native growth/evidence admission and an exact complete regression suite remain required before the proposed native learning experiment. No native/HDS import, restore, Query, processing/Teach, SDK, Action, or Git write was performed.

Reviewed Owner instructions (2026-10-09 and both additions), main/AGENTS.md, main/運用/権限順序.md, and main/制御/現在状態.json. HDS v0.4.2 remains fixed. Strategy is null and automatic transition false; this review does not change either.

## Independently checked

See `audit_witnesses.py` and successful `witness_audit.json` for reproducible checks. Execution had AS=512 MiB; peak RSS 86,580 KiB. Review output is far below 96 MiB. Source artifacts were read only; only this separate review directory was written.

- All 156 manifest-listed files matched their sizes and SHA256s.
- Streamed the two whole original Goal6 public-recording members, matched source closure hashes/sizes, exact row bytes/offsets, and all 12 retained raw rows.
- Read the archived pinned pure public perception and membership source. Executed only selected pure AST declarations, without imports or native code. Recomputed every one of the 112 frame interpretations: 35 measured, 77 unknown. Recomputed every cell's proposed geometry/overwrite and all six repair/preservation aggregates directly from publicly read before frames.
- Recomputed six public-score labels: FF=false, FF=false, TF=false, FT=false, TT=true, TT=true. Four non-progress/two progress. Exact teachers and matched queries equal all corresponding historical native intents.
- Streamed the whole control corpus and verified its exact hash/size and all 59 raw retained rows/offsets. Recomputed eligibility and outcome projection for every one of the 58 cases using its full preserved public-derived scene and candidate goal sets. Matched all before-terminal hashes and all 1,530 after-phase hashes/metadata/counts. Exactly rows169,171,173,190 qualify. All four teacher payloads exactly match experiences130–133 in current state.
- Current state has 183 observations; Goal6's exact learned boundary is absent. Static absence does not establish a native HOLD prediction. Its state hash is pinned in the JSON report.

## What the teachers mean

Control input asks whether the selected actual inventory token assigned to the actual unique empty clicked slot is compatible with at least one member of the entire existing feasible-goal set. Its output reports reduced empty-slot count and a nonempty feasible-goal set in the response's last phase. The same goal skeleton and unchanged public progress are checked. This is terminal-phase repair correspondence, not continuous preservation. Goal enumeration, scene grammar, and role interpretation remain existing prior, not newly learned HDS mechanisms. This audit independently recomputed projection/eligibility from those preserved public-derived sets; it did not rederive the complete control perception/enumeration algorithm from raw pixels.

Goal6 input is a JSON-string-encoded pair of universal predicates under a fixed half-plane geometry/overwrite hypothesis: every currently mismatched cell would match its public reference, and every currently matching cell would stay matching. The output is strictly public score after > public score before. Direction, color, reference/target rectangles and 100 cell roles are measurable public-frame material. Mask membership remains fixed prior; the reader's Action5→wide-paint role is also fixed classification. These are not learned by the six teachers. No hidden answer/state is required to recompute the bits or score labels. Generic content is justified only as this public-derived conditional endpoint correspondence within the explicitly named boundary.

Neither the bit pair nor the six observations proves actual mask correctness, universal causal necessity/sufficiency, prerequisite necessity, target/reference continuity, hidden-delta absence, or Action safety. All statuses remain NOT_FINISHED. The two positive endpoints change reference binding, and 77 phase interpretations remain unknown. Unknowns must stay unknown. Runtime fields omit IDs, hashes, paths, and replay selectors; provenance retains them separately. There is no new independent observation: zero. The six are the complete selected historical batch, not proof of exhaustiveness over all possible Action5 events or of minimum teaching-set size. Four truth-table combinations are covered, with duplicates preserved.

## Experiment and adoption gates

1. The matched six before/after queries are four unique training-condition strings. They can demonstrate current-descendant acquisition/retrieval of this exact projected endpoint mapping, not held-out generalization, new environment evidence, or learning of role/relation/mask semantics. Keep all six, including duplicates and native HOLD/negative replies.
2. Existing four-row queries are a narrow already-learned control. They are insufficient for complete regression across the nine existing boundaries or prior-success behavior. Pin and include the remaining exact existing-boundary/prior-success regression inputs before making a no-regression/adoption claim. The README recognizes this unfinished work.
3. Preserve every existing183 record/history prefix and explicitly account for all new support/refutation/applicability/history changes. Historical learning success in another state is not a current before/after result.
4. A bounded native serialization/growth/output budget covering all whole states, native replies, partial failure states, and reserve remains unresolved. Offline audit RSS and historical fresh-six growth are not admission bounds. Do not execute native teaching on this review alone.
5. Any future claim of cross-game/fresh-instance causal transfer requires separately authorized actual observations; renaming/surface variation of these inputs is diagnostic only.

Minor documentation inconsistency: `existing_four_row_control.json` retains its earlier status saying the raw source join was not yet located. The later README/full joins/control verification supersede that statement and raw joins were independently verified here. This is not a witness or label failure, but the stale status should not be cited as current.

The initial audit runner had a syntax typo and then a missing typing annotation environment; both failed before any native action and were corrected only in this review directory. The successful complete run is the result reported above.
