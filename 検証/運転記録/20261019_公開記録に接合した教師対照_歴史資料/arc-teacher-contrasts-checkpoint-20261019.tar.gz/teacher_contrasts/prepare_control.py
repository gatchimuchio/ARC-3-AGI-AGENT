import pathlib,json,tarfile,hashlib,resource
from inspect_state import decode
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2)); R=pathlib.Path(__file__).resolve().parent;B=R.parent
sha=lambda b:hashlib.sha256(b).hexdigest()
p=R/'control/goalset_teacher_pack_v2.json';pack=json.loads(p.read_bytes()); rows={};h=hashlib.sha256();offset=0
with tarfile.open(B/'ARC3_目標相対操作学習_20261013_v2.tar.gz','r|gz') as t:
 for m in t:
  if m.name.endswith('/public-recording-v2.jsonl'):
   for i,line in enumerate(t.extractfile(m)):
    h.update(line)
    if 167<=i<=225:
     q=R/'control'/f'raw_row{i}.json';q.write_bytes(line);rows[i]={'row':i,'offset':offset,'bytes':len(line),'sha256':sha(line),'file':str(q.relative_to(R))}
    offset+=len(line)
assert len(rows)==59 and offset==pack['original_recording']['bytes'] and h.hexdigest()==pack['original_recording']['sha256']
def put(n,x):(R/n).write_text(json.dumps(x,ensure_ascii=False,indent=2))
state=decode(json.loads((B/'arc-native-query-20261019/query_retry02/poststate.json').read_bytes()));obs={x['値']['経験識別子']:x['値'] for x in state['台帳']['観測台帳']}
joins=[]; runtime=[]
for i,t in enumerate(pack['teachers']):
 case=pack['all58_before_decisions_and_observations'][t['evidence']['case_index']];assert case['row']==t['row']
 old=obs[f'経験-{130+i:06}'];assert t['teacher']==old['原入力'] and t['boundary']==old['対象系境界']
 before=json.loads((R/rows[t['row']-1]['file']).read_bytes())['data'];after=json.loads((R/rows[t['row']]['file']).read_bytes())['data']
 assert len(after['frame'])==t['evidence']['all_after_phases']
 runtime.append({'内容':t['teacher'],'対象系境界':t['boundary'],'主体':None,'対象':None,'目的':None,'文脈':{}})
 joins.append({'teacher':t,'existing_experience':old['経験識別子'],'before_raw':rows[t['row']-1],'after_raw':rows[t['row']],'before_phase_count':len(before['frame']),'after_phase_count':len(after['frame']),'all_case_fields':case,'before_metadata':{k:v for k,v in before.items() if k!='frame'},'after_metadata':{k:v for k,v in after.items() if k!='frame'},'hidden_delta':'unknown','reward':'not exposed except public score','new_independent_evidence':False})
put('existing_four_row_teachers.runtime.json',runtime);put('existing_four_row_full_witness_joins.json',joins)
put('control_source_verification.json',{'whole_original_bytes':offset,'whole_original_sha256':h.hexdigest(),'all59_rows':list(rows.values()),'rows_bytes':sum(x['bytes'] for x in rows.values()),'retained_all58_decisions':True,'teachers_exactly_match_current_experiences':[130,131,132,133],'RSS_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss})
print('control joins verified',sum(x['bytes'] for x in rows.values()),[(x['teacher']['row'],x['before_phase_count'],x['after_phase_count']) for x in joins])
phase_total=0
for case in pack['all58_before_decisions_and_observations']:
 n=case['row'];before=json.loads((R/rows[n-1]['file']).read_bytes())['data'];after=json.loads((R/rows[n]['file']).read_bytes())['data']
 assert case['after']['metadata']=={k:v for k,v in after.items() if k!='frame'}
 assert case['after']['before_metadata']=={k:v for k,v in before.items() if k!='frame'}
 assert len(after['frame'])==len(case['after']['phases'])
 assert sha(bytes(x for row in before['frame'][-1] for x in row))==case['before']['phase']['画素SHA256']
 for phase,frame in zip(case['after']['phases'],after['frame']):assert sha(bytes(x for row in frame for x in row))==phase['reference']['画素SHA256'];phase_total+=1
put('control_all58_phase_join_verification.json',{'all58_metadata_and_last_before_phase_hashes_match':True,'all_after_phase_count':phase_total,'all_after_phase_hashes_match':True,'new_independent_evidence':0})
