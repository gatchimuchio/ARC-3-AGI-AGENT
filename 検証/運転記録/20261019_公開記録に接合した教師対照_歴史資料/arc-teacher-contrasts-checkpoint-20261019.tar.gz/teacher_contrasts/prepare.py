import json,pathlib,lzma,tarfile,hashlib,resource,collections
from inspect_state import decode
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
R=pathlib.Path(__file__).resolve().parent; B=R.parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(n,x):
 p=R/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2))
p=next((R/'pinned').glob('*/producer/*')); packet=decode(json.loads(lzma.decompress(p.read_bytes())))
rows=packet['rows']; closures={pathlib.Path(x['source']['path']).name:x for x in packet['source_closures']}; checks=[]
with tarfile.open(B/'arc-preservation-recovery-20261019/remaining/arc-recovery-20261013-evidence.tar.gz','r|gz') as t:
 for m in t:
  name=pathlib.Path(m.name).name
  if name not in closures:continue
  c=closures[name]; si=c['source_index']; f=t.extractfile(m);h=hashlib.sha256();offset=0;selected=[]
  for i,line in enumerate(f):
   h.update(line)
   if (si,i) in rows:
    original=rows[(si,i)];assert original['raw_utf8'].encode()==line;assert original['ref']['sha256']==sha(line);assert original['ref']['byte_offset']==offset
    q=R/'witnesses'/f'source{si}_row{i}.json';q.parent.mkdir(exist_ok=True);q.write_bytes(line); selected.append(i)
   offset+=len(line)
  assert offset==c['source']['bytes'] and h.hexdigest()==c['source']['sha256']
  checks.append({'archive_member':m.name,'bytes':offset,'sha256':h.hexdigest(),'all_selected_rows_byte_equal':selected})
assert len(checks)==2
statepath=B/'arc-native-query-20261019/query_retry02/poststate.json'; state=decode(json.loads(statepath.read_bytes()))
observations=[x['値'] for x in state['台帳']['観測台帳']]; principles=[x['値'] for x in state['台帳']['原理台帳']]
# Exact historical inputs, not reinvented encodings or boundary spellings.
intents=sorted((R/'pinned').glob('arc-goal-learning*/journal/7fe*intent*'))
print('intentkeys',decode(json.loads(intents[0].read_bytes())).keys())
for k,v in decode(json.loads(intents[0].read_bytes())).items():
 if k!='whole_measured_case':print(k,str(v)[:700])
put('source_closure_checks.json',checks)
put('state_boundary_inventory.json',{'state_bytes':statepath.stat().st_size,'state_sha256':sha(statepath.read_bytes()),'counters':state['識別子状態'],'boundaries':dict(collections.Counter(x['対象系境界'] for x in observations)),'principles':principles})
put('existing_four_row_control.json',{'status':'existing learned payloads; raw source join not yet located, not admitted teachers','experiences':[x for x in observations if x['経験識別子'] in ['経験-000130','経験-000131','経験-000132','経験-000133']]})
put('goal6_case_summary.json',[{k:c[k] for k in ['ordinal','selection','teacher','query_input','boundary','public_progress','holds','before_row_ref','after_row_ref','after_bindings']} for c in packet['cases']])
print('resource',resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
teachers=[];queries=[];joins=[]
for i,c in enumerate(packet['cases']):
 intent=decode(json.loads(intents[i].read_bytes())); inp=intent['input']['値']; assert intent['selection']==c['selection']
 teachers.append(inp)
 q=dict(inp);q['内容']={k:v for k,v in inp['内容'].items() if k!='公開進捗が増加'};queries.append(q)
 assert not any(o['対象系境界']==inp['対象系境界'] for o in observations)
 si,br,ar=c['selection'];before=rows[(si,br)]['data'];after=rows[(si,ar)]['data']; prev=before['frame'][-1];deltas=[]
 for phase,frame in enumerate(after['frame']):
  changes=[[x,y,a,b] for y,(r1,r2) in enumerate(zip(prev,frame)) for x,(a,b) in enumerate(zip(r1,r2)) if a!=b]
  deltas.append({'phase':phase,'changed_pixel_count':len(changes),'pixel_changes':changes});prev=frame
 put(f'witnesses/case{i}_all_phase_pixel_deltas.json',deltas)
 joins.append({'teacher_ordinal':i,'historical_intent':str(intents[i].relative_to(R)),'selection':c['selection'],'before_row':c['before_row_ref'],'after_row':c['after_row_ref'],'raw_before':f'witnesses/source{si}_row{br}.json','raw_after':f'witnesses/source{si}_row{ar}.json','before_phases':len(before['frame']),'after_phases':len(after['frame']),'action':c['original_action'],'coordinates':c['original_action'].get('data',{}).get('x'),'coordinate_note':'Action5 has no x/y; targets are all100 cells enumerated in pinned material before_hypothesis.targets','role':'広域塗布','goal_and_preconditions':c['before_hypothesis'],'public_progress':c['public_progress'],'public_metadata_before':c['before_metadata'],'public_metadata_after':c['after_metadata'],'reward':'not exposed separately; score only','hidden_delta':'unknown','success_failure':'endpoint public progress only; no game WIN or GAME_OVER in these six pairs','holds':c['holds'],'phase_bindings':c['after_bindings'],'already_in_current183':False,'historically_learned':True,'new_independent_support':0})
put('goal6_teachers.runtime.json',teachers);put('goal6_matched_queries.runtime.json',queries);put('goal6_full_witness_joins.json',joins)
# Existing control uses exact current learned boundary and leaves answers out of Query.
control=[o for o in observations if o['経験識別子'] in ['経験-000130','経験-000131','経験-000132','経験-000133']]
put('existing_four_row_queries.runtime.json',[{'内容':{k:v for k,v in o['原入力'].items() if k=='実対象割当と整合する成立可能目標がある'},'対象系境界':o['対象系境界'],'主体':None,'対象':None,'目的':None,'文脈':{}} for o in control])
put('runtime_payload_sizes.json',{n:{'bytes':(R/n).stat().st_size,'sha256':sha((R/n).read_bytes())} for n in ['goal6_teachers.runtime.json','goal6_matched_queries.runtime.json','existing_four_row_queries.runtime.json']})
# Keep historical negative learning/HOLD replies and exact native Query evidence clearly separate.
history=[]
for p in sorted((R/'pinned').glob('arc-goal-learning*/journal/7fe*reply*')):
 x=decode(json.loads(p.read_bytes()));history.append({'file':str(p.relative_to(R)),'external_reply':x['external_reply']})
put('historical_learning_replies.json',history)
put('preparation_resources.json',{'AS_limit_bytes':512*1024**2,'disk_limit_bytes':96*1024**2,'max_rss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'directory_bytes_before_this_report':sum(p.stat().st_size for p in R.rglob('*') if p.is_file()),'native_calls':0,'SDK_calls':0,'Action_calls':0,'teaching_admission':'blocked pending native growth bound/profile; offline RSS not a native growth bound'})
