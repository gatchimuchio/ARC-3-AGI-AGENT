import json,lzma,pathlib,hashlib,collections,resource
from inspect_state import decode
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2));R=pathlib.Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(n,x):(R/n).write_text(json.dumps(x,ensure_ascii=False,indent=2))
p=next((R/'pinned').glob('*/producer/*'));packet=decode(json.loads(lzma.decompress(p.read_bytes())))
queries=json.loads((R/'goal6_matched_queries.runtime.json').read_bytes())
for p in (R/'pinned').glob('arc-goal-query*/journal/*intent*'):
 x=decode(json.loads(p.read_bytes()));assert x['input']['値']==queries[x['index']]
unknowns=[]
for c in packet['cases']:
 unknowns.append({'case':c['ordinal'],'before':dict(collections.Counter(p['status'] for p in c['before_phases'])),'after':dict(collections.Counter(p['status'] for p in c['after_phases'])),'unknown_phase_details':[{'side':side,**p} for side in ['before_phases','after_phases'] for p in c[side] if p['status']!='measured']})
put('all_phase_unknowns.json',unknowns)
replies=[]
for p in sorted((R/'pinned').glob('arc-goal-query*/journal/*reply*')):
 x=decode(json.loads(p.read_bytes()));replies.append({'file':str(p.relative_to(R)), 'reply':x})
put('historical_queries.json',replies)
files=[{'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(R.rglob('*')) if p.is_file() and p.name!='MANIFEST.json' and '__pycache__' not in str(p)]
put('MANIFEST.json',{'scope':'new offline preparation evidence, not replacement historical358669B analysis','files':files,'total_payload_bytes':sum(x['bytes'] for x in files)})
print('unknown counts',[(x['case'],x['before'],x['after']) for x in unknowns]);print('bytes',sum(x['bytes'] for x in files))
