import pathlib,json,tarfile,lzma,hashlib,resource
from inspect_state import decode
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
R=pathlib.Path(__file__).resolve().parent;B=R.parent;OUT=R/'regression_v2';OUT.mkdir(exist_ok=True)
archives=['ARC3_目標相対操作学習_20261013_v2.tar.gz','ARC3_goalset4_learning_checkpoint_20261013.tar.gz','preparation_preservation_learning_checkpoint.tar.gz']
assert hashlib.sha256((B/archives[-1]).read_bytes()).hexdigest()=='272110bf92783dc1ea191a6efd65baabd32d22626bec3a86c6653ec14544bfb8'
selected={}; inventory=[]
for name in archives:
 with tarfile.open(B/name,'r|gz') as t:
  for m in t:
   if not m.isfile() or not ('intent' in m.name and m.name.endswith(('.json.xz','.json'))):continue
   if m.size>150000:continue
   raw=t.extractfile(m).read()
   try:x=decode(json.loads(lzma.decompress(raw) if m.name.endswith('.xz') else raw))
   except (ValueError,lzma.LZMAError):continue
   if x.get('method')!='照会する':continue
   inp=x.get('input',{}); inp=inp.get('値',inp)
   if not isinstance(inp,dict) or '対象系境界' not in inp:continue
   boundary=inp['対象系境界']; entry={'archive':name,'member':m.name,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'input':inp,'phase':x.get('phase'),'frame_ordinal':x.get('frame_ordinal'),'origin':x.get('origin'),'before':x.get('before')}
   inventory.append(entry)
   # Prefer complete learned-state regression phase, preserving historical exact input.
   rank=(('regression' in str(x.get('phase'))),x.get('before',{}).get('identifiers',{}).get('経験',0))
   if boundary not in selected or rank>selected[boundary][0]:selected[boundary]=(rank,entry,raw)
print('boundaries',len(selected))
for k,(r,e,raw) in selected.items():print(k,e['archive'],e['member'],e['phase'],e['input']['内容'])
(OUT/'query_inventory.json').write_text(json.dumps(inventory,ensure_ascii=False,indent=2))
(OUT/'selected_preliminary.json').write_text(json.dumps([x[1] for x in selected.values()],ensure_ascii=False,indent=2))
for i,(rank,e,raw) in enumerate(selected.values()): (OUT/f'intent_{i}.json.xz').write_bytes(raw)
