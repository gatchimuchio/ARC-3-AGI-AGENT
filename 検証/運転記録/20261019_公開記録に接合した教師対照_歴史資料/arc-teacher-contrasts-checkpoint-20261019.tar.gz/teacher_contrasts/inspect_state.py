import json,pathlib,collections
ROOT=pathlib.Path(__file__).resolve().parent
def decode(x):
 if isinstance(x,list):return [decode(v) for v in x]
 if isinstance(x,dict):
  if '__辞書__' in x:return {decode(k):decode(v) for k,v in x['__辞書__']}
  if '__組__' in x:return tuple(decode(v) for v in x['__組__'])
  return {k:decode(v) for k,v in x.items()}
 return x
if __name__=='__main__':
 s=decode(json.loads((ROOT.parent/'arc-native-query-20261019/query_retry02/poststate.json').read_bytes()))
 print(s.keys());print(s['台帳'].keys())
 obs=s['台帳']['観測台帳']; print(collections.Counter(x['値']['対象系境界'] for x in obs))
 for k in ['観測台帳','原理台帳']:
  for x in s['台帳'][k]:
   v=x['値']
   if any(z in str(v.get('対象系境界')) for z in ['保全','修復','準備','保存']):print(k, str(v)[:2800])
