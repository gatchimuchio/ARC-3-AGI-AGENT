import resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
import ast,json,hashlib,signal,os,time,traceback,itertools,shutil
from pathlib import Path
from collections import Counter
B=Path('/workspace/scratch/a94ff513b3af')
D=B/'arc-column-phase-audit-20261013'
S=B/'arc-current-family-source-20261013'
R=B/'arc-column-teacher-recovery-20261013/public-recording-v2.jsonl'
DIGEST='e26ff1df251af042911126a067c08ee25973b01d3389269472eed6859a4383f2'
def timeout(*a): raise TimeoutError('fixed phase audit deadline')
signal.signal(signal.SIGALRM,timeout);signal.alarm(600)
def guard(n=0):
    used=sum(p.stat().st_size for p in D.rglob('*') if p.is_file())
    if used+n>16*1024**2: raise MemoryError('scope cap')
    if shutil.disk_usage(D).free < (916+1024)*1024**2+n: raise MemoryError('disk full future and floor')
    mem=int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024
    if mem < (2048+512)*1024**2: raise MemoryError('available memory floor plus ownAS')
def digestfile(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for x in iter(lambda:f.read(1048576),b''): h.update(x)
    return {'path':str(p),'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def save(p,obj,cap):
    raw=json.dumps(obj,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()
    if len(raw)>cap:raise MemoryError('complete output exceeds cap: '+str(len(raw)))
    guard(len(raw))
    with p.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
    fd=os.open(p.parent,os.O_RDONLY);os.fsync(fd);os.close(fd)
    if p.read_bytes()!=raw:raise ValueError('readback mismatch')
    return digestfile(p)
def typed(x):return (type(x).__name__,tuple((typed(k),typed(v)) for k,v in x.items()) if isinstance(x,dict) else tuple(typed(v) for v in x) if isinstance(x,(list,tuple)) else x)
def eq(a,b):return typed(a)==typed(b)
def structure(scene):
    return {'背景色':scene['背景色'],'目標列':scene['目標列'],'容器群':[{'色':b['色'],'位置':b['位置'],'起点':b['起点'],'枠位置':[s['位置'] for s in b['枠群']]} for b in scene['容器群']]}
def run():
    guard();rawref=digestfile(R);assert rawref['sha256']==DIGEST
    manifest=json.loads((S/'manifest.json').read_text());sources=[];ns={'Counter':Counter,'itertools':itertools}
    specs=[('接続/図式観測.py',{'_作用番号'}),('接続/列図式規則.py',{'知覚不適用','記号を読む','容器外形を観測する','図式を観測する','列を生成する','一致する','選択を読む'}),('道具/列図式教師検証.py',{'完了数','同一実行','記号記録','遷移作用を測る'})]
    for path,names in specs:
        p=S/path;ref=digestfile(p);entry=next(x for x in manifest['files'] if x['path']==path)
        assert ref['sha256']==entry['sha256'];sources.append(ref)
        tree=ast.parse(p.read_text());nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in names]
        assert {n.name for n in nodes}==names
        exec(compile(ast.Module(body=nodes,type_ignores=[]),str(p),'exec'),ns)
    rows=[];events=[];completed={};last=None;offset=0;selected=set(range(60))|set(range(225,257))
    with R.open('rb') as f:
        for i,line in enumerate(f):
            start=offset;offset+=len(line)
            if i not in selected:continue
            guard();env=json.loads(line);row=env.get('data',env);frames=row['frame'];phase=[]
            for j,frame in enumerate(frames):
                item={'phase':j,'json_path':['data','frame',j],'frame_sha256_uint8':hashlib.sha256(bytes(v for r in frame for v in r)).hexdigest()}
                try:
                    sc=ns['図式を観測する'](frame);item['scene']=sc
                    try:item['selection']=ns['選択を読む'](frame,sc)
                    except ValueError as e:item['selection_unknown']=str(e)
                except ValueError as e:item['unknown']={'type':type(e).__name__,'message':str(e)}
                phase.append(item)
            meta={k:v for k,v in row.items() if k!='frame'}
            rr={'row':i,'byte_offset':start,'line_bytes':len(line),'line_sha256':hashlib.sha256(line).hexdigest(),'metadata':meta,'phases':phase}
            rows.append(rr)
            if i in (12,43,59,256):completed[i]=phase[0]
            if last is not None and last[0]==i-1:
                prev,prior=last[1],last[2];same=ns['同一実行'](prev,row);advanced=ns['完了数'](row)>ns['完了数'](prev)
                ev={'row':i,'before_row':i-1,'same_instance':same,'full_reset':row.get('full_reset'),'advanced':advanced,'before_terminal_phase':len(prev['frame'])-1,'after_phase_count':len(frames),'action':row.get('action_input')}
                if same and not row.get('full_reset') and row.get('action_input'):
                    ev['terminal_measurement']=ns['遷移作用を測る'](prev['frame'][-1],frames[-1],row['action_input'],advanced)
                    ev['per_phase_measurements']=[ns['遷移作用を測る'](prev['frame'][-1],fr,row['action_input'],False) for fr in frames]
                    pre=prior['phases'][-1]
                    ev['structural_comparison']=[{'phase':k,'known':('scene'in pre and 'scene'in p),'same_goal_and_containers':eq(structure(pre['scene']),structure(p['scene'])) if 'scene'in pre and 'scene'in p else None,'same_complete_scene':eq(pre['scene'],p['scene']) if 'scene'in pre and 'scene'in p else None} for k,p in enumerate(phase)]
                events.append(ev)
            last=(i,row,rr)
    assert len(rows)==92
    semantics=[dict(zip((False,True),ops)) for ops in itertools.product(('出力','参照'),repeat=2)]
    role_trials=[]
    for roles in semantics:
        values=[]
        for i,p in completed.items():values.append({'row':i,'match':ns['一致する'](p['scene'],roles) if 'scene'in p else None})
        role_trials.append({'roles':[{'hollow':k,'role':v} for k,v in roles.items()],'completed':values})
    compatible=[r for r in semantics if all('scene'in p and ns['一致する'](p['scene'],r)[0] for p in completed.values())]
    assert len(compatible)==1
    roles=compatible[0];submit_ids={ns['_作用番号'](next(r['metadata'] for r in rows if r['row']==i)['action_input']['id']) for i in completed};assert len(submit_ids)==1
    goal=[];ops=[];conflicts=[];warnings=[]
    byrow={r['row']:r for r in rows}
    for e in events:
        i=e['row']
        if (1<=i<=59 or 226<=i<=256) and e['action'] and ns['_作用番号'](e['action']['id']) in submit_ids:
            pre=byrow[i-1]['phases'][-1]
            if 'scene'in pre:
                match,detail=ns['一致する'](pre['scene'],roles)
                goal.append({'row':i,'before_phase':e['before_terminal_phase'],'match':match,'detail':detail,'accepted_public':e['advanced'],'teacher_used':detail.get('構造状態')!='HOLD'})
        if 1<=i<=59 and 'terminal_measurement'in e:
            m=e['terminal_measurement'];ops.append({'row':i,'measurement':m})
            if m['状態']=='実測' and not e['advanced']:
                if any(c['known'] and not c['same_goal_and_containers'] for c in e['structural_comparison']):conflicts.append({'row':i,'reason':'operation current goal/container changed'})
                other=[x for x in e['per_phase_measurements'] if x['状態']=='実測' and x['作用']!=m['作用']]
                if other:conflicts.append({'row':i,'reason':'different observed intermediate operation','alternatives':other})
    completed_binding=[]
    for i in completed:
        e=next(e for e in events if e['row']==i);first=e['structural_comparison'][0]
        ok=e['same_instance'] and not e['full_reset'] and e['advanced'] and first['same_goal_and_containers'] is True and first['same_complete_scene'] is True
        completed_binding.append({'row':i,'same_completed_scene':ok,'all_phase_structure':e['structural_comparison']})
        if not ok:conflicts.append({'row':i,'reason':'completed first phase differs from preceding terminal goal/scene','comparison':first})
    detail={'schema':'column-teacher-phase-audit-detail-v1','raw_recording':rawref,'sources':sources,'rows':rows,'events':events,'role_trials':role_trials,'goal_teachers':goal,'operation_observations':ops,'completed_binding':completed_binding,'conflicts':conflicts,'warnings':warnings,'limits':['fixed geometry functions shared by AST; no HDS imports or API','all phases inspected; public acceptance remains event-level, not attributed to every phase','same-action and same-recording observations correlated; role token views not independent Actions','no hidden-state or universal-cause inference']}
    signal.alarm(120);dr=save(D/'result/detail_v1.json',detail,12*1024**2-65536)
    summary={'schema':'column-teacher-phase-audit-v1','status':'PASS' if not conflicts else 'FAIL','errors':[], 'raw_recording':rawref,'sources':sources,'source':digestfile(Path(__file__)),'detail':dr,'verified':{'all_92_rows_all_phases_retained':len(rows)==92,'completed_frame0_same_goal_binding':all(x['same_completed_scene'] for x in completed_binding),'goal_before_terminal_binding':all(x['before_phase']==len(byrow[x['row']-1]['phases'])-1 for x in goal),'operation_terminal_labels_noncontradictory':not any(x for x in conflicts if x['reason'].startswith(('operation','different')))},'counts':{'rows':len(rows),'phases':sum(len(x['phases']) for x in rows),'phase_unknown':sum('unknown'in p for r in rows for p in r['phases']),'role_token_views':sum(len(b['枠群']) for p in completed.values() for b in p['scene']['容器群']),'goal_teachers':sum(x['teacher_used'] for x in goal),'operation_teachers':sum(x['measurement']['状態']=='実測' for x in ops),'conflicts':len(conflicts)},'goal_teachers':goal,'completed_first_phase':[{'row':x['row'],'same_completed_scene':x['same_completed_scene']} for x in completed_binding],'conflicts':conflicts,'limits':detail['limits'],'preparation_procedure_difference':'ebd95e created empty scope directories before resource check and /tmp/column_audit_draft_unused.txt zero bytes; retained, no raw/source altered'}
    sr=save(D/'result/summary_v1.json',summary,65536);print(json.dumps({'summary':sr,'status':summary['status'],'counts':summary['counts'],'verified':summary['verified'],'conflicts':conflicts},ensure_ascii=False),flush=True)
    if conflicts:raise ValueError('observed phase binding conflicts; no teaching performed')
try:run()
except BaseException:
    text=traceback.format_exc();print(text,flush=True)
    signal.alarm(120)
    try:print(json.dumps({'failure':save(D/'failure/error_v1.json',{'traceback':text},2*1024**2)},ensure_ascii=False),flush=True)
    except BaseException:print(traceback.format_exc(),flush=True)
    raise
