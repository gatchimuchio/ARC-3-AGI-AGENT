"""Pinned saved-observation comparison. No HDS engine import/call/restore; no SDK."""
import ast,dataclasses,enum,hashlib,importlib.util,json,lzma,os,pathlib,resource,shutil,signal,sys,time,traceback
from copy import deepcopy
B=pathlib.Path('/workspace/scratch/a94ff513b3af');D=B/'arc-column-goal-work-measurement-20261013'
M=1048576;OWNER=None

def sha(p):
 h=hashlib.sha256()
 with pathlib.Path(p).open('rb') as f:
  for b in iter(lambda:f.read(65536),b''):h.update(b)
 return h.hexdigest()
def identity(p):
 s=pathlib.Path(p).stat();return [s.st_dev,s.st_ino,s.st_size,s.st_mode,s.st_mtime_ns,s.st_ctime_ns]
def ref(p):return {'path':str(p),'bytes':pathlib.Path(p).stat().st_size,'sha256':sha(p)}
def fsyncdir(p):
 fd=os.open(p,os.O_RDONLY)
 try:os.fsync(fd)
 finally:os.close(fd)
def checkref(r,cap=16*M):
 p=pathlib.Path(r['path'])
 if set(r)!={'path','bytes','sha256'} or type(r['bytes'])is not int or not 0<=r['bytes']<=cap or p.is_symlink() or p.stat().st_size!=r['bytes'] or sha(p)!=r['sha256']:raise ValueError('exact immutable input ref')
 return p

def guard(category=None,n=0):
 caps={'source':4*M,'output':24*M,'failure':4*M};used={}
 if D.is_symlink():raise ValueError('scope symlink')
 for k,c in caps.items():
  q=D/k
  if q.is_symlink():raise ValueError('category symlink')
  files=list(q.rglob('*')) if q.exists() else []
  if any(x.is_symlink() for x in files):raise ValueError('member symlink')
  used[k]=sum(x.stat().st_size for x in files if x.is_file())
  if used[k]+(n if category==k else 0)>c:raise MemoryError('category cap '+k)
 if sum(used.values())+n>32*M:raise MemoryError('total32MiB')
 if shutil.disk_usage(B).free<(988+1024)*M+n:raise MemoryError('disk future988MiB+floor1GiB')
 mem=int(next(x.split()[1] for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
 if mem<(4096+2048)*M:raise MemoryError('retained4GiB+floor2GiB')
 return used

class Clock:
 def __init__(self):
  self.remaining={'compute':600.,'save':120.};self.mode=None;self.start=None
  signal.signal(signal.SIGALRM,self.expire)
 def expire(self,*a):raise TimeoutError('column work '+str(self.mode)+' deadline')
 def stop(self):
  signal.setitimer(signal.ITIMER_REAL,0)
  if self.mode is not None:self.remaining[self.mode]-=time.monotonic()-self.start
  self.mode=None
 def enter(self,mode):
  self.stop()
  if self.remaining[mode]<=0:raise TimeoutError('aggregate deadline '+mode)
  self.mode=mode;self.start=time.monotonic();signal.setitimer(signal.ITIMER_REAL,self.remaining[mode])

class Run:
 def __init__(self):
  self.clock=Clock();self.modules=[];self.exceptions=[];self.errors=[];self.current=None;self.pending=None;self.refs=[];self.inputs={};self.row=1;self.complete=False
 def load(self,p,name):
  spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);self.modules.append(m);spec.loader.exec_module(m);return m
 def codec(self,p):
  t=ast.parse(p.read_text());names={'_符号化','_復号'};nodes=[n for n in t.body if isinstance(n,ast.FunctionDef) and n.name in names]
  if {n.name for n in nodes}!=names:raise ValueError('codec closure')
  ns={'Enum':enum.Enum,'is_dataclass':dataclasses.is_dataclass,'fields':dataclasses.fields,'Any':object,'_型表':lambda:{}}
  exec(compile(ast.Module(body=nodes,type_ignores=[]),str(p),'exec'),ns)
  self.enc=ns['_符号化'];self.dec=ns['_復号'];self.codec_namespace=ns
 def read_xz(self,r,typed=True):
  p=checkref(r['file']);b=p.read_bytes();z=lzma.LZMADecompressor();raw=z.decompress(b,max_length=16*M+1)
  if len(raw)>16*M or not z.eof or z.unused_data or z.check!=lzma.CHECK_CRC64 or len(raw)!=r['rawbytes'] or hashlib.sha256(raw).hexdigest()!=r['rawsha256']:raise ValueError('CRC64/EOF/raw closure')
  x=json.loads(raw)
  if not typed:return x
  v=self.dec(x)
  if not self.m.同型(self.enc(v),x):raise ValueError('typed input roundtrip')
  return v
 def save(self,name,v,category='output'):
  self.pending={'name':name,'value':v};self.clock.enter('save');primary=None
  try:
   encoded=self.enc(v);raw=json.dumps(encoded,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()
   if len(raw)>16*M:raise MemoryError('raw16MiB record stop')
   if not self.m.同型(v,self.dec(json.loads(raw))):raise ValueError('all type/order roundtrip')
   blob=lzma.compress(raw,preset=0,check=lzma.CHECK_CRC64);guard(category,len(blob))
   folder=D/category;folder.mkdir(exist_ok=True);fsyncdir(D);p=folder/(name+'.json.xz')
   with p.open('xb') as f:
    if f.write(blob)!=len(blob):raise OSError('short write')
    f.flush();os.fsync(f.fileno())
   fsyncdir(folder)
   r={'file':ref(p),'rawbytes':len(raw),'rawsha256':hashlib.sha256(raw).hexdigest()}
   if p.read_bytes()!=blob or not self.m.同型(v,self.read_xz(r)):raise ValueError('saved full readback')
   self.pending=None;return r
  except BaseException as e:primary=e;self.exceptions.append(e);raise
  finally:
   self.clock.stop()
   if primary is None:self.clock.enter('compute')
 def preflight(self):
  soft,hard=resource.getrlimit(resource.RLIMIT_AS)
  if not 0<soft<=512*M or not 0<hard<=512*M:raise PermissionError('AS512 before import')
  guard();manifest=json.loads((D/'source/caller_contract_v1.json').read_text())
  if manifest['caller_sha256']!=sha(__file__):raise ValueError('caller pin')
  self.manifest=manifest
  for key,r in manifest['inputs'].items():
   p=checkref(r,80*M);self.inputs[key]={'ref':r,'identity':identity(p)}
  self.m=self.load(pathlib.Path(manifest['inputs']['pure']['path']),'column_work_pure_v2')
  self.codec(pathlib.Path(manifest['inputs']['codec']['path']))
  family=pathlib.Path(manifest['inputs']['family']['path']);tree=ast.parse(family.read_text());names={'列を生成する','一致する'}
  nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
  if {n.name for n in nodes}!=names:raise ValueError('exact pure column closure')
  ns={};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(family),'exec'),ns);self.match=ns['一致する'];self.prior_namespace=ns
  proof=json.loads(pathlib.Path(manifest['inputs']['pool_readback']['path']).read_text())
  if proof['exit_code']!=0 or 'ALL_API 236 ROWS 59' not in proof['output']:raise ValueError('saved full pool readback not PASS')
  exittool=json.loads(pathlib.Path(manifest['inputs']['pool_exit']['path']).read_text())
  if exittool['exit_code']!=0:raise ValueError('pool native actual exit')
  public=json.loads(exittool['output'].splitlines()[0])
  if public['status']!='complete' or public['receipt']!=manifest['completion']:raise ValueError('pool completion actual join')
  self.completion=self.read_xz(manifest['completion'],False)
  c=self.completion
  if c['status']!='complete' or c['errors'] or c['case_count']!=59 or c['teach_calls']!=0 or c['query_calls']!=236 or c['Action']!=0 or len(c['pools'])!=59:raise ValueError('all59 native pool closure')
  detail=json.loads(pathlib.Path(manifest['inputs']['LS_detail']['path']).read_text());self.detail=detail
  self.rows={r['row']:r for r in detail['rows']};self.events={e['row']:e for e in detail['events']}
  if len(self.rows)!=len(detail['rows']) or len(self.events)!=len(detail['events']):raise ValueError('duplicate LS row/event')
  if detail['raw_recording']!=manifest['inputs']['raw']:raise ValueError('raw ref binding')
  self.pool_counts={};self.work_counts={};self.phase_count=0;self.unknown_goal_rows=[]
 def execute(self):
  for i in range(1,60):
   self.row=i;guard();r=self.completion['pools'][i-1];pool=self.read_xz(r)
   a,b=self.rows[i-1],self.rows[i];ev=self.events[i];phase=a['phases'][-1]
   if pool['action_row']!=i or pool['before_row']!=i-1 or pool['ordinal']!=i-1 or pool['phase']!=phase['phase'] or pool['frame_sha256_uint8']!=phase['frame_sha256_uint8']:raise ValueError('pool before binding')
   if pool['raw_row']!={'offset':a['byte_offset'],'bytes':a['line_bytes'],'sha256':a['line_sha256']}:raise ValueError('raw row binding')
   if not self.m.同型(pool['scene'],phase.get('scene')):raise ValueError('native and LS scene all types/order')
   # Every full capture file remains reachable and hash-bound, including all raw replies.
   for ap in pool['API_records']:
    for key in ('intent','reply'):
     checkref(ap[key]['file'])
   self.current={'行':i,'pool正本':r,'全pool包絡':pool,'隠れ状態差':'未観測','報酬':'未観測'}
   measured=self.m.作用を比較する(a,b,ev,pool['work_measurement_capture'],self.match)
   self.current['教師候補観測']=measured
   if measured['例外'] or any(x['例外'] for x in measured['各相効果']):raise ValueError('unexpected saved pure-comparison errors; stop with suffix')
   out=self.save('case_%02d'%i,self.current);self.refs.append({'行':i,'ref':out})
   state=measured['前提'].get('目標pool状態');self.pool_counts[state]=self.pool_counts.get(state,0)+1
   op=ev.get('terminal_measurement',{}).get('状態','未観測');self.work_counts[op]=self.work_counts.get(op,0)+1
   self.phase_count+=len(measured['全後相'])
   if state!='一意':self.unknown_goal_rows.append(i)
   self.current=None
  for key,x in self.inputs.items():
   p=checkref(x['ref'],80*M)
   if identity(p)!=x['identity']:raise ValueError('input changed during observation '+key)
  terminal={'種別':'列目標作業全59教師候補観測-v1','状態':'complete','errors':[], '全行順':list(range(1,60)),'cases':self.refs,'未処理suffix':[],
    '全入力closure':self.inputs,'native_pool_completion':self.manifest['completion'],'目標pool集計':self.pool_counts,'作業実測状態集計':self.work_counts,'全後相数':self.phase_count,'目標UNKNOWN行':self.unknown_goal_rows,
    '隠れ状態差':'未観測','報酬':'未観測','HDS呼出し':0,'SDK呼出し':0,'Action':0,'Teach':0,'限界':'教師候補観測のみ。0poolは当該空欄全単射文法未成立、選択知覚は在庫外周限定、全相を独立支持としない。公開進捗はevent単位。'}
  self.terminal=self.save('terminal',terminal);self.complete=True;return self.terminal

def run():
 global OWNER
 if OWNER is not None:raise RuntimeError('single run only')
 OWNER=Run();OWNER.clock.enter('compute')
 try:
  OWNER.preflight();r=OWNER.execute();OWNER.clock.stop();print(json.dumps({'status':'complete','terminal':r,'cases':len(OWNER.refs),'pool_counts':OWNER.pool_counts,'work_counts':OWNER.work_counts,'after_phases':OWNER.phase_count},ensure_ascii=False),flush=True);return r
 except BaseException as e:
  OWNER.clock.stop();OWNER.exceptions.append(e);err={'type':type(e).__name__,'args':e.args,'traceback':traceback.format_exc()};OWNER.errors.append(err)
  print(json.dumps({'status':'failed','row':OWNER.row,'saved_cases':len(OWNER.refs),'error':err},ensure_ascii=False),flush=True)
  try:
   OWNER.failure=OWNER.save('failure',{'errors':OWNER.errors,'current':OWNER.current,'pending':OWNER.pending,'saved':OWNER.refs,'未処理suffix':list(range(OWNER.row,60))},'failure')
   OWNER.clock.stop();print(json.dumps({'failure':OWNER.failure},ensure_ascii=False),flush=True)
  except BaseException as secondary:
   OWNER.clock.stop();OWNER.exceptions.append(secondary);print(traceback.format_exc(),flush=True)
  raise
