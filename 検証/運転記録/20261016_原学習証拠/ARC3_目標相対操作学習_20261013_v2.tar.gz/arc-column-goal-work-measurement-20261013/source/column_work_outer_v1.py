import resource
resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912))
import sys,importlib.util,pathlib,hashlib,traceback
sys.dont_write_bytecode=True
P=pathlib.Path(__file__).parent/'column_work_caller_v1.py'
OUTER={'module':None,'exceptions':[]}
try:
 if hashlib.sha256(P.read_bytes()).hexdigest()!='f41309349c082ca0146a3c0cd21597d24a2b27056b1658c257f66491cc8ed576':raise ValueError('caller source pin')
 spec=importlib.util.spec_from_file_location('column_work_caller',P);m=importlib.util.module_from_spec(spec);OUTER['module']=m;spec.loader.exec_module(m);OUTER['result']=m.run()
except BaseException as e:
 OUTER['exceptions'].append(e);print(traceback.format_exc(),flush=True);raise
