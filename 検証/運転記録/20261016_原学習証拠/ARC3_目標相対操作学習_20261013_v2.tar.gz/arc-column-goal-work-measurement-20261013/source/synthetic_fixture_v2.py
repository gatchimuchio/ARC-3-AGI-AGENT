import resource
resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912))
import sys,importlib.util,json,pathlib,hashlib,os,traceback,signal,shutil,copy,time
sys.dont_write_bytecode=True
B=pathlib.Path('/workspace/scratch/a94ff513b3af');D=B/'arc-column-goal-work-measurement-20261013';P=D/'source'
def timeout(*a):raise TimeoutError('synthetic fixture compute deadline')
signal.signal(signal.SIGALRM,timeout);signal.alarm(120)
def guard(n):
    used=sum(p.stat().st_size for p in D.rglob('*') if p.is_file())
    if used+n>4*1048576:raise MemoryError('source/prep cap')
    if shutil.disk_usage(B).free<(948+1024)*1048576+n:raise MemoryError('disk fullfuture/floor')
    m=int(next(x.split()[1] for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
    if m<(2048+512)*1048576:raise MemoryError('RAM floor+own')
def file_ref(p):
    b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
guard(65536)
p=P/'column_goal_work_v2.py';assert file_ref(p)['sha256']=='8427b6cf7498613c548e6ac883ebfe800ffa6c43b25ded7488d45facdb9f34be'
spec=importlib.util.spec_from_file_location('pure_column_goal_work',p);m=importlib.util.module_from_spec(spec);OWNER={'module':m,'cases':[],'exceptions':[]};spec.loader.exec_module(m)
def record(name,inputs,call,check,expected=None):
    c={'case':name,'synthetic_inputs':copy.deepcopy(inputs),'expected_exception':None if expected is None else expected.__name__};OWNER['cases'].append(c)
    try:
        v=call();c['return']=v;c['pass']=expected is None and check(v)
    except Exception as e:
        OWNER['exceptions'].append(e);c['exception']={'type':type(e).__name__,'args':list(e.args),'args_type':type(e.args).__name__,'traceback':traceback.format_exc()};c['pass']=expected is not None and type(e)is expected
    return c
old={'guid':'synthetic','game_id':'index_only','full_reset':False,'score':2};new={**old};new.pop('score');new['levels_completed']=2
record('旧新alias一致',[old,new],lambda:[m.境界(old,old),m.境界(new,new)],lambda v:m.同型(v[0],v[1]))
record('旧非進捗',[old,old],lambda:m.境界(old,old),lambda v:v['公開進捗あり'] is False and v['旧問題継続確認'] is True)
record('新進捗',[new,{**new,'levels_completed':3}],lambda:m.境界(new,{**new,'levels_completed':3}),lambda v:v['公開進捗あり'] is True and v['旧問題継続確認'] is False)
record('alias矛盾',{**old,'levels_completed':3},lambda:m.完了数({**old,'levels_completed':3}),lambda v:False,ValueError)
record('完了数bool拒否',{'score':True},lambda:m.完了数({'score':True}),lambda v:False,ValueError)
record('RESET',[old,{**old,'full_reset':True}],lambda:m.境界(old,{**old,'full_reset':True}),lambda v:v['公開進捗あり'] is None and not v['旧問題継続確認'])
record('RESET欠損',[old,{'guid':'synthetic','game_id':'index_only','score':2}],lambda:m.境界(old,{'guid':'synthetic','game_id':'index_only','score':2}),lambda v:v['公開進捗あり'] is None)
scene={'背景色':0,'目標列':[2],'容器群':[{'色':1,'位置':[0,0],'起点':True,'枠群':[{'位置':[3,3],'記号':None}]}],'在庫群':[]}
def row(i,sc=scene):return {'row':i,'byte_offset':i*10,'line_bytes':10,'line_sha256':'synthetic','metadata':copy.deepcopy(old),'phases':[{'phase':0,'frame_sha256_uint8':'synthetic_frame','scene':copy.deepcopy(sc),'selection':None}]}
a,b=row(0),row(1);event={'row':1,'action':{'id':6,'data':{'x':3,'y':3}},'terminal_measurement':{'状態':'HOLD','理由':'synthetic'},'per_phase_measurements':[]}
cap={'前相画素SHA256':'synthetic_frame','実照会参照':{'synthetic':True},'役割支持参照':['synthetic_not_native'],'学習役割':[{'記号は中空':False,'列展開役割':'出力'},{'記号は中空':True,'列展開役割':'参照'}],'全内容候補返却':{'候補数':0,'候補':[]}}
def match(*a):return False,{'構造状態':'HOLD','理由':'synthetic未記入'}
record('空pool',[a,b,event,cap],lambda:m.作用を比較する(a,b,event,cap,match),lambda v:v['前提']['目標pool状態']=='当該生成文法で未成立' and v['前提']['集約適合'] is None and v['前提']['現在列一致'] is None)
pool=[{'割当':[{'位置':[3,3],'色':c,'中空':False}]} for c in (2,3)]
multiple=copy.deepcopy(cap);multiple['全内容候補返却']={'候補数':2,'候補':pool}
record('複数pool全保持',[a,b,event,multiple],lambda:m.作用を比較する(a,b,event,multiple,match),lambda v:len(v['前提']['全候補比較'])==2 and len(v['各相効果'][0]['全候補効果'])==2 and v['各相効果'][0]['集約効果'] is None)
u=copy.deepcopy(a);u['phases'][0].pop('scene');u['phases'][0]['unknown']={'type':'ValueError','message':'synthetic perception failure'}
record('知覚unknown',[u,b,event],lambda:m.作用を比較する(u,b,event),lambda v:v['前提']['UNKNOWN']=='before知覚不成立' and v['全前相']==u['phases'])
record('選択None範囲明示',[a,b,event],lambda:m.作用を比較する(a,b,event),lambda v:v['前提']['現在選択'] is None and 'Noneは全選択なし' in v['前提']['選択知覚の範囲'])
for exc in (MemoryError,TimeoutError,RuntimeError):
    def fail(*args,E=exc):raise E('synthetic propagation')
    record('前提_'+exc.__name__,{'injection':'既存一致関数','a':a,'b':b,'event':event,'capture':cap},lambda:m.作用を比較する(a,b,event,cap,fail),lambda v:False,exc)
    original=m.候補効果
    try:
        m.候補効果=fail
        record('後相_'+exc.__name__,{'injection':'候補効果','a':a,'b':b,'event':event,'capture':multiple},lambda:m.作用を比較する(a,b,event,multiple,match),lambda v:False,exc)
    finally:m.候補効果=original
record('空欄0不一致を維持',{'synthetic_match':False},lambda:m.作用を比較する(row(0,{**scene,'容器群':[{'色':1,'位置':[0,0],'起点':True,'枠群':[{'位置':[3,3],'記号':{'色':3,'中空':False}}]}]}),b,event,cap,lambda *a:(False,{'出力列':[3]})),lambda v:v['前提']['空欄数']==0 and v['前提']['現在列一致'] is False)
report={'schema':'column-goal-work-synthetic-fixture-v2','status':'PASS' if all(c['pass'] for c in OWNER['cases']) else 'FAIL','source':file_ref(p),'fixture':file_ref(pathlib.Path(__file__)),'cases':OWNER['cases'],'count':len(OWNER['cases']),'errors':[],'limits':['synthetic cases only; HDS/SDK/raw measurement0','role values injected only into explicit synthetic fixture, not recovered teacher facts','no native capture authenticity or real source fit claim','resource exception propagation verified; retained outer suffix preservation remains later caller work']}
signal.alarm(120);data=json.dumps(report,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode();guard(len(data))
p=P/'synthetic_fixture_result_v2.json'
with p.open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
fd=os.open(P,os.O_RDONLY);os.fsync(fd);os.close(fd);assert p.read_bytes()==data
print(json.dumps({'status':report['status'],'count':report['count'],'result':file_ref(p)},ensure_ascii=False),flush=True)
signal.alarm(0)
if report['status']!='PASS':raise AssertionError('synthetic cases failed; full report retained')
