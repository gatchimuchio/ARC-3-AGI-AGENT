import resource
resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912))
import importlib.util,pathlib,sys,json,hashlib,traceback,signal,time,copy,ast
sys.dont_write_bytecode=True
P=pathlib.Path(__file__).parent
sp=importlib.util.spec_from_file_location('work_caller_fixture',P/'column_work_caller_v1.py');c=importlib.util.module_from_spec(sp);sp.loader.exec_module(c)
c.guard('source',65536);o=c.Run();o.m=o.load(P/'column_goal_work_v2.py','work_pure_fixture');manifest=json.loads((P/'caller_contract_v1.json').read_text());o.codec(pathlib.Path(manifest['inputs']['codec']['path']))
RESULTS=[];EXCEPTIONS=[]
def case(name,inputs,fn,check,expected=None):
 r={'case':name,'inputs':inputs,'expected_exception':expected.__name__ if expected else None};RESULTS.append(r)
 try:r['result']=fn();r['pass']=expected is None and check(r['result'])
 except BaseException as e:
  EXCEPTIONS.append(e);r['exception']={'type':type(e).__name__,'args':list(e.args),'traceback':traceback.format_exc()};r['pass']=expected is not None and type(e)is expected
v={'順序':[1,False,None,(2,'a')],'整数鍵':{2:'b',1:'a'}}
case('typed保存全読戻し',v,lambda:o.save('caller_fixture_transport',v,'source'),lambda r:o.m.同型(o.read_xz(r),v))
saved=RESULTS[0]['result'];bad=copy.deepcopy(saved);bad['file']['sha256']='0'*64
case('SHA拒否',bad,lambda:o.read_xz(bad),lambda r:False,ValueError)
bad=copy.deepcopy(saved);bad['rawbytes']+=1
case('raw長拒否',bad,lambda:o.read_xz(bad),lambda r:False,ValueError)
case('bool_int鍵区別',{'a':[[True,'x']],'b':[[1,'x']]},lambda:o.m.同型({True:'x'},{1:'x'}),lambda x:x is False)
case('辞書順区別',{'a':[[1,'x'],[2,'y']],'b':[[2,'y'],[1,'x']]},lambda:o.m.同型({1:'x',2:'y'},{2:'y',1:'x'}),lambda x:x is False)
o.clock.stop();clock=c.Clock();clock.remaining['compute']=0.02
try:
 def expire():clock.enter('compute');time.sleep(0.1)
 case('単一操作deadline',{'seconds':0.02},expire,lambda x:False,TimeoutError)
finally:clock.stop()
clock=c.Clock();clock.remaining['save']=0
try:case('保存枠枯渇',{'remaining':0},lambda:clock.enter('save'),lambda x:False,TimeoutError)
finally:clock.stop()
# Static scope audit: no HDS engine, SDK, full59 convenience call or role constants in caller.
t=ast.parse((P/'column_work_caller_v1.py').read_text())
imports=[n.module for n in ast.walk(t) if isinstance(n,ast.ImportFrom)]+[a.name for n in ast.walk(t) if isinstance(n,ast.Import) for a in n.names]
calls=[n.func.attr for n in ast.walk(t) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute)]
case('static呼出範囲',{'imports':imports,'attributes':calls},lambda:not any('hds' in x.lower() or 'arc_agi' in x.lower() for x in imports) and '全59作用' not in calls and '作用を比較する' in calls,lambda x:x is True)
report={'schema':'column-work-caller-fixture-v1','status':'PASS' if all(x['pass'] for x in RESULTS) else 'FAIL','cases':RESULTS,'source':c.ref(P/'column_work_caller_v1.py'),'native':0,'SDK':0,'raw_measurement':0,'limits':'synthetic transport/static checks only; not all real59 fit proof'}
o.clock=c.Clock();r=o.save('caller_fixture_result',report,'source');o.clock.stop();print(json.dumps({'status':report['status'],'count':len(RESULTS),'receipt':r},ensure_ascii=False),flush=True)
if report['status']!='PASS':raise AssertionError('caller fixture failed')
