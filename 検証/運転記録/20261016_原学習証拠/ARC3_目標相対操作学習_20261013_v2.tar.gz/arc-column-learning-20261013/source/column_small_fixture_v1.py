"""Small synthetic harness checks; native HDS/Teach/Query/restore are never imported."""
import resource
resource.setrlimit(resource.RLIMIT_AS,(134217728,134217728))
import sys,os,json,hashlib,importlib.util,traceback,signal,types
from pathlib import Path
ROOT=Path("/workspace/scratch/a94ff513b3af/arc-column-learning-20261013")
signal.signal(signal.SIGALRM,lambda *a:(_ for _ in ()).throw(TimeoutError("pure120")));signal.alarm(120)
MODULE=None;CASES=[];ERRORS=[]
def check(name,fn,error=None):
 c={"name":name,"result":None,"exception":None}
 try:
  c["result"]=fn()
  if error:raise AssertionError("expected refusal missing")
 except BaseException as e:
  c["exception"]={"type":type(e).__name__,"repr":repr(e),"traceback":traceback.format_exc()}
  if type(e) is not error:ERRORS.append(c["exception"]);raise
 finally:CASES.append(c)
def main():
 global MODULE
 p=ROOT/"source/column_harness_v1.py";manifest=json.loads((ROOT/"source/column_contract_v1.json").read_bytes())
 assert hashlib.sha256(p.read_bytes()).hexdigest()==manifest["source"]["sha256"]
 sp=importlib.util.spec_from_file_location("column_harness_fixture_subject",p);MODULE=importlib.util.module_from_spec(sp);sp.loader.exec_module(MODULE)
 assert not any(x.startswith("hds学習系統") for x in sys.modules)
 MODULE.guard("source",65536)
 folder=ROOT/"source"/"synthetic_fixture";folder.mkdir();MODULE.fsyncdir(folder.parent)
 rows=[{"data":{"frame":[[[i]],[[i+1]]],"x":i}} for i in range(3)]
 raw=b"".join(MODULE.jb(x)+b"\n" for x in rows);p=folder/"rows.jsonl"
 with p.open("xb") as f:f.write(raw);f.flush();os.fsync(f.fileno())
 MODULE.fsyncdir(folder)
 reads=[];r=MODULE.IndexedRows(p,hashlib.sha256(raw).hexdigest(),(0,2),reads.append)
 def positive():
  assert len(r)==3 and r[2]==rows[2]["data"] and r[0]==rows[0]["data"]
  assert [x["row"] for x in reads]==[2,0] and all(len(x["phases"])==2 for x in reads)
  r.close_check();return {"calls":r.calls,"all_phase_refs":reads,"offsets":r.offsets}
 check("lazy_original_order_and_all_phases",positive)
 check("unselected_row_refused",lambda:r[1],IndexError)
 check("bool_index_refused",lambda:r[True],IndexError)
 check("wrong_whole_source_SHA",lambda:MODULE.IndexedRows(p,"0"*64,(0,)),ValueError)
 def strict():assert MODULE.eq({"a":[True,1]},{"a":[True,1]}) and not MODULE.eq(True,1) and not MODULE.eq({"a":1,"b":2},{"b":2,"a":1});return True
 check("strict_type_order",strict)
 class Exhaust:
  def 排出する(self,結果):return 結果
 class Machine:
  def __init__(self,fail=False):self.排気系=Exhaust();self.calls=0;self.fail=fail
  def 処理する(self,x):
   self.calls+=1;z=self.排気系.排出する(x)
   if self.fail:raise ValueError("synthetic after capture")
   return z
 held={}
 def normal():
  m=Machine();v={"retained":[True,False]};out=MODULE.capture_call(m,"処理する",v,held)
  assert out is v and held["raw"][0] is v and m.calls==1 and held["profile_restored"] and sys.getprofile() is None
  return held
 check("exact_normal_capture",normal)
 failed={};m=Machine(True)
 check("exact_exception_capture",lambda:MODULE.capture_call(m,"処理する",{"x":1},failed),ValueError)
 assert m.calls==1 and failed["profile_restored"] and failed["raw"]==[{"x":1}]
 CASES[-1]["retained_capture"]=failed
 previous=lambda *a:None
 sys.setprofile(previous)
 try:check("existing_profile_refused",lambda:MODULE.capture_call(Machine(),"処理する",{},{}),PermissionError)
 finally:sys.setprofile(None)
 assert not any(x.startswith("hds学習系統") for x in sys.modules)
 return {"schema":"column-harness-synthetic-v1","status":"PASS","cases":CASES,"errors":ERRORS,"HDS_import":False,"raw_teacher_read":False,"limitations":["Synthetic helper checks only; actual HDS standard save/import and 78 teachers are unexecuted.","Profile exact identity is checked in this process; saved JSON preserves values/trace, not heap aliases."]}
try:
 result=main()
except BaseException as e:
 ERRORS.append({"type":type(e).__name__,"repr":repr(e),"traceback":traceback.format_exc()})
 result={"schema":"column-harness-synthetic-v1","status":"FAIL","cases":CASES,"errors":ERRORS}
finally:
 signal.alarm(0)
 raw=json.dumps(result,ensure_ascii=False,separators=(",",":")).encode()
 MODULE.guard("source",len(raw))
 p=ROOT/"source/synthetic_fixture_result_v1.json"
 with p.open("xb") as f:f.write(raw);f.flush();os.fsync(f.fileno())
 MODULE.fsyncdir(p.parent);assert p.read_bytes()==raw
 print(json.dumps({"status":result["status"],"cases":len(CASES),"result":MODULE.ref(p)},ensure_ascii=False))
 if result["status"]!="PASS":raise SystemExit(1)
