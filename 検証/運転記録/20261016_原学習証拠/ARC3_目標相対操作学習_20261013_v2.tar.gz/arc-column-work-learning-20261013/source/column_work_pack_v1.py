"""Pure saved-evidence teacher projection. No HDS import/API, no expected-answer table."""
import ast,dataclasses,enum,hashlib,json,lzma,os,shutil
from pathlib import Path
B=Path("/workspace/scratch/a94ff513b3af")
ROOT=B/"arc-column-work-learning-20261013"
MIB=1048576
BOUNDARY="公開列図式・一意目標候補・在庫選択と実枠クリックの末相不足修復"
X="実対象への選択記号適合"
Y="応答末相で不足が修復された"
TERMINAL={"path":str(B/"arc-column-goal-work-measurement-20261013/output/terminal.json.xz"),"bytes":7648,"sha256":"db4add2a01cb2e8fe583c0d9f225c23de88c8c29ddc659872af234ed788b2fda"}
CODEC=B/"arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/永続化.py"
CODEC_SHA="8aa431b3012424fd8347c5b3d93a5fbf2218d35020836f5d40abb427f9d6da0d"
def eq(a,b):
 if type(a)is not type(b):return False
 if isinstance(a,dict):return len(a)==len(b) and all(eq(k,l) and eq(a[k],b[l]) for k,l in zip(a,b))
 if isinstance(a,(tuple,list)):return len(a)==len(b) and all(eq(x,y) for x,y in zip(a,b))
 return a==b
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def ref(p):return {"path":str(p),"bytes":Path(p).stat().st_size,"sha256":sha(p)}
def guard(category=None,extra=0):
 caps={"source":4*MIB,"state_trace":48*MIB,"failure":12*MIB};used={}
 if ROOT.is_symlink():raise ValueError("scope symlink")
 for k,cap in caps.items():
  p=ROOT/k;fs=list(p.rglob("*")) if p.exists() else []
  if p.is_symlink() or any(q.is_symlink() for q in fs):raise ValueError("symlink")
  used[k]=sum(q.stat().st_size for q in fs if q.is_file())
  if used[k]+(extra if category==k else 0)>cap:raise MemoryError("category cap "+k)
 if sum(used.values())+extra>64*MIB:raise MemoryError("64MiB scope")
 if shutil.disk_usage(B).free<(1052+1024)*MIB+extra:raise MemoryError("future1052MiB+disk1GiB")
 mem=int(next(x.split()[1] for x in Path("/proc/meminfo").read_text().splitlines() if x.startswith("MemAvailable:")))*1024
 if mem<(4096+2048)*MIB:raise MemoryError("retained4GiB+floor2GiB")
 return {"used":used,"MemAvailable":mem}
def sync(p):
 fd=os.open(p,os.O_RDONLY)
 try:os.fsync(fd)
 finally:os.close(fd)
def write_new(p,b,category="source"):
 guard(category,len(b));p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 with p.open("xb")as f:
  if f.write(b)!=len(b):raise OSError("short write")
  f.flush();os.fsync(f.fileno())
 sync(p.parent);sync(p.parent.parent)
 if p.read_bytes()!=b:raise ValueError("full readback")
 return ref(p)
def check(r,cap=16*MIB):
 p=Path(r["path"])
 if set(r)!={"path","bytes","sha256"} or type(r["bytes"])is not int or not 0<=r["bytes"]<=cap or p.is_symlink() or p.stat().st_size!=r["bytes"] or sha(p)!=r["sha256"]:raise ValueError("exact FileRef")
 return p
def codec():
 if sha(CODEC)!=CODEC_SHA:raise ValueError("normal codec pin")
 tree=ast.parse(CODEC.read_text());names={"_符号化","_復号"};nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
 if {n.name for n in nodes}!=names:raise ValueError("codec AST")
 ns={"Enum":enum.Enum,"is_dataclass":dataclasses.is_dataclass,"fields":dataclasses.fields,"Any":object,"_型表":lambda:{}}
 exec(compile(ast.Module(body=nodes,type_ignores=[]),str(CODEC),"exec"),ns)
 return ns["_符号化"],ns["_復号"]
def read_packet(r,enc,dec,wrapped=True):
 file=r["file"] if wrapped else r;b=check(file).read_bytes();z=lzma.LZMADecompressor();raw=z.decompress(b,max_length=16*MIB+1)
 if len(raw)>16*MIB or not z.eof or z.unused_data or z.check!=lzma.CHECK_CRC64:raise ValueError("CRC64/EOF/raw cap")
 if wrapped and (len(raw)!=r["rawbytes"] or hashlib.sha256(raw).hexdigest()!=r["rawsha256"]):raise ValueError("raw bytes SHA")
 tag=json.loads(raw);v=dec(tag)
 if not eq(enc(v),tag):raise ValueError("full typed/order roundtrip")
 return v
def before_view(r):
 # Metadata pair is used only to establish same public problem, never outcome success.
 return {"phase":r["全前相"][-1] if r["全前相"] else None,
         "pre":r["前提"],"action":r["公開Action"],"scope":r["境界"],
         "metadata":r["公開前後metadata"][0]}
def decide(v):
 reasons=[];p=v["pre"];phase=v["phase"];s=phase.get("scene") if phase else None
 candidates=p.get("全候補比較",[]);q=candidates[0] if len(candidates)==1 else None
 if s is None:reasons.append("before知覚不成立")
 if p.get("目標pool状態")!="一意" or q is None:reasons.append("before目標候補非一意")
 selection=p.get("現在選択")
 if selection is None or p.get("選択UNKNOWN") is not None:reasons.append("在庫選択不明")
 elif s is None or not any(eq(selection,t) for t in s["在庫群"]):reasons.append("可視在庫との対応なし")
 if v["scope"].get("旧問題継続確認") is not True:reasons.append("同一問題境界未確認")
 action=v["action"];number=action.get("id") if isinstance(action,dict) else None
 available=v["metadata"].get("available_actions",[])
 if type(number)is not int or number!=6:reasons.append("既存公開座標クリックAction外")
 if not isinstance(available,list) or any(type(x)is not int for x in available) or number not in available:reasons.append("公開available外")
 if q is None or len(q.get("公開座標の枠候補",[]))!=1:reasons.append("実クリック対象枠非一意")
 if q is not None and type(q.get(X))is not bool:reasons.append("before適合bool未確定")
 return {"eligible_before":not reasons,"reasons":reasons,"query_input":{X:q[X]} if not reasons else None}
def project(case):
 r=case["教師候補観測"];v=before_view(r);d=decide(v)
 result={"row":r["行"],"before_view":v,"decision":d,"teacher":None,"boundary":BOUNDARY,
         "hidden":case["隠れ状態差"],"reward":case["報酬"],"all_phase_references":{"before":r["全前相"],"after":r["全後相"]},
         "other_effects":r["各相効果"],"original_scope":r["境界"]}
 if not d["eligible_before"]:return result
 # An eligible but unmeasurable result is a pack failure, never silently removed.
 if r["例外"] or not r["各相効果"]:raise ValueError("eligible observation missing")
 last=r["各相効果"][-1]
 if last["例外"] or last.get("旧scope効果確認")is not True or len(last["全候補効果"])!=1:raise ValueError("eligible terminal scope unknown")
 effect=last["全候補効果"][0];y=effect.get("不足が修復された")
 if type(y)is not bool:raise ValueError("eligible result must be strict bool")
 result["teacher"]={X:d["query_input"][X],Y:y}
 return result
def build():
 guard();enc,dec=codec();terminal=read_packet(TERMINAL,enc,dec,False)
 if terminal["状態"]!="complete" or terminal["errors"] or terminal["全行順"]!=list(range(1,60)) or terminal["未処理suffix"] or len(terminal["cases"])!=59:raise ValueError("all59 complete")
 allcases=[];teachers=[]
 for i,item in enumerate(terminal["cases"],1):
  if item["行"]!=i:raise ValueError("original order")
  case=read_packet(item["ref"],enc,dec)
  if case["行"]!=i or case["教師候補観測"]["行"]!=i:raise ValueError("case join")
  projected=project(case);projected["case_ref"]=item["ref"]
  allcases.append(projected)
  if projected["decision"]["eligible_before"]:
   teachers.append({"ordinal":len(teachers),"row":i,"case_ref":item["ref"],"query_input":projected["decision"]["query_input"],"teacher":projected["teacher"],"boundary":BOUNDARY})
 return {"schema":"column-work-teacher-pack-v1","terminal":TERMINAL,"cases":allcases,"teachers":teachers,
         "selection":"before structural eligibility; terminal bool never used for admission",
         "uninterpreted_not_false":True,"Action":0,"Teach":0,"new_independent_support":0,
         "limits":"Same public correlated trajectory; no hidden/reward measurement, policy necessity or unseen transfer claim."}
def save_pack(pack):
 enc,dec=codec();raw=json.dumps(enc(pack),ensure_ascii=False,separators=(",",":"),allow_nan=False).encode()
 if len(raw)>16*MIB or not eq(pack,dec(json.loads(raw))):raise ValueError("pack full types")
 b=lzma.compress(raw,preset=0,check=lzma.CHECK_CRC64)
 r={"file":write_new(ROOT/"source/teacher_pack_v1.json.xz",b),"rawbytes":len(raw),"rawsha256":hashlib.sha256(raw).hexdigest()}
 if not eq(read_packet(r,enc,dec),pack):raise ValueError("pack durable full readback")
 return r
