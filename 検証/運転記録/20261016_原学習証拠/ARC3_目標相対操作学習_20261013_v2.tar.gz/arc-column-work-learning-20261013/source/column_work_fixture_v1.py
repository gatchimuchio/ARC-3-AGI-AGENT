"""Pure pack/readback and bounded synthetic entry checks. No HDS import/API."""
import resource,signal
resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912))
signal.signal(signal.SIGALRM,lambda *a:(_ for _ in ()).throw(TimeoutError("fixture120")))
signal.alarm(120)
import ast,copy,hashlib,importlib.util,json,lzma,sys,traceback,types
from pathlib import Path
D=Path("/workspace/scratch/a94ff513b3af/arc-column-work-learning-20261013/source")
def load(name,p):
 sp=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
p=load("pure_pack_fixture",D/"column_work_pack_v1.py")
h=load("native_source_static",D/"column_work_harness_v1.py")
CASES=[];ERRORS=[]
def check(name,fn,error=None):
 c={"name":name,"result":None,"exception":None}
 try:
  c["result"]=fn()
  if error:raise AssertionError("expected refusal absent")
 except BaseException as e:
  c["exception"]={"type":type(e).__name__,"repr":repr(e),"traceback":traceback.format_exc()}
  if type(e)is not error:ERRORS.append(c["exception"]);raise
 finally:CASES.append(c)
def test():
 p.guard()
 enc,dec=p.codec();file=p.ref(D/"teacher_pack_v1.json.xz");blob=Path(file["path"]).read_bytes()
 z=lzma.LZMADecompressor();raw=z.decompress(blob,max_length=16*p.MIB+1)
 assert z.eof and not z.unused_data and z.check==lzma.CHECK_CRC64
 r={"file":file,"rawbytes":len(raw),"rawsha256":hashlib.sha256(raw).hexdigest()}
 del raw,blob,z
 pack=p.read_packet(r,enc,dec);rebuilt=p.build()
 def same():
  assert p.eq(pack,rebuilt);return {"pack":r,"all59":len(pack["cases"])}
 check("saved_packet_full_regeneration_type_order",same);del rebuilt
 rows=[t["row"] for t in pack["teachers"]]
 def coverage():
  assert rows==[5,7,9,11,16,45,47,49,51,53,54,56,58]
  assert [t["row"] for t in pack["teachers"] if t["teacher"][p.Y]is False]==[16,53]
  assert len(pack["cases"])==59 and sum(not x["decision"]["eligible_before"] for x in pack["cases"])==46
  return {"rows":rows,"all_teacher_values":[t["teacher"] for t in pack["teachers"]],"rejection_reasons":[{"row":c["row"],"decision":c["decision"]} for c in pack["cases"] if not c["decision"]["eligible_before"]]}
 check("external_expected_coverage_only_not_selector",coverage)
 item=pack["teachers"][0];case=p.read_packet(item["case_ref"],enc,dec);base=p.project(case)
 def contrary():
  changed=copy.deepcopy(case);end=changed["教師候補観測"]["各相効果"][-1];end["全候補効果"][0]["不足が修復された"]=False
  out=p.project(changed);assert out["decision"]==base["decision"] and out["teacher"][p.Y]is False
  return {"original_ref":item["case_ref"],"changed_terminal":end,"projection":out["teacher"],"decision":out["decision"]}
 check("contrary_after_does_not_change_before_selection",contrary)
 def absent():
  changed=copy.deepcopy(case);changed["教師候補観測"]["各相効果"]=[]
  return p.decide(p.before_view(changed["教師候補観測"]))
 check("before_admission_ignores_all_after_effects",absent)
 def unknown():
  changed=copy.deepcopy(case);changed["教師候補観測"]["各相効果"][-1]["全候補効果"][0]["不足が修復された"]=None
  return p.project(changed)
 check("eligible_unknown_result_fails_not_dropped",unknown,ValueError)
 view=copy.deepcopy(base["before_view"])
 for name,mutate in [
  ("no_visible_inventory_selection",lambda v:v["pre"].update({"現在選択":None})),
  ("multiple_goals",lambda v:v["pre"]["全候補比較"].append(copy.deepcopy(v["pre"]["全候補比較"][0]))),
  ("missing_target",lambda v:v["pre"]["全候補比較"][0].update({"公開座標の枠候補":[]})),
  ("strict_input_not_int",lambda v:v["pre"]["全候補比較"][0].update({p.X:1})),
  ("unavailable",lambda v:v["metadata"].update({"available_actions":[]})),
  ("bool_Action_rejected",lambda v:v["action"].update({"id":True})),
  ("different_problem",lambda v:v["scope"].update({"旧問題継続確認":False}))]:
  def run(mutate=mutate):
   v=copy.deepcopy(view);mutate(v);out=p.decide(v);assert out["eligible_before"]is False
   return {"synthetic_before":v,"decision":out}
  check(name,run)
 class Exhaust:
  def 排出する(self,結果):return 結果
 class Machine:
  def __init__(self,fail=False):self.排気系=Exhaust();self.calls=0;self.fail=fail
  def 処理する(self,x):
   self.calls+=1;v=self.排気系.排出する(x)
   if self.fail:raise ValueError("synthetic failure")
   return v
 def capture():
  m=Machine();v={"x":True};held={};out=h.capture_call(m,"処理する",v,held)
  assert out is v and held["raw"][0]is v and m.calls==1 and held["profile_restored"]
  return held
 check("profile_normal_single_call",capture)
 held={};machine=Machine(True)
 check("profile_exception_restored",lambda:h.capture_call(machine,"処理する",{"x":False},held),ValueError)
 assert held["profile_restored"] and machine.calls==1;CASES[-1]["retained_capture"]=held
 def calls():
  owner=types.SimpleNamespace(calls=[],phase="regression_queries",pack={"teachers":[item]},frame_ordinal=0)
  # API after-label injection is refused before owner marker/native access.
  return h.Run.call(owner,"照会する",types.SimpleNamespace(内容=item["teacher"],対象系境界=item["boundary"]))
 check("query_after_label_injection_refused",calls,PermissionError)
 def limit():
  return h.Run.call(types.SimpleNamespace(calls=[None]*27),"照会する",None)
 check("API_ceiling_no_native_call",limit,PermissionError)
 def static():
  tree=ast.parse((D/"column_work_harness_v1.py").read_text());code=ast.get_source_segment((D/"column_work_harness_v1.py").read_text(),next(n for n in tree.body if isinstance(n,ast.ClassDef)and n.name=="Run"))
  assert 'range(13)'not in code and 'self.pack["teachers"]'in code and "old ledger prefix changed"in code
  assert code.index('reply_ref=self.save("all13_query_replies"')<code.index('scoring=[]')
  assert 'self.machine=self.native.HDS学習系統.読み込む' in code
  return {"scope":"AST only; normal restore/core memory behavior awaits native gate","source":p.ref(D/"column_work_harness_v1.py")}
 check("source_seams_static",static)
 assert not any(x.startswith("hds学習系統") for x in sys.modules)
 return {"schema":"column-work-pack-fixture-v1","status":"PASS","cases":CASES,"errors":ERRORS,"pack":r,"HDS_import":False,"native_API":0,"limitations":"Saved evidence and synthetic adapter tests; no native restore/Teach/Query run, expected row/result values used only in external fixture assertion."}
try:result=test()
except BaseException as e:
 ERRORS.append({"type":type(e).__name__,"repr":repr(e),"traceback":traceback.format_exc()});result={"status":"FAIL","cases":CASES,"errors":ERRORS}
finally:
 signal.alarm(0)
 enc,dec=p.codec();raw=json.dumps(enc(result),ensure_ascii=False,separators=(",",":")).encode();blob=lzma.compress(raw,preset=0,check=lzma.CHECK_CRC64)
 out=p.write_new(D/"fixture_result_v1.json.xz",blob)
 z=lzma.LZMADecompressor();back=z.decompress(Path(out["path"]).read_bytes())
 assert z.eof and not z.unused_data and z.check==lzma.CHECK_CRC64 and back==raw and p.eq(dec(json.loads(back)),result)
 print(json.dumps({"status":result["status"],"checks":len(CASES),"result":out,"rawbytes":len(raw),"rawsha256":hashlib.sha256(raw).hexdigest(),"pack":result.get("pack"),"guard":p.guard()},ensure_ascii=False))
 if result["status"]!="PASS":raise SystemExit(1)
