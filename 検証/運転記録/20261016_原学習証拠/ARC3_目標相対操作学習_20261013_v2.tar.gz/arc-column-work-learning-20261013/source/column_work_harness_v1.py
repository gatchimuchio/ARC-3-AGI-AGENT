"""Existing column-family delegation; no native calls at import time."""
import ast,base64,hashlib,importlib.util,json,lzma,os,resource,shutil,signal,stat,sys,time,traceback
from pathlib import Path
B=Path("/workspace/scratch/a94ff513b3af")
ROOT=B/"arc-column-work-learning-20261013"
FAMILY=B/"arc-current-family-source-20261013"
CORE=B/"arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2"
RAW=B/"arc-column-teacher-recovery-20261013/public-recording-v2.jsonl"
RAW_SHA="e26ff1df251af042911126a067c08ee25973b01d3389269472eed6859a4383f2"
ROWS=tuple(range(59))
ANSWERS=(12,43,59,256)
GOALS=((1,59),(226,256))
ACTIONS=((1,59),)
MIB=1048576
OWNER=None
# DEPENDENCIES is appended during source preparation from pinned recovered manifests.
def eq(a,b):
 if type(a) is not type(b):return False
 if isinstance(a,dict):return len(a)==len(b) and all(eq(k,l) and eq(a[k],b[l]) for k,l in zip(a,b))
 if isinstance(a,(list,tuple)):return len(a)==len(b) and all(eq(x,y) for x,y in zip(a,b))
 return a==b
def jb(x):return json.dumps(x,ensure_ascii=False,separators=(",",":"),allow_nan=False).encode()
def sha(p):
 h=hashlib.sha256()
 with Path(p).open("rb") as f:
  for v in iter(lambda:f.read(65536),b""):h.update(v)
 return h.hexdigest()
def identity(p):
 s=Path(p).stat();return [s.st_dev,s.st_ino,s.st_size,s.st_mode,s.st_mtime_ns,s.st_ctime_ns]
def ref(p):return {"path":str(p),"bytes":Path(p).stat().st_size,"sha256":sha(p)}
def fsyncdir(p):
 fd=os.open(p,os.O_RDONLY)
 try:os.fsync(fd)
 finally:os.close(fd)
def readref(r,cap=4*MIB):
 p=Path(r["path"])
 if set(r)!={"path","bytes","sha256"} or type(r["bytes"]) is not int or r["bytes"]>cap or p.is_symlink() or p.stat().st_size!=r["bytes"] or sha(p)!=r["sha256"]:raise ValueError("exact reference")
 return p.read_bytes()
def guard(category=None,extra=0):
 caps={"source":4*MIB,"state_trace":48*MIB,"failure":12*MIB}
 used={k:sum(p.stat().st_size for p in (ROOT/k).rglob("*") if p.is_file()) if (ROOT/k).exists() else 0 for k in caps}
 if ROOT.is_symlink() or any((ROOT/k).is_symlink() for k in caps):raise ValueError("scope symlink")
 if category is not None and used[category]+extra>caps[category]:raise MemoryError("local category cap")
 if sum(used.values())+extra>64*MIB:raise MemoryError("64MiB total")
 if shutil.disk_usage(B).free<(1024+1052)*MIB:raise MemoryError("disk1GiB+full1052MiB future")
 mem=next(int(z.split()[1])*1024 for z in open("/proc/meminfo") if z.startswith("MemAvailable:"))
 if mem<(4096+2048)*MIB:raise MemoryError("retained4GiB+floor2GiB")
 return {"used":used,"MemAvailable":mem}
class Clock:
 def __init__(self):
  self.remaining={"compute":600.0,"save":120.0};self.mode=None;self.started=None
  signal.signal(signal.SIGALRM,self.expire)
 def expire(self,*a):raise TimeoutError("column "+str(self.mode)+" aggregate deadline")
 def stop(self):
  signal.setitimer(signal.ITIMER_REAL,0)
  if self.mode is not None:self.remaining[self.mode]-=time.monotonic()-self.started
  self.mode=None;self.started=None
 def enter(self,mode):
  self.stop()
  if self.remaining[mode]<=0:raise TimeoutError("column "+mode+" exhausted")
  self.mode=mode;self.started=time.monotonic();signal.setitimer(signal.ITIMER_REAL,self.remaining[mode])
class IndexedRows:
 """Original row order/len and exact data projection, lazily reading complete selected rows."""
 def __init__(self,path,digest,allowed,onread=None):
  self.path=Path(path);self.digest=digest;self.allowed=set(allowed);self.onread=onread
  self.offsets=[];self.calls=[];self.cache=None;self.cache_index=None
  self.initial=identity(self.path);h=hashlib.sha256()
  with self.path.open("rb") as f:
   while True:
    at=f.tell();line=f.readline(8*MIB+1)
    if not line:break
    if len(line)>8*MIB:raise MemoryError("raw row8MiB stop")
    h.update(line)
    if line.strip():self.offsets.append({"offset":at,"bytes":len(line),"sha256":hashlib.sha256(line).hexdigest()})
  if h.hexdigest()!=digest or identity(self.path)!=self.initial:raise ValueError("whole raw source closure")
 def __len__(self):return len(self.offsets)
 def __getitem__(self,index):
  if type(index) is not int or index not in self.allowed or not 0<=index<len(self.offsets):raise IndexError("outside fixed teacher evidence rows")
  entry=self.offsets[index]
  with self.path.open("rb") as f:f.seek(entry["offset"]);raw=f.read(entry["bytes"])
  if hashlib.sha256(raw).hexdigest()!=entry["sha256"] or identity(self.path)!=self.initial:raise ValueError("row changed")
  item=json.loads(raw);value=item.get("data",item)
  evidence={"row":index,"raw":entry,"metadata":{k:v for k,v in value.items() if k!="frame"},"phases":[{"index":i,"sha256":hashlib.sha256(jb(frame)).hexdigest(),"height":len(frame),"width":len(frame[0]) if frame else 0} for i,frame in enumerate(value.get("frame",[]))]}
  self.calls.append({"row":index,"raw":entry})
  if self.onread:self.onread(evidence)
  self.cache=value;self.cache_index=index
  return value
 def close_check(self):
  if identity(self.path)!=self.initial or sha(self.path)!=self.digest:raise ValueError("final whole raw closure")
def capture_call(machine,method,external,held):
 previous=sys.getprofile()
 if previous is not None:raise PermissionError("existing profile not displaced")
 target=machine.排気系.排出する;code=target.__func__.__code__;receiver=target.__self__
 held["raw"]=[];held["events"]=[];held["profile_restored"]=False
 def observe(frame,event,arg):
  if event=="call" and frame.f_code is code and frame.f_locals.get("self") is receiver:
   held["raw"].append(frame.f_locals["結果"])
   held["events"].append({"function":code.co_name,"filename":code.co_filename,"firstlineno":code.co_firstlineno,"exact_code_self":True})
 sys.setprofile(observe)
 try:
  held["return"]=getattr(machine,method)(external)
 finally:
  sys.setprofile(previous);held["profile_restored"]=sys.getprofile() is previous
 if len(held["raw"])!=1 or len(held["events"])!=1 or not held["profile_restored"]:raise ValueError("exact single exhaust capture")
 return held["return"]
def snapshot_value(machine):
 e=machine.エンジン
 return {"形式版":3,"最小支持数":e.最小支持数,"最大条件数":e.最大条件数,"識別子状態":e.識別子.状態を書き出す(),"台帳":e.台帳.全取得(),"状態履歴":e.状態.履歴(),"原理履歴":e._原理履歴}
def frame_hash(frame):
 if not frame or not frame[0] or any(len(r)!=len(frame[0]) for r in frame) or any(type(v) is not int or not 0<=v<=15 for r in frame for v in r):raise ValueError("strict uint8 frame")
 return hashlib.sha256(bytes(v for r in frame for v in r)).hexdigest()
class APIView:
 """External measurement wrapper. Does not replace any core/module/instance method."""
 def __init__(self,owner):self.owner=owner
 def 処理する(self,external):return self.owner.call("処理する",external)
 def 照会する(self,external):return self.owner.call("照会する",external)
class Run:
 def __init__(self):
  self.clock=Clock();self.machine=None;self.modules=[];self.pending=None;self.current=None
  self.calls=[];self.rows_seen={};self.errors=[];self.exceptions=[];self.gate=None;self.complete=False
  self.trace_bytes=0;self.state_refs=[];self.phase="preflight";self.frame_ordinal=None;self.raw_observers=[]
 def encoded(self,v):
  x=self.enc(v);raw=jb(x);again=self.dec(json.loads(raw))
  if not eq(self.enc(again),x):raise ValueError("normal codec full types/order")
  return raw
 def save(self,name,value,category="state_trace",codec=True):
  self.pending={"name":name,"value":value};primary=None;self.clock.enter("save")
  try:
   raw=self.encoded(value) if codec else jb(value)
   if len(raw)>16*MIB:raise MemoryError("journal raw16MiB stop")
   blob=lzma.compress(raw,preset=0,check=lzma.CHECK_CRC64)
   if category=="state_trace" and self.trace_bytes+len(blob)>24*MIB:raise MemoryError("trace24MiB aggregate")
   guard(category,len(blob));folder=ROOT/category/self.gate["nonce"];folder.mkdir(exist_ok=True)
   p=folder/(name+".json.xz")
   with p.open("xb") as f:
    if f.write(blob)!=len(blob):raise OSError("short write")
    f.flush();os.fsync(f.fileno())
   fsyncdir(folder);fsyncdir(folder.parent)
   back=p.read_bytes();z=lzma.LZMADecompressor();decoded=z.decompress(back,max_length=16*MIB+1)
   if back!=blob or not z.eof or z.unused_data or z.check!=lzma.CHECK_CRC64 or decoded!=raw:raise ValueError("full journal CRC64/EOF/bytes")
   if category=="state_trace":self.trace_bytes+=len(blob)
   result={"file":ref(p),"rawbytes":len(raw),"rawsha256":hashlib.sha256(raw).hexdigest()}
   self.pending=None;return result
  except BaseException as e:primary=e;self.exceptions.append(e);raise
  finally:
   self.clock.stop()
   if primary is None:self.clock.enter("compute")
 def standard(self,label):
  primary=None;self.clock.enter("save")
  folder=ROOT/"state_trace"/self.gate["nonce"];folder.mkdir(exist_ok=True)
  p=folder/(label+".standard.json");self.pending={"standard":str(p)}
  try:
   guard("state_trace",8*MIB)
   fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600);oldstat=os.fstat(fd);os.close(fd);fsyncdir(folder)
   limits=resource.getrlimit(resource.RLIMIT_FSIZE);handler=signal.signal(signal.SIGXFSZ,lambda *a:(_ for _ in ()).throw(OSError("standard8MiB cap")))
   try:
    resource.setrlimit(resource.RLIMIT_FSIZE,(8*MIB,limits[1]));self.machine.保存する(p)
   finally:
    resource.setrlimit(resource.RLIMIT_FSIZE,limits);signal.signal(signal.SIGXFSZ,handler)
   fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
   try:
    st=os.fstat(fd)
    if (st.st_dev,st.st_ino)!=(oldstat.st_dev,oldstat.st_ino) or st.st_size>8*MIB:raise ValueError("reserved standard identity")
    os.fsync(fd)
   finally:os.close(fd)
   fsyncdir(folder);raw=p.read_bytes();value=self.dec(json.loads(raw))
   if not eq(self.enc(value),self.enc(snapshot_value(self.machine))):raise ValueError("full live standard value")
   if json.dumps(self.enc(value),ensure_ascii=False,indent=2).encode()!=raw:raise ValueError("standard byte/type/order roundtrip")
   r=ref(p);self.state_refs.append(r);self.pending=None;return r,value
  except BaseException as e:primary=e;self.exceptions.append(e);raise
  finally:
   self.clock.stop()
   if primary is None:self.clock.enter("compute")
 def markers(self):
  e=self.machine.エンジン
  return {"identifiers":e.識別子.状態を書き出す(),"ledger_lengths":{k:len(v) for k,v in e.台帳.全取得().items()},"principle_history_lengths":{k:len(v) for k,v in e._原理履歴.items()},"state_history_length":len(e.状態.履歴())}
 def call(self,method,external):
  if len(self.calls)>=27:raise PermissionError("API ceiling")
  if self.phase=="before_action_mapping":
   if method!="照会する" or self.calls or external.内容!={"解答作業":"選択記号を空欄へ割当"} or external.対象系境界!=self.family.作用境界:raise PermissionError("before mapping only")
  else:
   t=self.pack["teachers"][self.frame_ordinal]
   wanted="処理する" if self.phase=="additional_teachers" else "照会する" if self.phase=="regression_queries" else None
   values=t["teacher"] if wanted=="処理する" else t["query_input"]
   if method!=wanted or not eq(external.内容,values) or external.対象系境界!=t["boundary"]:raise PermissionError("exact typed teacher/query boundary")
  i=len(self.calls)
  # Observe teacher locals only for provenance. They never enter API content.
  origin={};f=sys._getframe()
  while f:
   if f.f_code is self.trainer.教師を取り込む.__code__:
    origin={k:f.f_locals[k] for k in ("i","origin","measurement") if k in f.f_locals};break
   f=f.f_back
  del f
  self.current={"ordinal":i,"phase":self.phase,"frame_ordinal":self.frame_ordinal,"method":method,"input":external,"origin":origin,"before":self.markers(),"capture":{}}
  intent=self.save("api_%04d_intent"%i,self.current)
  result=capture_call(self.machine,method,external,self.current["capture"])
  self.pool_returns.append((external,result))
  self.current["after"]=self.markers()
  reply=self.save("api_%04d_reply"%i,self.current)
  self.calls.append({"ordinal":i,"method":method,"phase":self.phase,"intent":intent,"reply":reply})
  self.current=None
  return result
 def row_read(self,evidence):
  n=str(evidence["row"])
  if n not in self.rows_seen:self.rows_seen[n]=self.save("teacher_row_%03d_all_phases"%int(n),evidence,codec=False)
 def load_module(self,name,path):
  sp=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(sp);self.modules.append(m);sp.loader.exec_module(m);return m
 def preflight(self,path,digest):
  raw=readref({"path":str(path),"bytes":Path(path).stat().st_size,"sha256":digest},65536);g=json.loads(raw);self.gate=g
  if g["schema"]!="column-work-learning-release-v1" or g["enabled"] is not True or g["source_sha256"]!=sha(__file__):raise PermissionError("exact native root gate")
  if type(g["nonce"])is not str or len(g["nonce"])!=32 or any(c not in "0123456789abcdef" for c in g["nonce"]):raise ValueError("nonce")
  if time.time()>g["admission_deadline_epoch"] or g["limits"]!={"AS":512*MIB,"compute":600,"save":120}:raise PermissionError("finite gate")
  if g.get("teacher_pack_approved")is not True:raise PermissionError("root pack adoption")
  contract=json.loads(readref(g["contract"]))
  if contract["source"]!=ref(Path(__file__)):raise ValueError("contract source")
  pp=contract["pack_source"];readref(pp)
  self.pack_module=self.load_module("pinned_work_pack",Path(pp["path"]))
  enc,dec=self.pack_module.codec();self.pack=self.pack_module.read_packet(g["teacher_pack"],enc,dec)
  actual=self.pack_module.build()
  if not eq(self.pack,actual) or len(self.pack["teachers"])!=13:raise ValueError("all59 teacher packet regeneration")
  self.pack_evidence=g["teacher_pack"]
  for t in self.pack["teachers"]:
   if list(t["query_input"])!=[self.pack_module.X] or list(t["teacher"])!=[self.pack_module.X,self.pack_module.Y] or any(type(v)is not bool for v in t["teacher"].values()):raise ValueError("two strict bools")
  if g["baseline_state"]!={"path":str(B/"arc-column-goal-pools-20261013/state_trace/6a947066e1a16bf2b668ea7af1a7e51b/after_goal_pools.standard.json"),"bytes":2197297,"sha256":"e72f3f02bfbaabea3a9f366d790ce53b7e2063e9960048085e0699a0d82ee133"}:raise ValueError("exact pool finalstate")
  readref(g["baseline_state"],8*MIB)
  audit=json.loads(readref(g["baseline_audit"]))
  if audit["schema"]!="column-goal-pools-independent-audit-v1" or audit["status"]!="PASS" or audit["errors"] or len(audit["verified"])!=4 or any(v is not True for v in audit["verified"].values()):raise ValueError("pool independent PASS")
  completed=g["baseline_completion"];z=lzma.LZMADecompressor();raw=z.decompress(readref(completed["file"]),max_length=16*MIB+1)
  if not z.eof or z.unused_data or z.check!=lzma.CHECK_CRC64 or len(raw)!=completed["rawbytes"] or hashlib.sha256(raw).hexdigest()!=completed["rawsha256"]:raise ValueError("pool completion bytes")
  c=json.loads(raw)
  if c["status"]!="complete" or c["errors"] or c["states"][-1]!=g["baseline_state"] or c["case_count"]!=59 or c["teach_calls"]!=0 or c["query_calls"]!=236:raise ValueError("pool closure")
  ex=json.loads(readref(g["baseline_actual_exit"],65536));lines=ex.get("output","").splitlines()
  if ex.get("exit_code")!=0 or len(lines)!=2 or not lines[1].startswith("UTCEND ") or json.loads(lines[0]).get("receipt")!=completed:raise ValueError("pool actual exit")
  # Root supplies exact independent report; bind its measured state/nonce references structurally.
  if g["baseline_audit"]!={"path":str(B/"arc-column-learning-audit-20261013/result/pool_audit_summary_v1.json"),"bytes":210766,"sha256":"7e9515fa6ae2e88ae61868603639ad957ed4f1544053154d91a9b93c96b37a6f"}:raise ValueError("pool actual audit pin")
  for r in DEPENDENCIES:readref(r,4*MIB)
  guard()
  sys.dont_write_bytecode=True;sys.path.insert(0,str(CORE));sys.path.insert(0,str(FAMILY))
  import hds学習系統 as native
  import hds学習系統.永続化 as persistence
  if Path(native.__file__).resolve()!=CORE/"hds学習系統/__init__.py":raise ValueError("core import identity")
  self.native=native;self.enc=persistence._符号化;self.dec=persistence._復号
  self.trainer=self.load_module("pinned_column_teacher",FAMILY/"道具/列図式教師検証.py")
  from 接続 import 列図式規則 as family
  if Path(family.__file__).resolve()!=FAMILY/"接続/列図式規則.py":raise ValueError("family import identity")
  self.family=family
  self.save("all59_teacher_pack",self.pack)
 def execute(self):
  self.machine=self.native.HDS学習系統.読み込む(self.gate["baseline_state"]["path"])
  initial,old=self.standard("restored_before")
  if initial["bytes"]!=self.gate["baseline_state"]["bytes"] or initial["sha256"]!=self.gate["baseline_state"]["sha256"]:raise ValueError("restored standard raw exact")
  self.pool_returns=[];view=APIView(self);self.phase="before_action_mapping";self.frame_ordinal=None
  number,mapping=self.family.照会(view,self.family.作用境界,{"解答作業":"選択記号を空欄へ割当"},"必要行動ID")
  mapping_ref=self.save("before_action_mapping",{"number":number,"mapping":mapping,"API":self.calls[-1]})
  if type(number)is not int or number!=6 or not self.family._参照群(mapping):raise ValueError("learned supported click correspondence not established")
  self.phase="additional_teachers";records=[]
  for t in self.pack["teachers"]:
   self.frame_ordinal=t["ordinal"]
   result=self.call("処理する",self.native.外部入力(dict(t["teacher"]),t["boundary"]))
   records.append({"teacher":t,"API":self.calls[-1],"external_return":result})
  teachers_ref=self.save("all13_teachers",records)
  trained,learned=self.standard("after_teachers")
  for name,prior in old["台帳"].items():
   if not eq(self.enc(learned["台帳"][name][:len(prior)]),self.enc(prior)):raise ValueError("old ledger prefix changed "+name)
  if not eq(self.enc(learned["状態履歴"][:len(old["状態履歴"])]),self.enc(old["状態履歴"])):raise ValueError("old state history prefix")
  for name,prior in old["原理履歴"].items():
   if not eq(self.enc(learned["原理履歴"][name][:len(prior)]),self.enc(prior)):raise ValueError("old principle versions changed")
  if learned["識別子状態"].get("経験",0)-old["識別子状態"].get("経験",0)!=13:raise ValueError("exact13 new experiences")
  if any(learned["識別子状態"].get(k,0)-old["識別子状態"].get(k,0)!=1 for k in ("照会","学習判定")):raise ValueError("single before mapping query")
  self.phase="regression_queries";replies=[]
  for t in self.pack["teachers"]:
   self.frame_ordinal=t["ordinal"]
   result=self.call("照会する",self.native.外部入力(dict(t["query_input"]),t["boundary"]))
   replies.append({"ordinal":t["ordinal"],"row":t["row"],"API":self.calls[-1],"reply":result})
  # All raw/native/external replies are durable before after labels enter scoring.
  reply_ref=self.save("all13_query_replies",replies)
  final,last=self.standard("after_queries")
  expected=self.dec(self.enc(learned))
  for key in ("照会","学習判定"):expected["識別子状態"][key]=expected["識別子状態"].get(key,0)+13
  if not eq(self.enc(last),self.enc(expected)):raise ValueError("query whole state except paired counters unchanged")
  scoring=[]
  for t,item in zip(self.pack["teachers"],replies):
   r=item["reply"];pred=r.内容.get("予測群",[]);wanted=[p for p in pred if tuple(p["結果経路"])==(self.pack_module.Y,)]
   values=[p["予測値"] for p in wanted]
   scoring.append({"ordinal":t["ordinal"],"row":t["row"],"expected":t["teacher"][self.pack_module.Y],"all_predictions":pred,"result_values":values,
    "correct":bool(values) and all(type(v)is bool and v is t["teacher"][self.pack_module.Y] for v in values),
    "wrong":any(type(v)is not bool or v is not t["teacher"][self.pack_module.Y] for v in values),
    "missing":not values,"extra":[p for p in pred if tuple(p["結果経路"])!=(self.pack_module.Y,)],"HOLD":r.状態=="断定保留","external_state":r.状態})
  scoring_ref=self.save("external_scoring",scoring)
  if len(self.calls)!=27 or sum(c["method"]=="処理する" for c in self.calls)!=13:raise ValueError("exact API counts")
  self.summary={"schema":"column-work-learning-completion-v1","nonce":self.gate["nonce"],"status":"complete","errors":[],
   "source":ref(Path(__file__)),"teacher_pack":self.pack_evidence,"baseline_state":self.gate["baseline_state"],"baseline_audit":self.gate["baseline_audit"],
   "states":self.state_refs,"api_calls":self.calls,"mapping":mapping_ref,"teachers":teachers_ref,"queries":reply_ref,"scoring":scoring_ref,
   "teach_calls":13,"query_calls":14,"regression_queries":13,"Action":0,"new_clear":0,"old_78_ledger_prefix_unchanged":True,
   "limits":"13 correlated public actions; same-trajectory regression only; unselected46 remain uninterpreted, not False."}
  out=self.save("completion",self.summary,codec=False);self.complete=True;return out

def run(path,digest):
 global OWNER
 if OWNER is not None:raise RuntimeError("one run only")
 OWNER=Run()
 try:
  soft,hard=resource.getrlimit(resource.RLIMIT_AS)
  if not (0<soft<=512*MIB and 0<hard<=512*MIB):raise PermissionError("finite AS512 before import")
  OWNER.clock.enter("compute");OWNER.preflight(path,digest);result=OWNER.execute();OWNER.clock.stop()
  print(json.dumps({"status":"complete","receipt":result,"Teach":OWNER.summary["teach_calls"],"Query":OWNER.summary["query_calls"],"Action":0}),flush=True)
  return result
 except BaseException as e:
  OWNER.clock.stop();OWNER.exceptions.append(e);OWNER.errors.append(traceback.format_exc())
  original_pending=OWNER.pending
  try:
   if OWNER.gate:
    OWNER.save("failure",{"errors":OWNER.errors,"current":OWNER.current,"completed_api_calls":OWNER.calls,"states":OWNER.state_refs,"pending_descriptor":str(OWNER.pending.get("name")) if OWNER.pending else None},category="failure",codec=hasattr(OWNER,"enc"))
  except BaseException as secondary:OWNER.exceptions.append(secondary);OWNER.errors.append(traceback.format_exc())
  finally:OWNER.clock.stop();OWNER.pending=original_pending
  print(json.dumps({"status":"failed_held","errors":OWNER.errors},ensure_ascii=False),flush=True)
  while True:time.sleep(60)

DEPENDENCIES=[{'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/README.md', 'bytes': 622, 'sha256': 'fcb579bf30bf51a3d45d1935ba6c58c79baeef9c2c95df3c27046641e6f176d6'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/__init__.py', 'bytes': 527, 'sha256': 'eaed97760656afc40088ad7e0d85a02fbd59a0d0034054956e9ead63319fba57'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/台帳.py', 'bytes': 2815, 'sha256': 'a6cab8fca7cb591c42fa7444f9678fe0003da69faafcce852598286dceb522e2'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/吸気系.py', 'bytes': 3061, 'sha256': '50c48e5a9a8aa39158d0cdaacc0501608a829486960d41cb2fea6cb02e5660a4'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/型.py', 'bytes': 6575, 'sha256': 'aa1241708655280b36564f5e3ff6968849b4d09790b8932aabad1570cbca302c'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/実行系.py', 'bytes': 34178, 'sha256': '11d253705181873bcc22e312a0d0a2198fe16a82e3d7289ea8746fdc14695429'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/懐疑.py', 'bytes': 3392, 'sha256': 'bb7e85c2dbafbd430f1b7733bf3a2d307dc24e3227e79994b491cf711322f715'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/排気系.py', 'bytes': 2779, 'sha256': '2ba7ceb8d0d6c784d092f91fe484477127f044e50f68c54c977374b17f2f6361'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/推論.py', 'bytes': 11404, 'sha256': '315dd0d23a9682cdf14be71346341976cbdbcd2cbd924a250afc4ad53058dba6'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/検証.py', 'bytes': 2696, 'sha256': 'e23f271d38e1f52d75557dbf3342abf7b59a85fbdc315a06c0040fd7ca204eb3'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/永続化.py', 'bytes': 3125, 'sha256': '8aa431b3012424fd8347c5b3d93a5fbf2218d35020836f5d40abb427f9d6da0d'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/系統.py', 'bytes': 1951, 'sha256': 'f57e34fcab9249ad7fef72d7b9088fbb440c01afcd4313c9447b7a31427bd4a5'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/適応.py', 'bytes': 10139, 'sha256': 'c74797d49472646010ed0b37bd17dfa602084ba3347ac9386dec265e78a797ac'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/pyproject.toml', 'bytes': 173, 'sha256': 'c0d318c4a533f7ad7a2fe6f141cc44480a718def8c9794caf4a866e89b63961e'}, {'path': '/workspace/scratch/a94ff513b3af/arc-current-family-source-20261013/接続/列図式規則.py', 'bytes': 20302, 'sha256': 'd303b314446d22c604008d590636cccf6e1d140fbd365f22ff018b55d97de399'}, {'path': '/workspace/scratch/a94ff513b3af/arc-current-family-source-20261013/道具/列図式教師検証.py', 'bytes': 11873, 'sha256': 'f8a6bbca6a557973a7f54bdf0af8e85ed0419fcf5b463e10dcc310160245bc28'}, {'path': '/workspace/scratch/a94ff513b3af/arc-current-family-source-20261013/検証/test_列図式規則.py', 'bytes': 9912, 'sha256': '6202f490248cfd5f3734338b2bd119fedfe373c31b5abb6213119b1e07a91769'}, {'path': '/workspace/scratch/a94ff513b3af/arc-current-family-source-20261013/接続/列図式規則.md', 'bytes': 6946, 'sha256': 'b4e865988b1453cc350052e3300891d1935e745c92883b6dec4f327776df7569'}, {'path': '/workspace/scratch/a94ff513b3af/arc-current-family-source-20261013/接続/ARC3境界.py', 'bytes': 9941, 'sha256': 'ed95bb80f2326827c3f1237537a3df33203af8cac7881e46fd8b4d17e439d358'}, {'path': '/workspace/scratch/a94ff513b3af/arc-current-family-source-20261013/接続/図式観測.py', 'bytes': 1295, 'sha256': '417269f9e94ec548c7f727c3e263efe952bbae21cf601021bcfd4d89b1a786d2'}]
