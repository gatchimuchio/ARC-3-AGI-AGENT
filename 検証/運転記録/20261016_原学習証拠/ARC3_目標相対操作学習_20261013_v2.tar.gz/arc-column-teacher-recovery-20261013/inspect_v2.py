import pathlib,json,hashlib,resource,time,os,sys,collections,signal
resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
P=pathlib.Path(__file__).resolve().parent;C=json.loads((P/'contract-v2.json').read_text());start=time.monotonic()
def stamp():return time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
def put(name,obj):
 b=(json.dumps(obj,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode();assert len(b)<8*1024**2
 assert sum(f.stat().st_size for f in P.iterdir() if f.is_file())+len(b)<=C['scope_cap']
 with (P/name).open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
 d=os.open(P,os.O_RDONLY);os.fsync(d);os.close(d)
def deadline(s,f):raise TimeoutError('audit_deadline')
signal.signal(signal.SIGALRM,deadline);signal.alarm(120)
rows=[];errors=[];games=collections.Counter();states=collections.Counter();actions=collections.Counter();keysets=collections.Counter();framed=0;frames_total=0;frame_max=0;frame_errors=0;pixel_errors=0;maxline=0;count=0;bytecount=0;h=hashlib.sha256();rc=1
report={'schema':'column-teacher-jsonl-audit-v2','started':stamp(),'HDS_calls':0,'SDK_calls':0,'environment_actions':0,'game_success_claimed':False,'line_limit_bytes':C['line_cap']}
try:
 with (P/C['raw_filename']).open('rb') as f:
  while True:
   line=f.readline(C['line_cap']+1)
   if not line:break
   i=count;count+=1;n=len(line);h.update(line);bytecount+=len(line)
   if n>C['line_cap']:
    ends=line.endswith(b'\n')
    while not ends:
     extra=f.readline(65536)
     if not extra:break
     n+=len(extra);h.update(extra);bytecount+=len(extra);ends=extra.endswith(b'\n')
    maxline=max(maxline,n);errors.append({'line':i,'type':'line_limit_UNKNOWN','bytes':n});rows.append({'line':i,'bytes':n,'state':'UNKNOWN'});continue
   maxline=max(maxline,n)
   try:obj=json.loads(line)
   except Exception as e:errors.append({'line':i,'type':type(e).__name__});continue
   if not isinstance(obj,dict):errors.append({'line':i,'type':'not_object'});continue
   data=obj.get('data',obj)
   if not isinstance(data,dict):errors.append({'line':i,'type':'data_not_object'});continue
   keysets[','.join(sorted(data))]+=1
   row={'line':i,'bytes':n,'data_keys':sorted(data)}
   for k in ('game_id','state','score','win_score','levels_completed','win_levels','full_reset','available_actions','action_input'):
    if k in data:row[k]=data[k]
   if isinstance(data.get('game_id'),str):games[data['game_id']]+=1
   if isinstance(data.get('state'),str):states[data['state']]+=1
   action=data.get('action_input')
   if isinstance(action,dict):action=action.get('id',action.get('name'))
   if isinstance(action,(str,int)):actions[str(action)]+=1
   frames=data.get('frame')
   if frames is not None:
    if not isinstance(frames,list):frame_errors+=1
    else:
     framed+=1;frames_total+=len(frames);frame_max=max(frame_max,len(frames));row['frame_count']=len(frames)
     shapes=collections.Counter()
     for frame in frames:
      if not isinstance(frame,list) or not 1<=len(frame)<=64 or any(not isinstance(r,list) for r in frame):frame_errors+=1;continue
      widths={len(r) for r in frame}
      if len(widths)!=1 or not 1<=next(iter(widths))<=64:frame_errors+=1;continue
      shapes[str(len(frame))+'x'+str(next(iter(widths)))]+=1
      if any(type(x)is not int or not 0<=x<=15 for r in frame for x in r):pixel_errors+=1
     row['frame_shapes']=dict(shapes)
   rows.append(row);del obj,data,line
 report.update({'state':'complete','bytes_streamed':bytecount,'sha256':h.hexdigest(),'expected_digest_matches':h.hexdigest()==C['expected_sha256'],'jsonl_lines':count,'object_rows':len(rows),'json_errors':errors,'maximum_line_bytes':maxline,'frame_rows':framed,'total_frames':frames_total,'maximum_frames_per_row':frame_max,'frame_shape_errors':frame_errors,'pixel_domain_error_frames':pixel_errors,'game_ids':dict(games),'states':dict(states),'action_id_counts':dict(actions),'data_keysets':dict(keysets)})
 rc=0 if not errors and not frame_errors and not pixel_errors and report['expected_digest_matches'] else 2
except Exception as e:report.update({'state':'failed','error_type':type(e).__name__,'rows_examined':count})
finally:
 signal.alarm(0);report.update({'finished':stamp(),'duration_seconds':round(time.monotonic()-start,3),'requested_exit':rc})
 put('row-metadata-v2.json',rows);put('structure-v2-receipt.json',report)
print(json.dumps(report,ensure_ascii=False,sort_keys=True));sys.exit(rc)
