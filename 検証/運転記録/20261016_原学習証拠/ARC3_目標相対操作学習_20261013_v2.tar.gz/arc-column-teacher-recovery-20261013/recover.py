import pathlib,os,sys,json,hashlib,resource,signal,time,logging,http.client,shutil,collections
logging.disable(logging.CRITICAL);http.client.HTTPConnection.debuglevel=0
resource.setrlimit(resource.RLIMIT_AS,(134217728,134217728));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
P=pathlib.Path(__file__).resolve().parent; C=json.loads((P/'contract.json').read_text())
def stamp():return time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
def size():return sum(f.stat().st_size for f in P.iterdir() if f.is_file())
def put(name,obj):
    b=(json.dumps(obj,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode()
    if len(b)>4194304 or size()+len(b)>67108864:raise RuntimeError('scope_cap')
    with (P/name).open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
    fd=os.open(P,os.O_RDONLY);os.fsync(fd);os.close(fd)
def check():
    if shutil.disk_usage(P).free<C['physical_free_floor']:raise RuntimeError('disk_floor')
    mem=int(next(x.split()[1] for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
    if mem<C['memory_floor']:raise RuntimeError('memory_floor')
def deadline(s,f):raise TimeoutError('download_deadline')
signal.signal(signal.SIGALRM,deadline)
report={'schema':'column-teacher-recovery-receipt-v1','started':stamp(),'url':C['source_url'],'expected_sha256':C['expected_sha256'],'HDS_calls':0,'SDK_calls':0,'environment_actions':0,'game_success_claimed':False}
start=time.monotonic();written=0;rc=1;raw=P/'public-recording.jsonl'
try:
    check();report['disk_free_before']=shutil.disk_usage(P).free
    put('request-start.json',{'url':C['source_url'],'started':stamp(),'headers':'no authentication','timeout':120})
    import requests
    signal.alarm(120)
    with requests.get(C['source_url'],timeout=(15,120),stream=True,allow_redirects=False) as response:
        report['http_status']=response.status_code;report['content_type']=response.headers.get('Content-Type')
        report['content_length_header']=response.headers.get('Content-Length')
        with raw.open('xb') as f:
            try:
                for block in response.iter_content(65536):
                    check()
                    remain=C['raw_cap']-written
                    if len(block)>remain:
                        if remain:f.write(block[:remain]);written+=remain
                        raise RuntimeError('raw_cap_exceeded_partial_retained')
                    f.write(block);written+=len(block)
            finally:f.flush();os.fsync(f.fileno())
    signal.alarm(0)
    fd=os.open(P,os.O_RDONLY);os.fsync(fd);os.close(fd)
    report['download_seconds']=round(time.monotonic()-start,3)
    h=hashlib.sha256()
    with raw.open('rb') as f:
        for block in iter(lambda:f.read(65536),b''):h.update(block)
    report['bytes']=raw.stat().st_size;report['sha256']=h.hexdigest();report['fsync_and_readback']=report['bytes']==written
    report['digest_matches']=report['sha256']==C['expected_sha256']
    if report['http_status']!=200:raise RuntimeError('http_status')
    if not report['digest_matches']:raise RuntimeError('digest_mismatch')
    put('download-verified.json',report)
    keys=collections.Counter();games=collections.Counter();states=collections.Counter();actions=collections.Counter();frame_counts=[];metadata=[];errors=[];line_count=0;blank=0;frames_total=0;frame_shape_errors=0
    with raw.open('rb') as f:
        for i,line in enumerate(f):
            line_count+=1
            if not line.strip():blank+=1;continue
            try:obj=json.loads(line)
            except Exception as e:errors.append({'line':i,'type':type(e).__name__});continue
            if not isinstance(obj,dict):errors.append({'line':i,'type':'not_object'});continue
            keys.update(obj.keys())
            row={'line':i}
            for k in ('game_id','state','levels_completed','win_levels','score','win_score','full_reset','available_actions','action','action_input'):
                if k in obj:row[k]=obj[k]
            if isinstance(obj.get('game_id'),str):games[obj['game_id']]+=1
            if isinstance(obj.get('state'),str):states[obj['state']]+=1
            a=obj.get('action',obj.get('action_input'))
            if isinstance(a,dict):a=a.get('id',a.get('name'))
            if isinstance(a,(int,str)):actions[str(a)]+=1
            frames=obj.get('frame')
            if frames is not None:
                if not isinstance(frames,list):frame_shape_errors+=1
                else:
                    count=len(frames);frames_total+=count;frame_counts.append({'line':i,'frames':count});row['frames']=count
                    for frame in frames:
                        if not isinstance(frame,list) or not frame or any(not isinstance(r,list) for r in frame):frame_shape_errors+=1;continue
                        widths={len(r) for r in frame}
                        if len(widths)!=1 or not widths or max(widths)>64 or len(frame)>64:frame_shape_errors+=1
            metadata.append(row)
    structure={'jsonl_lines':line_count,'blank_lines':blank,'json_object_lines':len(metadata),'errors':errors,'top_level_keys':dict(keys),'game_ids':dict(games),'states':dict(states),'actions':dict(actions),'frame_rows':len(frame_counts),'total_frames':frames_total,'frame_counts':frame_counts,'frame_shape_errors':frame_shape_errors,'metadata':metadata,'game_success_claimed':False}
    put('structure-audit.json',structure)
    report.update({'state':'complete','jsonl_lines':line_count,'json_object_lines':len(metadata),'frame_rows':len(frame_counts),'total_frames':frames_total,'frame_shape_errors':frame_shape_errors,'json_errors':len(errors),'game_ids':dict(games)})
    rc=0 if not errors and not frame_shape_errors else 2
except Exception as e:
    report.update({'state':'failed','error_type':type(e).__name__,'bytes_retained':raw.stat().st_size if raw.exists() else 0})
finally:
    signal.alarm(0)
    report.update({'finished':stamp(),'elapsed_seconds':round(time.monotonic()-start,3),'requested_exit':rc,'scope_bytes_before_receipt':size()})
    put('receipt.json',report)
print(json.dumps(report,ensure_ascii=False,sort_keys=True));sys.exit(rc)
