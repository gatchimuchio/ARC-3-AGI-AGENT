import json,pathlib,os,sys,resource,logging,http.client,time,signal,hashlib,shutil
logging.disable(logging.CRITICAL);http.client.HTTPConnection.debuglevel=0
resource.setrlimit(resource.RLIMIT_AS,(134217728,134217728));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
P=pathlib.Path(__file__).resolve().parent;C=json.loads((P/'contract-v2.json').read_text());raw=P/C['raw_filename'];start=time.monotonic();written=0;rc=1
def stamp():return time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
def put(name,obj):
 b=(json.dumps(obj,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode()
 assert sum(f.stat().st_size for f in P.iterdir() if f.is_file())+len(b)<=C['scope_cap']
 with (P/name).open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
 d=os.open(P,os.O_RDONLY);os.fsync(d);os.close(d)
def check():
 if shutil.disk_usage(P).free<C['physical_free_floor']:raise RuntimeError('disk_floor')
 mem=int(next(x.split()[1] for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
 if mem<C['memory_floor']:raise RuntimeError('memory_floor')
def deadline(s,f):raise TimeoutError('deadline')
signal.signal(signal.SIGALRM,deadline)
r={'schema':'column-teacher-download-v2','started':stamp(),'url':C['source_url'],'expected_sha256':C['expected_sha256'],'SDK_calls':0,'HDS_calls':0,'environment_actions':0,'partial_files_deleted':False}
try:
 check();r['disk_free_before']=shutil.disk_usage(P).free
 put('request-v2-start.json',r)
 import requests
 signal.alarm(300)
 with requests.get(C['source_url'],stream=True,allow_redirects=False,timeout=(15,300)) as response:
  r.update({'http_status':response.status_code,'content_type':response.headers.get('Content-Type'),'content_length_header':response.headers.get('Content-Length')})
  put('response-v2-headers.json',r)
  if r['content_length_header'] and int(r['content_length_header'])>C['raw_cap']:raise RuntimeError('declared_size_cap')
  with raw.open('xb') as f:
   try:
    for block in response.iter_content(65536):
     check();remaining=C['raw_cap']-written
     if len(block)>remaining:
      if remaining:f.write(block[:remaining]);written+=remaining
      raise RuntimeError('raw_cap_partial_retained')
     f.write(block);written+=len(block)
   finally:f.flush();os.fsync(f.fileno())
 signal.alarm(0)
 d=os.open(P,os.O_RDONLY);os.fsync(d);os.close(d)
 h=hashlib.sha256();read_bytes=0
 with raw.open('rb') as f:
  for block in iter(lambda:f.read(65536),b''):h.update(block);read_bytes+=len(block)
 r.update({'bytes':read_bytes,'sha256':h.hexdigest(),'fsync_readback':read_bytes==written,'digest_matches':h.hexdigest()==C['expected_sha256']})
 if r['http_status']!=200:raise RuntimeError('http_status')
 if not r['digest_matches']:raise RuntimeError('digest_mismatch')
 r['state']='download_verified';rc=0
except Exception as e:r.update({'state':'failed','error_type':type(e).__name__,'bytes_retained':raw.stat().st_size if raw.exists() else 0})
finally:
 signal.alarm(0);r.update({'finished':stamp(),'duration_seconds':round(time.monotonic()-start,3),'requested_exit':rc});put('download-v2-receipt.json',r)
print(json.dumps(r,ensure_ascii=False,sort_keys=True));sys.exit(rc)
