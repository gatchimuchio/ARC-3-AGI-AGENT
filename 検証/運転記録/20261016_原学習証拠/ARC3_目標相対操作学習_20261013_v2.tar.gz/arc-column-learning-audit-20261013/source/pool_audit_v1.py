import resource
resource.setrlimit(resource.RLIMIT_AS,(512<<20,512<<20))
import hashlib
from pathlib import Path
BASE=Path("/workspace/scratch/a94ff513b3af/arc-column-learning-audit-20261013/source/audit_v1.py")
base=BASE.read_bytes()
assert hashlib.sha256(base).hexdigest()=="e95c8a8307be21b9dc9981685fe84d2b41c0a8216b38f45361e47f4a0d267324"
prefix=base.decode().split("def main():",1)[0]
assert prefix.count("(1024+956)*M")==1
exec(compile(prefix.replace("(1024+956)*M","(1024+988)*M"),str(BASE),"exec"),globals())
R=B/"arc-column-goal-pools-20261013"
D=R/"state_trace/6a947066e1a16bf2b668ea7af1a7e51b"
def main():
 global enc,dec,CURSOR
 signal.signal(signal.SIGALRM,timeout);signal.alarm(300);guard()
 contract=js(plain(R/"source/column_pool_contract_v1.json"))
 assert contract["source"]["sha256"]=="323ca84b88818873a94ad53e28689a0f9a3e40c02c461b986f04746edcff2300"
 source=exact(contract["source"]);tree=ast.parse(source)
 deps=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=="DEPENDENCIES" for t in n.targets))
 for ref in deps:exact(ref,4*M)
 sys.dont_write_bytecode=True;sys.path[:0]=[str(CORE),str(F)]
 import hds学習系統.永続化 as codec
 enc,dec=codec._符号化,codec._復号
 from 接続 import 列図式規則 as family
 c=packet({"file":{"path":str(D/"completion.json.xz"),"bytes":55280,"sha256":"9661997070da791166e456010d2208c072e24f668439615d784b4b0e19c92402"},"rawbytes":220979,"rawsha256":"8800496536363748376c726281b15d3f7538e01f766f01261d8aa5d2cbfce741"},False)
 assert c["status"]=="complete" and c["errors"]==[] and c["teach_calls"]==c["Action"]==c["new_clear"]==0 and c["query_calls"]==236 and c["case_count"]==59
 audit=js(exact(c["baseline_audit"]));assert audit["status"]=="PASS" and all(audit["verified"].values())
 predecessor=packet(c["baseline_completion"],False)
 assert predecessor["states"][-1]==c["baseline_state"]==audit["standard_states"][-1]
 exit_tool=js(exact({"path":str(R/"source/native_actual_exit_v1.json"),"bytes":596,"sha256":"b700c1d4dd6e6d114fff371b97bf8f424511cd77c5d2cc82a2bb0314e1e2d95d"}))
 assert exit_tool["exit_code"]==0
 readback=js(exact({"path":str(R/"source/native_full_readback_v1.json"),"bytes":2916,"sha256":"903124e836d455d74ce2b9902867b8473bec2fe8b1ed625b032026ab0f5d9a0c"}))
 plain(R/"source/native_actual_tools_v1.json")
 states=[]
 for ref in c["states"]:
  raw=exact(ref);v=js(raw);x=dec(v)
  assert same(enc(x),v) and json.dumps(v,ensure_ascii=False,indent=2).encode()==raw
  states.append(x)
 before,after=states
 assert exact(c["states"][0])==exact(c["baseline_state"])
 expected=dec(enc(before))
 for key in ("照会","学習判定"):
  assert before["識別子状態"][key]==7 and after["識別子状態"][key]==243
  expected["識別子状態"][key]+=236
 assert same(enc(expected),enc(after))
 CHECKS["baseline_restore_all_raw_bytes_and_whole_state_only_two_counters_plus236"]=True
 histories={p.原理識別子:p for h in before["原理履歴"].values() for p in h}
 experiences={e.経験識別子:e for e in before["台帳"]["観測台帳"]}
 api=[];previous=None
 # Pure external projection, AST extracted from pinned exhaust source; no machine/API instance.
 exhaust=CORE/"hds学習系統/排気系.py"
 fn=next(n for n in ast.walk(ast.parse(exhaust.read_bytes())) if isinstance(n,ast.FunctionDef) and n.name=="排出する")
 ns={"asdict":dataclasses.asdict,"Any":object}
 from hds学習系統.型 import 外部出力,実行結果,学習成立状態
 ns.update(外部出力=外部出力,実行結果=実行結果,学習成立状態=学習成立状態)
 exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])),str(exhaust),"exec"),ns)
 for ordinal,item in enumerate(c["api_calls"]):
  CURSOR="api_"+str(ordinal);assert item["ordinal"]==ordinal and item["method"]=="照会する"
  intent=packet(item["intent"]);reply=packet(item["reply"])
  for key in ("ordinal","phase","frame_ordinal","method","input","origin","before"):assert same(enc(intent[key]),enc(reply[key]))
  assert intent["capture"]=={} and reply["origin"]=={}
  capture=reply["capture"];assert capture["profile_restored"] is True and len(capture["raw"])==len(capture["events"])==1
  event=capture["events"][0];assert event["exact_code_self"] is True and event["function"]=="排出する"
  raw=capture["raw"][0];ret=capture["return"]
  assert same(enc(ns["排出する"](None,raw)),enc(ret))
  assert raw.学習過程.学習成立状態.value=="適用外"
  expected_markers=dec(enc(reply["before"]))
  for key in ("照会","学習判定"):expected_markers["identifiers"][key]+=1
  assert same(expected_markers,reply["after"])
  if previous is not None:assert same(previous,reply["before"])
  previous=reply["after"]
  for p in raw.有効原理群:
   assert same(enc(p),enc(histories[p.原理識別子]))
   assert all(e in experiences for e in p.根拠参照群+p.反証参照群)
  for pred in raw.予測群:
   p=histories[pred.原理参照]
   assert p.対象系境界==reply["input"].対象系境界 and same(pred.結果経路,p.結果経路)
  api.append(reply)
 assert len(api)==236
 CHECKS["all236_actual_inputs_raw_replies_exhaust_projection_support_joins"]=True
 CURSOR="raw_offsets"
 index=pfile("raw_full_offset_index.json.xz",False)
 assert index["source"]["sha256"]=="e26ff1df251af042911126a067c08ee25973b01d3389269472eed6859a4383f2"
 raw_identity=ident(RAW);assert filehash(RAW)==index["source"]["sha256"];IDENT[str(RAW)]=raw_identity
 offsets=[]
 with RAW.open("rb") as f:
  while True:
   at=f.tell();line=f.readline(8*M+1)
   if not line:break
   assert len(line)<=8*M
   if line.strip():offsets.append({"offset":at,"bytes":len(line),"sha256":digest(line)})
 assert same(offsets,index["all_offsets"]) and index["selected_rows"]==list(range(59))
 assert set(map(int,c["row_all_phase_refs"]))==set(range(59))
 class Replay:
  def __init__(self):self.i=0;self.current=[]
  def 照会する(self,x):
   r=api[self.i];assert r["method"]=="照会する" and same(enc(x),enc(r["input"]))
   self.i+=1;self.current.append((x,r["capture"]["return"]));return r["capture"]["return"]
 replay=Replay();summary=[];phases=0
 for row,ref in enumerate(c["pools"]):
  CURSOR="pool_"+str(row)
  with RAW.open("rb") as f:f.seek(offsets[row]["offset"]);line=f.read(offsets[row]["bytes"])
  assert digest(line)==offsets[row]["sha256"]
  v=js(line);v=v.get("data",v);frames=v.get("frame",[])
  evidence={"row":row,"raw":offsets[row],"metadata":{k:x for k,x in v.items() if k!="frame"},"phases":[{"index":j,"sha256":digest(jb(fr)),"height":len(fr),"width":len(fr[0]) if fr else 0} for j,fr in enumerate(frames)]}
  assert same(evidence,packet(c["row_all_phase_refs"][str(row)],False));phases+=len(frames)
  inp={"ordinal":row,"action_row":row+1,"before_row":row,"raw_source":{"path":str(RAW),"sha256":index["source"]["sha256"]},"raw_row":offsets[row],"phase":len(frames)-1,"frame_sha256":digest(jb(frames[-1])),"frame_sha256_uint8":digest(bytes(z for line in frames[-1] for z in line)),"scene":None,"goal_pool":None,"error":None,"api_start":replay.i}
  assert same(enc(inp),enc(pfile("pool_%02d_input.json.xz"%row)))
  scene=family.図式を観測する(frames[-1]);replay.current=[]
  goal=family.内容候補を構成する(replay,scene)
  inp["scene"]=scene;inp["goal_pool"]=goal;inp["status"]="measured";inp["api_end"]=replay.i
  inp["API_records"]=c["api_calls"][inp["api_start"]:inp["api_end"]]
  inp["learned_role_evidence"]=goal.get("照会",{})
  roles=[];supports=[]
  for external,ret in replay.current:
   if external.対象系境界==family.役割境界:
    values={p["予測値"] for p in ret.内容.get("予測群",[]) if tuple(p["結果経路"])==("列展開役割",)}
    if ret.状態!="断定保留" and len(values)==1:roles.append({"記号は中空":external.内容["記号は中空"],"列展開役割":next(iter(values))})
    supports.extend(family._参照群(ret.内容))
  inp["work_measurement_capture"]={"前相画素SHA256":inp["frame_sha256_uint8"],"実照会参照":inp["API_records"],"役割支持参照":list(dict.fromkeys(supports)),"学習役割":roles,"全内容候補返却":goal}
  assert same(enc(inp),enc(packet(ref)))
  assert all(p in histories or p in experiences for p in supports)
  summary.append({"action_row":row+1,"before_row":row,"phase":len(frames)-1,"pool_count":goal.get("候補数"),"status":goal["状態"],"roles":roles,"supports":list(dict.fromkeys(supports)),"tested":goal.get("全数確認した相異なる割当数"),"rejections":goal.get("不採用理由集計")})
 assert len(summary)==59 and replay.i==236
 CHECKS["all59_before_terminal_scene_full_pool_index_roles_and_support_exact"]=True
 def refs(v):
  if isinstance(v,dict):
   if set(v)=={"path","bytes","sha256"} and type(v["path"])is str:exact(v,16*M)
   else:
    for x in v.values():refs(x)
  elif isinstance(v,list):
   for x in v:refs(x)
 refs(c)
 xzcount=0
 for p in sorted(D.iterdir()):
  if p.suffix==".xz":
   raw=unpack(plain(p));v=js(raw);assert jb(v)==raw
   if isinstance(v,dict) and "__辞書__" in v:assert same(enc(dec(v)),v)
   xzcount+=1
 for ref in deps:exact(ref,4*M)
 assert filehash(RAW)==index["source"]["sha256"] and ident(RAW)==raw_identity
 for path,i in IDENT.items():assert ident(Path(path))==i
 CHECKS["all_refs_CRC64_EOF_typed_order_source_core_unchanged"]=True
 result={"schema":"column-goal-pools-independent-audit-v1","status":"PASS","errors":[],"verified":CHECKS,"counts":{"Teach":0,"Query":236,"Action":0,"cases":59,"raw_phases":phases,"XZ_files":xzcount,"native_API_calls_by_auditor":0},"pools":summary,"states":c["states"],"completion":REFS[str(D/"completion.json.xz")],"references":list(REFS.values()),"elapsed_seconds":time.monotonic()-START,"limitations":["Saved reply replay and existing fixed perception/enumeration only; no native Query, restoration, Teach or Action.","This is evidence of teacher-premise queries, not a new gameplay success or causal learning.","All native support/refutation/history retained unchanged in whole standard states."]}
 r=out("pool_audit_summary_v1.json",result);signal.alarm(0);print(json.dumps({"status":"PASS","report":r,"counts":result["counts"]}))
try:main()
except BaseException:
 signal.alarm(0)
 r=out("pool_audit_failure_v1.json",{"status":"FAIL","cursor":CURSOR,"checks":CHECKS,"traceback":traceback.format_exc()},"failure")
 print(json.dumps({"status":"FAIL","failure":r}));raise
