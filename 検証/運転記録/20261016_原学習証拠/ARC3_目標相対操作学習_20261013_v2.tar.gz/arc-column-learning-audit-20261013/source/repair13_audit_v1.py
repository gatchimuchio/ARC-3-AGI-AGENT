import resource
resource.setrlimit(resource.RLIMIT_AS,(512<<20,512<<20))
import hashlib
from pathlib import Path
BASE=Path("/workspace/scratch/a94ff513b3af/arc-column-learning-audit-20261013/source/audit_v1.py")
raw=BASE.read_bytes()
assert hashlib.sha256(raw).hexdigest()=="e95c8a8307be21b9dc9981685fe84d2b41c0a8216b38f45361e47f4a0d267324"
prefix=raw.decode().split("def main():",1)[0]
assert prefix.count("(1024+956)*M")==prefix.count("(4096+2048)*M")==1
exec(compile(prefix.replace("(1024+956)*M","(1024+1092)*M").replace("(4096+2048)*M","(4608+2048)*M"),str(BASE),"exec"),globals())
R=B/"arc-column-work-learning-20261013"
D=R/"state_trace/b0ed233c65f273f9dca51289ed9b80cc"
def main():
 global enc,dec,CURSOR
 signal.signal(signal.SIGALRM,timeout);signal.alarm(300);guard()
 contract=js(plain(R/"source/column_work_contract_v3.json"))
 assert contract["source"]["sha256"]=="f0d73f35a9516eda585b134ae54be9815b36d6164786b9f8a0966c3983640007"
 source=exact(contract["source"]);tree=ast.parse(source)
 deps=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=="DEPENDENCIES" for t in n.targets))
 for ref in deps:exact(ref,4*M)
 exact(contract["outer"]);exact(contract["pack_source"])
 sys.dont_write_bytecode=True;sys.path[:0]=[str(CORE),str(F)]
 import hds学習系統.永続化 as codec
 enc,dec=codec._符号化,codec._復号
 from hds学習系統.型 import 外部出力,実行結果,学習成立状態,外部入力
 c=packet({"file":{"path":str(D/"completion.json.xz"),"bytes":6600,"sha256":"45aaf894d21c2661581b384a8e3e9f2e9769ab8871532b35d39e613a8fb61fa7"},"rawbytes":24112,"rawsha256":"5a4f9dae197167fe7ebf35b3c028a0acd4c008f2cc624e49611fa9e088b2e734"},False)
 assert c["status"]=="complete" and c["errors"]==[] and c["teach_calls"]==13 and c["query_calls"]==14 and c["Action"]==c["new_clear"]==0
 # Exit FileRef is an argument supplied only after actual producer closure.
 exit_ref=js(sys.argv[1]);exit_tool=js(exact(exit_ref))
 assert exit_tool["exit_code"]==0 and "UTCEND " in exit_tool["output"]
 first=json.loads(exit_tool["output"].splitlines()[0]);assert first["receipt"]["file"]==REFS[str(D/"completion.json.xz")]
 previous=js(exact(c["baseline_audit"]));assert previous["status"]=="PASS" and all(previous["verified"].values()) and c["baseline_state"]==previous["states"][-1]
 states=[]
 for ref in c["states"]:
  raw=exact(ref);v=js(raw);x=dec(v)
  assert same(enc(x),v) and json.dumps(v,ensure_ascii=False,indent=2).encode()==raw
  states.append(x)
 old,trained,final=states
 assert exact(c["states"][0])==exact(c["baseline_state"])
 for table,values in old["台帳"].items():assert same(enc(trained["台帳"][table][:len(values)]),enc(values))
 assert same(enc(trained["状態履歴"][:len(old["状態履歴"])]),enc(old["状態履歴"]))
 for name,versions in old["原理履歴"].items():assert same(enc(trained["原理履歴"][name][:len(versions)]),enc(versions))
 assert len(old["台帳"]["観測台帳"])==78 and len(trained["台帳"]["観測台帳"])==91
 assert trained["識別子状態"]["経験"]-old["識別子状態"]["経験"]==13
 expected=dec(enc(trained))
 for key in ("照会","学習判定"):
  assert trained["識別子状態"][key]-old["識別子状態"][key]==1
  expected["識別子状態"][key]+=13
 assert same(enc(expected),enc(final))
 assert old["最小支持数"]==trained["最小支持数"]==3 and old["最大条件数"]==trained["最大条件数"]==2
 CHECKS["normal_restore_old78_all_ledger_history_prefix_and_query_only_counters"]=True
 CURSOR="teacher_projection"
 pack=packet(c["teacher_pack"]);assert same(enc(pack),enc(pfile("all59_teacher_pack.json.xz")))
 pm=load("audit_existing_work_projection",Path(contract["pack_source"]["path"]))
 terminal=packet({"file":pm.TERMINAL,"rawbytes":0,"rawsha256":""},False) if False else None
 blob=exact(pm.TERMINAL);tag=js(unpack(blob));terminal=dec(tag);assert same(enc(terminal),tag)
 assert terminal["状態"]=="complete" and terminal["errors"]==[] and terminal["全行順"]==list(range(1,60))
 allcases=[];teachers=[]
 for i,item in enumerate(terminal["cases"],1):
  case=packet(item["ref"]);assert case["行"]==i and case["教師候補観測"]["行"]==i
  projected=pm.project(case);projected["case_ref"]=item["ref"];allcases.append(projected)
  if projected["decision"]["eligible_before"]:
   teachers.append({"ordinal":len(teachers),"row":i,"case_ref":item["ref"],"query_input":projected["decision"]["query_input"],"teacher":projected["teacher"],"boundary":pm.BOUNDARY})
 assert len(allcases)==59 and len(teachers)==13 and same(enc(allcases),enc(pack["cases"])) and same(enc(teachers),enc(pack["teachers"]))
 for t in teachers:
  assert list(t["teacher"])==[pm.X,pm.Y] and list(t["query_input"])==[pm.X] and all(type(v)is bool for v in t["teacher"].values())
  assert same(t["query_input"],{pm.X:t["teacher"][pm.X]})
 CHECKS["all59_exact_case_projection_13_before_only_two_bool_teachers"]=True
 histories={p.原理識別子:p for h in trained["原理履歴"].values() for p in h}
 observations={e.経験識別子:e for e in trained["台帳"]["観測台帳"]}
 learning={e.学習識別子:e for e in trained["台帳"]["学習過程台帳"]}
 exhaust=CORE/"hds学習系統/排気系.py"
 fn=next(n for n in ast.walk(ast.parse(exhaust.read_bytes())) if isinstance(n,ast.FunctionDef) and n.name=="排出する")
 ns={"asdict":dataclasses.asdict,"Any":object,"外部出力":外部出力,"実行結果":実行結果,"学習成立状態":学習成立状態}
 exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])),str(exhaust),"exec"),ns)
 api=[];teach_results=[];prev=None
 for ordinal,item in enumerate(c["api_calls"]):
  CURSOR="api_"+str(ordinal);assert item["ordinal"]==ordinal
  intent=packet(item["intent"]);reply=packet(item["reply"])
  for key in ("ordinal","phase","frame_ordinal","method","input","origin","before"):assert same(enc(intent[key]),enc(reply[key]))
  assert intent["capture"]=={} and reply["origin"]=={}
  cap=reply["capture"];assert cap["profile_restored"] is True and len(cap["raw"])==len(cap["events"])==1
  assert cap["events"][0]["exact_code_self"] is True and cap["events"][0]["function"]=="排出する"
  raw=cap["raw"][0];ret=cap["return"]
  assert same(enc(ns["排出する"](None,raw)),enc(ret))
  if prev is not None:assert same(prev,reply["before"])
  prev=reply["after"]
  if ordinal==0:
   assert item["method"]=="照会する" and reply["input"].内容=={"解答作業":"選択記号を空欄へ割当"}
  elif ordinal<=13:
   t=teachers[ordinal-1];assert item["method"]=="処理する" and same(enc(reply["input"]),enc(外部入力(t["teacher"],t["boundary"])))
   e=observations[ret.追跡情報["経験参照"]]
   assert same(e.原入力,t["teacher"]) and e.対象系境界==t["boundary"]
   assert same(enc(e),enc(trained["台帳"]["観測台帳"][78+ordinal-1]))
   assert same(enc(raw.学習過程),enc(learning[raw.学習過程.学習識別子]))
   teach_results.append({"row":t["row"],"state":ret.状態,"learning_status":raw.学習過程.学習成立状態.value,"experience":e.経験識別子,"reasons":list(raw.断定保留理由群)})
  else:
   t=teachers[ordinal-14];assert item["method"]=="照会する" and same(enc(reply["input"]),enc(外部入力(t["query_input"],t["boundary"])))
  for p in raw.有効原理群:
   assert same(enc(p),enc(histories[p.原理識別子]))
   assert all(e in observations for e in p.根拠参照群+p.反証参照群)
  for pred in raw.予測群:
   p=histories[pred.原理参照];assert p.対象系境界==reply["input"].対象系境界 and same(pred.結果経路,p.結果経路)
  api.append(reply)
 assert len(api)==27
 mapping=packet(c["mapping"]);assert mapping["API"]==c["api_calls"][0] and mapping["number"]==6
 t_saved=packet(c["teachers"])
 assert same(enc(t_saved),enc([{"teacher":t,"API":c["api_calls"][i+1],"external_return":api[i+1]["capture"]["return"]} for i,t in enumerate(teachers)]))
 replies=packet(c["queries"])
 assert same(enc(replies),enc([{"ordinal":t["ordinal"],"row":t["row"],"API":c["api_calls"][i+14],"reply":api[i+14]["capture"]["return"]} for i,t in enumerate(teachers)]))
 CHECKS["all27_raw_native_external_replies_exact_inputs_experiences_supports"]=True
 scoring=[]
 for t,item in zip(teachers,replies):
  r=item["reply"];pred=r.内容.get("予測群",[]);wanted=[p for p in pred if tuple(p["結果経路"])==(pm.Y,)];values=[p["予測値"] for p in wanted]
  scoring.append({"ordinal":t["ordinal"],"row":t["row"],"expected":t["teacher"][pm.Y],"all_predictions":pred,"result_values":values,"correct":bool(values) and all(type(v)is bool and v is t["teacher"][pm.Y] for v in values),"wrong":any(type(v)is not bool or v is not t["teacher"][pm.Y] for v in values),"missing":not values,"extra":[p for p in pred if tuple(p["結果経路"])!=(pm.Y,)],"HOLD":r.状態=="断定保留","external_state":r.状態})
 assert same(enc(scoring),enc(packet(c["scoring"])))
 CHECKS["all13_regression_correct_wrong_missing_extra_HOLD_separate"]=True
 changed=[]
 for key,versions in trained["原理履歴"].items():
  prior=old["原理履歴"].get(key,[])
  if not same(enc(prior),enc(versions)):
   changed.append({"lineage":key,"before_versions":len(prior),"after_versions":len(versions),"full_versions":enc(versions)})
 def refs(v):
  if isinstance(v,dict):
   if set(v)=={"path","bytes","sha256"} and type(v["path"])is str:exact(v,16*M)
   else:
    for x in v.values():refs(x)
  elif isinstance(v,list):
   for x in v:refs(x)
 refs(c);refs(pack)
 for p in sorted(D.iterdir()):
  if p.suffix==".xz":
   back=unpack(plain(p));tag=js(back);assert jb(tag)==back
   if isinstance(tag,dict) and "__辞書__" in tag:assert same(enc(dec(tag)),tag)
 for ref in deps:exact(ref,4*M)
 for path,i in IDENT.items():assert ident(Path(path))==i
 CHECKS["all_refs_CRC64_EOF_type_order_core_source_unchanged"]=True
 prior_failure=js(plain(R/"source/pre_native_failure_structural_proof_v1.json"))
 result={"schema":"column-repair13-independent-audit-v1","status":"PASS","errors":[],"verified":CHECKS,"nonce":c["nonce"],"completion":REFS[str(D/"completion.json.xz")],"actual_exit":exit_ref,"states":c["states"],"counts":{"Teach":13,"mapping_Query":1,"regression_Query":13,"Action":0,"native_API_by_auditor":0,"all_cases":59,"correct":sum(x["correct"] for x in scoring),"wrong":sum(x["wrong"] for x in scoring),"missing":sum(x["missing"] for x in scoring),"HOLD":sum(x["HOLD"] for x in scoring)},"teacher_results":teach_results,"scoring":scoring,"changed_lineages":changed,"prior_pre_native_failure":prior_failure,"references":list(REFS.values()),"elapsed_seconds":time.monotonic()-START,"limitations":["Only same-trajectory teacher regression, no new game success or unseen transfer.","Before measurement projection reused with exact saved full cases; no repeated raw67MB scan or native inference.","Prior pre-native failure retained separately and not reclassified as success."]}
 r=out("repair13_audit_summary_v1.json",result);signal.alarm(0);print(json.dumps({"status":"PASS","report":r,"counts":result["counts"]}))
try:main()
except BaseException:
 signal.alarm(0)
 r=out("repair13_audit_failure_v1.json",{"status":"FAIL","cursor":CURSOR,"checks":CHECKS,"traceback":traceback.format_exc()},"failure")
 print(json.dumps({"status":"FAIL","failure":r}));raise
