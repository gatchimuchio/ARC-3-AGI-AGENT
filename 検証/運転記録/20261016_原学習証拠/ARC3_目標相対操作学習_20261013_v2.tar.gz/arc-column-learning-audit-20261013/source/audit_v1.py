import resource
resource.setrlimit(resource.RLIMIT_AS,(512<<20,512<<20))
import ast,base64,dataclasses,hashlib,importlib.util,json,lzma,os,signal,sys,time,traceback
from pathlib import Path
B=Path("/workspace/scratch/a94ff513b3af")
R=B/"arc-column-learning-20261013"
D=R/"state_trace/c2f866fa03f288e255c4c88aea21cb75"
A=B/"arc-column-learning-audit-20261013"
F=B/"arc-current-family-source-20261013"
CORE=B/"arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2"
RAW=B/"arc-column-teacher-recovery-20261013/public-recording-v2.jsonl"
M=1048576
CURSOR="start"; CHECKS={}; REFS={}; IDENT={}; START=time.monotonic()
def guard(extra=0,category="result"):
 caps={"source":2*M,"result":4*M,"failure":2*M}
 usage={k:sum(p.stat().st_size for p in (A/k).rglob("*") if p.is_file()) for k in caps}
 assert usage[category]+extra<=caps[category] and sum(usage.values())+extra<=8*M
 v=os.statvfs(B);assert v.f_bavail*v.f_frsize >= (1024+956)*M
 mem=int(next(x.split()[1] for x in Path("/proc/meminfo").read_text().splitlines() if x.startswith("MemAvailable:")))*1024
 assert mem >= (4096+2048)*M
def ident(p):
 s=p.stat();return [s.st_dev,s.st_ino,s.st_size,s.st_mode,s.st_mtime_ns,s.st_ctime_ns]
def digest(raw):return hashlib.sha256(raw).hexdigest()
def filehash(p):
 h=hashlib.sha256()
 with p.open("rb") as f:
  for v in iter(lambda:f.read(65536),b""):h.update(v)
 return h.hexdigest()
def exact(r,cap=16*M):
 p=Path(r["path"]);assert set(r)=={"path","bytes","sha256"} and type(r["bytes"])is int and r["bytes"]<=cap
 assert not p.is_symlink() and p.stat().st_size==r["bytes"]
 i=ident(p);raw=p.read_bytes();assert digest(raw)==r["sha256"] and ident(p)==i
 IDENT[str(p)]=i;REFS[str(p)]=r;return raw
def plain(p):
 raw=p.read_bytes();return exact({"path":str(p),"bytes":len(raw),"sha256":digest(raw)})
def unique(pairs):
 d={}
 for k,v in pairs:
  assert k not in d
  d[k]=v
 return d
def js(raw):return json.loads(raw,object_pairs_hook=unique)
def jb(x):return json.dumps(x,ensure_ascii=False,separators=(",",":"),allow_nan=False).encode()
def same(a,b):return type(a)is type(b) and (len(a)==len(b) and all(same(k,l) and same(a[k],b[l]) for k,l in zip(a,b)) if isinstance(a,dict) else len(a)==len(b) and all(same(x,y) for x,y in zip(a,b)) if isinstance(a,(tuple,list)) else a==b)
def unpack(raw):
 z=lzma.LZMADecompressor();out=z.decompress(raw,max_length=16*M+1)
 assert len(out)<=16*M and z.eof and not z.unused_data and z.check==lzma.CHECK_CRC64
 return out
def packet(r,typed=True):
 raw=unpack(exact(r["file"]));assert len(raw)==r["rawbytes"] and digest(raw)==r["rawsha256"]
 v=js(raw);assert jb(v)==raw
 if typed:
  value=dec(v);assert same(enc(value),v);return value
 return v
def pfile(name,typed=True):
 p=D/name;raw=plain(p);back=unpack(raw);v=js(back);assert jb(v)==back
 if typed:
  value=dec(v);assert same(enc(value),v);return value
 return v
def out(name,v,category="result"):
 raw=(json.dumps(v,ensure_ascii=False,indent=2)+"\n").encode();guard(len(raw),category);p=A/category/name
 with p.open("xb") as f:f.write(raw);f.flush();os.fsync(f.fileno())
 fd=os.open(p.parent,os.O_RDONLY);os.fsync(fd);os.close(fd);assert p.read_bytes()==raw
 return {"path":str(p),"bytes":len(raw),"sha256":digest(raw)}
def load(name,p):
 sp=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
def timeout(*a):raise TimeoutError("independent300s")
def main():
 global CURSOR,enc,dec
 signal.signal(signal.SIGALRM,timeout);signal.alarm(300);guard()
 contract=js(plain(R/"source/column_contract_v1.json"))
 assert contract["source"]["sha256"]=="6cd9e4291e73ed8204215bd6a408e758af1d6430eb6a236b0331b728039e1da2"
 for r in contract["dependencies"]:exact(r,4*M)
 exact(contract["source"])
 sys.dont_write_bytecode=True;sys.path[:0]=[str(CORE),str(F)]
 import hds学習系統.永続化 as codec
 enc,dec=codec._符号化,codec._復号
 # No HDS instance, restoration, teach or query is invoked.
 c=packet({"file":{"path":str(D/"completion.json.xz"),"bytes":27848,"sha256":"87218d4661140d4c62316fac2cdc7db4965fa954199a036a0be831562e501415"},"rawbytes":105810,"rawsha256":"f3c76af45e66ebd168ab6298c990a8214dd9bec343582263f6639debaf0bf080"},False)
 assert c["status"]=="complete" and c["errors"]==[] and c["teach_calls"]==78 and c["query_calls"]==7 and c["fresh_query_calls"]==5 and c["fresh_frame_count"]==27 and c["Action"]==0
 exact(c["source"]);exit_tool=js(exact({"path":str(R/"source/native_actual_exit_c2f866fa_v1.json"),"bytes":592,"sha256":"19d1f167ae179d5a2893e27ded69a0cb3131b089b71782620ecae04b81cc0e3b"}))
 assert exit_tool["exit_code"]==0
 exact({"path":str(R/"source/native_actual_tools_c2f866fa_v1.json"),"bytes":1100,"sha256":"8d7257c7a2def38c0d4a86388ef0377179c5962d11713916c1eb0b87a375afbe"})
 states=[]
 for r in c["states"]:
  raw=exact(r);v=js(raw);x=dec(v);assert same(enc(x),v) and json.dumps(v,ensure_ascii=False,indent=2).encode()==raw;states.append(x)
 initial,learned,final=states
 assert initial["台帳"]=={} and initial["原理履歴"]=={} and initial["識別子状態"]=={}
 assert initial["最小支持数"]==learned["最小支持数"]==final["最小支持数"]==3
 assert initial["最大条件数"]==learned["最大条件数"]==final["最大条件数"]==2
 expected=dec(enc(learned))
 for k in ("照会","学習判定"):expected["識別子状態"][k]+=5
 assert same(enc(expected),enc(final));CHECKS["all_state_except_two_counters_plus5"]=True
 observations={e.経験識別子:e for e in learned["台帳"]["観測台帳"]}
 learning={e.学習識別子:e for e in learned["台帳"]["学習過程台帳"]}
 assert len(observations)==len(learning)==78
 histories={p.原理識別子:p for h in learned["原理履歴"].values() for p in h}
 api=[]
 previous=None
 for ordinal,item in enumerate(c["api_calls"]):
  CURSOR="API"+str(ordinal);assert item["ordinal"]==ordinal
  intent=packet(item["intent"]);reply=packet(item["reply"])
  for key in ("ordinal","phase","frame_ordinal","method","input","origin","before"):assert same(enc(intent[key]),enc(reply[key]))
  assert intent["capture"]=={} and reply["capture"]["profile_restored"]is True
  assert len(reply["capture"]["raw"])==len(reply["capture"]["events"])==1
  event=reply["capture"]["events"][0];assert event["exact_code_self"]is True and event["function"]=="排出する"
  raw=reply["capture"]["raw"][0];ret=reply["capture"]["return"];ext=reply["input"]
  if previous is not None:assert same(previous,reply["before"])
  previous=reply["after"]
  if item["method"]=="処理する":
   e=observations[ret.追跡情報["経験参照"]]
   assert same(e.原入力,ext.内容) and e.対象系境界==ext.対象系境界
   assert same(enc(learning[raw.学習過程.学習識別子]),enc(raw.学習過程))
  else:assert item["method"]=="照会する" and raw.学習過程.学習成立状態.value=="適用外"
  for p in raw.有効原理群:assert p.原理識別子 in histories and same(enc(p),enc(histories[p.原理識別子]))
  api.append(reply)
 assert len(api)==85 and sum(x["method"]=="処理する" for x in api)==78
 CHECKS["all85_intent_reply_and_native_ledger_joins"]=True
 CURSOR="raw_rows"
 index=pfile("raw_full_offset_index.json.xz",False);assert index["source"]["sha256"]=="e26ff1df251af042911126a067c08ee25973b01d3389269472eed6859a4383f2"
 before=ident(RAW);assert filehash(RAW)==index["source"]["sha256"];IDENT[str(RAW)]=before
 offsets=[]
 with RAW.open("rb") as f:
  while True:
   at=f.tell();line=f.readline(8*M+1)
   if not line:break
   assert len(line)<=8*M
   if line.strip():offsets.append({"offset":at,"bytes":len(line),"sha256":digest(line)})
 assert same(offsets,index["all_offsets"])
 selected=list(range(60))+list(range(225,257));assert index["selected_rows"]==selected and set(map(int,c["row_all_phase_refs"]))==set(selected)
 class Rows:
  def __len__(self):return len(offsets)
  def __getitem__(self,i):
   assert type(i)is int and i in selected
   e=offsets[i]
   with RAW.open("rb") as f:f.seek(e["offset"]);r=f.read(e["bytes"])
   assert digest(r)==e["sha256"];v=js(r);return v.get("data",v)
 rows=Rows();phase_total=0
 for i in selected:
  v=rows[i];r=packet(c["row_all_phase_refs"][str(i)],False)
  expected={"row":i,"raw":offsets[i],"metadata":{k:x for k,x in v.items() if k!="frame"},"phases":[{"index":j,"sha256":digest(jb(fr)),"height":len(fr),"width":len(fr[0]) if fr else 0} for j,fr in enumerate(v.get("frame",[]))]}
  assert same(r,expected);phase_total+=len(expected["phases"])
 assert phase_total==2551
 CHECKS["all92_raw_bindings_all2551_phase_hashes"]=True
 CURSOR="teacher_source_reconstruction"
 trainer=load("audit_pinned_teacher",F/"道具/列図式教師検証.py")
 from 接続 import 列図式規則 as family
 class SavedReplies:
  def __init__(self):self.i=0
  def call(self,method,x):
   r=api[self.i];assert r["method"]==method and same(enc(r["input"]),enc(x)),self.i
   self.i+=1;return r["capture"]["return"]
  def 処理する(self,x):return self.call("処理する",x)
  def 照会する(self,x):return self.call("照会する",x)
 replay=SavedReplies()
 generated=trainer.教師を取り込む(replay,rows,(12,43,59,256),((1,59),(226,256)),((1,59),),原票SHA256=index["source"]["sha256"])
 teacher=packet(c["teacher_result"]);assert same(enc(generated),enc(teacher)) and replay.i==80
 counts={}
 for r in teacher["教師記録"]:
  if "教師" in r:counts[r["種別"]]=counts.get(r["種別"],0)+1
 assert counts=={"役割教師":29,"目標教師":8,"作用観測":41}
 CHECKS["78_inputs_from_original_measurements_order_and_returns"]=True
 CURSOR="all27_candidates";candidate_summary=[];inputs=[]
 for i,r in enumerate(c["fresh_results"]):
  inp=pfile("frame_%02d_input.json.xz"%i);item=inp["input"];assert inp["ordinal"]==i;inputs.append(item)
  obs=js(exact(item["observation"]));fr=obs["frames"][item["phase"]];b=base64.b64decode(fr["base64"],validate=True)
  assert digest(b)==fr["sha256"] and fr["dtype"]=="|i1" and fr["shape"]==[64,64]
  assert item["frame"]==[list(b[j:j+64]) for j in range(0,4096,64)]
  assert item["actions"]==[trainer._作用番号(v) for v in obs["model_json"]["available_actions"]]
  result=family.候補を構成する(replay,item["frame"],作用可能番号=item["actions"])
  ledger=family.候補台帳を構成する(result);stored=packet(r)
  assert same(enc(stored),enc({"ordinal":i,"result":result,"ledger":ledger,"evidence":item["evidence"]}))
  assert result["実行許可"]is False and ledger["実行許可"]is False
  candidate_summary.append({"ordinal":i,"applicability":result["適用性"]["状態"],"selection":result["解答選択状態"],"goals":len(result["目標候補群"]),"actions":len(result["作用候補群"]),"holds":result["保留理由群"]})
 assert replay.i==85 and len(candidate_summary)==27
 CHECKS["all27_pixels_actions_candidates_HOLD_exact"]=True
 CURSOR="all_ref_closure"
 def refs(v):
  if isinstance(v,dict):
   if set(v)=={"path","bytes","sha256"} and type(v["path"])is str:exact(v,16*M)
   else:
    for x in v.values():refs(x)
  elif isinstance(v,list):
   for x in v:refs(x)
 refs(c)
 # Every saved trace is reread, including frame inputs not listed by completion.
 allfiles=sorted(D.iterdir());xzcount=0
 for p in allfiles:
  if p.suffix==".xz":
   raw=unpack(plain(p));v=js(raw);assert jb(v)==raw
   if isinstance(v,dict) and "__辞書__" in v:assert same(enc(dec(v)),v)
   xzcount+=1
 for r in contract["dependencies"]:exact(r,4*M)
 assert filehash(RAW)==index["source"]["sha256"] and ident(RAW)==before
 for p,i in IDENT.items():assert ident(Path(p))==i
 CHECKS["all_refs_CRC64_EOF_type_order_core_unchanged"]=True
 result={"schema":"column-learning-independent-audit-v1","status":"PASS","errors":[],"verified":CHECKS,"counts":{"Teach":78,"teacher_views":counts,"training_queries":2,"fresh_queries":5,"frames":27,"raw_rows":92,"raw_phases":phase_total,"XZ_files":xzcount,"native_API_calls_by_auditor":0,"Action":0},"candidate_results":candidate_summary,"standard_states":c["states"],"references":list(REFS.values()),"source":{"path":__file__,"bytes":Path(__file__).stat().st_size,"sha256":filehash(Path(__file__))},"elapsed_seconds":time.monotonic()-START,"limits":["Existing fixed perception and teacher functions reused for source-measurement reconstruction; saved native replies are compared and returned by a read-only replay object, never new HDS calls.","No new learning or causal derivation; all support/refutation/history preserved in exact standard state and raw replies.","27-frame structure applicability and candidate outputs are not gameplay success."]}
 r=out("summary_v1.json",result);signal.alarm(0);print(json.dumps({"status":"PASS","report":r,"counts":result["counts"]}))
try:main()
except BaseException:
 signal.alarm(0)
 r=out("failure_v1.json",{"status":"FAIL","cursor":CURSOR,"checks":CHECKS,"traceback":traceback.format_exc()},"failure")
 print(json.dumps({"status":"FAIL","failure":r}));raise
