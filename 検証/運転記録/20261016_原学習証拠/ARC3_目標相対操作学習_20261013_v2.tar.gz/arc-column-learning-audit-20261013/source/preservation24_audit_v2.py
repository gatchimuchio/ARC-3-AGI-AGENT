import resource
resource.setrlimit(resource.RLIMIT_AS,(512<<20,512<<20))
import hashlib
from pathlib import Path
BASE=Path("/workspace/scratch/a94ff513b3af/arc-column-learning-audit-20261013/source/audit_v1.py")
raw=BASE.read_bytes()
assert hashlib.sha256(raw).hexdigest()=="e95c8a8307be21b9dc9981685fe84d2b41c0a8216b38f45361e47f4a0d267324"
prefix=raw.decode().split("def main():",1)[0]
exec(compile(prefix.replace("(1024+956)*M","(1024+1348)*M").replace("(4096+2048)*M","(4608+2048)*M"),str(BASE),"exec"),globals())
R=B/"arc-column-preparation-learning-20261013"
D=R/"state_trace/4b4bed2b789a62d3d941224ab5e174b0"
def main():
 global enc,dec,CURSOR
 signal.signal(signal.SIGALRM,timeout);signal.alarm(300);guard()
 contract=js(plain(R/"source/column_preservation_contract_v2.json"))
 assert contract["source"]["sha256"]=="8e0d4d7c358e8dff93906818863f6302f955cb6d9724ed7d3a4f4f06da75a2bf"
 exact(contract["source"]);exact(contract["outer"])
 base=exact({"path":str(B/"arc-column-work-learning-20261013/source/column_work_harness_v3.py"),"bytes":26932,"sha256":"f0d73f35a9516eda585b134ae54be9815b36d6164786b9f8a0966c3983640007"});tree=ast.parse(base)
 deps=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=="DEPENDENCIES" for t in n.targets))
 for ref in deps:exact(ref,4*M)
 sys.dont_write_bytecode=True;sys.path[:0]=[str(CORE),str(F)]
 import hds学習系統.永続化 as codec
 enc,dec=codec._符号化,codec._復号
 from hds学習系統.型 import 外部出力,実行結果,学習成立状態,外部入力
 from 接続 import 列図式規則 as family
 c=packet({"file":{"path":str(D/"completion.json.xz"),"bytes":17148,"sha256":"72ba1c240a3b1ad2a3c7cef75ab400187269c565cdf6dc9f4ccff024c0d43f92"},"rawbytes":69389,"rawsha256":"d43e61c4fe4d5fb052a07d5abcfcda09c1398c295202304d35a1b4c3b59f5f15"},False)
 assert c["status"]=="complete" and c["errors"]==[] and c["teach_calls"]==24 and c["query_calls"]==60 and c["Action"]==c["new_clear"]==0
 exit_ref=js(sys.argv[1]);exit_tool=js(exact(exit_ref));assert exit_tool["exit_code"]==0 and "UTCEND " in exit_tool["output"]
 receipt=json.loads(exit_tool["output"].splitlines()[0])["receipt"];assert receipt["file"]==REFS[str(D/"completion.json.xz")]
 previous=js(exact(c["baseline_audit"]));assert previous["status"]=="PASS" and all(previous["verified"].values()) and c["baseline_state"]==previous["states"][-1]
 states=[]
 for ref in c["states"]:
  raw=exact(ref);v=js(raw);x=dec(v);assert same(enc(x),v) and json.dumps(v,ensure_ascii=False,indent=2).encode()==raw;states.append(x)
 old,trained,final=states
 assert exact(c["states"][0])==exact(c["baseline_state"])
 for table,values in old["台帳"].items():assert same(enc(trained["台帳"][table][:len(values)]),enc(values))
 assert same(enc(trained["状態履歴"][:len(old["状態履歴"])]),enc(old["状態履歴"]))
 for name,versions in old["原理履歴"].items():assert same(enc(trained["原理履歴"][name][:len(versions)]),enc(versions))
 assert len(old["台帳"]["観測台帳"])==105 and len(trained["台帳"]["観測台帳"])==129
 assert trained["識別子状態"]["経験"]-old["識別子状態"]["経験"]==24
 expected=dec(enc(trained))
 for key in ("照会","学習判定"):
  assert trained["識別子状態"][key]-old["識別子状態"][key]==2
  expected["識別子状態"][key]+=58
 assert same(enc(expected),enc(final))
 assert old["最小支持数"]==trained["最小支持数"]==3 and old["最大条件数"]==trained["最大条件数"]==2
 CHECKS["normal_restore_old105_all_prefixes_and_query_only_counters_plus58"]=True
 CURSOR="materials"
 mc=js(exact(c["material_contract"]));exact(mc["source"])
 pm=load("audit_pinned_preservation_projection",Path(mc["source"]["path"]))
 p,repair_decide=pm.bootstrap()
 assert filehash(pm.PREP)==pm.PREP_SHA and filehash(pm.REPAIR)==pm.REPAIR_SHA
 pack=packet(mc["actual"]["pack"])
 assert same(enc(pack),enc(pfile("all24_material.json.xz"))) and pack["status"]=="complete" and pack["eligible_unknown_rows"]==[]
 tag=js(unpack(exact(p.TERMINAL)));terminal=dec(tag);assert same(enc(terminal),tag)
 assert terminal["状態"]=="complete" and terminal["errors"]==[] and terminal["全行順"]==list(range(1,60))
 evtag=js(unpack(exact(p.EVIDENCE)));evidence=dec(evtag);assert same(enc(evidence),evtag)
 assert same(enc(p.learned_click(evidence)),enc(pack["learned_click_evidence"]))
 allcases=[];teachers=[];phase_count=0
 for i,item in enumerate(terminal["cases"],1):
  case=packet(item["ref"]);assert case["行"]==i and case["教師候補観測"]["行"]==i
  projected=pm.project(case,p,repair_decide,pack["learned_click_evidence"]["number"]);projected["case_ref"]=item["ref"];allcases.append(projected)
  if projected["decision"]["eligible_before"]:
   assert projected["outcome_status"]=="measured" and projected["teacher"]is not None and projected["decision"]["existing_correct_slots"]
   phase_count+=len(projected["phases"])
   assert len(projected["phases"])==len(case["教師候補観測"]["全後相"])
   for phase,effect in zip(projected["phases"],case["教師候補観測"]["各相効果"]):
    assert effect["旧scope効果確認"] and same(phase["value"],effect["集約効果"]["既充足が全て保持された"])
   teachers.append({"ordinal":len(teachers),"row":i,"case_ref":item["ref"],"query_input":projected["decision"]["query_input"],"teacher":projected["teacher"],"boundary":pm.BOUNDARY})
 assert len(allcases)==59 and len(teachers)==24 and phase_count==90 and same(enc(allcases),enc(pack["all59"])) and same(enc(teachers),enc(pack["teachers"]))
 empty=[r for r in allcases if r["decision"]["empty_set"]]
 assert len(empty)==3 and all(r["measured_preservation"]is None and r["teacher"]is None for r in empty)
 for t in teachers:
  assert list(t["teacher"])==[pm.X,pm.Y] and list(t["query_input"])==[pm.X] and type(t["teacher"][pm.X])is str and type(t["teacher"][pm.Y])is bool
  assert same(t["query_input"],{pm.X:t["teacher"][pm.X]})
 CHECKS["all59_material_24_before_inputs_all90_phases_empty_unknown_preservation"]=True
 CURSOR="baseline_plan"
 gate=js(plain(R/("source/root_preservation_release_"+c["nonce"]+".json")))
 prior_gate=js(exact(gate["preparation_gate"]))
 prep_completion=packet(gate["baseline_completion"],False)
 assert prep_completion["states"][-1]==c["baseline_state"]
 old78=packet(prior_gate["old78_completion"],False);repair=packet(prior_gate["baseline_completion"],False)
 assert repair["source"]["sha256"]=="f0d73f35a9516eda585b134ae54be9815b36d6164786b9f8a0966c3983640007"
 prep_contract=js(exact(prep_completion["material_contract"]));prep_pack=packet(prep_contract["runtime"]["pack"])
 oldstate=dec(js(exact(old78["states"][1])));repair_pack=packet(repair["teacher_pack"])
 plan=pfile("original_regression_plan.json.xz")
 signatures={}
 for completion in (old78,repair):
  for item in completion["api_calls"]:
   if item["method"]=="照会する":
    r=packet(item["reply"]);external=r["input"]
    signatures.setdefault((external.対象系境界,jb(enc(external.内容)).hex()),{"ref":item["reply"],"reply":r["capture"]["return"]})
 groupspec=[(family.役割境界,"記号は中空","列展開役割"),(family.目標境界,"終端条件に応じた列が一致","提出が受理された"),(family.作用境界,"解答作業","必要行動ID")]
 rebuilt=[]
 for boundary,key,outkey in groupspec:
  values=[]
  for item in old78["api_calls"]:
   if item["method"]=="処理する":
    r=packet(item["intent"]);e=r["input"]
    if e.対象系境界==boundary and key in e.内容 and not any(same(e.内容[key],v) for v in values):values.append(e.内容[key])
  for value in values:
   content={key:value};hist=signatures.get((boundary,jb(enc(content)).hex()))
   active=set(oldstate["状態履歴"][-1].values())
   rules=[p for p in oldstate["台帳"]["原理台帳"] if p.原理識別子 in active and p.対象系境界==boundary and p.条件経路群==((key,),) and p.結果経路==(outkey,)]
   assert len(rules)==1
   rule=rules[0];k=json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(",",":"));outcomes=[v for keys,v in rule.対応値表 if keys==(k,)];assert len(outcomes)==1
   rebuilt.append({"boundary":boundary,"query_input":content,"output_key":outkey,"expected_value":outcomes[0],"baseline_rule":rule,"historical":hist,"comparison_kind":"historical actual query" if hist else "saved standard relationship expectation versus first real query"})
 assert len(plan)==7 and same(enc(plan),enc(rebuilt))
 histories={p.原理識別子:p for h in trained["原理履歴"].values() for p in h}
 observations={e.経験識別子:e for e in trained["台帳"]["観測台帳"]}
 learning={e.学習識別子:e for e in trained["台帳"]["学習過程台帳"]}
 exhaust=CORE/"hds学習系統/排気系.py"
 fn=next(n for n in ast.walk(ast.parse(exhaust.read_bytes())) if isinstance(n,ast.FunctionDef) and n.name=="排出する")
 ns={"asdict":dataclasses.asdict,"Any":object,"外部出力":外部出力,"実行結果":実行結果,"学習成立状態":学習成立状態}
 exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])),str(exhaust),"exec"),ns)
 regression=[("preservation_regression",teachers),("baseline_regression",plan),("repair_regression",repair_pack["teachers"]),("preparation_regression",prep_pack["teachers"])]
 flat=[(group,i,t) for group,items in regression for i,t in enumerate(items)]
 assert len(flat)==58
 api=[];teach_results=[];prev=None
 for ordinal,item in enumerate(c["api_calls"]):
  CURSOR="api_"+str(ordinal);assert item["ordinal"]==ordinal
  intent=packet(item["intent"]);reply=packet(item["reply"])
  for key in ("ordinal","phase","frame_ordinal","method","input","origin","before"):assert same(enc(intent[key]),enc(reply[key]))
  assert intent["capture"]=={}
  cap=reply["capture"];assert cap["profile_restored"] is True and len(cap["raw"])==len(cap["events"])==1
  assert cap["events"][0]["exact_code_self"] is True and cap["events"][0]["function"]=="排出する"
  raw=cap["raw"][0];ret=cap["return"];assert same(enc(ns["排出する"](None,raw)),enc(ret))
  if prev is not None:assert same(prev,reply["before"])
  prev=reply["after"]
  if ordinal<2:
   operation=("在庫記号を選択","選択記号を空欄へ割当")[ordinal]
   assert item["method"]=="照会する" and same(enc(reply["input"]),enc(外部入力({"解答作業":operation},family.作用境界)))
  elif ordinal<=25:
   t=teachers[ordinal-2];assert item["method"]=="処理する" and same(enc(reply["input"]),enc(外部入力(t["teacher"],t["boundary"])))
   e=observations[ret.追跡情報["経験参照"]]
   assert same(e.原入力,t["teacher"]) and e.対象系境界==t["boundary"] and same(enc(e),enc(trained["台帳"]["観測台帳"][105+ordinal-2]))
   assert same(enc(raw.学習過程),enc(learning[raw.学習過程.学習識別子]))
   teach_results.append({"row":t["row"],"state":ret.状態,"learning_status":raw.学習過程.学習成立状態.value,"experience":e.経験識別子,"reasons":list(raw.断定保留理由群)})
  else:
   group,i,t=flat[ordinal-26];assert reply["phase"]==group and reply["frame_ordinal"]==i
   assert item["method"]=="照会する" and same(enc(reply["input"]),enc(外部入力(t["query_input"],t["boundary"])))
  for p in raw.有効原理群:
   assert same(enc(p),enc(histories[p.原理識別子]))
   assert all(e in observations for e in p.根拠参照群+p.反証参照群)
  for pred in raw.予測群:
   p=histories[pred.原理参照];assert p.対象系境界==reply["input"].対象系境界 and same(pred.結果経路,p.結果経路)
  api.append(reply)
 assert len(api)==84
 mapping=packet(c["mapping"])
 assert len(mapping)==2
 for i,operation in enumerate(("在庫記号を選択","選択記号を空欄へ割当")):
  assert mapping[i]["operation"]==operation and mapping[i]["API"]==c["api_calls"][i] and same(enc(mapping[i]["reply"]),enc(api[i]["capture"]["return"]))
 assert same(enc(packet(c["teachers"])),enc([{"teacher":t,"reply":api[i+2]["capture"]["return"],"API":c["api_calls"][i+2]} for i,t in enumerate(teachers)]))
 replies=packet(c["queries"])
 assert same(enc(replies),enc([{"group":group,"index":i,"reply":api[j+26]["capture"]["return"],"API":c["api_calls"][j+26]} for j,(group,i,t) in enumerate(flat)]))
 CHECKS["all84_actual_inputs_raw_external_replies_support_and_24_experience_joins"]=True
 def semantic(r):return {"state":r.状態,"predictions":r.内容.get("予測群",[]),"HOLD_reasons":r.内容.get("断定保留理由群",[])}
 scoring=[];prior_repair=packet(repair["queries"]);prior_preparation=packet(prep_completion["queries"])
 for (group,i,t),item in zip(flat,replies):
  r=item["reply"]
  key=t["output_key"] if group=="baseline_regression" else next(k for k in t["teacher"] if k not in t["query_input"])
  truth=t["expected_value"] if group=="baseline_regression" else t["teacher"][key]
  ps=r.内容.get("予測群",[]);wanted=[p for p in ps if tuple(p["結果経路"])==(key,)];values=[p["予測値"] for p in wanted]
  score={"group":group,"index":i,"row":t.get("row"),"expected":truth,"all_predictions":ps,"correct":bool(values) and all(same(v,truth) for v in values),"wrong":any(not same(v,truth) for v in values),"missing":not values,"extra":[p for p in ps if tuple(p["結果経路"])!=(key,)],"HOLD":r.状態=="断定保留","state":r.状態}
  if group=="baseline_regression":
   rule=t["baseline_rule"];score.update(comparison_kind=t["comparison_kind"],baseline_rule=rule,historical_ref=t["historical"]["ref"] if t["historical"] else None,support_rule_refs_match=all(p["原理参照"]==rule.原理識別子 for p in wanted) and bool(wanted),historical_semantics_equal=same(semantic(r),semantic(t["historical"]["reply"])) if t["historical"] else None)
  if group=="repair_regression":
   prior=prior_repair[i];score["historical_semantics_equal"]=same(semantic(r),semantic(prior["reply"]));score["historical_ref"]=prior["API"]["reply"]
  if group=="preparation_regression":
   prior=prior_preparation[i];assert prior["group"]==group
   score["historical_semantics_equal"]=same(semantic(r),semantic(prior["reply"]));score["historical_ref"]=prior["API"]["reply"]
  scoring.append(score)
 assert same(enc(scoring),enc(packet(c["scoring"])))
 CHECKS["all58_scoring_HOLD_and_historical_vs_saved_rule_expectation_distinguished"]=True
 changed=[]
 for key,versions in trained["原理履歴"].items():
  prior=old["原理履歴"].get(key,[])
  if not same(enc(prior),enc(versions)):changed.append({"lineage":key,"before_versions":len(prior),"after_versions":len(versions),"full_versions":enc(versions)})
 def refs(v):
  if isinstance(v,dict):
   if set(v)=={"path","bytes","sha256"} and type(v["path"])is str:exact(v,16*M)
   else:
    for x in v.values():refs(x)
  elif isinstance(v,list):
   for x in v:refs(x)
 refs(c);refs(pack)
 for p in sorted(D.iterdir()):
  if p.suffix==".xz":
   back=unpack(plain(p));tag=js(back);assert jb(tag)==back
   if isinstance(tag,dict) and "__辞書__" in tag:assert same(enc(dec(tag)),tag)
 for ref in deps:exact(ref,4*M)
 for path,i in IDENT.items():assert ident(Path(path))==i
 CHECKS["all_refs_CRC64_EOF_type_order_core_source_unchanged"]=True
 counts={}
 for group,_ in regression:
  rows=[s for s in scoring if s["group"]==group]
  counts[group]={k:sum(bool(s[k]) for s in rows) for k in ("correct","wrong","missing","extra","HOLD")}
 result={"schema":"column-preservation24-independent-audit-v1","status":"PASS","errors":[],"verified":CHECKS,"nonce":c["nonce"],"completion":REFS[str(D/"completion.json.xz")],"actual_exit":exit_ref,"states":c["states"],"counts":{"Teach":24,"Query":60,"Action":0,"native_API_by_auditor":0,"all_cases":59,"phases":phase_count,"preservation_true":sum(t["teacher"][pm.Y]is True for t in teachers),"preservation_false":sum(t["teacher"][pm.Y]is False for t in teachers),"regressions":counts},"teacher_results":teach_results,"scoring":enc(scoring),"changed_lineages":changed,"references":list(REFS.values()),"elapsed_seconds":time.monotonic()-START,"limitations":["24 preservation examples all True and real False0; constant-output correspondence is not universal safety. Same-trajectory regression; old7 includes saved-rule expectation where historical Query is absent.","Pure material projection and exhaust serialization reused; no native inference/restore/Teach/Action performed by auditor.","Prior repair pre-native failure remains in original independent report. No unseen transfer or game clear claim."]}
 r=out("preservation24_audit_summary_v2.json",result);signal.alarm(0);print(json.dumps({"status":"PASS","report":r,"counts":result["counts"]}))
try:main()
except BaseException:
 signal.alarm(0)
 r=out("preservation24_audit_failure_v2.json",{"status":"FAIL","cursor":CURSOR,"checks":CHECKS,"traceback":traceback.format_exc()},"failure")
 print(json.dumps({"status":"FAIL","failure":r}));raise
