"""Existing column-family delegation; no native calls at import time."""
import ast,base64,hashlib,importlib.util,json,lzma,os,resource,shutil,signal,stat,sys,time,traceback
from pathlib import Path
B=Path("/workspace/scratch/a94ff513b3af")
ROOT=B/"arc-column-goal-pools-20261013"
FAMILY=B/"arc-current-family-source-20261013"
CORE=B/"arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2"
RAW=B/"arc-column-teacher-recovery-20261013/public-recording-v2.jsonl"
RAW_SHA="e26ff1df251af042911126a067c08ee25973b01d3389269472eed6859a4383f2"
ROWS=tuple(range(59))
ANSWERS=(12,43,59,256)
GOALS=((1,59),(226,256))
ACTIONS=((1,59),)
MIB=1048576
OWNER=None
# DEPENDENCIES is appended during source preparation from pinned recovered manifests.
def eq(a,b):
 if type(a) is not type(b):return False
 if isinstance(a,dict):return len(a)==len(b) and all(eq(k,l) and eq(a[k],b[l]) for k,l in zip(a,b))
 if isinstance(a,(list,tuple)):return len(a)==len(b) and all(eq(x,y) for x,y in zip(a,b))
 return a==b
def jb(x):return json.dumps(x,ensure_ascii=False,separators=(",",":"),allow_nan=False).encode()
def sha(p):
 h=hashlib.sha256()
 with Path(p).open("rb") as f:
  for v in iter(lambda:f.read(65536),b""):h.update(v)
 return h.hexdigest()
def identity(p):
 s=Path(p).stat();return [s.st_dev,s.st_ino,s.st_size,s.st_mode,s.st_mtime_ns,s.st_ctime_ns]
def ref(p):return {"path":str(p),"bytes":Path(p).stat().st_size,"sha256":sha(p)}
def fsyncdir(p):
 fd=os.open(p,os.O_RDONLY)
 try:os.fsync(fd)
 finally:os.close(fd)
def readref(r,cap=4*MIB):
 p=Path(r["path"])
 if set(r)!={"path","bytes","sha256"} or type(r["bytes"]) is not int or r["bytes"]>cap or p.is_symlink() or p.stat().st_size!=r["bytes"] or sha(p)!=r["sha256"]:raise ValueError("exact reference")
 return p.read_bytes()
def guard(category=None,extra=0):
 caps={"source":4*MIB,"state_trace":24*MIB,"failure":4*MIB}
 used={k:sum(p.stat().st_size for p in (ROOT/k).rglob("*") if p.is_file()) if (ROOT/k).exists() else 0 for k in caps}
 if ROOT.is_symlink() or any((ROOT/k).is_symlink() for k in caps):raise ValueError("scope symlink")
 if category is not None and used[category]+extra>caps[category]:raise MemoryError("local category cap")
 if sum(used.values())+extra>32*MIB:raise MemoryError("32MiB total")
 if shutil.disk_usage(B).free<(1024+988)*MIB:raise MemoryError("disk1GiB+full988MiB future")
 mem=next(int(z.split()[1])*1024 for z in open("/proc/meminfo") if z.startswith("MemAvailable:"))
 if mem<(4096+2048)*MIB:raise MemoryError("retained4GiB+floor2GiB")
 return {"used":used,"MemAvailable":mem}
class Clock:
 def __init__(self):
  self.remaining={"compute":600.0,"save":120.0};self.mode=None;self.started=None
  signal.signal(signal.SIGALRM,self.expire)
 def expire(self,*a):raise TimeoutError("column "+str(self.mode)+" aggregate deadline")
 def stop(self):
  signal.setitimer(signal.ITIMER_REAL,0)
  if self.mode is not None:self.remaining[self.mode]-=time.monotonic()-self.started
  self.mode=None;self.started=None
 def enter(self,mode):
  self.stop()
  if self.remaining[mode]<=0:raise TimeoutError("column "+mode+" exhausted")
  self.mode=mode;self.started=time.monotonic();signal.setitimer(signal.ITIMER_REAL,self.remaining[mode])
class IndexedRows:
 """Original row order/len and exact data projection, lazily reading complete selected rows."""
 def __init__(self,path,digest,allowed,onread=None):
  self.path=Path(path);self.digest=digest;self.allowed=set(allowed);self.onread=onread
  self.offsets=[];self.calls=[];self.cache=None;self.cache_index=None
  self.initial=identity(self.path);h=hashlib.sha256()
  with self.path.open("rb") as f:
   while True:
    at=f.tell();line=f.readline(8*MIB+1)
    if not line:break
    if len(line)>8*MIB:raise MemoryError("raw row8MiB stop")
    h.update(line)
    if line.strip():self.offsets.append({"offset":at,"bytes":len(line),"sha256":hashlib.sha256(line).hexdigest()})
  if h.hexdigest()!=digest or identity(self.path)!=self.initial:raise ValueError("whole raw source closure")
 def __len__(self):return len(self.offsets)
 def __getitem__(self,index):
  if type(index) is not int or index not in self.allowed or not 0<=index<len(self.offsets):raise IndexError("outside fixed teacher evidence rows")
  entry=self.offsets[index]
  with self.path.open("rb") as f:f.seek(entry["offset"]);raw=f.read(entry["bytes"])
  if hashlib.sha256(raw).hexdigest()!=entry["sha256"] or identity(self.path)!=self.initial:raise ValueError("row changed")
  item=json.loads(raw);value=item.get("data",item)
  evidence={"row":index,"raw":entry,"metadata":{k:v for k,v in value.items() if k!="frame"},"phases":[{"index":i,"sha256":hashlib.sha256(jb(frame)).hexdigest(),"height":len(frame),"width":len(frame[0]) if frame else 0} for i,frame in enumerate(value.get("frame",[]))]}
  self.calls.append({"row":index,"raw":entry})
  if self.onread:self.onread(evidence)
  self.cache=value;self.cache_index=index
  return value
 def close_check(self):
  if identity(self.path)!=self.initial or sha(self.path)!=self.digest:raise ValueError("final whole raw closure")
def capture_call(machine,method,external,held):
 previous=sys.getprofile()
 if previous is not None:raise PermissionError("existing profile not displaced")
 target=machine.排気系.排出する;code=target.__func__.__code__;receiver=target.__self__
 held["raw"]=[];held["events"]=[];held["profile_restored"]=False
 def observe(frame,event,arg):
  if event=="call" and frame.f_code is code and frame.f_locals.get("self") is receiver:
   held["raw"].append(frame.f_locals["結果"])
   held["events"].append({"function":code.co_name,"filename":code.co_filename,"firstlineno":code.co_firstlineno,"exact_code_self":True})
 sys.setprofile(observe)
 try:
  held["return"]=getattr(machine,method)(external)
 finally:
  sys.setprofile(previous);held["profile_restored"]=sys.getprofile() is previous
 if len(held["raw"])!=1 or len(held["events"])!=1 or not held["profile_restored"]:raise ValueError("exact single exhaust capture")
 return held["return"]
def snapshot_value(machine):
 e=machine.エンジン
 return {"形式版":3,"最小支持数":e.最小支持数,"最大条件数":e.最大条件数,"識別子状態":e.識別子.状態を書き出す(),"台帳":e.台帳.全取得(),"状態履歴":e.状態.履歴(),"原理履歴":e._原理履歴}
def frame_hash(frame):
 if not frame or not frame[0] or any(len(r)!=len(frame[0]) for r in frame) or any(type(v) is not int or not 0<=v<=15 for r in frame for v in r):raise ValueError("strict uint8 frame")
 return hashlib.sha256(bytes(v for r in frame for v in r)).hexdigest()
class APIView:
 """External measurement wrapper. Does not replace any core/module/instance method."""
 def __init__(self,owner):self.owner=owner
 def 処理する(self,external):return self.owner.call("処理する",external)
 def 照会する(self,external):return self.owner.call("照会する",external)
class Run:
 def __init__(self):
  self.clock=Clock();self.machine=None;self.modules=[];self.pending=None;self.current=None
  self.calls=[];self.rows_seen={};self.errors=[];self.exceptions=[];self.gate=None;self.complete=False
  self.trace_bytes=0;self.state_refs=[];self.phase="preflight";self.frame_ordinal=None;self.raw_observers=[]
 def encoded(self,v):
  x=self.enc(v);raw=jb(x);again=self.dec(json.loads(raw))
  if not eq(self.enc(again),x):raise ValueError("normal codec full types/order")
  return raw
 def save(self,name,value,category="state_trace",codec=True):
  self.pending={"name":name,"value":value};primary=None;self.clock.enter("save")
  try:
   raw=self.encoded(value) if codec else jb(value)
   if len(raw)>16*MIB:raise MemoryError("journal raw16MiB stop")
   blob=lzma.compress(raw,preset=0,check=lzma.CHECK_CRC64)
   if category=="state_trace" and self.trace_bytes+len(blob)>8*MIB:raise MemoryError("trace8MiB aggregate")
   guard(category,len(blob));folder=ROOT/category/self.gate["nonce"];folder.mkdir(exist_ok=True)
   p=folder/(name+".json.xz")
   with p.open("xb") as f:
    if f.write(blob)!=len(blob):raise OSError("short write")
    f.flush();os.fsync(f.fileno())
   fsyncdir(folder);fsyncdir(folder.parent)
   back=p.read_bytes();z=lzma.LZMADecompressor();decoded=z.decompress(back,max_length=16*MIB+1)
   if back!=blob or not z.eof or z.unused_data or z.check!=lzma.CHECK_CRC64 or decoded!=raw:raise ValueError("full journal CRC64/EOF/bytes")
   if category=="state_trace":self.trace_bytes+=len(blob)
   result={"file":ref(p),"rawbytes":len(raw),"rawsha256":hashlib.sha256(raw).hexdigest()}
   self.pending=None;return result
  except BaseException as e:primary=e;self.exceptions.append(e);raise
  finally:
   self.clock.stop()
   if primary is None:self.clock.enter("compute")
 def standard(self,label):
  primary=None;self.clock.enter("save")
  folder=ROOT/"state_trace"/self.gate["nonce"];folder.mkdir(exist_ok=True)
  p=folder/(label+".standard.json");self.pending={"standard":str(p)}
  try:
   guard("state_trace",8*MIB)
   fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600);oldstat=os.fstat(fd);os.close(fd);fsyncdir(folder)
   limits=resource.getrlimit(resource.RLIMIT_FSIZE);handler=signal.signal(signal.SIGXFSZ,lambda *a:(_ for _ in ()).throw(OSError("standard8MiB cap")))
   try:
    resource.setrlimit(resource.RLIMIT_FSIZE,(8*MIB,limits[1]));self.machine.保存する(p)
   finally:
    resource.setrlimit(resource.RLIMIT_FSIZE,limits);signal.signal(signal.SIGXFSZ,handler)
   fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
   try:
    st=os.fstat(fd)
    if (st.st_dev,st.st_ino)!=(oldstat.st_dev,oldstat.st_ino) or st.st_size>8*MIB:raise ValueError("reserved standard identity")
    os.fsync(fd)
   finally:os.close(fd)
   fsyncdir(folder);raw=p.read_bytes();value=self.dec(json.loads(raw))
   if not eq(self.enc(value),self.enc(snapshot_value(self.machine))):raise ValueError("full live standard value")
   if json.dumps(self.enc(value),ensure_ascii=False,indent=2).encode()!=raw:raise ValueError("standard byte/type/order roundtrip")
   r=ref(p);self.state_refs.append(r);self.pending=None;return r,value
  except BaseException as e:primary=e;self.exceptions.append(e);raise
  finally:
   self.clock.stop()
   if primary is None:self.clock.enter("compute")
 def markers(self):
  e=self.machine.エンジン
  return {"identifiers":e.識別子.状態を書き出す(),"ledger_lengths":{k:len(v) for k,v in e.台帳.全取得().items()},"principle_history_lengths":{k:len(v) for k,v in e._原理履歴.items()},"state_history_length":len(e.状態.履歴())}
 def call(self,method,external):
  if method!="照会する":raise PermissionError("Teach forbidden in goal pools")
  i=len(self.calls)
  # Observe teacher locals only for provenance. They never enter API content.
  origin={};f=sys._getframe()
  while f:
   if f.f_code is self.trainer.教師を取り込む.__code__:
    origin={k:f.f_locals[k] for k in ("i","origin","measurement") if k in f.f_locals};break
   f=f.f_back
  del f
  self.current={"ordinal":i,"phase":self.phase,"frame_ordinal":self.frame_ordinal,"method":method,"input":external,"origin":origin,"before":self.markers(),"capture":{}}
  intent=self.save("api_%04d_intent"%i,self.current)
  result=capture_call(self.machine,method,external,self.current["capture"])
  self.pool_returns.append((external,result))
  self.current["after"]=self.markers()
  reply=self.save("api_%04d_reply"%i,self.current)
  self.calls.append({"ordinal":i,"method":method,"phase":self.phase,"intent":intent,"reply":reply})
  self.current=None
  return result
 def row_read(self,evidence):
  n=str(evidence["row"])
  if n not in self.rows_seen:self.rows_seen[n]=self.save("teacher_row_%03d_all_phases"%int(n),evidence,codec=False)
 def load_module(self,name,path):
  sp=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(sp);self.modules.append(m);sp.loader.exec_module(m);return m
 def preflight(self,path,digest):
  raw=readref({"path":str(path),"bytes":Path(path).stat().st_size,"sha256":digest},65536);g=json.loads(raw);self.gate=g
  if g["schema"]!="column-goal-pools-release-v1" or g["enabled"] is not True or g["source_sha256"]!=sha(__file__):raise PermissionError("exact native root gate")
  if type(g["nonce"]) is not str or len(g["nonce"])!=32 or any(c not in "0123456789abcdef" for c in g["nonce"]):raise ValueError("nonce")
  if time.time()>g["admission_deadline_epoch"] or g["limits"]!={"AS":512*MIB,"compute":600,"save":120}:raise PermissionError("finite gate")
  if not eq(g["action_rows"],list(range(1,60))):raise PermissionError("all original action rows")
  if g.get("baseline_audit_approved") is not True:raise PermissionError("root baseline independent adoption")
  state=g["baseline_state"]
  if state!={"path":str(B/"arc-column-learning-20261013/state_trace/c2f866fa03f288e255c4c88aea21cb75/after_queries.standard.json"),"bytes":2197293,"sha256":"a631848f7805957e01791377c2b4993d9bcb27fc8ef301435d638d36066f7814"}:raise ValueError("exact baseline state")
  readref(state,8*MIB)
  audit=json.loads(readref(g["baseline_audit"],4*MIB))
  required=("all_state_except_two_counters_plus5","all85_intent_reply_and_native_ledger_joins","all92_raw_bindings_all2551_phase_hashes","78_inputs_from_original_measurements_order_and_returns","all27_pixels_actions_candidates_HOLD_exact","all_refs_CRC64_EOF_type_order_core_unchanged")
  if audit.get("schema")!="column-learning-independent-audit-v1" or audit.get("status")!="PASS" or audit.get("errors")!=[] or any(audit.get("verified",{}).get(k) is not True for k in required):raise ValueError("baseline actual independent PASS")
  completed=g["baseline_completion"];b=readref(completed["file"],4*MIB);z=lzma.LZMADecompressor();raw=z.decompress(b,max_length=16*MIB+1)
  if not z.eof or z.unused_data or z.check!=lzma.CHECK_CRC64 or len(raw)!=completed["rawbytes"] or hashlib.sha256(raw).hexdigest()!=completed["rawsha256"]:raise ValueError("baseline complete raw closure")
  c=json.loads(raw)
  if c["status"]!="complete" or c["errors"] or c["nonce"]!="c2f866fa03f288e255c4c88aea21cb75" or c["states"][-1]!=state or c["teach_calls"]!=78:raise ValueError("baseline completion join")
  exit_tool=json.loads(readref(g["baseline_actual_exit"],65536))
  if exit_tool.get("exit_code")!=0 or "UTCEND " not in exit_tool.get("output",""):raise ValueError("baseline actual exit")
  lines=exit_tool["output"].splitlines()
  if len(lines)!=2 or json.loads(lines[0]).get("receipt")!=completed:raise ValueError("baseline output receipt join")
  self.baseline_audit=audit
  structure=json.loads(readref(g["raw_structure_audit"]))
  if structure.get("schema")!="column-teacher-jsonl-audit-v2" or structure.get("state")!="complete" or structure.get("sha256")!=RAW_SHA or structure.get("json_errors")!=[] or structure.get("frame_shape_errors")!=0 or structure.get("pixel_domain_error_frames")!=0:raise ValueError("full raw audit")
  for r in DEPENDENCIES:readref(r,4*MIB)
  guard()
  sys.dont_write_bytecode=True;sys.path.insert(0,str(CORE));sys.path.insert(0,str(FAMILY))
  import hds学習系統 as native
  import hds学習系統.永続化 as persistence
  if Path(native.__file__).resolve()!=CORE/"hds学習系統/__init__.py":raise ValueError("core import identity")
  self.native=native;self.enc=persistence._符号化;self.dec=persistence._復号
  self.trainer=self.load_module("pinned_column_teacher",FAMILY/"道具/列図式教師検証.py")
  from 接続 import 列図式規則 as family
  if Path(family.__file__).resolve()!=FAMILY/"接続/列図式規則.py":raise ValueError("family import identity")
  self.family=family
  self.rows=IndexedRows(RAW,RAW_SHA,ROWS,self.row_read)
  self.save("raw_full_offset_index",{"source":ref(RAW),"identity":self.rows.initial,"all_offsets":self.rows.offsets,"selected_rows":list(ROWS),"all_other_rows_retained_in_source":True},codec=False)
 def execute(self):
  self.machine=self.native.HDS学習系統.読み込む(self.gate["baseline_state"]["path"])
  initial,learned=self.standard("restored_before")
  if initial["bytes"]!=self.gate["baseline_state"]["bytes"] or initial["sha256"]!=self.gate["baseline_state"]["sha256"]:raise ValueError("restored standard raw exact")
  view=APIView(self);self.phase="before_goal_pools";pools=[]
  for row in range(59):
   self.frame_ordinal=row;self.pool_returns=[]
   rawrow=self.rows[row];frames=rawrow.get("frame",[])
   self.current={"ordinal":row,"action_row":row+1,"before_row":row,"raw_source":{"path":str(RAW),"sha256":RAW_SHA},"raw_row":self.rows.offsets[row],"phase":len(frames)-1,"frame_sha256":hashlib.sha256(jb(frames[-1])).hexdigest() if frames else None,"frame_sha256_uint8":frame_hash(frames[-1]) if frames else None,"scene":None,"goal_pool":None,"error":None,"api_start":len(self.calls)}
   self.save("pool_%02d_input"%row,self.current)
   try:
    if not frames:raise ValueError("before has no observation phases")
    scene=self.family.図式を観測する(frames[-1])
   except ValueError as e:
    self.exceptions.append(e);self.current["error"]={"type":type(e).__name__,"message":str(e),"traceback":traceback.format_exc()};self.current["status"]="perception_inapplicable"
   else:
    # Existing function alone chooses complete solution pool; no action selection is invoked.
    context=self.current;context["scene"]=scene
    goal=self.family.内容候補を構成する(view,scene)
    self.current=context;self.current["goal_pool"]=goal;self.current["status"]="measured"
   self.current["api_end"]=len(self.calls)
   self.current["API_records"]=self.calls[self.current["api_start"]:self.current["api_end"]]
   self.current["learned_role_evidence"]=(self.current["goal_pool"] or {}).get("照会",{})
   roles=[];supports=[]
   for external,result in self.pool_returns:
    if external.対象系境界==self.family.役割境界:
     values={p["予測値"] for p in result.内容.get("予測群",[]) if tuple(p["結果経路"])==("列展開役割",)}
     if result.状態!="断定保留" and len(values)==1:roles.append({"記号は中空":external.内容["記号は中空"],"列展開役割":next(iter(values))})
     supports.extend(self.family._参照群(result.内容))
   self.current["work_measurement_capture"]={"前相画素SHA256":self.current["frame_sha256_uint8"],"実照会参照":self.current["API_records"],"役割支持参照":list(dict.fromkeys(supports)),"学習役割":roles,"全内容候補返却":self.current["goal_pool"]}
   pools.append(self.save("pool_%02d_result"%row,self.current))
   self.current=None
  final,last=self.standard("after_goal_pools")
  qcount=len(self.calls)
  if any(c["method"]!="照会する" for c in self.calls):raise ValueError("Teach forbidden")
  expected=self.dec(self.enc(learned))
  for key in ("照会","学習判定"):expected["識別子状態"][key]=expected["識別子状態"].get(key,0)+qcount
  if not eq(self.enc(last),self.enc(expected)):raise ValueError("all state except paired Query counters unchanged")
  self.rows.close_check()
  self.summary={"schema":"column-goal-pools-completion-v1","nonce":self.gate["nonce"],"status":"complete","errors":[],"source":ref(Path(__file__)),"baseline_state":self.gate["baseline_state"],"baseline_audit":self.gate["baseline_audit"],"baseline_completion":self.gate["baseline_completion"],"baseline_actual_exit":self.gate["baseline_actual_exit"],"states":self.state_refs,"api_calls":self.calls,"row_all_phase_refs":self.rows_seen,"pools":pools,"teach_calls":0,"query_calls":qcount,"Action":0,"new_clear":0,"case_count":59,"limits":"Existing fixed perception and complete assignment enumeration with learned HDS role/acceptance. No action selection, pruning, teacher labels or independent support added."}
  out=self.save("completion",self.summary,codec=False);self.complete=True;return out

def run(path,digest):
 global OWNER
 if OWNER is not None:raise RuntimeError("one run only")
 OWNER=Run()
 try:
  soft,hard=resource.getrlimit(resource.RLIMIT_AS)
  if not (0<soft<=512*MIB and 0<hard<=512*MIB):raise PermissionError("finite AS512 before import")
  OWNER.clock.enter("compute");OWNER.preflight(path,digest);result=OWNER.execute();OWNER.clock.stop()
  print(json.dumps({"status":"complete","receipt":result,"Teach":OWNER.summary["teach_calls"],"Query":OWNER.summary["query_calls"],"Action":0}),flush=True)
  return result
 except BaseException as e:
  OWNER.clock.stop();OWNER.exceptions.append(e);OWNER.errors.append(traceback.format_exc())
  original_pending=OWNER.pending
  try:
   if OWNER.gate:
    OWNER.save("failure",{"errors":OWNER.errors,"current":OWNER.current,"completed_api_calls":OWNER.calls,"states":OWNER.state_refs,"pending_descriptor":str(OWNER.pending.get("name")) if OWNER.pending else None},category="failure",codec=hasattr(OWNER,"enc"))
  except BaseException as secondary:OWNER.exceptions.append(secondary);OWNER.errors.append(traceback.format_exc())
  finally:OWNER.clock.stop();OWNER.pending=original_pending
  print(json.dumps({"status":"failed_held","errors":OWNER.errors},ensure_ascii=False),flush=True)
  while True:time.sleep(60)

DEPENDENCIES=[{'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/README.md', 'bytes': 622, 'sha256': 'fcb579bf30bf51a3d45d1935ba6c58c79baeef9c2c95df3c27046641e6f176d6'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/__init__.py', 'bytes': 527, 'sha256': 'eaed97760656afc40088ad7e0d85a02fbd59a0d0034054956e9ead63319fba57'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/台帳.py', 'bytes': 2815, 'sha256': 'a6cab8fca7cb591c42fa7444f9678fe0003da69faafcce852598286dceb522e2'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/吸気系.py', 'bytes': 3061, 'sha256': '50c48e5a9a8aa39158d0cdaacc0501608a829486960d41cb2fea6cb02e5660a4'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/型.py', 'bytes': 6575, 'sha256': 'aa1241708655280b36564f5e3ff6968849b4d09790b8932aabad1570cbca302c'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/実行系.py', 'bytes': 34178, 'sha256': '11d253705181873bcc22e312a0d0a2198fe16a82e3d7289ea8746fdc14695429'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/懐疑.py', 'bytes': 3392, 'sha256': 'bb7e85c2dbafbd430f1b7733bf3a2d307dc24e3227e79994b491cf711322f715'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/排気系.py', 'bytes': 2779, 'sha256': '2ba7ceb8d0d6c784d092f91fe484477127f044e50f68c54c977374b17f2f6361'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/推論.py', 'bytes': 11404, 'sha256': '315dd0d23a9682cdf14be71346341976cbdbcd2cbd924a250afc4ad53058dba6'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/検証.py', 'bytes': 2696, 'sha256': 'e23f271d38e1f52d75557dbf3342abf7b59a85fbdc315a06c0040fd7ca204eb3'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/永続化.py', 'bytes': 3125, 'sha256': '8aa431b3012424fd8347c5b3d93a5fbf2218d35020836f5d40abb427f9d6da0d'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/系統.py', 'bytes': 1951, 'sha256': 'f57e34fcab9249ad7fef72d7b9088fbb440c01afcd4313c9447b7a31427bd4a5'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/適応.py', 'bytes': 10139, 'sha256': 'c74797d49472646010ed0b37bd17dfa602084ba3347ac9386dec265e78a797ac'}, {'path': '/workspace/scratch/a94ff513b3af/arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/pyproject.toml', 'bytes': 173, 'sha256': 'c0d318c4a533f7ad7a2fe6f141cc44480a718def8c9794caf4a866e89b63961e'}, {'path': '/workspace/scratch/a94ff513b3af/arc-current-family-source-20261013/接続/列図式規則.py', 'bytes': 20302, 'sha256': 'd303b314446d22c604008d590636cccf6e1d140fbd365f22ff018b55d97de399'}, {'path': '/workspace/scratch/a94ff513b3af/arc-current-family-source-20261013/道具/列図式教師検証.py', 'bytes': 11873, 'sha256': 'f8a6bbca6a557973a7f54bdf0af8e85ed0419fcf5b463e10dcc310160245bc28'}, {'path': '/workspace/scratch/a94ff513b3af/arc-current-family-source-20261013/検証/test_列図式規則.py', 'bytes': 9912, 'sha256': '6202f490248cfd5f3734338b2bd119fedfe373c31b5abb6213119b1e07a91769'}, {'path': '/workspace/scratch/a94ff513b3af/arc-current-family-source-20261013/接続/列図式規則.md', 'bytes': 6946, 'sha256': 'b4e865988b1453cc350052e3300891d1935e745c92883b6dec4f327776df7569'}, {'path': '/workspace/scratch/a94ff513b3af/arc-current-family-source-20261013/接続/ARC3境界.py', 'bytes': 9941, 'sha256': 'ed95bb80f2326827c3f1237537a3df33203af8cac7881e46fd8b4d17e439d358'}, {'path': '/workspace/scratch/a94ff513b3af/arc-current-family-source-20261013/接続/図式観測.py', 'bytes': 1295, 'sha256': '417269f9e94ec548c7f727c3e263efe952bbae21cf601021bcfd4d89b1a786d2'}]
