import resource
resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912))
import sys,signal,importlib.util,hashlib,json,time,traceback
from pathlib import Path
MODULE=None;RETURN=None;ERRORS=[];EXCEPTIONS=[]
def timeout(*a):raise TimeoutError("outer import120")
signal.signal(signal.SIGALRM,timeout);signal.alarm(120)
try:
 path=Path(__file__).with_name("column_preservation_harness_v1.py")
 contract=json.loads(path.with_name("column_preservation_contract_v1.json").read_bytes())
 if hashlib.sha256(path.read_bytes()).hexdigest()!=contract["source"]["sha256"]:raise ValueError("source pin")
 sp=importlib.util.spec_from_file_location("column_native_harness",path);MODULE=importlib.util.module_from_spec(sp);sp.loader.exec_module(MODULE);signal.alarm(0)
 RETURN=MODULE.run(sys.argv[1],sys.argv[2])
 if not MODULE.OWNER.complete:raise ValueError("incomplete return")
 print("UTCEND "+__import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat(),flush=True)
except BaseException as e:
 signal.alarm(0);EXCEPTIONS.append(e);ERRORS.append(traceback.format_exc());print(json.dumps({"status":"outer_failed_held","errors":ERRORS}),flush=True)
 if MODULE is None or (getattr(MODULE,"OWNER",None) is None) or (MODULE.OWNER.machine is None and not MODULE.OWNER.calls):raise SystemExit(1)
 while True:time.sleep(60)
