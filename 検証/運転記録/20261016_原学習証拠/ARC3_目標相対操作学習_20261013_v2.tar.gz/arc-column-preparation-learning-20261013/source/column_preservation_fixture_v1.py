"""Fresh-scope persistence and saved-baseline plan checks only; HDS/nativeAPI0."""
import resource,signal
resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912));signal.alarm(120)
import importlib.util,json,lzma,hashlib,os,sys,traceback
from pathlib import Path
D=Path("/workspace/scratch/a94ff513b3af/arc-column-preparation-learning-20261013/source")
sp=importlib.util.spec_from_file_location("prep_fixture_subject",D/"column_preservation_harness_v2.py");m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
class Record:
 def __init__(self,tag,name,values):self._tag=tag;self._name=name;self._values=values;self.__dict__.update(values)
def dec(x):
 if isinstance(x,list):return [dec(v)for v in x]
 if isinstance(x,dict):
  if "__辞書__"in x:return {dec(k):dec(v)for k,v in x["__辞書__"]}
  if "__組__"in x:return tuple(dec(v)for v in x["__組__"])
  if "__データ型__"in x:return Record("__データ型__",x["__データ型__"],{k:dec(v)for k,v in x["値"].items()})
  if "__列挙__"in x:return Record("__列挙__",x["__列挙__"],{"value":x["値"]})
 return x
def enc(x):
 if isinstance(x,Record):
  return {x._tag:x._name,"値":x.value if x._tag=="__列挙__" else {k:enc(v)for k,v in x._values.items()}}
 if isinstance(x,tuple):return {"__組__":[enc(v)for v in x]}
 if isinstance(x,list):return [enc(v)for v in x]
 if isinstance(x,dict):return {"__辞書__":[[enc(k),enc(v)]for k,v in x.items()]}
 return x
def completion(exit_path):
 x=json.loads(Path(exit_path).read_bytes());return m.packet(json.loads(x["output"].splitlines()[0])["receipt"])
CASES=[];ERRORS=[]
try:
 m.guard("source",65536);original=m.ROOT;fresh=D/"preservation_fresh_scope_fixture_v1";assert not fresh.exists()
 m.ROOT=fresh;m.b.ROOT=fresh;m.b.ensure_scope()
 assert all((fresh/k).is_dir()for k in ("source","state_trace","failure"))
 owner=m.b.Run();owner.gate={"nonce":"fixture0000000000000000000000000"}
 a=owner.save("first",{"synthetic":True},codec=False);owner.clock.stop()
 m.ROOT=original;m.b.ROOT=original;CASES.append({"name":"fresh_scope_first_save","result":a})
 r=object.__new__(m.Run);r.enc=enc;r.dec=dec
 r.old_completion=completion(m.B/"arc-column-learning-20261013/source/native_actual_exit_c2f866fa_v1.json")
 r.repair_completion=completion(m.B/"arc-column-work-learning-20261013/source/native_actual_exit_b0ed233c_v1.json")
 r.old_state=dec(json.loads(m.readref(r.old_completion["states"][1],8*m.MIB)))
 r.family=type("SavedBoundaryNames",(),{"役割境界":"公開列図式:記号外形と展開役割","目標境界":"公開列図式:有限全列または生産的反復の目標長一致と提出受理","作用境界":"公開列図式:観測された解答作業と行動ID"})()
 plan=r.regression_plan();assert len(plan)==7
 CASES.append({"name":"all_original2_2_3_plan","plan":plan})
 c=json.loads(m.readref(m.PRESERVATION_CONTRACT));pack=m.packet(c["actual"]["pack"],dec,enc)
 assert len(pack["teachers"])==24 and pack["eligible_unknown_rows"]==[]
 assert all(list(t["query_input"])==[m.X] and list(t["teacher"])==[m.X,m.Y] and type(t["teacher"][m.X])is str and type(t["teacher"][m.Y])is bool for t in pack["teachers"])
 CASES.append({"name":"actual24_input_shapes","material":c["actual"]["pack"],"rows":[t["row"]for t in pack["teachers"]]})
 owner=object.__new__(m.Run);owner.calls=[None]*84
 try:owner.call("照会する",None)
 except PermissionError as e:CASES.append({"name":"API84_ceiling","type":type(e).__name__,"repr":repr(e)})
 else:raise AssertionError("API ceiling")
 source=(D/"column_preservation_harness_v2.py").read_text()
 assert source.index('query_ref=self.save("all58_regression_replies"')<source.index("scoring=[]")
 assert "expected[\"識別子状態\"][k]+=58"in source
 assert not any(k.startswith("hds学習系統")for k in sys.modules)
 CASES.append({"name":"no_HDS_import_and_scoring_after_durable_replies","native_API":0})
 operations=[x['query_input']['解答作業'] for x in plan if x['boundary']==r.family.作用境界]
 assert '在庫記号を選択' in operations and '選択記号を空欄へ割当' in operations
 assert '選択記号を枠へ置く' not in source
 CASES.append({'name':'two_mapping_labels_are_original_learned_inputs','all_original':operations})
 u=m.guard()['used'];forecast=2982700+16*m.MIB+20*m.MIB
 assert u['state_trace']+forecast<=48*m.MIB
 CASES.append({'name':'full_worst_case_storage_stops','existing':u,'prospective':forecast,'total':u['state_trace']+forecast})

 result={"schema":"column-preservation-learning-pure-fixture-v1","status":"PASS","cases":CASES,"errors":[],"limits":"Saved tagged records decoded into inert records; no actual core class, HDS import, Teach, Query or restore."}
except BaseException as e:
 ERRORS.append({"type":type(e).__name__,"repr":repr(e),"traceback":traceback.format_exc()});result={"status":"FAIL","cases":CASES,"errors":ERRORS}
finally:
 signal.alarm(0);m.ROOT=D.parent;m.b.ROOT=m.ROOT
 raw=json.dumps(enc(result),ensure_ascii=False,separators=(",",":")).encode();b=lzma.compress(raw,preset=0,check=lzma.CHECK_CRC64)
 m.guard("source",len(b));p=D/"preservation_fixture_result_v1.json.xz"
 with p.open("xb")as f:f.write(b);f.flush();os.fsync(f.fileno())
 m.b.fsyncdir(D);z=lzma.LZMADecompressor();back=z.decompress(p.read_bytes());assert z.eof and not z.unused_data and z.check==lzma.CHECK_CRC64 and back==raw and m.eq(enc(dec(json.loads(back))),json.loads(raw))
 print(json.dumps({"status":result["status"],"cases":len(CASES),"result":{"file":m.ref(p),"rawbytes":len(raw),"rawsha256":hashlib.sha256(raw).hexdigest()},"errors":ERRORS},ensure_ascii=False))
 if result["status"]!="PASS":raise SystemExit(1)
