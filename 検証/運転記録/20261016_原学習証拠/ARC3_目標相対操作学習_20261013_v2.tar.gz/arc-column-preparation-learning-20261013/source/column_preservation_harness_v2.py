"""Preservation24 continuation. Reuses immutable work-v3 IO/profile/normal persistence; no core edits."""
import hashlib,importlib.util,json,lzma,os,resource,shutil,sys,time
from pathlib import Path
B=Path("/workspace/scratch/a94ff513b3af");MIB=1048576
ROOT=B/"arc-column-preparation-learning-20261013"
BASE=B/"arc-column-work-learning-20261013/source/column_work_harness_v3.py"
BASE_SHA="f0d73f35a9516eda585b134ae54be9815b36d6164786b9f8a0966c3983640007"
if hashlib.sha256(BASE.read_bytes()).hexdigest()!=BASE_SHA:raise ValueError("immutable IO base")
sp=importlib.util.spec_from_file_location("preparation_io_base",BASE);b=importlib.util.module_from_spec(sp);sp.loader.exec_module(b)
eq=b.eq;readref=b.readref;ref=b.ref
OWNER=None
X="可視対象に対する操作区分"
Y="応答全相で既充足枠が保持された"
BOUNDARY="公開列図式・一意目標候補・既充足枠非空・可視対象操作の全相保存"
PREP_CONTRACT={"path":str(B/"arc-column-preparation-teacher-20261013/source/contract_v1.json"),"bytes":3964,"sha256":"7b3bf39fd79f61c53cbe9fdab49f92c5895aa58648dce88b372302100abfceeb"}
REPAIR_STATE={"path":str(B/"arc-column-work-learning-20261013/state_trace/b0ed233c65f273f9dca51289ed9b80cc/after_queries.standard.json"),"bytes":2556440,"sha256":"4016573bafe9ce92c13566b022ad231cc2611eb4f35020ae57435fb941da312d"}
REPAIR_AUDIT={"path":str(B/"arc-column-learning-audit-20261013/result/repair13_audit_summary_v1.json"),"bytes":60127,"sha256":"1f22bbf89a7f0d876606f771ba3258bbb35759e2f47509cb4d4a463b9c288a7c"}
PREPARATION_STATE={"path":str(ROOT/"state_trace/de69b52d4c3717fd331eb420149bf7a1/after_queries.standard.json"),"bytes":2982700,"sha256":"b98bd02f3e8fbaa710d87e99694bfca997236d4811031cc95951495186d5bc19"}
PREPARATION_AUDIT={"path":str(B/"arc-column-learning-audit-20261013/result/preparation14_audit_summary_v1.json"),"bytes":192017,"sha256":"c9464d76f365a2818f3b1e087452e16b20b8d33f9ce44eafcdbe8cc85987ff8c"}
PRESERVATION_CONTRACT={"path":str(B/"arc-column-preparation-teacher-20261013/source/preservation_contract_v1.json"),"bytes":3210,"sha256":"a378f2bb5361c1f1978deffa42b9a510d7ae055fc05fea8c52be1e9bb50498b1"}
def guard(category=None,extra=0):
 caps={"source":4*MIB,"state_trace":48*MIB,"failure":12*MIB};used={}
 if ROOT.is_symlink():raise ValueError("scope symlink")
 for k,cap in caps.items():
  p=ROOT/k;files=list(p.rglob("*")) if p.exists() else []
  if p.is_symlink() or any(x.is_symlink()for x in files):raise ValueError("scope member symlink")
  used[k]=sum(x.stat().st_size for x in files if x.is_file())
  if used[k]+(extra if category==k else 0)>cap:raise MemoryError("category "+k)
 if sum(used.values())+extra>64*MIB:raise MemoryError("scope64MiB")
 if shutil.disk_usage(B).free<(1348+1024)*MIB+extra:raise MemoryError("future1348MiB+floor1GiB")
 mem=int(next(x.split()[1]for x in Path("/proc/meminfo").read_text().splitlines()if x.startswith("MemAvailable:")))*1024
 if mem<(4608+2048)*MIB:raise MemoryError("retained4.5GiB+floor2GiB")
 return {"used":used,"MemAvailable":mem}
# Bind only this newly imported external harness instance. No old source or HDS object is edited.
b.ROOT=ROOT;b.guard=guard
def packet(r,dec=None,enc=None):
 z=lzma.LZMADecompressor();raw=z.decompress(readref(r["file"],16*MIB),max_length=16*MIB+1)
 if not z.eof or z.unused_data or z.check!=lzma.CHECK_CRC64 or len(raw)!=r["rawbytes"] or hashlib.sha256(raw).hexdigest()!=r["rawsha256"]:raise ValueError("packet CRC/EOF/raw")
 tag=json.loads(raw)
 if dec is None:return tag
 v=dec(tag)
 if enc is not None and not eq(enc(v),tag):raise ValueError("whole codec types/order")
 return v
def semantic(r):
 return {"state":r.状態,"predictions":r.内容.get("予測群",[]),"HOLD_reasons":r.内容.get("断定保留理由群",[])}
def one_result(r,path):
 ps=r.内容.get("予測群",[]);wanted=[p for p in ps if tuple(p["結果経路"])==(path,)]
 return ps,wanted
class Run(b.Run):
 def __init__(self):
  super().__init__();global OWNER;OWNER=self;self.pool_returns=[];self.plan=None;self.current_expectation=None
 def save(self,name,value,category="state_trace",codec=True):
  if category=="state_trace":
   self.pending={"name":name,"value":value}
   raw=self.encoded(value) if codec else b.jb(value)
   if len(raw)>16*MIB:raise MemoryError("journal raw16MiB stop")
   blob=lzma.compress(raw,preset=0,check=lzma.CHECK_CRC64)
   if self.trace_bytes+len(blob)>20*MIB:raise MemoryError("this run journal20MiB storage envelope")
   del blob,raw
  return super().save(name,value,category,codec)
 def call(self,method,external):
  if len(self.calls)>=84:raise PermissionError("API84 ceiling")
  expected=self.current_expectation
  if expected is None or method!=expected["method"] or external.対象系境界!=expected["boundary"] or not eq(external.内容,expected["content"]):raise PermissionError("exact planned input")
  i=len(self.calls);self.current={"ordinal":i,"phase":self.phase,"frame_ordinal":self.frame_ordinal,"method":method,"input":external,"origin":expected["origin"],"before":self.markers(),"capture":{}}
  intent=self.save("api_%04d_intent"%i,self.current)
  result=b.capture_call(self.machine,method,external,self.current["capture"])
  self.current["after"]=self.markers();reply=self.save("api_%04d_reply"%i,self.current)
  self.calls.append({"ordinal":i,"method":method,"phase":self.phase,"intent":intent,"reply":reply})
  self.current=None;return result
 def invoke(self,method,content,boundary,origin):
  self.current_expectation={"method":method,"content":content,"boundary":boundary,"origin":origin}
  try:return self.call(method,self.native.外部入力(content,boundary))
  finally:self.current_expectation=None
 def preflight(self,path,digest):
  g=json.loads(readref({"path":str(path),"bytes":Path(path).stat().st_size,"sha256":digest},65536));self.gate=g
  if g["schema"]!="column-preservation-learning-release-v1" or g["enabled"]is not True or g["source_sha256"]!=b.sha(__file__):raise PermissionError("root release")
  if type(g["nonce"])is not str or len(g["nonce"])!=32 or any(x not in "0123456789abcdef"for x in g["nonce"]):raise ValueError("nonce")
  if time.time()>g["admission_deadline_epoch"] or g["limits"]!={"AS":512*MIB,"compute":600,"save":120}:raise PermissionError("limits")
  if g["baseline_state"]!=PREPARATION_STATE or g["baseline_audit"]!=PREPARATION_AUDIT:raise ValueError("exact closed preparation14")
  audit=json.loads(readref(PREPARATION_AUDIT))
  if audit["schema"]!="column-preparation14-independent-audit-v1" or audit["status"]!="PASS" or audit["errors"] or len(audit["verified"])!=5 or any(v is not True for v in audit["verified"].values()):raise ValueError("preparation independent PASS")
  self.preparation_completion=packet(g["baseline_completion"]);c=self.preparation_completion
  if c["status"]!="complete" or c["errors"] or c["states"][-1]!=PREPARATION_STATE or c["teach_calls"]!=14 or c["query_calls"]!=35:raise ValueError("preparation closure")
  if audit["completion"]!=g["baseline_completion"]["file"] or audit["actual_exit"]!=g["baseline_actual_exit"]:raise ValueError("audit producer join")
  ex=json.loads(readref(g["baseline_actual_exit"]));lines=ex["output"].splitlines()
  if ex["exit_code"]!=0 or len(lines)!=2 or not lines[1].startswith("UTCEND ") or json.loads(lines[0])["receipt"]!=g["baseline_completion"]:raise ValueError("actual exit")
  for r in b.DEPENDENCIES:readref(r,4*MIB)
  readref(g["source_contract"])
  contract=json.loads(readref(PRESERVATION_CONTRACT));readref(contract["source"])
  if contract["boundary"]!=BOUNDARY or contract["input"]!=X or contract["output"]!=Y:raise ValueError("material schema")
  self.material_contract=contract
  pure_path=B/"arc-column-work-learning-20261013/source/column_work_pack_v3.py"
  if b.sha(pure_path)!="bca394e4e4689a2d42e60510b992e137c17061b3fcbfbc5bbf9ffcb444102f0e":raise ValueError("pure codec helper pin")
  self.pure=self.load_module("preservation_codec",pure_path);enc,dec=self.pure.codec()
  self.pack=packet(contract["actual"]["pack"],dec,enc)
  self.projection=self.load_module("preservation_projection",Path(contract["source"]["path"]));p,repair=self.projection.bootstrap()
  if self.pack["status"]!="complete" or self.pack["eligible_unknown_rows"] or len(self.pack["all59"])!=59 or len(self.pack["teachers"])!=24:raise ValueError("complete24, unknown cannot pass")
  teachers=[]
  for i,x in enumerate(self.pack["all59"],1):
   rawcase=packet(x["case_ref"],dec,enc);again=self.projection.project(rawcase,p,repair,self.pack["learned_click_evidence"]["number"]);again["case_ref"]=x["case_ref"]
   if not eq(again,x) or x["row"]!=i:raise ValueError("all59 independent preservation projection")
   if x["decision"]["eligible_before"]:
    if x["outcome_status"]!="measured" or x["teacher"]is None:raise ValueError("eligible HOLD")
    teachers.append({"ordinal":len(teachers),"row":i,"case_ref":x["case_ref"],"query_input":x["decision"]["query_input"],"teacher":x["teacher"],"boundary":BOUNDARY})
  if not eq(teachers,self.pack["teachers"]):raise ValueError("original24 order")
  for t in teachers:
   if list(t["teacher"])!=[X,Y] or list(t["query_input"])!=[X] or type(t["teacher"][X])is not str or t["teacher"][X]not in contract["values"] or type(t["teacher"][Y])is not bool or t["boundary"]!=BOUNDARY:raise ValueError("strict string,bool teacher")
  # Whole predecessor gate is immutable ancestry evidence, never rewritten or used as this run's gate.
  pg=json.loads(readref(g["preparation_gate"]))
  if pg["source_sha256"]!="2704bdf0bbad8313c5887585d328892d68f15b90eb7c200cd9a2b46057badaf2" or pg["nonce"]!=c["nonce"]:raise ValueError("preparation gate ancestry")
  self.repair_completion=packet(pg["baseline_completion"])
  if self.repair_completion["states"][-1]!=REPAIR_STATE or self.repair_completion["teach_calls"]!=13:raise ValueError("repair ancestor")
  self.old_completion=packet(pg["old78_completion"])
  if self.old_completion["teach_calls"]!=78:raise ValueError("old78")
  guard();sys.dont_write_bytecode=True;sys.path.insert(0,str(b.CORE));sys.path.insert(0,str(b.FAMILY))
  import hds学習系統 as native
  import hds学習系統.永続化 as persistence
  if Path(native.__file__).resolve()!=b.CORE/"hds学習系統/__init__.py":raise ValueError("native core identity")
  self.native=native;self.enc=persistence._符号化;self.dec=persistence._復号
  from 接続 import 列図式規則 as family
  self.family=family
  self.repair_pack=packet(self.repair_completion["teacher_pack"],self.dec,self.enc)
  pc=json.loads(readref(PREP_CONTRACT));self.preparation_pack=packet(pc["runtime"]["pack"],self.dec,self.enc)
  if c["material_contract"]!=PREP_CONTRACT:raise ValueError("prior preparation material")
  self.old_state=self.dec(json.loads(readref(self.old_completion["states"][1],8*MIB)))
  self.plan=self.regression_plan()
  self.save("all24_material",self.pack);self.save("original_regression_plan",self.plan)
 def regression_plan(self):
  groups=[(self.family.役割境界,"記号は中空","列展開役割"),(self.family.目標境界,"終端条件に応じた列が一致","提出が受理された"),(self.family.作用境界,"解答作業","必要行動ID")]
  entries=[];history={}
  # Actual saved replies are references, never rerun native baseline.
  for completed in (self.old_completion,self.repair_completion):
   for ap in completed["api_calls"]:
    r=packet(ap["reply"],self.dec,self.enc);external=r["input"]
    if ap["method"]=="照会する":
     key=(external.対象系境界,b.jb(self.enc(external.内容)).hex());history.setdefault(key,{"ref":ap["reply"],"reply":r["capture"]["return"]})
  for boundary,key,out in groups:
   values=[]
   for ap in self.old_completion["api_calls"]:
    if ap["method"]!="処理する":continue
    r=packet(ap["intent"],self.dec,self.enc);e=r["input"]
    if e.対象系境界==boundary and key in e.内容 and not any(eq(e.内容[key],v)for v in values):values.append(e.内容[key])
   for value in values:
    content={key:value};hist=history.get((boundary,b.jb(self.enc(content)).hex()))
    active=set(self.old_state["状態履歴"][-1].values());rules=[r for r in self.old_state["台帳"]["原理台帳"] if r.原理識別子 in active and r.対象系境界==boundary and r.条件経路群==((key,),) and r.結果経路==(out,)]
    if len(rules)!=1:raise ValueError("one original active relationship")
    rule=rules[0];k=json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(",",":"))
    outcomes=[v for keys,v in rule.対応値表 if keys==(k,)]
    if len(outcomes)!=1:raise ValueError("stored observed condition correspondence")
    entries.append({"boundary":boundary,"query_input":content,"output_key":out,"expected_value":outcomes[0],"baseline_rule":rule,"historical":hist,
      "comparison_kind":"historical actual query" if hist else "saved standard relationship expectation versus first real query"})
  if len(entries)!=7 or [sum(x["boundary"]==g[0]for x in entries)for g in groups]!=[2,2,3]:raise ValueError("all distinct baseline2+2+3")
  return entries
 def execute(self):
  self.machine=self.native.HDS学習系統.読み込む(PREPARATION_STATE["path"])
  initial,old=self.standard("restored_before")
  if initial["bytes"]!=PREPARATION_STATE["bytes"] or initial["sha256"]!=PREPARATION_STATE["sha256"]:raise ValueError("normal restore full bytes")
  self.phase="operation_mappings";self.frame_ordinal=None;mapping_results=[]
  for operation in ("在庫記号を選択","選択記号を空欄へ割当"):
   mapping=self.invoke("照会する",{"解答作業":operation},self.family.作用境界,{"material":PRESERVATION_CONTRACT,"operation":operation})
   _,mp=one_result(mapping,"必要行動ID");numbers=[p["予測値"]for p in mp]
   if mapping.状態=="断定保留" or not numbers or any(type(v)is not int or v!=self.pack["learned_click_evidence"]["number"]for v in numbers) or not self.family._参照群(mapping.内容):raise ValueError("current supported operation Action mapping")
   mapping_results.append({"operation":operation,"reply":mapping,"API":self.calls[-1]})
  mapping_ref=self.save("operation_mappings",mapping_results)
  self.phase="preservation_teachers";teacher_results=[]
  for t in self.pack["teachers"]:
   self.frame_ordinal=t["ordinal"];r=self.invoke("処理する",dict(t["teacher"]),BOUNDARY,{"material_case":t["case_ref"],"ordinal":t["ordinal"],"row":t["row"]})
   teacher_results.append({"teacher":t,"reply":r,"API":self.calls[-1]})
  teacher_ref=self.save("all24_teachers",teacher_results);trained,learned=self.standard("after_teachers")
  for key,values in old["台帳"].items():
   if not eq(self.enc(learned["台帳"][key][:len(values)]),self.enc(values)):raise ValueError("old105 ledger prefix")
  if not eq(self.enc(learned["状態履歴"][:len(old["状態履歴"])]),self.enc(old["状態履歴"])):raise ValueError("old state prefix")
  for key,values in old["原理履歴"].items():
   if not eq(self.enc(learned["原理履歴"][key][:len(values)]),self.enc(values)):raise ValueError("old principle version prefix")
  if learned["識別子状態"]["経験"]-old["識別子状態"]["経験"]!=24 or any(learned["識別子状態"][k]-old["識別子状態"][k]!=2 for k in ("照会","学習判定")):raise ValueError("Teach24 mappingQuery2")
  allqueries=[]
  groups=[("preservation_regression",self.pack["teachers"]),("baseline_regression",self.plan),("repair_regression",self.repair_pack["teachers"]),("preparation_regression",self.preparation_pack["teachers"])]
  for name,items in groups:
   self.phase=name
   for i,t in enumerate(items):
    self.frame_ordinal=i;r=self.invoke("照会する",dict(t["query_input"]),t["boundary"],{"group":name,"index":i,"evidence":t.get("case_ref"),"baseline_kind":t.get("comparison_kind")})
    allqueries.append({"group":name,"index":i,"reply":r,"API":self.calls[-1]})
  query_ref=self.save("all58_regression_replies",allqueries);final,last=self.standard("after_queries")
  expected=self.dec(self.enc(learned))
  for k in ("照会","学習判定"):expected["識別子状態"][k]+=58
  if not eq(self.enc(expected),self.enc(last)):raise ValueError("all query state except two counters")
  scoring=[];offset=0
  for name,items in groups:
   for i,t in enumerate(items):
    item=allqueries[offset];offset+=1;r=item["reply"]
    key=t["output_key"] if name=="baseline_regression" else next(k for k in t["teacher"]if k not in t["query_input"])
    truth=t["expected_value"] if name=="baseline_regression" else t["teacher"][key]
    ps,wanted=one_result(r,key);values=[v["予測値"]for v in wanted]
    score={"group":name,"index":i,"row":t.get("row"),"expected":truth,"all_predictions":ps,"correct":bool(values) and all(eq(v,truth)for v in values),"wrong":any(not eq(v,truth)for v in values),"missing":not values,"extra":[p for p in ps if tuple(p["結果経路"])!=(key,)],"HOLD":r.状態=="断定保留","state":r.状態}
    if name=="baseline_regression":
     rule=t["baseline_rule"];score.update(comparison_kind=t["comparison_kind"],baseline_rule=rule,historical_ref=t["historical"]["ref"]if t["historical"]else None,
      support_rule_refs_match=all(p["原理参照"]==rule.原理識別子 for p in wanted) and bool(wanted),
      historical_semantics_equal=eq(semantic(r),semantic(t["historical"]["reply"])) if t["historical"] else None)
    if name=="repair_regression":
     prior=packet(self.repair_completion["queries"],self.dec,self.enc)[i]
     score["historical_semantics_equal"]=eq(semantic(r),semantic(prior["reply"]));score["historical_ref"]=prior["API"]["reply"]
    if name=="preparation_regression":
     prior=packet(self.preparation_completion["queries"],self.dec,self.enc)[i]
     if prior["group"]!="preparation_regression":raise ValueError("prior preparation query order")
     score["historical_semantics_equal"]=eq(semantic(r),semantic(prior["reply"]));score["historical_ref"]=prior["API"]["reply"]
    scoring.append(score)
  score_ref=self.save("all_regression_scoring",scoring)
  if len(self.calls)!=84 or sum(a["method"]=="処理する"for a in self.calls)!=24:raise ValueError("84 exactAPI")
  self.summary={"schema":"column-preservation-learning-completion-v1","nonce":self.gate["nonce"],"status":"complete","errors":[],"source":ref(Path(__file__)),"source_contract":self.gate["source_contract"],
   "baseline_state":PREPARATION_STATE,"baseline_audit":PREPARATION_AUDIT,"material_contract":PRESERVATION_CONTRACT,"states":self.state_refs,"api_calls":self.calls,"mapping":mapping_ref,"teachers":teacher_ref,"queries":query_ref,"scoring":score_ref,
   "teach_calls":24,"query_calls":60,"Action":0,"new_clear":0,"limits":"Same public correlated trajectory. No independent-support increment or unseen-policy/clear claim. Submission old mapping comparison is stored-rule expectation, not historical-query regression. All observed preservation True with no real counterexample; no universal safety claim."}
  out=self.save("completion",self.summary,codec=False);self.complete=True;return out
def run(path,digest):
 b.Run=Run
 return b.run(path,digest)
