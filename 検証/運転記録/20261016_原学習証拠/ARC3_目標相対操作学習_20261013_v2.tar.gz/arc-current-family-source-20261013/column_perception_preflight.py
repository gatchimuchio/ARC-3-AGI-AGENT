"""全公開初期相へ既存列知覚のみ適用。HDS教示・照会・Actionなし。"""
import base64, hashlib, json, math, os, pathlib, resource, signal, sys
from collections import Counter

B = pathlib.Path('/workspace/scratch/a94ff513b3af')
D = B / 'arc-current-family-source-20261013'
sys.dont_write_bytecode = True
sys.path.insert(0, str(D))
sys.path.insert(0, str(B / 'arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2'))
resource.setrlimit(resource.RLIMIT_AS, (512*1024**2, 512*1024**2))
signal.alarm(120)
from 接続.列図式規則 import 図式を観測する, 知覚不適用

def save(name, value):
    raw = (json.dumps(value, ensure_ascii=False, indent=2)+'\n').encode()
    assert len(raw) <= 1024**2
    p = D / name
    with p.open('xb') as f:
        f.write(raw); f.flush(); os.fsync(f.fileno())
    assert p.read_bytes() == raw
    fd=os.open(D,os.O_RDONLY);os.fsync(fd);os.close(fd)
    return {'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}

paths = sorted((B/'arc-official-fresh-all25-20261013/observation').glob('*.public.json'))
assert len(paths)==25
rows=[]
for p in paths:
    raw=p.read_bytes(); packet=json.loads(raw)
    origin={'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
    assert packet['frame_count']==len(packet['frames'])
    for fr in packet['frames']:
        pixels=base64.b64decode(fr['base64'],validate=True)
        assert fr['dtype']=='|i1' and fr['shape']==[64,64] and fr['order']=='C'
        assert len(pixels)==fr['bytes']==4096
        assert hashlib.sha256(pixels).hexdigest()==fr['sha256']
        assert all(0<=v<=15 for v in pixels)
        frame=[list(pixels[i:i+64]) for i in range(0,4096,64)]
        row={'元観測':origin,'相':fr['ordinal'],'画素SHA256':fr['sha256'],
             '照合状態':'未確認','HDS照会':False,'作用実行':False}
        try:
            scene=図式を観測する(frame)
            slots=[s for z in scene['容器群'] for s in z['枠群'] if s['記号'] is None]
            inventory=scene['在庫群']; counts=Counter((x['記号']['色'],x['記号']['中空']) for x in inventory)
            row.update({'照合状態':'固定知覚に適合','場面':scene,'空欄数':len(slots),'在庫数':len(inventory),
                        '全順列作業上限':math.factorial(len(inventory)),
                        '同値記号を除いた全配置数':math.factorial(len(inventory))//math.prod(math.factorial(n) for n in counts.values()),
                        '注記':'個数一致・学習支持・目標到達・実作用の成立は未検証'})
        except 知覚不適用 as e:
            row.update({'照合状態':'当該固定知覚に不適用','例外型':type(e).__name__,'理由':str(e)})
        except (ValueError,TypeError,KeyError) as e:
            row.update({'例外型':type(e).__name__,'理由':str(e)})
        ref=save(f'column_perception_case_{len(rows):02d}.json',row)
        rows.append({'参照':ref,'状態':row['照合状態']})
assert len(rows)==27
ref=save('column_perception_preflight_result.json',{'状態':'全27相の純知覚照合完了','結果':rows,
         '集計':dict(Counter(x['状態'] for x in rows)),'Teach':0,'Query':0,'Action':0,'新規clear':0})
print(json.dumps(ref)); print(dict(Counter(x['状態'] for x in rows)))
