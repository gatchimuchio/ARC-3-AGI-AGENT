#!/usr/bin/env python3
"""Read-only source snapshot, bounded streaming archive and exact readback.

Writes only its own checkpoint scope. It performs no Git, network, SDK, HDS,
Teach, Query or Action calls. It never extracts an archive or follows symlinks.
"""
import argparse
import gzip
import hashlib
import io
import json
import lzma
import os
from pathlib import Path
import re
import resource
import shutil
import stat
import tarfile
import time

B = Path('/workspace/scratch/a94ff513b3af')
O = B / 'arc-goal-operation-checkpoint-20261013'
MiB = 1024 ** 2
CAP = 128 * MiB
AS = 512 * MiB
BLOCK = MiB
SCOPES = [
 'arc-current-family-source-20261013',
 'arc-column-teacher-recovery-20261013',
 'arc-column-phase-audit-20261013',
 'arc-column-learning-20261013',
 'arc-column-learning-audit-20261013',
 'arc-column-goal-pools-20261013',
 'arc-column-goal-work-measurement-20261013',
 'arc-column-work-learning-20261013',
 'arc-column-preparation-teacher-20261013',
 'arc-column-preparation-learning-20261013',
]
AUTHORITY = [
 'arc-recovery-authority-20261013/Owner指示書原文_20261009.md',
 'arc-recovery-authority-20261013/Owner追加指示原文_20261010T1907.md',
 'arc-recovery-authority-20261013/Owner追加指示原文_20261011T1904.md',
 'arc-recovery-main-20261013/repository/AGENTS.md',
 'arc-recovery-main-20261013/repository/運用/権限順序.md',
 'arc-recovery-main-20261013/repository/制御/現在状態.json',
]
CORE = 'arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2'
F25 = 'arc-official-fresh-all25-20261013/observation'
PACKAGED_OWN = [
 '報告書_v2.txt', 'source/build_checkpoint_v2.py', 'source/preparation_preflight.json',
 'source/closure_pins.json', 'source/build_preflight_v2.json',
]
SECRET_PATTERNS = [
 re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),
 re.compile(rb'\bAKIA[A-Z0-9]{16}\b'),
 re.compile(rb'\bgh[pousr]_[A-Za-z0-9]{30,}\b'),
 re.compile(rb'\bsk-(?:proj-)?[A-Za-z0-9_-]{35,}\b'),
 re.compile(rb'(?i)[\"\x27]authorization[\"\x27]\s*:\s*[\"\x27]Bearer\s+[A-Za-z0-9._-]{20,}'),
]

def encoded(o):
    return (json.dumps(o, ensure_ascii=False, indent=2, sort_keys=True) + '\n').encode()

def scope_bytes():
    total = 0
    for p in O.rglob('*'):
        s = p.lstat()
        if stat.S_ISLNK(s.st_mode):
            raise RuntimeError('Symlink in output scope: ' + str(p))
        if stat.S_ISREG(s.st_mode):
            total += s.st_size
    return total

def resources():
    m = {k: int(v.split()[0]) * 1024 for k, v in
         (x.split(':', 1) for x in Path('/proc/meminfo').read_text().splitlines())}
    r = {'epoch': time.time(), 'disk_available': shutil.disk_usage(B).free,
         'disk_future_reserved': 1476 * MiB, 'disk_floor': 1024 * MiB,
         'scope_cap': CAP, 'scope_bytes': scope_bytes(),
         'RAM_available': m['MemAvailable'], 'RAM_retained': 4608 * MiB,
         'RAM_floor': 2048 * MiB, 'builder_AS': AS}
    assert r['disk_available'] >= r['disk_future_reserved'] + r['disk_floor'] + CAP
    assert r['RAM_available'] >= r['RAM_retained'] + r['RAM_floor'] + AS
    assert r['scope_bytes'] <= CAP
    return r

def write_new(p, raw):
    assert p.is_relative_to(O)
    resources()
    assert scope_bytes() + len(raw) <= CAP
    with open(p, 'xb') as f:
        f.write(raw)
        f.flush()
        os.fsync(f.fileno())

def identity(s):
    return {'device': s.st_dev, 'inode': s.st_ino, 'size': s.st_size,
            'mode': s.st_mode, 'mtime_ns': s.st_mtime_ns, 'ctime_ns': s.st_ctime_ns}

def checked_stat(p):
    assert p.is_relative_to(B)
    cur = B
    for component in p.relative_to(B).parts:
        cur = cur / component
        s = cur.lstat()
        assert not stat.S_ISLNK(s.st_mode), 'Symlink forbidden: ' + str(cur)
    assert stat.S_ISREG(s.st_mode), 'Nonregular source: ' + str(p)
    assert p.name != 'game.py', 'game.py forbidden'
    assert not any(x in {'.git', '.env', '.aws', 'credentials', 'id_rsa', 'id_ed25519'} for x in p.parts)
    return s

def read_digest(p, scan=True):
    s = checked_stat(p)
    h, n, tail = hashlib.sha256(), 0, b''
    fd = os.open(p, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, 'rb') as f:
        assert identity(os.fstat(f.fileno())) == identity(s)
        while True:
            chunk = f.read(BLOCK)
            if not chunk:
                break
            h.update(chunk)
            n += len(chunk)
            if scan and p.suffix != '.xz':
                window = tail + chunk
                assert not any(x.search(window) for x in SECRET_PATTERNS), 'Credential marker found: ' + str(p)
                tail = window[-512:]
        assert identity(os.fstat(f.fileno())) == identity(s)
    assert identity(checked_stat(p)) == identity(s)
    assert n == s.st_size
    if scan and p.suffix == '.xz':
        tail = b''
        with lzma.open(p, 'rb') as f:
            while True:
                chunk = f.read(BLOCK)
                if not chunk:
                    break
                window = tail + chunk
                assert not any(x.search(window) for x in SECRET_PATTERNS), 'Credential marker found: ' + str(p)
                tail = window[-512:]
        assert identity(checked_stat(p)) == identity(s)
    return {'path': str(p.relative_to(B)), 'bytes': n, 'sha256': h.hexdigest(), 'identity': identity(s)}

def inventory_paths():
    # Keep the exact v1 evidence selection, not a newly expanded audit directory.
    p = O / 'manifest.json'
    r = read_digest(p, scan=False)
    assert r['bytes'] == 702697 and r['sha256'] == '719ef562df7e751ef95773aa87e8b027345b3cf2601449dcc118fecacf78f282'
    baseline = json.loads(p.read_text())
    paths = []
    for e in baseline['entries']:
        if e['path'].startswith(O.name + '/'):
            continue
        current = read_digest(B / e['path'], scan=False)
        assert current == e, 'Evidence changed since v1: ' + e['path']
        paths.append(B / e['path'])
    paths.extend(O / rel for rel in PACKAGED_OWN)
    assert len(paths) == len(set(paths)) == baseline['entry_count']
    return sorted(paths), baseline['excluded_fixed_core_files']


class BoundedWriter:
    def __init__(self, f, initial_scope):
        self.f, self.initial_scope, self.written = f, initial_scope, 0
    def write(self, data):
        assert self.initial_scope + self.written + len(data) + 2 * MiB <= CAP
        n = self.f.write(data)
        assert n == len(data)
        self.written += n
        return n
    def flush(self):
        return self.f.flush()
    def tell(self):
        return self.written

class HashReader:
    def __init__(self, f):
        self.f, self.hash, self.size = f, hashlib.sha256(), 0
    def read(self, n=-1):
        raw = self.f.read(n)
        self.hash.update(raw)
        self.size += len(raw)
        return raw

def info(name, size):
    t = tarfile.TarInfo(name)
    t.size, t.mode, t.mtime, t.uid, t.gid = size, 0o644, 0, 0, 0
    t.uname = t.gname = ''
    return t

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--build', action='store_true')
    args = parser.parse_args()
    assert args.build, 'Explicit build required'
    resource.setrlimit(resource.RLIMIT_AS, (AS, AS))
    start = resources()
    closure_path = O / 'source/closure_pins.json'
    closure = json.loads(closure_path.read_text())
    assert closure['parent_approved_freeze'] is True
    assert closure['archive_scope_writers_stopped'] is True
    for pin in closure['pins']:
        actual = read_digest(B / pin['path'])
        assert actual['bytes'] == pin['bytes'] and actual['sha256'] == pin['sha256'], pin['path']
    write_new(O / 'source/build_preflight_v2.json', encoded(start))
    paths, excluded = inventory_paths()
    entries = [read_digest(p) for p in paths]
    manifest = {'schema': 'goal-operation-checkpoint-manifest-v2', 'base_path': str(B),
                'created_epoch': time.time(), 'frozen_scopes': SCOPES,
                'entry_count': len(entries), 'source_bytes': sum(e['bytes'] for e in entries),
                'entries': entries, 'excluded_fixed_core_files': excluded,
                'not_in_scope': ['candidate-query', 'live-pilot', 'live-step-adapter', 'SDK game bundles', 'game.py'],
                'archive_manifest_self_reference': 'manifest.json is separately checked byte-for-byte; its own bytes/hash cannot be recursively included.',
                'scan': 'All source bytes, and decompressed XZ contents, checked for explicit credential patterns; no detected marker. No credentials are intentionally included.',
                'Git_writes': 0, 'HDS_calls': 0, 'SDK_calls': 0, 'Action': 0}
    manifest_bytes = encoded(manifest)
    write_new(O / 'manifest_v2.json', manifest_bytes)
    resources()
    archive = O / 'ARC3_目標相対操作学習_20261013_v2.tar.gz'
    initial_scope = scope_bytes()
    with open(archive, 'xb') as raw:
        bounded = BoundedWriter(raw, initial_scope)
        with gzip.GzipFile(fileobj=bounded, mode='wb', filename='', mtime=0, compresslevel=6) as gz:
            with tarfile.open(fileobj=gz, mode='w|', format=tarfile.PAX_FORMAT, bufsize=BLOCK) as tar:
                tar.addfile(info('manifest.json', len(manifest_bytes)), io.BytesIO(manifest_bytes))
                for e in entries:
                    p = B / e['path']
                    assert identity(checked_stat(p)) == e['identity']
                    fd = os.open(p, os.O_RDONLY | os.O_NOFOLLOW)
                    with os.fdopen(fd, 'rb') as f:
                        assert identity(os.fstat(f.fileno())) == e['identity']
                        reader = HashReader(f)
                        tar.addfile(info(e['path'], e['bytes']), reader)
                        assert reader.size == e['bytes'] and reader.hash.hexdigest() == e['sha256']
                        assert identity(os.fstat(f.fileno())) == e['identity']
                    assert identity(checked_stat(p)) == e['identity']
        raw.flush()
        os.fsync(raw.fileno())
    expected = {'manifest.json': {'bytes': len(manifest_bytes), 'sha256': hashlib.sha256(manifest_bytes).hexdigest()}}
    expected.update({e['path']: e for e in entries})
    seen, verified_bytes = set(), 0
    with gzip.open(archive, 'rb') as gz:
        with tarfile.open(fileobj=gz, mode='r|', bufsize=BLOCK) as tar:
            for t in tar:
                assert t.isfile() and not t.issym() and not t.islnk()
                assert not t.name.startswith('/') and '..' not in Path(t.name).parts
                assert t.name in expected and t.name not in seen, 'Unexpected or duplicate entry: ' + t.name
                e = expected[t.name]
                assert t.size == e['bytes']
                seen.add(t.name)
                source = io.BytesIO(manifest_bytes) if t.name == 'manifest.json' else open(B / t.name, 'rb')
                h, n = hashlib.sha256(), 0
                with source, tar.extractfile(t) as member:
                    while True:
                        chunk = member.read(BLOCK)
                        if not chunk:
                            break
                        assert source.read(len(chunk)) == chunk, 'Source/archive byte mismatch: ' + t.name
                        h.update(chunk)
                        n += len(chunk)
                    assert source.read(1) == b''
                assert n == e['bytes'] and h.hexdigest() == e['sha256']
                verified_bytes += n
        while True:
            extra = gz.read(BLOCK)
            if not extra:
                break
            assert not extra.strip(b'\x00'), 'Nonzero content after tar EOF'
    assert seen == set(expected)
    paths_after, exclusions_after = inventory_paths()
    assert paths_after == paths and exclusions_after == excluded
    for e in entries:
        current = read_digest(B / e['path'], scan=False)
        assert current == e, 'Source changed across snapshot: ' + e['path']
    archive_ref = read_digest(archive, scan=False)
    manifest_ref = read_digest(O / 'manifest_v2.json', scan=False)
    receipt = {'schema': 'goal-operation-checkpoint-readback-v2', 'status': 'PASS',
               'archive': archive_ref, 'manifest': manifest_ref,
               'all_source_files': len(entries), 'all_tar_entries': len(seen),
               'source_bytes': manifest['source_bytes'], 'verified_tar_payload_bytes': verified_bytes,
               'byte_for_byte_source_comparison': True, 'every_entry_sha256_size_verified': True,
               'same_snapshot_identities_unchanged': True, 'inventory_unchanged': True,
               'gzip_CRC_EOF_checked': True, 'duplicates_links_escape_paths': 0,
               'no_silent_truncation': True, 'address_space_limit_bytes': AS,
               'maxrss_KiB': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
               'before_resources': start, 'after_resources': resources(),
               'Git_writes': 0, 'SDK_calls': 0, 'HDS_calls': 0, 'Action': 0,
               'elapsed_seconds': time.time() - start['epoch']}
    write_new(O / 'readback_v2.json', encoded(receipt))
    print(json.dumps(receipt, ensure_ascii=False), flush=True)

if __name__ == '__main__':
    main()
