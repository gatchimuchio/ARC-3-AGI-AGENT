"""Pure preparation-effect teacher pack; no native API or game imports."""
import resource
resource.setrlimit(resource.RLIMIT_AS,(512*1048576,512*1048576))
import ast,dataclasses,enum,json,lzma,hashlib,os,shutil,signal,traceback,copy
from pathlib import Path
B=Path('/workspace/scratch/a94ff513b3af');ROOT=B/'arc-column-preparation-teacher-20261013';MIB=1048576
X='実クリック在庫記号が未充足要求に適合'
Y='応答末相で要求適合する在庫選択表示が成立'
BOUNDARY='公開列図式・一意目標候補・在庫選択表示なし・既学習クリック作用の末相準備成立'
TERMINAL={'path':str(B/'arc-column-goal-work-measurement-20261013/output/terminal.json.xz'),'bytes':7648,'sha256':'db4add2a01cb2e8fe583c0d9f225c23de88c8c29ddc659872af234ed788b2fda'}
BASE=B/'arc-column-work-learning-20261013/source/column_work_pack_v2.py'
BASE_SHA='14a241a942f654d520ac59b5e1aa2599c137df75e65064c5e16d1507ad8060ad'
EVIDENCE={'path':str(B/'arc-column-learning-20261013/state_trace/c2f866fa03f288e255c4c88aea21cb75/frame_18_result.json.xz'),'bytes':2268,'sha256':'6cfc9cdc5bca2d5ceff5e8f16ecf3397517c4c4b03438331c7344b33e3ae91bb'}
CODEC=B/'arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/永続化.py'
CODEC_SHA='8aa431b3012424fd8347c5b3d93a5fbf2218d35020836f5d40abb427f9d6da0d'
def guard(category=None,n=0):
    used={}
    if ROOT.is_symlink():raise ValueError('scope symlink')
    for cat in ('source','output'):
        p=ROOT/cat;files=list(p.rglob('*')) if p.exists() else []
        if p.is_symlink() or any(f.is_symlink() for f in files):raise ValueError('symlink')
        used[cat]=sum(f.stat().st_size for f in files if f.is_file())
        if used[cat]+(n if category==cat else 0)>4*MIB:raise MemoryError('category cap')
    if sum(used.values())+n>8*MIB:raise MemoryError('scope cap')
    if shutil.disk_usage(B).free<(1076+1024)*MIB+n:raise MemoryError('future1076MiB + floor1GiB')
    mem=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
    if mem<(4096+2048)*MIB:raise MemoryError('RAM4GiB + floor2GiB')
    return {'used':used,'MemAvailable':mem}
def load_helpers():
    guard()
    if hashlib.sha256(BASE.read_bytes()).hexdigest()!=BASE_SHA:raise ValueError('base pin')
    names={'eq','sha','ref','check','codec','read_packet'};tree=ast.parse(BASE.read_text())
    nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
    if {n.name for n in nodes}!=names:raise ValueError('helper names')
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(BASE),'exec'),globals())
def save(name,v,enc,dec):
    raw=json.dumps(enc(v),ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()
    if len(raw)>16*MIB or not eq(dec(json.loads(raw)),v):raise ValueError('raw bound/types/order')
    out=lzma.compress(raw,preset=0,check=lzma.CHECK_CRC64);guard('output',len(out))
    p=ROOT/'output'/name;p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb') as f:
        if f.write(out)!=len(out):raise OSError('short write')
        f.flush();os.fsync(f.fileno())
    for d in (p.parent,ROOT):
        fd=os.open(d,os.O_RDONLY);os.fsync(fd);os.close(fd)
    r={'file':ref(p),'rawbytes':len(raw),'rawsha256':hashlib.sha256(raw).hexdigest()}
    if not eq(read_packet(r,enc,dec),v):raise ValueError('durable full readback')
    return r
def learned_click(evidence):
    result=evidence['result'];records=[x['記録'] for x in result['照会記録'] if x['段階']=='作用']
    if len(records)!=1:raise ValueError('single saved work query')
    r=records[0]
    if r['状態']=='断定保留' or r['保留理由']:raise ValueError('learned work HOLD')
    predictions=[p for p in r['予測'] if p['結果経路']==('必要行動ID',) and p['条件値群']==('在庫記号を選択',)]
    if not predictions or any(type(p['予測値'])is not int or not p['原理参照'] for p in predictions):raise ValueError('supported saved work prediction')
    numbers={p['予測値'] for p in predictions}
    if len(numbers)!=1:raise ValueError('conflicting click mapping')
    number=numbers.pop()
    # 6 is only the public coordinate-action contract, never a learned answer substitute.
    if number!=6:raise ValueError('coordinate action contract')
    return {'number':number,'full_query':r,'source':EVIDENCE}
def before_view(r):
    return {'phase':copy.deepcopy(r['全前相'][-1]) if r['全前相'] else None,
            'pre':copy.deepcopy(r['前提']),'metadata':copy.deepcopy(r['公開前後metadata'][0]),
            'action':copy.deepcopy(r['公開Action'])}
def hit(position,point):
    return all(type(v)is int for v in point) and position[0]-1<=point[0]<position[0]+5 and position[1]-1<=point[1]<position[1]+5
def decide(v,number):
    reasons=[];p=v['pre'];phase=v['phase'];scene=phase.get('scene') if phase else None
    q=p.get('全候補比較',[]);q=q[0] if len(q)==1 else None
    if scene is None:reasons.append('before知覚不成立')
    if p.get('目標pool状態')!='一意' or q is None:reasons.append('before一意目標不成立')
    if phase is None or 'selection'not in phase or 'selection_unknown'in phase or p.get('選択UNKNOWN') is not None:reasons.append('在庫表示知覚UNKNOWN')
    elif phase['selection'] is not None:reasons.append('before在庫選択表示あり')
    a=v['action'];av=v['metadata'].get('available_actions',[])
    if type(a.get('id'))is not int or a['id']!=number:reasons.append('既学習クリックAction以外')
    if type(av)is not list or any(type(x)is not int for x in av) or a.get('id') not in av:reasons.append('公開available外')
    xy=a.get('data',{});point=(xy.get('x'),xy.get('y'))
    if not all(type(x)is int for x in point):reasons.append('公開クリック座標UNKNOWN')
    if reasons:return {'eligible_before':False,'reasons':reasons,'query_input':None}
    if not eq(phase['selection'],p['現在選択']):raise ValueError('before selection binding')
    hits=[t for t in scene['在庫群'] if hit(t['位置'],point)]
    if len(hits)>1:raise ValueError('ambiguous clicked inventory')
    desired=dict(q['要求枠']);needs=q['未充足枠']
    if not needs:raise ValueError('goal has no unmet requirement within preparation scope')
    fits=bool(hits) and any(eq(hits[0]['記号'],desired[k]) for k in needs)
    return {'eligible_before':True,'reasons':[],'query_input':{X:fits},'clicked_inventory':copy.deepcopy(hits),
            'clicked_point':point,'full_goal_relation':copy.deepcopy(q),'all_inventory':copy.deepcopy(scene['在庫群']),
            'negative_definition':'No matching clicked visible inventory object; no hidden selection claim.'}
def phase_result(phase,desired,needs):
    if 'scene'not in phase or 'selection'not in phase or 'selection_unknown'in phase:
        return {'known':False,'value':None,'reason':'visible inventory selection unparsed'}
    sel=phase['selection']
    if sel is not None and not any(eq(sel,t) for t in phase['scene']['在庫群']):raise ValueError('selected inventory membership')
    value=False if sel is None else any(eq(sel['記号'],desired[k]) for k in needs)
    return {'known':True,'value':value,'selection':copy.deepcopy(sel),
            'negative_basis':'fully parsed visible inventory and explicit selection=None' if sel is None else None}
def project(case,number):
    r=case['教師候補観測'];v=before_view(r);d=decide(v,number)
    out={'row':r['行'],'before':v,'decision':d,'teacher':None,'boundary':BOUNDARY,'outcome_status':'not_eligible',
         'phase_results':[],'original_other_effects':copy.deepcopy(r['各相効果']),'after_scope':copy.deepcopy(r['境界']),
         'hidden':case['隠れ状態差'],'reward':case['報酬']}
    if not d['eligible_before']:return out
    out['outcome_status']='HOLD';reasons=[]
    if r['境界'].get('旧問題継続確認') is not True:reasons.append('after same-problem unconfirmed')
    if r['例外'] or not r['全後相'] or len(r['全後相'])!=len(r['各相効果']):reasons.append('after missing/exception')
    q=d['full_goal_relation'];desired=dict(q['要求枠']);needs=q['未充足枠']
    for phase,effect in zip(r['全後相'],r['各相効果']):
        s=phase_result(phase,desired,needs);s['phase']=phase['phase'];s['frame_sha256_uint8']=phase['frame_sha256_uint8']
        s['same_problem_and_structure']=effect.get('旧scope効果確認') is True
        out['phase_results'].append(s)
    last=out['phase_results'][-1] if out['phase_results'] else None
    if last is None or not last['known'] or not last['same_problem_and_structure']:reasons.append('eligible terminal observation UNKNOWN')
    if reasons:out['outcome_reasons']=reasons;return out
    if type(last['value'])is not bool:raise ValueError('strict result bool')
    out['teacher']={X:d['query_input'][X],Y:last['value']};out['outcome_status']='measured'
    return out
def fixtures(cases,number):
    results=[]
    # Derive synthetic bases by observed features, never by source row IDs.
    neg=next(c for c in cases if project(c,number)['teacher'] and project(c,number)['teacher'][X] is False)
    pos=next(c for c in cases if project(c,number)['teacher'] and project(c,number)['teacher'][X] is True)
    def test(name,original,changed,check):
        a=project(original,number);b=project(changed,number)
        result={'name':name,'original':original,'mutated':changed,'original_projection':a,'mutated_projection':b,'pass':bool(check(a,b))}
        results.append(result)
        if not result['pass']:raise AssertionError(name)
    mutated=copy.deepcopy(pos);mutated['教師候補観測']['全後相'][-1]['selection']=None
    test('after label reversal leaves eligibility/input identical',pos,mutated,lambda a,b:eq(a['decision'],b['decision']) and a['teacher'][Y]is True and b['teacher'][Y]is False)
    mutated=copy.deepcopy(pos);mutated['教師候補観測']['境界']['旧問題継続確認']=False;mutated['教師候補観測']['境界']['公開進捗あり']=True
    test('after boundary progress cannot alter eligibility',pos,mutated,lambda a,b:eq(a['decision'],b['decision']) and b['outcome_status']=='HOLD' and b['teacher']is None)
    mutated=copy.deepcopy(pos);mutated['教師候補観測']['全後相'][-1]['selection_unknown']='synthetic unknown'
    test('eligible unknown stays explicit HOLD',pos,mutated,lambda a,b:b['decision']['eligible_before'] and b['outcome_status']=='HOLD' and b['teacher']is None)
    test('outside-inventory negative retained',neg,copy.deepcopy(neg),lambda a,b:a['decision']['clicked_inventory']==[] and a['teacher']=={X:False,Y:False})
    mutated=copy.deepcopy(pos);mutated['教師候補観測']['行']=-991
    test('row index never selects teacher',pos,mutated,lambda a,b:eq(a['decision'],b['decision']) and eq(a['teacher'],b['teacher']))
    mutated=copy.deepcopy(pos);mutated['教師候補観測']['各相効果'][-1]['集約効果']['要求適合する選択状態']=None
    test('legacy None field is not coerced or used',pos,mutated,lambda a,b:eq(a['teacher'],b['teacher']) and b['teacher'][Y]is True)
    return {'schema':'column-preparation-pure-fixture-v1','status':'PASS','cases':results,'native':0}
def main():
    load_helpers();enc,dec=codec();ev=read_packet(EVIDENCE,enc,dec,False);mapping=learned_click(ev)
    terminal=read_packet(TERMINAL,enc,dec,False)
    if terminal['状態']!='complete' or terminal['errors'] or terminal['全行順']!=list(range(1,60)) or terminal['未処理suffix'] or len(terminal['cases'])!=59:raise ValueError('whole59 closure')
    allcases=[];originals=[];teachers=[]
    for i,item in enumerate(terminal['cases'],1):
        guard();case=read_packet(item['ref'],enc,dec)
        if item['行']!=i or case['行']!=i or case['教師候補観測']['行']!=i:raise ValueError('original order/binding')
        r=project(case,mapping['number']);r['case_ref']=item['ref'];allcases.append(r);originals.append(case)
        if r['decision']['eligible_before'] and r['teacher']is not None:
            teachers.append({'ordinal':len(teachers),'row':i,'case_ref':item['ref'],'query_input':r['decision']['query_input'],'teacher':r['teacher'],'boundary':BOUNDARY})
    fixture=fixtures(originals,mapping['number']);fr=save('fixture_v1.json.xz',fixture,enc,dec)
    holds=[r['row'] for r in allcases if r['decision']['eligible_before'] and r['teacher']is None]
    pack={'schema':'column-preparation-teacher-pack-v1','status':'HOLD' if holds else 'complete','source':ref(Path(__file__)),'terminal':TERMINAL,
          'learned_click_evidence':mapping,'all59':allcases,'teachers':teachers,'eligible_unknown_rows':holds,'fixture':fr,'new_independent_support':0,
          'negative_limitation':'Observed negatives are outside inventory, not incompatible inventory-token selections. Selection=None concerns visible inventory only; hidden/filled-slot selection remains unknown.',
          'selection':'Eligibility uses only before_view and saved learned action correspondence; after validity never removes an eligible record.',
          'HDS':0,'Action':0,'all_phase_source':'Each immutable case_ref retains complete original tagged case, raw source refs and all phases without truncation.'}
    pr=save('teacher_pack_v1.json.xz',pack,enc,dec)
    print(json.dumps({'status':pack['status'],'pack':pr,'fixture':fr,'counts':{'all59':len(allcases),'eligible':sum(r['decision']['eligible_before'] for r in allcases),'teachers':len(teachers),'unknown_eligible':len(holds),'positive':sum(t['teacher'][Y] for t in teachers),'negative':sum(not t['teacher'][Y] for t in teachers)},'rows':[t['row'] for t in teachers]},ensure_ascii=False),flush=True)
    if holds:raise ValueError('eligible observations unknown, not silently excluded')
if __name__=='__main__':
    def alarm(*args):raise TimeoutError('pure pack600s')
    signal.signal(signal.SIGALRM,alarm);signal.alarm(600)
    try:main()
    except BaseException:
        text=traceback.format_exc();print(text,flush=True)
        try:
            load_helpers();enc,dec=codec();signal.alarm(120);print(json.dumps({'failure':save('failure_v1.json.xz',{'traceback':text},enc,dec)}),flush=True)
        except BaseException:print(traceback.format_exc(),flush=True)
        raise
