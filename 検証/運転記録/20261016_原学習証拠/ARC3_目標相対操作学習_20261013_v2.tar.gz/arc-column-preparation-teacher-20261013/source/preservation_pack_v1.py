"""Pure preservation teacher projection. Two before operation classes, all response phases."""
import resource
resource.setrlimit(resource.RLIMIT_AS,(512*1048576,512*1048576))
import ast,copy,hashlib,importlib.util,json,os,signal,shutil,traceback
from pathlib import Path
B=Path('/workspace/scratch/a94ff513b3af');ROOT=B/'arc-column-preparation-teacher-20261013'
PREP=ROOT/'source/preparation_pack_v1.py';PREP_SHA='8152c5d2d76995afee2e3a38c3d618894bc94f2aaaa5121076c41f94cbcdc867'
REPAIR=B/'arc-column-work-learning-20261013/source/column_work_pack_v2.py';REPAIR_SHA='14a241a942f654d520ac59b5e1aa2599c137df75e65064c5e16d1507ad8060ad'
X='可視対象に対する操作区分';Y='応答全相で既充足枠が保持された'
CLASSES=('在庫選択表示なしのクリック','在庫選択済みの実枠クリック')
BOUNDARY='公開列図式・一意目標候補・既充足枠非空・可視対象操作の全相保存'
def bootstrap():
    if shutil.disk_usage(B).free<(1076+1024)*1048576:raise MemoryError('future+disk floor')
    mem=int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024
    if mem<(4096+2048)*1048576:raise MemoryError('RAM4+2GiB')
    if hashlib.sha256(PREP.read_bytes()).hexdigest()!=PREP_SHA or hashlib.sha256(REPAIR.read_bytes()).hexdigest()!=REPAIR_SHA:raise ValueError('pure dependency pins')
    spec=importlib.util.spec_from_file_location('prep_preservation_dependency',PREP);p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
    p.load_helpers();p.guard()
    tree=ast.parse(REPAIR.read_text());nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='decide']
    if len(nodes)!=1:raise ValueError('repair eligibility AST')
    ns={'eq':p.eq,'X':'実対象への選択記号適合'}
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(REPAIR),'exec'),ns)
    return p,ns['decide']
def before_decision(case,p,repair_decide,number):
    r=case['教師候補観測'];v=p.before_view(r)
    a=p.decide(v,number);b=repair_decide(v)
    if a['eligible_before'] and b['eligible_before']:raise ValueError('operation classes overlap')
    matches=[label for label,d in zip(CLASSES,(a,b)) if d['eligible_before']]
    d={'eligible_before':False,'reasons':[],'operation_decisions':[a,b],'query_input':None,
       'before_view':v,'existing_correct_slots':None,'goal_relation':None,'empty_set':False}
    if not matches:d['reasons'].append('neither existing before operation scope');return d
    q=v['pre']['集約適合']
    if q is None:raise ValueError('eligible operation must have one goal')
    kept=q['既充足枠'];desired=dict(q['要求枠']);scene=v['phase']['scene']
    current={tuple(s['位置']):s['記号'] for z in scene['容器群'] for s in z['枠群']}
    if any(k not in current or not p.eq(current[k],desired[k]) for k in kept):raise ValueError('before correct-set witness')
    d['goal_relation']=copy.deepcopy(q);d['existing_correct_slots']=copy.deepcopy(kept);d['operation_class']=matches[0]
    if not kept:d['empty_set']=True;d['reasons'].append('existing correct slot set empty; preservation=None');return d
    d['eligible_before']=True;d['query_input']={X:matches[0]};return d
def project(case,p,repair_decide,number):
    r=case['教師候補観測'];d=before_decision(case,p,repair_decide,number)
    out={'row':r['行'],'decision':d,'teacher':None,'boundary':BOUNDARY,'outcome_status':'not_eligible',
         'measured_preservation':None,'phases':[],'hidden':case['隠れ状態差'],'reward':case['報酬']}
    if not d['eligible_before']:return out
    out['outcome_status']='HOLD';reasons=[];after=r['全後相']
    if r['境界'].get('旧問題継続確認')is not True:reasons.append('after sameproblem unknown')
    if r['例外'] or not after or len(after)!=len(r['各相効果']):reasons.append('after missing/exception')
    before=d['before_view']['phase']['scene'];q=d['goal_relation'];desired=dict(q['要求枠']);kept=d['existing_correct_slots']
    def structure(s):
        return {'背景色':s['背景色'],'目標列':s['目標列'],'容器群':[{'色':b['色'],'位置':b['位置'],'起点':b['起点'],'枠位置':[x['位置'] for x in b['枠群']]} for b in s['容器群']]}
    for phase in after:
        item={'phase':phase['phase'],'frame_sha256_uint8':phase['frame_sha256_uint8'],'known':False,'value':None,'broken_slots':[]}
        out['phases'].append(item);scene=phase.get('scene')
        if scene is None:item['reason']='phase scene unknown';reasons.append('unknown phase');continue
        if not p.eq(structure(scene),structure(before)):item['reason']='phase goal/structure changed';reasons.append('unknown phase binding');continue
        actual={tuple(s['位置']):s['記号'] for b in scene['容器群'] for s in b['枠群']}
        if any(k not in actual for k in kept):item['reason']='missing slot correspondence';reasons.append('missing correspondence');continue
        item['known']=True;item['actual_correct_slot_values']=[(k,copy.deepcopy(actual[k])) for k in kept]
        item['required_slot_values']=[(k,copy.deepcopy(desired[k])) for k in kept]
        item['broken_slots']=[k for k in kept if not p.eq(actual[k],desired[k])]
        item['value']=not item['broken_slots']
    if reasons:out['outcome_reasons']=reasons;return out
    y=all(x['value'] for x in out['phases'])
    out['measured_preservation']=y;out['teacher']={X:d['query_input'][X],Y:y};out['outcome_status']='measured'
    return out
def fixtures(cases,p,repair,number):
    records=[];positive=next(c for c in cases if project(c,p,repair,number)['teacher'] is not None and len(c['教師候補観測']['全後相'])>1)
    empty=next(c for c in cases if before_decision(c,p,repair,number)['empty_set'])
    def test(name,a,b,fn):
        x=project(a,p,repair,number);y=project(b,p,repair,number)
        rec={'name':name,'original':a,'mutated':b,'before_result':x,'after_result':y,'pass':bool(fn(x,y))};records.append(rec)
        if not rec['pass']:raise AssertionError(name)
    m=copy.deepcopy(positive);key=before_decision(m,p,repair,number)['existing_correct_slots'][0]
    for box in m['教師候補観測']['全後相'][0]['scene']['容器群']:
        for slot in box['枠群']:
            if tuple(slot['位置'])==key:slot['記号']=None
    test('one phase bad gives False and same eligibility',positive,m,lambda a,b:p.eq(a['decision'],b['decision']) and a['teacher'][Y]is True and b['teacher'][Y]is False)
    m=copy.deepcopy(positive);m['教師候補観測']['境界']['旧問題継続確認']=False;m['教師候補観測']['境界']['公開進捗あり']=True
    test('progress cannot change before eligibility',positive,m,lambda a,b:p.eq(a['decision'],b['decision']) and b['outcome_status']=='HOLD' and b['teacher']is None)
    m=copy.deepcopy(positive);del m['教師候補観測']['全後相'][0]['scene']
    test('one unknown phase explicit HOLD',positive,m,lambda a,b:p.eq(a['decision'],b['decision']) and b['outcome_status']=='HOLD' and b['teacher']is None)
    test('empty preservation set remains None',empty,copy.deepcopy(empty),lambda a,b:a['decision']['empty_set'] and a['measured_preservation']is None and a['teacher']is None)
    m=copy.deepcopy(positive);m['教師候補観測']['行']=-177
    test('no row selector',positive,m,lambda a,b:p.eq(a['decision'],b['decision']) and p.eq(a['teacher'],b['teacher']))
    return {'schema':'column-preservation-pure-fixture-v1','status':'PASS','cases':records,'native':0}
def main():
    p,repair=bootstrap();enc,dec=p.codec();terminal=p.read_packet(p.TERMINAL,enc,dec,False);mapping=p.learned_click(p.read_packet(p.EVIDENCE,enc,dec,False))
    if terminal['状態']!='complete' or terminal['errors'] or terminal['全行順']!=list(range(1,60)) or terminal['未処理suffix'] or len(terminal['cases'])!=59:raise ValueError('whole59 closure')
    original=[];allcases=[];teachers=[]
    for i,item in enumerate(terminal['cases'],1):
        p.guard();case=p.read_packet(item['ref'],enc,dec)
        if item['行']!=i or case['行']!=i or case['教師候補観測']['行']!=i:raise ValueError('original row order')
        original.append(case);r=project(case,p,repair,mapping['number']);r['case_ref']=item['ref'];allcases.append(r)
        if r['decision']['eligible_before']:
            if r['teacher']is not None:
                for phase,effect in zip(r['phases'],case['教師候補観測']['各相効果']):
                    if not effect['旧scope効果確認'] or not p.eq(phase['value'],effect['集約効果']['既充足が全て保持された']):raise ValueError('direct versus existing preservation disagreement')
                teachers.append({'ordinal':len(teachers),'row':i,'case_ref':item['ref'],'query_input':r['decision']['query_input'],'teacher':r['teacher'],'boundary':BOUNDARY})
    fr=p.save('preservation_fixture_v1.json.xz',fixtures(original,p,repair,mapping['number']),enc,dec)
    holds=[r['row'] for r in allcases if r['decision']['eligible_before'] and r['teacher']is None]
    pack={'schema':'column-preservation-teacher-pack-v1','status':'HOLD' if holds else 'complete','source':p.ref(Path(__file__)),
          'dependencies':[p.ref(PREP),p.ref(REPAIR)],'terminal':p.TERMINAL,'learned_click_evidence':mapping,'all59':allcases,'teachers':teachers,
          'eligible_unknown_rows':holds,'empty_set_rows':[r['row'] for r in allcases if r['decision']['empty_set']],'fixture':fr,
          'selection':'before-only exact union of preparation and repair eligibility plus nonempty original goal-correct slot set; afterunknown retained HOLD',
          'new_independent_support':0,'HDS':0,'Action':0,
          'limits':'Observed False0 does not establish universal preservation. Same correlated public Actions already support other boundaries; not independent new source experience. Hidden state unobserved. Class1 includes clicks outside inventory. Whole original59 cases/all phases preserved by exact immutable case_ref.'}
    pr=p.save('preservation_pack_v1.json.xz',pack,enc,dec)
    counts={'all59':len(allcases),'teachers':len(teachers),'unknown_eligible':len(holds),'empty_none':len(pack['empty_set_rows']),
            'phases':sum(len(r['phases']) for r in allcases if r['decision']['eligible_before']),
            'classes':{k:sum(t['teacher'][X]==k for t in teachers) for k in CLASSES},'true':sum(t['teacher'][Y]is True for t in teachers),'false':sum(t['teacher'][Y]is False for t in teachers)}
    print(json.dumps({'status':pack['status'],'pack':pr,'fixture':fr,'counts':counts,'empty_none_rows':pack['empty_set_rows']},ensure_ascii=False),flush=True)
    if holds:raise ValueError('eligible phase UNKNOWN retained; not all teachers measurable')
if __name__=='__main__':
    def alarm(*a):raise TimeoutError('pure preservation600s')
    signal.signal(signal.SIGALRM,alarm);signal.alarm(600)
    try:main()
    except BaseException:
        text=traceback.format_exc();print(text,flush=True)
        try:
            p,repair=bootstrap();enc,dec=p.codec();signal.alarm(120);print(json.dumps({'failure':p.save('preservation_failure_v1.json.xz',{'traceback':text},enc,dec)}),flush=True)
        except BaseException:print(traceback.format_exc(),flush=True)
        raise
