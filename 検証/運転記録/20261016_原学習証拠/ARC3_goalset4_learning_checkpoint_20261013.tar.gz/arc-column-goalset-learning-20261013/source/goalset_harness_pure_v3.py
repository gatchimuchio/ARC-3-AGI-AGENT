"""Bounded pure fixture. In-memory gates and synthetic machine are never native authority.
Actual immutable closure/read plans are inspected; HDS/native classes/import/API are forbidden.
"""
import resource,signal
resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912))
def timeout(*a):raise TimeoutError('pure fixture aggregate180s')
signal.signal(signal.SIGALRM,timeout);signal.alarm(180)
import ast,hashlib,importlib.util,json,sys,time,traceback,types
from pathlib import Path
B=Path('/workspace/scratch/a94ff513b3af');R=B/'arc-column-goalset-learning-20261013'
SUBJECT=R/'source/goalset_harness_v3.py'
SOURCE_SHA='13ba0f5a514319d221329f2b383a3ba18c24870f4310c9de728300d1d699e775'
sys.dont_write_bytecode=True
FORBIDDEN=[]
def audit(event,args):
 if event=='import' and str(args[0]).startswith(('hds学習系統','arc_agi','arcengine','arcade')):
  FORBIDDEN.append(args[0]);raise PermissionError('pure fixture forbids native/SDK imports')
sys.addaudithook(audit)
assert hashlib.sha256(SUBJECT.read_bytes()).hexdigest()==SOURCE_SHA
sp=importlib.util.spec_from_file_location('goalset_pure_subject',SUBJECT);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
# Use the existing inert Record codec definitions only, never native codec imports.
codec_path=B/'arc-column-preparation-learning-20261013/source/column_preservation_fixture_v1.py'
codec_raw=codec_path.read_bytes();tree=ast.parse(codec_raw)
nodes=[n for n in tree.body if isinstance(n,(ast.ClassDef,ast.FunctionDef))and n.name in {'Record','dec','enc'}]
assert {n.name for n in nodes}=={'Record','dec','enc'}
ns={};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(codec_path),'exec'),ns)
Record,dec,enc=(ns[k]for k in ('Record','dec','enc'))
def clone(x):return dec(enc(x))
def ref(p):
 p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
CASES=[];ERRORS=[]
def passed(name,**more):CASES.append({'name':name,'status':'PASS',**more})
ORIGINAL_CHECKED=m.checked
FAKE_GATE_PATH=str(Path(__file__))
FAKE_GATE={'schema':'column-goalset-learning-release-v1','enabled':True,'native_authorized':True,'teacher_pack_approved':True,'source_sha256':SOURCE_SHA,'teacher_pack':m.PACK,'nonce':'f'*32,'admission_deadline_epoch':time.time()+180,'limits':{'AS':536870912,'compute':600,'save':120},'source_contract':ref(R/'source/goalset_material_contract_v1.json')}
# source_contract points at a real material contract solely as an inert readable FileRef.
# No enabled gate or native contract is written. These fakes cannot leave this process.
def static(gate=None,pack=None):
 gate=FAKE_GATE if gate is None else gate
 def read_override(r,cap=8*m.MIB):
  if r['path']==FAKE_GATE_PATH:return json.dumps(gate,ensure_ascii=False).encode()
  if pack is not None and r==m.PACK:return json.dumps(pack,ensure_ascii=False).encode()
  return ORIGINAL_CHECKED(r,cap)
 m.checked=read_override
 try:
  owner=object.__new__(m.Run);answer=owner.static_preflight(FAKE_GATE_PATH,'PURE_IN_MEMORY_GATE_ONLY');return owner,answer
 finally:m.checked=ORIGINAL_CHECKED

def must_reject(name,fn,kind=(ValueError,PermissionError,MemoryError)):
 try:fn()
 except kind as e:passed(name,rejection=type(e).__name__,message=str(e))
 else:raise AssertionError(name+' unexpectedly accepted')

class FakeExhaust:
 def 排出する(self,結果):return 結果
class FakeMachine:
 def __init__(self,owner,fault=None):self.owner=owner;self.state=dec(json.loads(ORIGINAL_CHECKED(m.BASELINE)));self.排気系=FakeExhaust();self.fault=fault;self.query_count=0;self.teach_count=0
 def 処理する(self,e):
  index=self.teach_count;t=self.owner.pack['teachers'][index]
  if e.対象系境界!=m.BOUNDARY or not m.eq(e.内容,t['teacher']):raise ValueError('fake expected exact ordered teacher')
  self.teach_count+=1;self.state['識別子状態']['経験']+=1;self.state['識別子状態']['学習']+=1
  self.state['台帳']['観測台帳']+=({'synthetic_teacher':clone(t['teacher']),'row':t['row']},)
  if self.fault=='old_prefix' and index==0:self.state['台帳']['観測台帳']=({'synthetic_corruption':True},)+self.state['台帳']['観測台帳'][1:]
  if self.fault=='teach_query_counter' and index==0:self.state['識別子状態']['学習判定']+=1
  out=Record('__データ型__','外部出力',{'状態':'出力','内容':{'synthetic_teacher_result':True}})
  return self.排気系.排出する(out)
 def 照会する(self,e):
  i=self.query_count;self.query_count+=1
  for k in ('照会','学習判定'):self.state['識別子状態'][k]+=1
  planned=self.owner.plan[4+i]
  if e.対象系境界!=planned['boundary'] or not m.eq(e.内容,planned['content']):raise ValueError('fake expected exact ordered query')
  if i<4:
   value=self.owner.pack['teachers'][i]['expected_output'][m.Y]
   if self.fault=='wrong_bool_type' and i==0:value=1
   out=Record('__データ型__','外部出力',{'状態':'出力','内容':{'予測群':[{'原理参照':'SYNTHETIC_NOT_NATIVE','結果経路':(m.Y,),'予測値':value,'条件値群':(self.owner.pack['teachers'][i]['teacher'][m.X],)}],'断定保留理由群':[]}})
  else:out=clone(self.owner.regression[i-4]['original_reply'])
  if self.fault and self.fault.startswith('uncertainty:') and i==4:out.内容[self.fault.split(':',1)[1]]=[{'synthetic_drift':True}]
  if self.fault=='learning_state' and i==4:out.内容['学習成立状態']='synthetic_drift'
  if self.fault=='query_mutation' and i==0:self.state['台帳']['観測台帳']+=({'synthetic_unexpected_mutation':True},)
  if self.fault=='dictionary_order' and i==0:self.state=dict(reversed(list(self.state.items())))
  return self.排気系.排出する(out)

class FixtureRun(m.Run):
 def __init__(self,template,regression,fault=None):
  self.machine=None;self.enc=enc;self.dec=dec;self.pack=clone(template.pack);self.regression=regression;self.preservation=template.preservation;self.preservation_ref=template.preservation_ref
  self.gate=dict(FAKE_GATE);self.calls=[];self.state_refs=[];self.plan=[];self.artifacts=[];self.saved={};self.events=[];self.current=None;self.pending=None;self.complete=False;self.terminal=None;self.fault=fault
  machine=FakeMachine(self,fault)
  def fake_restore(path):
   assert path==m.BASELINE['path'];self.events.append(('synthetic_restore',path));return machine
  self.native=types.SimpleNamespace(HDS学習系統=types.SimpleNamespace(読み込む=fake_restore),外部入力=lambda content,boundary:Record('__データ型__','外部入力',{'内容':content,'対象系境界':boundary}))
 def markers(self):
  s=self.machine.state
  return {'identifiers':dict(s['識別子状態']),'ledger_lengths':{k:len(v)for k,v in s['台帳'].items()},'principle_history_lengths':{k:len(v)for k,v in s['原理履歴'].items()},'state_history_length':len(s['状態履歴'])}
 def save(self,name,value,category='state_trace',codec=True):
  raw=m.b.jb(enc(value) if codec else value)
  assert len(raw)<=16*m.MIB
  self.saved[name]=json.loads(raw);self.events.append(('synthetic_save',name))
  r={'file':{'path':'synthetic-memory://'+name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()},'rawbytes':len(raw),'rawsha256':hashlib.sha256(raw).hexdigest()};self.artifacts.append(r);return r
 def standard(self,label):
  snapshot=clone(self.machine.state);raw=m.b.jb(enc(snapshot));r=m.BASELINE if label=='restored_before' else {'path':'synthetic-memory://'+label,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
  self.state_refs.append(r);self.events.append(('synthetic_standard',label));return r,snapshot

# Reuse the actual source's post-import plan-building statements; omit native import/restore.
source_tree=ast.parse(SUBJECT.read_bytes());run_class=next(n for n in source_tree.body if isinstance(n,ast.ClassDef)and n.name=='Run');pre=next(n for n in run_class.body if isinstance(n,ast.FunctionDef)and n.name=='preflight')
start=next(i for i,n in enumerate(pre.body)if isinstance(n,ast.Assign)and any(isinstance(t,ast.Attribute)and t.attr=='plan'for t in n.targets))
planfn=ast.FunctionDef(name='prepare_exact_plan',args=ast.arguments(posonlyargs=[],args=[ast.arg(arg='self')],kwonlyargs=[],kw_defaults=[],defaults=[]),body=pre.body[start:],decorator_list=[])
plan_ns=dict(m.__dict__);exec(compile(ast.fix_missing_locations(ast.Module(body=[planfn],type_ignores=[])),str(SUBJECT),'exec'),plan_ns)

def simulate(template,regression,fault=None):
 owner=FixtureRun(template,regression,fault);plan_ns['prepare_exact_plan'](owner);receipt=owner.execute();return owner,receipt

try:
 owner,joins=static();passed('actual_static_preflight_immutable_closure_joins',joins=joins,gate='in-memory override only')
 bad=dict(FAKE_GATE);bad['enabled']=False;must_reject('disabled_gate',lambda:static(bad))
 bad=dict(FAKE_GATE);bad['native_authorized']=False;must_reject('missing_native_authority',lambda:static(bad))
 bad=dict(FAKE_GATE);bad['source_sha256']='0'*64;must_reject('wrong_source_pin',lambda:static(bad))
 bad=dict(FAKE_GATE);bad['limits']={'AS':536870912,'compute':601,'save':120};must_reject('changed_runtime_limits',lambda:static(bad))
 bad=dict(FAKE_GATE);bad['nonce']='fixture';must_reject('malformed_nonce',lambda:static(bad))
 bad=dict(FAKE_GATE);bad['admission_deadline_epoch']=0;must_reject('expired_gate',lambda:static(bad))
 pack=json.loads(ORIGINAL_CHECKED(m.PACK))
 altered=clone(pack);altered['teachers'][0]['teacher'][m.X]=1;must_reject('strict_bool_not_integer',lambda:static(pack=altered))
 altered=clone(pack);altered['teachers'][0]['teacher']=dict(reversed(list(altered['teachers'][0]['teacher'].items())));must_reject('teacher_key_order',lambda:static(pack=altered))
 altered=clone(pack);altered['teachers'][0],altered['teachers'][1]=altered['teachers'][1],altered['teachers'][0];must_reject('original_teacher_row_order',lambda:static(pack=altered))
 altered=clone(pack);altered['teachers'][0]['query_input'][m.Y]=True;must_reject('before_only_query_no_outcome_leaf',lambda:static(pack=altered))
 altered=clone(pack);altered['teachers'][0]['expected_output']=True;must_reject('exact_expected_output_object',lambda:static(pack=altered))
 owner.enc=enc;owner.dec=dec;plan=owner.regression_plan();assert len(plan)==58
 assert [sum(x['group']==k for x in plan)for k in ('preservation_regression','baseline_regression','repair_regression','preparation_regression')]==[24,7,13,14]
 assert plan[30]['original_score']['comparison_kind']=='saved standard relationship expectation versus first real query'
 passed('source_bound_actual_old58_full_type_order_plan',count=58,groups=[24,7,13,14],original_saved_rule_distinction_preserved=True)
 run,receipt=simulate(owner,plan);assert run.complete and run.terminal=='complete' and len(run.calls)==66 and run.machine.teach_count==4 and run.machine.query_count==62
 assert run.machine.state['識別子状態']['経験']==133 and all(run.machine.state['識別子状態'][k]==4775 for k in ('照会','学習判定'))
 assert run.events.index(('synthetic_save','all62_query_replies'))<run.events.index(('synthetic_standard','after_queries'))<run.events.index(('synthetic_save','all62_external_scoring'))
 assert all(len(dec(run.saved['api_%04d_reply'%i])['capture']['raw'])==1 and dec(run.saved['api_%04d_reply'%i])['capture']['profile_restored']is True for i in range(66))
 passed('actual_invoke_execute_fake66_and_counter_closure',synthetic_Teach=4,synthetic_Query=62,paired_counter=[4713,4775],experience=[129,133],durable_order='memory-only spy',raw_return_pairs=66)
 must_reject('API67_ceiling',run.invoke_next)
 failed,_=simulate(owner,plan,'wrong_bool_type');assert failed.terminal=='completed_regression_failed' and len(failed.calls)==66 and failed.summary['failed_scoring_indices']==[0]
 passed('integer_prediction_rejected_after_all62_queries',completed_synthetic_calls=66)
 for fault in ('uncertainty:追加観測要求群','uncertainty:識別不能群','uncertainty:競合群','uncertainty:係争中原理群','learning_state'):
  drifted,_=simulate(owner,plan,fault);assert drifted.terminal=='completed_regression_failed' and len(drifted.calls)==66 and drifted.summary['failed_scoring_indices']==[4]
  assert dec(drifted.saved['all62_query_replies'])[4]['reply'].状態=='出力'
  passed('old58_'+fault+'_semantic_drift',completed_synthetic_calls=66,nominal_state='出力')
 must_reject('old129_prefix_corruption',lambda:simulate(owner,plan,'old_prefix'))
 must_reject('unexpected_query_state_mutation',lambda:simulate(owner,plan,'query_mutation'))
 must_reject('state_dictionary_order_drift',lambda:simulate(owner,plan,'dictionary_order'))
 must_reject('teach_paired_counter_drift',lambda:simulate(owner,plan,'teach_query_counter'))
 assert not FORBIDDEN and not any(k.startswith(('hds学習系統','arc_agi','arcengine'))for k in sys.modules)
 passed('native_import_restore_Teach_Query_Action_all_zero',native_counts={'import':0,'restore':0,'Teach':0,'Query':0,'Action':0})
 result={'schema':'column-goalset-harness-pure-fixture-v1','status':'PASS','subject':ref(SUBJECT),'inert_codec_source':ref(codec_path),'cases':CASES,'errors':[],'limits':['Static production preflight exercised through an in-memory fake gate read, never a persisted enabled gate.','Tagged historical objects decoded into inert Record objects; no HDS/native modules, restore, Teach, Query, or SDK/Action.','Synthetic machine exercises actual invoke_next/execute and source-extracted plan construction; memory-only save/standard spies do not prove native learning or filesystem persistence.','Prior native evidence remains immutable and is only read/type-order checked.']}
except BaseException as e:
 ERRORS.append({'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()});result={'schema':'column-goalset-harness-pure-fixture-v1','status':'FAIL','subject':ref(SUBJECT),'cases':CASES,'errors':ERRORS}
finally:
 signal.alarm(0);m.checked=ORIGINAL_CHECKED
 raw=(json.dumps(result,ensure_ascii=False,separators=(',',':'))+'\n').encode()
 if len(raw)>256*1024:raise MemoryError('pure summary256KiB')
 receipt=m.g.save('evidence','goalset_harness_pure_v3.json',raw)
 print(json.dumps({'status':result['status'],'cases':len(CASES),'result':receipt,'errors':ERRORS},ensure_ascii=False))
 if result['status']!='PASS':raise SystemExit(1)
