"""Finite outer owner. No native invocation without an exact enabled root gate."""
import resource
resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912))
import hashlib,importlib.util,json,signal,sys,time,traceback
from pathlib import Path
sys.dont_write_bytecode=True
MODULE=None

def timeout(*a):raise TimeoutError('outer import120')
signal.signal(signal.SIGALRM,timeout);signal.alarm(120)
try:
 path=Path(__file__).with_name('goalset_harness_v3.py')
 contract=json.loads(path.with_name('goalset_contract_v3.json').read_bytes())
 if hashlib.sha256(path.read_bytes()).hexdigest()!=contract['source']['sha256'] or path.stat().st_size!=contract['source']['bytes']:raise ValueError('exact source pin')
 sp=importlib.util.spec_from_file_location('goalset_native_harness',path);MODULE=importlib.util.module_from_spec(sp);sp.loader.exec_module(MODULE);signal.alarm(0)
 code=MODULE.run(sys.argv[1],sys.argv[2])
 if MODULE.OWNER.terminal not in ('complete','completed_regression_failed','failed_closed'):raise ValueError('unclosed owner')
 print('UTCEND '+__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),flush=True)
except BaseException:
 signal.alarm(0);print(json.dumps({'status':'outer_failed_held','error':traceback.format_exc()}),flush=True)
 if MODULE is not None and getattr(MODULE,'OWNER',None) is not None and (MODULE.OWNER.machine is not None or MODULE.OWNER.calls):
  while True:time.sleep(60)
 raise SystemExit(1)
raise SystemExit(code)
