"""Pure material projection, all58 observed Actions; no native/HDS/SDK import."""
import copy,hashlib,json
from pathlib import Path
import goalset_guard_v1 as guard
B=guard.B;ROOT=guard.ROOT;M=1048576
BOUNDARY='公開列図式・成立可能目標集合非空・在庫選択済み実空欄クリックの末相可解性保持修復'
X='実対象割当と整合する成立可能目標がある'
Y='応答末相で不足枠が減少し成立可能目標が残った'
ANALYSIS={'path':str(B/'arc-column-live-loop-20261013/evidence/goal_set_public_rows167_225_analysis_v2.json'),'bytes':836540,'sha256':'3670e9c0a563de57ac5c789bb86f858365e078f26a0d151d7c6ae056e8bcfb34'}
def exact(a,b):
 if type(a)is not type(b):return False
 if isinstance(a,dict):return list(a)==list(b) and all(exact(a[k],b[k]) for k in a)
 if isinstance(a,(list,tuple)):return len(a)==len(b) and all(exact(x,y) for x,y in zip(a,b))
 return a==b
def ref(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(M),b''):h.update(b)
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def check(r):
 p=Path(r['path'])
 if p.is_symlink() or ref(p)!=r:raise ValueError('exact file ref')
 return p
def slots(scene):return {tuple(s['位置']):s['記号'] for box in scene['容器群'] for s in box['枠群']}
def skeleton(s):return {'目標列':s['目標列'],'容器群':[{'色':b['色'],'位置':b['位置'],'起点':b['起点'],'枠群':[x['位置'] for x in b['枠群']]} for b in s['容器群']]}
def hit(xy,pt):return all(type(v)is int for v in pt) and xy[0]-1<=pt[0]<xy[0]+5 and xy[1]-1<=pt[1]<xy[1]+5

def before_view(data,i,click):
 # Deliberately only prior row and actual attempted Action; no after outcome.
 prev=data['全行'][i-1];action=data['全行'][i]['公開metadata']['action_input'];m=prev['全相'][-1]['測定'];observed=data['全場面候補集合'].get(m.get('場面参照'))
 return {'previous_row':prev['行'],'phase':copy.deepcopy(prev['全相'][-1]),'observed':copy.deepcopy(observed),'selection_known':'在庫選択'in m,'selection':copy.deepcopy(m.get('在庫選択')),'action':copy.deepcopy(action),'available':copy.deepcopy(prev['公開metadata']['available_actions']),'learned_click':copy.deepcopy(click)}
def decide(v):
 reasons=[];o=v['observed'];scene=o['場面'] if o else None;pool=o['候補集合'] if o else None;selection=v['selection'];act=v['action'];num=act.get('id');pt=(act.get('data',{}).get('x'),act.get('data',{}).get('y'))
 if scene is None:reasons.append('before知覚UNKNOWN')
 if pool is None or not pool:reasons.append('before成立可能目標集合非空未成立')
 if not v['selection_known'] or selection is None:reasons.append('before在庫選択表示未成立')
 elif scene is None or not any(exact(selection,x) for x in scene['在庫群']):reasons.append('before実在庫対応欠損')
 if type(num)is not int or num!=v['learned_click']['number'] or num not in v['available']:reasons.append('学習クリック/公開available境界外')
 hit_slots=[(k,t) for k,t in slots(scene).items() if hit(k,pt)] if scene is not None else []
 if len(hit_slots)!=1 or hit_slots[0][1]is not None:reasons.append('実対象が一意の空欄でない')
 value=None
 if not reasons:
  k=hit_slots[0][0];token=selection['記号'];value=any(any(tuple(a['位置'])==k and exact(a['記号'],token) for a in goal['全枠割当']) for goal in pool)
 return {'eligible_before':not reasons,'reasons':reasons,'target':list(hit_slots[0][0]) if len(hit_slots)==1 else None,'query_input':{X:value} if not reasons else None}
def after_view(data,i):
 row=data['全行'][i];old=data['全行'][i-1]
 return {'metadata':copy.deepcopy(row['公開metadata']),'before_metadata':copy.deepcopy(old['公開metadata']),'phases':[{'reference':copy.deepcopy(p),'observed':copy.deepcopy(data['全場面候補集合'].get(p['測定'].get('場面参照')))} for p in row['全相']]}
def project(v,a):
 d=decide(v)
 if not d['eligible_before']:return {'decision':d,'teacher':None}
 bm=a['before_metadata'];am=a['metadata']
 if any(type(meta.get(k))is not str or not meta[k] for meta in (bm,am) for k in ('game_id','guid')):raise ValueError('eligible instance identity absent')
 if (bm['game_id'],bm['guid'])!=(am['game_id'],am['guid']) or am.get('full_reset')is not False:raise ValueError('eligible same-instance/reset unknown')
 def progress(meta):
  values=[meta[k] for k in ('score','levels_completed') if k in meta]
  if not values or any(type(x)is not int or x<0 for x in values) or len(set(values))!=1:raise ValueError('eligible public progress unknown/conflicting')
  return values[0]
 if progress(bm)!=progress(am):raise ValueError('eligible public old problem ended')
 if not a['phases']:raise ValueError('eligible after phases absent')
 end=a['phases'][-1]['observed'];prior=v['observed']
 if end is None or not exact(skeleton(prior['場面']),skeleton(end['場面'])) or end['候補集合']is None:raise ValueError('eligible terminal old-goal/model unknown')
 reduced=sum(x is None for x in slots(end['場面']).values())<sum(x is None for x in slots(prior['場面']).values());y=bool(reduced and len(end['候補集合'])>0)
 teacher={X:d['query_input'][X],Y:y}
 if any(type(x)is not bool for x in teacher.values()):raise ValueError('strictbool leaves')
 return {'decision':d,'teacher':teacher,'expected_output':{Y:y},'after_remaining_candidates':len(end['候補集合']),'after_empty_slots_decreased':reduced}
def learned_click(data):
 # No HDS restoration: inspect pinned standard tagged evidence only.
 raw=json.loads(check(data['学習状態']).read_bytes());top=dict(raw['__辞書__']);hist=dict(top['原理履歴']['__辞書__']);found=[]
 for versions in hist.values():
  p=versions[-1]['値']
  if p['対象系境界']=='公開列図式:観測された解答作業と行動ID' and p['条件経路群']=={'__組__':[{'__組__':['解答作業']}]} and p['結果経路']=={'__組__':['必要行動ID']}:
   for pair in p['対応値表']['__組__']:
    k,val=pair['__組__']
    if k['__組__']==['"選択記号を空欄へ割当"']:found.append({'number':val,'principle':p})
 if len(found)!=1 or type(found[0]['number'])is not int or found[0]['number']!=6:raise ValueError('saved learned click correspondence missing')
 return found[0]
def build():
 guard.guard('evidence',8*M);data=json.loads(check(ANALYSIS).read_bytes());check(data['原票']);click=learned_click(data);all_cases=[];teachers=[]
 rows=data['全行'];assert [r['行'] for r in rows]==list(range(167,226))
 # Independently bind every preserved frame descriptor to its official row bytes.
 byrow={r['行']:r for r in rows}
 with Path(data['原票']['path']).open('rb') as f:
  for i,line in enumerate(f):
   if i not in byrow:continue
   r=byrow[i]
   if len(line)!=r['bytes'] or hashlib.sha256(line).hexdigest()!=r['lineSHA256']:raise ValueError('official whole row pin')
   row=json.loads(line)['data'];meta={k:v for k,v in row.items() if k!='frame'}
   if not exact(meta,r['公開metadata']) or len(row['frame'])!=len(r['全相']):raise ValueError('official metadata/phases')
   for phase,frame in zip(r['全相'],row['frame']):
    if hashlib.sha256(bytes(x for fr in frame for x in fr)).hexdigest()!=phase['画素SHA256']:raise ValueError('official full public frame')
 for i in range(1,len(rows)):
  v=before_view(data,i,click);a=after_view(data,i);out=project(v,a);case={'row':rows[i]['行'],'before':v,'after':a,**out};all_cases.append(case)
  if out['decision']['eligible_before']:
   teachers.append({'row':case['row'],'boundary':BOUNDARY,'teacher':out['teacher'],'query_input':out['decision']['query_input'],'expected_output':out['expected_output'],'evidence':{'analysis':ANALYSIS,'case_index':i-1,'row':case['row'],'all_after_phases':len(a['phases'])}})
 # Scope assertions after content-derived selection, never a row selector.
 if [x['row'] for x in teachers]!=[169,171,173,190] or sum(x['evidence']['all_after_phases'] for x in teachers)!=28:raise ValueError('measured pack scope differs')
 return {'schema':'column-goalset-teacher-pack-v1','analysis':ANALYSIS,'original_recording':data['原票'],'whole_59_rows_and_pools':ANALYSIS,'source':ref(Path(__file__)),'boundary':BOUNDARY,'X':X,'Y':Y,'learned_click_evidence':click,'all58_before_decisions_and_observations':all_cases,'teachers':teachers,'counts':{'teachers':len(teachers),'all_action_cases':len(all_cases),'all_rows':59,'teacher_after_phases':28},'limitations':['Full solution enumeration/role interpretation are existing prior; HDS learns only projected compatibility to observed repair.','No arbitrary goal index selected. Full all-goal pool kept in original analysis and every before/after view.','One original Action per proposed experience; phases and alternative goals are correlated views, not independent supports.','No SDK/HDS API/Teach/Query performed while building this pack.','Original failed run and heap loss remain historical; material is not a runtime success claim.']}
if __name__=='__main__':
 result=build();raw=(json.dumps(result,ensure_ascii=False,separators=(',',':'))+'\n').encode();print(guard.save('evidence','goalset_teacher_pack_v2.json',raw))
