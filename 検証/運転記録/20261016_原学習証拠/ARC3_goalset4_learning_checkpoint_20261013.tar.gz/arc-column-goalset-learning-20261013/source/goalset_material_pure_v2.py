"""Pure pack fixture. Actual model evidence, no HDS or SDK."""
import resource;resource.setrlimit(resource.RLIMIT_AS,(512<<20,512<<20))
import copy,json,hashlib,signal
from pathlib import Path
import goalset_guard_v1 as g
import goalset_pack_v2 as p
signal.signal(signal.SIGALRM,lambda *a:(_ for _ in ()).throw(TimeoutError('pure120')));signal.alarm(120)
g.guard('evidence',4<<20)
pack=json.loads((g.ROOT/'evidence/goalset_teacher_pack_v2.json').read_bytes());data=json.loads(p.check(p.ANALYSIS).read_bytes());click=p.learned_click(data);cases=[]
selected=[x for x in pack['all58_before_decisions_and_observations'] if x['decision']['eligible_before']]
assert [x['row'] for x in selected]==[169,171,173,190]
assert [x['teacher'][p.X] for x in selected]==[True,True,False,True]
assert [x['teacher'][p.Y] for x in selected]==[True,True,False,True]
cases.append({'name':'all58_original_order_four_strictbool_and_negative','pass':True,'rows':[x['row'] for x in selected]})
assert sum(len(x['after']['phases']) for x in selected)==28
cases.append({'name':'all28_phases_preserved','pass':True})
first=selected[0];v=first['before'];a=first['after'];original=p.decide(v)
changed=copy.deepcopy(a);changed['metadata']['score']+=99;assert p.exact(p.decide(v),original)
try:p.project(v,changed)
except ValueError as e:cases.append({'name':'after_progress_preserves_before_eligibility_but_HOLD_label','pass':True,'error':str(e)})
else:raise AssertionError('new problem accepted')
changed=copy.deepcopy(a);changed['phases'][-1]['observed']['候補集合']=[];z=p.project(v,changed);assert p.exact(z['decision'],original) and z['teacher'][p.Y]is False;cases.append({'name':'after_effect_reversal_changes_only_label','pass':True})
for name,change in [('unknown_eligible_terminal',lambda a:a['phases'][-1].update(observed=None)),('unknown_eligible_pool',lambda a:a['phases'][-1]['observed'].update(候補集合=None)),('identity_absent',lambda a:[m.update(guid=None) for m in (a['metadata'],a['before_metadata'])]),('conflicting_progress',lambda a:a['metadata'].update(levels_completed=999)),('bool_progress',lambda a:a['metadata'].update(score=True)),('missing_after_phases',lambda a:a.update(phases=[])),('new_goal_not_negative',lambda a:a['phases'][-1]['observed']['場面'].update(目標列=[99]))]:
 changed=copy.deepcopy(a);change(changed)
 try:p.project(v,changed)
 except ValueError as e:cases.append({'name':name,'pass':True,'error':str(e),'decision_preserved':p.decide(v)})
 else:raise AssertionError('eligible unknown accepted '+name)
changed=copy.deepcopy(v);changed['previous_row']=-99;assert p.exact(p.decide(changed),original);cases.append({'name':'provenance_row_not_answer_selector','pass':True})
changed=copy.deepcopy(v);changed['observed']['候補集合']=[];assert p.decide(changed)['eligible_before']is False;cases.append({'name':'empty_before_pool_not_eligible','pass':True})
for t in pack['teachers']:
 assert list(t['teacher'])==[p.X,p.Y] and list(t['query_input'])==[p.X] and list(t['expected_output'])==[p.Y]
 assert all(type(x)is bool for x in t['teacher'].values())
cases.append({'name':'two_leaf_order_one_leaf_query_no_ID_after','pass':True})
result={'schema':'column-goalset-material-pure-v1','status':'PASS','native_calls':0,'SDK_calls':0,'pack':p.ref(g.ROOT/'evidence/goalset_teacher_pack_v2.json'),'source':p.ref(Path(__file__)),'cases':cases,'limitations':'Synthetic after alterations test isolation only. No HDS learning or new environment outcomes; full solution search remains prior.'}
print(g.save('evidence','goalset_material_pure_v2.json',(json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode()))
