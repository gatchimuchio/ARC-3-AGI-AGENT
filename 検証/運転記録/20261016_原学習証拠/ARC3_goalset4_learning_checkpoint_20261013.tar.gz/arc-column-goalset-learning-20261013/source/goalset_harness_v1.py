"""Goalset4 external learning harness. No HDS import or API at module import.
Reuses pinned work-v3 persistence and capture bodies in an isolated module namespace.
Only a separately authorized exact root gate can reach native imports/restoration.
"""
import hashlib,importlib.util,json,lzma,os,resource,signal,sys,time,traceback
from pathlib import Path
B=Path('/workspace/scratch/a94ff513b3af');MIB=1048576
ROOT=B/'arc-column-goalset-learning-20261013'
OWNER=None
X='実対象割当と整合する成立可能目標がある'
Y='応答末相で不足枠が減少し成立可能目標が残った'
BOUNDARY='公開列図式・成立可能目標集合非空・在庫選択済み実空欄クリックの末相可解性保持修復'
BASE={'path': '/workspace/scratch/a94ff513b3af/arc-column-work-learning-20261013/source/column_work_harness_v3.py', 'bytes': 26932, 'sha256': 'f0d73f35a9516eda585b134ae54be9815b36d6164786b9f8a0966c3983640007'}
GUARD={'path': '/workspace/scratch/a94ff513b3af/arc-column-goalset-learning-20261013/source/goalset_guard_v1.py', 'bytes': 1962, 'sha256': 'b0c637996d2ff7c7576ed4f68b851714d741bda339114a59a555dcfdf58cd132'}
BASELINE={'path': '/workspace/scratch/a94ff513b3af/arc-column-live-loop-20261013/failure/087b258ca57e41ff82229797bd8035b4/step_90_b42ced76cc934a38ab348f28c6fe6fa8_failure_normal_state.standard.json', 'bytes': 3639754, 'sha256': '45d591f7df7414bb63ab303485a0dc41c8bcef843488a55ac16046e917a9bad0'}
BASELINE_AUDIT={'path': '/workspace/scratch/a94ff513b3af/arc-column-live-loop-20261013/evidence/independent_failure_087b258c_summary_v2.json', 'bytes': 2445656, 'sha256': '1d956d63a277e9171e6ed7ed39f756cb6a874223d37ca65cceb9ff5011f471f6'}
BASELINE_AUDIT_TOOLS={'path': '/workspace/scratch/a94ff513b3af/arc-column-live-loop-20261013/evidence/independent_failure_087b258c_actual_tools_v1.json', 'bytes': 4288, 'sha256': '4aa6a2b66100c5ca77ef92eca57c2fcbe541e7a7127862e97d4af6355330eb59'}
BASELINE_TOOLS={'path': '/workspace/scratch/a94ff513b3af/arc-column-live-loop-20261013/evidence/actual_live_loop_tools_087b258c_v1.json', 'bytes': 4094, 'sha256': 'a7724c9063a0971d1c5bb760ccbde878a4382c88929c4029391f99b7b9995571'}
PRESERVATION_AUDIT={'path': '/workspace/scratch/a94ff513b3af/arc-column-learning-audit-20261013/result/preservation24_audit_summary_v2.json', 'bytes': 261098, 'sha256': 'f72cbae1b96ead9975494d2d365ed89311b07aa956cecaf385557a1de473d7ba'}
PRESERVATION_EXIT={'path': '/workspace/scratch/a94ff513b3af/arc-column-preparation-learning-20261013/source/preservation_native_actual_exit_4b4bed2b_v1.json', 'bytes': 625, 'sha256': 'e69e5c17eab81e219f9c6e8be4d54ef77c33acf574700687f33b1cf5d16b9141'}
PACK={'path': '/workspace/scratch/a94ff513b3af/arc-column-goalset-learning-20261013/evidence/goalset_teacher_pack_v1.json', 'bytes': 1986243, 'sha256': 'a3fbbbe80a569d95fd281791eab8077f015a3f90f94df5605d49aec4f2899276'}
PACK_SOURCE={'path': '/workspace/scratch/a94ff513b3af/arc-column-goalset-learning-20261013/source/goalset_pack_v1.py', 'bytes': 8673, 'sha256': '05174ee18e623b07f5fc0f050cb4669f85eebf1ac4e718e5209f7488f93ecae9'}

def checked(r,cap=8*MIB):
 p=Path(r['path'])
 if set(r)!={'path','bytes','sha256'} or type(r['bytes'])is not int or not 0<=r['bytes']<=cap or p.is_symlink() or p.stat().st_size!=r['bytes']:raise ValueError('exact FileRef metadata')
 raw=p.read_bytes()
 if hashlib.sha256(raw).hexdigest()!=r['sha256']:raise ValueError('exact FileRef hash')
 return raw
def load(name,r):
 checked(r);sp=importlib.util.spec_from_file_location(name,r['path']);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
g=load('goalset_finite_scope',GUARD)
b=load('goalset_immutable_work_io',BASE)
eq=b.eq
# Preserve inherited method bodies; route only the external evidence namespace.
class EvidencePaths:
 def __truediv__(self,k):
  if k not in ('source','state_trace','failure'):raise ValueError('external namespace')
  return ROOT/('evidence' if k=='state_trace' else k)
def guard(category=None,extra=0):
 return g.guard('evidence' if category=='state_trace' else category,extra)
b.ROOT=EvidencePaths();b.guard=guard

def packet(r,dec=None,enc=None):
 z=lzma.LZMADecompressor();raw=z.decompress(checked(r['file'],16*MIB),max_length=16*MIB+1)
 if len(raw)>16*MIB or not z.eof or z.unused_data or z.check!=lzma.CHECK_CRC64 or len(raw)!=r['rawbytes'] or hashlib.sha256(raw).hexdigest()!=r['rawsha256']:raise ValueError('packet CRC64/EOF/raw')
 tag=json.loads(raw)
 if dec is None:return tag
 value=dec(tag)
 if not eq(enc(value),tag):raise ValueError('normal codec types/order')
 return value

def semantic(r):
 return {'state':r.状態,'predictions':r.内容.get('予測群',[]),'HOLD_reasons':r.内容.get('断定保留理由群',[])}
def score(r,key,truth):
 ps=r.内容.get('予測群',[]);wanted=[p for p in ps if tuple(p['結果経路'])==(key,)];values=[p['予測値']for p in wanted]
 return {'expected':truth,'all_predictions':ps,'correct':bool(values) and all(eq(v,truth)for v in values),'wrong':any(not eq(v,truth)for v in values),'missing':not values,'extra':[p for p in ps if tuple(p['結果経路'])!=(key,)],'HOLD':r.状態=='断定保留','state':r.状態}

class BudgetClock(b.Clock):
 def __init__(self):
  super().__init__();self.closing=False
 def enter(self,mode):
  if self.closing and mode=='compute':self.stop();return
  return super().enter(mode)

class Run(b.Run):
 def __init__(self):
  super().__init__();self.clock=BudgetClock();self.plan=[];self.regression=[];self.terminal=None;self.artifacts=[]
 def save(self,name,value,category='state_trace',codec=True):
  self.pending={'name':name,'value':value}
  raw=self.encoded(value) if codec else b.jb(value)
  if len(raw)>(4*MIB if category=='failure' else 16*MIB):raise MemoryError('bounded journal raw')
  blob=lzma.compress(raw,preset=0,check=lzma.CHECK_CRC64)
  if category=='state_trace' and self.trace_bytes+len(blob)>16*MIB:raise MemoryError('journal aggregate16MiB')
  del raw,blob
  r=super().save(name,value,category,codec);self.artifacts.append(r);return r
 def static_preflight(self,path,digest):
  gate_ref={'path':str(path),'bytes':Path(path).stat().st_size,'sha256':digest};gate=json.loads(checked(gate_ref,65536));self.gate=gate
  if gate.get('schema')!='column-goalset-learning-release-v1' or gate.get('enabled')is not True or gate.get('native_authorized')is not True or gate.get('teacher_pack_approved')is not True:raise PermissionError('exact root native release required')
  if gate.get('source_sha256')!=b.sha(__file__) or gate.get('teacher_pack')!=PACK:raise PermissionError('root source/material pin')
  if type(gate.get('nonce'))is not str or len(gate['nonce'])!=32 or any(c not in '0123456789abcdef'for c in gate['nonce']):raise ValueError('nonce')
  if time.time()>gate['admission_deadline_epoch'] or gate['limits']!={'AS':512*MIB,'compute':600,'save':120}:raise PermissionError('finite admission')
  checked(gate['source_contract']);checked(PACK_SOURCE)
  # Validate closed failure against both actual producer and actual independent audit exits.
  audit=json.loads(checked(BASELINE_AUDIT));tools=json.loads(checked(BASELINE_TOOLS));at=json.loads(checked(BASELINE_AUDIT_TOOLS))
  if audit['schema']!='column-loop-failed-closed-independent-audit-v1' or audit['status']!='OPERATIONAL_RECOVERY_VERIFIED_RUN_FAILED' or audit['nonce']!='087b258ca57e41ff82229797bd8035b4' or audit['native_success']is not False or audit['actual_exit']!=1:raise ValueError('audited failed closure')
  if len(audit['verified'])!=7 or any(v is not True for v in audit['verified'].values()) or audit['counts']['final_counter']!=4713 or audit['failure_normal_state']!=BASELINE or audit['states'][-1]!={'ref':BASELINE,'native_queries':2234,'counter':4713}:raise ValueError('verified exact4713 state')
  if audit['actual_tools']!=BASELINE_TOOLS or tools['nonce']!=audit['nonce'] or tools['status']!='failed_closed' or tools['actual_exit']!=1 or tools['automatic_retry']is not False:raise ValueError('failed actual tool join')
  finals=[p for p in tools['polls']if 'exit_code'in p]
  if len(finals)!=1 or finals[0]['exit_code']!=1:raise ValueError('single actual failed exit')
  terminal=json.loads(finals[0]['output'].splitlines()[0])
  if terminal!={'status':'failed_closed','failure_manifest':audit['manifest'],'automatic_retry':False}:raise ValueError('failed manifest actual join')
  checked(audit['manifest']['file']);checked(BASELINE)
  audit_receipts=[]
  for run in at['runs']:
   for poll in run['polls']:
    if poll.get('exit_code')==0:
     row=json.loads(poll['output'].splitlines()[0])
     if row.get('report')==BASELINE_AUDIT:
      if run['actual_exit']!=0 or row.get('status')!=audit['status'] or row.get('counts')!=audit['counts']:raise ValueError('independent actual audit receipt')
      audit_receipts.append(row)
  if len(audit_receipts)!=1:raise ValueError('unique independent audit exit')
  pa=json.loads(checked(PRESERVATION_AUDIT));pe=json.loads(checked(PRESERVATION_EXIT));lines=pe['output'].splitlines()
  if pa['schema']!='column-preservation24-independent-audit-v1' or pa['status']!='PASS' or pa['errors'] or len(pa['verified'])!=5 or any(v is not True for v in pa['verified'].values()):raise ValueError('old58 independent PASS')
  if pe['exit_code']!=0 or len(lines)!=2 or not lines[1].startswith('UTCEND '):raise ValueError('preservation actual exit')
  receipt=json.loads(lines[0]);self.preservation_ref=receipt['receipt'];self.preservation=packet(self.preservation_ref)
  if pa['completion']!=self.preservation_ref['file'] or pa['actual_exit']!=PRESERVATION_EXIT or receipt['status']!='complete' or receipt['Teach']!=24 or receipt['Query']!=60 or receipt['Action']!=0:raise ValueError('old58 producer/audit join')
  c=self.preservation
  if c['status']!='complete' or c['errors'] or c['teach_calls']!=24 or c['query_calls']!=60 or c['Action']!=0 or c['new_clear']!=0:raise ValueError('old58 completion')
  self.pack=json.loads(checked(PACK))
  if self.pack['schema']!='column-goalset-teacher-pack-v1' or self.pack['source']!=PACK_SOURCE or self.pack['X']!=X or self.pack['Y']!=Y or self.pack['boundary']!=BOUNDARY:raise ValueError('new material exact schema')
  ts=self.pack['teachers']
  if [t['row']for t in ts]!=[169,171,173,190] or len(ts)!=4 or self.pack['counts']!={'teachers':4,'all_action_cases':58,'all_rows':59,'teacher_after_phases':28}:raise ValueError('four original teachers in order')
  for t in ts:
   if set(t)!={'row','boundary','teacher','query_input','expected_output','evidence'} or t['boundary']!=BOUNDARY or list(t['teacher'])!=[X,Y] or any(type(v)is not bool for v in t['teacher'].values()) or not eq(t['query_input'],{X:t['teacher'][X]}) or not eq(t['expected_output'],{Y:t['teacher'][Y]}):raise ValueError('two strictbool leaves only')
   if t['evidence']['analysis']!=self.pack['analysis'] or t['evidence']['row']!=t['row'] or t['evidence']['all_after_phases']!=7:raise ValueError('material row evidence join')
  checked(self.pack['analysis']);checked(self.pack['original_recording'],32*MIB)
  for dep in b.DEPENDENCIES:checked(dep,4*MIB)
  # Three normal success snapshots plus one possible failure checkpoint, and all journals.
  guard('state_trace',BASELINE['bytes']+3*8*MIB+16*MIB)
  return {'baseline':BASELINE,'baseline_audit':BASELINE_AUDIT,'material':PACK,'regression_completion':self.preservation_ref}
 def preflight(self,path,digest):
  self.static_preflight(path,digest)
  sys.dont_write_bytecode=True;sys.path.insert(0,str(b.CORE))
  import hds学習系統 as native
  import hds学習系統.永続化 as persistence
  if Path(native.__file__).resolve()!=b.CORE/'hds学習系統/__init__.py':raise ValueError('native exact path')
  self.native=native;self.enc=persistence._符号化;self.dec=persistence._復号
  baseline=self.dec(json.loads(checked(BASELINE)));prior=self.dec(json.loads(checked(self.preservation['states'][-1])))
  expected=self.dec(self.enc(prior))
  for k in ('照会','学習判定'):expected['識別子状態'][k]=4713
  if not eq(self.enc(expected),self.enc(baseline)) or baseline['識別子状態']['経験']!=129 or len(baseline['台帳']['観測台帳'])!=129:raise ValueError('whole129 knowledge identical except paired counters')
  self.regression=self.regression_plan()
  self.plan=[{'method':'処理する','content':dict(t['teacher']),'boundary':BOUNDARY,'origin':{'group':'new_teach','row':t['row'],'evidence':t['evidence']}}for t in self.pack['teachers']]
  self.plan += [{'method':'照会する','content':dict(t['query_input']),'boundary':BOUNDARY,'origin':{'group':'new_query','row':t['row'],'evidence':t['evidence']}}for t in self.pack['teachers']]
  self.plan += [{'method':'照会する','content':dict(t['query_input']),'boundary':t['boundary'],'origin':{'group':t['group'],'index':t['index'],'original_API':t['API'],'original_comparison_kind':t['original_score'].get('comparison_kind')}}for t in self.regression]
  if len(self.plan)!=66:raise ValueError('exact66 plan')
  self.save('material4',self.pack);self.save('original_old58_plan',self.regression);self.save('exact66_call_plan',self.plan)
 def regression_plan(self):
  c=self.preservation;queries=packet(c['queries'],self.dec,self.enc);scores=packet(c['scoring'],self.dec,self.enc)
  expected_groups=[('preservation_regression',24),('baseline_regression',7),('repair_regression',13),('preparation_regression',14)]
  order=[(name,i)for name,count in expected_groups for i in range(count)]
  if len(queries)!=58 or len(scores)!=58 or [(q['group'],q['index'])for q in queries]!=order or [(q['group'],q['index'])for q in scores]!=order:raise ValueError('all58 original group/order')
  api=[x for x in c['api_calls']if x['method']=='照会する' and x['phase'] in {n for n,c in expected_groups}]
  if len(api)!=58:raise ValueError('all58 actualAPI plan')
  out=[]
  for i,(q,s,a)in enumerate(zip(queries,scores,api)):
   if q['API']!=a:raise ValueError('old query API identity')
   intent=packet(a['intent'],self.dec,self.enc);reply=packet(a['reply'],self.dec,self.enc)
   e=reply['input']
   if intent['method']!='照会する' or reply['method']!='照会する' or not eq(self.enc(intent['input']),self.enc(e)) or not eq(self.enc(q['reply']),self.enc(reply['capture']['return'])):raise ValueError('old full intent/reply join')
   if len(reply['capture']['raw'])!=1 or len(reply['capture']['events'])!=1 or reply['capture']['profile_restored']is not True:raise ValueError('old exact raw exhaust')
   ps=q['reply'].内容.get('予測群',[]);paths={tuple(p['結果経路'])for p in ps}
   if len(paths)!=1 or len(next(iter(paths)))!=1:raise ValueError('old single original output leaf')
   key=next(iter(paths))[0];actual=score(q['reply'],key,s['expected'])
   if any(not eq(actual[k],s[k])for k in actual):raise ValueError('old full scoring markers recomputed')
   out.append({'group':q['group'],'index':q['index'],'boundary':e.対象系境界,'query_input':e.内容,'output_key':key,'expected_output':{key:s['expected']},'original_reply':q['reply'],'original_raw_reply':reply['capture']['raw'],'original_score':s,'API':a})
  return out
 def invoke_next(self):
  i=len(self.calls)
  if not 0<=i<66:raise PermissionError('exact66 API ceiling')
  t=self.plan[i];self.phase=t['origin']['group'];self.frame_ordinal=i
  external=self.native.外部入力(dict(t['content']),t['boundary'])
  self.current={'ordinal':i,'phase':self.phase,'frame_ordinal':i,'method':t['method'],'input':external,'origin':t['origin'],'before':self.markers(),'capture':{}}
  intent=self.save('api_%04d_intent'%i,self.current)
  result=b.capture_call(self.machine,t['method'],external,self.current['capture'])
  self.current['after']=self.markers();reply=self.save('api_%04d_reply'%i,self.current)
  self.calls.append({'ordinal':i,'method':t['method'],'phase':self.phase,'intent':intent,'reply':reply});self.current=None
  return result
 def execute(self):
  self.machine=self.native.HDS学習系統.読み込む(BASELINE['path'])
  initial,old=self.standard('restored_before')
  if initial['bytes']!=BASELINE['bytes'] or initial['sha256']!=BASELINE['sha256']:raise ValueError('byte-identical normal4713 restore')
  teachers=[]
  for t in self.pack['teachers']:
   r=self.invoke_next();teachers.append({'teacher':t,'reply':r,'API':self.calls[-1]})
  tr=self.save('all4_teacher_replies',teachers);trained,learned=self.standard('after_teachers')
  for name,values in old['台帳'].items():
   if not eq(self.enc(learned['台帳'][name][:len(values)]),self.enc(values)):raise ValueError('old129 full ledger prefix')
  if not eq(self.enc(learned['状態履歴'][:len(old['状態履歴'])]),self.enc(old['状態履歴'])):raise ValueError('old full state history prefix')
  for name,values in old['原理履歴'].items():
   if not eq(self.enc(learned['原理履歴'][name][:len(values)]),self.enc(values)):raise ValueError('old principle version prefix')
  if learned['識別子状態']['経験']!=133 or len(learned['台帳']['観測台帳'])!=133 or any(learned['識別子状態'][k]!=4713 for k in ('照会','学習判定')):raise ValueError('Teach4 only exact experience/counters')
  for k in ('最小支持数','最大条件数'):
   if not eq(learned[k],old[k]):raise ValueError('learning configuration unchanged')
  queries=[]
  while len(self.calls)<66:
   r=self.invoke_next();queries.append({'ordinal':len(queries),'origin':self.plan[len(self.calls)-1]['origin'],'reply':r,'API':self.calls[-1]})
  qr=self.save('all62_query_replies',queries);final,last=self.standard('after_queries')
  expected=self.dec(self.enc(learned))
  for k in ('照会','学習判定'):expected['識別子状態'][k]+=62
  if not eq(self.enc(expected),self.enc(last)):raise ValueError('all62 query whole state except paired counters')
  scoring=[]
  for i,(q,t)in enumerate(zip(queries[:4],self.pack['teachers'])):
   s=score(q['reply'],Y,t['expected_output'][Y]);s.update(group='new_query',index=i,row=t['row'],API=q['API']);scoring.append(s)
  for q,t in zip(queries[4:],self.regression):
   s=score(q['reply'],t['output_key'],t['expected_output'][t['output_key']]);s.update(group=t['group'],index=t['index'],API=q['API'],historical_ref=t['API']['reply'],historical_semantics_equal=eq(semantic(q['reply']),semantic(t['original_reply'])),original_score=t['original_score'],original_comparison_kind=t['original_score'].get('comparison_kind'));scoring.append(s)
  sr=self.save('all62_external_scoring',scoring)
  bad=[i for i,s in enumerate(scoring)if not s['correct'] or s['wrong'] or s['missing'] or s['extra'] or s['HOLD'] or ('historical_semantics_equal'in s and not s['historical_semantics_equal'])]
  for dep in b.DEPENDENCIES:checked(dep,4*MIB)
  checked(BASE);checked(GUARD);checked(PACK);checked(PACK_SOURCE)
  if len(self.calls)!=66 or sum(c['method']=='処理する'for c in self.calls)!=4 or sum(c['method']=='照会する'for c in self.calls)!=62:raise ValueError('exactTeach4 Query62')
  self.summary={'schema':'column-goalset-learning-completion-v1','nonce':self.gate['nonce'],'status':'complete' if not bad else 'completed_regression_failed','errors':[],'source':b.ref(Path(__file__)),'source_contract':self.gate['source_contract'],'baseline_state':BASELINE,'baseline_audit':BASELINE_AUDIT,'baseline_audit_actual_tools':BASELINE_AUDIT_TOOLS,'baseline_actual_tools':BASELINE_TOOLS,'material':PACK,'preservation_completion':self.preservation_ref,'states':self.state_refs,'api_calls':self.calls,'teachers':tr,'queries':qr,'scoring':sr,'teach_calls':4,'query_calls':62,'old_regression_queries':58,'new_queries':4,'Action':0,'new_clear':0,'old129_all_prefixes_unchanged':True,'paired_counter_before':4713,'paired_counter_after':4775,'regression_pass':not bad,'failed_scoring_indices':bad,'limits':'Four original correlated public actions, no phase/alternative-goal independent-support expansion. Learned leaves only; no universal safety, live Action or new clear claim. Whole old58 actual outputs compared; original historical-versus-saved-rule distinction retained.'}
  result=self.save('completion',self.summary,codec=False);self.complete=True;self.terminal=self.summary['status'];return result
 def close_failure(self):
  self.clock.stop();self.clock.closing=True;pending=self.pending;current=self.current
  state=None
  if self.machine is not None:state,_=self.standard('failed_closed_state')
  payload={'schema':'column-goalset-learning-failure-v1','nonce':self.gate['nonce'],'status':'failed_closed','errors':self.errors,'current':current,'pending':pending,'completed_api_calls':self.calls,'states':self.state_refs,'normal_state':state,'prior_artifacts':list(self.artifacts),'automatic_retry':False,'limits':'Ordinary HDS state and listed exact API/output evidence saved; arbitrary Python heap/code objects not claimed.'}
  r=self.save('failure',payload,'failure',codec=hasattr(self,'enc'));self.clock.stop();self.terminal='failed_closed';return r

def run(path,digest):
 global OWNER
 if OWNER is not None:raise RuntimeError('one exact run only')
 OWNER=Run()
 try:
  soft,hard=resource.getrlimit(resource.RLIMIT_AS)
  if not(0<soft<=512*MIB and 0<hard<=512*MIB):raise PermissionError('finite AS512 before native import')
  OWNER.clock.enter('compute');guard();OWNER.preflight(path,digest);receipt=OWNER.execute();OWNER.clock.stop()
  print(json.dumps({'status':OWNER.terminal,'receipt':receipt,'Teach':4,'Query':62,'Action':0}),flush=True)
  return 0 if OWNER.terminal=='complete' else 1
 except BaseException as exc:
  OWNER.clock.stop();OWNER.exceptions.append(exc);OWNER.errors.append(traceback.format_exc())
  try:
   if OWNER.gate is None:raise RuntimeError('failure before gate')
   receipt=OWNER.close_failure();print(json.dumps({'status':'failed_closed','failure':receipt,'automatic_retry':False}),flush=True);return 1
  except BaseException as secondary:
   OWNER.clock.stop();OWNER.exceptions.append(secondary);OWNER.errors.append(traceback.format_exc())
   print(json.dumps({'status':'failed_held','automatic_retry':False,'errors':OWNER.errors},ensure_ascii=False),flush=True)
   if OWNER.machine is None and not OWNER.calls:return 1
   while True:time.sleep(60)
