import resource
resource.setrlimit(resource.RLIMIT_AS,(512<<20,512<<20))
resource.setrlimit(resource.RLIMIT_FSIZE,(15<<20,15<<20))
import json,hashlib,tarfile,gzip,os,time,io
from pathlib import Path
B=Path('/workspace/scratch/a94ff513b3af');L=B/'arc-column-live-loop-20261013';O=L/'evidence/checkpoint_goalset4_learning';N='51229802dbf84496a84d401f79e62e1f'
CAP=64<<20

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
def ref(p):return {'path':str(p.relative_to(B)),'bytes':p.stat().st_size,'sha256':sha(p)}
def total(d):return sum(p.stat().st_size for p in d.rglob('*') if p.is_file())
def guard():
 assert total(O)<=CAP
 assert total(L)+CAP<=2048<<20
 assert total(L/'evidence')+CAP<=2000<<20
 s=os.statvfs(B);assert s.f_bavail*s.f_frsize>=(3604+1024)*2**20
 mem=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
 assert mem>=(4608+2048)*2**20
 return {'available_disk_bytes':s.f_bavail*s.f_frsize,'available_ram_bytes':mem,'L_source_bytes':total(L),'output_bytes':total(O)}
pre=guard()
files={B/p for p in json.loads((O/'selection_v1.json').read_text())};files.add(O/'selection_v1.json');excluded=[]
for p in files:
 assert not p.is_symlink() and 'HDS' not in p.parts and 'sdk-runtime' not in p.parts and 'environment_files' not in p.parts and '__pycache__' not in p.parts
for name,h in [('independent_goalset4_51229802_summary_v1.json','35c63b42e175ac5a92e223127c5f308a06e4b92369250de1c2e5b9bacf1c744f'),('independent_goalset4_51229802_actual_tools_v1.json','35907277e8110148d28d42b57e7f34b832f55bfb977935ae4dc2317f9922ef84')]:
 assert sha(L/'evidence'/name)==h
summary=json.loads((L/'evidence/independent_goalset4_51229802_summary_v1.json').read_text());assert summary['status']=='PASS' and summary['actual_exit']==0
assert summary['counts']['Teach']==4 and summary['counts']['Query']==62 and summary['counts']['Action']==0
c7=json.loads((L/'source/loop_contract_v7.json').read_text())
external={'public_recording':json.loads((B/'arc-column-teacher-recovery-20261013/download-v2-receipt.json').read_text()),'HDS_core_pins_not_read_or_included':[r for r in c7['core_and_family_pins'] if 'HDS' in Path(r['path']).parts],'prior_goal_ambiguity_archive':{'name':'ARC3_goal_ambiguity_failure_checkpoint_20261013.tar.gz','bytes':22304243,'sha256':'93dd03fc79465d07ae0604e91c9a52f2eca1546549f8ca9f3d6377297ba76fec'},'baseline_requirement':'Prior checkpoint and fixed HDS installation are external dependencies; not self-contained native runtime. Public raw 67880086 bytes is referenced by original official URL/hash only, never copied.'}
ep=O/'external_refs_v1.json';ep.write_text(json.dumps(external,ensure_ascii=False,indent=2)+'\n');files.add(ep)
report='# ARC3 目標集合・修復4教師 学習checkpoint（2026-10-13）\n\n閉鎖済みnative run: 51229802dbf84496a84d401f79e62e1f。Teach4 / Query62 / Action0、実exit0。独立監査PASS。クリア増分0、認定1/183は据置。\n\n## 実測学習\n- 旧129経験→133経験。counter4,713→4,775（Query62）。旧129経験・全台帳/原理版/履歴prefixを維持。\n- 教師は公開row169→171→173→190の元順。経験130/131/132/133へ接続。173はFalse負例。経験132で成立確認、順向き原理000012と逆向き000013の固定版支持は130–132。後続候補支持130–133と区別する。逆向きを別因果発見として加算しない。\n- 新4件と旧58件（保存24、基底7、修復13、準備14）は全correct、wrong/missing/extra/HOLDは0。教師返却の接続途上/HOLD理由は別途全保存しており、照会採点と混同しない。\n- 全66 intent/raw/external返却、3通常state、支持/反証・候補・隔離・旧返却意味比較を独立確認。独立監査はnativeを再実行しない。\n\n## 学んだ範囲と固定prior\n既存の幾何・記号役割・全在庫と空欄の全単射探索・固定列生成で全成立目標集合を得る処理は固定priorであり、LMが探索方策を獲得したわけではない。今回学んだのは限定境界のbefore『実対象割当と整合する成立可能目標がある』と実after『不足枠が減少し成立可能目標が残った』の2葉順逆対応。before特徴へafterを流入させず、afterを実公開応答から測定する。\n4元Actionは同一公開系列で相関し、28応答相/候補数を独立支持へ増幅しない。任意目標選択、複数目標の保存採否、準備規則、未見転用、全run成功は未成立。\n\n## HOLD接続修正の別管理\nloop_live_v12とhelpers、純検証19ケース・レビューを収録。保存済みstep90の全13返却/5目標pool/9操作候補を保持したHOLD、追加Action0、一意目標step89回帰、異常型/欠落/参照破損のfailure維持を純検証済み。HOLD修正はまだlive未採用で、今回native学習成功とは別の成果。\n\n## 失敗・記録の来歴\nGSLの旧source/material/pure v1–v3と失敗履歴を保持。goalset_harness_pure_tool_reconstruction_v1.jsonは後から再構成した記録であり、原transport/stdoutとbyte一致する原tool証拠ではない。保存結果/traceと元sourceを別保持。analysis_generation_source_evidence_v1.py.txtもsource text証拠で、未保存inline projectionの完全原文ではない。\nHOLD pure v1は19assertion後のreport serializationでTypeError、v2/v3はPASS19。教師独立審査の比較checker失敗もレビュー/tool記録に保持。古い『教示未実施』記載はその審査時点の履歴であり、後続native完了を否定しない。\n\n## 収録・非収録\nGSL閉鎖source/material/native/pure全履歴、教師設計・公開59行/58作用解析・独立審査・原票参照、HOLD v12純検証/レビュー、固定接続依存sourceを収録。再生成__pycache__、進行中Inspect追加準備/保存教材、SDK opaque・ゲーム実装・HDS中核本体を含めない。HDSはpin参照のみ。過去baseline archiveはhash参照し複製しない。\n原公開教師67,880,086 bytesは再複製しない。公式URL https://arcprize.org/api/recordings/sb26-7fbdac44/005a84c0-2969-488b-baa1-d57e68866b33 、SHA256 e26ff1df251af042911126a067c08ee25973b01d3389269472eed6859a4383f2。offset/行SHA/画素SHAは材料・解析に保持。external_refs_v1.jsonに原URL/receiptとbaseline archive/HDS pinsを収録。単体でnative実行できる完全環境とはしない。\n\n## 資源・検証\n添付archiveは独立解凍可能で15 MiB以下。checkpoint出力64 MiB、L2 GiB/evidence2,000 MiB、globalfuture3,604 MiB＋diskfloor1,024 MiB、RAM4,608＋floor2,048 MiB、AS512 MiBを遵守。stream作成、全source/member bytes/hash、manifest、gzip全CRC/EOF読戻しを検証し展開複製なし。packaging自体はSDK/HDS/Action実行なし。upload/sendなし。exact refsはverification_v1.json。\n'
reportp=O/'checkpoint_ja.md';reportp.write_text(report,encoding='utf-8');files.add(reportp);files.add(O/'package_readonly_v1.py')
rows=[ref(p) for p in sorted(files)];sourcebytes=sum(r['bytes'] for r in rows)
manifest={'schema':'arc3-goalset4-learning-checkpoint-v1','nonce':N,'status':'NATIVE_TEACH4_QUERY62_INDEPENDENT_AUDIT_PASS','source_file_count':len(rows),'source_bytes':sourcebytes,'members':rows,'excluded':excluded,'external_baseline_archives':[{'name':'ARC3_resource_failure_checkpoint_20261013.tar.gz','sha256':'6997ea0290620d809eac4c7c5a727786bc4b4f1c9babcdbd2bc6a07b93fda992'},{'name':'ARC3_first_fresh_level_checkpoint_20261013.tar.gz','sha256':'5a063272f5eb967c051fb54e0d896f4d774aa54990b97f93627aec0445290b0d'}],'limits':{'output':CAP,'L':2048<<20,'evidence_category':2000<<20,'globalfuture':3604<<20,'disk_floor':1024<<20,'RAM_reserved':4608<<20,'RAM_floor':2048<<20,'packaging_AS':512<<20},'preflight':pre}
manifest['external_baseline_archives'].append({'name':'ARC3_compute_failure_checkpoint_20261013.tar.gz','sha256':'98bb631629373e59ba642ba65077a1dd3952a038d42331e43a2c483b383d902a'})
mp=O/'manifest_v1.json';mp.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');mr=ref(mp)
archive=O/'ARC3_goalset4_learning_checkpoint_20261013.tar.gz'
with archive.open('xb') as f:
 with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0,compresslevel=6) as gz:
  with tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT) as tar:
   for r in rows+[mr]:
    p=B/r['path'];assert p.stat().st_size==r['bytes'] and sha(p)==r['sha256']
    info=tar.gettarinfo(str(p),arcname=r['path']);info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
    with p.open('rb') as src:tar.addfile(info,src)
    assert p.stat().st_size==r['bytes'] and sha(p)==r['sha256']
    assert archive.stat().st_size+total(O)-archive.stat().st_size<CAP
want={r['path']:r for r in rows+[mr]};seen=set();readbytes=0
with tarfile.open(archive,'r|gz') as tar:
 for member in tar:
  assert member.isfile() and member.name in want and member.name not in seen
  seen.add(member.name);h=hashlib.sha256();n=0
  with tar.extractfile(member) as src:
   for b in iter(lambda:src.read(1<<20),b''):h.update(b);n+=len(b)
  r=want[member.name];assert n==member.size==r['bytes'] and h.hexdigest()==r['sha256'];readbytes+=n
assert seen==set(want)
# Explicit read through the entire gzip trailer and physical EOF; tar iteration alone is insufficient.
gzipbytes=0
with gzip.open(archive,'rb') as gz:
 for b in iter(lambda:gz.read(1<<20),b''):gzipbytes+=len(b)
assert json.loads(mp.read_text())==manifest
for r in rows+[mr]:assert (B/r['path']).stat().st_size==r['bytes'] and sha(B/r['path'])==r['sha256']
assert archive.stat().st_size<=15<<20
post=guard()
v={'schema':'arc3-checkpoint-readback-v1','status':'PASS','archive':ref(archive),'manifest':mr,'member_count':len(seen),'source_file_count':len(rows),'source_bytes':sourcebytes,'all_member_bytes':readbytes,'full_gzip_uncompressed_bytes':gzipbytes,'checks':{'all_member_sha256_and_bytes':True,'source_unchanged_sha256_and_bytes':True,'manifest_exact':True,'full_gzip_CRC_EOF':True,'no_full_extraction':True,'no_SDK_HDS_Action_execution':True,'no_opaque_body_reads':True},'preflight':pre,'postflight':post,'limits':manifest['limits']}
vp=O/'verification_v1.json';vp.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n');assert total(O)<=CAP
print(json.dumps(v,ensure_ascii=False));print('report',json.dumps(ref(reportp)));print('verification',json.dumps(ref(vp)));print('output_bytes',total(O))
