# ARC3 目標集合・修復4教師 学習checkpoint（2026-10-13）

閉鎖済みnative run: 51229802dbf84496a84d401f79e62e1f。Teach4 / Query62 / Action0、実exit0。独立監査PASS。クリア増分0、認定1/183は据置。

## 実測学習
- 旧129経験→133経験。counter4,713→4,775（Query62）。旧129経験・全台帳/原理版/履歴prefixを維持。
- 教師は公開row169→171→173→190の元順。経験130/131/132/133へ接続。173はFalse負例。経験132で成立確認、順向き原理000012と逆向き000013の固定版支持は130–132。後続候補支持130–133と区別する。逆向きを別因果発見として加算しない。
- 新4件と旧58件（保存24、基底7、修復13、準備14）は全correct、wrong/missing/extra/HOLDは0。教師返却の接続途上/HOLD理由は別途全保存しており、照会採点と混同しない。
- 全66 intent/raw/external返却、3通常state、支持/反証・候補・隔離・旧返却意味比較を独立確認。独立監査はnativeを再実行しない。

## 学んだ範囲と固定prior
既存の幾何・記号役割・全在庫と空欄の全単射探索・固定列生成で全成立目標集合を得る処理は固定priorであり、LMが探索方策を獲得したわけではない。今回学んだのは限定境界のbefore『実対象割当と整合する成立可能目標がある』と実after『不足枠が減少し成立可能目標が残った』の2葉順逆対応。before特徴へafterを流入させず、afterを実公開応答から測定する。
4元Actionは同一公開系列で相関し、28応答相/候補数を独立支持へ増幅しない。任意目標選択、複数目標の保存採否、準備規則、未見転用、全run成功は未成立。

## HOLD接続修正の別管理
loop_live_v12とhelpers、純検証19ケース・レビューを収録。保存済みstep90の全13返却/5目標pool/9操作候補を保持したHOLD、追加Action0、一意目標step89回帰、異常型/欠落/参照破損のfailure維持を純検証済み。HOLD修正はまだlive未採用で、今回native学習成功とは別の成果。

## 失敗・記録の来歴
GSLの旧source/material/pure v1–v3と失敗履歴を保持。goalset_harness_pure_tool_reconstruction_v1.jsonは後から再構成した記録であり、原transport/stdoutとbyte一致する原tool証拠ではない。保存結果/traceと元sourceを別保持。analysis_generation_source_evidence_v1.py.txtもsource text証拠で、未保存inline projectionの完全原文ではない。
HOLD pure v1は19assertion後のreport serializationでTypeError、v2/v3はPASS19。教師独立審査の比較checker失敗もレビュー/tool記録に保持。古い『教示未実施』記載はその審査時点の履歴であり、後続native完了を否定しない。

## 収録・非収録
GSL閉鎖source/material/native/pure全履歴、教師設計・公開59行/58作用解析・独立審査・原票参照、HOLD v12純検証/レビュー、固定接続依存sourceを収録。再生成__pycache__、進行中Inspect追加準備/保存教材、SDK opaque・ゲーム実装・HDS中核本体を含めない。HDSはpin参照のみ。過去baseline archiveはhash参照し複製しない。
原公開教師67,880,086 bytesは再複製しない。公式URL https://arcprize.org/api/recordings/sb26-7fbdac44/005a84c0-2969-488b-baa1-d57e68866b33 、SHA256 e26ff1df251af042911126a067c08ee25973b01d3389269472eed6859a4383f2。offset/行SHA/画素SHAは材料・解析に保持。external_refs_v1.jsonに原URL/receiptとbaseline archive/HDS pinsを収録。単体でnative実行できる完全環境とはしない。

## 資源・検証
添付archiveは独立解凍可能で15 MiB以下。checkpoint出力64 MiB、L2 GiB/evidence2,000 MiB、globalfuture3,604 MiB＋diskfloor1,024 MiB、RAM4,608＋floor2,048 MiB、AS512 MiBを遵守。stream作成、全source/member bytes/hash、manifest、gzip全CRC/EOF読戻しを検証し展開複製なし。packaging自体はSDK/HDS/Action実行なし。upload/sendなし。exact refsはverification_v1.json。
