import resource
resource.setrlimit(resource.RLIMIT_AS,(512<<20,512<<20))
import ast,dataclasses,hashlib,importlib.util,json,lzma,os,signal,sys,time,traceback
from pathlib import Path
B=Path('/workspace/scratch/a94ff513b3af')
L=B/'arc-column-live-loop-20261013'; A=L; M=1048576
BASE=B/'arc-column-learning-audit-20261013/source/audit_v1.py'
base=BASE.read_bytes()
assert hashlib.sha256(base).hexdigest()=='e95c8a8307be21b9dc9981685fe84d2b41c0a8216b38f45361e47f4a0d267324'
exec(compile(base.decode().split('def main():',1)[0],str(BASE),'exec'),globals())
L=B/'arc-column-live-loop-20261013'; A=L
G=B/'arc-column-goalset-learning-20261013'; N='51229802dbf84496a84d401f79e62e1f'; D=G/'evidence'/N
g=load('independent_goalset_scope',L/'source/loop_guard_v3.py')
def guard(extra=0,category='evidence'):
 assert os.statvfs(B).f_bavail*os.statvfs(B).f_frsize >= (3604+1024)*M+extra
 return g.guard(category,extra)
def out(name,v,category='evidence'):
 raw=(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
 guard(len(raw),category); return g.save(category,name,raw)
def refs(v):
 if isinstance(v,dict):
  if set(v)=={'path','bytes','sha256'}:exact(v,16*M)
  else:
   for x in v.values():refs(x)
 elif isinstance(v,(list,tuple)):
  for x in v:refs(x)
def semantic(r):
 return {'state':r.状態,'predictions':r.内容['予測群'],'HOLD_reasons':r.内容['断定保留理由群'],**{k:r.内容[k] for k in ('学習成立状態','追加観測要求群','識別不能群','競合群','係争中原理群')}}
def scored(r,key,truth):
 ps=r.内容['予測群'];values=[p['予測値'] for p in ps if tuple(p['結果経路'])==(key,)]
 return {'expected':truth,'all_predictions':ps,'correct':bool(values) and all(same(v,truth) for v in values),'wrong':any(not same(v,truth) for v in values),'missing':not values,'extra':[p for p in ps if tuple(p['結果経路'])!=(key,)],'HOLD':r.状態=='断定保留','state':r.状態}
def main():
 global enc,dec,CURSOR
 signal.signal(signal.SIGALRM,timeout);signal.alarm(300);guard()
 c=packet({'file':{'path':str(D/'completion.json.xz'),'bytes':14084,'sha256':'f529ce30fd9aa2561a54555960f8704048a4d2877306f1551eec35b03fe5e49b'},'rawbytes':54961,'rawsha256':'0209add05cab1d8787287f1c6dd7201aeffb62d8ff6f2311810db9a84773f9b8'},False)
 assert c['nonce']==N and c['status']=='complete' and c['errors']==[] and c['teach_calls']==4 and c['query_calls']==62 and c['Action']==c['new_clear']==0
 assert c['source']['sha256']=='13ba0f5a514319d221329f2b383a3ba18c24870f4310c9de728300d1d699e775'
 source=exact(c['source']); contract=js(exact(c['source_contract']))
 toolsref={'path':str(G/'evidence/actual_native_51229802_v1.json'),'bytes':19004,'sha256':'669a29b93669fcd2f5975a0a789819a0cbe9e22c2313430f69d0f1f6d21e1149'}
 tools=js(exact(toolsref))
 # Find actual terminal result, independent of wrapper field names.
 terminals=[]
 def terminal(v):
  if isinstance(v,dict):
   if v.get('exit_code')==0 and isinstance(v.get('output'),str):
    for line in v['output'].splitlines():
     try:x=json.loads(line)
     except (ValueError,TypeError):continue
     if isinstance(x,dict) and x.get('receipt',{}).get('file')==REFS[str(D/'completion.json.xz')]:terminals.append((v,x))
   for x in v.values():terminal(x)
  elif isinstance(v,list):
   for x in v:terminal(x)
 terminal(tools);assert len(terminals)==1
 assert terminals[0][1]['status']=='complete' and terminals[0][1]['Teach']==4 and terminals[0][1]['Query']==62 and terminals[0][1]['Action']==0
 assert 'UTCEND ' in terminals[0][0]['output']
 tree=ast.parse((B/'arc-column-work-learning-20261013/source/column_work_harness_v3.py').read_bytes())
 deps=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='DEPENDENCIES' for t in n.targets))
 for r in deps:exact(r,4*M)
 sys.dont_write_bytecode=True;sys.path.insert(0,str(CORE))
 import hds学習系統.永続化 as codec
 from hds学習系統.型 import 外部出力,実行結果,学習成立状態,外部入力
 enc,dec=codec._符号化,codec._復号
 CURSOR='three_states'
 states=[]
 for r in c['states']:
  raw=exact(r);tag=js(raw);s=dec(tag)
  assert same(enc(s),tag) and json.dumps(tag,ensure_ascii=False,indent=2).encode()==raw
  states.append(s)
 assert len(states)==3
 old,trained,final=states
 assert exact(c['states'][0])==exact(c['baseline_state'])
 ba=js(exact(c['baseline_audit']));assert ba['status']=='OPERATIONAL_RECOVERY_VERIFIED_RUN_FAILED' and ba['native_success']is False and ba['failure_normal_state']==c['baseline_state'] and all(v is True for v in ba['verified'].values())
 for k,vs in old['台帳'].items():assert same(enc(trained['台帳'][k][:len(vs)]),enc(vs))
 assert same(enc(trained['状態履歴'][:len(old['状態履歴'])]),enc(old['状態履歴']))
 for k,vs in old['原理履歴'].items():assert same(enc(trained['原理履歴'][k][:len(vs)]),enc(vs))
 assert len(old['台帳']['観測台帳'])==129 and len(trained['台帳']['観測台帳'])==133
 assert old['識別子状態']['経験']==129 and trained['識別子状態']['経験']==133
 for k in ('照会','学習判定'):assert old['識別子状態'][k]==trained['識別子状態'][k]==4713 and final['識別子状態'][k]==4775
 expected=dec(enc(trained))
 for k in ('照会','学習判定'):expected['識別子状態'][k]+=62
 assert same(enc(expected),enc(final))
 assert old['最小支持数']==trained['最小支持数']==3 and old['最大条件数']==trained['最大条件数']==2
 CHECKS['three_normal_states_all_old129_ledger_history_prefix_query_only_counter62']=True
 CURSOR='teacher_material_and_old58'
 pack=js(exact(c['material']));ts=pack['teachers'];X=pack['X'];Y=pack['Y'];boundary=pack['boundary']
 assert [t['row'] for t in ts]==[169,171,173,190] and pack['counts']=={'teachers':4,'all_action_cases':58,'all_rows':59,'teacher_after_phases':28}
 assert same(enc(pack),enc(pfile('material4.json.xz')))
 review=plain(L/'evidence/independent_goalset4_teacher_review_v1.md')
 assert digest(review)=='eb0a42211e34c01a025681d35b4ec546b77e0f3f01121c162f53187d679fde66'
 exact(pack['analysis']); exact({'path':str(B/pack['source']['path']),'bytes':pack['source']['bytes'],'sha256':pack['source']['sha256']})
 for t in ts:
  assert list(t['teacher'])==[X,Y] and all(type(v)is bool for v in t['teacher'].values())
  assert same(t['query_input'],{X:t['teacher'][X]}) and same(t['expected_output'],{Y:t['teacher'][Y]}) and t['boundary']==boundary
 oldc=packet(c['preservation_completion'],False);oldq=packet(oldc['queries']);olds=packet(oldc['scoring'])
 assert len(oldq)==len(olds)==58
 plan=[]
 for q,s in zip(oldq,olds):
  r=packet(q['API']['reply']);it=packet(q['API']['intent'])
  assert same(enc(q['reply']),enc(r['capture']['return'])) and same(enc(r['input']),enc(it['input']))
  paths={tuple(p['結果経路']) for p in q['reply'].内容['予測群']}
  assert len(paths)==1 and len(next(iter(paths)))==1
  key=next(iter(paths))[0];calculated=scored(q['reply'],key,s['expected'])
  assert all(same(v,s[k]) for k,v in calculated.items())
  plan.append({'group':q['group'],'index':q['index'],'boundary':r['input'].対象系境界,'query_input':r['input'].内容,'output_key':key,'expected_output':{key:s['expected']},'original_reply':q['reply'],'original_raw_reply':r['capture']['raw'],'original_score':s,'API':q['API']})
 assert same(enc(plan),enc(pfile('original_old58_plan.json.xz')))
 expectedplan=[{'method':'処理する','content':dict(t['teacher']),'boundary':boundary,'origin':{'group':'new_teach','row':t['row'],'evidence':t['evidence']}} for t in ts]
 expectedplan += [{'method':'照会する','content':dict(t['query_input']),'boundary':boundary,'origin':{'group':'new_query','row':t['row'],'evidence':t['evidence']}} for t in ts]
 expectedplan += [{'method':'照会する','content':dict(t['query_input']),'boundary':t['boundary'],'origin':{'group':t['group'],'index':t['index'],'original_API':t['API'],'original_comparison_kind':t['original_score'].get('comparison_kind')}} for t in plan]
 assert same(enc(expectedplan),enc(pfile('exact66_call_plan.json.xz')))
 CHECKS['four_before_only_strict_teachers_original_order_prior_evidence_and_old58_exact_plan']=True
 histories={p.原理識別子:p for vs in trained['原理履歴'].values() for p in vs}
 obs={e.経験識別子:e for e in trained['台帳']['観測台帳']}
 learning={e.学習識別子:e for e in trained['台帳']['学習過程台帳']}
 exhaust=CORE/'hds学習系統/排気系.py'
 fn=next(n for n in ast.walk(ast.parse(exhaust.read_bytes())) if isinstance(n,ast.FunctionDef) and n.name=='排出する')
 ns={'asdict':dataclasses.asdict,'Any':object,'外部出力':外部出力,'実行結果':実行結果,'学習成立状態':学習成立状態}
 exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])),str(exhaust),'exec'),ns)
 api=[];previous=None;teacherresults=[]
 for i,(item,p) in enumerate(zip(c['api_calls'],expectedplan)):
  CURSOR='API_'+str(i);assert item['ordinal']==i and item['method']==p['method']
  it=packet(item['intent']);r=packet(item['reply'])
  for k in ('ordinal','phase','frame_ordinal','method','input','origin','before'):assert same(enc(it[k]),enc(r[k]))
  assert it['capture']=={} and r['ordinal']==r['frame_ordinal']==i and r['phase']==p['origin']['group'] and same(enc(r['origin']),enc(p['origin']))
  assert same(enc(r['input']),enc(外部入力(p['content'],p['boundary'])))
  cap=r['capture'];assert cap['profile_restored']is True and len(cap['raw'])==len(cap['events'])==1 and cap['events'][0]['exact_code_self']is True and cap['events'][0]['function']=='排出する'
  raw=cap['raw'][0];ret=cap['return'];assert same(enc(ns['排出する'](None,raw)),enc(ret))
  if previous is not None:assert same(previous,r['before'])
  previous=r['after']
  if i<4:
   e=obs[ret.追跡情報['経験参照']];assert same(enc(e),enc(trained['台帳']['観測台帳'][129+i])) and same(e.原入力,ts[i]['teacher']) and e.対象系境界==boundary
   assert same(enc(raw.学習過程),enc(learning[raw.学習過程.学習識別子]))
   teacherresults.append({'row':ts[i]['row'],'experience':e.経験識別子,'state':ret.状態,'learning_status':raw.学習過程.学習成立状態.value,'HOLD_reasons':ret.内容['断定保留理由群']})
  else:assert raw.学習過程.学習成立状態.value=='適用外'
  for rule in raw.有効原理群:
   assert same(enc(rule),enc(histories[rule.原理識別子])) and all(x in obs for x in rule.根拠参照群+rule.反証参照群+rule.除外反証参照群)
  for pred in raw.予測群:
   rule=histories[pred.原理参照];assert rule.対象系境界==r['input'].対象系境界 and same(rule.結果経路,pred.結果経路)
  api.append(r)
 assert len(api)==len(c['api_calls'])==66
 assert same(enc(packet(c['teachers'])),enc([{'teacher':t,'reply':api[i]['capture']['return'],'API':c['api_calls'][i]} for i,t in enumerate(ts)]))
 queries=packet(c['queries'])
 assert same(enc(queries),enc([{'ordinal':i,'origin':expectedplan[i+4]['origin'],'reply':api[i+4]['capture']['return'],'API':c['api_calls'][i+4]} for i in range(62)]))
 CHECKS['all66_intent_raw_external_type_order_support_and_new_experience_joins']=True
 scoring=[]
 for i,q in enumerate(queries):
  if i<4:
   t=ts[i];s=scored(q['reply'],Y,t['expected_output'][Y]);s.update(group='new_query',index=i,row=t['row'],API=q['API'])
  else:
   t=plan[i-4];s=scored(q['reply'],t['output_key'],t['expected_output'][t['output_key']])
   s.update(group=t['group'],index=t['index'],API=q['API'],historical_ref=t['API']['reply'],historical_semantics_equal=same(semantic(q['reply']),semantic(t['original_reply'])),original_score=t['original_score'],original_comparison_kind=t['original_score'].get('comparison_kind'))
  scoring.append(s)
 assert same(enc(scoring),enc(packet(c['scoring'])))
 assert all(s['correct'] and not any(s[k] for k in ('wrong','missing','extra','HOLD')) and s.get('historical_semantics_equal',True) for s in scoring)
 CHECKS['all62_strict_scores_whole_HOLD_and_old58_all_eight_semantic_fields']=True
 CURSOR='lineages_and_candidate_evidence'
 changed=[p for name,vs in trained['原理履歴'].items() for p in vs[len(old['原理履歴'].get(name,[])):]]
 assert len(changed)==2
 for p in changed:
  assert p.版==1 and p.根拠参照群==('経験-000130','経験-000131','経験-000132') and p.反証参照群==p.除外反証参照群==() and p.採用状態.value=='有効'
  assert p.対応値表==((('false',),False),(('true',),True))
 assert {(p.条件経路群,p.結果経路) for p in changed}=={(((X,),),(Y,)),(((Y,),),(X,))}
 # Record all new ledger entries including later candidate evidence, disputes and judgment.
 deltas={k:v[len(old['台帳'][k]):] for k,v in trained['台帳'].items()}
 def support_refs(v):
  if dataclasses.is_dataclass(v):support_refs(dataclasses.asdict(v))
  elif isinstance(v,dict):
   for k,x in v.items():
    if k in ('支持参照群','根拠参照群','反証参照群','除外反証参照群','経験参照群'):
     assert all(z in obs for z in x)
    support_refs(x)
  elif isinstance(v,(tuple,list)):
   for x in v:support_refs(x)
 support_refs(deltas)
 CHECKS['forward_inverse_fixed_version_support_and_all_new_candidate_refutation_quarantine_evidence']=True
 refs(c)
 for p in sorted(D.iterdir()):
  if p.suffix=='.xz':
   tag=js(unpack(plain(p)))
   if isinstance(tag,dict) and '__辞書__'in tag:assert same(enc(dec(tag)),tag)
 for r in deps:exact(r,4*M)
 for p,i in IDENT.items():assert ident(Path(p))==i
 CHECKS['all_saved_packet_CRC_EOF_refs_core_bytes_and_identity_unchanged']=True
 counts={group:{k:sum(bool(s[k]) for s in scoring if s['group']==group) for k in ('correct','wrong','missing','extra','HOLD')} for group in dict.fromkeys(s['group'] for s in scoring)}
 result={'schema':'column-goalset4-independent-audit-v1','status':'PASS','errors':[],'nonce':N,'verified':CHECKS,'completion':REFS[str(D/'completion.json.xz')],'actual_tools':toolsref,'actual_exit':0,'states':c['states'],'counts':{'Teach':4,'Query':62,'Action':0,'native_API_by_auditor':0,'experience_before':129,'experience_after':133,'counter_before':4713,'counter_after':4775,'regressions':counts},'teacher_results':teacherresults,'scoring':enc(scoring),'changed_principles':enc(changed),'new_ledger_entries':enc(deltas),'references':list(REFS.values()),'elapsed_seconds':time.monotonic()-START,'limitations':['Full goal enumeration and compatibility are fixed prior. HDS learned the two projected boolean correspondence directions, not goal search or general causal planning.','Four actions from one correlated public trajectory. Before-only teacher evidence is reused from pinned independent full raw/phase review; no new raw remeasurement in this native audit.','Fixed rule version supports130-132; experience133 later candidate support is not relabeled as fixed version support.','Old58 current actual semantic outputs compared on all8 fields, while original historical-query versus saved-rule expectation distinction remains in original_score. No new SDK/Action/clear or unseen transfer claim.','Original failed_closed baseline run remains failed. Pure reconstructed tool summaries are not used as native execution evidence.']}
 ref=out('independent_goalset4_51229802_summary_v1.json',result);signal.alarm(0)
 print(json.dumps({'status':'PASS','report':ref,'counts':result['counts']},ensure_ascii=False),flush=True)
try:main()
except BaseException:
 signal.alarm(0)
 ref=out('independent_goalset4_51229802_failure_v1.json',{'status':'FAIL','cursor':CURSOR,'checks':CHECKS,'traceback':traceback.format_exc()})
 print(json.dumps({'status':'FAIL','failure':ref}),flush=True)
 raise
