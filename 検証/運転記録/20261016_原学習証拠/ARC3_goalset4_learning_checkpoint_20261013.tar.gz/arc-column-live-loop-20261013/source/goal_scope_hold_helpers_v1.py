"""Strict goal-projection boundary classification only; no learner or Action calls."""
import copy

def projection_scope(result, same):
    def require(value, reason):
        if not value:raise ValueError('goal projection boundary: '+reason)
    require(type(result)is dict and result['適用性']=='固定知覚適合', 'structural semantic schema')
    require(type(result['例外'])is list and not result['例外'], 'structural semantic exception')
    require(result['実行許可']is False, 'semantic execution permission')
    full=result['全作用候補'];goal=result['全目標pool']
    require(type(full)is dict and type(goal)is dict, 'complete candidate/goal mapping')
    require(full['実行許可']is False and full['自動選択']is None, 'candidate permission or selection')
    require(same(full['目標pool全件'],goal), 'complete goal copies disagree')
    require(type(goal['状態'])is str, 'goal state type')
    count=None
    if '候補' in goal or '候補数' in goal:
        require('候補' in goal and '候補数' in goal, 'incomplete enumerated goal schema')
        require(type(goal['候補'])is list and type(goal['候補数'])is int, 'goal pool/count type')
        count=goal['候補数'];require(count>=0 and count==len(goal['候補']), 'goal pool/count mismatch')
        expected='HOLD' if count==0 else '唯一解答候補' if count==1 else '複数解答候補'
        require(goal['状態']==expected, 'goal state/count mismatch')
        require(type(goal['全数確認した相異なる割当数'])is int and goal['全数確認した相異なる割当数']>=count, 'enumeration count')
        require(goal['実行許可']is False, 'goal execution permission')
        for item in goal['候補']:
            require(type(item)is dict and type(item['割当'])is list and type(item['列生成'])is dict, 'goal candidate schema')
    else:
        # Exact unresolved forms already emitted by the pinned family. Missing
        # fields in an enumerated pool do not become an empty/unknown pool.
        known_forms=({'状態','理由','照会'}, {'状態','理由','正例照会','負例照会'})
        require(set(goal) in known_forms and goal['状態']=='HOLD' and type(goal['理由'])is str and bool(goal['理由']), 'unrecognized unresolved goal schema')
        require(all(type(goal[k])is dict for k in goal if k not in ('状態','理由')), 'unresolved query schema')
    candidates=full['全候補'];order=full['助言順序']
    require(type(candidates)is list and type(order)is list, 'candidate/order type')
    ids=[]
    for c in candidates:
        require(type(c)is dict and type(c['候補番号'])is int and c['候補番号']>=0, 'candidate identity type')
        require(c['実行許可']is False and type(c['照会全件'])is list, 'candidate permission/query schema')
        ids.append(c['候補番号'])
    require(len(set(ids))==len(ids) and all(type(i)is int for i in order) and same(ids,order), 'all candidate order/identity')
    scan=full['既充足走査完了']
    require(scan is None or type(scan)is bool, 'scan must be bool or explicit None')
    kept=full['既充足枠全件'];required=full['全要求枠']
    require(kept is None or type(kept)is list, 'correct-slot scan type')
    require(required is None or type(required)is dict, 'required-slot scan type')
    if scan is True:
        require(count==1 and kept is not None and required is not None, 'complete scan without one complete goal')
    reasons=[]
    if count is None:reasons.append('目標列挙前の学習関係未確定')
    elif count==0:reasons.append('現在の固定語彙内で整合目標候補なし')
    elif count>1:reasons.append('複数目標候補。割当・操作効果の同値性は未確認')
    if scan is False:reasons.append('既充足走査未完了')
    elif scan is None:reasons.append('既充足走査状態は明示UNKNOWN')
    return {'status':'HOLD' if reasons else 'PROJECT', 'reasons':reasons,
            'goal_count_known':count is not None,'goal_count':count,'goal_state':goal['状態'],
            'scan':copy.deepcopy({'既充足走査完了':scan,'既充足枠全件':kept,'全要求枠':required}),
            'candidate_count':len(candidates)}
