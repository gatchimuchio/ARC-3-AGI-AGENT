"""Pure saved-reply integration fixtures. No learner, SDK, Action or gate.

Only the pinned stdlib dataclass definitions and codec functions are loaded
from HDS sources; no package initializer/engine/state API is executed.
"""
import resource
resource.setrlimit(resource.RLIMIT_AS,(512<<20,512<<20))
import ast,base64,collections,copy,dataclasses,enum,hashlib,importlib.util,itertools,json,lzma,sys,traceback,types
from pathlib import Path
sys.dont_write_bytecode=True
B=Path('/workspace/scratch/a94ff513b3af');L=B/'arc-column-live-loop-20261013';S=L/'source';M=1<<20
D=L/'evidence/087b258ca57e41ff82229797bd8035b4'
OUT=L/'evidence/goal_scope_hold_pure_v1'
sys.path[:0]=[str(S),str(B/'arc-live-step-adapter-20261013')]
import loop_guard_v3 as guard
from loop_fresh_factory_v3 import read,ref,jsonbytes
PINS={};CHECKS=[]
def source(p):
 p=Path(p);r=ref(p);PINS[str(p)]=r;return read(r,8*M)
def load(name,p):
 m=types.ModuleType(name);m.__file__=str(p);sys.modules[name]=m
 exec(compile(source(p),str(p),'exec'),m.__dict__);return m
def lift(name,p,names,ns):
 t=ast.parse(source(p));nodes=[x for x in t.body if isinstance(x,(ast.FunctionDef,ast.ClassDef)) and x.name in names]
 assert {x.name for x in nodes}==set(names)
 m=types.ModuleType(name);m.__dict__.update(ns);sys.modules[name]=m
 exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),str(p),'exec'),m.__dict__);return m
CORE=B/'arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統'
native=load('fixture_pure_types',CORE/'型.py')
codec=lift('fixture_pure_codec',CORE/'永続化.py',['_型表','issubclass_safe','_符号化','_復号'],
 {'型定義':native,'Enum':enum.Enum,'fields':dataclasses.fields,'is_dataclass':dataclasses.is_dataclass,'Any':object})
enc=codec._符号化;dec=codec._復号
old=load('fixture_loop_v11',S/'loop_live_v11.py');new=load('fixture_loop_v12',S/'loop_live_v12.py')
sem=new.semantics;same=sem.exact
source(B/'arc-column-live-pilot-20261013/source/pilot_semantics_v3.py');source(S/'goal_scope_hold_helpers_v1.py')
family_path=B/'arc-current-family-source-20261013/接続/列図式規則.py'
component=load('fixture_components',family_path.parent/'図式観測.py')
names=['知覚不適用','記号を読む','容器外形を観測する','図式を観測する','列を生成する','一致する','照会','内容候補を構成する','選択を読む']
fns={'Counter':collections.Counter,'deepcopy':copy.deepcopy,'itertools':itertools,'外部入力':native.外部入力,'成分群':component.成分群}
for x in ast.parse(source(family_path)).body:
 if isinstance(x,ast.Assign) and len(x.targets)==1 and isinstance(x.targets[0],ast.Name):
  try:fns[x.targets[0].id]=ast.literal_eval(x.value)
  except (ValueError,TypeError):pass
family=lift('fixture_family',family_path,names,fns)
query=lift('fixture_query',B/'arc-column-candidate-query-20261013/source/candidate_query_v5.py',
 ['canonical_observation','semantic_entry'],{'base64':base64,'hashlib':hashlib,'deepcopy':copy.deepcopy,'traceback':traceback})
candidate=load('fixture_candidates',B/'arc-column-candidate-query-20261013/source/candidate_preservation_v1.py')
work=load('fixture_goalwork',B/'arc-column-goal-work-measurement-20261013/source/column_goal_work_v2.py')
boundary=load('fixture_public_boundary',B/'arc-recovery-main-20261013/repository/接続/ARC3境界.py')
final=load('fixture_final',B/'arc-live-step-adapter-20261013/final_adoption_v4.py')
source(B/'arc-live-step-adapter-20261013/adapter.py')

def packetref(p):
 fr=ref(p);blob=read(fr,16*M);z=lzma.LZMADecompressor(memlimit=128*M);raw=z.decompress(blob,max_length=16*M+1)
 assert z.eof and not z.unused_data and z.check==lzma.CHECK_CRC64 and len(raw)<=16*M
 return {'file':fr,'rawbytes':len(raw),'rawsha256':hashlib.sha256(raw).hexdigest()}
def packetvalue(p):
 tag=json.loads(new.rawpacket(p));v=dec(tag);assert same(enc(v),tag);return v
def data(index):
 files=list(D.glob('step_%02d_*_current_complete_semantic.typed.json.xz'%index));assert len(files)==1
 prefix=files[0].name.split('current_complete_semantic')[0];saved=packetvalue(packetref(files[0]));records=[]
 for p in sorted(D.glob(prefix+'query_*_reply.typed.json.xz'),key=lambda p:int(p.name.split('_query_')[1].split('_')[0])):
  rp=packetref(p);v=packetvalue(rp);ip=packetref(p.with_name(p.name.replace('_reply.','_intent.')))
  link={'ordinal':v['ordinal'],'frame':v['frame'],'method':v['method'],'intent':ip,'reply':rp}
  records.append(new.replay_from_packet(link,dec))
 assert records
 origin=records[0]['origin'];public_ref=origin['公開観測参照'];public=json.loads(read(public_ref,16*M))
 cur=query.canonical_observation(boundary,public,index)
 replayed=sem.replay_current(cur,family,candidate,query.semantic_entry,records,dataclasses.asdict,native.外部出力,saved)
 assert same(enc(saved),enc(replayed))
 return types.SimpleNamespace(index=index,nonce=prefix.split('_')[2],records=records,origin=origin,current=cur,
  semantic=saved,semantic_ref=packetref(files[0]),public_ref=public_ref,before=origin['復元状態参照'],
  state_ref=ref(D/(prefix+'after_current_queries.standard.json')),
  state=dec(json.loads(read(ref(D/(prefix+'after_current_queries.standard.json')),8*M))))

def savefile(name,b):
 assert len(b)<=16*M;guard.guard('evidence',len(b));p=OUT/(hashlib.sha256(b).hexdigest()+'_'+name)
 if p.exists():assert p.read_bytes()==b
 else:
  with p.open('xb') as f:f.write(b)
 return ref(p)
class StopBeforeAction(Exception):pass
class FakeTransport:
 def __init__(self,*args,**kwargs):self.verifier=kwargs['verifier']
 def run(self,factory,game,record,**kw):
  factory.dispatch=copy.deepcopy(record)
  raise StopBeforeAction('pure fixture stops before verifier/SDK/Action')

def run_case(module,d,mutation=None,corrupt=None):
 class Fixture(module.Run):
  def __init__(self):
   super().__init__();self.enc=enc;self.dec=dec;self.native=native
   self.family=family;self.candidate=candidate;self.work=work;self.boundary=boundary;self.final=final
   self.step_index=d.index;self.step_nonce=d.nonce;self.public_ref=d.public_ref;self.step_before_state=d.before
   self.before_current_public=d.public_ref;self.final_public_response=d.public_ref
   self.replay_records=copy.deepcopy(d.records);self.prepared={'stale_previous_prepared':'must not be used'}
   self.folder=OUT;self.journal=object();self.events=[]
   self.factory=types.SimpleNamespace(np=None,GameAction=None,dispatch=None,
     arm_step=lambda *a:self.events.append('arm_step'),observe_current=lambda:None)
   self.adapter=types.SimpleNamespace(OneStepTransport=FakeTransport)
   self.r=sem.Replay(self.replay_records,dataclasses.asdict,native.外部出力)
   def entry(*args):
    result=query.semantic_entry(*args)
    if mutation:mutation(result)
    return result
   self.query=types.SimpleNamespace(semantic_entry=entry)
  def allow_frame(self,n):self.r.allow_frame(n)
  def 照会する(self,ext):return self.r.照会する(ext)
  def ask(self,*args):return self.r.ask(*args)
  def version(self):return len(d.state['状態履歴'])-1
  def packet(self,name,value):
   raw=jsonbytes(enc(value));blob=lzma.compress(raw,preset=0,check=lzma.CHECK_CRC64)
   r=savefile(name+'.typed.json.xz',blob);self.refs.append(r);self.events.append(name)
   p={'file':r,'rawbytes':len(raw),'rawsha256':hashlib.sha256(raw).hexdigest()}
   if corrupt=='semantic_ref' and name=='current_complete_semantic':p['file']=dict(r,sha256='0'*64)
   return p
  def save(self,name,value,raw=False):
   r=savefile(name,value if raw else jsonbytes(value));self.refs.append(r);return r
  def standard(self,label):
   assert label=='after_current_queries';self.events.append('verified_existing_standard')
   r=copy.deepcopy(d.state_ref)
   if corrupt=='state_ref':r['sha256']='0'*64
   return r,copy.deepcopy(d.state)
 f=Fixture()
 if corrupt=='reply_input':f.replay_records[0]['input']['対象系境界']+=' damaged'
 if corrupt=='reply_ref':f.replay_records[-1]['reference']['reply']['file']['sha256']='0'*64
 if corrupt=='intent_ref':f.replay_records[0]['reference']['intent']['file']['sha256']='0'*64
 try:
  result=f.step_cycle(None,d.current);f.r.finish();return f,{'kind':'return','value':result}
 except StopBeforeAction:
  f.r.finish();return f,{'kind':'dispatch_not_run','record':f.factory.dispatch,'prepared':f.prepared}
 except Exception as e:return f,{'kind':'failure','type':type(e).__name__,'args':list(e.args),'traceback':traceback.format_exc()}

def mutate_count(n):
 def change(s):
  p=s['全目標pool'];p['候補']=p['候補'][:n];p['候補数']=n;p['状態']='HOLD' if not n else '唯一解答候補' if n==1 else '複数解答候補'
  f=s['全作用候補'];f['目標pool全件']=copy.deepcopy(p);f['既充足走査完了']=False;f['既充足枠全件']=None;f['全要求枠']=None
 return change
def scan(value):
 def change(s):s['全作用候補']['既充足走査完了']=value
 return change
def unknown(s):
 p=s['全目標pool'];s['全目標pool']={'状態':'HOLD','理由':'synthetic unresolved learned acceptance',
  '正例照会':p['正例照会'],'負例照会':p['負例照会']}
 s['全作用候補']['目標pool全件']=copy.deepcopy(s['全目標pool'])
 s['全作用候補']['既充足走査完了']=None

def main():
 guard.guard('evidence',8*M);OUT.mkdir(exist_ok=False)
 d90=data(90);d89=data(89)
 assert d90.semantic['全目標pool']['候補数']==5 and len(d90.records)==13
 assert d89.semantic['全目標pool']['候補数']==1 and d89.semantic['全作用候補']['既充足走査完了'] is True
 for name,d,mutation,expect in [('actual_step90',d90,None,5),('zero',d90,mutate_count(0),0),
  ('multiple',d90,mutate_count(2),2),('unique_incomplete',d89,scan(False),1),
  ('unique_scan_UNKNOWN',d89,scan(None),1),('goal_unknown',d90,unknown,None)]:
  f,r=run_case(new,d,mutation);assert r['kind']=='return',r
  result=r['value'];assert result['status']=='HOLD' and result['Action']==result['additional_Query']==0 and result['prepared'] is None
  assert f.prepared is None and f.factory.dispatch is None and 'arm_step' not in f.events
  held=packetvalue(result['current_goal_boundary']);assert held['scope']['goal_count']==expect
  assert held['current_Query']==len(d.records) and same(held['full_goal_pool'],f.semantic['全目標pool'])
  assert same(held['all_candidates'],f.semantic['全作用候補']) and held['state']==d.state_ref
  assert held['current_replies']==[x['reference'] for x in d.records]
  assert f.events.index('current_complete_semantic')<f.events.index('verified_existing_standard')<f.events.index('current_goal_boundary_HOLD')
  CHECKS.append({'case':name,'result':r,'scope':held['scope'],'all_current_replies':len(d.records),'Action':0})
 f,r=run_case(old,d90);assert r['kind']=='failure' and r['args']==['unique complete goal required'];CHECKS.append({'case':'old_step90_assert_reproduced','result':r})
 # v11 and v12 run the actual unique-state replay and complete dossier generation.
 # Both stop at the same instrumented transport boundary before any Action.
 a,ar=run_case(old,d89);b,br=run_case(new,d89)
 assert ar['kind']==br['kind']=='dispatch_not_run',(ar,br)
 assert same(enc(ar),enc(br));CHECKS.append({'case':'normal_unique_v11_v12_full_dispatch_equal','result':br,'Action':0})
 for name in ('semantic_ref','state_ref','reply_ref','intent_ref','reply_input'):
  f,r=run_case(new,d90,corrupt=name);assert r['kind']=='failure' and f.factory.dispatch is None,r
  assert 'current_goal_boundary_HOLD' not in f.events
  CHECKS.append({'case':'corrupt_'+name+'_rejected','result':r,'Action':0})
 bads={
  'bool_count':lambda s:s['全目標pool'].__setitem__('候補数',True),
  'scan_string':lambda s:s['全作用候補'].__setitem__('既充足走査完了','UNKNOWN'),
  'missing_scan':lambda s:s['全作用候補'].pop('既充足走査完了'),
  'duplicate_candidate':lambda s:s['全作用候補']['全候補'].append(copy.deepcopy(s['全作用候補']['全候補'][0])),
  'false_complete_multi':scan(True),
  'missing_pool_count':lambda s:s['全目標pool'].pop('候補数')}
 for name,mutation in bads.items():
  f,r=run_case(new,d90,mutation);assert r['kind']=='failure' and f.factory.dispatch is None,r
  CHECKS.append({'case':'malformed_'+name+'_rejected','result':r,'Action':0})
 assert not any(k=='hds学習系統' or k.startswith('hds学習系統.') or k.startswith('arc_agi') for k in sys.modules)
 report={'schema':'goal-scope-HOLD-pure-fixture-v1','status':'PASS','checks':CHECKS,'source_pins':list(PINS.values()),
  'actual_step90':{'semantic':d90.semantic_ref,'public':d90.public_ref,'after_query_state':d90.state_ref,
    'current_replies':13,'goals':5,'candidates':len(d90.semantic['全作用候補']['全候補'])},
  'native_calls':{'Teach':0,'Query':0,'SDK':0,'Action':0},
  'limitations':['Pure replay of previously saved native replies only; no new learned support or performance claim.',
   'Unique path compared through dossier and transport entry, not through transport verification, SDK or Action.',
   'Synthetic zero/multiple/incomplete/unknown fixtures modify the semantic-entry result consistently in both replay passes; they are contract tests, not new observed states.',
   'Existing standard-state reference is verified in the fixture; no native state-saving API is run.',
   'Old structural applicability/absent-candidate early-HOLD branch is unchanged.']}
 r=savefile('report.json',(json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode())
 print(json.dumps({'status':'PASS','checks':len(CHECKS),'report':r,'Action':0,'Query':0},ensure_ascii=False),flush=True)
if __name__=='__main__':
 try:main()
 except BaseException:
  raw=traceback.format_exc().encode();print(raw.decode(),flush=True)
  if OUT.exists():savefile('fixture_failure.txt',raw)
  raise
