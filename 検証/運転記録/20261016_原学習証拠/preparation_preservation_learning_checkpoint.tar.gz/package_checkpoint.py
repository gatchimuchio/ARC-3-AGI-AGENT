"""Read-only historical evidence packaging. Standard library only; no native imports."""
from pathlib import Path
import json, hashlib, shutil, lzma, gzip, tarfile, io, zlib, struct, os
B=Path('/workspace/scratch/a94ff513b3af'); L=B/'arc-column-live-loop-20261013'; D=L/'evidence/checkpoint_prepsave_learning'; S=B/'arc-column-goalset-prepsave-learning-20261013'; M=1048576
G=L/'source/goalset_connection/resource_guard_v1.py'; ns={};exec(compile(G.read_bytes(),str(G),'exec'),ns);guard=ns['guard']
def sha(x):return hashlib.sha256(x).hexdigest()
def ref(p):
 x=p.read_bytes();return {'path':str(p),'bytes':len(x),'sha256':sha(x)}
def write(rel,data):
 if isinstance(data,str):data=data.encode()
 guard('evidence',len(data));p=D/rel;p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
 assert p.read_bytes()==data
 return ref(p)
def js(rel,d):return write(rel,json.dumps(d,ensure_ascii=False,indent=2)+'\n')
initial_guard=guard('evidence',79*M)
inputs=[]
for p in sorted(S.rglob('*')):
 assert not p.is_symlink()
 if p.is_file():inputs.append((p,Path('original')/p.relative_to(B)))
for pattern in ['independent_prepsave_b6752d29*','independent_prepsave_ccd893ba_audit_v1.py','independent_prepsave_native_audit_v*.py']:
 for p in sorted((L/'evidence').glob(pattern)):inputs.append((p,Path('original')/p.relative_to(B)))
inputs.append((G,Path('original')/G.relative_to(B)))
assert len({str(p) for p,_ in inputs})==len(inputs)
authority=[B/'arc-recovery-authority-20261013'/x for x in ['Owner指示書原文_20261009.md','Owner追加指示原文_20261010T1907.md','Owner追加指示原文_20261011T1904.md']]+[B/'arc-recovery-main-20261013/repository'/x for x in ['AGENTS.md','運用/権限順序.md','制御/現在状態.json']]
for p in authority:inputs.append((p,Path('original')/p.relative_to(B)))
assert sum(p.stat().st_size for p,_ in inputs)<64*M
input_refs=[{**ref(p),'package_path':str(q)} for p,q in inputs]
for p,q in inputs:write(q,p.read_bytes())
audit_path=L/'evidence/independent_prepsave_b6752d29_summary_v1.json'; audit=json.loads(audit_path.read_bytes())
assert audit['status']=='PASS' and audit['errors']==[]
all_refs={}
def collect(v):
 if isinstance(v,dict):
  if isinstance(v.get('path'),str) and isinstance(v.get('bytes'),int) and isinstance(v.get('sha256'),str):
   key=(v['path'],v['sha256']);all_refs[key]={k:v[k] for k in ['path','bytes','sha256']}
  for x in v.values():collect(x)
 elif isinstance(v,list):
  for x in v:collect(x)
xz_checks=[]
for p,q in inputs:
 raw=p.read_bytes()
 if p.suffix=='.xz':
  dec=lzma.LZMADecompressor(); decoded=dec.decompress(raw)
  assert dec.eof and not dec.unused_data and dec.check in [lzma.CHECK_CRC32,lzma.CHECK_CRC64,lzma.CHECK_SHA256]
  xz_checks.append({'package_path':str(q),'compressed':ref(p),'rawbytes':len(decoded),'rawsha256':sha(decoded),'integrity_check':dec.check,'EOF':True,'unused_data_bytes':0})
  raw=decoded
 if p.suffix in ['.json','.xz']:
  try:collect(json.loads(raw))
  except (ValueError,UnicodeDecodeError):pass
package_sources={str(p) for p,q in inputs}; dependencies=[]
for r in sorted(all_refs.values(),key=lambda x:(x['path'],x['sha256'])):
 if r['path'] in package_sources:continue
 item={**r,'included':False,'provenance':'Exact FileRef retained from original evidence; referenced body is not bundled.'}
 if '/repository/HDS/学習系統/v0.4.2/' in r['path']:
  current=ref(Path(r['path']));assert current==r;item['current_bytes_hash_verified_unchanged']=True
 dependencies.append(item)
js('dependency_refs.json',{'schema':'historical-checkpoint-dependency-refs-v1','notes':['Public corpus and opaque game files are deliberately not copied or opened.','External references are provenance, not claims of an independently rerun native experiment.','Core file bytes are rehashed without importing the code.'],'references':dependencies})
external=[]
for name,expected in [('independent_saved118_failure_prefix_summary_v1.json','b69546d400a9e97a00c78e432626ddeb99092c11110f8c721e8a906e43048dca'),('independent_loop_d7bbc746_summary_v1.json','c9be28ce385d52ebf184b681707b37f2a3e67d970c0a87cb7ffa7affdce92b2b')]:
 r=ref(L/'evidence'/name);assert r['sha256']==expected;external.append(r)
js('context_refs.json',{'historical_checkpoint_counter':4887,'subsequent_diagnostic_counter':5880,'external_context_evidence_not_bundled':external,'main':{'commit':'9ce1830494bb80f5d820fbad61ca9096954a04c6','url':'https://github.com/gatchimuchio/ARC-3-AGI-AGENT/commit/9ce1830494bb80f5d820fbad61ca9096954a04c6','verification':'Parent reported GitHub GET verification at 2026-10-13 23:07 UTC; packaging worker performed no Git/network operation. No local FileRef fabricated.'},'certification':'Parent reports certified fresh achievement remains 1/183; later partial six-level failed-run observations are not promoted to certified achievements.'})
js('inputs_manifest.json',{'files':input_refs,'count':len(input_refs),'bytes':sum(r['bytes'] for r in input_refs)})
js('native_packet_integrity.json',{'status':'PASS','files':xz_checks,'count':len(xz_checks),'note':'Every supplied xz file decoded to EOF with its native integrity check validated; original bytes retained.'})
root='original/arc-column-goalset-prepsave-learning-20261013'; ar='original/arc-column-live-loop-20261013/evidence'; n=root+'/evidence/b6752d29848b4a86990c441935ae5363'
readme=f'''# ARC3 目標条件から逆算する準備・保存学習 checkpoint

## 目的
明確なクリア条件から必要状態と操作を逆算するため、準備操作と既充填枠の保存を分離し、既存HDSに限定範囲の関係を学習させた履歴を保存する。HDS中核・権限・現在状態は変更しない。本梱包は既存証拠の保存のみで、native/SDK/API/Actionを再実行していない。

## 観測・previous / current / delta
- 対象native実行: b6752d29848b4a86990c441935ae5363。Teach 50、Query 112、Action 0、新規clear 0。
- 経験数133 → 183（+50）、照会・学習判定counter4775 → 4887（各+112）。183は学習経験数であり、攻略level数ではない。
- 50教師は準備20・保存30。元の公開Actionは35種類、関係間重複15。50独立試行ではない。準備の応答26相、保存120相を保持。
- 原理13 → 16。原理14/15 v1の支持は経験134–136、原理16 v1は154–156。後続経験・候補支持をv1の固定支持へ水増ししない。
- 新規準備20、新規保存30、旧62の照会は全件正答。wrong/missing/extra/HOLDはいずれも0。旧62は出力の8意味項目まで比較。教師途中の「接続途上」やHOLD理由も原応答に保持。
根拠: `{n}/completion.json.xz`、`{root}/evidence/native_b6752d_readback_v1.json`、`{ar}/independent_prepsave_b6752d29_summary_v1.json`。

## 操作分類・成立した関係
1. 準備: 公開列図式・成立可能目標集合が非空・可視在庫が未選択・既学習クリック作用の範囲。「実クリック対象が利用可能な在庫対象」↔「応答全相でその在庫対象が選択表示」。原理14は順方向、15は逆方向。
2. 保存: 上記公開図式と目標集合に加え、操作前の既充填枠が非空。「可視在庫未選択時の実在庫クリック」または「可視在庫選択時の実空欄クリック」で、操作前の全充填枠が応答全相に保存された。原理16は観測した2操作種別に限る。
3. 範囲外・反例: 狭い保存範囲では反例未観測。広い保存条件や範囲外の否定例を消さず、普遍的安全性へ拡張しない。充填対象の選択、目標集合の列挙、全体攻略の成立は、この関係学習だけで保証されない。
根拠: `{root}/evidence/prepsave_teacher_pack_v2.json` の境界・operation_values・all117、監査summaryのchanged_principles/new_ledger_entries/limitations。

## 原因・変更
必要だったのは、目標に向けた準備操作と、すでに成立した条件を壊さない操作を、公開観測の前後関係として明確に分けること。関係教師は各2葉に限定し、照会には操作前に得られる葉だけを渡す。原理・支持・反証・候補・隔離と全応答を保存する。
前段の2起動失敗も保存した。最初はFileNotFoundError、次は既存失敗履歴に全8MiBを追加予約しfailure上限8MiBを超えるpreflight設計不備。native開始前に閉じた失敗で、HDS欠陥ではない。v5は履歴を保ち、raw4MiB/compressed6MiBと将来予約6MiBに限定。失敗nonceは再使用せず、新nonceで上記実行が完了した。
根拠: `{root}/failure/actual_launch_failure_ccd893ba_v1.json`、`{root}/evidence/actual_native_ccd893ba_v1.json`、`{root}/evidence/failed_ccd893ba_readback_v1.json`、`{root}/source/prepsave_harness_v4_v5.diff`、`{root}/source/prepsave_contract_v5.json`。

## 由来の分離
- 固定側: 公開観測の特徴抽出、成立可能目標集合の探索・射影、操作分類、教師の選別・整形、期待値採点。これらをnative実学習の成果とは呼ばない。
- native学習側: 2葉の関係経験を既存HDSへ入力し、原理14/15/16・経験台帳・候補台帳・支持/反証/隔離を実際に出力した部分。
- pure fixture側: 契約・入力型・呼出上限・保存・失敗系を模擬した検査。fake162呼出を実native件数に加えない。
- 独立監査側: 保存済み全162呼出と状態を読み、外部codecと純粋射影で照合した。監査はnative/API/Action 0。監査v2/v3の失敗も残し、v4のactual exit0/PASSを区別する。
根拠: source全版、`{root}/evidence/prepsave_harness_pure_v4.json`、`{root}/evidence/prepsave_pure_actual_tools_v3.json`、`{ar}/independent_prepsave_b6752d29_actual_tools_v1.json`。

## 回帰・限界・時点
旧133経験prefixを保持し、Query後は対応する2counterのみ変化した。50新規照会と62旧照会の成立は保存範囲の関係検証であり、未見転用・runtime改善・新しいlevel成功を実証していない。
このcheckpointはcounter4887時点の歴史資料。後続保存観測診断は993照会で5880へ進んだが、118観測のうち59完了・59未処理のfailed-heldで、診断完了ではない。この梱包を現在のruntime gateとして使わない。
認証済みfresh達成は親確認で1/183。後続失敗runの部分的6level観測を認証件数へ追加しない。1level根拠と後続診断根拠は同梱外の`context_refs.json`に正確なFileRefを記した。
mainは親の2026-10-13 23:07 UTC GitHub照合による9ce1830494bb80f5d820fbad61ca9096954a04c6。本梱包によるGit変更なし。Git書込はOwner許可待ち。

## 証拠・検証・利用方法
原本source/pure/actual-tools/失敗全版、native全intent/reply・3状態・completion、独立監査のsource/失敗/actual-toolsをバイト単位で同梱した。原本の絶対pathは由来として保持し、移動後は`inputs_manifest.json`のpackage_pathへ対応付ける。原本の参照を書き換えていない。
全原本FileRef（path/bytes/SHA-256）は`inputs_manifest.json`、外部依存FileRefは`dependency_refs.json`。HDS依存は再hash一致。巨大公開corpusとopaqueゲーム実装は複製・閲覧していない。依存全体を同梱した実行環境ではないため、そのまま実行する許可や完全自己完結性は意味しない。
`manifest.json`は同梱payload全ファイルのbytes/SHA-256を列挙し、`manifest.sha256`がmanifest自身を固定する。`archive_verification.json`は全tar memberの数・bytes/hash、gzip CRC/EOF、全xz packetの完全復号とEOF、資源guardを検証した結果。検証報告自身とarchiveは自己参照回避のためpayload manifest外、`delivery_manifest.json`で個別FileRefを固定する。
'''
write('README_ja.md',readme)
js('resource_guard_before.json',{'guard':initial_guard,'guard_source':ref(G),'raw_budget_bytes':64*M,'archive_budget_bytes':15*M})
# Prove every copied original still equals its snapshot, including authorities and all prior failures.
for r in input_refs:assert ref(Path(r['path']))=={k:r[k] for k in ['path','bytes','sha256']}
# The packager source is also preserved and hashed. No prior file is modified.
payload=sorted(p for p in D.rglob('*') if p.is_file())
manifest={'schema':'checkpoint-full-payload-manifest-v1','files':[{'path':str(p.relative_to(D)),**{k:v for k,v in ref(p).items() if k!='path'}} for p in payload]}
js('manifest.json',manifest);write('manifest.sha256',sha((D/'manifest.json').read_bytes())+'  manifest.json\n')
payload=sorted(p for p in D.rglob('*') if p.is_file());total=sum(p.stat().st_size for p in payload);assert total<64*M
archive=D/'preparation_preservation_learning_checkpoint.tar.gz';guard('evidence',15*M)
with archive.open('xb') as out:
 with gzip.GzipFile(filename='',mode='wb',fileobj=out,mtime=0,compresslevel=9) as gz:
  with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tf:
   for p in payload:
    ti=tf.gettarinfo(str(p),arcname=str(p.relative_to(D)));ti.uid=ti.gid=0;ti.uname=ti.gname='';ti.mtime=0
    with p.open('rb') as f:tf.addfile(ti,f)
assert archive.stat().st_size<=15*M
compressed=archive.read_bytes();dec=zlib.decompressobj(31);uncompressed=dec.decompress(compressed)+dec.flush();assert dec.eof and not dec.unused_data and not dec.unconsumed_tail
crc,isz=struct.unpack('<II',compressed[-8:]);assert crc==zlib.crc32(uncompressed)&0xffffffff and isz==len(uncompressed)&0xffffffff
expected={str(p.relative_to(D)):ref(p) for p in payload};seen=[]
with tarfile.open(fileobj=io.BytesIO(uncompressed),mode='r:') as tf:
 for member in tf.getmembers():
  assert member.isfile() and member.name in expected and member.name not in seen
  raw=tf.extractfile(member).read();r=expected[member.name];assert len(raw)==r['bytes']==member.size and sha(raw)==r['sha256'];seen.append(member.name)
 last_end=max(m.offset_data+((m.size+511)//512)*512 for m in tf.getmembers())
assert set(seen)==set(expected) and len(seen)==len(expected)
assert len(uncompressed)-last_end>=1024 and not any(uncompressed[last_end:])
for r in input_refs:assert ref(Path(r['path']))=={k:r[k] for k in ['path','bytes','sha256']}
verification={'status':'PASS','archive':ref(archive),'member_count':len(seen),'expected_member_count':len(expected),'payload_bytes':total,'all_member_hashes_sizes':True,'all_original_inputs_unchanged':True,'tar_end_zero_bytes':len(uncompressed)-last_end,'gzip_CRC32':crc,'gzip_EOF':True,'gzip_no_trailing_data':True,'xz_packets_verified':len(xz_checks),'raw_budget_bytes':64*M,'archive_budget_bytes':15*M,'guard_after':guard()}
js('archive_verification.json',verification)
js('delivery_manifest.json',{'status':'PASS','files':[ref(D/n) for n in ['README_ja.md','manifest.json','manifest.sha256','archive_verification.json',archive.name]],'note':'Archive contains the complete historical payload and source, manifest and manifest.sha256. This outer receipt and archive verification are outside the archive to avoid self-reference.'})
assert sum(p.stat().st_size for p in D.rglob('*') if p.is_file() and p!=archive)<64*M
print(json.dumps({'status':'PASS','archive':ref(archive),'manifest':ref(D/'manifest.json'),'verification':ref(D/'archive_verification.json'),'delivery':ref(D/'delivery_manifest.json'),'input_files':len(input_refs),'archive_members':len(seen),'raw_bytes':total,'xz_packets':len(xz_checks),'final_guard':guard()},ensure_ascii=False))
