import resource
resource.setrlimit(resource.RLIMIT_AS,(512<<20,512<<20))
import ast,dataclasses,hashlib,importlib.util,json,lzma,os,signal,sys,time,traceback
from pathlib import Path
B=Path('/workspace/scratch/a94ff513b3af')
L=B/'arc-column-live-loop-20261013'; A=L; M=1048576
BASE=B/'arc-column-learning-audit-20261013/source/audit_v1.py'
base=BASE.read_bytes()
assert hashlib.sha256(base).hexdigest()=='e95c8a8307be21b9dc9981685fe84d2b41c0a8216b38f45361e47f4a0d267324'
exec(compile(base.decode().split('def main():',1)[0],str(BASE),'exec'),globals())
L=B/'arc-column-live-loop-20261013'; A=L
G=B/'arc-column-goalset-prepsave-learning-20261013'; N=None; D=None
g=load('independent_goalset_scope',L/'source/loop_guard_v3.py')
def guard(extra=0,category='evidence'):
 assert os.statvfs(B).f_bavail*os.statvfs(B).f_frsize >= (3732+1024)*M+extra
 return g.guard(category,extra)
def out(name,v,category='evidence'):
 raw=(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
 guard(len(raw),category); return g.save(category,name,raw)
def refs(v):
 if isinstance(v,dict):
  if set(v)=={'path','bytes','sha256'}:exact(v,16*M)
  else:
   for x in v.values():refs(x)
 elif isinstance(v,(list,tuple)):
  for x in v:refs(x)
def semantic(r):
 return {'state':r.状態,'predictions':r.内容['予測群'],'HOLD_reasons':r.内容['断定保留理由群'],**{k:r.内容[k] for k in ('学習成立状態','追加観測要求群','識別不能群','競合群','係争中原理群')}}
def scored(r,key,truth):
 ps=r.内容['予測群'];values=[p['予測値'] for p in ps if tuple(p['結果経路'])==(key,)]
 return {'expected':truth,'all_predictions':ps,'correct':bool(values) and all(same(v,truth) for v in values),'wrong':any(not same(v,truth) for v in values),'missing':not values,'extra':[p for p in ps if tuple(p['結果経路'])!=(key,)],'HOLD':r.状態=='断定保留','state':r.状態}
def main():
 global enc,dec,CURSOR,N,D
 signal.signal(signal.SIGALRM,timeout);signal.alarm(300);guard()
 # CLI contains root/writer-provided exact immutable FileRefs, never an enabled action gate.
 receipt_raw=Path(sys.argv[1]).read_bytes();assert digest(receipt_raw)==sys.argv[2];receipt=js(receipt_raw);toolsref=receipt['actual_tools'];completion=receipt['completion'];N=receipt['nonce'];assert len(N)==32 and all(z in '0123456789abcdef'for z in N);D=G/'evidence'/N
 c=packet(completion,False);tools=js(exact(toolsref))
 assert c['nonce']==N and c['status']=='complete' and c['errors']==[] and c['teach_calls']==50 and c['query_calls']==112 and c['Action']==c['new_clear']==0
 assert c['source']['sha256']=='1571e28926375d7824ea733ac956dbee8ba51059ee047ef58986936258a2f045'
 exact(c['source']);contract=js(exact(c['source_contract']));assert contract['source']==c['source'] and contract['material']==c['material']
 terminal_lines=[];exits=[]
 def visit(v):
  if isinstance(v,dict):
   if 'exit_code'in v:exits.append(v['exit_code'])
   if isinstance(v.get('output'),str):
    for line in v['output'].splitlines():
     try:z=json.loads(line)
     except (ValueError,TypeError):continue
     if isinstance(z,dict) and z.get('receipt')==completion:terminal_lines.append(z)
   for z in v.values():visit(z)
  elif isinstance(v,list):
   for z in v:visit(z)
 visit(tools)
 assert len(terminal_lines)==1 and terminal_lines[0]['status']=='complete' and terminal_lines[0]['Teach']==50 and terminal_lines[0]['Query']==112 and terminal_lines[0]['Action']==0
 assert exits==[0] and tools['actual_exit']==0
 failed_launches=[js(exact(r))for r in receipt['prior_launch_failures']];assert len(failed_launches)==2 and 'FileNotFoundError'in json.dumps(failed_launches[0],ensure_ascii=False)and 'category failure'in json.dumps(failed_launches[1],ensure_ascii=False)
 CHECKS['actual_terminal_exit0_and_prior_pre_native_launch_failure_preserved']=True
 tree=ast.parse((B/'arc-column-work-learning-20261013/source/column_work_harness_v3.py').read_bytes())
 deps=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name)and t.id=='DEPENDENCIES'for t in n.targets))
 for r in deps:exact(r,4*M)
 sys.dont_write_bytecode=True;sys.path.insert(0,str(CORE))
 import hds学習系統.永続化 as codec
 from hds学習系統.型 import 外部出力,実行結果,学習成立状態,外部入力
 enc,dec=codec._符号化,codec._復号
 # Only tagged-object codec/types and pure exhaust projection; no machine or HDS API.
 CURSOR='three_states'
 states=[]
 for r in c['states']:
  raw=exact(r);tag=js(raw);s=dec(tag);assert same(enc(s),tag)and json.dumps(tag,ensure_ascii=False,indent=2).encode()==raw;states.append(s)
 assert len(states)==3;old,trained,final=states
 assert exact(c['states'][0])==exact(c['baseline_state'])
 ba=js(exact(c['baseline_audit']));assert ba['status']=='PASS' and ba['errors']==[] and ba['states'][-1]==c['baseline_state'] and all(v is True for v in ba['verified'].values())
 for k,vs in old['台帳'].items():assert same(enc(trained['台帳'][k][:len(vs)]),enc(vs))
 assert same(enc(trained['状態履歴'][:len(old['状態履歴'])]),enc(old['状態履歴']))
 for k,vs in old['原理履歴'].items():assert same(enc(trained['原理履歴'][k][:len(vs)]),enc(vs))
 assert len(old['台帳']['観測台帳'])==133 and len(trained['台帳']['観測台帳'])==183
 assert old['識別子状態']['経験']==133 and trained['識別子状態']['経験']==183
 for k in ('照会','学習判定'):assert old['識別子状態'][k]==trained['識別子状態'][k]==4775 and final['識別子状態'][k]==4887
 expected=dec(enc(trained))
 for k in ('照会','学習判定'):expected['識別子状態'][k]+=112
 assert same(enc(expected),enc(final))
 assert old['最小支持数']==trained['最小支持数']==3 and old['最大条件数']==trained['最大条件数']==2
 CHECKS['three_normal_states_all_old133_prefixes_and_only112_query_counter_changes']=True
 CURSOR='teacher_material_and_old62'
 pack=js(exact(c['material']));ts=pack['teachers'];X,Y,PX,PY=(pack[k]for k in ('X','Y','PX','PY'));PB,SB=(pack[k]for k in ('preparation_boundary','preservation_boundary'))
 assert len(ts)==50 and same(enc(pack),enc(pfile('material50.json.xz')))
 analysis=js(exact(pack['analysis']));original={(r['source'],r['row']):r for r in analysis['all117_before_and_all_after_measurements']}
 assert len(original)==117 and [r['measurement']for r in pack['all117']]==list(original.values())
 exact(pack['source']);assert pack['counts']=={'preparation':20,'preservation':30,'all_action_cases':117,'distinct_source_actions':35,'cross_relation_overlap':15,'preparation_after_phases':26,'preservation_after_phases':120,'broad_preservation':33,'unknown_after_HOLD':0}
 expectedp=[('PT',n)for n in [2,3,6,8,10,14,15,44,46,48,50,52,55,57]]+[('LS',n)for n in [168,170,172,189,191,192]]
 expecteds=[('PT',n)for n in [6,7,8,9,10,11,15,16,44,45,46,47,48,49,50,51,52,54,55,56,57,58]]+[('LS',n)for n in [168,169,170,171,172,173,189,190]]
 assert [(t['source'],t['row'])for t in ts]==expectedp+expecteds
 assert len(set(expectedp)|set(expecteds))==35 and len(set(expectedp)&set(expecteds))==15
 for i,t in enumerate(ts):
  x,y,bd=(X,Y,PB)if i<20 else(PX,PY,SB);r=original[(t['source'],t['row'])]
  assert list(t['teacher'])==[x,y] and type(t['teacher'][y])is bool and t['status']=='READY'and t['boundary']==bd
  assert same(t['query_input'],{x:t['teacher'][x]})and same(t['expected_output'],{y:t['teacher'][y]})and same(t['evidence']['measurement'],r)
  assert r['pool']>0 and r['empty']>0 and r['selection_known']is True and not r['before_reasons']
  if i<20:assert type(t['teacher'][x])is bool and r['selected_before']is None and t['teacher'][x]is bool(r['target_inventory'])and r['prep_before']
  else:
   assert r['filled']>0
   op=pack['operation_values'][0]if r['target_kind']=='実在庫'and r['selected_before']is None else pack['operation_values'][1]if r['target_kind']=='実空欄'and r['selected_before']is not None else None
   assert op is not None and t['teacher'][x]==op
  vals=r['clicked_inventory_selection_per_phase']if i<20 else r['preservation_per_phase'];assert len(vals)==r['phases']and vals and all(type(z)is bool for z in vals)and t['teacher'][y]is all(vals)
 # Reparse raw public pixels for all50 projections; do not execute game code/SDK.
 rawref=pack['raw_source'];assert RAW.stat().st_size==rawref['bytes']and filehash(RAW)==rawref['sha256'];IDENT[str(RAW)]=ident(RAW);REFS[str(RAW)]=rawref
 from collections import Counter
 src=next(r for r in pack['source_pins']if r['path'].endswith('/列図式規則.py'));raw=exact(src);names={'知覚不適用','記号を読む','容器外形を観測する','図式を観測する','選択を読む'}
 nodes=[n for n in ast.parse(raw).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))and n.name in names];assert len(nodes)==5;ns={'Counter':Counter};exec(compile(ast.Module(body=nodes,type_ignores=[]),src['path'],'exec'),ns)
 prep_by={t['row']:t for t in ts[:20]};pres_by={t['row']:t for t in ts[20:]};prev=None;pn=sn=0
 with RAW.open('rb')as f:
  for index,line in enumerate(f):
   value=js(line)['data'];frames=value.get('frame',[])
   if index in prep_by or index in pres_by:
    pin=pack['raw_rows_verified'][str(index)];assert len(line)==pin['bytes']and digest(line)==pin['sha256']
    before=ns['図式を観測する'](prev);filled={tuple(s['位置']):s['記号']for box in before['容器群']for s in box['枠群']if s['記号']is not None}
    for phase,frame in enumerate(frames):
     scene=ns['図式を観測する'](frame);selection=ns['選択を読む'](frame,scene)
     if index in prep_by:
      r=prep_by[index]['evidence']['measurement'];assert selection==r['visible_selection_all_phases'][phase]
      outcome=bool(r['target_inventory'])and selection==r['target_inventory'][0];assert outcome==r['clicked_inventory_selection_per_phase'][phase];pn+=1
     if index in pres_by:
      r=pres_by[index]['evidence']['measurement'];assert len(filled)==r['filled'];after={tuple(s['位置']):s['記号']for box in scene['容器群']for s in box['枠群']}
      assert all(k in after and after[k]==v for k,v in filled.items())==r['preservation_per_phase'][phase];sn+=1
   if frames:prev=frames[-1]
 assert (pn,sn)==(26,120)
 oldc=packet(c['previous_completion'],False);oldq=packet(oldc['queries']);olds=packet(oldc['scoring']);assert len(oldq)==len(olds)==62
 plan=[]
 for i,(q,s)in enumerate(zip(oldq,olds)):
  r=packet(q['API']['reply']);it=packet(q['API']['intent']);assert same(enc(q['reply']),enc(r['capture']['return']))and same(enc(r['input']),enc(it['input']))
  paths={tuple(p['結果経路'])for p in q['reply'].内容['予測群']};assert len(paths)==1 and len(next(iter(paths)))==1
  key=next(iter(paths))[0];calculated=scored(q['reply'],key,s['expected']);assert all(same(v,s[k])for k,v in calculated.items())
  plan.append({'group':'old62_regression','index':i,'boundary':r['input'].対象系境界,'query_input':r['input'].内容,'output_key':key,'expected_output':{key:s['expected']},'original_reply':q['reply'],'original_raw_reply':r['capture']['raw'],'original_score':s,'API':q['API']})
 assert same(enc(plan),enc(pfile('original_old62_plan.json.xz')))
 expectedplan=[{'method':'処理する','content':dict(t['teacher']),'boundary':t['boundary'],'origin':{'group':'new_teach','relation':'preparation'if i<20 else'preservation','source':t['source'],'row':t['row'],'evidence':t['evidence']}}for i,t in enumerate(ts)]
 expectedplan += [{'method':'照会する','content':dict(t['query_input']),'boundary':t['boundary'],'origin':{'group':'new_query','relation':'preparation'if i<20 else'preservation','source':t['source'],'row':t['row'],'evidence':t['evidence']}}for i,t in enumerate(ts)]
 expectedplan += [{'method':'照会する','content':dict(t['query_input']),'boundary':t['boundary'],'origin':{'group':t['group'],'index':t['index'],'original_API':t['API'],'original_comparison_kind':t['original_score'].get('original_comparison_kind')}}for t in plan]
 assert same(enc(expectedplan),enc(pfile('exact162_call_plan.json.xz')))
 CHECKS['all50_before_only_two_leaf_teachers_35_actions_all26_120_raw_phases_and_old62_plan']=True
 CURSOR='all162_native_captures'
 histories={p.原理識別子:p for vs in trained['原理履歴'].values()for p in vs};obs={e.経験識別子:e for e in trained['台帳']['観測台帳']};learning={e.学習識別子:e for e in trained['台帳']['学習過程台帳']}
 exhaust=CORE/'hds学習系統/排気系.py';fn=next(n for n in ast.walk(ast.parse(exhaust.read_bytes()))if isinstance(n,ast.FunctionDef)and n.name=='排出する');ns={'asdict':dataclasses.asdict,'Any':object,'外部出力':外部出力,'実行結果':実行結果,'学習成立状態':学習成立状態};exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])),str(exhaust),'exec'),ns)
 api=[];previous=None;teacherresults=[]
 assert len(c['api_calls'])==162
 for i,(item,p)in enumerate(zip(c['api_calls'],expectedplan)):
  CURSOR='API_'+str(i);assert item['ordinal']==i and item['method']==p['method']
  it=packet(item['intent']);r=packet(item['reply'])
  for k in ('ordinal','phase','frame_ordinal','method','input','origin','before'):assert same(enc(it[k]),enc(r[k]))
  assert it['capture']=={}and r['ordinal']==r['frame_ordinal']==i and r['phase']==p['origin']['group']and same(enc(r['origin']),enc(p['origin']))
  assert same(enc(r['input']),enc(外部入力(p['content'],p['boundary'])))
  cap=r['capture'];assert cap['profile_restored']is True and len(cap['raw'])==len(cap['events'])==1 and cap['events'][0]['exact_code_self']is True and cap['events'][0]['function']=='排出する'
  assert Path(cap['events'][0]['filename'])==exhaust
  raw=cap['raw'][0];ret=cap['return'];assert same(enc(ns['排出する'](None,raw)),enc(ret))
  if previous is not None:assert same(previous,r['before'])
  previous=r['after']
  if i<50:
   e=obs[ret.追跡情報['経験参照']];assert same(enc(e),enc(trained['台帳']['観測台帳'][133+i]))and same(e.原入力,ts[i]['teacher'])and e.対象系境界==ts[i]['boundary'];assert same(enc(raw.学習過程),enc(learning[raw.学習過程.学習識別子]))
   teacherresults.append({'source':ts[i]['source'],'row':ts[i]['row'],'experience':e.経験識別子,'state':ret.状態,'learning_status':raw.学習過程.学習成立状態.value,'HOLD_reasons':ret.内容['断定保留理由群']})
  else:
   assert raw.学習過程.学習成立状態.value=='適用外'
   assert not any(ret.内容[k]for k in ('断定保留理由群','追加観測要求群','識別不能群','競合群','係争中原理群'))
  for rule in raw.有効原理群:
   assert same(enc(rule),enc(histories[rule.原理識別子]))and all(x in obs for x in rule.根拠参照群+rule.反証参照群+rule.除外反証参照群)
  for pred in raw.予測群:
   rule=histories[pred.原理参照];assert rule.対象系境界==r['input'].対象系境界 and same(rule.結果経路,pred.結果経路)
   vals=tuple(r['input'].内容[path[0]]for path in rule.条件経路群);assert same(vals,pred.条件値群)
   keys=tuple(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'))for v in vals)
   value=vals[0]if rule.関係型=='同値関係'else dict(rule.対応値表)[keys];assert same(value,pred.予測値)
  api.append(r)
 assert same(enc(packet(c['teachers'])),enc([{'teacher':t,'reply':api[i]['capture']['return'],'API':c['api_calls'][i]}for i,t in enumerate(ts)]))
 queries=packet(c['queries']);assert same(enc(queries),enc([{'ordinal':i,'origin':expectedplan[i+50]['origin'],'reply':api[i+50]['capture']['return'],'API':c['api_calls'][i+50]}for i in range(112)]))
 CHECKS['all162_intent_raw_external_type_order_support_prediction_and_new_experience_joins']=True
 scoring=[]
 for i,q in enumerate(queries):
  if i<50:
   t=ts[i];key=next(iter(t['expected_output']));s=scored(q['reply'],key,t['expected_output'][key]);s.update(group='new_query',index=i,row=t['row'],API=q['API'])
  else:
   t=plan[i-50];s=scored(q['reply'],t['output_key'],t['expected_output'][t['output_key']]);s.update(group=t['group'],index=t['index'],API=q['API'],historical_ref=t['API']['reply'],historical_semantics_equal=same(semantic(q['reply']),semantic(t['original_reply'])),original_score=t['original_score'],original_comparison_kind=t['original_score'].get('original_comparison_kind'))
  scoring.append(s)
 assert same(enc(scoring),enc(packet(c['scoring'])))
 assert all(s['correct']and not any(s[k]for k in ('wrong','missing','extra','HOLD'))and s.get('historical_semantics_equal',True)for s in scoring)
 CHECKS['new50_strict_complete_predictions_zero_uncertainty_and_old62_all8_semantic_fields']=True
 CURSOR='lineages_and_candidate_evidence'
 changed=[p for name,vs in trained['原理履歴'].items()for p in vs[len(old['原理履歴'].get(name,[])):]]
 assert len(changed)==3
 assert {(p.対象系境界,p.条件経路群,p.結果経路)for p in changed}=={(PB,((X,),),(Y,)),(PB,((Y,),),(X,)),(SB,((PX,),),(PY,))}
 for p in changed:
  assert p.版==1 and p.反証参照群==p.除外反証参照群==()and p.採用状態.value=='有効'
  if p.対象系境界==PB:assert p.根拠参照群==('経験-000134','経験-000135','経験-000136')and p.対応値表==((('false',),False),(('true',),True))
  else:
   assert p.根拠参照群==('経験-000154','経験-000155','経験-000156')
   assert len(p.対応値表)==2 and all(value is True for key,value in p.対応値表)
  for rid in p.根拠参照群:
   e=obs[rid];assert e.対象系境界==p.対象系境界
   vals=tuple(e.原入力[path[0]]for path in p.条件経路群);keys=tuple(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'))for v in vals)
   assert same(dict(p.対応値表)[keys],e.原入力[p.結果経路[0]])
 deltas={k:v[len(old['台帳'][k]):]for k,v in trained['台帳'].items()}
 def support_refs(v):
  if dataclasses.is_dataclass(v):support_refs(dataclasses.asdict(v))
  elif isinstance(v,dict):
   for k,x in v.items():
    if k in ('支持参照群','根拠参照群','反証参照群','除外反証参照群','経験参照群'):assert all(z in obs for z in x)
    support_refs(x)
  elif isinstance(v,(tuple,list)):
   for x in v:support_refs(x)
 support_refs(deltas)
 CHECKS['preparation_forward_inverse_preservation_constant_fixed_supports_all_candidate_refutation_quarantine_evidence']=True
 CURSOR='immutable_closure'
 refs(c)
 for p in sorted(D.iterdir()):
  if p.suffix=='.xz':
   tag=js(unpack(plain(p)))
   if isinstance(tag,dict)and '__辞書__'in tag:assert same(enc(dec(tag)),tag)
 for r in deps:exact(r,4*M)
 for p,i in IDENT.items():assert ident(Path(p))==i
 CHECKS['all_saved_packet_CRC_EOF_refs_core_bytes_and_file_identity_unchanged']=True
 counts={group:{k:sum(bool(s[k])for s in scoring if s['group']==group)for k in ('correct','wrong','missing','extra','HOLD')}for group in dict.fromkeys(s['group']for s in scoring)}
 result={'schema':'column-goalset-prepsave-independent-audit-v1','status':'PASS','errors':[],'nonce':N,'verified':CHECKS,'completion':completion,'actual_tools':toolsref,'prior_launch_failures':receipt['prior_launch_failures'],'actual_exit':0,'states':c['states'],'counts':{'Teach':50,'Query':112,'Action':0,'native_API_by_auditor':0,'machine_restore_by_auditor':0,'experience_before':133,'experience_after':183,'counter_before':4775,'counter_after':4887,'distinct_source_actions':35,'overlap':15,'raw_preparation_phases':26,'raw_preservation_phases':120,'regressions':counts},'teacher_results':teacherresults,'scoring':enc(scoring),'changed_principles':enc(changed),'new_ledger_entries':enc(deltas),'references':list(REFS.values()),'elapsed_seconds':time.monotonic()-START,'limitations':['50 relational teachers are35 correlated historical public Actions, including15 cross-relation overlaps, not50 independent trials.','Preparation selection and filled preservation are bounded projections; neither learns goal enumeration or proves unseen transfer/whole-game feasibility.','Fixed rule version supports remain their first3; later candidate support is recorded separately.','All old62 current actual outputs match all8 semantics; historical-versus-saved-rule distinctions remain in original_score.','Auditor only decoded native codec/types and applied pure exhaust projection; no HDS instance, restoration, Teach, Query, SDK, Action or new clear.','Both previous pre-native harness failures remain preserved separately; the current native run uses a new authorization nonce.']}
 ref=out('independent_prepsave_'+N[:8]+'_summary_v1.json',result);signal.alarm(0);print(json.dumps({'status':'PASS','report':ref,'counts':result['counts']},ensure_ascii=False),flush=True)
try:main()
except BaseException:
 signal.alarm(0);ref=out('independent_prepsave_'+str(N)[:8]+'_failure_v1.json',{'status':'FAIL','cursor':CURSOR,'checks':CHECKS,'traceback':traceback.format_exc()});print(json.dumps({'status':'FAIL','failure':ref}),flush=True);raise
