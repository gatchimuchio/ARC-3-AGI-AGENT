from pathlib import Path
import json,hashlib
R=Path('/workspace/scratch/a94ff513b3af/arc-column-goalset-prepsave-learning-20261013')
def ref(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n')
s=(R/'source/prepsave_harness_v1.py').read_text().replace("for run in audit_actual['runs']:","for run in [audit_actual]:")
s=s.replace('normal4713','normal4775').replace('Teach4 only','Teach50 only').replace('all62 query whole','all112 query whole').replace('exactTeach4 Query62','exactTeach50 Query112')
s=s.replace("t['original_score'].get('comparison_kind')","t['original_score'].get('original_comparison_kind')")
# Remove tautological all117 assertion; compare every saved measurement to the pinned analysis in original order.
s=s.replace("if self.pack['all117']!=[dict(p)for p in self.pack['all117']]or len(self.pack['all117'])!=117:raise ValueError('all117')", "if len(self.pack['all117'])!=117 or [r['measurement']for r in self.pack['all117']]!=a['all117_before_and_all_after_measurements']:raise ValueError('all117 original measurement join')")
p=R/'source/prepsave_harness_v2.py';p.write_text(s)
c=json.loads((R/'source/prepsave_contract_v1.json').read_bytes());c['source']=ref(p);save(R/'source/prepsave_contract_v2.json',c)
g=json.loads((R/'source/root_prepsave_release_disabled_v1.json').read_bytes());g['source_sha256']=c['source']['sha256'];g['source_contract']=ref(R/'source/prepsave_contract_v2.json');save(R/'source/root_prepsave_release_disabled_v2.json',g)
p=R/'source/prepsave_outer_v2.py';p.write_text((R/'source/prepsave_outer_v1.py').read_text().replace('harness_v1','harness_v2').replace('contract_v1','contract_v2'))
