from pathlib import Path
import json,hashlib
R=Path('/workspace/scratch/a94ff513b3af/arc-column-goalset-prepsave-learning-20261013')
def ref(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def save(p,x):
 with p.open('x')as f:f.write(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n')
s=(R/'source/prepsave_harness_v2.py').read_text()
needle="   e=t['evidence'];r=e['measurement'];phasekey='clicked_inventory_selection_per_phase'if i<20 else'preservation_per_phase'"
replacement=needle+"\n   original=[v for v in a['all117_before_and_all_after_measurements']if v['source']==t['source']and v['row']==t['row']]\n   if len(original)!=1 or not eq(r,original[0]):raise ValueError('teacher exact original analysis measurement')\n   if not r['pool']or not r['empty']or not r['selection_known']or r['before_reasons']:raise ValueError('known before complete nonempty goal/empty/click gate')\n   if i<20:\n    if r['prep_before']is not True or r['selected_before']is not None or t['teacher'][x]is not r['X_inventory']:raise ValueError('preparation before-only feature')\n   else:\n    operation=self.pack['operation_values'][0]if r['selected_before']is None and r['target_kind']=='実在庫'else self.pack['operation_values'][1]if r['selected_before']is not None and r['target_kind']=='実空欄'else None\n    if not r['filled']or r['broad_preservation_before']is not True or t['teacher'][x]!=operation:raise ValueError('narrow operation before-only feature')"
assert needle in s;s=s.replace(needle,replacement)
p=R/'source/prepsave_harness_v3.py';p.write_text(s)
c=json.loads((R/'source/prepsave_contract_v2.json').read_bytes());c['source']=ref(p);save(R/'source/prepsave_contract_v3.json',c)
g=json.loads((R/'source/root_prepsave_release_disabled_v2.json').read_bytes());g['source_sha256']=c['source']['sha256'];g['source_contract']=ref(R/'source/prepsave_contract_v3.json');save(R/'source/root_prepsave_release_disabled_v3.json',g)
p=R/'source/prepsave_outer_v3.py';p.write_text((R/'source/prepsave_outer_v2.py').read_text().replace('harness_v2','harness_v3').replace('contract_v2','contract_v3'))
