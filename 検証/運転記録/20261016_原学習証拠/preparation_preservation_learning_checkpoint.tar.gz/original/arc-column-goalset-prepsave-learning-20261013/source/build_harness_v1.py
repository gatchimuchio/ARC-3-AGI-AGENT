from pathlib import Path
import ast,json,hashlib
B=Path('/workspace/scratch/a94ff513b3af');R=B/'arc-column-goalset-prepsave-learning-20261013';G=B/'arc-column-goalset-learning-20261013'
def ref(p):
 p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def js(x):return json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n'
audit=ref(B/'arc-column-live-loop-20261013/evidence/independent_goalset4_51229802_summary_v1.json');a=json.loads(Path(audit['path']).read_bytes())
refs={'INHERITED':ref(G/'source/goalset_harness_v3.py'),'GUARD':ref(R/'source/prepsave_guard_v1.py'),'PACK':ref(R/'evidence/prepsave_teacher_pack_v2.json'),'PACK_SOURCE':ref(R/'source/build_prepsave_v2.py'),'BASELINE_AUDIT':audit,'BASELINE_AUDIT_TOOLS':ref(B/'arc-column-live-loop-20261013/evidence/independent_goalset4_51229802_actual_tools_v1.json'),'BASELINE_TOOLS':ref(G/'evidence/actual_native_51229802_v1.json'),'BASELINE':a['states'][-1]}
head='''"""Goalset preparation20 and filled preservation30. Native only behind exact root gate.
Unchanged inherited goalset-v3 and work-v3 persistence/raw capture. No native import at module load.
"""
import hashlib,importlib.util,json,lzma,os,resource,signal,sys,time,traceback
from pathlib import Path
B=Path('/workspace/scratch/a94ff513b3af');MIB=1048576
ROOT=B/'arc-column-goalset-prepsave-learning-20261013';OWNER=None
'''
head+='\n'.join(k+'='+repr(v)for k,v in refs.items())+'\n'
head+='''def bootstrap(r,name):
 p=Path(r['path']);raw=p.read_bytes()
 if p.is_symlink()or len(raw)!=r['bytes']or hashlib.sha256(raw).hexdigest()!=r['sha256']:raise ValueError('bootstrap pin')
 sp=importlib.util.spec_from_file_location(name,p);module=importlib.util.module_from_spec(sp);sp.loader.exec_module(module);return module
m=bootstrap(INHERITED,'prepsave_immutable_goalset3');g=bootstrap(GUARD,'prepsave_guard')
b=m.b;eq=m.eq;checked=m.checked;checked_stream=m.checked_stream;packet=m.packet;score=m.score;semantic=m.semantic
# Only the evidence namespace changes; persistence/capture method bodies remain inherited.
m.ROOT=ROOT;m.g=g
class BudgetClock(m.BudgetClock):
 def __init__(self):
  super().__init__();self.remaining={'compute':1200.0,'save':600.0,'failure':120.0}
 def enter(self,mode):
  if self.closing:
   if mode=='compute':self.stop();return
   mode='failure'
  return b.Clock.enter(self,mode)
class Run(m.Run):
 def __init__(self):super().__init__();self.clock=BudgetClock()
 def static_preflight(self,path,digest):
  gate_ref={'path':str(path),'bytes':Path(path).stat().st_size,'sha256':digest};gate=json.loads(checked(gate_ref,65536));self.gate=gate
  if gate.get('schema')!='column-goalset-prepsave-release-v1' or any(gate.get(k)is not True for k in ('enabled','native_authorized','teacher_pack_approved')):raise PermissionError('exact root native release required')
  if gate.get('source_sha256')!=b.sha(__file__)or gate.get('teacher_pack')!=PACK:raise PermissionError('source/material pin')
  if type(gate.get('nonce'))is not str or len(gate['nonce'])!=32 or any(c not in '0123456789abcdef'for c in gate['nonce']):raise ValueError('nonce')
  if time.time()>gate['admission_deadline_epoch']or gate['limits']!={'AS':512*MIB,'compute':1200,'save':600,'failure':120}:raise PermissionError('finite admission')
  checked(gate['source_contract']);checked(INHERITED);checked(GUARD);checked(PACK_SOURCE)
  audit=json.loads(checked(BASELINE_AUDIT));actual=json.loads(checked(BASELINE_TOOLS));audit_actual=json.loads(checked(BASELINE_AUDIT_TOOLS))
  if audit['schema']!='column-goalset4-independent-audit-v1'or audit['status']!='PASS'or audit['errors']or len(audit['verified'])!=6 or any(v is not True for v in audit['verified'].values()):raise ValueError('full independent goalset4 closure')
  if audit['nonce']!='51229802dbf84496a84d401f79e62e1f'or audit['actual_tools']!=BASELINE_TOOLS or audit['actual_exit']!=0 or audit['states'][-1]!=BASELINE:raise ValueError('baseline audited identity')
  if actual['nonce']!=audit['nonce']or actual['actual_exit']!=0 or actual['automatic_retry']is not False:raise ValueError('actual native exit')
  finals=[p for p in actual['polls']if 'exit_code'in p]
  if len(finals)!=1 or finals[0]['exit_code']!=0:raise ValueError('one original native exit')
  lines=finals[0]['output'].splitlines();receipt=json.loads(lines[0])
  if len(lines)!=2 or not lines[1].startswith('UTCEND ')or receipt['status']!='complete'or receipt['Teach']!=4 or receipt['Query']!=62 or receipt['Action']!=0 or receipt['receipt']['file']!=audit['completion']:raise ValueError('actual completion join')
  self.previous_ref=receipt['receipt'];self.previous=packet(self.previous_ref)
  receipts=[]
  for run in audit_actual['runs']:
   for p in run['polls']:
    if p.get('exit_code')==0:
     row=json.loads(p['output'].splitlines()[0])
     if row.get('report')==BASELINE_AUDIT:
      if run['actual_exit']!=0 or row.get('status')!='PASS':raise ValueError('actual independent receipt')
      receipts.append(row)
  if len(receipts)!=1:raise ValueError('unique actual independent exit')
  c=self.previous
  if c['status']!='complete'or c['errors']or c['teach_calls']!=4 or c['query_calls']!=62 or c['regression_pass']is not True or c['paired_counter_after']!=4775 or c['states'][-1]!=BASELINE:raise ValueError('latest133 counter4775')
  self.pack=json.loads(checked(PACK));a=json.loads(checked(self.pack['analysis']))
  if self.pack['schema']!='column-goalset-prepsave-teacher-pack-v1'or self.pack['source']!=PACK_SOURCE:raise ValueError('material schema/source')
  ts=self.pack['teachers'];counts=self.pack['counts']
  if len(ts)!=50 or counts!={'preparation':20,'preservation':30,'all_action_cases':117,'distinct_source_actions':35,'cross_relation_overlap':15,'preparation_after_phases':26,'preservation_after_phases':120,'broad_preservation':33,'unknown_after_HOLD':0}:raise ValueError('exact material counts')
  expected_p=[('PT',n)for n in [2,3,6,8,10,14,15,44,46,48,50,52,55,57]]+[('LS',n)for n in [168,170,172,189,191,192]]
  expected_s=[('PT',n)for n in [6,7,8,9,10,11,15,16,44,45,46,47,48,49,50,51,52,54,55,56,57,58]]+[('LS',n)for n in [168,169,170,171,172,173,189,190]]
  if [(t['source'],t['row'])for t in ts]!=expected_p+expected_s:raise ValueError('original chronology two relations')
  for i,t in enumerate(ts):
   x,y,bd=(self.pack['X'],self.pack['Y'],self.pack['preparation_boundary'])if i<20 else(self.pack['PX'],self.pack['PY'],self.pack['preservation_boundary'])
   if t['boundary']!=bd or list(t['teacher'])!=[x,y]or type(t['teacher'][y])is not bool or (type(t['teacher'][x])is not bool if i<20 else type(t['teacher'][x])is not str or t['teacher'][x]not in self.pack['operation_values']):raise ValueError('exact two native leaves')
   if not eq(t['query_input'],{x:t['teacher'][x]})or not eq(t['expected_output'],{y:t['teacher'][y]})or t['status']!='READY':raise ValueError('before query/strict output/no unknown teacher')
   e=t['evidence'];r=e['measurement'];phasekey='clicked_inventory_selection_per_phase'if i<20 else'preservation_per_phase'
   if e['analysis']!=self.pack['analysis']or e['row']!=t['row']or e['source']!=t['source']or len(r[phasekey])!=r['phases']or any(type(v)is not bool for v in r[phasekey])or t['teacher'][y]is not all(r[phasekey]):raise ValueError('whole after phases')
  if self.pack['all117']!=[dict(p)for p in self.pack['all117']]or len(self.pack['all117'])!=117:raise ValueError('all117')
  for dep in self.pack['source_pins']+self.pack['whole_pool_sources']+[self.pack['raw_source']]:checked_stream(dep)
  for dep in b.DEPENDENCIES:checked(dep,4*MIB)
  checked(BASELINE)
  # Reserve three success states, a fourth failure state, immutable journals and failure payload.
  future=4*8*MIB+16*MIB+MIB
  storage=m.guard('state_trace',future);m.guard('failure',8*MIB)
  if sum(storage['used'].values())+future+8*MIB>128*MIB:raise MemoryError('joint128MiB reservation')
  return {'baseline':BASELINE,'baseline_audit':BASELINE_AUDIT,'material':PACK,'regression_completion':self.previous_ref}
 def preflight(self,path,digest):
  self.static_preflight(path,digest)
  sys.dont_write_bytecode=True;sys.path.insert(0,str(b.CORE))
  import hds学習系統 as native
  import hds学習系統.永続化 as persistence
  if Path(native.__file__).resolve()!=b.CORE/'hds学習系統/__init__.py':raise ValueError('exact native path')
  self.native=native;self.enc=persistence._符号化;self.dec=persistence._復号
  initial=self.dec(json.loads(checked(BASELINE)))
  if initial['識別子状態']['経験']!=133 or len(initial['台帳']['観測台帳'])!=133 or any(initial['識別子状態'][k]!=4775 for k in ('照会','学習判定')):raise ValueError('latest state exact markers')
  self.regression=self.regression_plan();self.prepare_plan()
 def prepare_plan(self):
  ts=self.pack['teachers']
  self.plan=[{'method':'処理する','content':dict(t['teacher']),'boundary':t['boundary'],'origin':{'group':'new_teach','relation':'preparation'if i<20 else'preservation','source':t['source'],'row':t['row'],'evidence':t['evidence']}}for i,t in enumerate(ts)]
  self.plan += [{'method':'照会する','content':dict(t['query_input']),'boundary':t['boundary'],'origin':{'group':'new_query','relation':'preparation'if i<20 else'preservation','source':t['source'],'row':t['row'],'evidence':t['evidence']}}for i,t in enumerate(ts)]
  self.plan += [{'method':'照会する','content':dict(t['query_input']),'boundary':t['boundary'],'origin':{'group':t['group'],'index':t['index'],'original_API':t['API'],'original_comparison_kind':t['original_score'].get('original_comparison_kind')}}for t in self.regression]
  if len(self.plan)!=162:raise ValueError('exact162 plan')
  self.save('material50',self.pack);self.save('original_old62_plan',self.regression);self.save('exact162_call_plan',self.plan)
 def regression_plan(self):
  c=self.previous;queries=packet(c['queries'],self.dec,self.enc);scores=packet(c['scoring'],self.dec,self.enc)
  if len(queries)!=62 or len(scores)!=62:raise ValueError('all62 original')
  api=[x for x in c['api_calls']if x['method']=='照会する']
  if len(api)!=62:raise ValueError('all62 actual API')
  out=[]
  for i,(q,s,a)in enumerate(zip(queries,scores,api)):
   if q['API']!=a or s['API']!=a or q['ordinal']!=i:raise ValueError('old query API identity/order')
   intent=packet(a['intent'],self.dec,self.enc);reply=packet(a['reply'],self.dec,self.enc);e=reply['input']
   if intent['method']!='照会する'or reply['method']!='照会する'or not eq(self.enc(intent['input']),self.enc(e))or not eq(self.enc(q['reply']),self.enc(reply['capture']['return'])):raise ValueError('old full intent/reply join')
   if len(reply['capture']['raw'])!=1 or len(reply['capture']['events'])!=1 or reply['capture']['profile_restored']is not True:raise ValueError('old raw exhaust')
   paths={tuple(p['結果経路'])for p in q['reply'].内容['予測群']}
   if len(paths)!=1 or len(next(iter(paths)))!=1:raise ValueError('old exact output leaf')
   key=next(iter(paths))[0];actual=score(q['reply'],key,s['expected'])
   if any(not eq(actual[k],s[k])for k in actual):raise ValueError('old scoring')
   out.append({'group':'old62_regression','index':i,'boundary':e.対象系境界,'query_input':e.内容,'output_key':key,'expected_output':{key:s['expected']},'original_reply':q['reply'],'original_raw_reply':reply['capture']['raw'],'original_score':s,'API':a})
  return out
'''
source=(G/'source/goalset_harness_v3.py').read_text();tree=ast.parse(source);cls=next(n for n in tree.body if isinstance(n,ast.ClassDef)and n.name=='Run')
for method in ['invoke_next','execute']:
 n=next(n for n in cls.body if isinstance(n,ast.FunctionDef)and n.name==method);s=ast.get_source_segment(source,n)
 s=' '+s.replace('\n','\n ')
 # Existing source has one-space class indentation; normalize source segment continuation.
 s='\n'.join(line[1:]if i and line.startswith('  ')else line for i,line in enumerate(s.splitlines()))
 s=s.replace('66','162').replace('all4_teacher','all50_teacher').replace('all62_query','all112_query').replace('all62_external','all112_external').replace("<62","<112")
 s=s.replace("queries[:4]","queries[:50]").replace("queries[4:]","queries[50:]").replace("score(q['reply'],Y,t['expected_output'][Y])","score(q['reply'],next(iter(t['expected_output'])),next(iter(t['expected_output'].values())))")
 s=s.replace('old129','old133').replace('!=133','!=183').replace('!=4713','!=4775').replace('+=62','+=112')
 s=s.replace("!=4 or sum", "!=50 or sum").replace("!=62:raise", "!=112:raise")
 s=s.replace("'teach_calls':4", "'teach_calls':50").replace("'query_calls':62", "'query_calls':112").replace("'old_regression_queries':58", "'old_regression_queries':62").replace("'new_queries':4", "'new_queries':50").replace("'paired_counter_before':4713", "'paired_counter_before':4775").replace("'paired_counter_after':4775", "'paired_counter_after':4887")
 s=s.replace("'preservation_completion':self.preservation_ref", "'previous_completion':self.previous_ref").replace("'column-goalset-learning-completion-v1'", "'column-goalset-prepsave-completion-v1'")
 s=s.replace("Four original correlated public actions, no phase/alternative-goal independent-support expansion.","Fifty relation teachers over35 distinct public actions with15 overlap; no phase/goal independent support expansion.")
 s=s.replace('Whole old58 actual outputs compared','Whole old62 actual outputs compared')
 s=s.replace("for dep in b.DEPENDENCIES", "for dep in b.DEPENDENCIES")
 s=s.replace('checked(BASE);','checked(INHERITED);')
 head+=s+'\n'
# inherited close_failure retains original schema but exact runtime nonce/artifacts and state; override schema label only via body copy.
n=next(n for n in cls.body if isinstance(n,ast.FunctionDef)and n.name=='close_failure');s=ast.get_source_segment(source,n);s=' '+s.replace('\n','\n ');s='\n'.join(line[1:]if i and line.startswith('  ')else line for i,line in enumerate(s.splitlines()));head+=s.replace('column-goalset-learning-failure-v1','column-goalset-prepsave-failure-v1')+'\n'
n=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='run');s=ast.get_source_segment(source,n).replace("guard();","m.guard();").replace("'Teach':4,'Query':62", "'Teach':50,'Query':112");head+=s+'\n'
p=R/'source/prepsave_harness_v1.py';p.write_text(head)
outer=(G/'source/goalset_outer_v3.py').read_text().replace('goalset_harness_v3.py','prepsave_harness_v1.py').replace('goalset_contract_v3.json','prepsave_contract_v1.json')
(R/'source/prepsave_outer_v1.py').write_text(outer)
contract={'schema':'column-goalset-prepsave-contract-v1','source':ref(p),'inherited':refs['INHERITED'],'guard':refs['GUARD'],'material':refs['PACK'],'material_source':refs['PACK_SOURCE'],'baseline':refs['BASELINE'],'baseline_audit':audit,'limits':{'AS':536870912,'compute':1200,'save':600,'failure':120},'plan':{'Teach':50,'Query':112,'Action':0,'new_clear':0,'experience_before':133,'experience_after_if_complete':183,'counter_before':4775,'counter_after_if_complete':4887},'native_executed':False}
(R/'source/prepsave_contract_v1.json').write_text(js(contract))
gate={'schema':'column-goalset-prepsave-release-v1','enabled':False,'native_authorized':False,'teacher_pack_approved':False,'source_sha256':contract['source']['sha256'],'teacher_pack':refs['PACK'],'nonce':'0'*32,'admission_deadline_epoch':0,'limits':contract['limits'],'source_contract':ref(R/'source/prepsave_contract_v1.json')}
(R/'source/root_prepsave_release_disabled_v1.json').write_text(js(gate))
print(js(contract))
