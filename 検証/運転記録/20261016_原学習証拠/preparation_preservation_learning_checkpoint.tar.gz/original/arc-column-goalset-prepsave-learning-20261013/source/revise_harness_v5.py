from pathlib import Path
import json,hashlib
R=Path('/workspace/scratch/a94ff513b3af/arc-column-goalset-prepsave-learning-20261013')
def ref(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def save(p,x):
 with p.open('x')as f:f.write(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n')
s=(R/'source/prepsave_harness_v4.py').read_text()
s=s.replace("storage=m.guard('state_trace',future);m.guard('failure',8*MIB)","storage=m.guard('state_trace',future);m.guard('failure',6*MIB)")
s=s.replace("sum(storage['used'].values())+future+8*MIB", "sum(storage['used'].values())+future+6*MIB")
# The inherited serializer remains unchanged. Add an outer prospective payload check only for failure.
needle=" def static_preflight(self,path,digest):"
insert=""" def save(self,name,value,category='state_trace',codec=True):
  if category=='failure':
   # At most4MiB raw and6MiB XZ for this attempt; retain existing failure history.
   raw=self.encoded(value)if codec else b.jb(value)
   if len(raw)>4*MIB:raise MemoryError('failure raw4MiB')
   blob=lzma.compress(raw,preset=0,check=lzma.CHECK_CRC64)
   if len(blob)>6*MIB:raise MemoryError('failure compressed6MiB reservation')
   del raw,blob
  return super().save(name,value,category,codec)
"""
s=s.replace(needle,insert+needle)
p=R/'source/prepsave_harness_v5.py';p.write_text(s)
c=json.loads((R/'source/prepsave_contract_v4.json').read_bytes());c['source']=ref(p);c['failure_reservation']={'raw_bytes':4*1048576,'compressed_bytes':6*1048576,'total_category_bytes':8*1048576,'existing_history_retained':True,'actual_compressed_size_checked_before_inherited_save':True};save(R/'source/prepsave_contract_v5.json',c)
g=json.loads((R/'source/root_prepsave_release_disabled_v4.json').read_bytes());g['source_sha256']=c['source']['sha256'];g['source_contract']=ref(R/'source/prepsave_contract_v5.json');save(R/'source/root_prepsave_release_disabled_v5.json',g)
p=R/'source/prepsave_outer_v5.py';p.write_text((R/'source/prepsave_outer_v4.py').read_text().replace('harness_v4','harness_v5').replace('contract_v4','contract_v5'))
s=(R/'source/prepsave_harness_pure_v3.py').read_text().replace('prepsave_harness_v4.py','prepsave_harness_v5.py').replace('prepsave_contract_v4.json','prepsave_contract_v5.json').replace('prepsave_harness_pure_v3.json','prepsave_harness_pure_v4.json').replace('6a4a168b0a8cbc8aeedd7001effd9fd8f55180f7be1a7229ae8b65a33d835afb',c['source']['sha256'])
needle=" assert not FORBIDDEN and not any(k.startswith"
extra=""" # Actual retained launch failure and failed_closed packet are present during static admission.
 assert sum(p.stat().st_size for p in (R/'failure').rglob('*')if p.is_file())>0
 passed('existing_failure_history_preflight_admitted_with6MiB_reserve')
 original_guard=m.m.guard
 def nearly_full(category=None,extra=0):
  if category=='failure'and extra+3*m.MIB>8*m.MIB:raise MemoryError('synthetic existing3MiB plus future6MiB exceeds8MiB')
  return original_guard(category,extra)
 m.m.guard=nearly_full
 try:must_reject('existing_failure_fullcap_before_native_refused',lambda:static())
 finally:m.m.guard=original_guard
 # Deterministic adversarial incompressible raw size has substantial6MiB margin.
 import random,lzma,contextlib,io
 raw=random.Random(812).randbytes(4*m.MIB);blob=lzma.compress(raw,preset=0,check=lzma.CHECK_CRC64)
 assert len(blob)<6*m.MIB and lzma.decompress(blob)==raw
 passed('failure4MiB_incompressible_xz_bounded',raw_bytes=len(raw),compressed_bytes=len(blob),reservation=6*m.MIB)
 del raw,blob
 # Check raw and compressed bound rejection before any inherited filesystem write.
 bare=object.__new__(m.Run);bare.enc=enc;bare.dec=dec
 must_reject('failure_raw_over4MiB_rejected',lambda:bare.save('synthetic','x'*(4*m.MIB),'failure',False))
 original_compress=m.lzma.compress
 m.lzma.compress=lambda *a,**k:b'x'*(6*m.MIB+1)
 try:must_reject('failure_compressed_over6MiB_rejected',lambda:bare.save('synthetic',{},'failure',False))
 finally:m.lzma.compress=original_compress
 # Run error path with an inert owner and trap sleep: no native import, persistence or real waiting.
 class RetentionObserved(Exception):pass
 original_run_class=m.Run;original_sleep=m.time.sleep;original_owner=m.OWNER
 for stage in ('raw_capture','normal_state','failure_payload'):
  class IncompleteOwner:
   def __init__(self):
    self.clock=m.BudgetClock();self.machine=object();self.calls=[];self.exceptions=[];self.errors=[];self.gate={};self.terminal=None
   def preflight(self,*a):pass
   def execute(self):raise ValueError('synthetic incomplete '+stage)
   def close_failure(self):raise OSError('synthetic closure missing '+stage)
  m.Run=IncompleteOwner;m.OWNER=None
  m.time.sleep=lambda seconds:(_ for _ in ()).throw(RetentionObserved())
  try:
   with contextlib.redirect_stdout(io.StringIO()):
    try:m.run('synthetic','synthetic')
    except RetentionObserved:pass
    else:raise AssertionError('incomplete live owner exited')
   assert len(m.OWNER.errors)==2 and m.OWNER.terminal is None
   passed('incomplete_'+stage+'_held_not_success_or_closed')
  finally:m.OWNER.clock.stop();m.Run=original_run_class;m.time.sleep=original_sleep;m.OWNER=original_owner
"""
s=s.replace(needle,extra+needle)
(R/'source/prepsave_harness_pure_v4.py').write_text(s)
