"""Pure artifact construction. No native HDS, SDK, or game code execution."""
from pathlib import Path
import json,hashlib,ast,resource
resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912))
B=Path('/workspace/scratch/a94ff513b3af');R=B/'arc-column-goalset-prepsave-learning-20261013';G=B/'arc-column-goalset-learning-20261013'
def ref(p):
 p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def write(name,text):
 p=R/name
 with p.open('x')as f:f.write(text)
 return ref(p)
def js(x):return json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n'
g=(G/'source/goalset_guard_v1.py').read_text().replace('arc-column-goalset-learning-20261013','arc-column-goalset-prepsave-learning-20261013').replace("'evidence':48*M","'evidence':112*M").replace('64*M','128*M').replace('goalset64','prepsave128').replace('3604','3732')
write('source/prepsave_guard_v1.py',g)
A=ref(B/'arc-next-family-audit-20261013/goalset_preparation/goalset_preparation_preservation_analysis_v1.json')
assert A['bytes']==358669 and A['sha256']=='a86fb6da4582d5e8db24032cef2fa8f1a661fe55ca48ca2e8643a9ef5faffd85'
X='実クリック対象は利用可能な在庫対象である';Y='応答全相で実クリック在庫対象が選択表示された'
PX='実操作種別';PY='応答全相で操作前の全充填枠が保存された'
PB='公開列図式・成立可能目標集合非空・可視在庫未選択・既学習クリック作用の在庫選択準備'
SB='公開列図式・成立可能目標集合非空・既充填枠非空・未選択実在庫または選択済実空欄クリックの全相充填保存'
VALUES=['可視在庫未選択時の実在庫クリック','可視在庫選択時の実空欄クリック']
a=json.loads(Path(A['path']).read_bytes());allrows=[];prep=[];pres=[]
for r in a['all117_before_and_all_after_measurements']:
 assert type(r['prep_before'])is bool and type(r['broad_preservation_before'])is bool
 reasons=list(r['before_reasons']); pr=list(reasons); sr=list(reasons)
 if not r['pool']:pr.append('before成立可能目標集合が空');sr.append('before成立可能目標集合が空')
 if not r['selection_known']:pr.append('before可視在庫選択UNKNOWN');sr.append('before可視在庫選択UNKNOWN')
 if r['selected_before']is not None:pr.append('before可視在庫選択済み')
 if not r['filled']:sr.append('before既充填枠が空で保存支持なし')
 op=VALUES[0]if r['selected_before']is None and r['target_kind']=='実在庫' else VALUES[1]if r['selected_before']is not None and r['target_kind']=='実空欄' else None
 if op is None:sr.append('before実操作が未選択実在庫/選択済実空欄のいずれでもない')
 eligible_p=r['prep_before'];eligible_s=r['broad_preservation_before'] and op is not None
 assert eligible_p==(not pr);assert eligible_s==(not sr)
 evidence={'analysis':A,'source':r['source'],'row':r['row'],'measurement':r,'all_after_phases':r['phases'],'provenance':'同一公開連続記録の相関投影。独立した新規世界経験ではない。'}
 for eligible,out,x,y,bd,value,arr,phases in [(eligible_p,prep,X,Y,PB,r['X_inventory'],None,r['clicked_inventory_selection_per_phase']),(eligible_s,pres,PX,PY,SB,op,None,r['preservation_per_phase'])]:
  if not eligible:continue
  assert len(phases)==r['phases'] and phases
  outcome=all(phases) if all(type(v)is bool for v in phases) else None
  out.append({'source':r['source'],'row':r['row'],'boundary':bd,'teacher':{x:value,y:outcome},'query_input':{x:value},'expected_output':{y:outcome},'evidence':evidence,'status':'READY'if outcome is not None else 'HOLD_UNKNOWN_AFTER'})
 allrows.append({'source':r['source'],'row':r['row'],'measurement':r,'preparation_eligible_before':eligible_p,'preparation_excluded_before':pr,'preservation_eligible_before':eligible_s,'preservation_excluded_before':sr,'broad_preservation_before':r['broad_preservation_before']})
assert len(allrows)==117 and len(prep)==20 and len(pres)==30
assert sum(t['teacher'][X] is True for t in prep)==16 and all(t['expected_output'][PY]is True for t in pres)
assert all(t['status']=='READY'for t in prep+pres)
pack={'schema':'column-goalset-prepsave-teacher-pack-v1','source':ref(__file__),'analysis':A,'X':X,'Y':Y,'PX':PX,'PY':PY,'preparation_boundary':PB,'preservation_boundary':SB,'operation_values':VALUES,'teachers':prep+pres,'all117':allrows,'source_pins':a['source_pins'],'whole_pool_sources':a['whole_pool_sources'],'raw_source':a['raw_source'],'raw_rows_verified':a['raw_rows_verified'],'counts':{'preparation':20,'preservation':30,'all_action_cases':117,'broad_preservation':33,'unknown_after_HOLD':0},'limitations':['No goalexistence predicate is learned: nonempty bijection-pool inventory membership is tautological.','Preservation true is an inductively bounded observed constant, never universal safety.','Filled preservation does not replace feasibility-pool retention learned separately by repair4.','Old unique boundaries remain unchanged. Every eligible unknown after is retained HOLD, never false or excluded.','PT and LS are correlated projections of the same public recording, not fifty independent new world experiences.']}
write('evidence/prepsave_teacher_pack_v1.json',js(pack))
