from pathlib import Path
import hashlib
B=Path('/workspace/scratch/a94ff513b3af');R=B/'arc-column-goalset-prepsave-learning-20261013'
s=(B/'arc-column-goalset-learning-20261013/source/goalset_harness_pure_v3.py').read_text()
s=s.replace("R=B/'arc-column-goalset-learning-20261013'","R=B/'arc-column-goalset-prepsave-learning-20261013'").replace('goalset_harness_v3.py','prepsave_harness_v2.py')
s=s.replace("13ba0f5a514319d221329f2b383a3ba18c24870f4310c9de728300d1d699e775",hashlib.sha256((R/'source/prepsave_harness_v2.py').read_bytes()).hexdigest())
s=s.replace('column-goalset-learning-release-v1','column-goalset-prepsave-release-v1').replace("'compute':600,'save':120","'compute':1200,'save':600,'failure':120").replace('goalset_material_contract_v1.json','prepsave_contract_v2.json').replace("'compute':601,'save':120","'compute':1201,'save':600,'failure':120")
s=s.replace("e.対象系境界!=m.BOUNDARY","e.対象系境界!=t['boundary']")
s=s.replace('self.owner.plan[4+i]','self.owner.plan[50+i]').replace('if i<4:','if i<50:').replace('i-4','i-50').replace('i==4','i==50')
s=s.replace("value=self.owner.pack['teachers'][i]['expected_output'][m.Y]","teacher=self.owner.pack['teachers'][i];key=next(iter(teacher['expected_output']));value=teacher['expected_output'][key]")
s=s.replace("(m.Y,)","(key,)").replace("self.owner.pack['teachers'][i]['teacher'][m.X]","next(iter(teacher['query_input'].values()))")
s=s.replace('self.preservation=template.preservation;self.preservation_ref=template.preservation_ref','self.previous=template.previous;self.previous_ref=template.previous_ref')
start=s.index('# Reuse the actual source');end=s.index('\ndef simulate',start);s=s[:start]+s[end:]
s=s.replace("plan_ns['prepare_exact_plan'](owner)","owner.prepare_plan()")
s=s.replace("[m.X]","[pack['X']]").replace("[m.Y]","[pack['Y']]")
s=s.replace('assert len(plan)==58','assert len(plan)==62')
start=s.index(" assert [sum(x['group']");end=s.index(" run,receipt=simulate",start)
s=s[:start]+" passed('actual_old62_full_type_order_plan',count=62)\n"+s[end:]
s=s.replace('len(run.calls)==66','len(run.calls)==162').replace('teach_count==4','teach_count==50').replace('query_count==62','query_count==112').replace("['経験']==133","['経験']==183").replace('==4775','==4887').replace('all62_query_replies','all112_query_replies').replace('all62_external_scoring','all112_external_scoring').replace('range(66)','range(162)')
s=s.replace('synthetic_Teach=4,synthetic_Query=62','synthetic_Teach=50,synthetic_Query=112').replace('[4713,4775]','[4775,4887]').replace('[129,133]','[133,183]').replace('raw_return_pairs=66','raw_return_pairs=162').replace('API67','API163')
s=s.replace('len(failed.calls)==66','len(failed.calls)==162').replace('completed_synthetic_calls=66','completed_synthetic_calls=162').replace('len(drifted.calls)==66','len(drifted.calls)==162').replace("['failed_scoring_indices']==[4]","['failed_scoring_indices']==[50]").replace("replies'])[4]","replies'])[50]")
s=s.replace('goalset_harness_pure_v3.json','prepsave_harness_pure_v1.json')
(R/'source/prepsave_harness_pure_v1.py').write_text(s)
