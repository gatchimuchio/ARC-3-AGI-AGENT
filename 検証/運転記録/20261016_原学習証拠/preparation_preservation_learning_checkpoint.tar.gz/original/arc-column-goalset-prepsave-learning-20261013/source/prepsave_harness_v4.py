"""Goalset preparation20 and filled preservation30. Native only behind exact root gate.
Unchanged inherited goalset-v3 and work-v3 persistence/raw capture. No native import at module load.
"""
import hashlib,importlib.util,json,lzma,os,resource,signal,sys,time,traceback
from pathlib import Path
B=Path('/workspace/scratch/a94ff513b3af');MIB=1048576
ROOT=B/'arc-column-goalset-prepsave-learning-20261013';OWNER=None
INHERITED={'path': '/workspace/scratch/a94ff513b3af/arc-column-goalset-learning-20261013/source/goalset_harness_v3.py', 'bytes': 22991, 'sha256': '13ba0f5a514319d221329f2b383a3ba18c24870f4310c9de728300d1d699e775'}
GUARD={'path': '/workspace/scratch/a94ff513b3af/arc-column-goalset-prepsave-learning-20261013/source/prepsave_guard_v1.py', 'bytes': 1975, 'sha256': '177df37eb204ae407dac74eee2b80e00c1e9234c0818ebc6a13e46921ddb330c'}
PACK={'path': '/workspace/scratch/a94ff513b3af/arc-column-goalset-prepsave-learning-20261013/evidence/prepsave_teacher_pack_v2.json', 'bytes': 521154, 'sha256': 'bfb31d1318e0f72452baedca2b7855ca6ae028a1c8360fa58b3ec91bc0cea351'}
PACK_SOURCE={'path': '/workspace/scratch/a94ff513b3af/arc-column-goalset-prepsave-learning-20261013/source/build_prepsave_v2.py', 'bytes': 5582, 'sha256': '4b29235435004c7bbbc2c467665c504a8f521f9d337406abb630689ceec1a05f'}
BASELINE_AUDIT={'path': '/workspace/scratch/a94ff513b3af/arc-column-live-loop-20261013/evidence/independent_goalset4_51229802_summary_v1.json', 'bytes': 703907, 'sha256': '35c63b42e175ac5a92e223127c5f308a06e4b92369250de1c2e5b9bacf1c744f'}
BASELINE_AUDIT_TOOLS={'path': '/workspace/scratch/a94ff513b3af/arc-column-live-loop-20261013/evidence/independent_goalset4_51229802_actual_tools_v1.json', 'bytes': 2414, 'sha256': '35907277e8110148d28d42b57e7f34b832f55bfb977935ae4dc2317f9922ef84'}
BASELINE_TOOLS={'path': '/workspace/scratch/a94ff513b3af/arc-column-goalset-learning-20261013/evidence/actual_native_51229802_v1.json', 'bytes': 19004, 'sha256': '669a29b93669fcd2f5975a0a789819a0cbe9e22c2313430f69d0f1f6d21e1149'}
BASELINE={'path': '/workspace/scratch/a94ff513b3af/arc-column-goalset-learning-20261013/evidence/51229802dbf84496a84d401f79e62e1f/after_queries.standard.json', 'bytes': 3765619, 'sha256': '98c3acf28a9d893641135beb29c55b43e6c5d8f3d036e43c25698811f275a0ba'}
def bootstrap(r,name):
 p=Path(r['path']);raw=p.read_bytes()
 if p.is_symlink()or len(raw)!=r['bytes']or hashlib.sha256(raw).hexdigest()!=r['sha256']:raise ValueError('bootstrap pin')
 sp=importlib.util.spec_from_file_location(name,p);module=importlib.util.module_from_spec(sp);sp.loader.exec_module(module);return module
m=bootstrap(INHERITED,'prepsave_immutable_goalset3');g=bootstrap(GUARD,'prepsave_guard')
b=m.b;eq=m.eq;checked=m.checked;checked_stream=m.checked_stream;packet=m.packet;score=m.score;semantic=m.semantic
# Only the evidence namespace changes; persistence/capture method bodies remain inherited.
m.ROOT=ROOT;m.g=g
class BudgetClock(m.BudgetClock):
 def __init__(self):
  super().__init__();self.remaining={'compute':1200.0,'save':600.0,'failure':120.0}
 def enter(self,mode):
  if self.closing:mode='failure'
  return b.Clock.enter(self,mode)
class Run(m.Run):
 def __init__(self):super().__init__();self.clock=BudgetClock()
 def static_preflight(self,path,digest):
  gate_ref={'path':str(path),'bytes':Path(path).stat().st_size,'sha256':digest};gate=json.loads(checked(gate_ref,65536));self.gate=gate
  if gate.get('schema')!='column-goalset-prepsave-release-v1' or any(gate.get(k)is not True for k in ('enabled','native_authorized','teacher_pack_approved')):raise PermissionError('exact root native release required')
  if gate.get('source_sha256')!=b.sha(__file__)or gate.get('teacher_pack')!=PACK:raise PermissionError('source/material pin')
  if type(gate.get('nonce'))is not str or len(gate['nonce'])!=32 or any(c not in '0123456789abcdef'for c in gate['nonce']):raise ValueError('nonce')
  if time.time()>gate['admission_deadline_epoch']or gate['limits']!={'AS':512*MIB,'compute':1200,'save':600,'failure':120}:raise PermissionError('finite admission')
  checked(gate['source_contract']);checked(INHERITED);checked(GUARD);checked(PACK_SOURCE)
  audit=json.loads(checked(BASELINE_AUDIT));actual=json.loads(checked(BASELINE_TOOLS));audit_actual=json.loads(checked(BASELINE_AUDIT_TOOLS))
  if audit['schema']!='column-goalset4-independent-audit-v1'or audit['status']!='PASS'or audit['errors']or len(audit['verified'])!=6 or any(v is not True for v in audit['verified'].values()):raise ValueError('full independent goalset4 closure')
  if audit['nonce']!='51229802dbf84496a84d401f79e62e1f'or audit['actual_tools']!=BASELINE_TOOLS or audit['actual_exit']!=0 or audit['states'][-1]!=BASELINE:raise ValueError('baseline audited identity')
  if actual['nonce']!=audit['nonce']or actual['actual_exit']!=0 or actual['automatic_retry']is not False:raise ValueError('actual native exit')
  finals=[p for p in actual['polls']if 'exit_code'in p]
  if len(finals)!=1 or finals[0]['exit_code']!=0:raise ValueError('one original native exit')
  lines=finals[0]['output'].splitlines();receipt=json.loads(lines[0])
  if len(lines)!=2 or not lines[1].startswith('UTCEND ')or receipt['status']!='complete'or receipt['Teach']!=4 or receipt['Query']!=62 or receipt['Action']!=0 or receipt['receipt']['file']!=audit['completion']:raise ValueError('actual completion join')
  self.previous_ref=receipt['receipt'];self.previous=packet(self.previous_ref)
  receipts=[]
  for run in [audit_actual]:
   for p in run['polls']:
    if p.get('exit_code')==0:
     row=json.loads(p['output'].splitlines()[0])
     if row.get('report')==BASELINE_AUDIT:
      if run['actual_exit']!=0 or row.get('status')!='PASS':raise ValueError('actual independent receipt')
      receipts.append(row)
  if len(receipts)!=1:raise ValueError('unique actual independent exit')
  c=self.previous
  if c['status']!='complete'or c['errors']or c['teach_calls']!=4 or c['query_calls']!=62 or c['regression_pass']is not True or c['paired_counter_after']!=4775 or c['states'][-1]!=BASELINE:raise ValueError('latest133 counter4775')
  self.pack=json.loads(checked(PACK));a=json.loads(checked(self.pack['analysis']))
  if self.pack['schema']!='column-goalset-prepsave-teacher-pack-v1'or self.pack['source']!=PACK_SOURCE:raise ValueError('material schema/source')
  ts=self.pack['teachers'];counts=self.pack['counts']
  if len(ts)!=50 or counts!={'preparation':20,'preservation':30,'all_action_cases':117,'distinct_source_actions':35,'cross_relation_overlap':15,'preparation_after_phases':26,'preservation_after_phases':120,'broad_preservation':33,'unknown_after_HOLD':0}:raise ValueError('exact material counts')
  expected_p=[('PT',n)for n in [2,3,6,8,10,14,15,44,46,48,50,52,55,57]]+[('LS',n)for n in [168,170,172,189,191,192]]
  expected_s=[('PT',n)for n in [6,7,8,9,10,11,15,16,44,45,46,47,48,49,50,51,52,54,55,56,57,58]]+[('LS',n)for n in [168,169,170,171,172,173,189,190]]
  if [(t['source'],t['row'])for t in ts]!=expected_p+expected_s:raise ValueError('original chronology two relations')
  for i,t in enumerate(ts):
   x,y,bd=(self.pack['X'],self.pack['Y'],self.pack['preparation_boundary'])if i<20 else(self.pack['PX'],self.pack['PY'],self.pack['preservation_boundary'])
   if t['boundary']!=bd or list(t['teacher'])!=[x,y]or type(t['teacher'][y])is not bool or (type(t['teacher'][x])is not bool if i<20 else type(t['teacher'][x])is not str or t['teacher'][x]not in self.pack['operation_values']):raise ValueError('exact two native leaves')
   if not eq(t['query_input'],{x:t['teacher'][x]})or not eq(t['expected_output'],{y:t['teacher'][y]})or t['status']!='READY':raise ValueError('before query/strict output/no unknown teacher')
   e=t['evidence'];r=e['measurement'];phasekey='clicked_inventory_selection_per_phase'if i<20 else'preservation_per_phase'
   original=[v for v in a['all117_before_and_all_after_measurements']if v['source']==t['source']and v['row']==t['row']]
   if len(original)!=1 or not eq(r,original[0]):raise ValueError('teacher exact original analysis measurement')
   if not r['pool']or not r['empty']or not r['selection_known']or r['before_reasons']:raise ValueError('known before complete nonempty goal/empty/click gate')
   if i<20:
    if r['prep_before']is not True or r['selected_before']is not None or t['teacher'][x]is not r['X_inventory']:raise ValueError('preparation before-only feature')
   else:
    operation=self.pack['operation_values'][0]if r['selected_before']is None and r['target_kind']=='実在庫'else self.pack['operation_values'][1]if r['selected_before']is not None and r['target_kind']=='実空欄'else None
    if not r['filled']or r['broad_preservation_before']is not True or t['teacher'][x]!=operation:raise ValueError('narrow operation before-only feature')
   if e['analysis']!=self.pack['analysis']or e['row']!=t['row']or e['source']!=t['source']or len(r[phasekey])!=r['phases']or any(type(v)is not bool for v in r[phasekey])or t['teacher'][y]is not all(r[phasekey]):raise ValueError('whole after phases')
  if len(self.pack['all117'])!=117 or [r['measurement']for r in self.pack['all117']]!=a['all117_before_and_all_after_measurements']:raise ValueError('all117 original measurement join')
  for dep in self.pack['source_pins']+self.pack['whole_pool_sources']+[self.pack['raw_source']]:checked_stream(dep)
  for dep in b.DEPENDENCIES:checked(dep,4*MIB)
  checked(BASELINE)
  # Reserve three success states, a fourth failure state, immutable journals and failure payload.
  future=4*8*MIB+16*MIB+MIB
  storage=m.guard('state_trace',future);m.guard('failure',8*MIB)
  if sum(storage['used'].values())+future+8*MIB>128*MIB:raise MemoryError('joint128MiB reservation')
  return {'baseline':BASELINE,'baseline_audit':BASELINE_AUDIT,'material':PACK,'regression_completion':self.previous_ref}
 def preflight(self,path,digest):
  self.static_preflight(path,digest)
  sys.dont_write_bytecode=True;sys.path.insert(0,str(b.CORE))
  import hds学習系統 as native
  import hds学習系統.永続化 as persistence
  if Path(native.__file__).resolve()!=b.CORE/'hds学習系統/__init__.py':raise ValueError('exact native path')
  self.native=native;self.enc=persistence._符号化;self.dec=persistence._復号
  initial=self.dec(json.loads(checked(BASELINE)))
  if initial['識別子状態']['経験']!=133 or len(initial['台帳']['観測台帳'])!=133 or any(initial['識別子状態'][k]!=4775 for k in ('照会','学習判定')):raise ValueError('latest state exact markers')
  self.regression=self.regression_plan();self.prepare_plan()
 def prepare_plan(self):
  ts=self.pack['teachers']
  self.plan=[{'method':'処理する','content':dict(t['teacher']),'boundary':t['boundary'],'origin':{'group':'new_teach','relation':'preparation'if i<20 else'preservation','source':t['source'],'row':t['row'],'evidence':t['evidence']}}for i,t in enumerate(ts)]
  self.plan += [{'method':'照会する','content':dict(t['query_input']),'boundary':t['boundary'],'origin':{'group':'new_query','relation':'preparation'if i<20 else'preservation','source':t['source'],'row':t['row'],'evidence':t['evidence']}}for i,t in enumerate(ts)]
  self.plan += [{'method':'照会する','content':dict(t['query_input']),'boundary':t['boundary'],'origin':{'group':t['group'],'index':t['index'],'original_API':t['API'],'original_comparison_kind':t['original_score'].get('original_comparison_kind')}}for t in self.regression]
  if len(self.plan)!=162:raise ValueError('exact162 plan')
  self.save('material50',self.pack);self.save('original_old62_plan',self.regression);self.save('exact162_call_plan',self.plan)
 def regression_plan(self):
  c=self.previous;queries=packet(c['queries'],self.dec,self.enc);scores=packet(c['scoring'],self.dec,self.enc)
  if len(queries)!=62 or len(scores)!=62:raise ValueError('all62 original')
  api=[x for x in c['api_calls']if x['method']=='照会する']
  if len(api)!=62:raise ValueError('all62 actual API')
  out=[]
  for i,(q,s,a)in enumerate(zip(queries,scores,api)):
   if q['API']!=a or s['API']!=a or q['ordinal']!=i:raise ValueError('old query API identity/order')
   intent=packet(a['intent'],self.dec,self.enc);reply=packet(a['reply'],self.dec,self.enc);e=reply['input']
   if intent['method']!='照会する'or reply['method']!='照会する'or not eq(self.enc(intent['input']),self.enc(e))or not eq(self.enc(q['reply']),self.enc(reply['capture']['return'])):raise ValueError('old full intent/reply join')
   if len(reply['capture']['raw'])!=1 or len(reply['capture']['events'])!=1 or reply['capture']['profile_restored']is not True:raise ValueError('old raw exhaust')
   paths={tuple(p['結果経路'])for p in q['reply'].内容['予測群']}
   if len(paths)!=1 or len(next(iter(paths)))!=1:raise ValueError('old exact output leaf')
   key=next(iter(paths))[0];actual=score(q['reply'],key,s['expected'])
   if any(not eq(actual[k],s[k])for k in actual):raise ValueError('old scoring')
   out.append({'group':'old62_regression','index':i,'boundary':e.対象系境界,'query_input':e.内容,'output_key':key,'expected_output':{key:s['expected']},'original_reply':q['reply'],'original_raw_reply':reply['capture']['raw'],'original_score':s,'API':a})
  return out
 def invoke_next(self):
  i=len(self.calls)
  if not 0<=i<162:raise PermissionError('exact162 API ceiling')
  t=self.plan[i];self.phase=t['origin']['group'];self.frame_ordinal=i
  external=self.native.外部入力(dict(t['content']),t['boundary'])
  self.current={'ordinal':i,'phase':self.phase,'frame_ordinal':i,'method':t['method'],'input':external,'origin':t['origin'],'before':self.markers(),'capture':{}}
  intent=self.save('api_%04d_intent'%i,self.current)
  result=b.capture_call(self.machine,t['method'],external,self.current['capture'])
  self.current['after']=self.markers();reply=self.save('api_%04d_reply'%i,self.current)
  self.calls.append({'ordinal':i,'method':t['method'],'phase':self.phase,'intent':intent,'reply':reply});self.current=None
  return result
 def execute(self):
  self.machine=self.native.HDS学習系統.読み込む(BASELINE['path'])
  initial,old=self.standard('restored_before')
  if initial['bytes']!=BASELINE['bytes'] or initial['sha256']!=BASELINE['sha256']:raise ValueError('byte-identical normal4775 restore')
  teachers=[]
  for t in self.pack['teachers']:
   r=self.invoke_next();teachers.append({'teacher':t,'reply':r,'API':self.calls[-1]})
  tr=self.save('all50_teacher_replies',teachers);trained,learned=self.standard('after_teachers')
  for name,values in old['台帳'].items():
   if not eq(self.enc(learned['台帳'][name][:len(values)]),self.enc(values)):raise ValueError('old133 full ledger prefix')
  if not eq(self.enc(learned['状態履歴'][:len(old['状態履歴'])]),self.enc(old['状態履歴'])):raise ValueError('old full state history prefix')
  for name,values in old['原理履歴'].items():
   if not eq(self.enc(learned['原理履歴'][name][:len(values)]),self.enc(values)):raise ValueError('old principle version prefix')
  if learned['識別子状態']['経験']!=183 or len(learned['台帳']['観測台帳'])!=183 or any(learned['識別子状態'][k]!=4775 for k in ('照会','学習判定')):raise ValueError('Teach50 only exact experience/counters')
  for k in ('最小支持数','最大条件数'):
   if not eq(learned[k],old[k]):raise ValueError('learning configuration unchanged')
  queries=[]
  while len(self.calls)<162:
   r=self.invoke_next();queries.append({'ordinal':len(queries),'origin':self.plan[len(self.calls)-1]['origin'],'reply':r,'API':self.calls[-1]})
  qr=self.save('all112_query_replies',queries);final,last=self.standard('after_queries')
  expected=self.dec(self.enc(learned))
  for k in ('照会','学習判定'):expected['識別子状態'][k]+=112
  if not eq(self.enc(expected),self.enc(last)):raise ValueError('all112 query whole state except paired counters')
  scoring=[]
  for i,(q,t)in enumerate(zip(queries[:50],self.pack['teachers'])):
   s=score(q['reply'],next(iter(t['expected_output'])),next(iter(t['expected_output'].values())));s.update(group='new_query',index=i,row=t['row'],API=q['API']);scoring.append(s)
  for q,t in zip(queries[50:],self.regression):
   s=score(q['reply'],t['output_key'],t['expected_output'][t['output_key']]);s.update(group=t['group'],index=t['index'],API=q['API'],historical_ref=t['API']['reply'],historical_semantics_equal=eq(semantic(q['reply']),semantic(t['original_reply'])),original_score=t['original_score'],original_comparison_kind=t['original_score'].get('original_comparison_kind'));scoring.append(s)
  sr=self.save('all112_external_scoring',scoring)
  bad=[i for i,s in enumerate(scoring)if not s['correct'] or s['wrong'] or s['missing'] or s['extra'] or s['HOLD'] or ('historical_semantics_equal'in s and not s['historical_semantics_equal'])]
  for dep in b.DEPENDENCIES:checked(dep,4*MIB)
  checked(INHERITED);checked(GUARD);checked(PACK);checked(PACK_SOURCE)
  if len(self.calls)!=162 or sum(c['method']=='処理する'for c in self.calls)!=50 or sum(c['method']=='照会する'for c in self.calls)!=112:raise ValueError('exactTeach50 Query112')
  self.summary={'schema':'column-goalset-prepsave-completion-v1','nonce':self.gate['nonce'],'status':'complete' if not bad else 'completed_regression_failed','errors':[],'source':b.ref(Path(__file__)),'source_contract':self.gate['source_contract'],'baseline_state':BASELINE,'baseline_audit':BASELINE_AUDIT,'baseline_audit_actual_tools':BASELINE_AUDIT_TOOLS,'baseline_actual_tools':BASELINE_TOOLS,'material':PACK,'previous_completion':self.previous_ref,'states':self.state_refs,'api_calls':self.calls,'teachers':tr,'queries':qr,'scoring':sr,'teach_calls':50,'query_calls':112,'old_regression_queries':62,'new_queries':50,'Action':0,'new_clear':0,'old133_all_prefixes_unchanged':True,'paired_counter_before':4775,'paired_counter_after':4887,'regression_pass':not bad,'failed_scoring_indices':bad,'limits':'Fifty relation teachers over35 distinct public actions with15 overlap; no phase/goal independent support expansion. Learned leaves only; no universal safety, live Action or new clear claim. Whole old62 actual outputs compared; original historical-versus-saved-rule distinction retained.'}
  result=self.save('completion',self.summary,codec=False);self.complete=True;self.terminal=self.summary['status'];return result
 def close_failure(self):
  self.clock.stop();self.clock.closing=True;self.clock.enter('failure');pending=self.pending;current=self.current
  state=None
  if self.machine is not None:state,_=self.standard('failed_closed_state')
  payload={'schema':'column-goalset-prepsave-failure-v1','nonce':self.gate['nonce'],'status':'failed_closed','errors':self.errors,'current':current,'pending':pending,'completed_api_calls':self.calls,'states':self.state_refs,'normal_state':state,'prior_artifacts':list(self.artifacts),'automatic_retry':False,'limits':'Ordinary HDS state and listed exact API/output evidence saved; arbitrary Python heap/code objects not claimed.'}
  r=self.save('failure',payload,'failure',codec=hasattr(self,'enc'));self.clock.stop();self.terminal='failed_closed';return r
def run(path,digest):
 global OWNER
 if OWNER is not None:raise RuntimeError('one exact run only')
 OWNER=Run()
 try:
  soft,hard=resource.getrlimit(resource.RLIMIT_AS)
  if not(0<soft<=512*MIB and 0<hard<=512*MIB):raise PermissionError('finite AS512 before native import')
  OWNER.clock.enter('compute');m.guard();OWNER.preflight(path,digest);receipt=OWNER.execute();OWNER.clock.stop()
  print(json.dumps({'status':OWNER.terminal,'receipt':receipt,'Teach':50,'Query':112,'Action':0}),flush=True)
  return 0 if OWNER.terminal=='complete' else 1
 except BaseException as exc:
  OWNER.clock.stop();OWNER.exceptions.append(exc);OWNER.errors.append(traceback.format_exc())
  try:
   if OWNER.gate is None:raise RuntimeError('failure before gate')
   receipt=OWNER.close_failure();print(json.dumps({'status':'failed_closed','failure':receipt,'automatic_retry':False}),flush=True);return 1
  except BaseException as secondary:
   OWNER.clock.stop();OWNER.exceptions.append(secondary);OWNER.errors.append(traceback.format_exc())
   print(json.dumps({'status':'failed_held','automatic_retry':False,'errors':OWNER.errors},ensure_ascii=False),flush=True)
   if OWNER.machine is None and not OWNER.calls:return 1
   while True:time.sleep(60)
