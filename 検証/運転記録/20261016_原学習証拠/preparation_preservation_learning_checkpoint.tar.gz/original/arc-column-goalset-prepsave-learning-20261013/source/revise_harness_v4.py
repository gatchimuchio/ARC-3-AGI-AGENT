from pathlib import Path
import json,hashlib
R=Path('/workspace/scratch/a94ff513b3af/arc-column-goalset-prepsave-learning-20261013')
def ref(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def save(p,x):
 with p.open('x')as f:f.write(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n')
s=(R/'source/prepsave_harness_v3.py').read_text().replace("  if self.closing:\n   if mode=='compute':self.stop();return\n   mode='failure'", "  if self.closing:mode='failure'")
s=s.replace("self.clock.stop();self.clock.closing=True;pending=self.pending;current=self.current", "self.clock.stop();self.clock.closing=True;self.clock.enter('failure');pending=self.pending;current=self.current")
p=R/'source/prepsave_harness_v4.py';p.write_text(s)
c=json.loads((R/'source/prepsave_contract_v3.json').read_bytes());c['source']=ref(p);save(R/'source/prepsave_contract_v4.json',c)
g=json.loads((R/'source/root_prepsave_release_disabled_v3.json').read_bytes());g['source_sha256']=c['source']['sha256'];g['source_contract']=ref(R/'source/prepsave_contract_v4.json');save(R/'source/root_prepsave_release_disabled_v4.json',g)
p=R/'source/prepsave_outer_v4.py';p.write_text((R/'source/prepsave_outer_v3.py').read_text().replace('harness_v3','harness_v4').replace('contract_v3','contract_v4'))
s=(R/'source/prepsave_harness_pure_v2.py').read_text().replace('prepsave_harness_v3.py','prepsave_harness_v4.py').replace('prepsave_contract_v3.json','prepsave_contract_v4.json').replace('prepsave_harness_pure_v2.json','prepsave_harness_pure_v3.json').replace('b5698d2d14c4a761f3605da36b2c753263ac2668cb58fa741ff1c1c75782e166',c['source']['sha256'])
needle=" assert not FORBIDDEN and not any(k.startswith"
s=s.replace(needle," clock=m.BudgetClock();clock.closing=True;clock.enter('failure');assert clock.mode=='failure'\n clock.enter('compute');assert clock.mode=='failure'\n clock.enter('save');assert clock.mode=='failure'\n clock.stop();passed('continuous_failure_timer_across_all_closing_modes',aggregate_seconds=120)\n"+needle)
(R/'source/prepsave_harness_pure_v3.py').write_text(s)
