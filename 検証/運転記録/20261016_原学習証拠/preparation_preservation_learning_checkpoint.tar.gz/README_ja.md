# ARC3 目標条件から逆算する準備・保存学習 checkpoint

## 目的
明確なクリア条件から必要状態と操作を逆算するため、準備操作と既充填枠の保存を分離し、既存HDSに限定範囲の関係を学習させた履歴を保存する。HDS中核・権限・現在状態は変更しない。本梱包は既存証拠の保存のみで、native/SDK/API/Actionを再実行していない。

## 観測・previous / current / delta
- 対象native実行: b6752d29848b4a86990c441935ae5363。Teach 50、Query 112、Action 0、新規clear 0。
- 経験数133 → 183（+50）、照会・学習判定counter4775 → 4887（各+112）。183は学習経験数であり、攻略level数ではない。
- 50教師は準備20・保存30。元の公開Actionは35種類、関係間重複15。50独立試行ではない。準備の応答26相、保存120相を保持。
- 原理13 → 16。原理14/15 v1の支持は経験134–136、原理16 v1は154–156。後続経験・候補支持をv1の固定支持へ水増ししない。
- 新規準備20、新規保存30、旧62の照会は全件正答。wrong/missing/extra/HOLDはいずれも0。旧62は出力の8意味項目まで比較。教師途中の「接続途上」やHOLD理由も原応答に保持。
根拠: `original/arc-column-goalset-prepsave-learning-20261013/evidence/b6752d29848b4a86990c441935ae5363/completion.json.xz`、`original/arc-column-goalset-prepsave-learning-20261013/evidence/native_b6752d_readback_v1.json`、`original/arc-column-live-loop-20261013/evidence/independent_prepsave_b6752d29_summary_v1.json`。

## 操作分類・成立した関係
1. 準備: 公開列図式・成立可能目標集合が非空・可視在庫が未選択・既学習クリック作用の範囲。「実クリック対象が利用可能な在庫対象」↔「応答全相でその在庫対象が選択表示」。原理14は順方向、15は逆方向。
2. 保存: 上記公開図式と目標集合に加え、操作前の既充填枠が非空。「可視在庫未選択時の実在庫クリック」または「可視在庫選択時の実空欄クリック」で、操作前の全充填枠が応答全相に保存された。原理16は観測した2操作種別に限る。
3. 範囲外・反例: 狭い保存範囲では反例未観測。広い保存条件や範囲外の否定例を消さず、普遍的安全性へ拡張しない。充填対象の選択、目標集合の列挙、全体攻略の成立は、この関係学習だけで保証されない。
根拠: `original/arc-column-goalset-prepsave-learning-20261013/evidence/prepsave_teacher_pack_v2.json` の境界・operation_values・all117、監査summaryのchanged_principles/new_ledger_entries/limitations。

## 原因・変更
必要だったのは、目標に向けた準備操作と、すでに成立した条件を壊さない操作を、公開観測の前後関係として明確に分けること。関係教師は各2葉に限定し、照会には操作前に得られる葉だけを渡す。原理・支持・反証・候補・隔離と全応答を保存する。
前段の2起動失敗も保存した。最初はFileNotFoundError、次は既存失敗履歴に全8MiBを追加予約しfailure上限8MiBを超えるpreflight設計不備。native開始前に閉じた失敗で、HDS欠陥ではない。v5は履歴を保ち、raw4MiB/compressed6MiBと将来予約6MiBに限定。失敗nonceは再使用せず、新nonceで上記実行が完了した。
根拠: `original/arc-column-goalset-prepsave-learning-20261013/failure/actual_launch_failure_ccd893ba_v1.json`、`original/arc-column-goalset-prepsave-learning-20261013/evidence/actual_native_ccd893ba_v1.json`、`original/arc-column-goalset-prepsave-learning-20261013/evidence/failed_ccd893ba_readback_v1.json`、`original/arc-column-goalset-prepsave-learning-20261013/source/prepsave_harness_v4_v5.diff`、`original/arc-column-goalset-prepsave-learning-20261013/source/prepsave_contract_v5.json`。

## 由来の分離
- 固定側: 公開観測の特徴抽出、成立可能目標集合の探索・射影、操作分類、教師の選別・整形、期待値採点。これらをnative実学習の成果とは呼ばない。
- native学習側: 2葉の関係経験を既存HDSへ入力し、原理14/15/16・経験台帳・候補台帳・支持/反証/隔離を実際に出力した部分。
- pure fixture側: 契約・入力型・呼出上限・保存・失敗系を模擬した検査。fake162呼出を実native件数に加えない。
- 独立監査側: 保存済み全162呼出と状態を読み、外部codecと純粋射影で照合した。監査はnative/API/Action 0。監査v2/v3の失敗も残し、v4のactual exit0/PASSを区別する。
根拠: source全版、`original/arc-column-goalset-prepsave-learning-20261013/evidence/prepsave_harness_pure_v4.json`、`original/arc-column-goalset-prepsave-learning-20261013/evidence/prepsave_pure_actual_tools_v3.json`、`original/arc-column-live-loop-20261013/evidence/independent_prepsave_b6752d29_actual_tools_v1.json`。

## 回帰・限界・時点
旧133経験prefixを保持し、Query後は対応する2counterのみ変化した。50新規照会と62旧照会の成立は保存範囲の関係検証であり、未見転用・runtime改善・新しいlevel成功を実証していない。
このcheckpointはcounter4887時点の歴史資料。後続保存観測診断は993照会で5880へ進んだが、118観測のうち59完了・59未処理のfailed-heldで、診断完了ではない。この梱包を現在のruntime gateとして使わない。
認証済みfresh達成は親確認で1/183。後続失敗runの部分的6level観測を認証件数へ追加しない。1level根拠と後続診断根拠は同梱外の`context_refs.json`に正確なFileRefを記した。
mainは親の2026-10-13 23:07 UTC GitHub照合による9ce1830494bb80f5d820fbad61ca9096954a04c6。本梱包によるGit変更なし。Git書込はOwner許可待ち。

## 証拠・検証・利用方法
原本source/pure/actual-tools/失敗全版、native全intent/reply・3状態・completion、独立監査のsource/失敗/actual-toolsをバイト単位で同梱した。原本の絶対pathは由来として保持し、移動後は`inputs_manifest.json`のpackage_pathへ対応付ける。原本の参照を書き換えていない。
全原本FileRef（path/bytes/SHA-256）は`inputs_manifest.json`、外部依存FileRefは`dependency_refs.json`。HDS依存は再hash一致。巨大公開corpusとopaqueゲーム実装は複製・閲覧していない。依存全体を同梱した実行環境ではないため、そのまま実行する許可や完全自己完結性は意味しない。
`manifest.json`は同梱payload全ファイルのbytes/SHA-256を列挙し、`manifest.sha256`がmanifest自身を固定する。`archive_verification.json`は全tar memberの数・bytes/hash、gzip CRC/EOF、全xz packetの完全復号とEOF、資源guardを検証した結果。検証報告自身とarchiveは自己参照回避のためpayload manifest外、`delivery_manifest.json`で個別FileRefを固定する。
