"""One OFFLINE constructor RESET; public observation only. Root release required."""
import resource
resource.setrlimit(resource.RLIMIT_AS, (1024 ** 3, 1024 ** 3))
import base64
import hashlib
import json
import logging
import os
import signal
import stat
import sys
import time
from pathlib import Path

BASE = Path("/workspace/scratch/a94ff513b3af")
SCOPE = BASE / "arc-official-fresh-initial-20261013"
BUNDLES = BASE / "arc-official-bundles-20261013"
SITE = BASE / "arc-sdk-venv/lib/python3.12/site-packages"
CAPS = {"observation": 8 << 20, "prep": 4 << 20, "failure": 4 << 20}
FULL_DISK_FUTURE = (72 + 96 + 4 + 64 + 16) << 20
SDK_FILES = {
    "arc_agi/base.py": "42973618f223096d6269422352980e85bdf6b2b51dcb42e7390f96164b0f994f",
    "arc_agi/local_wrapper.py": "77e0a39f583e148bfc785f933d111ed4d8653d134def55b204dda3064e93bbd2",
    "arc_agi/wrapper.py": "deaf07a628fb2e0f743366de4967110d4c06bafa21c5b61561d9ca02f31055ee",
    "arc_agi/models.py": "b9b00ce1f2280b03b20a9e973c3abab5f5b64595a4bbbe3fa513fe8c36feffbb",
    "arcengine/enums.py": "94ebef48f6fe950a18679a1b991c366e8e28c32ab58c9335f385e19bea21950e",
}
OWNER = {"stage": "created", "exceptions": [], "sdk_events": [], "denials": [],
         "observation": None, "packet": None, "frames": [], "saved": []}
SDK_PHASE = False
WRITE_PHASE = False
NONCE = None
PARALLEL_MEMORY = 4096 << 20
QUARANTINE = []
START = time.monotonic()


class Deadline(BaseException):
    pass


def timeout(signum, frame):
    raise Deadline()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(path):
    s = path.stat()
    return [s.st_dev, s.st_ino, s.st_size, s.st_mode, s.st_mtime_ns, s.st_ctime_ns]


def file_ref(path):
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": sha(raw)}


def exact_ref(ref):
    path = Path(ref["path"])
    raw = path.read_bytes()
    if len(raw) != ref["bytes"] or sha(raw) != ref["sha256"]:
        raise ValueError("FileRef mismatch")
    return raw


def usage():
    result = {}
    for category, cap in CAPS.items():
        folder = SCOPE / category
        n = 0
        if folder.exists():
            for p in folder.rglob("*"):
                if p.is_symlink():
                    raise ValueError("scope symlink")
                if p.is_file():
                    n += p.stat().st_size
        if n > cap:
            raise MemoryError("category cap")
        result[category] = n
    if sum(result.values()) > 16 << 20:
        raise MemoryError("scope cap")
    return result


def admit(category=None, additional=0):
    used = usage()
    if category and used[category] + additional > CAPS[category]:
        raise MemoryError("reserved output cap")
    fs = os.statvfs(SCOPE)
    free = fs.f_bavail * fs.f_frsize
    mem = int(next(line.split()[1] for line in Path("/proc/meminfo").read_text().splitlines()
                   if line.startswith("MemAvailable:"))) * 1024
    if free < (1 << 30) + FULL_DISK_FUTURE:
        raise MemoryError("physical floor")
    # Full own AS plus controller reservation, in addition to free-memory floor.
    if mem < (2 << 30) + PARALLEL_MEMORY:
        raise MemoryError("memory floor")
    return {"usage": used, "disk_free": free, "MemAvailable": mem,
            "full_disk_future": FULL_DISK_FUTURE}


def fsync_dir(path):
    fd = os.open(path, os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def write_new(category, name, raw):
    global WRITE_PHASE
    if Path(name).name != name:
        raise ValueError("output basename")
    admit(category, len(raw))
    path = SCOPE / category / name
    WRITE_PHASE = True
    try:
        with path.open("xb") as f:
            f.write(raw)
            f.flush()
            os.fsync(f.fileno())
        fsync_dir(path.parent)
    finally:
        WRITE_PHASE = False
    back = path.read_bytes()
    if back != raw:
        raise ValueError("full readback")
    ref = {"path": str(path), "bytes": len(raw), "sha256": sha(raw)}
    OWNER["saved"].append(ref)
    return ref


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, separators=(",", ":"), allow_nan=False) + "\n").encode()


def safe_exception(exc):
    # Never stringify exc, inspect args/locals or ask linecache for source.
    positions = []
    tb = exc.__traceback__
    while tb is not None:
        filename = tb.tb_frame.f_code.co_filename
        if filename.startswith(str(SITE / "arc_agi") + "/"):
            positions.append({"sdk_file": str(Path(filename).relative_to(SITE)),
                              "line": tb.tb_lineno})
        tb = tb.tb_next
    return {"type": type(exc).__name__, "sdk_positions": positions,
            "exception_text_omitted": True, "source_lines_and_locals_omitted": True}


class SafeSDKHandler(logging.Handler):
    def emit(self, record):
        # No getMessage/Formatter: f-string exception text in record.msg stays unrendered.
        item = {"level": int(record.levelno)}
        if str(record.pathname).startswith(str(SITE / "arc_agi") + "/"):
            item["sdk_file"] = str(Path(record.pathname).relative_to(SITE))
            item["line"] = int(record.lineno)
        if record.exc_info and isinstance(record.exc_info[1], BaseException):
            exc = record.exc_info[1]
            OWNER["exceptions"].append(exc)
            item["exception"] = safe_exception(exc)
        if len(OWNER["sdk_events"]) >= 1024:
            raise MemoryError("SDK diagnostic count")
        OWNER["sdk_events"].append(item)


def audit_hook(event, args):
    # A Python audit boundary, not a claim of OS sandboxing against native syscalls.
    denied = False
    if event.startswith("socket.") or event in (
        "subprocess.Popen", "os.system", "os.posix_spawn", "os.posix_spawnp",
        "os.fork", "os.forkpty", "os.exec", "pty.spawn"
    ):
        denied = True
    if event == "open":
        path, mode, flags = args
        if isinstance(path, (str, bytes, os.PathLike)):
            p = Path(os.fsdecode(path)).resolve()
            if p.name in (".env", ".env.example"):
                denied = True
            writing = (isinstance(mode, str) and any(c in mode for c in "wax+"))
            writing = writing or (isinstance(flags, int) and bool(flags & (
                os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND)))
            if writing and (not WRITE_PHASE or not p.is_relative_to(SCOPE)):
                denied = True
    if event in ("os.remove", "os.rename", "os.rmdir", "os.link", "os.symlink",
                 "os.truncate", "os.chmod", "os.chown", "os.mkdir"):
        denied = True
    if denied:
        if len(OWNER["denials"]) < 1024:
            OWNER["denials"].append({"event": event, "stage": OWNER["stage"]})
        raise PermissionError("restricted SDK process operation")


def typed(value):
    from enum import Enum
    if isinstance(value, Enum):
        if type(value).__module__ != "arcengine.enums":
            raise TypeError("unknown public enum")
        return {"enum": type(value).__name__, "name": value.name, "value": typed(value.value)}
    if value is None or type(value) in (bool, int, str):
        return value
    if type(value) is float:
        import math
        if not math.isfinite(value):
            raise ValueError("nonfinite public value")
        return {"float": value.hex()}
    if type(value) is list:
        return {"list": [typed(v) for v in value]}
    if type(value) is tuple:
        return {"tuple": [typed(v) for v in value]}
    if type(value) is dict:
        return {"dict": [[typed(k), typed(v)] for k, v in value.items()]}
    raise TypeError("unknown public field type")


def preserve_observation(obs, np):
    fields = list(type(obs).model_fields)
    expected = ["game_id", "state", "levels_completed", "win_levels", "action_input",
                "guid", "full_reset", "available_actions"]
    if fields != expected:
        raise ValueError("public model schema changed")
    model = obs.model_dump(mode="python", round_trip=True, exclude_none=False)
    if list(model) != fields:
        raise ValueError("public model fields missing")
    packet = {"schema": "official-fresh-public-observation-v1", "nonce": NONCE,
              "model_class": "arcengine.FrameDataRaw", "model_field_order": fields,
              "model_python_typed": typed(model),
              "model_json": obs.model_dump(mode="json", round_trip=True, exclude_none=False),
              "frame_count": len(obs.frame), "frames": []}
    OWNER["packet"] = packet
    if len(json_bytes(packet)) > 1 << 20:
        raise MemoryError("public model metadata cap")
    if not isinstance(obs.frame, list) or not obs.frame:
        raise ValueError("missing public frames")
    for index, a in enumerate(obs.frame):
        if type(a) is not np.ndarray:
            raise TypeError("unknown public frame type")
        if a.dtype.hasobject or a.dtype.fields is not None or a.dtype.subdtype is not None:
            raise TypeError("unsupported public frame dtype")
        if a.dtype.kind not in "biuf":
            raise TypeError("unknown public frame dtype")
        if a.nbytes > 4 << 20:
            raise MemoryError("single public frame raw cap")
        if sum(f["bytes"] for f in packet["frames"]) + a.nbytes > 4 << 20:
            raise MemoryError("aggregate public frame raw cap")
        raw = a.tobytes(order="C")
        item = {"ordinal": index, "dtype": a.dtype.str, "shape": list(a.shape),
                "strides": list(a.strides), "source_C_contiguous": bool(a.flags.c_contiguous),
                "source_F_contiguous": bool(a.flags.f_contiguous),
                "order": "C", "bytes": len(raw), "sha256": sha(raw),
                "base64": base64.b64encode(raw).decode("ascii")}
        packet["frames"].append(item)
        OWNER["frames"].append(a)
        if sum(f["bytes"] for f in packet["frames"]) > 4 << 20:
            raise MemoryError("aggregate public frame raw cap")
    return packet


def verify_packet(raw, obs, np):
    packet = json.loads(raw)
    if packet["model_python_typed"] != typed(obs.model_dump(mode="python", round_trip=True, exclude_none=False)):
        raise ValueError("public model roundtrip")
    if packet["model_json"] != obs.model_dump(mode="json", round_trip=True, exclude_none=False):
        raise ValueError("public JSON model roundtrip")
    if len(packet["frames"]) != len(obs.frame):
        raise ValueError("frame coverage")
    for item, a in zip(packet["frames"], obs.frame):
        b = base64.b64decode(item["base64"], validate=True)
        if sha(b) != item["sha256"] or len(b) != item["bytes"]:
            raise ValueError("frame hash")
        restored = np.frombuffer(b, dtype=np.dtype(item["dtype"])).reshape(item["shape"], order="C")
        if restored.dtype != a.dtype or restored.shape != a.shape or restored.tobytes(order="C") != a.tobytes(order="C"):
            raise ValueError("public frame roundtrip")
    if json_bytes(packet) != raw:
        raise ValueError("canonical full type/order roundtrip")


def main():
    global NONCE, SDK_PHASE, WRITE_PHASE, PARALLEL_MEMORY
    signal.signal(signal.SIGALRM, timeout)
    signal.setitimer(signal.ITIMER_REAL, 120)
    gate_path = Path(sys.argv[1]).resolve()
    gate_raw = gate_path.read_bytes()
    if sha(gate_raw) != sys.argv[2] or gate_path.parent != SCOPE / "prep":
        raise ValueError("gate identity")
    gate = json.loads(gate_raw)
    if gate["schema"] != "official-fresh-initial-release-v1" or gate["enabled"] is not True:
        raise ValueError("gate release")
    if gate["limits"] != {"AS": 1073741824, "compute_seconds": 120, "save_seconds": 120}:
        raise ValueError("gate limits")
    if gate["game_id"] != "ar25-0c556536" or type(gate["seed"]) is not int or gate["seed"] != 0:
        raise ValueError("initial audit index/seed")
    if gate["parallel_memory_reserve_bytes"] != 4096 << 20:
        raise ValueError("full parallel RAM reservation")
    NONCE = gate["nonce"]
    if len(NONCE) != 32 or any(c not in "0123456789abcdef" for c in NONCE):
        raise ValueError("nonce")
    if exact_ref(gate["source"]) != Path(__file__).read_bytes():
        raise ValueError("source binding")
    contract = json.loads(exact_ref(gate["contract"]))
    for key in ("bundle_receipt", "bundle_results", "bundle_audit", "metadata"):
        exact_ref(gate[key])
    if gate["bundle_receipt"]["sha256"] != contract["bundle_receipt"]["sha256"] or gate["bundle_results"]["sha256"] != contract["bundle_results"]["sha256"]:
        raise ValueError("bundle contract binding")
    if gate["bundle_audit"]["sha256"] != "403ab3664d99ae1abfe1476ea1741691bb741849895fe35e40b2f7ec24b6f6e7":
        raise ValueError("independent audit pin")
    bundle_audit = json.loads(exact_ref(gate["bundle_audit"]))
    if bundle_audit["schema"] != "official-bundles-independent-audit-v1" or bundle_audit["status"] != "PASS" or bundle_audit["errors"]:
        raise ValueError("bundle independent PASS required")
    if not all(v is True for v in bundle_audit["verified"].values()):
        raise ValueError("bundle verification flags")
    if bundle_audit["all_targets"][0]["metadata"] != gate["metadata"]:
        raise ValueError("index zero metadata join")
    for name, h in SDK_FILES.items():
        if sha((SITE / name).read_bytes()) != h:
            raise ValueError("SDK source pin")
    meta = json.loads(exact_ref(gate["metadata"]))
    if gate["metadata"]["sha256"] != "fdf76cbac6f874778836a1e33f11a5950dbb2224c0432601a842986cb7f2aa32":
        raise ValueError("first public metadata pin")
    if meta["game_id"] != gate["game_id"]:
        raise ValueError("metadata target")
    # No game source read/hash here; the independently audited opaque bundle pins are evidence.
    for name in ("work", "home", "cache", "tmp", "sdk_recordings"):
        (SCOPE / "prep" / name).mkdir(exist_ok=False)
    allowed_env = {
        "PATH": str(BASE / "arc-sdk-venv/bin") + ":/usr/bin:/bin",
        "HOME": str(SCOPE / "prep/home"), "TMPDIR": str(SCOPE / "prep/tmp"),
        "XDG_CACHE_HOME": str(SCOPE / "prep/cache"), "MPLCONFIGDIR": str(SCOPE / "prep/cache"),
        "LANG": "C.UTF-8", "LC_ALL": "C.UTF-8", "PYTHONDONTWRITEBYTECODE": "1",
        "OPENBLAS_NUM_THREADS": "1", "OMP_NUM_THREADS": "1", "MKL_NUM_THREADS": "1",
        "NUMEXPR_NUM_THREADS": "1", "VECLIB_MAXIMUM_THREADS": "1",
        "BLIS_NUM_THREADS": "1", "OPERATION_MODE": "offline"
    }
    os.environ.clear()
    os.environ.update(allowed_env)
    sys.dont_write_bytecode = True
    os.chdir(SCOPE / "prep/work")
    admit()
    # Redirect even native/C print paths. Payload stays opaque and is never printed/read as text.
    saved_fds = [os.dup(1), os.dup(2)]
    for number, name in ((1, "stdout"), (2, "stderr")):
        p = SCOPE / "prep" / (NONCE + "_" + name + ".opaque")
        fd = os.open(p, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        os.dup2(fd, number)
        os.close(fd)
        QUARANTINE.append(p)
    resource.setrlimit(resource.RLIMIT_FSIZE, (1 << 20, 8 << 20))
    signal.signal(signal.SIGALRM, timeout)
    signal.signal(signal.SIGXFSZ, timeout)
    handler = SafeSDKHandler()
    logging.disable(logging.NOTSET)
    root_logger = logging.getLogger()
    root_logger.handlers[:] = [handler]
    root_logger.setLevel(logging.ERROR)
    sdk_logger = logging.getLogger("fresh-initial-sdk")
    sdk_logger.handlers[:] = [handler]
    sdk_logger.propagate = False
    sdk_logger.setLevel(logging.ERROR)
    sys.addaudithook(audit_hook)
    error = None
    np = None
    try:
        OWNER["stage"] = "SDK_import"
        SDK_PHASE = True
        import numpy as np
        from arc_agi import Arcade, OperationMode
        from arcengine import FrameDataRaw
        OWNER["stage"] = "constructor_make"
        arcade = Arcade(arc_api_key="", operation_mode=OperationMode.OFFLINE,
                        environments_dir=str(BUNDLES / "environment_files"),
                        recordings_dir=str(SCOPE / "prep/sdk_recordings"), logger=sdk_logger)
        OWNER["arcade"] = arcade
        if arcade.operation_mode != OperationMode.OFFLINE or arcade.arc_api_key != "":
            raise ValueError("offline empty credential")
        env = arcade.make(gate["game_id"], seed=0, save_recording=False,
                          include_frame_data=True, render_mode=None, renderer=None)
        OWNER["environment"] = env
        if env is None:
            raise ValueError("make returned None")
        obs = env.observation_space
        OWNER["observation"] = obs
        if type(obs) is not FrameDataRaw or obs.is_empty():
            raise ValueError("public observation absent")
        if OWNER["sdk_events"] or OWNER["denials"]:
            raise ValueError("SDK error or denied operation")
        OWNER["stage"] = "public_projection"
        preserve_observation(obs, np)
    except BaseException as exc:
        OWNER["exceptions"].append(exc)
        error = safe_exception(exc)
    finally:
        SDK_PHASE = False
        signal.setitimer(signal.ITIMER_REAL, 120)
        resource.setrlimit(resource.RLIMIT_FSIZE, (8 << 20, 8 << 20))
        for target, saved in zip((1, 2), saved_fds):
            try:
                os.fsync(target)
            except OSError:
                pass
            os.dup2(saved, target)
            os.close(saved)
    OWNER["stage"] = "save"
    opaque_refs = [file_ref(p) for p in QUARANTINE]
    for p in QUARANTINE:
        fsync_dir(p.parent)
    try:
        if error is not None:
            raise RuntimeError("recorded SDK failure")
        raw = json_bytes(OWNER["packet"])
        if len(raw) > 8 << 20:
            raise MemoryError("observation category cap")
        verify_packet(raw, OWNER["observation"], np)
        ref = write_new("observation", NONCE + ".public.json", raw)
        verify_packet(exact_ref(ref), OWNER["observation"], np)
        result = {"schema": "official-fresh-initial-receipt-v1", "nonce": NONCE,
                  "status": "PASS", "public_observation": ref,
                  "frame_count": len(OWNER["packet"]["frames"]), "sdk_versions": contract["sdk_versions"],
                  "source": gate["source"], "gate": file_ref(gate_path),
                  "metadata": gate["metadata"], "bundle_audit": gate["bundle_audit"],
                  "opaque_output_refs": opaque_refs, "errors": [], "denials": [],
                  "make_calls": 1, "constructor_reset_calls_expected_by_pinned_sdk": 1,
                  "additional_reset_calls": 0, "ordinary_action_calls": 0, "HDS_calls": 0,
                  "all_public_fields_and_frames_readback": True,
                  "heap_alias_claim": False, "runtime_solver_adoption": False,
                  "elapsed_seconds": time.monotonic() - START}
        receipt = write_new("prep", NONCE + ".receipt.json", json_bytes(result))
        signal.setitimer(signal.ITIMER_REAL, 0)
        print(json.dumps({"status": "PASS", "receipt": receipt}, separators=(",", ":")), flush=True)
        return 0
    except BaseException as exc:
        OWNER["exceptions"].append(exc)
        prefix_ref = None
        prefix_save_error = None
        if OWNER["packet"] is not None:
            try:
                prefix_raw = json_bytes(OWNER["packet"])
                prefix_ref = write_new("observation", NONCE + ".partial-public.json", prefix_raw)
            except BaseException as prefix_exc:
                OWNER["exceptions"].append(prefix_exc)
                prefix_save_error = safe_exception(prefix_exc)
        diagnostics = {"schema": "official-fresh-initial-failure-v1", "nonce": NONCE,
                       "status": "FAIL", "first_error": error,
                       "save_error": safe_exception(exc), "sdk_events": OWNER["sdk_events"],
                       "denials": OWNER["denials"], "saved": OWNER["saved"],
                       "opaque_output_refs": opaque_refs,
                       "public_projection_completed_prefix": prefix_ref,
                       "prefix_save_error": prefix_save_error,
                       "public_observation_complete": False,
                       "source_lines_locals_exception_text_saved": False}
        raw = json_bytes(diagnostics)
        ref = write_new("failure", NONCE + ".failure.json", raw)
        signal.setitimer(signal.ITIMER_REAL, 0)
        print(json.dumps({"status": "FAIL", "failure": ref}, separators=(",", ":")), flush=True)
        return 1


if __name__ == "__main__":
    try:
        code = main()
    except BaseException as exc:
        # No default traceback: it might include executable bundle source/exception text.
        OWNER["exceptions"].append(exc)
        signal.setitimer(signal.ITIMER_REAL, 0)
        summary = {"status": "FAIL", "failure_record_complete": False,
                   "stage": OWNER["stage"], "exception": safe_exception(exc)}
        # Source-less fixed diagnostics only. No unbounded sleep or automatic retry.
        try:
            ref = write_new("failure", "outer_" + str(time.time_ns()) + ".json", json_bytes(summary))
            summary["failure_ref"] = ref
        except BaseException:
            summary["failure_persistence_failed"] = True
        print(json.dumps(summary, separators=(",", ":")), flush=True)
        code = 1
    raise SystemExit(code)
