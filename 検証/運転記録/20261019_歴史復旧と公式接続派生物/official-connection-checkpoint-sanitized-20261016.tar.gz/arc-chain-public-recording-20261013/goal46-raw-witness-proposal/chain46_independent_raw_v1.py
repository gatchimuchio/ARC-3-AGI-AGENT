"""Independent source-only raw inventory auditor. No candidate import, HDS or SDK.
Only the pinned three existing perception functions are compiled after an execution gate.
Independent expected values are rebuilt from original raw rows; saved summaries are not truth.
"""
import ast,collections,hashlib,itertools,json,lzma,math,os,re,resource,shutil,signal,time,traceback
from pathlib import Path
BASE=Path("/workspace/scratch/a94ff513b3af/arc-chain-public-recording-20261013")
D=BASE/"goal46-raw-witness-proposal"
RAW=BASE/"api_response_v1.body"
OLD=BASE/"goal-reconstruction-source/目標教師46.json"
PRIOR=BASE/"source/画素.py"
CALLER=D/"chain46_all_phase_caller_v4.py"
WITNESS=D/"chain46_raw_witness_v2.py"
PINS={str(RAW):"689b90f7968c96e1a08cd2f8bf73f62a404e03a3b5a1586de9b257034771c4e6",str(OLD):"3b006236552c410fa9c93dc87f134cd58ed393ced413fcf6f504235a2eb38395",str(PRIOR):"b7447f4a849a054daf6ef9834b86ac93dc0972cce93b4d83cceed5c8a091d48e",str(CALLER):"3b30c0ea39be4a3f5c942da0a4083e5facb4e75a73d412f14ffc6f9b6182a906",str(WITNESS):"af3e6100e4ee98d00478a615778576e22140382f67e78e1dd54efaa7d1c89b2e"}
ROWS=(37,38,219,220,733,734,858,859)
FIELDS=("all_eight_raw_rows","all_phases_and_errors","all_candidates_and_multiplicity","full_types_order","scope_unknowns_preserved","old46_not_forced")
OWNER=None
def eq(a,b,path=""):
 if type(a) is not type(b):raise ValueError("type mismatch "+path)
 if isinstance(a,dict):
  eq(list(a),list(b),path+"/keys")
  for k in a:eq(a[k],b[k],path+"/"+str(k))
 elif isinstance(a,list):
  if len(a)!=len(b):raise ValueError("length mismatch "+path)
  for i,(x,y) in enumerate(zip(a,b)):eq(x,y,path+"/"+str(i))
 elif a!=b:raise ValueError("value mismatch "+path)
def encode(x):return json.dumps(x,ensure_ascii=False,separators=(",",":"),allow_nan=False).encode()
def decode(b):
 def pairs(items):
  d={}
  for k,v in items:
   if k in d:raise ValueError("duplicate JSON key")
   d[k]=v
  return d
 return json.loads(b,object_pairs_hook=pairs,parse_constant=lambda s:(_ for _ in ()).throw(ValueError("nonfinite JSON")))
def sha(p):
 h=hashlib.sha256()
 with open(p,"rb") as f:
  for b in iter(lambda:f.read(65536),b""):h.update(b)
 return h.hexdigest()
def ident(p):
 s=p.stat();return [s.st_dev,s.st_ino,s.st_size,s.st_mode,s.st_mtime_ns,s.st_ctime_ns]
def safe(p):
 p=Path(p)
 if not p.is_absolute() or BASE not in p.parents:raise ValueError("outside audit scope")
 for q in (p,*p.parents):
  if q.is_symlink():raise ValueError("symlink refused")
 return p
def reference(p):
 p=safe(p);return {"path":str(p),"bytes":p.stat().st_size,"sha256":sha(p)}
def readref(r,cap):
 if type(r) is not dict or set(r)!={"path","bytes","sha256"}:raise ValueError("FileRef shape")
 p=safe(r["path"])
 if type(r["bytes"]) is not int or not 0<=r["bytes"]<=cap or p.stat().st_size!=r["bytes"]:raise ValueError("FileRef cap")
 b=p.read_bytes()
 if hashlib.sha256(b).hexdigest()!=r["sha256"]:raise ValueError("FileRef SHA")
 OWNER.read_refs.append(r)
 return decode(b)
def guard(extra=0):
 if BASE.is_symlink():raise ValueError("scope symlink")
 used=sum(p.stat().st_size for p in BASE.rglob("*") if p.is_file())
 if used+extra>96*1048576:raise MemoryError("C aggregate cap")
 if shutil.disk_usage(BASE).free<(1024+168)*1048576:raise MemoryError("disk floor/future")
 mem=next(int(z.split()[1])*1024 for z in open("/proc/meminfo") if z.startswith("MemAvailable:"))
 if mem<(2688+2048)*1048576:raise MemoryError("RAM reservation/floor")
 return used
class Clock:
 def __init__(self):
  self.remaining={"compute":3600.0,"save":300.0};self.mode=None;self.start=None
  signal.signal(signal.SIGALRM,self.expire)
 def expire(self,*a):raise TimeoutError("audit active "+str(self.mode))
 def stop(self):
  signal.setitimer(signal.ITIMER_REAL,0)
  if self.mode is not None:self.remaining[self.mode]-=time.monotonic()-self.start
  self.mode=None;self.start=None
 def enter(self,mode):
  self.stop()
  if self.remaining[mode]<=0:raise TimeoutError("audit aggregate "+mode)
  self.mode=mode;self.start=time.monotonic();signal.setitimer(signal.ITIMER_REAL,self.remaining[mode])
class Audit:
 def __init__(self):
  self.clock=Clock();self.gate=None;self.current=None;self.pending=None;self.exceptions=[];self.errors=[]
  self.read_refs=[];self.details=[];self.rows={};self.lines={};self.phase_errors=[];self.functions=None
  self.directory=None;self.written=0;self.complete=False;self.summary=None
  self.verified={k:False for k in FIELDS}
 def save(self,name,value,compressed=True):
  self.pending={"name":name,"value":value};primary=None;self.clock.enter("save")
  try:
   raw=encode(value)
   if len(raw)>8*1048576:raise MemoryError("detail raw8MiB stop")
   blob=lzma.compress(raw,preset=0,check=lzma.CHECK_CRC64) if compressed else raw
   if len(blob)>(512*1024 if compressed else 65536):raise MemoryError("individual audit output stop")
   if self.written+len(blob)>4*1048576-131072:raise MemoryError("audit4MiB tools/failure reserve")
   guard(4*1048576-self.written)
   p=self.directory/name
   with p.open("xb") as f:
    if f.write(blob)!=len(blob):raise OSError("short write")
    f.flush();os.fsync(f.fileno())
   self.written+=len(blob)
   fd=os.open(self.directory,os.O_RDONLY)
   try:os.fsync(fd)
   finally:os.close(fd)
   b=p.read_bytes()
   if b!=blob:raise ValueError("audit saved bytes")
   if compressed:
    z=lzma.LZMADecompressor();back=z.decompress(b,max_length=8*1048576+1)
    if not z.eof or z.unused_data or z.check!=lzma.CHECK_CRC64:raise ValueError("audit CRC64/EOF")
   else:back=b
   if back!=raw:raise ValueError("audit raw roundtrip")
   eq(decode(back),value)
   r=reference(p);self.pending=None
   return {"file":r,"rawbytes":len(raw),"rawsha256":hashlib.sha256(raw).hexdigest()}
  except BaseException as e:
   primary=e;self.exceptions.append(e);raise
  finally:
   self.clock.stop()
   if primary is None:self.clock.enter("compute")
 def load_functions(self):
  raw=PRIOR.read_bytes();tree=ast.parse(raw,filename=str(PRIOR))
  names=("parse","observed_chains","candidates")
  nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
  if tuple(n.name for n in nodes)!=names:raise ValueError("pure function set")
  allowed={"isinstance","list","any","len","type","int","range","set","sum","all","min","max","sorted","abs","enumerate","ValueError"}
  for n in ast.walk(ast.Module(body=nodes,type_ignores=[])):
   if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id not in allowed:raise ValueError("unexpected pure dependency")
  ns={"itertools":itertools,"collections":collections}
  exec(compile(ast.Module(body=nodes,type_ignores=[]),str(PRIOR),"exec"),ns)
  self.functions={k:ns[k] for k in names}
 def scan(self):
  guard(4*1048576)
  before=ident(RAW);h=hashlib.sha256();total=0
  with RAW.open("rb") as f:
   for i,line in enumerate(f):
    h.update(line)
    if i in ROWS:
     if len(line)>2097152:raise MemoryError("raw line stop")
     total+=len(line)
     if total>8388608:raise MemoryError("selected raw stop")
     self.lines[i]=line
     self.rows[i]=decode(line)
  if ident(RAW)!=before or h.hexdigest()!=PINS[str(RAW)] or tuple(self.rows)!=ROWS:raise ValueError("independent raw closure")
  if sum(len(v["data"]["frame"]) for v in self.rows.values())>256:raise MemoryError("phase stop")
  self.source_closure={"identity":before,"sha256":h.hexdigest()}
 def expected_phase(self,frame):
  s=self.functions["parse"](frame);rootn=len(s["根"]);colors=collections.Counter(b["色"] for b in s["珠"])
  work=number=assignmax=0
  for l in s["凡例"]:
   n=math.factorial(len(l["列"]));unique=n
   for count in collections.Counter(l["列"]).values():unique//=math.factorial(count)
   work+=rootn*n;number+=rootn*unique;assignmax+=rootn*unique*math.prod(colors[c] for c in l["列"])
  counts={"permutation_work":work,"distinct_candidates":number,"assignment_product_upper_bound":assignmax}
  if work>100000 or number>16384 or assignmax>65536:raise MemoryError("independent candidate domain stop")
  chains=self.functions["observed_chains"](frame,s);out=[];fixed=iter(self.functions["candidates"](s))
  for ri,r in enumerate(s["根"]):
   for li,l in enumerate(s["凡例"]):
    for si,seq in enumerate(sorted(set(itertools.permutations(l["列"])))):
     seq=list(seq)
     c={"根色":r["色"],"候補列":seq,"凡例根色":l["根"]["色"],"凡例列":l["列"],"特徴":{"根一致":r["色"]==l["根"]["色"],"順序一致":seq==l["列"]}}
     eq(c,next(fixed))
     roots=[x for x in s["根"] if x["色"]==r["色"]]
     legends=[x for x in s["凡例"] if x["根"]["色"]==l["根"]["色"]]
     paths=chains[ri]["候補経路"];options=[[b["対象"] for b in s["珠"] if b["色"]==color] for color in seq]
     assignments=[list(t) for t in itertools.product(*options) if len(set(t))==len(t)]
     reasons=[]
     if s["未対応画素"]:reasons.append("unparsed_pixels")
     if len(roots)!=1:reasons.append("ambiguous_root_binding")
     if len(legends)!=1:reasons.append("ambiguous_legend_binding")
     if len(paths)>1:reasons.append("multiple_observed_paths")
     if not assignments:reasons.append("no_distinct_bead_assignment")
     match=None if reasons else (paths[0]["列"]==seq if paths else seq==[])
     out.append({"ordinal":len(out),"candidate":c,"root_index":ri,"legend_index":li,"sequence_index":si,"bound_root":r,"bound_legend":l,"roots":roots,"legends":legends,"observed_paths":paths,"assignment_options":options,"distinct_assignments":assignments,"joint_before_features":[c["特徴"]["根一致"],c["特徴"]["順序一致"]],"observed_root_sequence_equal":match,"unknown":reasons,"old_teacher_completion_label":None})
  if next(fixed,None) is not None or len(out)!=number:raise ValueError("independent candidate exhaustive count")
  return {"scene":s,"observed_chains":chains,"counts":counts,"witnesses":out,"status":"HOLD" if not out else "measured_candidates","unknown":["zero_candidates"] if not out else [],"binding_limit":"root/legend generation indices identify enumeration origin, not proven correspondence"}
 def check_phase(self,row,index,ref):
  saved=readref(ref,33554432)
  eq(list(saved),["row","phase","raw_reference","result","error"])
  eq(saved["row"],row);eq(saved["phase"],index)
  original=readref(saved["raw_reference"],8388608);line=self.lines[row]
  expectedraw={"row0":row,"line_sha256":hashlib.sha256(line).hexdigest(),"raw_line":line.decode("utf-8"),"value":self.rows[row]}
  eq(original,expectedraw)
  self.current={"row":row,"phase":index,"raw_reference":saved["raw_reference"],"saved_reference":ref,"expected":None,"independent_error":None,"producer_error":saved["error"]}
  try:self.current["expected"]=self.expected_phase(self.rows[row]["data"]["frame"][index])
  except (ValueError,TypeError,IndexError,KeyError,StopIteration) as e:
   self.exceptions.append(e)
   self.current["independent_error"]={"type":type(e).__name__,"message":str(e),"traceback":traceback.format_exc()}
   if saved["result"] is not None or type(saved["error"]) is not dict:raise ValueError("expected phase error absent")
   er=saved["error"];eq(list(er),["type","message","traceback","counts"])
   eq(er["type"],type(e).__name__);eq(er["message"],str(e));eq(er["counts"],None)
   trace=er["traceback"]
   if type(trace) is not str or not trace.startswith("Traceback (most recent call last):\n") or not trace.endswith(type(e).__name__+": "+str(e)+"\n"):raise ValueError("producer full trace shape")
   frames=re.findall(r'  File "([^"]+)", line ([0-9]+), in ([^\n]+)',trace)
   if not frames or frames[0][0]!=str(CALLER) or frames[0][2]!="phase":raise ValueError("trace caller binding")
   for filename,lineno,func in frames:
    if filename not in (str(CALLER),str(WITNESS),str(PRIOR)):raise ValueError("unbound trace frame")
    text=Path(filename).read_text().splitlines()
    if not 1<=int(lineno)<=len(text):raise ValueError("trace line bound")
   if not any(f==str(PRIOR) for f,_,_ in frames):raise ValueError("independent perception trace origin")
   self.phase_errors.append(er)
  else:
   eq(saved["error"],None);eq(saved["result"],self.current["expected"])
  receipt=self.save("phase_%03d_%03d.json.xz"%(row,index),self.current)
  self.details.append(receipt)
  return saved
 def meta(self,x):return {k:v for k,v in x.items() if k!="data"}|{"data":{k:v for k,v in x["data"].items() if k!="frame"}}
 def transition(self,b,a):
  reasons=[]
  for k in ("guid","game_id"):
   if type(b["data"].get(k)) is not str or not b["data"].get(k) or type(a["data"].get(k)) is not str or not a["data"].get(k):reasons.append(k+"_unknown")
   elif b["data"][k]!=a["data"][k]:reasons.append(k+"_changed")
  for label,x in (("before",b["data"]),("after",a["data"])):
   if type(x.get("full_reset")) is not bool:reasons.append(label+"_reset_unknown")
   elif x["full_reset"]:reasons.append(label+"_reset")
  x,y=b["data"].get("levels_completed"),a["data"].get("levels_completed")
  delta=y-x if type(x) is int and type(y) is int else None
  if delta is None:reasons.append("progress_unknown")
  return {"before":self.meta(b),"after":self.meta(a),"levels_completed_delta":delta,"public_progress":None if reasons else delta>0,"unknown":reasons}
 def linkage(self,a,b,ar,br,transition):
  expected={"before_reference":ar,"after_reference":br,"relation":None,"comparisons":[],"unknown":[]}
  if a["result"] is None or b["result"] is None:
   expected["unknown"].append("phase_parse_unknown");return expected
  x,y=a["result"],b["result"];bs,ys=x["scene"],y["scene"]
  roots=[]
  for i,r in enumerate(bs["根"]):
   indices=[j for j,t in enumerate(ys["根"]) if t["色"]==r["色"] and t["形"]==r["形"]]
   roots.append({"before_root_index":i,"before_root":r,"after_root_indices":indices,"after_roots":[ys["根"][j] for j in indices],"unique_hypothesis":len(indices)==1,"origin":"fixed color/shape correspondence hypothesis; movement coordinates retained"})
  same=bs["凡例"]==ys["凡例"]
  expected["relation"]={"legend_exact_equal":same,"before_legend":bs["凡例"],"after_legend":ys["凡例"],"roots":roots}
  if not x["witnesses"] or not y["witnesses"]:expected["unknown"].append("zero_candidates")
  for w in x["witnesses"]:
   m=roots[w["root_index"]];reason=list(w["unknown"]);paths=[];obs=None
   if sum(l["根"]["色"]==w["candidate"]["凡例根色"] for l in ys["凡例"])!=1:reason.append("after_legend_color_ambiguous")
   if not same:reason.append("old_legend_scope_changed")
   if not m["unique_hypothesis"]:reason.append("root_correspondence_ambiguous")
   if m["unique_hypothesis"]:
    paths=y["observed_chains"][m["after_root_indices"][0]]["候補経路"]
    if len(paths)>1:reason.append("after_multiple_paths")
    if ys["未対応画素"]:reason.append("after_unparsed_pixels")
    if not reason:obs=paths[0]["列"]==w["candidate"]["候補列"] if paths else w["candidate"]["候補列"]==[]
   expected["comparisons"].append({"before_ordinal":w["ordinal"],"joint_before_features":w["joint_before_features"],"after_paths":paths,"observed_root_sequence_equal":obs,"unknown":reason,"row_public_progress":transition["public_progress"],"old_scope_link_unknown":list(transition["unknown"])+["same_legend_does_not_prove_same_problem_phase"],"old_scope_observed_sequence_equal":None,"completion_teacher_eligible":False,"old_completion_label":None})
  return expected
 def verify(self):
  g=self.gate
  for p,h in PINS.items():
   if sha(p)!=h:raise ValueError("fixed source pin "+p)
  self.load_functions();self.scan()
  terminal=readref(g["terminal"],1048576)
  eq(list(terminal),["schema","nonce","source_closure","groups","comparison","suffix","parse_errors","HDS_calls","teacher_provenance_proved","limits"])
  eq(terminal["schema"],"chain46-raw-witness-terminal-v1");eq(terminal["nonce"],g["nonce"])
  eq(terminal["source_closure"],self.source_closure)
  eq(terminal["suffix"],[]);eq(terminal["HDS_calls"],0);eq(terminal["teacher_provenance_proved"],False)
  eq(terminal["limits"],"Completed evidence inventory, not teacher correctness or native learning")
  if len(terminal["groups"])!=4:raise ValueError("all four groups")
  projections=[];phase_count=0
  for target,group in zip((38,220,734,859),terminal["groups"]):
   eq(list(group),["target_row","before_phases","metadata_transition","after_phases"]);eq(group["target_row"],target)
   expected_transition=self.transition(self.rows[target-1],self.rows[target]);eq(group["metadata_transition"],expected_transition)
   nb=len(self.rows[target-1]["data"]["frame"]);na=len(self.rows[target]["data"]["frame"])
   if not nb or len(group["before_phases"])!=nb or len(group["after_phases"])!=na:raise ValueError("complete phase lengths")
   before=None
   for i,ref in enumerate(group["before_phases"]):before=self.check_phase(target-1,i,ref);phase_count+=1
   for i,entry in enumerate(group["after_phases"]):
    eq(list(entry),["phase","phase_reference","link_reference"]);eq(entry["phase"],i)
    after=self.check_phase(target,i,entry["phase_reference"]);phase_count+=1
    expected=self.linkage(before,after,group["before_phases"][-1],entry["phase_reference"],expected_transition)
    eq(readref(entry["link_reference"],33554432),expected)
    for item in expected["comparisons"]:projections.append({"row":target,"phase":i,"before_reference":group["before_phases"][-1],"after_reference":entry["phase_reference"],**item})
    self.details.append(self.save("link_%03d_%03d.json.xz"%(target,i),{"saved_reference":entry["link_reference"],"expected":expected}))
  eq(terminal["parse_errors"],self.phase_errors)
  # Every producer packet, including group files not separately referenced by terminal.
  names=["rawrow"]*8
  group_positions=[]
  for target,group in zip((38,220,734,859),terminal["groups"]):
   names+=["phase"]*len(group["before_phases"])
   for entry in group["after_phases"]:names+=["phase","phase_link"]
   group_positions.append((len(names),group));names.append("group")
  names+=["old46_comparison","terminal"]
  run_dir=safe(g["terminal"]["path"]).parent
  if run_dir!=BASE/("goal46_witness_"+g["nonce"]):raise ValueError("producer directory")
  expected_names=[str(i).zfill(5)+"_"+kind+".json" for i,kind in enumerate(names)]
  actual_names=sorted(p.name for p in run_dir.iterdir() if re.match(r"^[0-9]{5}_",p.name))
  eq(actual_names,expected_names)
  if Path(g["terminal"]["path"]).name!=expected_names[-1]:raise ValueError("terminal position")
  inventory=[reference(run_dir/name) for name in expected_names]
  if sum(z["bytes"] for z in inventory[:-1])>33554432 or inventory[-1]["bytes"]>1048576:raise ValueError("producer aggregate bytes")
  for position,group in group_positions:eq(readref(inventory[position],33554432),group)
  self.details.append(self.save("producer_inventory.json.xz",inventory))
  old=decode(OLD.read_bytes());teachers=old["教師群"]
  if len(teachers)!=46:raise ValueError("all old46 required")
  counts={}
  for i,t in enumerate(teachers):counts.setdefault(encode(t).decode(),[]).append(i)
  expected={"old_complete_records":[{"teacher":decode(k),"indices":v,"multiplicity":len(v)} for k,v in counts.items()],"all_observed_projection":projections,"old_to_raw_exact_mapping":None,"status":"UNKNOWN","reason":"Original generator/witness identity missing; no chosen phase, deduplication, count fitting or AND result","independent_support_added":0}
  eq(readref(terminal["comparison"],33554432),expected)
  self.details.append(self.save("multiplicity_projection.json.xz",{"old_reference":reference(OLD),"saved_reference":terminal["comparison"],"expected":expected}))
  # Close raw identity/hash again after every saved-packet comparison.
  if ident(RAW)!=self.source_closure["identity"] or sha(RAW)!=PINS[str(RAW)]:raise ValueError("final raw closure")
  for p,h in PINS.items():
   if sha(p)!=h:raise ValueError("final source closure")
  self.verified={k:True for k in FIELDS}
  index={"schema":"chain46-independent-detail-v1","terminal":g["terminal"],"source_pins":PINS,"source_closure":self.source_closure,"read_refs":self.read_refs,"details":self.details,"phase_count":phase_count,"old_record_count":46,"all_checks":self.verified}
  indexref=self.save("index.json.xz",index)
  self.summary={"schema":"chain46-raw-witness-independent-v1","status":"PASS","nonce":g["nonce"],"errors":[],"terminal":g["terminal"],"source_sha256":sha(__file__),"verified":self.verified,"detail":indexref,"phase_count":phase_count,"HDS_calls":0,"teacher_provenance_proved":False,"limitations":["Fixed prior perception is reused, not independently validated as game semantics.","Full producer trace is preserved; independent error type/message and pinned frame origins are checked, traceback text differs by caller.","Old46 exact witness mapping and completion labels remain unproved."]}
  summaryref=self.save("summary.json",self.summary,False);self.complete=True
  return summaryref["file"]
def run(gate_path,gate_sha):
 global OWNER
 if OWNER is not None:raise RuntimeError("one audit only")
 OWNER=Audit()
 try:
  OWNER.clock.enter("compute")
  soft,hard=resource.getrlimit(resource.RLIMIT_AS)
  if not (0<soft<=536870912 and 0<hard<=536870912):raise ValueError("AS512 required before import")
  if sha(gate_path)!=gate_sha:raise ValueError("gate SHA")
  g=decode(Path(gate_path).read_bytes());OWNER.gate=g
  if g.get("schema")!="chain46-independent-release-v1" or g.get("enabled") is not True or g.get("source_sha256")!=sha(__file__):raise ValueError("audit gate binding")
  if type(g.get("nonce")) is not str or not re.fullmatch("[0-9a-f]{32}",g["nonce"]):raise ValueError("nonce")
  if g.get("compute_seconds")!=3600 or g.get("save_seconds")!=300 or time.time()>g["admission_deadline_epoch"]:raise ValueError("finite gate")
  eq(g["pins"],PINS)
  producer=readref(g["producer_gate"],65536)
  if producer.get("schema")!="chain46-raw-witness-release-v1" or producer.get("enabled") is not True or producer.get("nonce")!=g["nonce"] or producer.get("source_sha256")!=PINS[str(CALLER)] or producer.get("independent_audit_source_sha256")!=sha(__file__):raise ValueError("producer auditor join")
  eq(producer["pins"],{p:h for p,h in PINS.items() if p!=str(CALLER)})
  guard(4*1048576);OWNER.directory=BASE/("goal46_audit_"+g["nonce"]);OWNER.directory.mkdir()
  fd=os.open(BASE,os.O_RDONLY)
  try:os.fsync(fd)
  finally:os.close(fd)
  result=OWNER.verify();OWNER.clock.stop()
  print(json.dumps({"status":"PASS","receipt":result},ensure_ascii=False),flush=True)
  return result
 except BaseException as e:
  OWNER.clock.stop();OWNER.exceptions.append(e);OWNER.errors.append(traceback.format_exc())
  print(json.dumps({"status":"failed_held","errors":OWNER.errors,"directory":str(OWNER.directory),"complete":OWNER.complete},ensure_ascii=False),flush=True)
  # No result adoption or false verified flags. Original current/pending/traceback frames remain.
  while True:time.sleep(60)
 finally:OWNER.clock.stop()
