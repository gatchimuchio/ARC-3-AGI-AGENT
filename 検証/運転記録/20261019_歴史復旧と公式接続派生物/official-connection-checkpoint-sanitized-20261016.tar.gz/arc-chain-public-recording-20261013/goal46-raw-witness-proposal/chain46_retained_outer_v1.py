"""Retain imports and original failures; root gate only, no automatic retry."""
import resource
resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912))
import sys
sys.dont_write_bytecode=True
import pathlib,hashlib,importlib.util,signal,time,json,traceback
OUTER={"module":None,"exception":None,"traceback":None,"result":None}
P=pathlib.Path(__file__).with_name("chain46_all_phase_caller_v4.py")
PIN="3b30c0ea39be4a3f5c942da0a4083e5facb4e75a73d412f14ffc6f9b6182a906"
def deadline(*_):raise TimeoutError("outer import120")
def main(gate_path,gate_sha):
 signal.signal(signal.SIGALRM,deadline);signal.alarm(120)
 try:
  p=pathlib.Path(gate_path)
  assert p.is_file() and not p.is_symlink() and p.stat().st_size<=16384
  b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==gate_sha
  gate=json.loads(b)
  assert gate["outer_source_sha256"]==hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()
  assert hashlib.sha256(P.read_bytes()).hexdigest()==PIN
  spec=importlib.util.spec_from_file_location("chain46_retained_caller",P)
  m=importlib.util.module_from_spec(spec);OUTER["module"]=m
  spec.loader.exec_module(m)
  OUTER["result"]=m.run(gate_path,gate_sha)
  assert m.STATE["ack"] is not None and m.OWNER.complete and not m.OWNER.failed
  signal.alarm(0)
  print(json.dumps({"status":"outer_closed_after_root_ack","nonce":m.OWNER.gate["nonce"]}),flush=True)
 except BaseException as e:
  signal.alarm(0);OUTER["exception"]=e;OUTER["traceback"]=traceback.format_exc()
  print(json.dumps({"status":"outer_failed_held","traceback":OUTER["traceback"]}),flush=True)
  while True:time.sleep(60)
if __name__=="__main__":main(*sys.argv[1:])
