"""Source-only proposal. No CLI, no automatic raw reads, no HDS imports.
Caller, retained failure ownership and durable packet writer require separate review.
Every cap is a stop bound, not a fit guarantee.
"""
import ast
import collections
import hashlib
import itertools
import json
import math
from pathlib import Path

PIXEL_SHA = "b7447f4a849a054daf6ef9834b86ac93dc0972cce93b4d83cceed5c8a091d48e"
FUNCTIONS = ("parse", "observed_chains", "candidates")
PUBLIC_ROWS = (38, 220, 734, 859)
MAX_PHASES = 256
MAX_PERMUTATIONS_PER_PHASE = 100000
MAX_CANDIDATES_PER_PHASE = 16384
MAX_ASSIGNMENTS_PER_PHASE = 65536

def load_fixed_prior(path):
    """Executed only after a later gate; select unchanged existing function AST."""
    raw = Path(path).read_bytes()
    if hashlib.sha256(raw).hexdigest() != PIXEL_SHA:
        raise ValueError("pixel source pin mismatch")
    tree = ast.parse(raw, filename=str(path))
    selected = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in FUNCTIONS]
    if tuple(n.name for n in selected) != FUNCTIONS:
        raise ValueError("fixed function closure changed")
    allowed = {"isinstance", "list", "any", "len", "type", "int", "range",
               "set", "sum", "all", "min", "max", "sorted", "abs", "enumerate",
               "ValueError"}
    for node in ast.walk(ast.Module(body=selected, type_ignores=[])):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
            if node.func.id not in allowed:
                raise ValueError("unexpected function dependency: " + node.func.id)
    ns = {"itertools": itertools, "collections": collections}
    exec(compile(ast.Module(body=selected, type_ignores=[]), str(path), "exec"), ns)
    return {name: ns[name] for name in FUNCTIONS}

def count_domain(scene):
    """Call after parse, before candidates/set(permutations) or assignment expansion."""
    roots = len(scene["根"])
    counts = collections.Counter(b["色"] for b in scene["珠"])
    work = candidates = assignments = 0
    for legend in scene["凡例"]:
        seq = legend["列"]
        fact = math.factorial(len(seq))
        unique = fact
        for multiplicity in collections.Counter(seq).values():
            unique //= math.factorial(multiplicity)
        work += roots * fact
        candidates += roots * unique
        # Includes repeated bead choices: conservative bound before distinct-ID filter.
        options = math.prod(counts[c] for c in seq)
        assignments += roots * unique * options
    result = {"permutation_work": work, "distinct_candidates": candidates,
              "assignment_product_upper_bound": assignments}
    if work > MAX_PERMUTATIONS_PER_PHASE or candidates > MAX_CANDIDATES_PER_PHASE or assignments > MAX_ASSIGNMENTS_PER_PHASE:
        error = ValueError("candidate domain exceeds finite admission")
        error.measured_counts = result
        raise error
    return result

def legend_fingerprint(scene):
    # Exact structural evidence; never forces a new problem diagnosis.
    return scene["凡例"]

def phase_witnesses(frame, functions):
    """One phase; caller retains original frame, metadata and exceptions even on failure."""
    scene = functions["parse"](frame)
    bound = count_domain(scene)
    chains = functions["observed_chains"](frame, scene)
    witnesses = []
    def generation_indices():
        for root_index, root in enumerate(scene["根"]):
            for legend_index, legend in enumerate(scene["凡例"]):
                n = math.factorial(len(legend["列"]))
                for multiplicity in collections.Counter(legend["列"]).values():
                    n //= math.factorial(multiplicity)
                for sequence_index in range(n):
                    yield root_index, legend_index, sequence_index
    bindings = iter(generation_indices())
    for ordinal, candidate in enumerate(functions["candidates"](scene)):
        root_index, legend_index, sequence_index = next(bindings)
        bound_root = scene["根"][root_index]
        bound_legend = scene["凡例"][legend_index]
        if bound_root["色"] != candidate["根色"] or bound_legend["根"]["色"] != candidate["凡例根色"] or bound_legend["列"] != candidate["凡例列"]:
            raise ValueError("candidate generation-order witness mismatch")
        roots = [r for r in scene["根"] if r["色"] == candidate["根色"]]
        legends = [l for l in scene["凡例"] if l["根"]["色"] == candidate["凡例根色"] and l["列"] == candidate["凡例列"]]
        paths = chains[root_index]["候補経路"]
        options = [[b["対象"] for b in scene["珠"] if b["色"] == color] for color in candidate["候補列"]]
        assignments = [list(t) for t in itertools.product(*options) if len(t) == len(set(t))]
        unknown = []
        if scene["未対応画素"]: unknown.append("unparsed_pixels")
        if len(roots) != 1: unknown.append("ambiguous_root_binding")
        if len(legends) != 1: unknown.append("ambiguous_legend_binding")
        if len(paths) > 1: unknown.append("multiple_observed_paths")
        if not assignments: unknown.append("no_distinct_bead_assignment")
        # Result depends only on the observed chain of the candidate root.
        # It does not use either candidate feature boolean or their conjunction.
        match = None if unknown else (paths[0]["列"] == candidate["候補列"] if paths else candidate["候補列"] == [])
        witnesses.append({"ordinal": ordinal, "candidate": candidate,
            "root_index": root_index, "legend_index": legend_index, "sequence_index": sequence_index,
            "bound_root": bound_root, "bound_legend": bound_legend,
            "roots": roots, "legends": legends, "observed_paths": paths,
            "assignment_options": options, "distinct_assignments": assignments,
            "joint_before_features": [candidate["特徴"]["根一致"], candidate["特徴"]["順序一致"]],
            "observed_root_sequence_equal": match, "unknown": unknown,
            "old_teacher_completion_label": None})
    if next(bindings, None) is not None:
        raise ValueError("unconsumed generation index")
    if len(witnesses) != bound["distinct_candidates"]:
        raise ValueError("candidate count mismatch")
    return {"scene": scene, "observed_chains": chains, "counts": bound, "witnesses": witnesses}

def compare_phase_scope(before_scene, phase_scene):
    """Changed legend is only a scope mismatch, never unconditional new-game proof."""
    return {"legend_exact_equal": legend_fingerprint(before_scene) == legend_fingerprint(phase_scene),
            "completion_teacher_eligible": False,
            "reason": "public acceptance/phase identity and old-label semantics need independent evidence"}

def retained_phase_call(frame, functions, owner, reference):
    """Keep partial raw frame and exact exception object; durable writer is caller-owned."""
    import traceback
    current = {"reference": reference, "frame": frame, "result": None, "error": None}
    owner["phases"].append(current)
    try:
        current["result"] = phase_witnesses(frame, functions)
    except BaseException as error:
        owner["exceptions"].append(error)
        current["error"] = {"type": type(error).__name__, "message": str(error),
                            "traceback": traceback.format_exc(),
                            "counts": getattr(error, "measured_counts", None)}
        raise
    return current
