"""Synthetic-only fixture. Does not open public RAW or invoke HDS/SDK.
All production comparisons execute on explicit synthetic objects; mocked perception is identified.
"""
import resource
resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912))
import sys
sys.dont_write_bytecode=True
import os,json,hashlib,importlib.util,traceback,copy,types,time,signal,contextlib,io
from pathlib import Path
P=Path("/workspace/scratch/a94ff513b3af/arc-chain-public-recording-20261013")
S=P/"goal46-raw-witness-proposal"
F=P/"goal46-synthetic-fixture-v1"
OWNERS=[];EXCEPTIONS=[];CASES=[];MODULES=[]
def load(path,pin):
 raw=path.read_bytes()
 assert hashlib.sha256(raw).hexdigest()==pin
 sp=importlib.util.spec_from_file_location(path.stem,path);m=importlib.util.module_from_spec(sp);MODULES.append(m);sp.loader.exec_module(m);return m
def pack(x):
 if x is None or type(x) in (bool,int,float,str):return [type(x).__name__,x]
 if isinstance(x,bytes):return ["bytes",x.hex()]
 if isinstance(x,(list,tuple)):return [type(x).__name__,[pack(t) for t in x]]
 if isinstance(x,dict):return ["dict",[[pack(k),pack(v)] for k,v in x.items()]]
 if isinstance(x,Path):return ["path",str(x)]
 if isinstance(x,BaseException):return ["exception",type(x).__name__,pack(x.args),"".join(traceback.format_exception(type(x),x,x.__traceback__))]
 if isinstance(x,types.ModuleType):return ["module_descriptor",x.__name__,getattr(x,"__file__",None)]
 if callable(x):return ["callable_descriptor",getattr(x,"__module__",None),getattr(x,"__qualname__",None)]
 if hasattr(x,"__dict__"):return ["object",type(x).__name__,pack(vars(x))]
 raise TypeError("unhandled snapshot type "+str(type(x)))
def case(name,group,inputs,fn,expected=None,owner=None):
 rec={"id":name,"group":group,"input":pack(inputs),"owner_before":pack(owner),"result":None,"exception":None,"checks":[]}
 try:
  value=fn();rec["result"]=pack(value)
  if expected is not None:raise AssertionError("expected exception missing "+expected.__name__)
  rec["checks"].append("return assertions passed")
 except BaseException as e:
  EXCEPTIONS.append(e);rec["exception"]=pack(e)
  if expected is None or type(e) is not expected:
   rec["checks"].append("UNEXPECTED");CASES.append(rec);raise
  rec["checks"].append("exact expected exception type")
 finally:
  rec["owner_after"]=pack(owner)
  if rec not in CASES:CASES.append(rec)
 return rec
def filewrite(p,b):
 with p.open("xb") as f:f.write(b);f.flush();os.fsync(f.fileno())
 d=os.open(p.parent,os.O_RDONLY);os.fsync(d);os.close(d)
 assert p.read_bytes()==b
def ref(p):
 b=p.read_bytes();return {"path":str(p),"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()}
M=load(S/"chain46_all_phase_caller_v4.py","3b30c0ea39be4a3f5c942da0a4083e5facb4e75a73d412f14ffc6f9b6182a906")
W=load(S/"chain46_raw_witness_v2.py","af3e6100e4ee98d00478a615778576e22140382f67e78e1dd54efaa7d1c89b2e")
M.guard();F.mkdir();d=os.open(P,os.O_RDONLY);os.fsync(d);os.close(d)
FIXED=W.load_fixed_prior(M.PRIOR)
root={"色":6,"範囲":[0,0,5,5],"中心":[2.5,2.5],"形":"環"}
legend={"根":{"色":6,"範囲":[0,20,5,25],"中心":[2.5,22.5],"形":"環"},"列":[7],"珠":[]}
scene={"根":[root],"凡例":[legend],"珠":[{"色":7,"対象":"b0"}],"未対応画素":[]}
chains=[{"根色":6,"候補経路":[{"方向":[1,0],"列":[7],"対象":["b0"]}]}]
def funcs(sc,cs):
 return {"parse":lambda frame:copy.deepcopy(sc),"observed_chains":lambda frame,s:copy.deepcopy(cs),"candidates":FIXED["candidates"]}
def owner():
 clock=M.Deadline();M.STATE["clock"]=clock
 o=M.Run({"nonce":str(len(OWNERS)).zfill(32),"source_sha256":"a"*64,"independent_audit_source_sha256":"b"*64})
 o.directory=F/("owner_"+str(len(OWNERS)));o.module=W;o.functions=funcs(scene,chains);o.setup();OWNERS.append(o);return o
status="FAIL";fatal=None
try:
 # 1: actual derive with explicit synthetic row loader and actual save/phase/compare.
 o=owner()
 def synthetic_load():
  o.old={"教師群":[{"境界":"synthetic","入力":{"k":"[true,true]","v":True},"文脈":{"由来":0}}]}
  o.source_closure={"synthetic":True}
  for row in M.ROWS:
   frames=[[[row,0]],[[row,1]]]
   val={"data":{"frame":frames,"guid":"fixture","game_id":"fixture","full_reset":False,"levels_completed":0}}
   o.raw_rows[row]={"row0":row,"value":val};o.raw_refs[row]=o.save("synthetic_raw",o.raw_rows[row])
  def parse(frame):
   if frame==[[38,0]]:raise ValueError("synthetic phase parse failure")
   return copy.deepcopy(scene)
  o.functions={"parse":parse,"observed_chains":lambda f,s:copy.deepcopy(chains),"candidates":FIXED["candidates"]}
 o.load=synthetic_load
 def allphases():
  r=o.derive()
  assert [(x["row"],x["phase"]) for x in o.phases]==[(n,i) for n in M.ROWS for i in range(2)]
  assert len([x for x in o.phases if x["error"]])==1 and o.suffix==[]
  assert len(o.groups)==4 and len(o.refs)>16
  for p in o.directory.glob("*phase_link.json"):
   for c in json.loads(p.read_bytes())["comparisons"]:
    assert c["old_scope_observed_sequence_equal"] is None and c["completion_teacher_eligible"] is False
  return r
 case("all_phase_order_parse_failure",1,{"rows":M.ROWS,"all_frames":"two per synthetic row","parse_error":[38,0],"perception":"mocked scene, unchanged production candidates"},allphases,owner=o)
 # 2: exact fixed candidates with explicit mock scene; all alternatives retained.
 for name,sc,cs,reason in [
  ("duplicate_roots",{**scene,"根":[root,copy.deepcopy(root)]},chains+copy.deepcopy(chains),"ambiguous_root_binding"),
  ("duplicate_legend_different_seq",{**scene,"凡例":[legend,{**legend,"列":[8]}]} ,chains,"ambiguous_legend_binding")]:
  def check(sc=sc,cs=cs,reason=reason):
   x=W.phase_witnesses([],funcs(sc,cs));assert all(reason in a["unknown"] and a["observed_root_sequence_equal"] is None for a in x["witnesses"]);return x
  case(name,2,{"scene":sc,"chains":cs},check)
 case("zero_candidates",2,{},lambda:W.phase_witnesses([],funcs({**scene,"根":[]},[])))
 assert CASES[-1]["result"] is not None
 x=W.phase_witnesses([],funcs({**scene,"根":[]},[]));assert x["status"]=="HOLD" and x["unknown"]==["zero_candidates"]
 # 3: metadata only, same legend doesn't prove phase scope.
 base={"data":{"guid":"g","game_id":"a","full_reset":False,"levels_completed":2}}
 for key,value in (("guid","other"),("game_id","other"),("full_reset",True),("levels_completed",None)):
  aft=copy.deepcopy(base);aft["data"][key]=value
  def check(aft=aft):
   r=M.progress(base,aft);assert r["unknown"] and r["public_progress"] is None;return r
  case("boundary_"+key,3,{"before":base,"after":aft},check)
 case("same_legend_scope_unknown",3,scene,lambda:W.compare_phase_scope(scene,scene))
 assert W.compare_phase_scope(scene,scene)["completion_teacher_eligible"] is False
 # 4: candidate caps actual, and writer caps actual.
 for name,field,new in [("permutation_cap","MAX_PERMUTATIONS_PER_PHASE",0),("candidate_cap","MAX_CANDIDATES_PER_PHASE",0),("assignment_cap","MAX_ASSIGNMENTS_PER_PHASE",0)]:
  previous=getattr(W,field);setattr(W,field,new)
  try:case(name,4,{"field":field,"limit":new,"scene":scene},lambda:W.count_domain(scene),ValueError)
  finally:setattr(W,field,previous)
 for name,report in (("output_cap",False),("report_cap",True)):
  oo=owner()
  if report:oo.report_bytes=M.REPORT_CAP
  else:oo.output_bytes=M.OUTPUT_CAP
  case(name,4,{"report":report},lambda oo=oo,report=report:oo.save("cap",{"all":"kept"},report),MemoryError,oo)
  assert oo.pending["value"]=={"all":"kept"}
 # Actual load uses only a synthetic replacement source, never public recording.
 fp=F/"synthetic_rows.jsonl";op=F/"synthetic_old.json"
 synth=[]
 for n in range(860):
  val={"data":{"frame":([[]]*257 if n==37 else [[]]),"guid":"fixture","game_id":"fixture","full_reset":False,"levels_completed":0}}
  synth.append(json.dumps(val,separators=(",",":")))
 filewrite(fp,("\n".join(synth)+"\n").encode());filewrite(op,b'{"teacher":"synthetic"}')
 raw_old,old_old,pins_old=M.RAW,M.OLD,M.PINS
 M.RAW=fp;M.OLD=op;M.PINS={str(fp):M.sha(fp),str(op):M.sha(op),str(M.PRIOR):pins_old[str(M.PRIOR)],str(M.WITNESS):pins_old[str(M.WITNESS)]}
 oo=owner()
 try:case("phase_cap_load",4,{"synthetic_raw":ref(fp),"old":ref(op),"full_input_file_retained":True},lambda:oo.load(),MemoryError,oo)
 finally:M.RAW=raw_old;M.OLD=old_old;M.PINS=pins_old
 # 5: write/fsync/readback failure retain primary and pending.
 oo=owner();target=oo.directory/"00000_collision.json";filewrite(target,b"prior")
 case("exclusive_write_failure",5,{"prior":b"prior"},lambda:oo.save("collision",{"new":1}),FileExistsError,oo);assert oo.pending
 oo=owner();original=M.os.fsync
 def failfsync(fd):raise OSError("synthetic fsync failure")
 M.os.fsync=failfsync
 try:case("fsync_failure",5,{},lambda:oo.save("fsync",{"new":1}),OSError,oo)
 finally:M.os.fsync=original
 assert oo.pending and type(oo.exceptions[-1]) is OSError
 oo=owner();original=Path.read_bytes
 def badread(p):
  if p.parent==oo.directory:return b"wrong"
  return original(p)
 Path.read_bytes=badread
 try:case("readback_failure",5,{},lambda:oo.save("readback",{"new":1}),ValueError,oo)
 finally:Path.read_bytes=original
 assert oo.pending
 # Save error with expiration: original OSError must survive, then finite exhausted failure save.
 oo=owner();original=M.os.fsync
 def expire_then_fail(fd):
  oo.clock.remaining["save"]=0
  raise OSError("primary with exhausted save time")
 M.os.fsync=expire_then_fail
 try:case("save_primary_not_replaced",5,{},lambda:oo.save("primary",{"v":1}),OSError,oo)
 finally:M.os.fsync=original
 pending=oo.pending;oo.failure();assert oo.pending is pending and any(type(e) is TimeoutError for e in oo.exceptions)
 case("failure_secondary_preserved",5,{},lambda:{"errors":oo.errors,"pending":oo.pending},owner=oo)
 # 6: actual real deadline, pure strict gates, valid/invalid ACK and real hold close.
 clock=M.Deadline();clock.remaining["compute"]=0.02
 def deadline():
  clock.enter("compute")
  try:
   while True:pass
  finally:clock.stop()
 case("single_operation_alarm",6,{"seconds":0.02},deadline,TimeoutError)
 case("duplicate_json",6,b'{"x":1,"x":2}',lambda:M.unique_json(b'{"x":1,"x":2}'),ValueError)
 class StopHold(Exception):pass
 for name,as_value in (("AS_unlimited",(-1,-1)),("invalid_gate",(536870912,536870912))):
  gp=F/(name+".json");filewrite(gp,b'{"schema":"explicitly-invalid-synthetic"}')
  oldget=M.resource.getrlimit;oldsleep=M.time.sleep
  M.OWNER=None;M.STATE["errors"]=[];M.STATE["exceptions"]=[]
  M.resource.getrlimit=lambda kind:as_value
  def stop(t):raise StopHold("synthetic outer stops hold after evidence")
  M.time.sleep=stop
  try:
   case(name,6,{"AS":as_value,"gate":ref(gp)},lambda:M.run(str(gp),M.sha(gp)),StopHold)
   assert M.STATE["errors"];EXCEPTIONS.extend(M.STATE["exceptions"])
  finally:M.resource.getrlimit=oldget;M.time.sleep=oldsleep;M.STATE["clock"].stop()
 oo=owner();oo.complete=True;oo.failed=False;M.OWNER=oo;M.STATE["errors"]=[]
 terminal={"path":"synthetic-only-terminal","bytes":1,"sha256":"c"*64};M.STATE["terminal_reference"]=terminal
 fields=("all_eight_raw_rows","all_phases_and_errors","all_candidates_and_multiplicity","full_types_order","scope_unknowns_preserved","old46_not_forced")
 audit={"schema":"chain46-raw-witness-independent-v1","status":"PASS","nonce":oo.gate["nonce"],"errors":[],"terminal":terminal,"source_sha256":"b"*64,"verified":{k:True for k in fields}}
 ap=F/"synthetic_audit.json";filewrite(ap,json.dumps(audit).encode())
 ack={"schema":"chain46-raw-witness-root-ack-v1","decision":"ACK","nonce":oo.gate["nonce"],"source_sha256":"a"*64,"terminal":terminal,"independent_audit":ref(ap)}
 for key,value in (("nonce","wrong"),("source_sha256","wrong"),("decision","wrong")):
  bad={**ack,key:value};case("ACK_"+key,6,bad,lambda bad=bad:M.verify_ack(bad),ValueError,oo)
 for key in fields:
  bad=copy.deepcopy(audit);bad["verified"][key]=False;fp=F/("audit_false_"+key+".json");filewrite(fp,json.dumps(bad).encode())
  a={**ack,"independent_audit":ref(fp)};case("ACK_false_"+key,6,a,lambda a=a:M.verify_ack(a),ValueError,oo)
 oo.failed=True;case("failed_owner_ACK",6,ack,lambda:M.verify_ack(ack),ValueError,oo);oo.failed=False
 case("valid_ACK",6,ack,lambda:M.verify_ack(ack),owner=oo)
 filewrite(oo.directory/("root_ack_"+oo.gate["nonce"]+".json"),json.dumps(ack).encode())
 case("actual_hold_valid_close",6,ack,lambda:M.hold_for_ack(),owner=oo)
 assert M.STATE["ack"]==ack
 status="PASS"
except BaseException as e:
 EXCEPTIONS.append(e);fatal=pack(e)
finally:
 signal.setitimer(signal.ITIMER_REAL,0)
 for o in OWNERS:
  o.clock.stop()
  if o.dirfd is not None:os.close(o.dirfd);o.dirfd=None
 snapshot={"schema":"chain46-witness-pure-fixture-v1","status":status,"fatal":fatal,"cases":CASES,
  "owners":pack(OWNERS),"exceptions":pack(EXCEPTIONS),"module_descriptors":pack(MODULES),
  "limits":["Synthetic scenes mock perception; production candidate enumeration and caller methods exercised.","No public RAW opened; no HDS/SDK.","Callable/modules are descriptors; not heap reconstruction proof.","Fault injections do not establish OS crash durability."],
  "source_refs":[ref(S/"chain46_all_phase_caller_v4.py"),ref(S/"chain46_raw_witness_v2.py"),ref(Path(__file__))]}
 raw=json.dumps(snapshot,ensure_ascii=False,separators=(",",":")).encode()
 used=sum(p.stat().st_size for p in F.rglob("*") if p.is_file())
 assert used+len(raw)+65536<=4194304
 M.guard(len(raw)+65536)
 filewrite(F/"full_fixture_result.json",raw)
 assert json.loads((F/"full_fixture_result.json").read_bytes())==snapshot
 print(json.dumps({"status":status,"case_count":len(CASES),"groups":sorted(set(c["group"] for c in CASES)),"owner_count":len(OWNERS),"report":ref(F/"full_fixture_result.json"),"fixture_bytes":sum(p.stat().st_size for p in F.rglob("*") if p.is_file())}),flush=True)
 if status!="PASS":raise SystemExit(1)
