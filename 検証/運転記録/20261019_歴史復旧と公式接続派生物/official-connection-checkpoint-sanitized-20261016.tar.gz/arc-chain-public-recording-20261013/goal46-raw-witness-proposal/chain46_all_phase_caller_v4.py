"""Unexecuted caller proposal: all eight raw rows, every phase, complete candidate evidence.
Not a teacher generator. Old46 projection comparison does not establish old-label provenance.
"""
import ast
import hashlib
import importlib.util
import json
import os
import resource
import signal
import shutil
import time
import traceback
from pathlib import Path

BASE = Path("/workspace/scratch/a94ff513b3af/arc-chain-public-recording-20261013")
SOURCE = BASE / "goal46-raw-witness-proposal"
RAW = BASE / "api_response_v1.body"
OLD = BASE / "goal-reconstruction-source/目標教師46.json"
PRIOR = BASE / "source/画素.py"
WITNESS = SOURCE / "chain46_raw_witness_v2.py"
PINS = {
 str(RAW): "689b90f7968c96e1a08cd2f8bf73f62a404e03a3b5a1586de9b257034771c4e6",
 str(OLD): "3b006236552c410fa9c93dc87f134cd58ed393ced413fcf6f504235a2eb38395",
 str(PRIOR): "b7447f4a849a054daf6ef9834b86ac93dc0972cce93b4d83cceed5c8a091d48e",
 str(WITNESS): "af3e6100e4ee98d00478a615778576e22140382f67e78e1dd54efaa7d1c89b2e"}
TARGETS = (38, 220, 734, 859)
ROWS = tuple(n for target in TARGETS for n in (target-1, target))
OUTPUT_CAP = 33554432
REPORT_CAP = 1048576
SCOPE_CAP = 100663296
OWNER = None
STATE = {"owner":None,"clock":None,"exceptions":[],"errors":[],"gate":None,"terminal_reference":None,"ack":None,"ack_rejections":[]}

class Deadline:
 def __init__(self):
  self.remaining={"compute":1200.0,"save":300.0};self.mode=None;self.started=None
  signal.signal(signal.SIGALRM,self.expired)
 def expired(self,signum,frame):
  raise TimeoutError("active "+str(self.mode)+" deadline")
 def stop(self):
  signal.setitimer(signal.ITIMER_REAL,0)
  if self.mode is not None:self.remaining[self.mode]-=time.monotonic()-self.started
  self.mode=None;self.started=None
 def enter(self,mode):
  self.stop()
  if self.remaining[mode]<=0:raise TimeoutError(mode+" aggregate budget exhausted")
  self.mode=mode;self.started=time.monotonic()
  signal.setitimer(signal.ITIMER_REAL,self.remaining[mode])


def strict(a,b):
 if type(a) is not type(b): raise ValueError("type mismatch")
 if isinstance(a,dict):
  strict(list(a),list(b))
  for k in a: strict(a[k],b[k])
 elif isinstance(a,list):
  if len(a)!=len(b): raise ValueError("length mismatch")
  for x,y in zip(a,b): strict(x,y)
 elif a!=b: raise ValueError("value mismatch")

def sha(path):
 h=hashlib.sha256()
 with open(path,"rb") as f:
  for b in iter(lambda:f.read(65536),b""): h.update(b)
 return h.hexdigest()

def identity(p):
 s=p.stat();return [s.st_dev,s.st_ino,s.st_size,s.st_mode,s.st_mtime_ns,s.st_ctime_ns]

def guard(extra=0):
 if BASE.is_symlink(): raise ValueError("scope symlink")
 used=sum(p.stat().st_size for p in BASE.rglob("*") if p.is_file())
 if used+extra>SCOPE_CAP: raise MemoryError("scope cap")
 if shutil.disk_usage(BASE).free < (1024+168)*1048576: raise MemoryError("disk floor/full scope future")
 mem=next(int(x.split()[1])*1024 for x in open("/proc/meminfo") if x.startswith("MemAvailable:"))
 if mem < (2688+2048)*1048576: raise MemoryError("memory reservation/floor")
 return used

def metadata(row):
 return {k:v for k,v in row.items() if k!="data"} | {"data":{k:v for k,v in row["data"].items() if k!="frame"}}

def progress(before,after):
 b,a=before["data"],after["data"]; reasons=[]
 for k in ("guid","game_id"):
  if type(b.get(k)) is not str or not b.get(k) or type(a.get(k)) is not str or not a.get(k): reasons.append(k+"_unknown")
  elif b[k]!=a[k]: reasons.append(k+"_changed")
 for label,x in (("before",b),("after",a)):
  if type(x.get("full_reset")) is not bool: reasons.append(label+"_reset_unknown")
  elif x["full_reset"]: reasons.append(label+"_reset")
 x,y=b.get("levels_completed"),a.get("levels_completed")
 delta=y-x if type(x) is int and type(y) is int else None
 if delta is None: reasons.append("progress_unknown")
 return {"before":metadata(before),"after":metadata(after),"levels_completed_delta":delta,
         "public_progress":None if reasons else delta>0,"unknown":reasons}

def correlate(before,after):
 """Keep every root alternative; never bind root by color alone or select a convenient phase."""
 bs,as_=before["scene"],after["scene"]
 legend_equal=bs["凡例"]==as_["凡例"]
 roots=[]
 for i,r in enumerate(bs["根"]):
  matches=[j for j,t in enumerate(as_["根"]) if t["色"]==r["色"] and t["形"]==r["形"]]
  roots.append({"before_root_index":i,"before_root":r,"after_root_indices":matches,
                "after_roots":[as_["根"][j] for j in matches],
                "unique_hypothesis":len(matches)==1,
                "origin":"fixed color/shape correspondence hypothesis; movement coordinates retained"})
 return {"legend_exact_equal":legend_equal,"before_legend":bs["凡例"],"after_legend":as_["凡例"],"roots":roots}

class Run:
 def __init__(self,gate):
  self.gate=gate;self.start=time.monotonic();self.io_used=0.
  self.compute_limit=1200.;self.io_limit=300.
  self.module=None;self.functions=None;self.raw_rows={};self.raw_refs={}
  self.phases=[];self.exceptions=[];self.errors=[];self.pending=None
  self.cursor={"stage":"initial","row":None,"phase":None};self.refs=[];self.groups=[]
  self.output_bytes=0;self.report_bytes=0;self.complete=False;self.failed=False
  self.directory=BASE/("goal46_witness_"+gate["nonce"])
  self.dirfd=None
  self.clock=STATE["clock"]
  self.suffix=list(ROWS);self.old=None

 def setup(self):
  self.directory.mkdir()
  fd=os.open(BASE,os.O_RDONLY)
  try:os.fsync(fd)
  finally:os.close(fd)
  self.dirfd=os.open(self.directory,os.O_RDONLY)

 def check(self):
  if time.monotonic()-self.start-self.io_used>self.compute_limit: raise TimeoutError("compute deadline")

 def save(self,kind,value,report=False):
  self.pending={"kind":kind,"value":value};start=time.monotonic();primary=None
  self.clock.enter("save")
  try:
   raw=json.dumps(value,ensure_ascii=False,separators=(",",":"),allow_nan=False).encode()
   cap=REPORT_CAP if report else OUTPUT_CAP;used=self.report_bytes if report else self.output_bytes
   if used+len(raw)>cap: raise MemoryError("aggregate output cap; pending retained")
   guard(len(raw))
   p=self.directory/(str(len(self.refs)).zfill(5)+"_"+kind+".json")
   with p.open("xb") as f:
    f.write(raw);f.flush();os.fsync(f.fileno())
   if report:self.report_bytes+=len(raw)
   else:self.output_bytes+=len(raw)
   os.fsync(self.dirfd)
   reread=p.read_bytes()
   if reread!=raw:raise ValueError("saved bytes mismatch")
   strict(json.loads(reread),value)
   ref={"path":str(p),"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}
   self.refs.append(ref);self.pending=None
   return ref
  except BaseException as e:
   primary=e;self.exceptions.append(e);self.errors.append({"role":"save_primary","traceback":traceback.format_exc()})
   raise
  finally:
   self.io_used+=time.monotonic()-start
   self.clock.stop()
   if primary is None and not self.failed:
    try:self.clock.enter("compute")
    except BaseException as secondary:
     self.exceptions.append(secondary);self.errors.append({"role":"save_exit_secondary","traceback":traceback.format_exc()})
     raise


 def load(self):
  self.check()
  for p,h in PINS.items():
   if sha(p)!=h:raise ValueError("source pin mismatch: "+p)
  spec=importlib.util.spec_from_file_location("chain_witness_pinned",WITNESS)
  self.module=importlib.util.module_from_spec(spec)
  spec.loader.exec_module(self.module)
  self.functions=self.module.load_fixed_prior(PRIOR)
  self.old=json.loads(OLD.read_bytes())
  before_id=identity(RAW);h=hashlib.sha256();selected_bytes=0
  with RAW.open("rb") as f:
   for index,line in enumerate(f):
    self.check();h.update(line)
    if index in ROWS:
     if len(line)>2097152:raise MemoryError("raw line stop")
     selected_bytes+=len(line)
     if selected_bytes>8388608:raise MemoryError("selected raw stop")
     value=json.loads(line)
     self.raw_rows[index]={"row0":index,"line_sha256":hashlib.sha256(line).hexdigest(),"raw_line":line.decode("utf-8"),"value":value}
  if identity(RAW)!=before_id or h.hexdigest()!=PINS[str(RAW)] or tuple(sorted(self.raw_rows))!=ROWS:
   raise ValueError("whole source closure failure")
  self.source_closure={"identity":before_id,"sha256":h.hexdigest()}
  phases=sum(len(v["value"]["data"]["frame"]) for v in self.raw_rows.values())
  if phases>256:raise MemoryError("phase stop before measurement")
  for row in ROWS:self.raw_refs[row]=self.save("rawrow",self.raw_rows[row])

 def phase(self,row,index):
  self.check();self.cursor={"stage":"phase","row":row,"phase":index}
  frame=self.raw_rows[row]["value"]["data"]["frame"][index]
  current={"row":row,"phase":index,"raw_reference":self.raw_refs[row],"result":None,"error":None}
  self.phases.append(current)
  try:current["result"]=self.module.phase_witnesses(frame,self.functions)
  except (ValueError,TypeError,IndexError,KeyError,StopIteration) as e:
   self.exceptions.append(e)
   current["error"]={"type":type(e).__name__,"message":str(e),"traceback":traceback.format_exc(),"counts":getattr(e,"measured_counts",None)}
   # Resource admission refusal stops the entire run, not just this phase.
   if hasattr(e,"measured_counts"):raise
  ref=self.save("phase",current)
  return current,ref

 def derive(self):
  self.load();all_projection=[]
  for target in TARGETS:
   before=target-1;before_phases=[]
   for i in range(len(self.raw_rows[before]["value"]["data"]["frame"])):
    before_phases.append(self.phase(before,i))
   self.suffix.remove(before)
   frozen,before_ref=before_phases[-1]
   transition=progress(self.raw_rows[before]["value"],self.raw_rows[target]["value"])
   group={"target_row":target,"before_phases":[r for _,r in before_phases],"metadata_transition":transition,"after_phases":[]}
   for i in range(len(self.raw_rows[target]["value"]["data"]["frame"])):
    current,ref=self.phase(target,i)
    linkage={"before_reference":before_ref,"after_reference":ref,"relation":None,"comparisons":[],"unknown":[]}
    if frozen["result"] is None or current["result"] is None:
     linkage["unknown"].append("phase_parse_unknown")
    else:
     a,b=frozen["result"],current["result"];relation=correlate(a,b);linkage["relation"]=relation
     if not a["witnesses"] or not b["witnesses"]:linkage["unknown"].append("zero_candidates")
     for witness in a["witnesses"]:
      rid=witness["root_index"];mapping=relation["roots"][rid];reasons=list(witness["unknown"])
      if sum(l["根"]["色"]==witness["candidate"]["凡例根色"] for l in b["scene"]["凡例"])!=1:reasons.append("after_legend_color_ambiguous")
      if not relation["legend_exact_equal"]:reasons.append("old_legend_scope_changed")
      if not mapping["unique_hypothesis"]:reasons.append("root_correspondence_ambiguous")
      observed=None;paths=[]
      if mapping["unique_hypothesis"]:
       paths=b["observed_chains"][mapping["after_root_indices"][0]]["候補経路"]
       if len(paths)>1:reasons.append("after_multiple_paths")
       if b["scene"]["未対応画素"]:reasons.append("after_unparsed_pixels")
       if not reasons:observed=paths[0]["列"]==witness["candidate"]["候補列"] if paths else witness["candidate"]["候補列"]==[]
      item={"before_ordinal":witness["ordinal"],"joint_before_features":witness["joint_before_features"],
       "after_paths":paths,"observed_root_sequence_equal":observed,"unknown":reasons,
       "row_public_progress":transition["public_progress"],
       "old_scope_link_unknown":list(transition["unknown"])+["same_legend_does_not_prove_same_problem_phase"],
       "old_scope_observed_sequence_equal":None,
       "completion_teacher_eligible":False,"old_completion_label":None}
      linkage["comparisons"].append(item)
      all_projection.append({"row":target,"phase":i,"before_reference":before_ref,"after_reference":ref,**item})
    linkref=self.save("phase_link",linkage)
    group["after_phases"].append({"phase":i,"phase_reference":ref,"link_reference":linkref})
   self.suffix.remove(target);self.groups.append(group);self.save("group",group)
  # Audit multiplicities, without mapping a direct observation into an unproved old label.
  counts={}
  for i,t in enumerate(self.old["教師群"]):
   key=json.dumps(t,ensure_ascii=False,separators=(",",":"))
   counts.setdefault(key,[]).append(i)
  old_counts=[{"teacher":json.loads(k),"indices":v,"multiplicity":len(v)} for k,v in counts.items()]
  comparison={"old_complete_records":old_counts,"all_observed_projection":all_projection,
   "old_to_raw_exact_mapping":None,"status":"UNKNOWN","reason":"Original generator/witness identity missing; no chosen phase, deduplication, count fitting or AND result",
   "independent_support_added":0}
  cref=self.save("old46_comparison",comparison)
  self.cursor={"stage":"terminal","row":None,"phase":None}
  terminal={"schema":"chain46-raw-witness-terminal-v1","nonce":self.gate["nonce"],"source_closure":self.source_closure,
   "groups":self.groups,"comparison":cref,"suffix":self.suffix,"parse_errors":[x["error"] for x in self.phases if x["error"]],
   "HDS_calls":0,"teacher_provenance_proved":False,"limits":"Completed evidence inventory, not teacher correctness or native learning"}
  ref=self.save("terminal",terminal,True);self.complete=True;return ref

 def failure(self):
  self.failed=True
  original_pending=self.pending
  try:
   self.save("failure",{"cursor":self.cursor,"suffix":self.suffix,"errors":self.errors,
       "saved_references":self.refs,"pending_kind":self.pending["kind"] if self.pending else None,
       "RAM_retained":"Original pending packet, raw_rows, all phase objects, modules and exceptions remain in OWNER"},True)
  except BaseException as e:
   self.exceptions.append(e);self.errors.append(traceback.format_exc())
  finally:
   self.pending=original_pending

def unique_json(raw):
 def pairs(items):
  out={}
  for k,v in items:
   if k in out:raise ValueError("duplicate JSON key")
   out[k]=v
  return out
 return json.loads(raw,object_pairs_hook=pairs)

def bounded_ref(ref,cap):
 if type(ref) is not dict or set(ref)!={"path","bytes","sha256"}:raise ValueError("exact reference shape")
 p=Path(ref["path"])
 if p.is_symlink() or not p.is_file() or type(ref["bytes"]) is not int or not 0<=ref["bytes"]<=cap or p.stat().st_size!=ref["bytes"]:raise ValueError("reference admission")
 raw=p.read_bytes()
 if len(raw)!=ref["bytes"] or hashlib.sha256(raw).hexdigest()!=ref["sha256"]:raise ValueError("reference bytes/SHA")
 return unique_json(raw)

def verify_ack(ack):
 if OWNER is None or not OWNER.complete or OWNER.failed or STATE["errors"]:raise ValueError("failed or incomplete owner cannot close")
 if ack.get("schema")!="chain46-raw-witness-root-ack-v1" or ack.get("decision")!="ACK" or ack.get("nonce")!=OWNER.gate["nonce"]:raise ValueError("ACK identity")
 if ack.get("source_sha256")!=OWNER.gate["source_sha256"]:raise ValueError("ACK caller pin")
 strict(ack["terminal"],STATE["terminal_reference"])
 audit=bounded_ref(ack["independent_audit"],65536)
 if audit.get("schema")!="chain46-raw-witness-independent-v1" or audit.get("status")!="PASS" or audit.get("nonce")!=OWNER.gate["nonce"] or audit.get("errors")!=[]:raise ValueError("audit identity/status")
 strict(audit["terminal"],STATE["terminal_reference"])
 if audit.get("source_sha256")!=OWNER.gate["independent_audit_source_sha256"]:raise ValueError("audit source pin")
 expected={"all_eight_raw_rows","all_phases_and_errors","all_candidates_and_multiplicity","full_types_order","scope_unknowns_preserved","old46_not_forced"}
 if set(audit.get("verified",{}))!=expected or any(v is not True for v in audit["verified"].values()):raise ValueError("full audit scope")
 return ack

def hold_for_ack():
 path=OWNER.directory/("root_ack_"+OWNER.gate["nonce"]+".json")
 last=None
 while True:
  if path.exists():
   st=path.lstat();identity=(st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns)
   if identity!=last:
    last=identity
    try:
     if path.is_symlink() or not path.is_file() or st.st_size>16384:raise ValueError("ACK file bound")
     raw=path.read_bytes();ack=verify_ack(unique_json(raw))
     STATE["ack"]=ack
     print(json.dumps({"status":"closed_after_root_ack","nonce":OWNER.gate["nonce"],"terminal":STATE["terminal_reference"]}),flush=True)
     return
    except BaseException as error:
     STATE["exceptions"].append(error)
     record={"identity":identity,"traceback":traceback.format_exc()}
     STATE["ack_rejections"].append(record)
     print(json.dumps({"status":"ACK_rejected","record":record}),flush=True)
  time.sleep(5)

def run(gate_path,gate_sha):
 global OWNER
 if OWNER is not None:raise RuntimeError("already owned")
 clock=Deadline();STATE["clock"]=clock
 try:
  clock.enter("compute")
  soft,hard=resource.getrlimit(resource.RLIMIT_AS)
  if not (0<soft<=536870912 and 0<hard<=536870912):raise ValueError("positive finite AS512 soft/hard required before import")
  if sha(gate_path)!=gate_sha:raise ValueError("gate hash")
  gate=unique_json(Path(gate_path).read_bytes());STATE["gate"]=gate
  if gate.get("schema")!="chain46-raw-witness-release-v1" or gate.get("enabled") is not True:raise ValueError("gate")
  if gate.get("source_sha256")!=sha(__file__):raise ValueError("caller binding")
  if gate.get("pins")!=PINS:raise ValueError("all pins")
  auditor=gate.get("independent_audit_source_sha256")
  if type(auditor) is not str or len(auditor)!=64 or any(c not in "0123456789abcdef" for c in auditor):raise ValueError("future auditor exact pin required")
  if gate.get("compute_seconds")!=1200 or gate.get("save_seconds")!=300:raise ValueError("time budget")
  if type(gate.get("nonce")) is not str or len(gate["nonce"])!=32 or any(c not in "0123456789abcdef" for c in gate["nonce"]):raise ValueError("nonce")
  if time.time()>gate["admission_deadline_epoch"]:raise TimeoutError("admission")
  guard()
  OWNER=Run.__new__(Run);STATE["owner"]=OWNER
  Run.__init__(OWNER,gate)
  OWNER.setup()
  ref=OWNER.derive();STATE["terminal_reference"]=ref;clock.stop()
  print(json.dumps({"status":"complete_held","terminal":ref}),flush=True)
 except BaseException as e:
  clock.stop();STATE["exceptions"].append(e);STATE["errors"].append(traceback.format_exc())
  if OWNER is not None and hasattr(OWNER,"errors"):
   OWNER.exceptions.append(e);OWNER.errors.append({"role":"run_primary","traceback":STATE["errors"][-1]})
   try:OWNER.failure()
   except BaseException as secondary:
    STATE["exceptions"].append(secondary);STATE["errors"].append(traceback.format_exc())
   finally:clock.stop()
  print(json.dumps({"status":"failed_held","errors":STATE["errors"],"owner_errors":getattr(OWNER,"errors",None),"cursor":getattr(OWNER,"cursor",None),"suffix":getattr(OWNER,"suffix",None)}),flush=True)
 finally:clock.stop()
 # All original exception objects/traceback frames remain owned on every failure.
 if OWNER is not None and OWNER.complete and not OWNER.failed and not STATE["errors"]:
  return hold_for_ack()
 while True:time.sleep(60)
