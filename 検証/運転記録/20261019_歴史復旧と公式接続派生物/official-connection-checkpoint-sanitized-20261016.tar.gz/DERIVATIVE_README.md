# 公式接続checkpoint・公開証拠の安全化派生物

これは original official-connection-checkpoint.tar.gz と同一の原archiveではありません。
原archiveは変更せず、既存のLibrary/local保存に保持しています。現在の原payloadは1,305,364 bytes、SHA256 8be89e9ba3e64f174a362acd9c231267cee2f8afe4541bd73d5a3f52d823fa9bです。さらに古い原archive同一性の照合値は未取得です。

## この派生物の構成
- 原archiveの1,137 member本文はbyte不変で保存
- 公開download metadataとそのtool receiptの2 JSON memberにあるcookie header値を、それぞれ1か所、明示的なREDACTED markerへ置換
- SDK/native stdout/stderrのopaque member54本は除外。本文は開いていません。元manifestが宣言するmember名、bytes、SHA256だけをDERIVATIVE_MANIFEST.jsonに保存
- 本書とDERIVATIVE_MANIFEST.jsonを追加。後者がこの派生物の構成・変更・除外の正本です

原manifest.json、README.mdおよびその他の原receiptは歴史的な由来の証拠としてbyte不変で残しています。それらにある「opaqueを収録した」「原bytesのhash」等の記載は原archiveを記述します。変更/除外を行った本派生物の完全性証明として読んではいけません。除外対象への旧参照は、本文の存在や閲覧可能性を意味しません。

## 成立範囲
公開鎖recordingの946行・2,110 frameと、公式25ゲームの初期観測27 frame等を保持します。全25のlevels_completedは0です。metadata win_levels合計183は攻略数ではありません。新規clear、通常Actionによる攻略、HDS学習、未見転用、runtime採用を主張しません。
165相の保存測定・監査は歴史的証拠です。旧46教師との正確な対応と完成ラベルの来歴は未証明のままです。初回v3 FAIL、SDK_IO診断、synthetic失敗fixture、旧版sourceを改変・削除して成功扱いにしていません。
opaque本文の未検査をhash-only許可で代替していません。cookieの認証上の意味も断定しません。ゲーム/SDK実装本文、native HDS/Query/Teach/SDK/Actionを今回読解・実行していません。
