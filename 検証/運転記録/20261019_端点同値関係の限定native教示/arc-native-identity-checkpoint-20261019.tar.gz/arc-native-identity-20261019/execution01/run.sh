#!/bin/bash
cd /workspace/scratch/a94ff513b3af
python arc-native-identity-20261019/execution01/source.py > arc-native-identity-20261019/execution01/stdout.log 2> arc-native-identity-20261019/execution01/stderr.log
s=$?; printf '%s\n' "$s" > arc-native-identity-20261019/execution01/exit_status.txt; exit "$s"
