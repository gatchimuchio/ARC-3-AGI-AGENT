"""ONE parent-admitted run, exact frozen config; no retry path."""
import pathlib,json,hashlib,shutil,sys,resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
sys.dont_write_bytecode=True
R=pathlib.Path(__file__).resolve().parent.parent;B=R.parent
EXPECTED='41ca6c242d9dc751dd2759c654b5b94960eaee18e1da62e629625ac48555804d'
raw=(R/'proposed_config.json').read_bytes();assert hashlib.sha256(raw).hexdigest()==EXPECTED
config=json.loads(raw);assert config['explicit_parent_admission'] is False
review=json.loads((R/'execution01/reviewed_manifest.json').read_bytes());assert review['config_sha256']==EXPECTED and review['all64pins_match']
for p,h in config['pins'].items():assert hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()==h,p
old=json.loads((B/'arc-native-teach-final-20261019/freeze_manifest.json').read_bytes())
for p,m in old['files'].items():
 path=B/p;assert path.stat().st_size==m['bytes'] and hashlib.sha256(path.read_bytes()).hexdigest()==m['sha256'],p
retained={p:sum(f.stat().st_size for f in pathlib.Path(p).rglob('*') if f.is_file()) for p in config['retained_directories']}
prep=sum(f.stat().st_size for f in R.rglob('*') if f.is_file());assert prep+168*1024**2+7*1024**2<176*1024**2
assert sum(retained.values())+176*1024**2<512*1024**2
assert shutil.disk_usage(R).free>=1024**3+168*1024**2
admission={'authority':'explicit parent one-run admission received2026-10-19T03:28:50UTC','config_sha256':EXPECTED,'calls':75,'sequence':'30Query/15processing/30Query','resource':config['resource'],'actual_retained_bytes':retained,'actual_preparation_bytes':prep,'free_bytes_before':shutil.disk_usage(R).free,'old_frozen_files_reverified':len(old['files']),'review_manifest_sha256':hashlib.sha256((R/'execution01/reviewed_manifest.json').read_bytes()).hexdigest(),'scope':'paired-observation value-copy only; no Action/adoption/generalization','automatic_retry':False}
(R/'execution_admission.json').write_text(json.dumps(admission,ensure_ascii=False,indent=2)+'\n')
# Only in-memory copy carries consumed admission; reviewed config unchanged.
config['explicit_parent_admission']=True;sys.path.insert(0,str(R));import launcher
result=launcher.execute(config)
(R/'native_supervisor.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
assert (R/'proposed_config.json').read_bytes()==raw
print(json.dumps(result,ensure_ascii=False));raise SystemExit(0 if result['status']=='PASS' else 2)
