import pathlib,json,hashlib
R=pathlib.Path(__file__).resolve().parent.parent
files={}
for p in sorted(R.rglob('*')):
 if not p.is_file() or p.name=='freeze_manifest.json' or p.parent.name=='closure01' and p.name in ('stdout.log','stderr.log','exit_status.txt'):continue
 files[str(p.relative_to(R))]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
report={'status':'NATIVE75_COMPLETE_PRODUCER_PASS_INDEPENDENT_OUTCOME_REVIEW_PENDING','config_sha256':hashlib.sha256((R/'proposed_config.json').read_bytes()).hexdigest(),'files':files,'total_bytes_excluding_manifest_and_closure_logs':sum(x['bytes'] for x in files.values()),'omissions':['freeze_manifest.json self','closure01 stdout/stderr/exit_status created by this closing run; retained separately'],'native_call_count':75,'further_native_calls_authorized':False,'raw_state_file_count':18,'evidence_records':243,'all_previous_frozen181files_unchanged':True}
(R/'freeze_manifest.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
