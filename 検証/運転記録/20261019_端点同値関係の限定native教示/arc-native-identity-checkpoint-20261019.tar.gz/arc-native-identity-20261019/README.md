# Scoped identity75-call caller proposal

OFFLINE PREPARATION ONLY. No native import/restore/Query/Teach/save, no168MiB reservation, no SDK/Action/Git. Parent must admit the final reviewed config separately.

## Exact experiment

Source post_state.reserve from successful prior pilot:189 experiences,19 principle versions, Query/learning counters6698,5,558,643B SHA3a0e57e44cf2385f70be34bd5908bb9b78de0c7251b3a688d2d27b5e1d21ad84. New isolated descendant only. Exact30Query/15処理する/30 identical Query.19state slots:normal,before,15after-teacher,post,failure. Successful path writes18 full snapshots and225 call records =243 evidence frames. Unknown/partial frontier retained; no automatic retry.

Measurement source is arc-identity-teacher-plan-20261019/revision03_target_endpoint, independently passed. All600 cells/6Actions/112phases retained outside runtime.15group teachers are5 informative historical interventions from2recordings,0new environmental observations. Missing/wrong-type inputs are caller rejection tests, not native outcomes.30queries contain11 scoped identity diagnostics (7observed values,4unseen-color algebraic probes) plus19 old smoke rows across10boundaries. Unseen-color queries are not environmental transfer evidence. Four directed identity lineages are analytically possible, not assumed outcomes.

## Provenance and interpretation

The before-reference-prefix terminal-pair selector is NEW FIXED OBSERVATION PROTOCOL. Role parsing, static BEFORE template, Action5 role hypothesis and mask membership are fixed priors. Only the measured value identity would be HDS learned if actual native outputs/ledgers confirm it. Dynamic device pixels are not asserted stable. All intermediate unknowns remain; no continuous object identity, preservation, whole-environment stability, future persistence, causal necessity, learned mask/rotation/composition or Action permission follows. Changed reference atphase15 resets any future current-goal interpretation.

## Reuse and narrowly scoped changes

Actual bootstrap-passed binding.py SHA43574797de492ef1a49b7498ee23a4ac410935b6c1dc0432baa7b43b17a52720, gate_metadata, source_allowlist and Guard are exact successful-pilot copies. No new native bootstrap implementation. Launcher changes exact plan/order/counters/state slots/baseline/total limits. NativeSaveSink allowlist extends six teacher slots to15; single-use ownership/caps unchanged. Caller validates exact constructor keys, metadata, new boundary leaf names and strict integer0..15 color domain before bootstrap. Caller evidence wrapper enforces8KiB input/postinput,64KiB output,16KiB snapshot index and256B frame header, before append. Native source closure unchanged and pinned.

Before each pure execution, source/script are retained in a fresh leaf; stdout/stderr and exit_status are durable.21 provided pure tests passed. Initial caller omitted new save-sink slots; reviewer reproduced seventh-save HOLD and all sources remain pre_fix01. repair01 failed a source-replacement assertion before writes; exact source/logs/exit1 retained, repair02 succeeded. Independent caller review will test the corrected real sink, not merely mocked saves. No failure is treated as successful native execution.

## Resources and caps

Independent static bound:full state7,221,324B <8MiB; complete reply60,103B. We deliberately tighten the earlier128KiB proposed output cap to64KiB. This keeps75×65536+150×8192+19×16384+244×264=6,519,712B evidence active prefix below8MiB, retaining original logical FSIZE8MiB. The evidence region is still preallocated12MiB, but reviewed closed-code writes are below8MiB. No physical-preallocation-survives-native-truncate guarantee is made.

Proposed176MiB new unit =19×8MiB state slots +12MiB evidence +4×1MiB metadata/worker-failure/emergency/supervisor +8MiB code/reports. AS512MiB CPU120s wall240s, free floor1GiB plus allocation. Original earlier attempts and all new measurement/review artifacts remain untouched. Proposed named-retention aggregate512MiB; measured prior retained281,516,940B +full176MiB future unit =466,066,316B at config freeze, leaving review-growth margin. Final prelaunch must remeasure all pins/retained bytes/free floor and retain sidecar admission without mutating reviewed config. Full failure-state retention remains bounded best effort under documented ENOSPC/OS/resource limitations, never guaranteed by preallocation alone.

## Gates still open

Final independent caller/source/config review and explicit parent execution admission. No runtime adoption or fresh Action is authorized by any static/pure PASS. Complete actual reports must compare every before/after Query, all15 native judgments, all ledger/history prefixes, support/refutation/adoption, four possible lineages, unseen-value diagnostics and19-row smoke projections/raw differences, with actual resource/frontier records.
