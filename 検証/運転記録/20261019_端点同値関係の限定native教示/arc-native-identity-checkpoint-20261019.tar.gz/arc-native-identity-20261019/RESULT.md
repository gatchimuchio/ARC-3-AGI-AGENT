# Actual bounded native value-identity result

Status: producer audit complete; independent outcome review pending. One admitted75-call run, no retry. Config41ca6c242d9dc751dd2759c654b5b94960eaee18e1da62e629625ac48555804d stayed immutable. Fixed HDSv0.4.2 actual API, isolated descendant, no SDK/Action/Git/core change.

## Observed result

30Query +15処理する +30Query all entered, returned and fully persisted.225call records plus18full-state indexes =243evidence frames. No incomplete frontier.19single-use state slots retained, including unused failure slot.

Before: all11 scoped identity queries returned native状態=出力 with empty predictions; this was not native HOLD. After: all7 observed-value and4 unseen-color diagnostics return one exact expected endpoint value. Inside source colors0/12/14 and unseen1/2; outside0/8/12/15 and unseen1/2. Unseen cases demonstrate native identity substitution within the declared observation boundary, not fresh environment/game transfer.

Native learned4 directed 同値関係 lineages: outside prior→endpoint and reverse; inside tool→endpoint and reverse. Each has2versions,8new principle records total. This is2paired relation families, not4 independently acquired action primitives. Actual adoption calls are teacher4/7/9/11. Teacher judgments in order:接続途上,接続途上,接続途上,成立確認,接続途上,接続途上,成立確認,接続途上,成立確認,接続途上,成立確認,接続途上,接続途上,接続途上,接続途上. The eleven non-adaptation judgments are retained, not relabeled failures or success.

Final active outside principles22/23 retain support experiences190/192/193/195/196. Active inside principles26/27 retain191/194/198/200. All have empty refutation lists. Later repeated correspondence observations remain in the ledger but do not refresh the stored principle support when its table is unchanged; do not claim all15new experiences appear in active support lists.

## Preservation and smoke comparisons

All189 original observations,19 original principle records and every prior ledger/history prefix remain byte-meaning equal in all saved checkpoints. Query-only batches change exactly照会 and学習判定 by30 each, nothing else. Final204experiences/27principle versions; paired counters6698→6728→6758. All19 old smoke relevant projections are equal, including6goal6/4controls/9historical queries across10boundaries. Full raw replies differ due new global principle summaries/state/counter/trace fields; complete originals and differences are retained. This is not exhaustive prior-success regression.

Full delta:15observation,15cognitive,75doubt,15learning,15feedback,22inference,22evidence,22judgment,8principle,8provisional,8update records;4state snapshots added to native history. Complete append payloads and support/refutation/history changes are in native_full_delta.json.

## Actual resources and retention

Wall19.550615941s; child peakRSS86,976KiB under512MiB AS. CPU120s enforced, actual CPU seconds not separately recorded. State5,558,643→6,116,344B (+557,701), below7,221,324B proved envelope and8MiB slots. Largest reply43,111B below60,103B proof/64KiB gate. Evidence active prefix3,121,785B below6,519,712B bound; full12MiB region including zeros retained.168MiB logical original reservations retained as actual files; native save truncates physical state allocations, so smaller actual directory size does not authorize slot reuse.

Measured own unit131,879,529B before final reports; named retained+unit426,183,377B before final reports, below176MiB/512MiB limits. Final freeze provides later exact file totals. All64config pins and181previously frozen attempt/diagnostic/final-pilot files reverified after completion. Prior native bootstrap failures, selector failures, source-validation fixes, and seventh-save mock failure remain intact. No guarantee of complete physical evidence survival under ENOSPC/truncate/OS failure is claimed.

## Meaning of the result

This is actual learned value equality between paired public observations under revision03's fixed target-observation protocol. Endpoint selection is new fixed observation logic; role/action hypotheses, mask geometry and object parsing remain priors. The last-two-before-reference-change protocol never matches predicted colors or falls back to an earlier fitting frame. Complete unknown intermediate phases and device changes remain; no continuous object identity, continuous MASK preservation, unique causal mechanism, learned geometry/rotation/composition, future persistence or Action permission is established. Phase15 goal rebinding is a separate current-goal reset condition for any future work.

15native experiences summarize5informative historical Actions across2recordings; all6Actions/600cells/112phases are retained,150ambiguous cells remain unlabelled,0new environmental observations. No runtime adoption or new live action follows from this bounded learning experiment.
