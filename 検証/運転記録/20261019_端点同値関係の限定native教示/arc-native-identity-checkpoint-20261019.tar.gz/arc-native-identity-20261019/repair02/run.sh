#!/bin/bash
cd /workspace/scratch/a94ff513b3af
python arc-native-identity-20261019/repair02/source.py > arc-native-identity-20261019/repair02/stdout.log 2> arc-native-identity-20261019/repair02/stderr.log
s=$?; printf '%s\n' "$s" > arc-native-identity-20261019/repair02/exit_status.txt; exit "$s"
