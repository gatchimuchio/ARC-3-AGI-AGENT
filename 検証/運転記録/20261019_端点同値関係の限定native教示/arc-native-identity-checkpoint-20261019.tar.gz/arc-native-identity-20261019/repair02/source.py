from pathlib import Path
R=Path(__file__).resolve().parent.parent
p=R/'bounded_store.py';s=p.read_text();assert "'teach_06_state','post_state'" in s;s=s.replace("'teach_06_state','post_state'", "'teach_06_state',"+",".join(repr(f"teach_{i:02d}_state") for i in range(7,16))+",'post_state'");p.write_text(s)
p=R/'launcher.py';s=p.read_text()
s=s.replace("  from source_allowlist import PERSISTENCE_SHA256\n  machine,",'''  # Validate exact native constructor and new measurement-domain payloads before bootstrap.
  for i,(method,payload) in enumerate(frozen_plan):
   p=json.loads(payload)
   if type(p)is not dict or set(p)!={'内容','対象系境界','主体','対象','目的','文脈'}:raise HOLD('constructor keys')
   if type(p['内容'])is not dict or type(p['文脈'])is not dict or p['文脈']!={} or any(p[k]is not None for k in ('主体','対象','目的')):raise HOLD('constructor metadata')
   if i<11 or 30<=i<45 or 45<=i<56:
    prefix='公開塗布端点:作用前識別可能・固定幾何'
    if p['対象系境界'] not in (prefix+'内',prefix+'外'):raise HOLD('identity measurement boundary')
    source='作用前器具色' if p['対象系境界']==prefix+'内' else '作用前対象色'
    keys={source,'同一問題端点対象色'} if method=='処理する' else {source}
    if set(p['内容'])!=keys or any(type(v)is not int or not 0<=v<=15 for v in p['内容'].values()):raise HOLD('identity measurement color scope')
  def persist(name,payload):
   cap=16384 if name.startswith('snapshot.') else (65536 if name.endswith('.output') else 8192)
   if type(payload)is not bytes or len(payload)>cap:raise HOLD('record byte bound: '+name)
   header=json_bytes({'name':name,'bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest()})
   if len(header)>256:raise HOLD('record header byte bound')
   store.append('evidence',name,payload)
  from source_allowlist import PERSISTENCE_SHA256
  machine,''')
s=s.replace("lambda n,b:store.append('evidence',n,b)","persist")
s=s.replace("store.append('evidence','snapshot.'+region,json_bytes(delta));previous=current","persist('snapshot.'+region,json_bytes(delta));previous=current")
p.write_text(s);print('Applied exact19-slot save allowlist and caller-only scope/frame gates; native binding unchanged.')
