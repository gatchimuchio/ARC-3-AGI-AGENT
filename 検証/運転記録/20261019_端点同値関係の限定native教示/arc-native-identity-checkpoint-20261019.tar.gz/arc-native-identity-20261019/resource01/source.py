"""Read-only final resources/pins/reservation prefix audit, no HDS."""
import pathlib,json,hashlib,struct,sys,resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2);sys.dont_write_bytecode=True
R=pathlib.Path(__file__).resolve().parent.parent;B=R.parent
cfg=json.loads((R/'proposed_config.json').read_bytes());audit=json.loads((R/'result_audit.json').read_bytes());slots=[]
for p in sorted((R/'run01').glob('*.reserve')):
 b=p.read_bytes();h=hashlib.sha256(b).hexdigest();entry={'name':p.name,'bytes':len(b),'sha256':h}
 if p.stem.endswith('_state') and b[:1]==b'{':entry.update({'format':'native_full_json','valid_prefix_bytes':len(b),'frames':[]})
 else:
  offset=0;frames=[]
  while b[offset:offset+8]!=b'\0'*8 and offset<len(b):
   length=struct.unpack('>Q',b[offset:offset+8])[0];assert 0<length<=1024
   meta=json.loads(b[offset+8:offset+8+length]);payload=b[offset+8+length:offset+8+length+meta['bytes']];assert hashlib.sha256(payload).hexdigest()==meta['sha256']
   frames.append({'offset':offset,'header_bytes':length,**meta});offset+=8+length+meta['bytes']
  assert not any(b[offset:]);entry.update({'format':'framed_or_unused_zero_reservation','valid_prefix_bytes':offset,'zero_tail_verified':True,'frames':frames})
 slots.append(entry)
for p,h in cfg['pins'].items():assert hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()==h
old=json.loads((B/'arc-native-teach-final-20261019/freeze_manifest.json').read_bytes())
for p,m in old['files'].items():assert hashlib.sha256((B/p).read_bytes()).hexdigest()==m['sha256'] and (B/p).stat().st_size==m['bytes']
retained={p:sum(f.stat().st_size for f in pathlib.Path(p).rglob('*') if f.is_file()) for p in cfg['retained_directories']};unit=sum(f.stat().st_size for f in R.rglob('*') if f.is_file())
ev=next(s for s in slots if s['name']=='evidence.reserve');assert ev['valid_prefix_bytes']<=6519712 and len(ev['frames'])==243
assert audit['full_state_max_bytes']<=7221324 and audit['max_reply_bytes']<=60103
assert unit<176*1024**2 and unit+sum(retained.values())<512*1024**2
summary={'new_active_principles':[{k:p[k] for k in ('原理識別子','系譜識別子','版','関係型','対象系境界','条件経路群','結果経路','対応値表','根拠参照群','反証参照群','適用範囲')} for p in audit['new_active_principles']],'before_identity_prediction_counts':[len(c['before']['内容']['予測群']) for c in audit['query_comparisons'][:11]],'before_identity_statuses':[c['before']['状態'] for c in audit['query_comparisons'][:11]],'identity_diagnostics':[{'index':c['query_index'],'kind':c['kind'],'expected':c['identity_expected_value'],'actual':c['identity_prediction_values']} for c in audit['query_comparisons'][:11]]}
res={'status':'ALL_PRODUCER_RESOURCE_AND_PREFIX_CHECKS_PASS_REVIEW_PENDING','native_calls':75,'complete_evidence_frames':243,'full_snapshots':18,'state_slots':19,'evidence_used_bytes':ev['valid_prefix_bytes'],'evidence_capacity_bytes':12*1024**2,'full_state_max_bytes':audit['full_state_max_bytes'],'state_bound_bytes':7221324,'max_reply_bytes':audit['max_reply_bytes'],'reply_bound_bytes':60103,'peak_child_rss_kib':audit['entered_returned_persisted']['peak_rss_KiB'],'wall_seconds':audit['supervisor']['wall_seconds'],'cpu_seconds':'not separately measured;120s enforced','fixed_reservations_bytes':168*1024**2,'unit_measured_bytes_before_final_reports':unit,'retained_measured_bytes':retained,'aggregate_measured_bytes':unit+sum(retained.values()),'old_frozen181files_reverified':len(old['files']),'all64configpins_reverified':True}
for n,v in [('reserve_prefix_index.json',slots),('identity_result_summary.json',summary),('resource_validation.json',res)]: (R/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(res,ensure_ascii=False));print(json.dumps({'active_identity_relations':[{'id':p['原理識別子'],'kind':p['関係型'],'version':p['版'],'support':p['根拠参照群'],'refutation':p['反証参照群']} for p in audit['new_active_principles']]},ensure_ascii=False))
