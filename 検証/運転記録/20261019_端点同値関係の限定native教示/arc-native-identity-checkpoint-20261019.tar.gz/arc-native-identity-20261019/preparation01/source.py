"""Prepare exact75-call derivative only. No native import/execute/allocation."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parent.parent;B=R.parent;OLD=B/'arc-native-teach-final-20261019'
for n in ('binding.py','bounded_store.py','gate_metadata.py','source_allowlist.py','guard.py','read_run.py','test_guard.py','test_import_attributes.py'):(R/n).write_bytes((OLD/n).read_bytes())
s=(OLD/'launcher.py').read_text();changes=[('range(1,7)','range(1,16)'),("'evidence':8*M","'evidence':12*M"),('==92*M','==168*M'),("STATE=ROOT.parent/'arc-native-query-20261019/query_retry02/poststate.json'","STATE=ROOT.parent/'arc-native-teach-final-20261019/run01/post_state.reserve'"),("('照会する',)*19+('処理する',)*6+('照会する',)*19","('照会する',)*30+('処理する',)*15+('照会する',)*30"),('frozen_plan[:19]!=frozen_plan[25:]','frozen_plan[:30]!=frozen_plan[45:]'),("len(plan)!=44 or sum(k=='処理する' for k,b in plan)!=6","len(plan)!=75 or sum(k=='処理する' for k,b in plan)!=15"),('exact44/6/38 plan','exact75/15/60 plan'),("expected['照会']+=19;expected['学習判定']+=19","expected['照会']+=30;expected['学習判定']+=30"),('if i==18:','if i==29:'),('elif 19<=i<=24:','elif 30<=i<=44:'),('i-18:02d','i-29:02d'),("!=189:raise HOLD('nominal", "!=204:raise HOLD('nominal"),('total_limit=96*M','total_limit=176*M')]
for a,b in changes:
 assert a in s,a;s=s.replace(a,b)
(R/'launcher.py').write_text(s)
(R/'derivative_changes.json').write_text(json.dumps({'origin':str(OLD/'launcher.py'),'origin_sha256':hashlib.sha256((OLD/'launcher.py').read_bytes()).hexdigest(),'replacements':changes,'exact_copies':{n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in ('binding.py','bounded_store.py','gate_metadata.py','source_allowlist.py','guard.py','read_run.py')}},ensure_ascii=False,indent=2)+'\n')
print('Prepared only; native closure untouched and unexecuted.')
