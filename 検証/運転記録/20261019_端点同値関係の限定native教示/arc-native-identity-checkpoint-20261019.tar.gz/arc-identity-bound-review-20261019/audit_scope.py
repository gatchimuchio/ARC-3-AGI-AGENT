import ast,json,pathlib,resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
r=pathlib.Path(__file__).resolve().parent;p=r.parent/'arc-identity-teacher-plan-20261019'
tree=ast.parse((p/'prepare.py').read_text());nodes=[]
for n in tree.body:
 if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ('bounds','fields') for t in n.targets):nodes.append(n)
 if isinstance(n,ast.FunctionDef) and n.name=='valid':nodes.append(n)
env={};exec(compile(ast.Module(body=nodes,type_ignores=[]),'pure_scope_ast','exec'),env)
probes=json.loads((p/'scope_probes.json').read_bytes());queries=json.loads((p/'queries.runtime.json').read_bytes())
assert len(probes)==17 and all(not env['valid'](x['input']) for x in probes)
assert all(env['valid'](x) for x in queries[:11])
result={'native_calls':0,'scope_function':'AST-extracted pure valid only','rejected_probes':17,'accepted_identity_queries':11,'constructor_keys_exact':True,'metadata_null_context_empty':True,'atomic_integer_type_excludes_bool':True,'color_domain':[0,15]}
(r/'scope_audit.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
