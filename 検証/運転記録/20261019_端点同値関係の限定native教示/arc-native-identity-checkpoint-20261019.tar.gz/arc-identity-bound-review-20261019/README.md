# Independent identity-teacher static resource review

## Verdict

BOUNDED PASS for the frozen 75-call plan's static state-growth, input, external-reply and evidence byte envelopes. This is NOT native execution admission, measurement/witness approval, runtime endpoint adoption, exhaustive regression, or an assertion that storage/allocator failures are survivable. No native imports, restoration, persistence, Query, Teach, SDK, Action, Git operation or native allocation occurred. Pure JSON/AST execution used512MiB AS; independent audit peak RSS30,416KiB and this directory is below96MiB.

Owner directive and both additions, nearest AGENTS, authority hierarchy and current state were reread. HDS v0.4.2 remains frozen; strategy null and automatic transition false.

## Frozen inputs and independent checks

Baseline: arc-native-teach-final-20261019/run01/post_state.reserve,5,558,643 bytes, SHA2563a0e57e44cf2385f70be34bd5908bb9b78de0c7251b3a688d2d27b5e1d21ad84. It has189 experiences,19 principle ledger versions,16 current active lineages and paired Query counters6698. It remains external read-only; an additional copied baseline is not implicitly budgeted.

Independent audit.py/audit.json verifies:
- Every existing dataclass field and its order exactly matches frozen 型.py. No restoration default expansion is omitted. All7 top-level persisted fields are accounted for.
- Both new measurement boundaries are absent from every existing observation AND all principle-history versions.
- Exact plan equals30 queries,15 teachers, identical30 queries, totaling75 calls. All constructor keys are exact, metadata null and context an empty strict dictionary. Content is flat and uses non-reserved string keys.
- All15 teachers have exactly two integer leaves, both strictly int (not bool), values0..15 and equal. First11 identity queries have exactly one strictly integer leaf0..15. Existing19 smoke inputs remain their original boolean/string types.
- Maximum input wire size501bytes, atom JSON50bytes, path JSON62bytes, boundary JSON152bytes, new lineage JSON142bytes. Padding limits therefore dominate escaped native wire width as well as UTF-8 width.
- AST-only extraction of prepare.py's valid function rejects all17 malformed scope probes and accepts all11 identity queries. This is caller HOLD evidence, not native HOLD evidence. The14 initial probes were expanded to17; revised artifacts are reviewed, revision01 remains retained.

Pins:
- teachers.runtime.json:1d27d471a7d5efdd1074c5430638f792ec74fbf7eabf8d881375e8f84176ded2
- queries.runtime.json:4ff3e70c818e4dbbeef23cd80c37be67a091a7201b8d643a1ffd7ce01e9e7cc5
- proposed_plan.json:515215779e1332406643a4144c6c0ca538b5c699af7189b4399e4b1a98c4a58d
- static_bound.py:cb6e7261c36fe89f7974487060ce42353d95ae7ddf80d5087096fff65b53471c
- refine_bound.py:26407e98516872820bc1b94008f1a33dd9d94bbf12d52801d91dc179b02a0900
- reply_bound.py:359529035e8875355d86aa12af58c0606ed1f553daee6149463c17eef3458636

All12 frozen native source hashes are in audit.json. The copied bound scripts were executed only as pure data/envelope analysis in this separate review directory; no HDS code was imported or called. Both coarse and refined results remain retained.

## Complete branch/count reasoning

Each new boundary has exactly2 inferred leaves plus2 intake metadata observations. Frozen inference enumerates both directions, each with one condition. Because all corresponding values are strictly equal integers, both relations are 同値関係. For each boundary, minimum support3 and at least2 distinct source values activate both directed candidates. Independent prefix analysis gives22 candidate events total. New values change tables on4 teacher calls; both directions are adopted on each, giving8 adoptions and4 state snapshots. There are4 distinct directed lineages, each with2 versions. Distinct result paths prevent the redundancy branch between opposite directions.

No old-boundary audit can mutate an existing principle. Equal pairs cannot refute either new identity relation, including newly seen colors because identity evidence uses value equality rather than only table membership. No isolated parent exists, so specialization/reopening branches are excluded. No excluded-experience continuation exists. Two inferred paths do not cross maximum2-condition residual threshold. Verification receives complete equal pairs and enough distinct values, so candidate verification has no contrary evidence. Queries do not append ledgers; they increment paired counters only, to at most6758.

Repeated evidence after an unchanged identity table does NOT create a new principle version or refresh its stored support references. Every teacher still contributes experience, doubts and learning records, and every candidate still contributes inference/evidence/judgment records. Support tuples are bounded by15 (actual largest new boundary10), candidate/adoption/update references by2, doubts by5. The six-digit IDs and scalar/version limits are conservative; the doubt counter's945→1020 width change is covered by structural slack.

## Serialization bound

The correct wire codec uses dataclass/enum/dictionary/tuple wrappers with ensure_ascii=False and indent2. Explicit envelopes retain actual field names, nested shapes, all old snapshot entries plus4 padded new lineages,15 support references,15 table rows, and sufficient dynamic string/enum/timestamp/ID widths. False is used for boolean-width dominance. Escaped source literals are checked. Every record root is shallower than padded depth12. The128-byte per-record slack covers sibling separators; additional32KiB covers new history dictionary entries, wrapper punctuation and counter-width growth.

Refined bound is a sum of conservative padded record shapes, NOT compression, deletion, shallow sampling or observed-size extrapolation:
5,558,643 baseline
+15*60,951 base records (experience+cognitive+5doubts+learning+completion)
+22*10,502 candidate records (inference+evidence+judgment)
+8*55,215 adoption records (2 full principle copies+provisional+update)
+4*10,721 full state snapshots
+32,768 structural slack
=7,221,324 bytes <8,388,608.

The earlier13,357,427-byte all-records32KiB estimate is retained as a looser valid bound. The refined improvement comes solely from summing explicit shape-specific upper bounds. Partial failures, including history or ledger appended before state update, cannot exceed these event totals. This byte proof does not guarantee sufficient RAM or successful finalization.

## Reply/evidence bound and allocation

All16 old active projections remain in external replies; maximum active count20 after4 new lineages. No isolated principle exists. Independent final grouping shows every (boundary,result path) group singleton, including the reverse identities. Therefore neither conflicting predictions nor global ambiguity groups can arise in this frozen sequence. Maximum2 principles match one boundary. Identity can copy unseen values; these are bounded atomic integers in this plan, and do not provide new environmental observations.

The envelope includes all16 exact old summaries+4 padded new summaries,2 predictions and2 observation requests simultaneously,6 HOLD reasons, and union of Teach/Query trace fields. Reproduced external-output upper bound60,103bytes < proposed128KiB cap. Empty conflict/ambiguity/isolation arrays follow the proven singleton/no-refutation facts, not a blanket assumption of successful native output.

75*128KiB replies +150*8KiB input/postinput +19*16KiB snapshot indices +244*(256+8) framing =11,434,912bytes <12MiB. This is conditional on the final caller retaining only the planned records and using the stated bounded snapshot/frame formats; arbitrary extra full-state deltas are not included.

Proposed new-unit ceiling176MiB:19 single-use8MiB state slots (normal,before,15 teacher,post,failure)=152MiB;12MiB evidence;four disjoint1MiB log/failure regions;8MiB code/input/report/partial-write allowance. Fixed reservations168MiB. Existing bytes and all earlier partial allocations within that unit must be measured before actual admission. No occupied slot may be reused or discarded. External old source/state remain read-only. Any larger or extra output requires renewed admission.

## Remaining admission boundaries

Final native caller, exact input/source bindings, resource limit enforcement, per-frame/index maxima, aggregate existing-byte measurement, failure frontier retention and explicit parent authorization require separate closure. Free-space floors/preallocation do not guarantee ENOSPC, allocator, kernel or machine-failure retention. Unknown frontier remains UNKNOWN; automatic resumption is forbidden.

This review does not validate the historical phase13/14 measurement choice or450-cell grouping; the evidence reviewer owns that. Their role remains qualified historical endpoint observations, not a generic runtime final-effect selector. Seven observed and4 unseen algebraic queries plus19 smoke rows do not establish exhaustive prior-success regression, fresh-instance causal transfer, mask/role learning or Action safety. Preserve all actual replies and negative/HOLD/failure outcomes.
