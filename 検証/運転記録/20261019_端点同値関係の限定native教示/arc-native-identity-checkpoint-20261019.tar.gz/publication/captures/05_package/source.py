from pathlib import Path,PurePosixPath
import hashlib,json,tarfile,gzip,resource,os,stat,shutil
resource.setrlimit(resource.RLIMIT_AS,(268435456,268435456))
B=Path("/workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019/publication_native_identity")
W=B.parent.parent
P=json.loads((B/'payload_manifest.json').read_text())
I=json.loads((B/'inspection_manifest.json').read_text())
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while z:=f.read(1048576): h.update(z)
 return h.hexdigest()
assert P['file_count']==399 and P['raw_bytes']==160290700
assert digest(B/'payload_manifest.json')=='24d1a5708e61a1877d1efa60a18c6605938cb0b2a6049610de58e5a373f8cddc'
assert (B/'inspection_runs/a017_seal/exitstatus.txt').read_text()=='0\n'
assert digest(B/'README.md')=='fcf0b274d11f744c129a02e988438b8ce3e56ce8212265cd8a2990d6a084fe28'
entries={}
def add(p,name,n=None,sha=None):
 p=Path(p)
 assert not p.is_symlink() and p.is_file()
 assert p.resolve().is_relative_to(W.resolve())
 assert '..' not in PurePosixPath(name).parts and not name.startswith('/')
 assert name not in entries
 assert 'disclosure_' not in name and 'canonical' not in name.lower()
 actual=(p.stat().st_size,digest(p))
 if n is not None: assert actual==(n,sha),(str(p),actual)
 entries[name]=(p,*actual)
for f in P['files']:
 assert f['archive_path'].split('/')[0] in P['closed_roots']
 add(f['source'],f['archive_path'],f['bytes'],f['sha256'])
for name,n,sha in I['files']: add(B/name,'publication/'+name,n,sha)
for name in ['README.md','resource_ledger.json','payload_manifest.json','inspection_manifest.json']:
 add(B/name,'publication/'+name)
for leaf in ['00_authority_inventory','01_manifest_shapes','02_freeze_closed_roots','03_readme_precision','04_prerelease_readback']:
 for p in sorted((B/'captures'/leaf).iterdir()):
  add(p,'publication/'+str(p.relative_to(B)))
add(B/'captures/05_package/source.py','publication/captures/05_package/source.py')
A={'schema':'arc3-native-identity-archive-allowlist-v1','status':'LOCAL_ONLY_GIT_PAUSED','payload_files':399,'payload_raw_bytes':160290700,'member_fields':['path','bytes','sha256'],'entries':[[k,v[1],v[2]] for k,v in sorted(entries.items())],'self_exclusion':'This manifest excludes its own hash; the external verification records the manifest member hash.','scope':'Only six explicit closed producer/reviewer roots and this identity unit admission/publisher evidence. No recursive recovery-root collection. All private disclosure/history audits and their receipts excluded.','capture_limits':'Package source included before execution; its final stdout/stderr/status and archive verification are external later receipts. Earlier shell listing was metadata-only and has no exact persisted execution capture.'}
ap=B/'archive_manifest.json'; ap.write_text(json.dumps(A,ensure_ascii=False,separators=(',',':'))+'\n')
add(ap,'publication/archive_manifest.json')
out=B/'arc-native-identity-checkpoint-20261019.tar.gz'
assert not out.exists()
class CapWriter:
 def __init__(self,f): self.f=f; self.n=0
 def write(self,z):
  assert self.n+len(z)<=4194304,'archive cap'
  r=self.f.write(z);self.n+=r;return r
 def flush(self):self.f.flush()
with out.open('xb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=CapWriter(raw),mtime=0,compresslevel=9) as gz:
  with tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT) as tf:
   for name,(p,n,sha) in sorted(entries.items()):
    assert p.stat().st_size==n and digest(p)==sha
    info=tarfile.TarInfo(name);info.size=n;info.mode=0o644;info.mtime=0;info.uid=info.gid=0;info.uname=info.gname=''
    with p.open('rb') as f: tf.addfile(info,f)
expected={k:(v[1],v[2]) for k,v in entries.items()}
seen={}
with gzip.open(out,'rb') as gz:
 with tarfile.open(fileobj=gz,mode='r|') as tf:
  for m in tf:
   assert m.isfile() and m.name in expected and m.name not in seen
   h=hashlib.sha256(); n=0
   with tf.extractfile(m) as f:
    while z:=f.read(1048576):n+=len(z);h.update(z)
   assert (n,h.hexdigest())==expected[m.name],m.name
   seen[m.name]=(n,h.hexdigest())
 while gz.read(1048576): pass
assert seen==expected
for f in P['files']: assert digest(Path(f['source']))==f['sha256']
b=out.read_bytes()
v={'schema':'arc3-native-identity-archive-verification-v1','status':'PASS_LOCAL_ONLY','archive':{'path':str(out),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob_sha1':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()},'archive_members':len(seen),'uncompressed_member_bytes':sum(n for n,h in seen.values()),'all_members_exact':True,'all399_originals_unchanged':True,'gzip_full_stream_crc_eof':True,'disclosure_private_roots_excluded':True,'no_native_execution':True,'Git_writes':0,'AS_limit_bytes':268435456,'max_rss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'manifest_sha256':digest(ap),'inspector_manifest_sha256':digest(B/'inspection_manifest.json'),'external_receipts':'This verification and package stdout/stderr/exitstatus were created after archive bytes, and are retained separately; no circular self-certification.'}
(B/'archive_verification.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
metadata=sum(p.stat().st_size for p in B.rglob('*') if p.is_file() and p!=out)
assert metadata<=1048576,metadata
assert shutil.disk_usage(B).free>=1073741824
print(json.dumps(v,ensure_ascii=False))
print('metadata_bytes',metadata)
