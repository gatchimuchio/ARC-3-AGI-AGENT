import pathlib,json
W=pathlib.Path('/workspace/scratch/a94ff513b3af')
rels=['arc-operation-teacher-contract-20261019/MANIFEST.json','arc-identity-teacher-plan-20261019/MANIFEST.json','arc-identity-teacher-plan-20261019/MANIFEST_v2.json','arc-identity-teacher-plan-20261019/MANIFEST_v3.json','arc-identity-teacher-plan-20261019/revision02_target_endpoint/MANIFEST.json','arc-identity-teacher-plan-20261019/revision03_target_endpoint/MANIFEST.json','arc-identity-teacher-review-20261019/FINAL_TARGET_REVIEW_MANIFEST.json','arc-native-identity-20261019/freeze_manifest.json','arc-identity-launch-review-20261019/reviewed_manifest.json','arc-identity-launch-review-20261019/final_execution_audit/verified_evidence_manifest.json']
for rel in rels:
 d=json.loads((W/rel).read_text());f=d['files'];print(rel,'type',type(f).__name__,'n',len(f),'first',json.dumps(next(iter(f.items())) if isinstance(f,dict) else f[0],ensure_ascii=False),'exclusions',d.get('omissions',d.get('excluded_live_execution_leaf')))
for rel in ['arc-native-identity-20261019/RESULT.md','arc-identity-launch-review-20261019/final_execution_audit/README.md']:
 print('REPORT',rel);print((W/rel).read_text())
