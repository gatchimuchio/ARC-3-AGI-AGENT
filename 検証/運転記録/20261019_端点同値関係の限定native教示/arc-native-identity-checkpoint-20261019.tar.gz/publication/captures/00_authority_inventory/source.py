import pathlib,json,hashlib,shutil,resource,datetime
resource.setrlimit(resource.RLIMIT_AS,(256*1024**2,256*1024**2))
W=pathlib.Path('/workspace/scratch/a94ff513b3af');R=W/'arc-preservation-recovery-20261019';U=R/'publication_native_identity'
for rel in ['authority/Owner指示書原文_20261009.md','authority/Owner追加指示原文_20261010T1907.md','authority/Owner追加指示原文_20261011T1904.md','main/AGENTS.md','main/運用/権限順序.md','main/制御/現在状態.json']:
 p=R/rel;b=p.read_bytes();print('AUTHORITY',rel,len(b),hashlib.sha256(b).hexdigest());print(b.decode())
archives=sum(p.stat().st_size for p in R.rglob('*') if p.is_file() and p.name.endswith(('.tar.gz','.tar.xz')))
metadata=sum(p.stat().st_size for p in R.rglob('*') if p.is_file() and not p.name.endswith(('.tar.gz','.tar.xz')))
assert archives+4194304+12467596<=83886080 and metadata+1048576<=16777216
mem={line.split(':')[0]:int(line.split()[1])*1024 for line in pathlib.Path('/proc/meminfo').read_text().splitlines() if ':' in line and line.split()[1].isdigit()}
ledger={'schema':'arc3-native-identity-preservation-resource-v1','created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive_cap':4194304,'metadata_cap':1048576,'global_archives_now':archives,'global_metadata_now':metadata,'possible_missing_mirror_recovery_reserved':12467596,'global_archive_cap':83886080,'global_metadata_cap':16777216,'packager_AS':268435456,'inspector_AS':268435456,'combined_validation_AS':536870912,'disk_free':shutil.disk_usage(R).free,'disk_floor':1073741824,'MemAvailable':mem.get('MemAvailable'),'memory_floor':2147483648,'native_execution':False,'Git_writes_paused':True,'reason':'Local-only admission of completed identity checkpoint while historical HDS-original scope is resolved'}
with (U/'resource_ledger.json').open('x') as f:json.dump(ledger,f,indent=2);f.write('\n')
print('LEDGER',json.dumps(ledger))
roots=['arc-operation-teacher-contract-20261019','arc-identity-teacher-plan-20261019','arc-identity-teacher-review-20261019','arc-identity-bound-review-20261019','arc-native-identity-20261019','arc-identity-launch-review-20261019']
for root in roots:
 files=[p for p in (W/root).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
 print('ROOT',root,'files',len(files),'bytes',sum(p.stat().st_size for p in files))
 for p in files:
  if 'manifest' in p.name.lower() or p.name in ['README.md','RESULT.md','verdict.json']:
   d=json.loads(p.read_text()) if p.suffix=='.json' else None
   print('BOUNDARY',str(p.relative_to(W)),p.stat().st_size,('keys '+str(list(d.keys())) if isinstance(d,dict) else 'text'))
