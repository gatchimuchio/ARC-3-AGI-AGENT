from pathlib import Path
import json,hashlib
B=Path("/workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019/publication_native_identity")
R=B.parent
for name in ['authority/Owner指示書原文_20261009.md','authority/Owner追加指示原文_20261010T1907.md','authority/Owner追加指示原文_20261011T1904.md','main/AGENTS.md','main/運用/権限順序.md','main/制御/現在状態.json']:
 p=R/name; b=p.read_bytes(); print('\n###',name,len(b),hashlib.sha256(b).hexdigest()); print(b.decode())
for name in ['README.md','resource_ledger.json','payload_admission.json','inspection_manifest.json']:
 p=B/name; b=p.read_bytes(); print('\n###',name,len(b),hashlib.sha256(b).hexdigest()); print(b.decode())
m=json.loads((B/'payload_manifest.json').read_text()); print('PAYLOADSHAPE',list(m)); print(json.dumps(m,ensure_ascii=False)[:1500])
