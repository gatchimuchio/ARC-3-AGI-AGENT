import pathlib,json,hashlib,resource
resource.setrlimit(resource.RLIMIT_AS,(256*1024**2,256*1024**2))
W=pathlib.Path('/workspace/scratch/a94ff513b3af');U=W/'arc-preservation-recovery-20261019/publication_native_identity'
roots=['arc-operation-teacher-contract-20261019','arc-identity-teacher-plan-20261019','arc-identity-teacher-review-20261019','arc-identity-bound-review-20261019','arc-native-identity-20261019','arc-identity-launch-review-20261019']
def ident(p):
 h=hashlib.sha256();n=0
 with p.open('rb') as f:
  while b:=f.read(65536):n+=len(b);h.update(b)
 return {'bytes':n,'sha256':h.hexdigest()}
rows=[];excluded=[]
for root in roots:
 for p in sorted((W/root).rglob('*')):
  assert not p.is_symlink(),str(p)
  if p.is_file():
   x={'source':str(p),'archive_path':str(p.relative_to(W)),**ident(p)}
   if '__pycache__' in p.parts or p.suffix=='.pyc':excluded.append({**x,'reason':'Derived bytecode cache; original own source retained; no bytecode semantics claim'})
   else:rows.append(x)
by_source={x['source']:x for x in rows}
manifest_paths=['arc-operation-teacher-contract-20261019/MANIFEST.json','arc-identity-teacher-plan-20261019/MANIFEST.json','arc-identity-teacher-plan-20261019/MANIFEST_v2.json','arc-identity-teacher-plan-20261019/MANIFEST_v3.json','arc-identity-teacher-plan-20261019/revision02_target_endpoint/MANIFEST.json','arc-identity-teacher-plan-20261019/revision03_target_endpoint/MANIFEST.json','arc-identity-teacher-review-20261019/FINAL_TARGET_REVIEW_MANIFEST.json','arc-native-identity-20261019/freeze_manifest.json','arc-identity-launch-review-20261019/reviewed_manifest.json','arc-identity-launch-review-20261019/final_execution_audit/verified_evidence_manifest.json']
checks=[]
for rel in manifest_paths:
 p=W/rel;d=json.loads(p.read_text());files=d['files'];files=[{'path':k,**v} for k,v in files.items()] if isinstance(files,dict) else files
 verified=[];external=[]
 for x in files:
  path=pathlib.Path(x['path']);target=path if path.is_absolute() else ((W/path) if path.parts[0] in roots else p.parent/path)
  target=target.resolve();entry=by_source.get(str(target))
  if entry is None:external.append({'path':str(target),'reference':x});continue
  assert all(entry[k]==x[k] for k in ['bytes','sha256']),(rel,x['path'])
  verified.append(str(target.relative_to(W)))
 checks.append({'manifest':rel,**ident(p),'verified_included_entries':len(verified),'external_or_not_included':external})
assert ident(W/'arc-native-identity-20261019/freeze_manifest.json')['sha256']=='4bd1a68fded11a3550510b55c3b7a2084056a13bf682258fd105443d7f38c32d'
assert ident(W/'arc-identity-launch-review-20261019/final_execution_audit/audit_report.json')['sha256']=='5c947a10ff99bb85d537a2849621d8eb3746e0164665defb18256d21397a10d4'
d={'schema':'arc3-native-identity-closed-payload-v1','base_main':'2ca6531908551755988ade040840362684c96b14','status':'AWAITING_CONTENT_ADMISSION_LOCAL_ONLY','closed_roots':roots,'closure_authority':'Root and producer messages explicitly close these six roots and all original revisions; native105-file freeze plus own closure01 receipts retained. No unfinished unrelated root included.','files':rows,'file_count':len(rows),'raw_bytes':sum(x['bytes'] for x in rows),'excluded_derived_files':excluded,'manifest_checks':checks,'native_calls_by_packager':0,'Git_writes_by_packager':0,'limits':'Chronological source manifests are preserved as original partial freezes. Full closed-root allowlist is this additive manifest, not a claim that every historical pre-fix source was captured. Prior181-file pilot and core are referenced, not duplicated.'}
with (U/'payload_manifest.json').open('x') as f:json.dump(d,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({'file_count':d['file_count'],'raw_bytes':d['raw_bytes'],'excluded_derived_files':len(excluded),'manifest_checks':[{'manifest':x['manifest'],'verified':x['verified_included_entries'],'external':len(x['external_or_not_included'])} for x in checks]},ensure_ascii=False))
