import pathlib,hashlib,difflib,json
R=pathlib.Path('/workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019/publication_native_identity');D=pathlib.Path(__file__).parent;p=R/'README.md';before=p.read_bytes();(D/'before_README.md').write_bytes(before);s=before.decode()
a='最終revision03は「参照条件が切り替わる前の最後の2相」等を用いる新しい固定観測手続である。'
b='最終revision03は「BEFORE参照が保たれる連続prefix末尾2相（切替がない場合はpacket末尾）」を用いる新しい固定観測手続である。今回phase15で参照が再結合するのはcase4/5である。'
c='認証済みfresh成功は引き続き1/183、フルゲームWINは未達。'
d='別の既存検証で確認された基準はfresh成功1/183、フルゲームWIN未達のままである。この399-file内容監査がfresh能力を再測定したものではない。'
assert s.count(a)==1 and s.count(c)==1
new=s.replace(a,b).replace(c,d);p.write_text(new)
print(json.dumps({'before_bytes':len(before),'before_sha256':hashlib.sha256(before).hexdigest(),'after_bytes':len(p.read_bytes()),'after_sha256':hashlib.sha256(p.read_bytes()).hexdigest()},ensure_ascii=False));print(''.join(difflib.unified_diff(s.splitlines(True),new.splitlines(True),fromfile='README.before',tofile='README.after')))
