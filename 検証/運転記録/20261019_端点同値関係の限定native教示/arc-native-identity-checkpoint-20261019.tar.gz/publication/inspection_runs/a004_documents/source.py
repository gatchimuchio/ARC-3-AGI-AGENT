import json,hashlib
from pathlib import Path
R=Path("/workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019")
m=json.loads((R/"publication_native_identity/payload_manifest.json").read_bytes())
seen=set()
for e in m["files"]:
 if not e["source"].endswith(".md") or e["sha256"] in seen: continue
 seen.add(e["sha256"]); p=Path(e["source"]);print("=== "+e["archive_path"]+" ==="); print(p.read_text())
print("OWN_CAPTURE_BYTES_SO_FAR",sum(x.stat().st_size for x in (R/"publication_native_identity/inspection_runs").rglob("*") if x.is_file()))
