import json,hashlib
from pathlib import Path
R=Path("/workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019");P=R/"publication_native_identity"
p=P/"README.md";b=p.read_bytes()
print("PUBLISHER_SUMMARY",len(b),hashlib.sha256(b).hexdigest())
for line in b.decode().splitlines():
 if "最終revision03" in line or "fresh" in line or "phase15" in line:print(line)
print("OWN_BYTES",sum(x.stat().st_size for x in (P/"inspection_runs").rglob("*") if x.is_file()))
