import json,collections,re,hashlib,struct,resource
from pathlib import Path
R=Path("/workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019")
m=json.loads((R/"publication_native_identity/payload_manifest.json").read_bytes())
seen=set();counts=collections.Counter();longs={};hits=[];bad=[];reserves=[]
patterns={"email":re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}"),"credential":re.compile(r"(?i)(?:AKIA[0-9A-Z]{16}|sk-[A-Za-z0-9]{20,}|gh[pousr]_[A-Za-z0-9]{20,}|BEGIN .*PRIVATE KEY|(?:password|api[_-]?key|access[_-]?token|cookie|authorization)\s*[:=]\s*['\"]?[^\s'\"]{8,})"),"network":re.compile(r"https?://[^\s'\"]+")}
def scan(s,path,structured=False):
 counts["strings"]+=1;counts["string_chars"]+=len(s)
 if structured and len(s)>=180:longs.setdefault(hashlib.sha256(s.encode()).hexdigest(),[len(s),path,s[:220]])
 for kind,rx in patterns.items():
  for hit in rx.finditer(s):
   if len(hits)<100:hits.append([kind,path,hit.group(0)[:150]])
def walk(x,path):
 if isinstance(x,dict):
  for k,v in x.items():scan(k,path+"/<key>",True);walk(v,path+"/"+k)
 elif isinstance(x,list):
  for i,v in enumerate(x):walk(v,path+"/"+str(i))
 elif isinstance(x,str):scan(x,path,True)
def zeros(f):
 for b in iter(lambda:f.read(65536),b""):assert not any(b),"nonzero tail"
for e in m["files"]:
 p=Path(e["source"]);name=e["archive_path"]
 if p.suffix==".reserve" or e["sha256"] in seen:continue
 seen.add(e["sha256"])
 try:s=p.read_text()
 except Exception as x:bad.append([name,"nontext",str(x)]);continue
 counts["unique_text_files"]+=1
 if p.suffix==".json":
  try:walk(json.loads(s),name);counts["unique_json_files"]+=1
  except Exception as x:bad.append([name,"json",str(x)])
 else:scan(s,name)
for e in m["files"]:
 p=Path(e["source"]);name=e["archive_path"]
 if p.suffix!=".reserve":continue
 with p.open("rb") as f:first=f.read(1)
 if first==b"{":
  d=json.loads(p.read_bytes());walk(d,name);counts["full_states"]+=1
  reserves.append([name,"full_json",p.stat().st_size,list(d.keys())])
 elif "synthetic12MiB" in name:
  pos=[];nz=collections.Counter();offset=0
  with p.open("rb") as f:
   for b in iter(lambda:f.read(65536),b""):
    for i,v in enumerate(b):
     if v:nz[v]+=1
     if v and len(pos)<10:pos.append(offset+i)
    offset+=len(b)
  reserves.append([name,"synthetic",dict(nz),pos])
 else:
  frames=[];offset=0
  with p.open("rb") as f:
   while True:
    head=f.read(8)
    if not head:break
    if head==bytes(8):zeros(f);break
    assert len(head)==8
    n=struct.unpack(">Q",head)[0];assert 0<n<=1024,(name,offset,n)
    h=json.loads(f.read(n));assert h["bytes"]<=8388608
    payload=f.read(h["bytes"]);assert len(payload)==h["bytes"]
    assert hashlib.sha256(payload).hexdigest()==h["sha256"]
    try:walk(json.loads(payload),name+"/"+h["name"])
    except (ValueError,UnicodeDecodeError):scan(payload.decode(),name+"/"+h["name"])
    frames.append([h["name"],h["bytes"]]);offset+=8+n+h["bytes"]
  reserves.append([name,"framed",offset,len(frames),p.stat().st_size-offset,frames[:2],frames[-2:]])
  counts["frames"]+=len(frames)
print("COUNTS",dict(counts),"BAD",bad)
print("RESERVES",json.dumps(reserves,ensure_ascii=False))
print("LONG_STRUCTURED_STRINGS",json.dumps(sorted(longs.values(),reverse=True)[:20],ensure_ascii=False))
print("SCAN_CANDIDATES",json.dumps(hits,ensure_ascii=False))
print("SYNTHETIC_SOURCE",next(Path(e["source"]).read_text() for e in m["files"] if e["archive_path"]=="arc-identity-launch-review-20261019/run04/check_fsize.py"))
print("MAXRSS_KIB",resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
print("OWN_BYTES",sum(x.stat().st_size for x in (R/"publication_native_identity/inspection_runs").rglob("*") if x.is_file()))
