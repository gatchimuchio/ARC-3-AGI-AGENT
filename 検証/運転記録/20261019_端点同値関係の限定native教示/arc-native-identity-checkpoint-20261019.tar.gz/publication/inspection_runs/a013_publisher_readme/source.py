from pathlib import Path
import hashlib
R=Path("/workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019")
p=R/"publication_native_identity/README.md";b=p.read_bytes()
print("PUBLISHER_SUMMARY_OUTSIDE_399",len(b),hashlib.sha256(b).hexdigest());print(b.decode())
print("OWN_BYTES",sum(x.stat().st_size for x in (R/"publication_native_identity/inspection_runs").rglob("*") if x.is_file()))
