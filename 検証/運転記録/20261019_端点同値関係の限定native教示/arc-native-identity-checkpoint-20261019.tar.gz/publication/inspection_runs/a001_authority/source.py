import os,json,hashlib
from pathlib import Path
R=Path("/workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019")
paths=[R/"authority/Owner指示書原文_20261009.md",R/"authority/Owner追加指示原文_20261010T1907.md",R/"authority/Owner追加指示原文_20261011T1904.md",R/"main/AGENTS.md",R/"main/運用/権限順序.md",R/"main/制御/現在状態.json"]
data=[(str(p),p.read_bytes()) for p in paths]
assert sum(len(b) for _,b in data)<110000, "authority capture budget exceeded"
for p,b in data:
 print("=== "+p+" bytes="+str(len(b))+" sha256="+hashlib.sha256(b).hexdigest()+" ===")
 print(b.decode("utf-8"))
