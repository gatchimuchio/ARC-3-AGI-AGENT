import json,hashlib
from pathlib import Path
R=Path("/workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019")
m=json.loads((R/"publication_native_identity/payload_manifest.json").read_bytes())
p=next(Path(e["source"]) for e in m["files"] if e["archive_path"]=="arc-operation-teacher-contract-20261019/inspection_failure_history.txt")
print("INITIAL_SOURCE_HOLE",p.read_text())
pub=R/"publication_native_identity";print("OWN_CAPTURE_BYTES",sum(x.stat().st_size for x in (pub/"inspection_runs").rglob("*") if x.is_file()))
print("DOCUMENT_COUNTS",sum(e["source"].endswith(".md") for e in m["files"]),len({e["sha256"] for e in m["files"] if e["source"].endswith(".md")}))
