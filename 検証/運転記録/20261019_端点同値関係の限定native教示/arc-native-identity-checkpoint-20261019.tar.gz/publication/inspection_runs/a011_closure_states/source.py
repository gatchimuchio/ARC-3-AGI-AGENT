import json,hashlib,struct,collections,resource
from pathlib import Path
R=Path("/workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019")
m=json.loads((R/"publication_native_identity/payload_manifest.json").read_bytes())
entries={e["archive_path"]:e for e in m["files"]}
def get(s):return Path(entries[s]["source"])
def data(s):return json.loads(get(s).read_bytes())
P="arc-native-identity-20261019/"
freeze=data(P+"freeze_manifest.json")
assert entries[P+"freeze_manifest.json"]["sha256"]=="4bd1a68fded11a3550510b55c3b7a2084056a13bf682258fd105443d7f38c32d1"
assert len(freeze["files"])==105
for name,v in freeze["files"].items():
 e=entries[P+name];assert (e["bytes"],e["sha256"])==(v["bytes"],v["sha256"])
audit="arc-identity-launch-review-20261019/final_execution_audit/audit_report.json"
assert entries[audit]["sha256"]=="5c947a10ff99bb85d537a2849621d8eb3746e0164665defb18256d21397a10d4"
assert data(audit)["verdict"]=="BOUNDED_NATIVE_IDENTITY_EVIDENCE_PASS"
review=data(P+"execution01/reviewed_manifest.json");resolved={}
for name,v in review["files"].items():
 candidates=[e["archive_path"] for e in m["files"] if e["bytes"]==v["bytes"] and e["sha256"]==v["sha256"] and Path(e["archive_path"]).name==name]
 assert candidates,(name,v)
 preferred=P+name
 assert preferred in candidates
 resolved[name]=preferred
def state(n):return dict(data(P+"run01/"+n+".reserve")["__辞書__"])
names=["normal_state","before_state"]+["teach_%02d_state"%i for i in range(1,16)]+["post_state"]
base=state(names[0]);prev=None;rows=[]
for name in names:
 s=state(name);led=dict(s["台帳"]["__辞書__"]);bl=dict(base["台帳"]["__辞書__"])
 for k,v in bl.items():assert led[k]["__組__"][:len(v["__組__"])]==v["__組__"],(name,k,"base prefix")
 if prev is not None:
  pl=dict(prev["台帳"]["__辞書__"])
  for k,v in pl.items():assert led[k]["__組__"][:len(v["__組__"])]==v["__組__"],(name,k,"previous prefix")
 for k in ("形式版","最小支持数","最大条件数"):assert s[k]==base[k]
 c=dict(s["識別子状態"]["__辞書__"])
 rows.append([name,len(led["観測台帳"]["__組__"]),len(led["原理台帳"]["__組__"]),c["照会"],c["学習判定"]])
 if name in ("before_state","post_state"):
  assert {k:v for k,v in s.items() if k!="識別子状態"}=={k:v for k,v in prev.items() if k!="識別子状態"}
  pc=dict(prev["識別子状態"]["__辞書__"])
  for k,v in c.items():assert v-pc[k]==(30 if k in ("照会","学習判定") else 0)
 prev=s
print("FREEZE105_VERIFIED","OUTCOME_AUDIT_PIN_PASS","LOGICAL_PINS",json.dumps(resolved))
print("STATE_ROWS",json.dumps(rows),"ROOT_KEYS",list(base))
idx={x["name"]:x for x in data(P+"reserve_prefix_index.json")}
for name,ix in idx.items():
 if ix["format"]=="native_full_json":assert get(P+"run01/"+name).stat().st_size==ix["valid_prefix_bytes"];continue
 frames=[];offset=0
 with get(P+"run01/"+name).open("rb") as f:
  while True:
   head=f.read(8)
   if not head or head==bytes(8):break
   n=struct.unpack(">Q",head)[0];h=json.loads(f.read(n));f.seek(h["bytes"],1)
   frames.append({"offset":offset,"header_bytes":n,**h});offset+=8+n+h["bytes"]
 assert offset==ix["valid_prefix_bytes"]
 assert frames==ix["frames"],name
print("RESERVE_INDEX_EXACT",len(idx),"MAXRSS_KIB",resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
print("OWN_BYTES",sum(x.stat().st_size for x in (R/"publication_native_identity/inspection_runs").rglob("*") if x.is_file()))
