import json,ast,collections
from pathlib import Path
R=Path("/workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019")
m=json.loads((R/"publication_native_identity/payload_manifest.json").read_bytes())
lookup={e["archive_path"]:Path(e["source"]) for e in m["files"]}
for name in ["arc-native-identity-20261019/read_run.py","arc-native-identity-20261019/reserve_prefix_index.json","arc-native-identity-20261019/execution01/reviewed_manifest.json"]:
 p=lookup[name];print("INSPECT",name)
 if p.suffix==".json":
  d=json.loads(p.read_bytes());print(json.dumps(d,ensure_ascii=False)[:4200])
 else:print(p.read_text())
s=lookup["arc-native-identity-20261019/bounded_store.py"].read_text()
for i,line in enumerate(s.splitlines(),1):
 if any(w in line for w in ("struct.","MAGIC","header","FRAME","append_record","read_record")):print("FORMAT",i,line)
seen=set();bad=[];big=[];count=0
for e in m["files"]:
 if not e["source"].endswith(".py") or e["sha256"] in seen:continue
 seen.add(e["sha256"]);s=Path(e["source"]).read_text();count+=1
 try:t=ast.parse(s)
 except SyntaxError as x:bad.append([e["archive_path"],x.lineno,x.msg]);continue
 for n in ast.walk(t):
  if isinstance(n,ast.Constant) and isinstance(n.value,str) and len(n.value)>350:big.append([e["archive_path"],n.lineno,len(n.value),n.value[:80]])
print("SOURCE_TOTAL",count,"parse_failures",bad,"long_literals",big)
print("OWN_BYTES",sum(x.stat().st_size for x in (R/"publication_native_identity/inspection_runs").rglob("*") if x.is_file()))
