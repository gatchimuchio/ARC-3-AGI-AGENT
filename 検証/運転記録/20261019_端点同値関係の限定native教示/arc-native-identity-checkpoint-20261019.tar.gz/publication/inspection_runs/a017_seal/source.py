import json,hashlib
from pathlib import Path
P=Path("/workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019/publication_native_identity")
leaf=Path(__file__).parent
assert not (leaf/"exitstatus.txt").exists()
assert (leaf/"stdout.txt").stat().st_size==(leaf/"stderr.txt").stat().st_size==0
paths=sorted([p for p in (P/"inspection_runs").rglob("*") if p.is_file()]+[P/"payload_admission.json"])
rows=[]
for p in paths:
 h=hashlib.sha256()
 with p.open("rb") as f:
  for block in iter(lambda:f.read(65536),b""):h.update(block)
 rows.append([str(p.relative_to(P)),p.stat().st_size,h.hexdigest()])
rows.append([str((leaf/"exitstatus.txt").relative_to(P)),2,hashlib.sha256(b"0\n").hexdigest()])
rows.sort()
d={"schema":"arc3-native-identity-inspection-seal-v1","status":"CLOSED_SUCCESS_RECEIPT_EXPECTED","file_count":len(rows),"file_fields":["path","bytes","sha256"],"covered_bytes":sum(x[1] for x in rows),"total_bytes_including_manifest":0,"cap_bytes":307200,"scope":"payload_admission.json and every own inspection_runs file; original399 payload files and publisher README remain separate pinned inputs.","self_exclusion":"inspection_manifest.json excludes its own hash. Final seal execution has empty stdout/stderr and expected exitstatus0, persisted by wrapper after exit; any deviation invalidates this seal.","files":rows}
while True:
 b=(json.dumps(d,ensure_ascii=False,separators=(",",":"))+"\n").encode()
 total=d["covered_bytes"]+len(b)
 if d["total_bytes_including_manifest"]==total:break
 d["total_bytes_including_manifest"]=total
assert total<=d["cap_bytes"],(total,d["cap_bytes"])
with (P/"inspection_manifest.json").open("xb") as f:f.write(b)
