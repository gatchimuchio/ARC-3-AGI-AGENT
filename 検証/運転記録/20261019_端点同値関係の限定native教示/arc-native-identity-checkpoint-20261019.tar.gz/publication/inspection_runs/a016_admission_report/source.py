import json,hashlib,difflib
from pathlib import Path
R=Path("/workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019");P=R/"publication_native_identity"
mp=P/"payload_manifest.json";mb=mp.read_bytes();m=json.loads(mb)
summary=P/"README.md";sb=summary.read_bytes()
assert hashlib.sha256(sb).hexdigest()=="fcf0b274d11f744c129a02e988438b8ce3e56ce8212265cd8a2990d6a084fe28"
old=(P/"inspection_runs/a013_publisher_readme/stdout.txt").read_text().split("\n",1)[1].rsplit("\nOWN_BYTES ",1)[0]
new=sb.decode()
changes=[x for x in difflib.ndiff(old.splitlines(),new.splitlines()) if x.startswith(("- ","+ "))]
assert len(changes)==4,changes
report={
"schema":"arc3-native-identity-independent-local-content-admission-v1",
"verdict":"PASS_LOCAL_CONTENT_ONLY",
"publication_authorized":False,
"git_writes_remain_paused":True,
"scope":{"payload_manifest_sha256":hashlib.sha256(mb).hexdigest(),"files":399,"raw_bytes":160290700,"closed_roots":m["closed_roots"],"unique_contents":221,"external_inputs_not_followed":"Prior181-file pilot, core, full public corpus and opaque references were not followed or duplicated."},
"authority":"All six specified authority documents read first; original instructions unchanged. Current owner restriction excludes newly publishing actual original HDS theory/specification manuscripts. Historical repository scope remains unresolved.",
"integrity":{"all399_size_and_sha256_pins_recomputed":True,"native_freeze_sha256":"4bd1a68fded11a3550510b55c3b7a2084056a13bf682258fd105443d7f38c32d","native_freeze_entries_verified":105,"closure_receipts_retained":3,"outcome_audit_sha256":"5c947a10ff99bb85d537a2849621d8eb3746e0164665defb18256d21397a10d4","outcome_audit_verdict":"BOUNDED_NATIVE_IDENTITY_EVIDENCE_PASS","caller_logical_pins":10,"caller_resolution":"Exact byte/hash matches with the same basename under arc-native-identity-20261019 in the frozen allowlist; no arbitrary external path resolution."},
"content_classification":{
"original_hds_theory_or_specification_manuscript_bodies":"NONE IDENTIFIED in this exact payload. This is based on bodies and structured content, not names such as 正本.",
"hds_related_prose":"PRESENT: task-origin capability/source analysis, proposed measurement contracts, static resource reasoning, semantic reviews and experiment-result explanations. These are derived operational documents; they are not copied original HDS theory/specification manuscripts. In particular the operation contract and bound review contain substantive technical explanation and are not described as theory-free.",
"documents":{"markdown_files":17,"distinct_bodies_reviewed":15,"raw_bytes":99883},
"source":{"python_files":111,"distinct_sources":60,"ast_parse_pass":59,"preserved_historical_syntax_error":"arc-identity-launch-review-20261019/freeze01/source.py:24","large_literals":"Five literals above350 characters are generated inspection/caller code, maximum1401 characters; no embedded manuscript prose found."},
"data":"Public-observation derivatives, typed ordinary learned-state records, complete replies, resource/manifest receipts, and synthetic test fixtures.",
"restricted_material":"No identified credentials, cookies, personal/contact data, official game/SDK implementation or official game/SDK stderr. Native imports appear only as inert caller references. No original core implementation is bundled.",
"structured_text_check":"65 distinct non-reserve JSON bodies plus every full state and framed payload were recursively inspected. No structured string of180 or more characters was found. This lexical check complements document/source review; it is not a general secrecy guarantee."
},
"reservations":{"files":25,"whole_native_states":18,"native_reserve_index_entries_exact":24,"evidence_frames":243,"evidence_prefix_bytes":3121785,"evidence_zero_tail_bytes":9461127,"additional_log_supervisor_frames":3,"all_frame_hashes_and_zero_tails_checked":True,"unused_failure_and_worker_regions":"All-zero reservations retained.","synthetic_probe":"12MiB fixture contains only14 bytes bounded-prefix at6519698..6519711; all other bytes zero; matches retained pure OS probe source."},
"direct_state_checks":{"observations":[189,204],"principle_records":[19,27],"paired_query_counters":[6698,6728,6758],"all_original_and_previous_ledger_prefixes_equal":True,"query_batches_change_only_paired_counters_by30":True,"adaptation_teacher_ordinals":[4,7,9,11]},
"bounded_claims":{"pinned_outcome_audit":"75 actual calls in30Query/15Teach/30Query;225call records and18state indices. Four directed identity lineages/eight versions, two forward and two inverse. Eleven forward queries initially 出力/no prediction, then seven observed and four unseen-color expected values. Nineteen old smoke relevant projections preserved while all raw replies differ. The already-closed audit verifies full history prefixes and all detailed prediction/support claims; this content inspection did not rerun native learning.","limits":"Five informative historical Actions/two recordings/zero new observations;150 ambiguous cells remain unlabelled. Endpoint selection, geometry, role, mask and grouping remain fixed priors. No continuous identity, MASK causality, inverse-query test, Action permission, generalization or fresh-success claim."},
"chronology":{"originals_unchanged":True,"producer_REVIEW_PENDING_preserved":True,"later_independent_PASS_preserved":True,"known_original_source_hole":"Initial operation-contract inline KeyError had no saved complete original standalone source. inspection_failure_history.txt explicitly discloses it; no reconstruction was treated as original."},
"publisher_summary_review":{"outside399_scope":True,"path":"README.md","bytes":len(sb),"sha256":hashlib.sha256(sb).hexdigest(),"result":"Consistent after exact endpoint-rule clarification and labeling fresh1/183 as external prior baseline, not measured by this inspection. Only those two paragraphs changed from reviewed draft."},
"inspection_safety":{"local_only":True,"native_hds_sdk_execution":0,"actions":0,"git_operations":0,"network_or_upload":0,"payload_or_authority_edits":0,"address_space_limit_bytes":268435456,"largest_observed_rss_KiB":72272,"full_reads_bounded_per_file_and_reserves_streamed":True},
"inspection_errors_retained":{"a006_inert_sources":"Uncaught historical freeze01 SyntaxError stopped AST scan; fresh a007 handled it and completed all60 distinct sources.","a008_all_content":"Scanner zero-marker escape typo reached empty JSON header; fresh a009 corrected it and completed all content.","a011_closure_states":"Inspection transcribed trailing count digit1 into expected freeze hash; fresh a012 uses actual pinned64-character hash and all closure checks passed."},
"captures":"Every inspection run used a fresh leaf with exact source saved before execution and stdout/stderr/exitstatus stored before review. inspection_manifest.json seals report and all capture leaves, excluding its own self-hash. No earlier leaves edited."
}
b=(json.dumps(report,ensure_ascii=False,indent=2)+"\n").encode()
current=sum(x.stat().st_size for x in (P/"inspection_runs").rglob("*") if x.is_file())
assert current+len(b)+18000<=300*1024,(current,len(b))
with (P/"payload_admission.json").open("xb") as f:f.write(b)
print("REPORT_CREATED",len(b),hashlib.sha256(b).hexdigest(),"CAPTURES_BEFORE_FINAL_SEAL",current)
