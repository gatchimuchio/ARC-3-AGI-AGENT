import os,json,hashlib,collections,stat
from pathlib import Path
R=Path("/workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019")
m=json.loads((R/"publication_native_identity/payload_manifest.json").read_bytes())
groups=collections.defaultdict(list); unique=collections.defaultdict(list); bad=[]; totals=collections.Counter()
for e in m["files"]:
 p=Path(e["source"]); st=p.lstat()
 if not stat.S_ISREG(st.st_mode): bad.append([e["archive_path"],"not regular"])
 h=hashlib.sha256()
 with p.open("rb") as f:
  for block in iter(lambda:f.read(65536),b""): h.update(block)
 if st.st_size!=e["bytes"] or h.hexdigest()!=e["sha256"]: bad.append([e["archive_path"],"pin mismatch"])
 groups[p.suffix or "(none)"].append(e); unique[e["sha256"]].append(e)
 totals[e["archive_path"].split("/")[0]]+=e["bytes"]
print("VERIFIED",len(m["files"]),"bytes",sum(e["bytes"] for e in m["files"]),"bad",bad,"unique",len(unique))
print("ROOT_BYTES",dict(totals))
for ext,es in sorted(groups.items()):print("TYPE",ext,len(es),sum(e["bytes"] for e in es))
print("FILES")
for e in m["files"]: print(e["bytes"],e["archive_path"])
