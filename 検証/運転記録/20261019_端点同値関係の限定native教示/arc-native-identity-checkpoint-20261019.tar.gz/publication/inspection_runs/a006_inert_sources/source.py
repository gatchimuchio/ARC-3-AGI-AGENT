import json,ast,collections,re,hashlib
from pathlib import Path
R=Path("/workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019")
m=json.loads((R/"publication_native_identity/payload_manifest.json").read_bytes());seen=set()
for e in m["files"]:
 if e["source"].endswith(".py") and e["sha256"] not in seen:
  seen.add(e["sha256"]);s=Path(e["source"]).read_text();t=ast.parse(s)
  imports=[];strings=[];classes=[]
  for n in ast.walk(t):
   if isinstance(n,ast.Import):imports.extend(x.name for x in n.names)
   elif isinstance(n,ast.ImportFrom):imports.append(n.module)
   elif isinstance(n,ast.Constant) and isinstance(n.value,str) and len(n.value)>350:strings.append((n.lineno,len(n.value),n.value[:220]))
   elif isinstance(n,ast.ClassDef):classes.append(n.name)
  print("AST",e["archive_path"],"imports",imports,"classes",classes,"large_literals",strings)
for name in ["arc-native-identity-20261019/read_run.py","arc-native-identity-20261019/reserve_prefix_index.json","arc-native-identity-20261019/execution01/reviewed_manifest.json"]:
 p=next(Path(e["source"]) for e in m["files"] if e["archive_path"]==name)
 print("INSPECT",name)
 if p.suffix==".json":
  d=json.loads(p.read_bytes())
  print(json.dumps(d,ensure_ascii=False)[:5000])
 else: print(p.read_text())
print("OWN_BYTES",sum(x.stat().st_size for x in (R/"publication_native_identity/inspection_runs").rglob("*") if x.is_file()))
