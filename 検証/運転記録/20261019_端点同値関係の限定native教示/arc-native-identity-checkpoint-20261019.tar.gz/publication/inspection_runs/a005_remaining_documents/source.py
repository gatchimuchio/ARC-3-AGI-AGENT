import json
from pathlib import Path
R=Path("/workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019")
m=json.loads((R/"publication_native_identity/payload_manifest.json").read_bytes())
skip={"arc-operation-teacher-contract-20261019/README.md","arc-identity-teacher-plan-20261019/MEASUREMENT_CONTRACT.md","arc-native-identity-20261019/RESULT.md","arc-identity-launch-review-20261019/README.md","arc-identity-launch-review-20261019/final_execution_audit/README.md"}
seen=set()
for e in m["files"]:
 if not e["source"].endswith(".md") or e["archive_path"] in skip or e["sha256"] in seen: continue
 seen.add(e["sha256"])
 if "/final_source/" in e["archive_path"] or "/final_revision03/" in e["archive_path"]:continue
 print("=== "+e["archive_path"]+" ===");print(Path(e["source"]).read_text())
