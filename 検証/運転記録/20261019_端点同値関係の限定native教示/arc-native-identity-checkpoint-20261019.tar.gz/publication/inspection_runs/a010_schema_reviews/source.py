import json,collections
from pathlib import Path
R=Path("/workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019")
m=json.loads((R/"publication_native_identity/payload_manifest.json").read_bytes());p={e["archive_path"]:Path(e["source"]) for e in m["files"]}
for name in ["arc-identity-teacher-review-20261019/FINAL_REVIEW.md","arc-identity-teacher-review-20261019/FINAL_TARGET_CONTRACT_PASS.md","arc-identity-teacher-review-20261019/INITIAL_REVIEW.md"]:
 print("DOCUMENT",name);print(p[name].read_text())
for name in ["arc-native-identity-20261019/run01/normal_state.reserve","arc-native-identity-20261019/run01/post_state.reserve"]:
 d=json.loads(p[name].read_bytes()); print("SCHEMA",name,json.dumps(d,ensure_ascii=False)[:2400])
for name in ["arc-native-identity-20261019/freeze_manifest.json","arc-identity-launch-review-20261019/final_execution_audit/audit_report.json","arc-native-identity-20261019/identity_result_summary.json"]:
 d=json.loads(p[name].read_bytes());print("SUMMARY",name)
 for k,v in d.items():
  print(k,type(v).__name__,json.dumps(v,ensure_ascii=False)[:260] if isinstance(v,(dict,list)) else v)
