import os,json,hashlib,collections
from pathlib import Path
R=Path("/workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019")
p=R/"publication_native_identity/payload_manifest.json"
b=p.read_bytes(); d=json.loads(b)
print("manifest",len(b),hashlib.sha256(b).hexdigest())
print("TYPE",type(d).__name__)
if isinstance(d,dict):
 for k,v in d.items():
  print("KEY",k,"TYPE",type(v).__name__,"SIZE",len(v) if hasattr(v,"__len__") else "")
  if isinstance(v,list): print(json.dumps(v[:2],ensure_ascii=False))
  elif isinstance(v,dict): print(json.dumps(v,ensure_ascii=False)[:5000])
  else: print(str(v)[:5000])
print("OWN_CAPTURE_BYTES",sum(x.stat().st_size for x in (R/"publication_native_identity/inspection_runs").rglob("*") if x.is_file()))
