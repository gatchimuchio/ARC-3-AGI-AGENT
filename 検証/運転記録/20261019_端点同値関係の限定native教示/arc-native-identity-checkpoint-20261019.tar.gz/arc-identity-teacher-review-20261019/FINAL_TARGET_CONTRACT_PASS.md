# Final scoped measurement review: PASS

Reviewed producer revision03_target_endpoint/prepare.py SHA256692bbba43be0366aa0819c1ed2b4a075c8619f1222c050fb623a3815e296629b, its CONTRACT and20manifest entries. PASS is restricted to the proposed paired public TARGET-observation value relation and its exact offline witnesses. It is not native execution, whole-environment endpoint proof, causal uniqueness, or Action admission.

## Why the verdict changed

The original literal13/14 proposal lacked an independent selector. A full-frame-stability selector then returned NONE for all6, correctly detecting continuing device animation. Requiring all device pixels to stop was unnecessarily strong for a target-value measurement. The revised protocol measures only the target at the boundary of the observed same-reference segment, while retaining device motion and all uncertain phases. Prior selector failures, gate assessments and source versions remain preserved as history; no failure was deleted or reclassified as success.

## Exact admitted measurement scope

Validate all before/after frames under the existing pixel contract and64×64 shape, nonempty same public guid/game, non-reset/nonterminal pair and the original before Action5 availability/echo/argument scope. BEFORE full parsing, unique-role guards and existing device-template gate bind reference pixels/rectangle, target rectangle and size.

Inspect the BEFORE reference crop in every after frame. Require its contiguous unchanged prefix; reject later reference re-entry. Take ONLY the last two frames of that prefix. Require both to pass full scene/unique-role parsing with the exact BEFORE reference pixels, reference rectangle, target rectangle and size. Require their observed target arrays equal. Otherwise HOLD without searching earlier. Mask membership, tool color, expected-copy fit, progress/reward and literal indices do not select endpoints.

All6 packets select13/14 as a result of this rule. This is the last paired observed target value at old-reference segment/packet boundary. It does not imply whole-frame stability, later persistence, hidden-state constancy, or continuous target identity through unknown phases. Phases2–12 remain semantic geometry/role HOLD where previously unknown. Fixed-coordinate raw projections do not erase those unknowns. All112 phases and all600cells remain evidence.

## Independent checks and correction evidence

- Independently implemented selector and all6producer selector results agree. Final target runs begin7,8,7,0,7,8 and end14. Instrument motion does not change those observed target arrays.
- Revision02 accepted pairs with both public IDs missing, and interpreted malformed phase15 as a reference transition. Exact source/probes were preserved. Revision03 now rejects both, with pair_identity_missing and packet_frame_shape_invalid.
- Producer source mutation test jointly changes one raw target pixel and its attribution in both selected frames. All15 BEFORE memberships remain identical,16teacher rows result, and1contradiction is retained. A final-frame-only change instead produces terminal_target_unstable_no_fallback. No outcome filtering, majority vote or earlier-fit search.
-20revision manifest entries verified. All15teacher,30query and75-call-plan bytes exactly match independent pre-review copies. These counts remain proposals, not executed native calls.
- Source/type validation already rejects17caller-scope probes. All600before classifications and raw outcomes were independently checked:450eligible,150held; case3 supplies0informative groups.15groups are correlated views of5informative historical actions, not15independent interventions.

## Prior, observation and proposed learning remain separate

The selector is a NEW FIXED OBSERVATION PROTOCOL. Geometry, Action5 role, device grammar, grouping and inside/outside composition remain fixed assumptions. Labels are actual measured public target values. Only prospective forward/reverse scalar identity relations could be HDS-learned; no native result is claimed here. Four unseen-color queries are algebraic diagnostics, not environmental transfer tests.19old-smoke rows span10boundaries and are not exhaustive regression.

No-op, constant-output, global overwrite, alternative masks, object rebinding, hidden-state and long-term effects remain causal rivals/limits as applicable. The current contrasts inform some rivals but do not establish a unique mechanism or universal causal prerequisite. ContinuousMASK, paletteCOPY, TURN, future persistence and Action safety are outside this PASS.

The75-call native value-relation pilot may now be PREPARED under this narrow reviewed measurement contract. Execution still requires separate native growth/reply/caller/source-pin/resource admission and parent authorization; this semantic review grants none of those automatically. No HDS/SDK/Action/Git operation occurred.

## Artifacts

final_revision03_result.json; counterfactual_result_revision03.json and exact test source; producer_scope_probes_692bbba43be0.json; preserved revision02 probes/source; independent target_selector_source_pins.json, target_projection_review.py, all_target_projection_phases.json and negative probes. Original INITIAL_REVIEW, FINAL_REVIEW and TARGET_SCOPE_REASSESSMENT are retained; this document is the current scoped semantic verdict.
