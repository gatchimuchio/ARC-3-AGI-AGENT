import resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
import json,pathlib,ast,types,copy,hashlib
B=pathlib.Path('/workspace/scratch/a94ff513b3af');O=B/'arc-identity-teacher-review-20261019';R=B/'arc-identity-teacher-plan-20261019/revision03_target_endpoint';W=B/'arc-teacher-contrasts-20261019';BR=B/'arc-goal6-action-bridge-20261019';n={'__file__':str(BR/'bridge.py'),'__name__':'pure_probes'};exec(compile((BR/'bridge.py').read_bytes(),'bridge','exec'),n)
source=(R/'prepare.py').read_bytes();env={'br':types.SimpleNamespace(**n)};nodes=[x for x in ast.parse(source).body if isinstance(x,ast.FunctionDef) and x.name=='endpoint_pair'];exec(compile(ast.Module(body=nodes,type_ignores=[]),'endpoint::pure','exec'),env)
js=json.loads((W/'goal6_full_witness_joins.json').read_bytes());results=[]
for case,mode in [(0,'both_missing_ids'),(4,'malformed_reference_transition_frame')]:
 j=js[case];bef=json.loads((W/j['raw_before']).read_bytes())['data'];aft=json.loads((W/j['raw_after']).read_bytes())['data']
 if mode=='both_missing_ids':
  for d in (bef,aft):
   for k in ('guid','game_id'):d.pop(k)
 else:aft['frame'][-1]=[[1]]
 try:result={'selected':env['endpoint_pair'](bef,aft),'rejected':False}
 except Exception as e:result={'rejected':True,'error_type':type(e).__name__,'error':str(e)}
 results.append({'mode':mode,**result})
sha=hashlib.sha256(source).hexdigest();(O/f'producer_endpoint_source_{sha[:12]}.py').write_bytes(source);(O/f'producer_scope_probes_{sha[:12]}.json').write_text(json.dumps(results,indent=2));print(sha,results)
