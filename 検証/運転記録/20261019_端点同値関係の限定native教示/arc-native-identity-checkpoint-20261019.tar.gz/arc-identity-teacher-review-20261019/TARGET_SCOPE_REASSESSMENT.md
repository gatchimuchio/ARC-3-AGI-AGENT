# Additive target-scope reassessment

## Revised scope finding

Full-frame stability was too strong a prerequisite for a target-value-scoped observation. Its all6 NONE results remain correct and preserved, but do not establish that no target-scoped response endpoint can be measured. This addendum supersedes that broader implication in FINAL_REVIEW.md. It does not grant native or Action admission.

A separate, prediction-independent diagnostic now identifies the last observed BEFORE-anchored target crop at the end of the old-public-reference segment in all6 packets. It never compares target values with tool color, the mask prediction or expected identity, and does not hardcode phase13/14. These indices emerge from recorded packet structure.

## Selector and retained evidence

1. Verify same nonempty public guid/game and non-reset pair; recover supported terminal-before reference and target rectangles.
2. Project the fixed BEFORE reference and target rectangles from every raw after frame. All92 after phases are retained, even where whole-scene interpretation is unknown. The original all112-phase evidence, including20before phases, remains intact.
3. Define the old-reference segment as the contiguous prefix whose reference crop equals the BEFORE public reference. Reject reference re-entry ambiguity. Its boundary is either the first changed reference or the recorded packet end, not a fit-selected frame.
4. Require the last two frames at this boundary to have independently parsed matching reference/target rectangles and public reference, and equal target crops. If the boundary is unstable or unbound, HOLD; do not search earlier for a pleasing result.
5. Report the maximal backward run of equal target crops ending at that boundary. This is fixed-coordinate projection stability, not proof of continuous object identity during unparsed phases.

Results (case0–5): target runs7–14,8–14,7–14,0–14,7–14,8–14. All select the last adjacent pair13/14. Only cases4/5 change reference next, at15; the others end the packet at14. The complete raw reference crops remain unchanged until the boundary in all6. The last pair's target/reference bindings are supported by full scene interpretation even though instrument pixels still move.

Counterfactual checks preserve the intended boundary: changing an observed target color in both last frames still selects that changed data; changing only the final frame returns HOLD and does not fall back to an earlier matching phase. The separate exact-producer test already shows changed observed data leaves before groups unchanged and retains contradictory labels. No original teacher/source was modified.

## What this licenses and what it does not

It licenses the narrow measurement description: 'observed target value at the old-reference boundary of this complete Action response.' This is a more principled basis than a declared phase index alone. Instrument animation need not halt to measure that target value. The original15 snapshot values agree with the selected target-scoped endpoint values, so the raw numerical labels need no replacement.

It does NOT certify a final whole-environment effect, later persistence beyond the packet, hidden-state equality, intermediate object identity, absence of non-target effects, unique true mask, prerequisite necessity, or Action safety. The77 whole-scene unknowns remain unknown. Public reference equality is only the measured public binding, not proof that all latent game conditions are unchanged. The selector is retrospective on a complete response, not an online Action authorization.

For causal interpretation, preserve and compare rivals: no-op versus copy on cells with prior!=tool; constant-output versus varying tool values; global overwrite versus outside preservation; geometry alternatives that coincide on these frames; animation/occlusion versus actual target transition; device and direction changes; public progress/reference rebinding and hidden-state uncertainty. Current data contain450 identifying cells from5 historical actions and150ambiguous cells; they do not supply fresh independent interventions or establish unique causality.

Thus an explicitly target-scoped observational relation is defensible. Native teacher admission, historical COPY/MASK contract reuse, broader causal transfer, and Action adoption remain separate gates. Merely learning the value equality still does not learn geometry, Action roles or conditional composition. No native operation or permission change occurred during this reassessment.

Evidence: target_projection_review.py, all_target_projection_phases.json (all92after projections), target_projection_result.json. AS512MiB, peakRSS18,736KiB. Original strict selector failures and prior reviews remain available as a record of the scope correction.
