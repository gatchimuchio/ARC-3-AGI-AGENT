import resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
import pathlib,json,hashlib,collections
B=pathlib.Path('/workspace/scratch/a94ff513b3af');R=B/'arc-identity-teacher-plan-20261019';O=B/'arc-identity-teacher-review-20261019';W=B/'arc-teacher-contrasts-20261019';BR=B/'arc-goal6-action-bridge-20261019'
def rd(p):return json.loads(p.read_bytes())
ns={'__file__':str(BR/'bridge.py'),'__name__':'pure_review'};exec(compile((BR/'bridge.py').read_bytes(),'pinned_pure_bridge','exec'),ns)
for ref in rd(R/'source_pins.json'):
 p=B/ref['path'];data=p.read_bytes();assert len(data)==ref['bytes'] and hashlib.sha256(data).hexdigest()==ref['sha256']
groups=rd(R/'groups.json');teachers=rd(R/'teachers.runtime.json');cells=rd(R/'all600_cells.json');scopes=rd(R/'case_scope.json');joins=rd(W/'goal6_full_witness_joins.json');recomputed={};counts=collections.Counter();case_reports=[]
for ci,j in enumerate(joins):
 bef=rd(W/j['raw_before'])['data'];aft=rd(W/j['raw_after'])['data'];s=ns['phase'](bef['frame'][-1],bef['state'],bef['available_actions'])['scene'];assert s==scopes[ci]['before_scene'] or ns['sig'](s)==ns['sig'](scopes[ci]['before_scene'])
 assert bef['guid']==aft['guid'] and bef['game_id']==aft['game_id'] and bef['full_reset'] is False and aft['full_reset'] is False
 per=[]
 for y in range(10):
  for x in range(10):
   old=s['対象'][y][x];tool=s['器具色'];inside=ns['P']['membership'](s['方向'],x,y,10,'広域塗布');eligible=old!=tool;row=next(z for z in cells if z['case']==ci and z['target']==[x,y]);assert row['eligible']==eligible and row['inside']==inside and row['before_target']==old and row['before_tool']==tool
   counts['eligible' if eligible else 'held']+=1
   if not eligible:continue
   key=(ci,tool if inside else old,inside);recomputed.setdefault(key,[]).append([x,y]);per.append(key)
 case_reports.append({'case':ci,'eligible':len(per),'groups':len(set(per))})
assert len(recomputed)==len(groups)==15
for g in groups:
 key=tuple(g['key']);assert sorted(recomputed[key])==sorted(g['cells']) and len(recomputed[key])==g['cell_count'];ci,source,inside=key;s=scopes[ci]['before_scene'];aft=rd(W/joins[ci]['raw_after'])['data'];actual=collections.defaultdict(list)
 # v1 snapshot raw outcomes audited; newer endpoint protocol is separately reviewed.
 for x,y in g['cells']:
  for phase in (13,14):
   cx,cy,_,_=s['対象矩形'];value=aft['frame'][phase][cy+y][cx+x];actual[value].append({'target':[x,y],'phase':phase})
 assert {x['value']:x['observations'] for x in g['actual_outcomes']}==dict(actual)
 for a in g['actual_outcomes']:assert a['contradicts_identity']==(a['value']!=source)
expected=[]
for g in groups:
 for a in g['actual_outcomes']:
  expected.append({'内容':{'作用前器具色' if g['inside'] else '作用前対象色':g['before_source_value'],'同一問題端点対象色':a['value']},'対象系境界':'公開塗布端点:作用前識別可能・固定幾何'+('内' if g['inside'] else '外'),'主体':None,'対象':None,'目的':None,'文脈':{}})
assert teachers==expected
qs=rd(R/'queries.runtime.json');plan=rd(R/'proposed_plan.json');assert plan['explicit_native_admission'] is False
assert plan['plan']==[{'method':'照会する','input':x} for x in qs]+[{'method':'処理する','input':x} for x in teachers]+[{'method':'照会する','input':x} for x in qs]
assert len(qs)==30 and len(plan['plan'])==75
assert qs[11:]==[x['input'] for x in rd(B/'arc-native-teach-final-20261019/proposed_config.json')['plan'][:19]]
report={'groups':len(groups),'teachers':len(teachers),'cells':len(cells),'counts':dict(counts),'cases':case_reports,'queries':len(qs),'proposed_native_calls':len(plan['plan']),'native_calls_executed':0,'old_smoke_exact':True,'all_observed_outcomes_equal_identity':all(not x['contradicts_identity'] for g in groups for x in g['actual_outcomes']),'max_RSS_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(O/'audit_result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,indent=2))
