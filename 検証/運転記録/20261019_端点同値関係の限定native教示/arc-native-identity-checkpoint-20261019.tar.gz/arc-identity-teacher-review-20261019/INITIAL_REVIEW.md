# Identity teacher measurement review: initial findings

Pure/static review, AS512MiB. No native HDS import, restore, Query, Teach, save, SDK, Action or Git operation. Original plan sources/evidence were preserved in pre_review/ before feedback. Authority and the operation-teacher-contract report/source were reread; fixed HDS v0.4.2 remains unchanged.

Independent checks in audit.py/audit_result.json confirm all600 before-defined cell memberships,450eligible/150held,15complete before-defined groups and their directly measured raw endpoint values. Case3 contributes zero informative groups. Exact15 native-form teacher mappings and30Query+15process+30Query proposed sequence matched; 19old-smoke inputs exactly equal the pinned existing configuration. Source pins match. Actual native calls executed:0. Proposed calls:75. PeakRSS22,160KiB.

Seven unique observed source values (inside0,12,14; outside0,8,12,15) plus four unseen-value queries (1,2 each boundary) and19existing smoke queries account for30 per side. Unseen color probes are algebraic diagnostics, not new environment observations or evidence of cross-game transfer. The19old smoke rows cover10boundaries but are not comprehensive behavioral/fresh-success regression.

New boundaries transparently name fixed geometry and before identifiability. Conditions are typed scalar color values; outcomes are measured after colors. No coordinate/case/game/hash/path/success marker enters runtime routing. Coordinates and case keys remain external provenance. Group membership depends only on before target/tool values, fixed mask membership and before scope. Outcomes are collected without filtering equality; all actual distinct outcomes per group are emitted and contradictions flagged. Native row counts are not independent intervention counts:15groups come from5informative historical actions across2recordings, all6actions retained. Fixed geometry, role mapping, inside/outside dispatch and composed rendering are not learned by the two relations.

Frozen native source supports a genuine identity-relation candidate: adaptation returns an unseen condition value directly for a one-condition 同値関係. This distinguishes a potential native learned equality from a finite seen-color lookup. Actual adoption, reverse competing relations, type scope, support/refutation and Query result remain unexecuted. The caller must enforce integer0..15 and scope; native identity is value-polymorphic.

Initial blocking feedback sent parent/worker:
1. prepare.py hardcodes phase13 primary and14replicate; augment_group_evidence.py hardcodes the same indices. This is not a separately justified general endpoint selector. Replace with prediction-independent structural binding/stability qualification, or explicitly freeze as historical qualified snapshots only, not runtime endpoint projection. Do not search/select on equality to tool/prior.
2. valid() uses .get for role fields and permits omitted required fields/extra top-level fields. Enforce an exact constructor shape if claiming that contract.
3. Existing source pairs pass same guid/game and full_reset=false, independently checked here, but those prerequisites should be explicitly part of the measurement contract. Original before-scope expression omits them.

All112phases and all600cell histories are retained. All-group-phase outcomes retain early mismatches, unknowns and rebinding; these do not become continuous-copy evidence merely because selected old-problem snapshots match. Require a counterfactual scope test: alter measured endpoint colors while keeping before data fixed; group membership must stay fixed and contradictory outputs must remain visible.

A synthetic counterexample design is retained separately, clearly marked not environmental evidence. Native resource proposal review is separate; this semantic review supplies no execution admission.
