import resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
import pathlib,json,ast,types,hashlib
B=pathlib.Path('/workspace/scratch/a94ff513b3af');R=B/'arc-identity-teacher-plan-20261019';O=B/'arc-identity-teacher-review-20261019';BR=B/'arc-goal6-action-bridge-20261019';W=B/'arc-teacher-contrasts-20261019'
ns={'__file__':str(BR/'bridge.py'),'__name__':'pure_contract'};exec(compile((BR/'bridge.py').read_bytes(),'bridge','exec'),ns)
env={'br':types.SimpleNamespace(**ns),'hashlib':hashlib,'json':json};src=(R/'retrospective_selector.py').read_bytes();nodes=[n for n in ast.parse(src).body if isinstance(n,ast.FunctionDef)];exec(compile(ast.Module(body=nodes,type_ignores=[]),'selector::pure','exec'),env)
results=[]
for j in json.loads((W/'goal6_full_witness_joins.json').read_bytes()):
 bef=json.loads((W/j['raw_before']).read_bytes())['data'];aft=json.loads((W/j['raw_after']).read_bytes())['data'];results.append({'case':j['teacher_ordinal'],**env['select'](bef,aft)})
assert json.loads(json.dumps(results))==json.loads((R/'retrospective_selector_results.json').read_bytes());assert all(x['pair_scope_verified'] and x['selected_pair'] is None for x in results)
scope={'bounds':{True:'公開塗布端点:作用前識別可能・固定幾何内',False:'公開塗布端点:作用前識別可能・固定幾何外'},'fields':{True:'作用前器具色',False:'作用前対象色'}};tree=ast.parse((R/'prepare.py').read_bytes());exec(compile(ast.Module(body=[x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='valid'],type_ignores=[]),'valid::pure','exec'),scope)
probes=json.loads((R/'scope_probes.json').read_bytes());assert len(probes)==17
for p in probes:assert scope['valid'](p['input']) is False
for p in json.loads((R/'queries.runtime.json').read_bytes())[:11]:assert scope['valid'](p) is True
for name in ('teachers.runtime.json','queries.runtime.json','proposed_plan.json'):assert (R/name).read_bytes()==(O/'pre_review'/name).read_bytes()
manifest=json.loads((R/'MANIFEST.json').read_bytes());entries=manifest['files']
for f in entries:
 p=R/f['path'];assert p.stat().st_size==f['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==f['sha256']
out={'manifest_entries':len(entries),'all6_strict_structural_selector_no_result':True,'all6_pair_scope_verified':True,'strict_scope_rejection_probes':len(probes),'all11_new_boundary_queries_valid':True,'teacher_query_plan_bytes_unchanged':True,'native_calls':0,'max_RSS_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(O/'contract_recheck_result.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
