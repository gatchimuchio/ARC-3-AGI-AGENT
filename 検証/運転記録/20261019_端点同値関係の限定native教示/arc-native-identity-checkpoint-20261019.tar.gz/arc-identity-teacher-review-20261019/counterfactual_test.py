import resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
import pathlib,json,ast,types,copy
B=pathlib.Path('/workspace/scratch/a94ff513b3af');R=B/'arc-identity-teacher-plan-20261019';O=B/'arc-identity-teacher-review-20261019';BR=B/'arc-goal6-action-bridge-20261019';W=B/'arc-teacher-contrasts-20261019'
n={'__file__':str(BR/'bridge.py'),'__name__':'pure_counterfactual'};exec(compile((BR/'bridge.py').read_bytes(),'bridge','exec'),n);br=types.SimpleNamespace(**n)
source=(R/'prepare.py').read_bytes();tree=ast.parse(source);start=next(i for i,x in enumerate(tree.body) if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='a' for t in x.targets));stop=next(i for i,x in enumerate(tree.body) if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='observed' for t in x.targets))
# Execute the producer's exact grouping/label fragment in memory with jointly altered raw/attribution views.
ns={'R':R,'B':B,'BR':BR,'W':W,'br':br,'collections':__import__('collections'),'pin':lambda p:{'path':str(p)},'json':json}
groups=json.loads((R/'groups.json').read_bytes());g=groups[0];ci,src,inside=g['key'];xy=g['cells'][0];new=(src+1)%16;j=json.loads((W/'goal6_full_witness_joins.json').read_bytes())[ci];scene=json.loads((R/'case_scope.json').read_bytes())[ci]['before_scene'];cx,cy,_,_=scene['対象矩形']
def read(p):
 data=json.loads(p.read_bytes())
 if p==BR/'all6_full_attribution_v2.json':
  cell=next(c for c in data[ci]['all100_target_attributions'] if c['target']==xy)
  for q in cell['all_after_phases']:
   if q['phase'] in (13,14):q['after_color']=new;q['identification']='other_color_change'
 if p==W/j['raw_after']:
  for phase in (13,14):data['data']['frame'][phase][cy+xy[1]][cx+xy[0]]=new
 return data
ns['read']=read
exec(compile(ast.Module(body=tree.body[start:stop],type_ignores=[]),'exact_prepare_grouping_fragment','exec'),ns)
actual=ns['groups'];assert [(x['key'],x['cells']) for x in actual]==[(x['key'],x['cells']) for x in groups]
assert len(actual)==15 and len(ns['teachers'])==16 and sum(x['contradicts_identity'] for x in ns['teacher_index'])==1
report={'synthetic_only_not_environment_evidence':True,'source_sha256':__import__('hashlib').sha256(source).hexdigest(),'changed_case':ci,'changed_cell':xy,'changed_phases':[13,14],'old_source':src,'synthetic_outcome':new,'all_15_before_memberships_unchanged':True,'teachers_before':15,'teachers_after':16,'contradictions_retained':1,'native_calls':0}
(O/'counterfactual_result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report))
