import resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
import json,pathlib,hashlib,copy
B=pathlib.Path('/workspace/scratch/a94ff513b3af');O=B/'arc-identity-teacher-review-20261019';R=B/'arc-identity-teacher-plan-20261019';W=B/'arc-teacher-contrasts-20261019';BR=B/'arc-goal6-action-bridge-20261019'
n={'__file__':str(BR/'bridge.py'),'__name__':'pure_projection_review'};exec(compile((BR/'bridge.py').read_bytes(),'bridge::pure','exec'),n)
def crop(frame,rect):
 x,y,X,Y=rect;return [r[x:X] for r in frame[y:Y]]
def select(before,after):
 if any(before.get(k)!=after.get(k) or not isinstance(before.get(k),str) or not before.get(k) for k in ('guid','game_id')) or before.get('full_reset') is not False or after.get('full_reset') is not False:return {'selected':None,'reason':'pair scope'}
 scene=n['phase'](before['frame'][-1],before['state'],before['available_actions'])['scene']
 if scene is None:return {'selected':None,'reason':'before binding unknown'}
 rows=[]
 for i,f in enumerate(after['frame']):
  if len(f)!=64 or any(len(r)!=64 for r in f):return {'selected':None,'reason':'frame shape unknown'}
  obs=n['phase'](f,after['state'],after['available_actions'])['scene'];ref=crop(f,scene['参照矩形']);tar=crop(f,scene['対象矩形'])
  rows.append({'phase':i,'reference_crop':ref,'target_crop':tar,'old_reference_pixels':ref==scene['参照'],'whole_scene_interpretable':obs is not None,'same_parsed_reference_target_binding':None if obs is None else all(obs[k]==scene[k] for k in ('参照','参照矩形','対象矩形'))})
 first_change=next((i for i,r in enumerate(rows) if not r['old_reference_pixels']),len(rows));end=first_change-1
 if any(r['old_reference_pixels'] for r in rows[first_change:]):return {'selected':None,'reason':'reference re-entry ambiguity','all_phases':rows}
 if end<1 or not rows[end]['same_parsed_reference_target_binding'] or not rows[end-1]['same_parsed_reference_target_binding']:return {'selected':None,'reason':'terminal paired binding unknown','all_phases':rows}
 if rows[end]['target_crop']!=rows[end-1]['target_crop']:return {'selected':None,'reason':'target not stable at boundary; do not search earlier fit','all_phases':rows}
 start=end
 while start>0 and rows[start-1]['target_crop']==rows[end]['target_crop']:start-=1
 return {'selected':[end-1,end],'equal_target_run':[start,end],'old_reference_segment_end':end,'reference_change_phase':first_change if first_change<len(rows) else None,'all_phases':rows,'meaning':'last observed before-anchored target crop at old-public-reference segment boundary; no continuous object identity or future persistence claim'}
res=[];joins=json.loads((W/'goal6_full_witness_joins.json').read_bytes())
for j in joins:
 bef=json.loads((W/j['raw_before']).read_bytes())['data'];aft=json.loads((W/j['raw_after']).read_bytes())['data'];res.append({'case':j['teacher_ordinal'],**select(bef,aft)})
assert [r['equal_target_run'][0] for r in res]==[7,8,7,0,7,8]
# Outcome robustness: arbitrary new terminal color changes are selected as data, never filtered to copy agreement.
j=joins[0];bef=json.loads((W/j['raw_before']).read_bytes())['data'];aft=json.loads((W/j['raw_after']).read_bytes())['data'];s=n['phase'](bef['frame'][-1],bef['state'],bef['available_actions'])['scene'];cx,cy,_,_=s['対象矩形'];a=copy.deepcopy(aft)
for i in res[0]['selected']:a['frame'][i][cy+5][cx+5]=1
changed=select(bef,a);assert changed['selected']==res[0]['selected'] and changed['all_phases'][changed['selected'][-1]]['target_crop'][5][5]==1
b=copy.deepcopy(aft);b['frame'][-1][cy+5][cx+5]=1;unstable=select(bef,b);assert unstable['selected'] is None
(O/'all_target_projection_phases.json').write_text(json.dumps(res,ensure_ascii=False,indent=2));summary={'cases':[{k:v for k,v in r.items() if k!='all_phases'} for r in res],'joint_changed_color_still_selected':True,'last_frame_only_change_HOLD_no_earlier_cherry_pick':True,'native_calls':0,'max_RSS_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss};(O/'target_projection_result.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));print(json.dumps(summary,ensure_ascii=False))
