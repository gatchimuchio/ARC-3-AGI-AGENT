import resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
import ast,pathlib,json,copy,hashlib
B=pathlib.Path('/workspace/scratch/a94ff513b3af');O=B/'arc-identity-teacher-review-20261019';W=B/'arc-teacher-contrasts-20261019';BR=B/'arc-goal6-action-bridge-20261019';n={'__file__':str(BR/'bridge.py'),'__name__':'pure_negative'};exec(compile((BR/'bridge.py').read_bytes(),'bridge','exec'),n);env={'n':n}
tree=ast.parse((O/'target_projection_review.py').read_bytes());exec(compile(ast.Module(body=[x for x in tree.body if isinstance(x,ast.FunctionDef)],type_ignores=[]),'selector_functions','exec'),env)
j=json.loads((W/'goal6_full_witness_joins.json').read_bytes())[0];bef=json.loads((W/j['raw_before']).read_bytes())['data'];aft=json.loads((W/j['raw_after']).read_bytes())['data'];s=n['phase'](bef['frame'][-1],bef['state'],bef['available_actions'])['scene'];rx,ry,_,_=s['参照矩形'];cases=[]
def probe(name,b,a):
 r=env['select'](b,a);assert r['selected'] is None;cases.append({'name':name,'result':r['reason']})
a=copy.deepcopy(aft);a['frame'][1][ry][rx]=(a['frame'][1][ry][rx]+1)%16;probe('reference_changes_then_returns_no_search',bef,a)
a=copy.deepcopy(aft);a['frame'][-1]=[[1]];probe('malformed_terminal_frame',bef,a)
a=copy.deepcopy(aft);a['full_reset']=True;probe('reset_pair',bef,a)
a=copy.deepcopy(aft);a['guid']+='different';probe('changed_public_instance',bef,a)
a=copy.deepcopy(aft)
for f in a['frame']:f[ry][rx]=(f[ry][rx]+1)%16
probe('no_old_reference_prefix',bef,a)
(O/'target_selector_negative_probes.json').write_text(json.dumps({'synthetic_only':True,'native_calls':0,'probes':cases},indent=2));print(cases)
