import os,pathlib,resource,signal,json
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
p=pathlib.Path(__file__).resolve().parent/'synthetic12MiB.reserve';fd=os.open(p,os.O_CREAT|os.O_EXCL|os.O_RDWR,0o600);os.ftruncate(fd,12*1024**2)
old=resource.getrlimit(resource.RLIMIT_FSIZE);oldsig=signal.signal(signal.SIGXFSZ,signal.SIG_IGN)
try:
 resource.setrlimit(resource.RLIMIT_FSIZE,(8*1024**2,old[1]));assert os.pwrite(fd,b'bounded-prefix',6519712-14)==14
 denied=False
 try:os.pwrite(fd,b'x',8*1024**2)
 except OSError:denied=True
 assert denied and os.fstat(fd).st_size==12*1024**2
finally:
 resource.setrlimit(resource.RLIMIT_FSIZE,old);signal.signal(signal.SIGXFSZ,oldsig);os.close(fd)
assert resource.getrlimit(resource.RLIMIT_FSIZE)==old
print(json.dumps({'preallocated12MiB_writable_below8MiB':True,'write_at8MiB_rejected':True,'original_limit_restored':True,'native_calls':0}))
