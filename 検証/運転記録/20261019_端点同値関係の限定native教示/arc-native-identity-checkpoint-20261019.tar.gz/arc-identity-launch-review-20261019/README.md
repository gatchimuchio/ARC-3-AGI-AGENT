# Independent 75-call identity-teacher caller review

## Verdict

BOUNDED STATIC/PURE PASS for the frozen proposed75-call caller and exact input pack. Config SHA25641ca6c242d9dc751dd2759c654b5b94960eaee18e1da62e629625ac48555804d remains explicit_parent_admission=false. No native imports, Query, Teach, save, SDK, Action, Git or native run allocation occurred in this review. Parent execution and aggregate-resource admission remain required.

Owner/AGENTS/hierarchy/current state, final revision03 target-observation semantic verdict and independent growth/reply verdict were reviewed. Strategy remains null and automatic transition false. Source and baseline are read-only.

## Exact scope and pins

All64 config pins verify. Exact75-call sequence equals the revision03_target_endpoint proposed_plan:30 Query,15 Teach, the same30 Query again. First11 queries are seven observed-value and four unseen-color algebraic diagnostics; the other19 exactly match the prior pilot's existing queries across10 boundaries. The15 teachers are correlated grouped views of five informative historical actions, not15 independent interventions.

The measurement source is revision03 prepare.py SHA692bbba43be0366aa0819c1ed2b4a075c8619f1222c050fb623a3815e296629b, not the superseded literal13/14 selector. Its complete manifest and final semantic review are pinned. The endpoint selector is a new fixed observation protocol. Mask, roles, grouping and inside/outside composition remain supplied assumptions. Only proposed scalar identity relations could be learned; unseen-color diagnostics are not fresh-instance environmental transfer.

External baseline is the prior final poststate:5,558,643B, SHA3a0e57e44cf2385f70be34bd5908bb9b78de0c7251b3a688d2d27b5e1d21ad84,189 experiences,19 principle versions, paired Query counter6698. Binding43574797de492ef1a49b7498ee23a4ac410935b6c1dc0432baa7b43b17a52720, Guard, gate metadata and source allowlist remain byte-identical to the successful earlier pilot. HDS core is unchanged.

## Tests and corrected blocker

33 independent tests and21 supplied tests pass under512MiB AS. An additional pure OS probe verifies the intended file-limit behavior. Fresh run02/run03/run04 leaves retain sources, stdout, stderr and exit statuses. run03 is the final full suite. Every native test dependency is a mock; storage tests bypass native identity checks explicitly and test the actual save-slot/file-limit plumbing with a synthetic writer.

Initial independent storage test reproduced a real derivative blocker: the unchanged save sink allowed only teacher01–06. The worker preserved pre-fix sources and extended only its exact slot allowlist to teacher15. All19 single-use slots now pass and reject reuse. The failure source/output remain retained in initial_storage_failure and storage_initial.log. The initial successful mocked worker test alone did not exercise this actual sink gate, which is why the independent storage fixture matters.

Tests cover exact30/15/30 ordering,243 expected records, all18 normal snapshots, immutable/detached inputs and captured callables, no CLI or execution without admission, malformed constructor metadata, boundary and bool/integer rejection before bootstrap, all17 reviewed scope probes, mid-second-Teach frontier32/31/31, returned-but-unpersisted frontier31/31/30, interrupted save with partial bytes and restored limit, readback failure, changed prefixes, Query-only state mutation, no follow-on after failure, disjoint failure evidence, supervisor fork/wait/terminal-write failures and no kill after reaping.

Caller now strictly requires six native constructor keys, dictionary content/context, empty context and null metadata. New identity inputs require exactly the scope-specific fields and strict integer0..15 values, excluding bool. Existing smoke rows remain exactly pinned. Each30-Query batch must leave every state field except paired counters unchanged and increment those counters by exactly30. Every original/previous ledger, principle-history and state-history prefix is retained.

## Resource envelope

Nineteen single-use8MiB state slots =152MiB:normal,before,fifteen per-teacher,post,failure. Nominal success uses18 snapshots, leaving failure unused.225 call records plus18 snapshot indices =243 frames.

12MiB evidence plus four disjoint1MiB log/failure regions gives168MiB fixed reservations. The new-unit ceiling is176MiB, leaving8MiB for preparation/reports/partials. Config retains the analytical state bound7,221,324B<8MiB and reply bound60,103B.

The actual caller deliberately enforces a stricter64KiB reply cap, not128KiB. It also enforces8KiB input/postinput,16KiB snapshot and256B frame-header caps before evidence append. Conservative active evidence bound:
75*65,536 +150*8,192 +19*16,384 +244*264 =6,519,712B <8MiB.
This fits unchanged RLIMIT_FSIZE8MiB even though the evidence reserve's existing length is12MiB. The OS probe confirms writing the admitted prefix succeeds and a write at8MiB fails; original limits are restored. Tests cover exact cap boundaries and one-byte excess rejection. The larger12MiB reservation is retained, not silently removed from accounting.

At final freeze, retained directories plus the full176MiB new unit total478,824,712B<proposed512MiB aggregate536,870,912B. This explicitly includes the review's retained synthetic12MiB probe file. Parent must remeasure at admission if other writers add files. The new176MiB unit is not an aggregate176MiB claim.

## Limits

Known-writer/file-length bounds are not filesystem-wide quotas or guarantees against ENOSPC, allocation failure, kernel failure or machine death. Native write_text truncates reserves. Partial files/extents are retained and never reused. Emergency writes can fail; unavailable exact frontier remains UNKNOWN and forbids automatic resume. Native learning/output, complete ledger deltas and preservation must be audited after a separately admitted run. Nineteen smoke rows are not exhaustive prior-success regression; no Action safety, mask/role learning, full-game progress or cross-game capability follows from this preparation.

freeze01 retains a reviewer-script syntax error that occurred before checks/writes. freeze02 preserves the corrected script, clean stdout/stderr and exit0; reviewed_manifest.json is the successful result.
