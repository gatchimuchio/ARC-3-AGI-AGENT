"""Independent read-only framed-byte and native-wire evidence audit; no native imports."""
import pathlib,json,hashlib,struct,resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
B=pathlib.Path(__file__).resolve().parents[2];R=B/'arc-native-identity-20261019';O=pathlib.Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def normalized(x):
 if isinstance(x,list):return [normalized(v) for v in x]
 if isinstance(x,dict):
  if set(x)=={'__辞書__'}:return {normalized(k):normalized(v) for k,v in x['__辞書__']}
  if set(x)=={'__組__'}:return tuple(normalized(v) for v in x['__組__'])
  return {k:normalized(v) for k,v in x.items()}
 return x
def plain(x):return json.loads(json.dumps(x,ensure_ascii=False))
def wire(b):return normalized(json.loads(b))
def framed(path):
 out=[];offset=0
 with path.open('rb') as f:
  while True:
   header=f.read(8)
   if header==b'\0'*8 or not header:
    assert not any(f.read()),'nonzero trailing evidence';break
   assert len(header)==8;n=struct.unpack('>Q',header)[0];assert 0<n<1024
   rawhead=f.read(n);h=json.loads(rawhead);assert h['bytes']<=8*1024**2
   payload=f.read(h['bytes']);assert len(payload)==h['bytes'] and sha(payload)==h['sha256']
   out.append((h,payload,offset));offset+=8+n+len(payload)
 return out,offset
c=json.loads((R/'proposed_config.json').read_bytes());review=json.loads((O.parent/'reviewed_manifest.json').read_bytes())
assert sha((R/'proposed_config.json').read_bytes())==review['config_sha256']
for p,h in c['pins'].items():assert sha(pathlib.Path(p).read_bytes())==h,p
rows,used=framed(R/'run01/evidence.reserve');assert len(rows)==243
records={h['name']:(b,offset) for h,b,offset in rows};assert len(records)==243
outputs=[];maxin=0;maxout=0;lastoffset=-1
for i,row in enumerate(c['plan'],1):
 prefix=f'{i:02d}.{row["method"]}';a,ao=records[prefix+'.input'];z,zo=records[prefix+'.input_after'];b,bo=records[prefix+'.output'];assert lastoffset<ao<bo<zo;lastoffset=zo
 assert a==z;assert wire(a)=={'__データ型__':'外部入力','値':row['input']}
 output=wire(b);assert output['__データ型__']=='外部出力';outputs.append(output['値']);maxin=max(maxin,len(a));maxout=max(maxout,len(b))
assert maxin<=8192 and maxout<=65536
names=['normal_state','before_state']+[f'teach_{i:02d}_state' for i in range(1,16)]+['post_state']
baselinebytes=(B/'arc-native-teach-final-20261019/run01/post_state.reserve').read_bytes();baseline=wire(baselinebytes);previous=baseline;snapshots=[]
for index,name in enumerate(names):
 p=R/'run01'/(name+'.reserve');raw=p.read_bytes();assert len(raw)<=c['state_upper_bound_bytes'];current=wire(raw)
 assert set(current)==set(baseline)
 assert all(current[k]==baseline[k] for k in baseline if k not in ('台帳','原理履歴','状態履歴','識別子状態'))
 if index==0:assert raw==baselinebytes
 for old in (baseline,previous):
  assert set(old['台帳'])<=set(current['台帳']) and set(old['原理履歴'])<=set(current['原理履歴'])
  for k,v in old['台帳'].items():assert current['台帳'][k][:len(v)]==v
  for k,v in old['原理履歴'].items():assert current['原理履歴'][k][:len(v)]==v
  assert current['状態履歴'][:len(old['状態履歴'])]==old['状態履歴']
 if name in ('before_state','post_state'):
  assert set(previous)==set(current)
  assert all(current[k]==previous[k] for k in current if k!='識別子状態')
  expected=dict(previous['識別子状態']);expected['照会']+=30;expected['学習判定']+=30;assert current['識別子状態']==expected
  assert len(current['台帳']['観測台帳'])==(189 if name=='before_state' else 204)
 if name.startswith('teach_'):assert len(current['台帳']['観測台帳'])==189+int(name[6:8])
 snap=wire(records['snapshot.'+name][0]);assert snap['receipt']['bytes']==len(raw) and snap['receipt']['sha256']==sha(raw)
 assert snap['ledger_slices']=={k:[len(previous['台帳'].get(k,())),len(v)] for k,v in current['台帳'].items()}
 assert snap['principle_history_slices']=={k:[len(previous['原理履歴'].get(k,())),len(v)] for k,v in current['原理履歴'].items()}
 assert snap['state_history_slice']==[len(previous['状態履歴']),len(current['状態履歴'])]
 snapshots.append({'name':name,'bytes':len(raw),'sha256':sha(raw),'observations':len(current['台帳']['観測台帳']),'principle_records':len(current['台帳']['原理台帳']),'counters':current['識別子状態']});previous=current
final=previous
assert len(final['台帳']['観測台帳'])==204 and len(final['台帳']['原理台帳'])==27
assert final['識別子状態']['照会']==final['識別子状態']['学習判定']==6758
expected_delta={'old_prefixes_equal':True,'ledger_appends':{k:v[len(baseline['台帳'].get(k,())):] for k,v in final['台帳'].items()},'principle_history_appends':{k:v[len(baseline['原理履歴'].get(k,[])):] for k,v in final['原理履歴'].items()},'state_history_appends':final['状態履歴'][len(baseline['状態履歴']):]}
assert plain(expected_delta)==json.loads((R/'native_full_delta.json').read_bytes())
delta=expected_delta['ledger_appends'];newobs=[x['値'] for x in delta['観測台帳']]
for i,x in enumerate(newobs):assert x['原入力']==c['plan'][30+i]['input']['内容'] and x['対象系境界']==c['plan'][30+i]['input']['対象系境界'] and x['経験識別子']==f'経験-{190+i:06d}'
principles=[p['値'] for p in delta['原理台帳']];assert len(principles)==8
lineages={}
for p in principles:
 assert p['関係型']=='同値関係' and p['反証参照群']==() and p['適用範囲']['条件数']==1
 assert p['状態']['値']=='適用範囲付き暫定原理' and p['採用状態']['値']=='有効'
 assert len(p['条件経路群'])==1 and len(p['条件経路群'][0])==1 and len(p['結果経路'])==1
 assert all(json.loads(k[0])==v and type(v)is int for k,v in p['対応値表'])
 for support in p['根拠参照群']:
  obs=next(x for x in newobs if x['経験識別子']==support)
  assert obs['対象系境界']==p['対象系境界'] and obs['原入力'][p['条件経路群'][0][0]]==obs['原入力'][p['結果経路'][0]]
 lineages.setdefault(p['系譜識別子'],[]).append(p)
assert len(lineages)==4 and all([p['版'] for p in values]==[1,2] for values in lineages.values())
active=[values[-1] for values in lineages.values()];outcome='同一問題端点対象色'
for suffix,sourcefield in [('内','作用前器具色'),('外','作用前対象色')]:
 boundary='公開塗布端点:作用前識別可能・固定幾何'+suffix
 pair=[p for p in active if p['対象系境界']==boundary];assert len(pair)==2
 assert {(p['条件経路群'][0][0],p['結果経路'][0]) for p in pair}=={(sourcefield,outcome),(outcome,sourcefield)}
 latest=final['状態履歴'][-1]
 for p in pair:assert latest[p['系譜識別子']]==p['原理識別子']
assert len(expected_delta['state_history_appends'])==4
judgments=[o['内容']['学習成立状態'] for o in outputs[30:45]]
assert [i+1 for i,s in enumerate(judgments) if s=='成立確認']==[4,7,9,11]
assert all(s in ('成立確認','接続途上') for s in judgments)
# Whole genuine outputs must equal the producer artifacts, not just selected conclusions.
producer=json.loads((R/'result_audit.json').read_bytes());summary=json.loads((R/'identity_result_summary.json').read_bytes())
assert producer['teacher_outputs']==plain(outputs[30:45]) and producer['teacher_judgments']==judgments
queries=json.loads((B/'arc-identity-teacher-plan-20261019/revision03_target_endpoint/query_index.json').read_bytes())
assert len(queries)==11
identity=[];projection_keys=('予測群','競合群','追加観測要求群','識別不能群','係争中原理群','断定保留理由群','学習成立状態')
raw_equal=[]
for i in range(30):
 before,after=outputs[i],outputs[45+i];row=producer['query_comparisons'][i]
 assert row['input']==c['plan'][i]['input'] and row['before']==plain(before) and row['after']==plain(after)
 raw_equal.append(records[f'{i+1:02d}.照会する.output'][0]==records[f'{i+46:02d}.照会する.output'][0])
 if i<11:
  assert before['状態']=='出力' and before['内容']['学習成立状態']=='適用外' and not before['内容']['予測群']
  q=c['plan'][i]['input'];value=next(iter(q['内容'].values()));prediction=after['内容']['予測群'];assert len(prediction)==1
  pred=prediction[0];assert tuple(pred['結果経路'])==(outcome,) and pred['予測値']==value and type(pred['予測値'])is int
  principle=next(p for p in active if p['原理識別子']==pred['原理参照']);assert principle['対象系境界']==q['対象系境界']
  observed_values={next(v for k,v in o['原入力'].items() if k!=outcome) for o in newobs if o['対象系境界']==q['対象系境界']}
  unseen=value not in observed_values;assert unseen==(queries[i]['kind']=='unseen_valid_color_algebraic_only')
  identity.append({'index':i,'kind':queries[i]['kind'],'value':value,'prediction':pred['予測値'],'principle':pred['原理参照'],'before_status':before['状態'],'before_learning_status':before['内容']['学習成立状態'],'unseen_in_this_boundary':unseen})
 else:
  assert before['状態']==after['状態']
  assert all(before['内容'][key]==after['内容'][key] for key in projection_keys)
  assert after['内容']['有効原理群'][:len(before['内容']['有効原理群'])]==before['内容']['有効原理群']
assert sum(x['unseen_in_this_boundary'] for x in identity)==4 and not any(raw_equal[11:])
assert summary['before_identity_prediction_counts']==[0]*11 and summary['before_identity_statuses']==['出力']*11
for a,b in zip(summary['identity_diagnostics'],identity):assert a['index']==b['index'] and a['kind']==b['kind'] and a['expected']==b['value'] and a['actual']==[b['prediction']]
for p in summary['new_active_principles']:
 actual=next(x for x in active if x['原理識別子']==p['原理識別子'])
 assert all(plain(actual[k])==v for k,v in p.items())
for a,b in zip(producer['snapshots'],snapshots):
 assert all(a[k]==b[k] for k in ('name','bytes','sha256','counters'))
 assert a['counts']['観測台帳']==b['observations'] and a['counts']['原理台帳']==b['principle_records']
assert producer['identity_diagnostics_exact'] and producer['old_smoke_relevant_equal'] and not producer['old_smoke_raw_equal']
assert producer['state_growth']==len((R/'run01/post_state.reserve').read_bytes())-len(baselinebytes)==557701
assert producer['max_reply_bytes']==maxout==43111
meta,_=framed(R/'run01/metadata_logs.reserve');completion=[wire(b) for h,b,o in meta if h['name']=='completed'];assert len(completion)==1
comp=completion[0];assert comp['native_calls_entered']==comp['native_calls_returned']==comp['fully_persisted_calls']==75
assert comp['unprocessed_suffix']['exact_remaining_calls']==0
for name in ('worker_failure','worker_emergency'):assert framed(R/'run01'/(name+'.reserve'))[0]==[]
sup=framed(R/'run01/supervisor_failure.reserve')[0];assert len(sup)==1 and wire(sup[0][1])['status']=='PASS'
assert wire(sup[0][1])==json.loads((R/'native_supervisor.json').read_bytes())
assert not any((R/'run01/failure_state.reserve').read_bytes())
# Independently verify every previously frozen artifact, including all failed runs and scripts.
previous_manifest=json.loads((B/'arc-native-teach-final-20261019/freeze_manifest.json').read_bytes());assert len(previous_manifest['files'])==181
for relative,pin in previous_manifest['files'].items():
 p=B/relative;h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(1024**2),b''):h.update(chunk)
 assert p.stat().st_size==pin['bytes'] and h.hexdigest()==pin['sha256'],relative
current_manifest=json.loads((R/'freeze_manifest.json').read_bytes())
for relative,pin in current_manifest['files'].items():
 p=R/relative;h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(1024**2),b''):h.update(chunk)
 assert p.stat().st_size==pin['bytes'] and h.hexdigest()==pin['sha256'],relative
sizes={d:sum(p.stat().st_size for p in pathlib.Path(d).rglob('*') if p.is_file()) for d in c['retained_directories']};unit=sum(p.stat().st_size for p in R.rglob('*') if p.is_file());assert unit<176*1024**2 and sum(sizes.values())+unit<512*1024**2
assert used==3121785<c['evidence_upper_bound_bytes']<8*1024**2;assert len((R/'run01/post_state.reserve').read_bytes())==6116344<c['state_upper_bound_bytes']
report={'verdict':'BOUNDED_NATIVE_IDENTITY_EVIDENCE_PASS','native_auditor_calls':0,'all64pins_verified':True,'all181_previous_frozen_files_unchanged':True,'all_current_frozen_files_verified':len(current_manifest['files']),'all_old_previous_prefixes_unchanged':True,'query_only_state_equal_except_counters':True,'final_counters':final['識別子状態'],'native_wall_seconds':wire(sup[0][1])['wall_seconds'],'native_calls':75,'queries':60,'teachers':15,'frames':243,'call_records':225,'snapshots':snapshots,'evidence_used_bytes':used,'max_input_bytes':maxin,'max_reply_bytes':maxout,'final_state_bytes':6116344,'state_growth_bytes':557701,'teacher_learning_statuses':judgments,'adaptation_teacher_ordinals':[4,7,9,11],'lineages':4,'principle_versions':8,'actual_relation_kinds':sorted(set(p['関係型'] for p in principles)),'new_active_principles':plain(active),'identity_queries':identity,'all19_smoke_relevant_equal':True,'old_smoke_raw_equal':raw_equal[11:],'delta_counts':{k:len(v) for k,v in delta.items()},'unit_actual_bytes':unit,'aggregate_actual_bytes':sum(sizes.values())+unit,'native_peak_rss_KiB':comp['peak_rss_KiB'],'audit_peak_rss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'limitations':['fixed revision03 paired target endpoint protocol','fixed mask/role/geometry/grouping prior not learned','15 correlated groups from5informative historical actions; zero new independent observations','4unseen colors test algebraic value identity not environment transfer','inverse lineages verified in state; queries test forward copies only','19smoke rows are not exhaustive prior-success regression','no SDK/Action/continuousMASK/fullgame/crossgame capability demonstrated']}
(O/'audit_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in report.items() if k not in ('snapshots','new_active_principles','identity_queries')},ensure_ascii=False,indent=2))
