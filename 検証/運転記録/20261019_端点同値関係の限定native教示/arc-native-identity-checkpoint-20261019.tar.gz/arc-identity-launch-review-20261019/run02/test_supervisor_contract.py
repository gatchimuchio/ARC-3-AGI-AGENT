import sys,pathlib,resource,unittest
from unittest.mock import patch
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2);sys.dont_write_bytecode=True
sys.path.insert(0,str(pathlib.Path('arc-native-identity-20261019').resolve()))
import launcher
class Store:
 def __init__(self,*a,**kw):self.closed=False;self.rows=[];self.fail=False
 def append(self,r,n,b):
  if self.fail and n=='supervisor_terminal':raise OSError('terminal record failure')
  self.rows.append((r,n,b))
 def close(self):self.closed=True
class Tests(unittest.TestCase):
 def setUp(self):self.s=Store();self.p=patch.object(launcher,'Store',lambda *a,**kw:self.s);self.p.start()
 def tearDown(self):self.p.stop()
 def test_fork_failure(self):
  with patch.object(launcher.os,'fork',side_effect=OSError('fork')):r=launcher.execute({'explicit_parent_admission':True})
  self.assertEqual(r['status'],'HOLD');self.assertTrue(self.s.closed);self.assertEqual(self.s.rows[0][1],'supervisor_error')
 def test_wait_failure_kills_reaps(self):
  with patch.object(launcher.os,'fork',return_value=123),patch.object(launcher.os,'waitpid',side_effect=[OSError('wait'),(123,9)]) as wait,patch.object(launcher.os,'kill') as kill:
   r=launcher.execute({'explicit_parent_admission':True});kill.assert_called_once();self.assertEqual(wait.call_count,2)
  self.assertEqual(r['status'],'HOLD');self.assertTrue(self.s.closed)
 def test_terminal_record_failure_holds(self):
  self.s.fail=True
  with patch.object(launcher.os,'fork',return_value=123),patch.object(launcher.os,'waitpid',return_value=(123,0)),patch.object(launcher.os,'kill') as kill:
   r=launcher.execute({'explicit_parent_admission':True});kill.assert_not_called()
  self.assertEqual(r['status'],'HOLD');self.assertTrue(self.s.closed);self.assertEqual(self.s.rows[0][1],'supervisor_error')
 def test_missing_admission_no_fork(self):
  with patch.object(launcher.os,'fork') as fork:
   with self.assertRaises(launcher.HOLD):launcher.execute({})
   fork.assert_not_called()
if __name__=='__main__':unittest.main(verbosity=2)
