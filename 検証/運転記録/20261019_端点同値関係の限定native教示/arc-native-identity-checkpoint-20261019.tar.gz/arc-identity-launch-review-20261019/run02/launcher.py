"""Scoped runner. Execution requires external explicit admission; no auto-run."""
import contextlib,resource,signal,os,time,pathlib,json,hashlib,sys
from bounded_store import Store,BoundedLog,HOLD,json_bytes,NativeSaveSink,install_known_write_boundary
from guard import Guard
M=1024**2
STATE_REGIONS=('normal_state','before_state',*(f'teach_{i:02d}_state' for i in range(1,16)),'post_state','failure_state')
CAPACITIES={**{n:8*M for n in STATE_REGIONS},'evidence':12*M,'metadata_logs':M,'worker_failure':M,'worker_emergency':M,'supervisor_failure':M}
assert sum(CAPACITIES.values())==168*M
ROOT=pathlib.Path(__file__).resolve().parent
CORE=ROOT.parent/'arc-native-query-20261019/frozen/HDS/学習系統/v0.4.2'
STATE=ROOT.parent/'arc-native-teach-final-20261019/run01/post_state.reserve'

def load_native():
 sys.path.insert(0,str(CORE))
 from hds学習系統 import HDS学習系統,外部入力
 from hds学習系統.永続化 import _符号化,_復号
 from source_allowlist import PERSISTENCE_SHA256
 from binding import verify
 def encode(x):return json.dumps(_符号化(x),ensure_ascii=False,indent=2).encode()
 def decode(x):return _復号(json.loads(x))
 source=STATE.read_bytes();baseline=decode(source)
 if encode(baseline)!=source:raise HOLD('native codec byte roundtrip')
 machine=HDS学習系統.読み込む(STATE)
 verify(machine,CORE/'hds学習系統/永続化.py',_符号化,_復号)
 return machine,外部入力,encode,decode,source,baseline

def worker(store,config):
 machine=None;g=None;stage='initialization';sink=NativeSaveSink(store)
 emergency=None
 def status():return {'stage':stage,**(g.progress() if g else {'native_calls_entered':0,'native_calls_returned':0,'fully_persisted_calls':0,'automatic_resume':False})}
 try:
  emergency=store.prepare_emergency(json_bytes({'status':'HOLD','frontier':'UNKNOWN','automatic_resume':False}))
  # Freeze method and JSON input bytes once, before loading native code.
  frozen_plan=tuple((row['method'],json_bytes(row['input'])) for row in config['plan'])
  if tuple(k for k,b in frozen_plan)!=('照会する',)*30+('処理する',)*15+('照会する',)*30:raise HOLD('exact method order')
  if frozen_plan[:30]!=frozen_plan[45:]:raise HOLD('before/after exact input mismatch')
  for p,h in config['pins'].items():
   if hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()!=h:raise HOLD('source/input pin mismatch')
  # Validate exact native constructor and new measurement-domain payloads before bootstrap.
  for i,(method,payload) in enumerate(frozen_plan):
   p=json.loads(payload)
   if type(p)is not dict or set(p)!={'内容','対象系境界','主体','対象','目的','文脈'}:raise HOLD('constructor keys')
   if type(p['内容'])is not dict or type(p['文脈'])is not dict or p['文脈']!={} or any(p[k]is not None for k in ('主体','対象','目的')):raise HOLD('constructor metadata')
   if i<11 or 30<=i<45 or 45<=i<56:
    prefix='公開塗布端点:作用前識別可能・固定幾何'
    if p['対象系境界'] not in (prefix+'内',prefix+'外'):raise HOLD('identity measurement boundary')
    source='作用前器具色' if p['対象系境界']==prefix+'内' else '作用前対象色'
    keys={source,'同一問題端点対象色'} if method=='処理する' else {source}
    if set(p['内容'])!=keys or any(type(v)is not int or not 0<=v<=15 for v in p['内容'].values()):raise HOLD('identity measurement color scope')
  def persist(name,payload):
   cap=16384 if name.startswith('snapshot.') else (65536 if name.endswith('.output') else 8192)
   if type(payload)is not bytes or len(payload)>cap:raise HOLD('record byte bound: '+name)
   header=json_bytes({'name':name,'bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest()})
   if len(header)>256:raise HOLD('record header byte bound')
   store.append('evidence',name,payload)
  from source_allowlist import PERSISTENCE_SHA256
  machine,外部入力,encode,decode,source,baseline=load_native()
  plan=[(method,encode(外部入力(**json.loads(payload)))) for method,payload in frozen_plan]
  if len(plan)!=75 or sum(k=='処理する' for k,b in plan)!=15:raise HOLD('exact75/15/60 plan')
  if any(len(b)>8192 for k,b in plan):raise HOLD('input byte bound')
  g=Guard(machine,encode,decode,persist,plan)
  previous=None
  def save(region,first=False,query_only=False):
   nonlocal previous,stage
   stage='saving:'+region
   receipt=sink.save(region,machine.保存する,source_file=CORE/'hds学習系統/永続化.py',expected_sha256=PERSISTENCE_SHA256)
   b=pathlib.Path(receipt['path']).read_bytes()
   if len(b)>config['state_upper_bound_bytes']:raise HOLD('analytical state bound exceeded')
   current=decode(b)
   if encode(current)!=b:raise HOLD('saved native codec exact readback')
   if first and b!=source:raise HOLD('normal roundtrip differs')
   for old in (baseline,previous):
    if old is None:continue
    for k,records in old['台帳'].items():
     if current['台帳'].get(k,())[:len(records)]!=records:raise HOLD('ledger prefix changed')
    if current['状態履歴'][:len(old['状態履歴'])]!=old['状態履歴']:raise HOLD('state history prefix changed')
    for k,records in old['原理履歴'].items():
     if current['原理履歴'].get(k,[])[:len(records)]!=records:raise HOLD('principle history prefix changed')
   if query_only:
    old=previous
    if old is None:raise HOLD('query-only prior checkpoint absent')
    if set(current)!=set(old):raise HOLD('query-only root changed')
    for key in current:
     if key!='識別子状態' and current[key]!=old[key]:raise HOLD('query-only state mutation')
    expected=dict(old['識別子状態'])
    expected['照会']+=30;expected['学習判定']+=30
    if current['識別子状態']!=expected:raise HOLD('query-only counters mismatch')
   # Full snapshots preserve every added field. This bounded index gives exact
   # slice coordinates, without duplicating complete states into evidence.
   delta={'state':region,'receipt':receipt,'counters':current['識別子状態'],
    'ledger_slices':{k:[len((previous or baseline)['台帳'].get(k,())),len(v)] for k,v in current['台帳'].items()},
    'principle_history_slices':{k:[len((previous or baseline)['原理履歴'].get(k,[])),len(v)] for k,v in current['原理履歴'].items()},
    'state_history_slice':[len((previous or baseline)['状態履歴']),len(current['状態履歴'])],
    'all_original_and_previous_prefixes_equal':True,'progress':g.progress()}
   persist('snapshot.'+region,json_bytes(delta));previous=current
   return current
  save('normal_state',True)
  with contextlib.redirect_stdout(BoundedLog(store,'stdout')),contextlib.redirect_stderr(BoundedLog(store,'stderr')):
   for i,(method,payload) in enumerate(frozen_plan):
    stage='native:'+str(i+1)+':'+method;external=外部入力(**json.loads(payload))
    if method=='処理する':g.処理する(external)
    else:g.照会する(external)
    if i==29:save('before_state',query_only=True)
    elif 30<=i<=44:save(f'teach_{i-29:02d}_state')
  after=save('post_state',query_only=True)
  if len(after['台帳']['観測台帳'])!=204:raise HOLD('nominal complete observation count not met')
  store.append('metadata_logs','completed',json_bytes({'status':'PASS','scope':'native calls/checkpoint persistence only; outcome review pending',**status(),'peak_rss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}))
 except BaseException as error:
  if g:g.failed=True
  try:store.append('worker_failure','failure',json_bytes({'status':'HOLD','type':type(error).__name__,'args':repr(error.args),**status()}))
  except BaseException:
   try:store.append('worker_emergency','small_frontier',json_bytes({'status':'HOLD',**status()}))
   except BaseException:
    try:
     if emergency is not None:store.raw_emergency(emergency)
    except BaseException:pass
  if machine is not None:
   try:sink.save('failure_state',machine.保存する,source_file=CORE/'hds学習系統/永続化.py',expected_sha256=PERSISTENCE_SHA256)
   except BaseException as secondary:
    try:store.append('worker_failure','failure_state_error',json_bytes({'type':type(secondary).__name__,**status()}))
    except BaseException:pass
  raise

def execute(config):
 # Caller supplies reviewed admission. Make an independent immutable byte copy
 # before allocating/launching so external config mutation cannot affect work.
 config=json.loads(json_bytes(config))
 if config.get('explicit_parent_admission') is not True:raise HOLD('parent execution admission required')
 store=Store(ROOT/'run01',CAPACITIES,total_limit=176*M)
 pid=None;start=time.monotonic();report=None
 try:
  pid=os.fork()
  if pid==0:
   try:
    resource.setrlimit(resource.RLIMIT_AS,(512*M,)*2);resource.setrlimit(resource.RLIMIT_CPU,(120,120));resource.setrlimit(resource.RLIMIT_FSIZE,(8*M,)*2)
    def timeout(*a):raise HOLD('compute deadline')
    signal.signal(signal.SIGALRM,timeout);signal.alarm(120)
    install_known_write_boundary();worker(store,config);os._exit(0)
   except BaseException:os._exit(1)
  killed=False
  while True:
   done,status=os.waitpid(pid,os.WNOHANG)
   if done:pid=None;break
   if time.monotonic()-start>240:
    os.kill(pid,signal.SIGKILL);_,status=os.waitpid(pid,0);pid=None;killed=True;break
   time.sleep(.02)
  report={'status':'PASS' if status==0 else 'HOLD','wait_status':status,'wall_seconds':time.monotonic()-start,'wall_killed':killed,'call_frontier':'worker persisted evidence if complete; otherwise UNKNOWN; never automatic resume','writer_scope':'known Python native closure; not physical persistence or hostile sandbox guarantee'}
  store.append('supervisor_failure','supervisor_terminal',json_bytes(report))
 except BaseException as error:
  if pid is not None and pid>0:
   try:os.kill(pid,signal.SIGKILL)
   except ProcessLookupError:pass
   try:os.waitpid(pid,0)
   except ChildProcessError:pass
  report={'status':'HOLD','supervisor_error':type(error).__name__,'call_frontier':'UNKNOWN; inspect durable worker evidence','automatic_resume':False}
  try:store.append('supervisor_failure','supervisor_error',json_bytes(report))
  except BaseException:pass
 finally:store.close()
 return report
if __name__=='__main__':
 raise SystemExit('No automatic CLI execution. Requires explicit parent admission and frozen reviewed configuration.')
