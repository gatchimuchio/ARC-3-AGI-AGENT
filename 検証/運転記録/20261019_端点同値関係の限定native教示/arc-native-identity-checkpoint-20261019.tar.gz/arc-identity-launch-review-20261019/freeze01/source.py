import pathlib,json,hashlib,resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
B=pathlib.Path(__file__).resolve().parent.parent;O=pathlib.Path(__file__).resolve().parent;R=B/'arc-native-identity-20261019';P=B/'arc-identity-teacher-plan-20261019/revision03_target_endpoint';old=B/'arc-native-teach-final-20261019'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
c=json.loads((R/'proposed_config.json').read_bytes());assert not c['explicit_parent_admission'];assert len(c['pins'])==64
for p,pin in c['pins'].items():assert h(pathlib.Path(p))==pin,p
plan=json.loads((P/'proposed_plan.json').read_bytes())['plan'];assert c['plan']==plan
assert tuple(x['method'] for x in plan)==('照会する',)*30+('処理する',)*15+('照会する',)*30
assert plan[:30]==plan[45:]
q=json.loads((P/'queries.runtime.json').read_bytes());t=json.loads((P/'teachers.runtime.json').read_bytes());assert [x['input'] for x in plan[:30]]==q and [x['input'] for x in plan[30:45]]==t
assert q[11:]==[x['input'] for x in json.loads((old/'proposed_config.json').read_bytes())['plan'][:19]]
assert h(P/'prepare.py')=='692bbba43be0366aa0819c1ed2b4a075c8619f1222c050fb623a3815e296629b'
for pin in json.loads((P/'MANIFEST.json').read_bytes())['files']:
 p=P/pin['path'];assert p.stat().st_size==pin['bytes'] and h(p)==pin['sha256']
for n in ['binding.py','gate_metadata.py','source_allowlist.py','guard.py']:assert (R/n).read_bytes()==(old/n).read_bytes()
assert h(R/'binding.py')=='43574797de492ef1a49b7498ee23a4ac410935b6c1dc0432baa7b43b17a52720'
state=old/'run01/post_state.reserve';assert state.stat().st_size==5558643 and h(state)=='3a0e57e44cf2385f70be34bd5908bb9b78de0c7251b3a688d2d27b5e1d21ad84'
assert c['state_upper_bound_bytes']==7221324 and c['reply_upper_bound_bytes']==60103 and c['reply_cap_bytes']==65536
bound=75*65536+150*8192+19*16384+244*264;assert bound==6519712==c['evidence_upper_bound_bytes'] and bound<8*1024**2
retained={p:sum(x.stat().st_size for x in pathlib.Path(p).rglob('*') if x.is_file()) for p in c['retained_directories']};new=sum(p.stat().st_size for p in R.rglob('*') if p.is_file());assert new+168*1024**2<176*1024**2
aggregate=sum(retained.values())+176*1024**2;assert aggregate<512*1024**2
for p in (O/'run03').glob('*.exit_status'):assert p.read_text().strip()=='0'
assert (O/'run04/exit_status').read_text().strip()=='0'
r={'verdict':'BOUNDED_STATIC_PURE_PASS_NOT_NATIVE_ADMISSION','config_sha256':h(R/'proposed_config.json'),'all64pins_match':True,'revision03_measurement_manifest_verified':True,'exact75plan_verified':True,'calls':75,'query_calls':60,'teacher_calls':15,'nominal_snapshots':18,'call_records':225,'total_nominal_frames':243,'single_use_state_slots':19,'fixed_reservation_bytes':168*1024**2,'unit_limit_bytes':176*1024**2,'reply_cap_bytes':65536,'reply_static_bound_bytes':60103,'active_evidence_bound_bytes':bound,'evidence_reservation_bytes':12*1024**2,'unchanged_binding_guard_metadata_allowlist':True,'native_reviewer_calls':0,'independent_tests':33,'provided_tests':21,'additional_os_limit_probe_pass':True,'new_preparation_bytes':new,'retained_bytes':retained,'retained_plus_full_newunit_bytes':aggregate,'aggregate_proposal_limit_bytes':512*1024**2,'parent_admission_required':True,'files':{p.name:{'bytes':p.stat().st_size,'sha256':h(p)} for p in list(R.glob('*.py'))+[R/'proposed_config.json']]}}
(O/'reviewed_manifest.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in r.items() if k not in ('files','retained_bytes')},indent=2))
