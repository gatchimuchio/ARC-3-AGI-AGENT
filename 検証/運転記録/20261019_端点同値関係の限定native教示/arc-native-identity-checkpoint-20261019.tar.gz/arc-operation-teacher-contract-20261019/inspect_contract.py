"""Read-only source/wire analysis. Does not import, restore, or call HDS."""
import ast,collections,hashlib,json,pathlib,resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
R=pathlib.Path(__file__).resolve().parent; B=R.parent
core=B/'arc-native-query-20261019/frozen/HDS/学習系統/v0.4.2/hds学習系統'
def dec(x):
 if isinstance(x,list):return [dec(v) for v in x]
 if isinstance(x,dict):
  if '__辞書__' in x:return {dec(k):dec(v) for k,v in x['__辞書__']}
  if '__組__' in x:return tuple(dec(v) for v in x['__組__'])
  return {k:dec(v) for k,v in x.items()}
 return x
sources=list(core.glob('*.py'))+list((B/'arc-goal6-action-bridge-20261019/origins').glob('*.py'))+[B/'arc-goal6-action-bridge-20261019/all6_full_attribution_v2.json',B/'arc-native-teach-final-20261019/run01/post_state.reserve', B/'arc-goal6-action-bridge-20261019/README.md',B/'arc-goal6-action-bridge-20261019/TEACHER_PLAN.md']
pins=[{'path':str(p.relative_to(B)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sources]
s=dec(json.loads(sources[-4].read_bytes())) if False else dec(json.loads((B/'arc-native-teach-final-20261019/run01/post_state.reserve').read_bytes()))
principles=[p['値'] for p in s['台帳']['原理台帳']]
summary=[{k:p[k] for k in ('原理識別子','対象系境界','関係型','条件経路群','結果経路')} for p in principles]
a=json.loads((B/'arc-goal6-action-bridge-20261019/all6_full_attribution_v2.json').read_bytes()); cases=[]
for c in a:
 rows=c['all100_target_attributions'];inside=[];outside=[];contradictions=[]
 for x in rows:
  if not x['precondition_observably_identifiable']:continue
  z=next(z for z in x['all_after_phases'] if z['phase']==13)
  assert z['same_problem_binding']
  pair=[x['tool'] if x['mask_hypothesis'] else x['before'],z['after_color']]
  (inside if x['mask_hypothesis'] else outside).append(pair)
  if pair[0]!=pair[1]:contradictions.append(x['target'])
 cases.append({'case':c['case'],'source_selection':c['selection'],'counts':dict(collections.Counter(x['endpoint_class'] for x in rows)),'inside_value_pairs':sorted(set(map(tuple,inside))),'outside_value_pairs':sorted(set(map(tuple,outside))),'contradictions':contradictions})
# Pure finite witness of representational limitation; these are synthetic diagnostic tuples, never teachers.
triples=[(m,a,b,b if m else a) for m in (False,True) for a in (0,1) for b in (0,1)]
lim={'synthetic_only':True,'assignment_tuples':triples,'no_single_leaf_identity':{name:any(row[i]!=row[3] for row in triples) for i,name in enumerate(['membership','prior','tool'])},'three_field_deterministic_representable_only_if_packed_or_extra_condition_capacity':'Current default max2; packed three values give only seen-key lookup. Not a generic conditional-copy operator.'}
report={'state_principles':summary,'cases':cases,'limitation':lim,'native_calls':0,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(R/'inspection.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');(R/'source_pins.json').write_text(json.dumps(pins,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'principles':len(summary),'cases':len(cases),'native_calls':0,'peak_rss_kib':report['peak_rss_kib']}))
