# Next operation teaching contract, read-only design

## Recommendation

Use the existing HDS **value identity relation** to learn two scoped endpoint relations: tool-value → observed-after-value on the hypothesized inside region; prior-value → observed-after-value on the outside region. This can reuse an unseen color value in a native Query. It is a meaningful step beyond another four-row Boolean table, but does not learn the mask, conditional composition, action-role classifier, or geometry. Do not execute yet: the exact historical raw-value teaching contract is unavailable, and this proposal requires measurement-contract and resource review.

No HDS import/restore/Query/Teach/save, SDK, Action, or Git operation occurred. Sources and final serialized state were inspected only. Native v0.4.2 remains unchanged. Parent scope: 512MiB AS, 96MiB new directory. Inspection peak RSS30,192KiB.

## Existing capability and actual state

Frozen 推論.py generates 同値関係 when exactly one condition leaf equals the result leaf throughout the complete supporting rows; otherwise 決定的対応関係. At least3 supporting rows and2 distinct condition values are required by 推論.py/検証.py. These are learner row thresholds, not independent causal-evidence counts. Default 最大条件数=2; additional conditions are searched only when doubt requests them. 吸気系.py recursively flattens dictionaries/lists into fixed paths, not variable object/pixel binders. 適応.py:134–137 predicts an identity relation by returning the new source value directly; deterministic correspondence requires an observed serialized key. No native induction of an arithmetic rotation, geometric predicate, conditional assignment, or universal pixel iterator appears in these generation/application paths.

inspection.json lists all19 principle versions in the final189-experience state. It contains column relations and the endpoint-progress lineage, not the three wide-paint boundaries below. This is a scoped serialized-state check, not a claim that no historical state exists. Historical Color3/Query3/Color12/Query1 and native29489/fixture18870 closures remain unresolved per the existing bridge investigation; no missing state or support has been invented.

## Exact existing adapter contracts

All use 外部入力(内容=<mapping>, 対象系境界=<below>, 主体=None, 対象=None, 目的=None, 文脈={}); actual processing method is 処理する. Queries omit the outcome leaf. Source is origins/関係.py, consumed by origins/予測.py.

1. COPY boundary 公開色対応:参照色と解答候補色: input leaf 候補色は参照役割色と一致 (bool), result 候補色は結果役割色と一致 (bool). This is candidate-membership identity, NOT raw-color copying. Palette→tool and reference→goal use different role interpretations; evidence for one does not license the other.
2. MASK boundary 公開塗布:器具側幾何と可視上書き:広域塗布: input 幾何領域候補に属する (bool), result 観測上この画素は器具色で上書き (bool). Small-mode suffix is 小域塗布. Half-plane depth≥0 and small-mask geometry are hardcoded membership priors. Existing prediction applies Python `if v: canvas[y][x]=color`; the assignment itself is adapter code, not learned HDS operation semantics.
3. TURN boundary 公開器具:現在方向と方向作用: input 現在方向と方向作用 = compact JSON string [direction,action_id], result 後方向 = compact JSON direction string. Native learning can acquire the witnessed direction/action correspondence; unseen pairs require observation. Neither numeric relative rotation nor 8×4 closure follows from a subset. Native results do not discover Action1–4 meaning, since classify already assigns it.

No recovered historical MASK training producer establishes whether its outcome meant endpoint or continuous overwrite. Do not reuse its unqualified label for new endpoint-only data without resolving that meaning.

## Proposed minimal raw-value contracts (new measurement schema, not native operators)

Common typed native constructor fields are unchanged. New boundary names disclose scope rather than smuggling a correct answer into a label:

A boundary 公開塗布端点:作用前識別可能・固定幾何内
内容 = {"作用前器具色": <int tool>, "同一問題端点対象色": <int observed_after>}
Query内容 = {"作用前器具色": <int tool>}

B boundary 公開塗布端点:作用前識別可能・固定幾何外
内容 = {"作用前対象色": <int prior>, "同一問題端点対象色": <int observed_after>}
Query内容 = {"作用前対象色": <int prior>}

For both, 主体/対象/目的=None and 文脈={}. No case ID, game ID, recording path, hash, coordinate index, expected color, or success flag is a runtime solution key. Coordinates, original Action, all raw phases, object bindings, and attribution stay in external evidence. These exact field names are a PROPOSAL, not a previously verified historical payload. Existing Boolean COPY consumers will not consume these automatically; any future adapter integration requires separate review and must retain explicit provenance of fixed routing.

Routing eligibility must be determined solely from BEFORE facts: unique supported target/tool binding, observed Action and arguments, declared endpoint protocol, prior≠tool, and the already-disclosed fixed geometric membership. The after color must always be measured, never assigned from the tool/prior or selected for equality. Include all eligible cells and every contradiction; preserve all ineligible/unknown cells as evidence. Do not choose a boundary by which color matched afterward. Do not encode presumed overwrite in the outcome or boundary name.

Old-problem phase13 and14 are duplicated views of one Action, not two independent teachers. A frozen measurement plan must specify endpoint selection independently of prediction fit, and retain both phases plus all unknowns and phase15 rebinding. There are 450 informative cells but only5 informative historical Actions across2 recordings. A practical plan should retain every cell and all6 Actions; explicitly group correlated support outside the native row count. Do not present passing minimum3 rows as3 independent interventions. No runnable teacher batch is emitted by this design.

## Available support and counterexample requirements

All6×100 attribution rows were re-read. Cases0,1,2,4,5 have inside change-to-tool and outside preserve-prior contrasts. Inside value pairs are 12→12,14→14,0→0 across both recordings; outside values include0,8,12,15. The source therefore has the two-value diversity required for identity candidates. There are210 observable changes,240 observable preservations,150 prior=tool ambiguous pixels. Case3 is entirely ambiguous and supplies zero informative overwrite support. inspection.json retains per-case value diversity and zero observed endpoint-copy contradictions. This is agreement with a fixed geometry hypothesis, not proof that the hypothesis is uniquely correct.

Retain/review: inside output≠tool; outside output≠prior; tool changing during response; any binding ambiguity; unsupported role/click; unknown phase; changed reference/goal; no-op and invalid action. For inside copy, varied old colors and tool colors distinguish no-op and constant-output rivals. For outside preservation, differing tool colors and outside prior colors distinguish global overwrite. Further independent public observations should vary direction/device/size and role bindings, with current≠tool cells on both sides, rather than replay the same recording. Unseen-color Query is only algebraic transfer within a learned identity boundary; fresh environment and cross-game transfer still need actual observations.

For actual palette COPY, recover actual Action6 click→tool changes with multiple selected colors, contrasting unselected candidates and exact click offsets. For goal COPY, require public acceptance/completion evidence and alternatives; score increase alone does not prove reference equality is necessary. For TURN, recover direction/action response pairs and all alternatives/no-ops; do not extrapolate32 pairs from a few. None of these observations is supplied by the six Action5 examples alone.

## Expected HDS and application gates

Three or more complete consistent rows with≥2 distinct source values can generate forward and reverse identity candidates; exact adoption, support/refutation, additional observation requests, competing rules and whole reply must be observed in a separately admitted native experiment. No prediction of guaranteed native PASS is made. A relation with a mismatch can become a finite correspondence or fail/conflict; reject any attempt to call such output an identity-copy success.

Before/after queries should cover each actual teacher condition, held-out source values (diagnostic only), missing/wrong-type inputs, prior ambiguity negatives, and all existing regressions. Preserve all complete replies, ledgers, refutations, and applicability changes. Strict integer color/role/type scope is an external measurement contract: native identity is value-polymorphic and does not independently enforce a color domain. Never query raw lists as an atomic color or use strings to hide whole objects while claiming object learning.

At application time, the two learned equalities can supply value predictions. The inside/outside branch, every-pixel composition, geometry, target binding, Action5 role, and subsequent rendering remain prior/adapter operations. A one-step action still needs current packet, complete candidate set, exact Action and target permission, all response-phase gates, and independent authorization. Endpoint equality is not necessary-condition proof or action safety. Existing predictors deliberately keep 実行許可=False.

## vNext candidate, bounded limitation

The synthetic diagnostic in inspection.json enumerates m∈{false,true}, old/tool∈{0,1}, result=tool if m else old. No single input leaf is universally identical to result. Native single-leaf identity therefore cannot express the unsplit conditional assignment. Default two-condition lookup also omits one independently varying input; packing all three into a string permits a seen-key table but does not induce a selector or unseen-value substitution. This is a pure finite representational check plus source inspection, not an executed native failure.

Existing scoped identity composition remains viable as above; it avoids falsely declaring all operation learning impossible. What is missing is learned guarded variable binding/composition and geometry/rotation operator induction, with typed applicability and evidence-unit awareness. Log those as vNext research candidates only. Do not modify the current core or replace them with a new fixed grammar described as learned.
