# Frozen historical snapshot identity measurement proposal

Status: OFFLINE ONLY. Historical qualified snapshots, NOT a generic runtime endpoint selector. Native execution and action adoption are blocked pending review and separate admission.

## Meaning and protocol

The two proposed boundaries are 公開塗布端点:作用前識別可能・固定幾何内 and 公開塗布端点:作用前識別可能・固定幾何外. These are new measurement names, not recovered historical teaching contracts. The word 端点 here denotes the qualified historical old-problem snapshots below; it must not be interpreted as generic final Action effect.

The recovered attribution corpus identifies after phase13 and14 as matching old-problem public bindings. This plan fixes those indices in advance of value grouping and never searches for a phase whose color matches a prediction. However their selection originated in historical analysis. No outcome-independent structural stability selector has been established for arbitrary future packets. Therefore the plan explicitly declines runtime endpoint projection and causal final-effect claims. It is still legitimate to measure the observed colors of those declared snapshots. Phase14 is a repeated snapshot, not another independent Action. All phases0–15 where present, including early mismatches,77 unknown interpretations, and phase15 goal rebinding, remain evidence. Do not infer that intermediate preservation holds.

Before eligibility uses the v3 pure bridge: full raw terminal before frame, nonterminal status, legal Action5 with no runtime coordinates, unique instrument-role guard, exact existing device template, existing structural target/tool parser, and prior target color != tool color. The fixed membership formula partitions inside/outside. Action5 role, geometry and template meanings remain prior hypotheses. No after value affects this partition. Source/game IDs are evidence keys only.

Group key is (original Action, source value available BEFORE, inside/outside). Source value is tool color inside, prior target color outside. This precisely defines 'before value'; inside groups can contain different prior target colors, all of which are retained cell-by-cell. Build all membership lists before reading any after outcomes. For every group, measure actual raw target pixel colors at phases13/14 through the BEFORE target rectangle, cross-check the retained attribution and binding. Emit one teacher per distinct actual outcome, preserving contradictory labels if any. No majority vote, no dropped contradictory cell, no duplicate phase counted as a new intervention.

All600 cells are retained.450 qualify;150 have prior=tool and remain HOLD, including all100 cells of case3. Fifteen groups each have one actual phase13/14 outcome; no identity contradiction in these selected snapshots. all_group_phase_outcomes.json separately exposes every group's early mismatches, unknown phases and changed-binding observations. This is15 native experiences if admitted,5 informative historical interventions from2 recordings,6 Actions retained,0 new environmental observations.

## Exact payload and queries

Inside content: {作用前器具色: integer measured tool color, 同一問題端点対象色: integer measured snapshot color}.
Outside content: {作用前対象色: integer measured prior target color, 同一問題端点対象色: integer measured snapshot color}.
All constructors use exactly 内容,対象系境界,主体,対象,目的,文脈, with metadata null and context {}. No provenance in runtime content. teachers.runtime.json fixes15 rows in case order, then sorted before-group key, then distinct measured outcome.

queries.runtime.json has30 rows. First7 are every distinct observed source color (inside0,12,14; outside0,8,12,15). Next by boundary ordering are4 algebraic probes: colors1 and2 absent from the corresponding training boundary. Their validity domain is the declared public color-index0..15 measurement scope, not proof that a fresh environment uses those colors in these roles. Queries omit the result leaf. Native identity's unseen-value result is algebraic transfer only. Query index records exact ordering. Then19 previous rows retain6 goal6 queries,4 existing controls,9 historical boundary smoke cases. Nineteen is the number of stored principle versions, not19 distinct boundaries; the regression pack spans10 actual boundaries. Full historical-success regression is unavailable.

Exact planned sequence:30Query,15処理する,30 identical Query =75 calls (60Query/15Teach). Before/after all observed values are covered; identical grouped input values need not be duplicated in Query, while every actual teacher group remains. This is a proposed caller plan, not the previous44-call launcher/config. No native call has occurred.

Seventeen scope probes reject missing content/source, bool, string, float, list, negative/out-of-range color, missing constructor field, unknown top-level key, and non-dict context. These are caller HOLD results, not native HOLD observations; rejected inputs never enter the proposed native plan. Native value identity is untyped, so caller scope checks are essential.

## Expected learning, limits and regression

Two fields per boundary permit forward/reverse identity candidates, at most4 new lineages. Closed prefix analysis proposes22 candidate events and8 adoptions/4 changed calls; these are analytical limits, not actual native outcomes. Admission requires retaining complete reply/HOLD/ambiguity, support/refutation, adoption and state histories. A native result alone must not be interpreted as trained conditional assignment: branch selection, mask, pixel iteration, role/classifier and rendering remain fixed outside HDS.

Compare complete raw replies plus a named relevant prediction/HOLD/conflict/request projection. Raw replies can change from added active principle summaries and counters. Preserve all189 prior experience prefixes and all19 prior principle records and histories. Regressions are one-case smoke coverage plus repeated goal6 conditions, not exhaustive transfer or full prior-success proof.

## Resource proposal, not admission

Current native source is frozen post-state189 experiences/19 principle records, paired counters6698,5,558,643 bytes, SHA3a0e57e44cf2385f70be34bd5908bb9b78de0c7251b3a688d2d27b5e1d21ad84. Input state remains external read-only.

The first coarse envelope13,357,427B is retained. Summing exact-shaped per-record envelopes instead of charging every record32KiB gives proposed full-state upper7,221,324B. Proof ingredients:15*(experience+cognitive+5doubt+learning+feedback),22*(inference+evidence+judgment),8*(two principle copies+provisional+update),4state snapshots,32KiB wrapper/counter allowance. Fields are padded to15 support references,15 table rows,20 active snapshot entries and conservative UTF-8 widths. No conflicts, old-boundary mutation or isolation are allowed by the closed equal-pair data; reviewer must independently verify these exclusions.

Proposed new native unit176MiB:19×8MiB state slots (normal,before,15teach,post,failure),12MiB evidence,4×1MiB metadata/worker-failure/emergency/supervisor,8MiB code/reports/partial-write allowance. Proposed reply cap128KiB requires its own closed projection proof; it is NOT yet proved. Evidence arithmetic75×128KiB+150×8KiB+19×16KiB+244×264 =11,434,912B <12MiB, assuming those separately verified per-frame caps. AS512MiB proposed; CPU/wall require caller admission. Free-floor and retained earlier runs must be included in aggregate admission; no allocation/reservation/reuse occurred. Native save truncation/ENOSPC evidence limitation remains, and no absolute failure-retention guarantee is made.

Current preparation stays within its authorized96MiB directory and AS512MiB. No native execution until independent measurement/source/growth/reply/caller review and explicit parent admission. No SDK, Action, Git, core modifications, or runtime adoption.

## Revision preservation

revision01/ preserves every source and produced artifact before review correction. Reviewer found top-level constructor scope was permissive; revised prepare.py now requires exact keys and strict dict context, with17 rejection probes. All15 teacher payloads and75-call plan are unchanged. Literal phase13/14 selection was not silently generalized: this document explicitly freezes historical qualified snapshot semantics and blocks runtime endpoint adoption. Both initial coarse and refined growth proposals remain.
