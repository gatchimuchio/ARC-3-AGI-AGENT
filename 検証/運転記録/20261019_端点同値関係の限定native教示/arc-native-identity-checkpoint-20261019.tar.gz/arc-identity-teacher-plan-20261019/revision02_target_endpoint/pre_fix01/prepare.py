"""Offline measurement plan; pure bridge only, never imports/calls native HDS."""
import json,pathlib,hashlib,resource,importlib.util,collections
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
R=pathlib.Path(__file__).resolve().parent;B=R.parent.parent;BR=B/'arc-goal6-action-bridge-20261019';W=B/'arc-teacher-contrasts-20261019'
def read(p):return json.loads(p.read_bytes())
def write(n,x): (R/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def pin(p):return {'path':str(p.relative_to(B)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
spec=importlib.util.spec_from_file_location('identity_pure_bridge',BR/'bridge.py');br=importlib.util.module_from_spec(spec);spec.loader.exec_module(br)
a=read(BR/'all6_full_attribution_v2.json'); phases=read(BR/'all_phases.json');joined=read(W/'goal6_full_witness_joins.json')
bounds={True:'公開塗布端点:作用前識別可能・固定幾何内',False:'公開塗布端点:作用前識別可能・固定幾何外'}
fields={True:'作用前器具色',False:'作用前対象色'}; outcome='同一問題端点対象色'
def payload(inside,v,y=None):
 d={fields[inside]:v}
 if y is not None:d[outcome]=y
 return dict(内容=d,対象系境界=bounds[inside],主体=None,対象=None,目的=None,文脈={})
# Protocol: before-reference prefix terminal two verified bindings/equal target crops;
# no literal phase indices or earlier fallback. All unknowns/transition phases retained.
def endpoint_pair(before,after):
 # Entire packet reference-prefix boundary, independently of target prediction.
 initial=br.phase(before['frame'][-1],before['state'],before['available_actions'])
 if initial['scene'] is None:raise ValueError('before_binding_missing')
 sc=initial['scene'];rx,ry,rX,rY=sc['参照矩形'];tr=sc['対象矩形']
 same=[ [row[rx:rX] for row in frame[ry:rY]]==sc['参照'] for frame in after['frame'] ]
 if not same or not same[0]:raise ValueError('old_reference_prefix_missing')
 end=next((i for i,v in enumerate(same) if not v),len(same))-1
 if any(same[end+1:]):raise ValueError('reference_returns_after_transition')
 if end<1:raise ValueError('terminal_pair_missing')
 pair=(end-1,end);parsed=[]
 for i in pair:
  o=br.phase(after['frame'][i],after['state'],after['available_actions'])
  q=o['scene']
  if q is None or not o['exact_existing_device_template']:raise ValueError('terminal_binding_unverified')
  if q['参照矩形']!=sc['参照矩形'] or q['対象矩形']!=tr or q['参照']!=sc['参照'] or q['大きさ']!=sc['大きさ']:raise ValueError('terminal_binding_changed')
  parsed.append(q)
 if parsed[0]['対象']!=parsed[1]['対象']:raise ValueError('terminal_target_unstable_no_fallback')
 if not all(before.get(k)==after.get(k) for k in ('guid','game_id')) or before.get('full_reset') is not False or after.get('full_reset') is not False or after['state']!='NOT_FINISHED':raise ValueError('pair_scope_invalid')
 return pair

groups=[];cells=[];case_scopes=[];rawpins=[]
for c in a:
 case=c['case'];j=joined[case];bef=read(W/j['raw_before'])['data'];aft=read(W/j['raw_after'])['data']
 rawpins.extend([pin(W/j['raw_before']),pin(W/j['raw_after'])])
 before=br.phase(bef['frame'][-1],bef['state'],bef['available_actions'])
 selected=endpoint_pair(bef,aft)
 action=aft['action_input']; scope=before['scene'] is not None and before['exact_existing_device_template'] and bef['state']=='NOT_FINISHED' and 5 in bef['available_actions'] and action['id']==5 and set(action['data'])<= {'game_id'}
 assert scope
 scene=before['scene']; grouped={}
 for x in c['all100_target_attributions']:
  xx,yy=x['target'];prior=scene['対象'][yy][xx];tool=scene['器具色'];inside=br.P['membership'](scene['方向'],xx,yy,scene['大きさ'],'広域塗布')
  assert prior==x['before'] and tool==x['tool'] and inside==x['mask_hypothesis']
  eligible=scope and prior!=tool; src=tool if inside else prior
  row={'case':case,'source_selection':c['selection'],'target':x['target'],'before_target':prior,'before_tool':tool,'inside':inside,'eligible':eligible,'group_key':[case,src,inside] if eligible else None,'hold_reason':None if eligible else 'before_target_equals_tool_unidentifiable','all_after_phases':x['all_after_phases']}
  cells.append(row)
  if eligible:grouped.setdefault((case,src,inside),[]).append(row)
 # Groups are complete BEFORE any observed after colors are used for labels.
 for key,members in sorted(grouped.items()):
  actuals=collections.defaultdict(list)
  for row in members:
   for phase in selected:
    obs=next(z for z in row['all_after_phases'] if z['phase']==phase)
    assert obs['same_problem_binding'] and type(obs['after_color']) is int
    # Cross-check actual raw public pixel through the fixed BEFORE target rectangle.
    xx,yy=row['target'];cx,cy,_,_=scene['対象矩形'];actual=aft['frame'][phase][cy+yy][cx+xx]
    assert actual==obs['after_color']
    actuals[actual].append({'target':row['target'],'phase':phase})
  groups.append({'key':list(key),'before_source_value':key[1],'inside':key[2],'cell_count':len(members),'cells':[r['target'] for r in members],'actual_outcomes':[{'value':v,'observations':refs,'contradicts_identity':v!=key[1]} for v,refs in sorted(actuals.items())]})
 case_scopes.append({'case':case,'source_selection':c['selection'],'before_scope':scope,'before_phase':len(bef['frame'])-1,'direction':scene['方向'],'tool':scene['器具色'],'before_scene':scene,'selected_endpoint_pair':selected,'all_after_phase_count':len(aft['frame'])})
teachers=[];teacher_index=[]
for g in groups:
 for out in g['actual_outcomes']:
  teacher_index.append({'teacher_index':len(teachers),'group_key':g['key'],'cell_count':g['cell_count'],'actual_outcome':out['value'],'contradicts_identity':out['contradicts_identity']})
  teachers.append(payload(g['inside'],g['before_source_value'],out['value']))
observed={k:sorted({g['before_source_value'] for g in groups if g['inside']==k}) for k in (True,False)}
queries=[];query_index=[]
for inside in (True,False):
 for val in observed[inside]+[v for v in (1,2) if v not in observed[inside]]:
  query_index.append({'index':len(queries),'inside':inside,'value':val,'kind':'observed_value' if val in observed[inside] else 'unseen_valid_color_algebraic_only'})
  queries.append(payload(inside,val))
old=read(B/'arc-native-teach-final-20261019/proposed_config.json')['plan'][:19]
queries.extend(x['input'] for x in old)
# Scope rejection is caller-side, not forged native HOLD. No invalid input is submitted.
def valid(p):
 if type(p)is not dict or set(p)!={'内容','対象系境界','主体','対象','目的','文脈'}:return False
 if type(p['文脈'])is not dict:return False
 if p.get('対象系境界') not in bounds.values():return False
 inside=p['対象系境界']==bounds[True];d=p.get('内容')
 return type(d)is dict and set(d)=={fields[inside]} and type(d[fields[inside]])is int and 0<=d[fields[inside]]<=15 and all(p.get(k)is None for k in ('主体','対象','目的')) and p.get('文脈')=={}
probes=[]
for inside in (True,False):
 for name,value in [('missing',None),('bool',True),('string','12'),('float',12.0),('negative',-1),('outside_palette',16),('list',[12])]:
  p=payload(inside,value)
  if name=='missing':p['内容']={}
  accepted=valid(p);assert not accepted;probes.append({'inside':inside,'case':name,'input':p,'caller_scope_result':'HOLD','native_call':False})
for name in ('missing_subject','extra_key','context_list'):
 p=payload(True,12)
 if name=='missing_subject':del p['主体']
 if name=='extra_key':p['unexpected']=True
 if name=='context_list':p['文脈']=[]
 assert not valid(p);probes.append({'case':name,'input':p,'caller_scope_result':'HOLD','native_call':False})
assert all(valid(q) for q in queries[:len(query_index)])
plan=[{'method':'照会する','input':q} for q in queries]+[{'method':'処理する','input':t} for t in teachers]+[{'method':'照会する','input':q} for q in queries]
write('teachers.runtime.json',teachers);write('queries.runtime.json',queries);write('proposed_plan.json',{'explicit_native_admission':False,'plan':plan});write('all600_cells.json',cells);write('groups.json',groups);write('teacher_index.json',teacher_index);write('query_index.json',query_index);write('scope_probes.json',probes);write('case_scope.json',case_scopes)
# Preserve complete existing phase interpretations as well as full raw row references.
(R/'all112_phases.json').write_bytes((BR/'all_phases.json').read_bytes())
sourcefiles=[BR/'bridge.py',BR/'MANIFEST_v3.json',BR/'all6_full_attribution_v2.json',BR/'all_phases.json',W/'goal6_full_witness_joins.json',B/'arc-native-teach-final-20261019/proposed_config.json',B/'arc-native-teach-final-20261019/run01/post_state.reserve']+list((BR/'origins').glob('*.py'))+list((B/'arc-native-query-20261019/frozen/HDS/学習系統/v0.4.2/hds学習系統').glob('*.py'))
write('source_pins.json',[pin(p) for p in sourcefiles]+rawpins)
summary={'native_calls_executed':0,'teachers':len(teachers),'queries_each_side':len(queries),'planned_calls':len(plan),'groups':len(groups),'all_cells':len(cells),'eligible_cells':sum(r['eligible'] for r in cells),'held_cells':sum(not r['eligible'] for r in cells),'historical_actions':6,'informative_actions':5,'recordings':2,'new_observations':0,'observed_source_values':{str(k):v for k,v in observed.items()},'contradictions':sum(o['contradicts_identity'] for g in groups for o in g['actual_outcomes']),'scope_probes':len(probes),'old_smoke_rows':19,'old_distinct_boundaries':len({x['input']['対象系境界'] for x in old}),'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
write('summary.json',summary);print(json.dumps(summary))
