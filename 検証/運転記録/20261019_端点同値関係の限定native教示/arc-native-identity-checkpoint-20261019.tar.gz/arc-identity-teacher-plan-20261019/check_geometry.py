"""Reuse existing perception prefix through canvas extraction; do not infer device roles."""
import pathlib,ast,json,resource,importlib.util
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
R=pathlib.Path(__file__).resolve().parent;B=R.parent;BR=B/'arc-goal6-action-bridge-20261019';W=B/'arc-teacher-contrasts-20261019'
spec=importlib.util.spec_from_file_location('geometry_bridge',BR/'bridge.py');br=importlib.util.module_from_spec(spec);spec.loader.exec_module(br)
tree=ast.parse((BR/'origins/知覚.py').read_text());fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='read')
cut=next(i for i,n in enumerate(fn.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='red' for t in n.targets));fn.body=fn.body[:cut]+ast.parse("return {'reference_rect':[rx,ry,rX,rY],'target_rect':[cx,cy,cX,cY],'reference':reference,'target':canvas,'size':size,'background':bg,'outer_reference_frame':frames[0]}").body
fn.name='geometry_only';module=ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[]));env=dict(br.P);exec(compile(module,'知覚.py::existing_prefix_geometry_only','exec'),env)
out=[]
for j in json.loads((W/'goal6_full_witness_joins.json').read_bytes()):
 before=json.loads((W/j['raw_before']).read_bytes())['data'];anchor=env['geometry_only'](before['frame'][-1]);rows=[]
 after=json.loads((W/j['raw_after']).read_bytes())['data']
 for i,f in enumerate(after['frame']):
  try:
   g=env['geometry_only'](f);rows.append({'phase':i,'status':'GEOMETRY_MEASURED','same_before_reference_rectangle':g['reference_rect']==anchor['reference_rect'],'same_before_target_rectangle':g['target_rect']==anchor['target_rect'],'same_before_reference_pixels':g['reference']==anchor['reference'],'size':g['size'],'outer_reference_frame':g['outer_reference_frame'],'instrument_role':'not evaluated; original unknowns preserved'})
  except Exception as e:rows.append({'phase':i,'status':'HOLD','error_type':type(e).__name__,'error':str(e)})
 out.append({'case':j['teacher_ordinal'],'before_anchor':anchor,'all_after_phases':rows})
(R/'geometry_results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps([{'case':x['case'],'holds':[p['phase'] for p in x['all_after_phases'] if p['status']=='HOLD'],'geometry_measured':sum(p['status']=='GEOMETRY_MEASURED' for p in x['all_after_phases'])} for x in out]))
