from pathlib import Path
r=Path(__file__).resolve().parent;s=(r/'prepare.py').read_text();s=s.replace('B=R.parent;BR=', 'B=R.parent.parent;BR=')
selector='''def endpoint_pair(before,after):
 # Entire packet reference-prefix boundary, independently of target prediction.
 initial=br.phase(before['frame'][-1],before['state'],before['available_actions'])
 if initial['scene'] is None:raise ValueError('before_binding_missing')
 sc=initial['scene'];rx,ry,rX,rY=sc['参照矩形'];tr=sc['対象矩形']
 same=[ [row[rx:rX] for row in frame[ry:rY]]==sc['参照'] for frame in after['frame'] ]
 if not same or not same[0]:raise ValueError('old_reference_prefix_missing')
 end=next((i for i,v in enumerate(same) if not v),len(same))-1
 if any(same[end+1:]):raise ValueError('reference_returns_after_transition')
 if end<1:raise ValueError('terminal_pair_missing')
 pair=(end-1,end);parsed=[]
 for i in pair:
  o=br.phase(after['frame'][i],after['state'],after['available_actions'])
  q=o['scene']
  if q is None or not o['exact_existing_device_template']:raise ValueError('terminal_binding_unverified')
  if q['参照矩形']!=sc['参照矩形'] or q['対象矩形']!=tr or q['参照']!=sc['参照'] or q['大きさ']!=sc['大きさ']:raise ValueError('terminal_binding_changed')
  parsed.append(q)
 if parsed[0]['対象']!=parsed[1]['対象']:raise ValueError('terminal_target_unstable_no_fallback')
 if not all(before.get(k)==after.get(k) for k in ('guid','game_id')) or before.get('full_reset') is not False or after.get('full_reset') is not False or after['state']!='NOT_FINISHED':raise ValueError('pair_scope_invalid')
 return pair
'''
s=s.replace('groups=[];cells=[];case_scopes=[];rawpins=[]',selector+'\ngroups=[];cells=[];case_scopes=[];rawpins=[]')
s=s.replace("action=aft['action_input']; scope=", "selected=endpoint_pair(bef,aft)\n action=aft['action_input']; scope=")
s=s.replace('for phase in (13,14):','for phase in selected:')
s=s.replace("'all_after_phase_count':len(aft['frame'])", "'selected_endpoint_pair':selected,'all_after_phase_count':len(aft['frame'])")
s=s.replace('# Protocol fixed before grouping/outcome reads: before terminal raw frame; after phase13 primary,\n# phase14 replicate; phase15 rebinding and all remaining phases retained. No best-fit search.', '# Protocol: before-reference prefix terminal two verified bindings/equal target crops;\n# no literal phase indices or earlier fallback. All unknowns/transition phases retained.')
(r/'revision02_target_endpoint/prepare.py').write_text(s)
