"""Pure retrospective TARGET-observation selector; device animation remains recorded, not called stable."""
import pathlib,json,hashlib,resource,importlib.util
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
R=pathlib.Path(__file__).resolve().parent;B=R.parent;W=B/'arc-teacher-contrasts-20261019';BR=B/'arc-goal6-action-bridge-20261019'
spec=importlib.util.spec_from_file_location('selector_pure_bridge',BR/'bridge.py');br=importlib.util.module_from_spec(spec);spec.loader.exec_module(br)
def bind(scene):
 return None if scene is None else {k:scene[k] for k in ('参照','対象矩形','大きさ')}
def select(before,after):
 provenance=all(before.get(k)==after.get(k) for k in ('guid','game_id')) and before.get('full_reset') is False and after.get('full_reset') is False and before['state']=='NOT_FINISHED' and after['state']=='NOT_FINISHED'
 initial=br.phase(before['frame'][-1],before['state'],before['available_actions']);binding=bind(initial['scene']);rows=[]
 for i,f in enumerate(after['frame']):
  obs=br.phase(f,after['state'],after['available_actions']);rows.append({'phase':i,'binding':bind(obs['scene']),'known':obs['scene'] is not None,'target_observation_hash':None if obs['scene'] is None else hashlib.sha256(json.dumps({'binding':bind(obs['scene']),'target':obs['scene']['対象']},ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'frame_hash':hashlib.sha256(json.dumps(f,separators=(',',':')).encode()).hexdigest(),'errors':obs['errors']})
 # Neighboring observed target projections equal; full-frame equality is NOT required; same public reference and target geometry as before.
 # No expected target/tool color or mask/prediction is evaluated.
 pairs=[(i-1,i) for i in range(1,len(rows)) if rows[i-1]['known'] and rows[i]['known'] and rows[i-1]['binding']==binding==rows[i]['binding'] and rows[i-1]['target_observation_hash']==rows[i]['target_observation_hash']]
 chosen=max(pairs) if pairs and provenance else None
 # Any later unknown or still-old changing packet prevents calling this last stable old-binding snapshot.
 suffix_ok=chosen is not None and all(x['known'] and x['binding']!=binding for x in rows[chosen[1]+1:])
 return {'pair_scope_verified':provenance,'before_binding':binding,'all_phases':rows,'candidate_pairs':pairs,'selected_pair':chosen if suffix_ok else None,'suffix_closed':suffix_ok,'scope':'retrospective stable target observation only; device animation and unknown phases preserved; no whole-environment stability, unique causality, or Action permission'}
results=[]
for j in json.loads((W/'goal6_full_witness_joins.json').read_bytes()):
 before=json.loads((W/j['raw_before']).read_bytes())['data'];after=json.loads((W/j['raw_after']).read_bytes())['data']
 results.append({'case':j['teacher_ordinal'],**select(before,after)})
(R/'target_selector_results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
print(json.dumps([{'case':x['case'],'pair_scope':x['pair_scope_verified'],'selected':x['selected_pair'],'suffix_closed':x['suffix_closed']} for x in results]))
