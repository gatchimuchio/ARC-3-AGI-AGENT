"""Creates a separately named target-observation diagnostic; retains strict predecessor."""
from pathlib import Path
r=Path(__file__).resolve().parent;s=(r/'retrospective_selector.py').read_text()
s=s.replace('Pure, prediction-independent retrospective snapshot selector on complete raw packets.','Pure retrospective TARGET-observation selector; device animation remains recorded, not called stable.')
s=s.replace("'frame_hash':hashlib.sha256", "'target_observation_hash':None if obs['scene'] is None else hashlib.sha256(json.dumps({'binding':bind(obs['scene']),'target':obs['scene']['対象']},ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'frame_hash':hashlib.sha256")
s=s.replace("rows[i-1]['frame_hash']==rows[i]['frame_hash']", "rows[i-1]['target_observation_hash']==rows[i]['target_observation_hash']")
s=s.replace('Exact neighboring public frames equal;', 'Neighboring observed target projections equal; full-frame equality is NOT required;')
s=s.replace("'retrospective complete-packet snapshot only; not proof of final Action effect or runtime action permission'", "'retrospective stable target observation only; device animation and unknown phases preserved; no whole-environment stability, unique causality, or Action permission'")
s=s.replace('retrospective_selector_results.json','target_selector_results.json')
(r/'target_selector.py').write_text(s)
