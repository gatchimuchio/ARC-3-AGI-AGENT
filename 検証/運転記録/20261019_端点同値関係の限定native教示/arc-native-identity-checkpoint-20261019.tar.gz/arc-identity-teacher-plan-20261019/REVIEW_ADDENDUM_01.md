# Additive review evidence, originals preserved

The stricter retrospective selector in retrospective_selector.py was tested without prediction or mask-fit matching. It compares BEFORE public reference/target geometry and seeks the last consecutive identical full public frame pair, with a closed later suffix. It selects no pair in all6 cases. Phases13/14 differ in device pixels and instrument rectangle. This negative result is retained; stability was not relaxed to force the known indices. The teachers therefore retain the explicit historical phase13/14 qualified-snapshot scope. No runtime-projectable endpoint or final Action-effect claim is admitted.

The same script independently verifies pair game_id/guid equality, full_reset=false and nonterminal public statuses for all6 pairs. These are corpus checks only; producer generic scope still is not an Action safety contract.

The previously pending reply proposal is now supplied in reply_bound.py/reply_proposal.json. Exact16 old active summaries plus4 new summary envelopes, singleton(boundary,result) groups and≤2 relevant principles give60,103B proposed output bound; all75 planned input widths checked. Reserve remains128KiB per reply. Evidence11,434,912B <12MiB. Both reply and growth proposals require independent review; this addendum does not admit execution.

Original MANIFEST.json remains the earlier freeze. MANIFEST_v2.json adds these files and points to its unchanged hash. Source15teacher/30query/75call payload bytes remain unchanged. No reservation or native call occurred.
