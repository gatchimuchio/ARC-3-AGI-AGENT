# Revision02: paired public target observation contract

OFFLINE PROPOSAL, independently review before native admission. This supersedes only the prior literal-index measurement proposal, preserving every previous source/result/manifest. It does not amend native state or HDS.

## Observable selection rule

1. Parse the BEFORE terminal public frame using the existing v3 unique-role guards and before template scope. Bind its unique reference rectangle, reference pixels, target rectangle and size. Verify source packet pair guid/game equality, neither reset, both nonterminal, and Action5 echo/availability/arguments. These are explicit historical pair checks, not generic Action safety proof.
2. At the fixed BEFORE reference rectangle, inspect the reference crop in EVERY after frame. Require a nonempty contiguous initial prefix equal to BEFORE reference. If it changes and later returns, HOLD rather than infer a continuous problem identity.
3. Select ONLY the final two frames of that initial prefix. Both must pass existing full scene/unique-role parsing and have the exact BEFORE reference rectangle, target rectangle, reference pixels and size. Require their observed target crops to equal each other. If either is unknown or unstable, HOLD; never search earlier for a convenient pair.
4. No mask, tool color, expected-copy label, reward/progress, or literal phase index enters selection. On these6 complete packets the selected pair happens to be13/14. Positive cases have reference rebinding at15, which is retained as a new-problem transition; any future current-goal context must reset there.
5. Intermediate pixel crops are measured across all phases, but existing target-object segmentation HOLDs phases2–12. Do not infer continuous semantic identity or preservation through them. Endpoints have verified observable role signatures; no claim of whole-environment stability, persistence after the packet, unique mechanism, or Action permission follows.

The initial revision02 run additionally required the terminal device pixels to match a static device template. That failed and is preserved in pre_fix01/prepare.py and run01.log. This additional requirement was not part of the requested target-observation protocol and incorrectly treated dynamic device rendering as required target stability. The corrected version keeps the BEFORE template gate and full endpoint scene/unique-role parse, but does not claim the animated endpoint device itself is a static template. No native or Action gate was weakened; this is a new offline measurement definition, still subject to review.

## Before-defined partition and actual labels

All600 cells retain membership in their original Action. Before-only eligibility: verified before scope, prior target color≠before tool color, and declared existing fixed half-plane membership. Inside source is before tool color; outside source is before target color. Group by original Action + that source value + inside/outside before examining outcomes. For each group retain all cells/counts and every distinct actual target color from the selected pair. No majority/drop. Expected identity is not used to manufacture labels.

Exact native-shaped proposal fields and boundary names remain as in the original measurement contract: 公開塗布端点:作用前識別可能・固定幾何内/外, input 作用前器具色 or 作用前対象色, measured output 同一問題端点対象色. The names refer only to this explicit observable contract. There are15 group rows,5 informative interventions from2 recordings,0 new observations. All6 Actions,150 ambiguous cells including all of case3, all112 phases,77 unknown interpretations and transitions remain evidence. A native support count is not an independent intervention count.

## Provenance separation

- Target-prefix/final-pair selection: NEW FIXED OBSERVATION PROTOCOL, not HDS learned and not recovered historical grammar.
- Structural parser, unique-role guard, static before device template, Action5 role hypothesis, half-plane membership and grouping conventions: fixed prior/measurement choices. The role hypothesis is not an independently learned causal mapping.
- Pixel labels: measured public frames, cross-checked raw pixels through before target coordinates; never hypothetical overwrite values.
- Forward/reverse value identities: only PROSPECTIVE HDS-learned relationships. No native execution yet. They would be scoped value-copy relations, not learned mask, turn/rotation, conditional composition, causal necessity, or universal operation.

No causal rivals are eliminated merely because the selected endpoint values agree. New independent observations are needed for fresh role/geometry/action transfer. Reusing unseen numeric colors in a native Query would be algebraic transfer within this contract only.

## Payload and budget continuity

All15 teacher bytes,30 query bytes and75-call plan bytes are identical to the previous reviewed-data proposal. Caller-side17 scope rejection probes pass. Old19 smoke rows cover10 boundaries; no exhaustive prior-success regression is implied. Proposed future native plan30Query/15Teach/30Query remains unadmitted. Independent static bounds7,221,324B state,60,103B reply and11,434,912B evidence apply to the unchanged exact payloads, subject to final caller/pin review.176MiB proposed unit is not allocated or authorized. AS512MiB prep, no native/SDK/Action/Git.

## Revision03 validation tightening

Revision02 remains unchanged. Before interpreting reference-prefix changes, both complete packet frame lists now pass the existing raw integer-pixel contract and exact64×64 shape for EVERY frame. Malformed trailing frames cannot masquerade as goal transitions. Both game_id and guid must be nonempty strings before equality can establish a pair; jointly missing values cannot pass. Current dataset is unchanged. run01/source.py and run.sh were stored before execution; stdout/stderr and exit_status.txt are retained separately. No native calls occurred.
