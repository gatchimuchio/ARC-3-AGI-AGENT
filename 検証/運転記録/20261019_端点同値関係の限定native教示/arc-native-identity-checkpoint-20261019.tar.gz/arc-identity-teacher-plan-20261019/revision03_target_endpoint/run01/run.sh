#!/bin/bash
cd /workspace/scratch/a94ff513b3af
python arc-identity-teacher-plan-20261019/revision03_target_endpoint/prepare.py > arc-identity-teacher-plan-20261019/revision03_target_endpoint/run01/stdout.log 2> arc-identity-teacher-plan-20261019/revision03_target_endpoint/run01/stderr.log
status=$?
printf '%s\n' "$status" > arc-identity-teacher-plan-20261019/revision03_target_endpoint/run01/exit_status.txt
exit "$status"
