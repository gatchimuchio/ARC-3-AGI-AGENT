from pathlib import Path
import json,hashlib
r=Path(__file__).resolve().parent.parent;checks=[]
for n in ('teachers.runtime.json','queries.runtime.json','proposed_plan.json'):
 a=(r/n).read_bytes();b=(r.parent/n).read_bytes();assert a==b;checks.append({'path':n,'bytes':len(a),'sha256':hashlib.sha256(a).hexdigest(),'equal_original':True})
(r/'payload_equality.json').write_text(json.dumps(checks,indent=2)+'\n')
fs=[{'path':str(p.relative_to(r)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(r.rglob('*')) if p.is_file() and 'freeze01' not in p.parts]
(r/'MANIFEST.json').write_text(json.dumps({'status':'NARROW_TARGET_OBSERVATION_MEASUREMENT_REVIEW_PENDING','native_admission':False,'files':fs,'total_bytes_excluding_manifest':sum(x['bytes'] for x in fs),'excluded_live_execution_leaf':'freeze01; its closed receipt is external'},ensure_ascii=False,indent=2)+'\n')
print(hashlib.sha256((r/'prepare.py').read_bytes()).hexdigest())
