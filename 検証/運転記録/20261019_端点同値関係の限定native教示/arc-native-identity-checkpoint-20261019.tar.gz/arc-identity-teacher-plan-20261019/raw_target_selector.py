"""All-phase BEFORE-anchored public crop diagnostic; no inferred object identity in unknown phases."""
import json,pathlib,hashlib,resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
R=pathlib.Path(__file__).resolve().parent;W=R.parent/'arc-teacher-contrasts-20261019'
def crop(f,rect):
 x,y,X,Y=rect;return [r[x:X] for r in f[y:Y]]
def sha(x):return hashlib.sha256(json.dumps(x,separators=(',',':')).encode()).hexdigest()
out=[]
for j,sc in zip(json.loads((W/'goal6_full_witness_joins.json').read_bytes()),json.loads((R/'case_scope.json').read_bytes())):
 b=json.loads((W/j['raw_before']).read_bytes())['data'];a=json.loads((W/j['raw_after']).read_bytes())['data'];scene=sc['before_scene'];rr=scene['参照矩形'];tr=scene['対象矩形'];ref=crop(b['frame'][-1],rr)
 phases=[]
 for i,f in enumerate(a['frame']):
  rc=crop(f,rr);tc=crop(f,tr);phases.append({'phase':i,'reference_crop':rc,'target_crop':tc,'same_before_reference_crop':rc==ref,'target_hash':sha(tc),'full_frame_hash':sha(f),'semantic_object_binding':'not inferred from crop equality; unknown parser phases remain unknown'})
 runs=[];start=None
 for i,p in enumerate(phases):
  if not p['same_before_reference_crop']:
   if start is not None:runs.append([start,i-1]);start=None
  elif start is None:start=i
  elif phases[i-1]['target_hash']!=p['target_hash']:runs.append([start,i-1]);start=i
 if start is not None:runs.append([start,len(phases)-1])
 candidates=[r for r in runs if r[1]>r[0] and all(not p['same_before_reference_crop'] for p in phases[r[1]+1:])]
 chosen=max(candidates,key=lambda r:r[1]) if candidates else None
 out.append({'case':j['teacher_ordinal'],'before_reference_rect':rr,'before_target_rect':tr,'all_after_phases':phases,'all_stable_old_reference_target_runs':runs,'selected_last_stable_run':chosen,'last_repeated_pair':None if chosen is None else [chosen[1]-1,chosen[1]],'scope':'observed pixel crop at BEFORE fixed coordinates, not proved same semantic object during all phases; no final-environment-effect or causal uniqueness'})
(R/'raw_target_selector_results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps([{'case':x['case'],'run':x['selected_last_stable_run'],'last_pair':x['last_repeated_pair']} for x in out]))
