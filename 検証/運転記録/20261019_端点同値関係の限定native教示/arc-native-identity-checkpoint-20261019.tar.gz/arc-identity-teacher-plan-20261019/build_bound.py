"""Generate a new static envelope script, retaining the original proof source by hash."""
from pathlib import Path
r=Path(__file__).resolve().parent;b=r.parent
s=(b/'arc-native-teach-20261019/preflight_bound.py').read_text()
head=s[:s.index('s=dec(json.loads(STATE.read_bytes()))')]
head=head.replace("STATE=BASE/'arc-native-query-20261019/query_retry02/poststate.json'","STATE=BASE/'arc-native-teach-final-20261019/run01/post_state.reserve'").replace("TEACH=BASE/'arc-teacher-contrasts-20261019/goal6_teachers.runtime.json'","TEACH=ROOT/'teachers.runtime.json'")
body=s[s.index("R='R'*32;"):s.index('# 54 base ledger records')]
body=body.replace("REFS=(R,)*6","REFS=(R,)*15").replace("snapshot['L'*1024]=R","snapshot.update({str(i)+'L'*1023:R for i in range(4)})").replace('len(snapshot)==16','len(snapshot)==20').replace('range(6)','range(15)').replace('"條件種類数":6','"條件種類数":15').replace("'条件種類数':6","'条件種類数':15").replace('推論候補参照群=(R,),採用原理参照群=(R,)','推論候補参照群=(R,R),採用原理参照群=(R,R)').replace('更新記録参照群=(R,)','更新記録参照群=(R,R)')
facts='''s=dec(json.loads(STATE.read_bytes()));ts=json.loads(TEACH.read_bytes());b=ts[0]['対象系境界']
assert len(ts)==15 and len(s['台帳']['観測台帳'])==189 and len(s['台帳']['原理台帳'])==19
assert s['識別子状態']['照会']==s['識別子状態']['学習判定']==6698
boundaries={t['対象系境界'] for t in ts};assert len(boundaries)==2
assert all(x['値']['対象系境界'] not in boundaries for x in s['台帳']['観測台帳'])
assert all(len(t['内容'])==2 and len(set(t['内容'].values()))==1 for t in ts)
seen={};tables={};candidate_events=0;adoptions=0;changed_calls=0;prefix=[]
for t in ts:
 boundary=t['対象系境界'];rows=seen.setdefault(boundary,[]);rows.append(next(iter(t['内容'].values())))
 candidate=len(rows)>=3 and len(set(rows))>=2;changed=candidate and tables.get(boundary)!=set(rows)
 candidate_events+=2*int(candidate);adoptions+=2*int(changed);changed_calls+=int(changed)
 if changed:tables[boundary]=set(rows)
 prefix.append({'boundary':boundary,'rows':len(rows),'distinct_values':len(set(rows)),'candidate_count':2*int(candidate),'adoption_upper':2*int(changed)})
literalmax=max(len(n.value.encode()) for p in CORE.glob('*.py') for n in ast.walk(ast.parse(p.read_text())) if isinstance(n,ast.Constant) and isinstance(n.value,str))
escaped_literalmax=max(len(json.dumps(n.value,ensure_ascii=False).encode())-2 for p in CORE.glob('*.py') for n in ast.walk(ast.parse(p.read_text())) if isinstance(n,ast.Constant) and isinstance(n.value,str))
assert escaped_literalmax<=512
'''
end='''# No conflicting old boundary, all new pairs equal; 2 directed candidates per eligible prefix.
# Each candidate has inference/evidence/judgment; redundancy branch cannot compare different result paths.
# Each adoption 3 ledger records + duplicate history; each changed call one state snapshot.
units=15*9+candidate_events*3+adoptions*4+changed_calls+1
bound=STATE.stat().st_size+units*32768
assert bound<16*1024**2
result={'status':'STATIC_PROPOSED_REQUIRES_INDEPENDENT_REVIEW','baseline_bytes':STATE.stat().st_size,'base_sha256':hashlib.sha256(STATE.read_bytes()).hexdigest(),'prefix':prefix,'candidate_events_upper':candidate_events,'adoptions_upper':adoptions,'changed_calls_upper':changed_calls,'state_units':units,'envelopes':envelopes,'state_upper_bound_bytes':bound,'state_slot_bytes':16*1024**2,'native_calls':0}
(ROOT/'growth_proposal.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\\n');print(json.dumps(result))
'''
(r/'static_bound.py').write_text(head+facts+body+end)
