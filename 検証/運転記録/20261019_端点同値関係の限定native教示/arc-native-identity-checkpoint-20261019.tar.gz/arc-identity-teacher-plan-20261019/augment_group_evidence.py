"""Separate additive all-phase outcome accounting; does not revise teacher labels."""
import json,pathlib,collections
r=pathlib.Path(__file__).resolve().parent;groups=json.loads((r/'groups.json').read_bytes());cells=json.loads((r/'all600_cells.json').read_bytes());out=[]
for g in groups:
 rows=[c for c in cells if c['group_key']==g['key']];by={}
 for c in rows:
  for p in c['all_after_phases']:
   k=(p['phase'],p['same_problem_binding'],p['after_color'],p['identification']);by.setdefault(k,[]).append(c['target'])
 out.append({'group_key':g['key'],'all_actual_phase_outcomes':[{'phase':k[0],'same_problem_binding':k[1],'after_color':k[2],'classification':k[3],'targets':v,'disagrees_with_copy_value':None if k[2] is None else k[2]!=g['before_source_value'],'teacher_protocol_member':k[0] in (13,14)} for k,v in by.items()]})
(r/'all_group_phase_outcomes.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print('Preserved all phase outcomes, including early mismatches, unknowns, and rebinding.')
