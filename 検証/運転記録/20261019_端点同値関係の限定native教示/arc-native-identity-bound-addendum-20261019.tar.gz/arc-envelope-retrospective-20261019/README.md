# Retrospective observation-envelope impact addendum

## Closed finding

The2-observation defect was introduced specifically in COPY6 preparation. It is NOT present in the frozen goal6 or15-teacher identity proofs. No historical proof/archive/main file was modified, and no native operation was rerun. This is a connection-layer resource-analysis generator failure, not an HDS change or observed ability failure.

Fresh private run01 retains audit.py, stdout.txt, stderr.txt, exit_status.txt and impact.json. Pure AST/JSON/envelope analysis ran under512MiB AS and exited0; output is below96MiB. It checked exact executed-configuration source hashes, independently retained reviewer copies, actual persisted new experience shapes, and the COPY generator. It executed no native imports/restoration/persistence/Query/Teach/SDK/Action/Git operations.

## Exact prior-plan impact

Goal6 (six teachers):
- Executed-admission pinned preflight_bound.py SHA256b6179da339ad870372181a0a3e8175bd3f03a6083b9c67d1325cf9fdbb4af436 matches the independent review copy.
- It explicitly contains4 observation entries. Every one of the6 actual saved new experience records also contains4.
- Four-observation padded experience upper5,270bytes is below its32,768-byte unit.
- Original fixed82-unit full-state bound8,042,933bytes remains verified and below8,388,608bytes. Even a hypothetical2-entry display envelope would not change this unit accounting, because the independently computed actual4-entry envelope fits the same32KiB unit. The actual pinned proof already uses4, so this hypothetical is not an old defect claim.

Identity (fifteen teachers):
- Executed-admission pinned static_bound.py SHA256cb6e7261c36fe89f7974487060ce42353d95ae7ddf80d5087096fff65b53471c matches the independent review copy.
- It explicitly contains4 observation entries. All15 actual saved new experience records contain4.
- Four-observation padded experience upper5,270bytes was already included in the published-to-review refined arithmetic.
- Full-state upper7,221,324bytes remains independently reproduced, below8,388,608bytes. No replacement upper bound is needed.
- Counterfactual2-entry identity arithmetic would be7,195,824bytes,25,500bytes LOWER than the actual preserved7,221,324 proposal. This sensitivity calculation confirms that the preserved refined proposal already includes all4 observations.

COPY6 (six teachers):
- Retained pre_fix01/static_bound.py contains2 observation entries, incorrectly omitting the2 metadata observations.
- The COPY generator build_bound01/source.py applies global string substitution ('range(4)','range(2)'). This correctly changed the intended4→2 new-lineage count but also unintentionally changed the unrelated4-observation experience envelope.
- Per-experience correction is5,270−3,570=1,700bytes;6 teachers add10,200bytes.
- Faulty6,628,545-byte proposal is superseded by verified6,638,745bytes, still below8MiB. Corrected source SHA256f25c630e501f064654a9905cf6a4291d4b3f64b57f2ad53d0afe9fc0cd96333a. Its broader independent review is arc-copy-bound-review-20261019.

## Interpretation and preservation

Native intake of these exact two-leaf dictionaries produces2 metadata observations (structure and element count) plus2 inferred leaves. Both prior proofs included all4; COPY's global text rewrite was the source of the regression. This conclusion is limited to the pinned closed plans reviewed here; it does not certify arbitrary future generated proofs.

Earlier successful native runs remain measured observations. This addendum does not replace their full state/trace audits or turn a static proof correction into a runtime failure. The old archives and proof versions remain unchanged. COPY's failed proof and corrected proof are both retained. No public write is authorized or performed while the publication/privacy question remains open. This addendum may accompany the historical archive only after separate publication authorization.
