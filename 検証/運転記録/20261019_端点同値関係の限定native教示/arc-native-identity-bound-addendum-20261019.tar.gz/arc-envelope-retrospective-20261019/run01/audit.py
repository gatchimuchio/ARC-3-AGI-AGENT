import ast,hashlib,json,pathlib,resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
R=pathlib.Path(__file__).resolve().parent;B=R.parent.parent
specs=[('goal6','arc-native-teach-final-20261019/preflight_bound.py','arc-native-teach-final-20261019/proposed_config.json','arc-native-teach-final-20261019/run01/post_state.reserve',6),('identity','arc-identity-teacher-plan-20261019/static_bound.py','arc-native-identity-20261019/proposed_config.json','arc-native-identity-20261019/run01/post_state.reserve',15),('copy6_fixed','arc-copy-pilot-plan-20261019/static_bound.py',None,None,6)]
results=[]
for name,source,config,after,n in specs:
 p=B/source;src=p.read_text();pin=hashlib.sha256(p.read_bytes()).hexdigest()
 if config:
  cfg=json.loads((B/config).read_bytes());assert cfg['pins'][str(p)]==pin
 cutoff=src.index('result=');pure=src[:cutoff]
 # Read/AST/envelope code only. Truncate all result-file writes; never load HDS.
 g={'__file__':str(p)};exec(compile(pure,str(p)+'::pure_envelope','exec'),g)
 assert len(g['ex']['値']['観測群']['__組__'])==4
 assert all(len(t['内容'])==2 and all(type(v) in (bool,int,str) for v in t['内容'].values()) for t in g['ts'])
 e=g['envelopes'];base=e['experience']+e['cognitive']+5*e['doubt']+e['learning']+e['feedback'];candidate=e['inference']+e['evidence']+e['judgement'];adoption=2*e['principle']+e['provisional']+e['update']
 if name=='goal6':full=g['state_bound'];assert full==8042933;kind='82 fixed32KiB units';expected_count=189
 else:
  full=g['STATE'].stat().st_size+n*base+g['candidate_events']*candidate+g['adoptions']*adoption+g['changed_calls']*e['state_history_snapshot']+32768
  assert full==({'identity':7221324,'copy6_fixed':6638745}[name]);kind='shape-specific padded sum';expected_count=204
 observations=None
 if after:
  actual=g['dec'](json.loads((B/after).read_bytes()));new=actual['台帳']['観測台帳'][-n:]
  assert len(actual['台帳']['観測台帳'])==expected_count
  observations=[len(x['値']['観測群']) for x in new];assert observations==[4]*n
 # Explicit counterfactual sensitivity, not assertion that old proof used2.
 two=dict(g['ex']);two['値']=dict(two['値']);two['値']['観測群']={'__組__':g['ex']['値']['観測群']['__組__'][:2]}
 two_bytes=g['size_at_depth'](two);four_bytes=e['experience'];delta=four_bytes-two_bytes
 assert delta==1700 and four_bytes<32768
 results.append({'name':name,'source':source,'source_sha256':pin,'matches_executed_config_pin':bool(config),'teacher_count':n,'envelope_observation_count':4,'actual_saved_new_observation_counts':observations,'two_observation_counterfactual_bytes':two_bytes,'four_observation_envelope_bytes':four_bytes,'difference_per_experience':delta,'bound_method':kind,'verified_full_state_upper_bytes':full,'slot_bytes':8388608,'counterfactual_two_observation_full_bound':full if name=='goal6' else full-n*delta,'goal6_fixed_unit_contains_actual_four':four_bytes<32768,'native_calls':0})
old=B/'arc-copy-pilot-plan-20261019/pre_fix01/static_bound.py'
assert old.exists();src=old.read_text();line=next(l for l in src.splitlines() if l.startswith("ex['値']['観測群']="));assert 'range(2)' in line
builder=B/'arc-copy-pilot-plan-20261019/build_bound01/source.py';text=builder.read_text();assert "('range(4)','range(2)')" in text
original_identity=B/'arc-identity-bound-review-20261019/static_bound.py';assert hashlib.sha256(original_identity.read_bytes()).hexdigest()==results[1]['source_sha256']
original_goal=B/'arc-teach-bound-review-20261019/reviewed_preflight_bound.py';assert hashlib.sha256(original_goal.read_bytes()).hexdigest()==results[0]['source_sha256']
out={'classification':'COPY6 connection-layer resource-analysis generation defect; not HDS change or observed ability failure','prior_goal6_identity_defect_found':False,'scope':'Only exact frozen closed plans and source pins reviewed; no blanket future-proof claim','results':results,'cause':{'generator':str(builder.relative_to(B)),'sha256':hashlib.sha256(builder.read_bytes()).hexdigest(),'exact_global_substitution':"('range(4)','range(2)')",'effect':'Intended4→2 new-lineage slots also reduced unrelated experience observation entries4→2','retained_bad_copy_source':str(old.relative_to(B)),'retained_bad_copy_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'bad_copy_bound':6628545,'corrected_copy_bound':6638745},'all_original_artifacts_unchanged':True,'native_calls':0,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(R/'impact.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out,ensure_ascii=False,indent=2))
