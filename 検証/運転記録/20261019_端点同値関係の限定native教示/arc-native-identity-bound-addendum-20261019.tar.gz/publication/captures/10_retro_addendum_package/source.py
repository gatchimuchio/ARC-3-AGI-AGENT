from pathlib import Path
import json,hashlib,tarfile,gzip,resource,re
resource.setrlimit(resource.RLIMIT_AS,(268435456,268435456))
B=Path("/workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019/publication_native_identity");W=B.parent.parent;A=W/'arc-envelope-retrospective-20261019'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(A/'MANIFEST.json')=='c0b8251f0cbe5efd9bf37dbb3344f6c10a0e6644332ee267e097b6758e96d365'
manifest=json.loads((A/'MANIFEST.json').read_text());files=[]
for n,f in manifest['files'].items():
 p=A/n;assert not p.is_symlink() and p.stat().st_size==f['bytes'] and sha(p)==f['sha256'];files.append(p)
files.append(A/'MANIFEST.json')
assert set(files)==set(p for p in A.rglob('*') if p.is_file())
impact=json.loads((A/'run01/impact.json').read_text())
assert impact['prior_goal6_identity_defect_found'] is False
row=next(x for x in impact['results'] if x['name']=='identity')
assert row['verified_full_state_upper_bytes']==7221324 and row['envelope_observation_count']==4
assert sha(W/row['source'])==row['source_sha256']=='cb6e7261c36fe89f7974487060ce42353d95ae7ddf80d5087096fff65b53471c'
assert row['actual_saved_new_observation_counts']==[4]*15
assert sha(W/'arc-identity-bound-review-20261019/static_bound.py')==row['source_sha256']
for p in files:
 b=p.read_bytes();b.decode()
 assert not re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY|gh[pousr]_[A-Za-z0-9]{20,}|AKIA[A-Z0-9]{16}',b)
ad={'schema':'arc3-identity-retrospective-addendum-admission-v1','status':'PASS_LOCAL_ONLY','original_files':len(files),'original_bytes':sum(p.stat().st_size for p in files),'inspection':'All seven UTF-8 bodies reviewed; own resource-proof analysis and exact content hashes only; no HDS original manuscript body, credentials, SDK/game implementation or raw SDK diagnostics. Source inspected without execution.','identity_impact':'No defect found in exact executed identity proof; four observations already modeled and original bound7221324 bytes remains reproduced. COPY-only later global substitution introduced its two-observation defect.','original_payload_archive_unchanged_sha256':'8b96379c20da06524ecb822cc561ccdd462729200b4942b3abb227365fb64ac6','Git_writes':0,'publication_gate':'Private pending historical HDS document scope resolution; this additive explanation does not rewrite original historical artifacts.'}
(B/'retrospective_admission.json').write_text(json.dumps(ad,ensure_ascii=False,indent=2)+'\n')
entries={str(p.relative_to(W)):p for p in files}
for p in sorted((B/'captures/09_retro_impact_review').iterdir()):entries['publication/'+str(p.relative_to(B))]=p
for n in ['retrospective_admission.json','captures/10_retro_addendum_package/source.py']:entries['publication/'+n]=B/n
index={'schema':'arc3-identity-retrospective-archive-v1','files':[[n,p.stat().st_size,sha(p)] for n,p in sorted(entries.items())],'self_exclusion':'This manifest excludes itself; verification records its hash.'}
ip=B/'retrospective_archive_manifest.json';ip.write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n');entries['publication/'+ip.name]=ip
out=B/'arc-native-identity-bound-addendum-20261019.tar.gz';assert not out.exists()
expected={n:(p.stat().st_size,sha(p)) for n,p in entries.items()}
with out.open('xb') as raw:
 with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0,compresslevel=9) as gz:
  with tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT) as tf:
   for n,p in sorted(entries.items()):
    i=tarfile.TarInfo(n);i.size=p.stat().st_size;i.mode=0o644
    with p.open('rb') as f:tf.addfile(i,f)
seen={}
with gzip.open(out,'rb') as gz:
 with tarfile.open(fileobj=gz,mode='r|') as tf:
  for m in tf:
   assert m.isfile() and m.name not in seen
   b=tf.extractfile(m).read();seen[m.name]=(len(b),hashlib.sha256(b).hexdigest())
 while gz.read(1048576):pass
assert expected==seen
v={'status':'PASS','archive':str(out),'bytes':out.stat().st_size,'sha256':sha(out),'members':len(seen),'all_members_exact':True,'gzip_crc_eof_checked':True,'original_manifest_sha256':sha(A/'MANIFEST.json'),'no_original_archive_rewrite':True,'publication':'PAUSED'}
(B/'retrospective_archive_verification.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
plan=json.loads((B/'proposed_plan.json').read_text());plan['schema']='arc3-native-identity-proposed-evidence-plan-v2';plan['adds']='Closed retrospective explanation: identity proof remains valid; COPY-only later defect is separate.'
for p in [out,B/'retrospective_admission.json',B/'retrospective_archive_verification.json']:
 b=p.read_bytes();plan['files'].append({'source':str(p),'path':'検証/運転記録/20261019_端点同値関係の限定native教示/'+p.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob_sha1':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
plan['total_bytes']=sum(f['bytes'] for f in plan['files'])
(B/'proposed_plan_v2.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n')
assert sum(p.stat().st_size for p in B.iterdir() if p.name.endswith('.tar.gz'))<=4194304
assert sum(p.stat().st_size for p in B.rglob('*') if p.is_file() and not p.name.endswith('.tar.gz'))<=1048576
print(json.dumps(v,ensure_ascii=False));print('proposed_files',len(plan['files']),'total_bytes',plan['total_bytes'])
