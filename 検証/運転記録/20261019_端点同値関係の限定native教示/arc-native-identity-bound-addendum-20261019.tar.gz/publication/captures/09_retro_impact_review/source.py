from pathlib import Path
import hashlib,json
B=Path("/workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019/publication_native_identity")
A=B.parent.parent/'arc-envelope-retrospective-20261019'
for p in sorted(A.rglob('*')):
 if p.is_file():
  assert not p.is_symlink()
  b=p.read_bytes();print('\nFILE',str(p.relative_to(A)),len(b),hashlib.sha256(b).hexdigest())
  assert len(b)<100000
  print(b.decode())
