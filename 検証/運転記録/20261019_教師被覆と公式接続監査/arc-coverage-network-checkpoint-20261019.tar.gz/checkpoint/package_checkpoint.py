import pathlib,json,hashlib,gzip,tarfile,io,resource
resource.setrlimit(resource.RLIMIT_AS,(256*1024**2,256*1024**2))
R=pathlib.Path('/workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019/publication_coverage_network')
def digest(f):
 h=hashlib.sha256();n=0
 while b:=f.read(65536):h.update(b);n+=len(b)
 return {'bytes':n,'sha256':h.hexdigest()}
def identity(p):
 with p.open('rb') as f:return digest(f)
m=json.loads((R/'payload_manifest.json').read_text());a=json.loads((R/'payload_admission.json').read_text());im=json.loads((R/'inspection_manifest.json').read_text())
assert a['hds_original_document_classification']['canonical_original_specification_or_design_bodies_found']==0
assert a['manifest']['file_count']==65 and a['manifest']['raw_bytes']==6468027
assert identity(R/'payload_admission.json')['sha256']=='49986a3d48e0514994050610e23c7ec9a2424f7e72197f08ecc60b5dd03c0b2a'
paths=[(pathlib.Path(x['source']),x['archive_path'],x) for x in m['files']]
for x in im['files']:
 p=R/x['path']; paths.append((p,'checkpoint/'+x['path'],x))
 if 'lossless_original_bytes' in x:
  with gzip.open(p,'rb') as f:assert digest(f)=={'bytes':x['lossless_original_bytes'],'sha256':x['lossless_original_sha256']}
for name in ['README.md','payload_manifest.json','inspection_manifest.json','resource_ledger.json']:
 p=R/name;paths.append((p,'checkpoint/'+name,identity(p)))
p=pathlib.Path(__file__); paths.append((p,'checkpoint/package_checkpoint.py',identity(p)))
assert len({x[1] for x in paths})==len(paths)
records=[]
for p,name,x in paths:
 assert p.is_file() and not p.is_symlink()
 assert not name.startswith('/') and '..' not in pathlib.PurePosixPath(name).parts
 assert identity(p)=={k:x[k] for k in ['bytes','sha256']},name
 records.append({'path':name,'bytes':x['bytes'],'sha256':x['sha256']})
manifest=json.dumps({'schema':'arc3-coverage-network-checkpoint-archive-manifest-v1','files':records,'self_excluded':True,'runtime_adopted':False,'native_execution_by_packager':False},ensure_ascii=False,indent=2).encode()+b'\n'
class CappedWriter:
 def __init__(self,f):self.f=f;self.n=0
 def write(self,b):
  if self.n+len(b)>8388608:raise RuntimeError('approved 8MiB archive cap exceeded')
  n=self.f.write(b);self.n+=n;return n
 def flush(self):self.f.flush()
out=R/'arc-coverage-network-checkpoint-20261019.tar.gz';assert not out.exists()
with out.open('xb') as raw,gzip.GzipFile(fileobj=CappedWriter(raw),mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT) as tar:
 for p,name,x in paths:
  ti=tarfile.TarInfo(name);ti.size=x['bytes'];ti.mode=0o644
  with p.open('rb') as f:tar.addfile(ti,f)
 ti=tarfile.TarInfo('MANIFEST.json');ti.size=len(manifest);ti.mode=0o644;tar.addfile(ti,io.BytesIO(manifest))
allrecords=records+[{'path':'MANIFEST.json','bytes':len(manifest),'sha256':hashlib.sha256(manifest).hexdigest()}]
with tarfile.open(out,'r|gz') as tar:
 for x,ti in zip(allrecords,tar,strict=True):
  assert ti.isfile() and ti.name==x['path'] and ti.size==x['bytes'];assert digest(tar.extractfile(ti))=={k:x[k] for k in ['bytes','sha256']}
with gzip.open(out,'rb') as f:
 while f.read(65536):pass
ident=identity(out);git=hashlib.sha1(f'blob {ident["bytes"]}\0'.encode())
with out.open('rb') as f:
 while b:=f.read(65536):git.update(b)
v={'schema':'arc3-coverage-network-archive-verification-v1','archive':{'name':out.name,**ident,'git_blob':git.hexdigest()},'members':len(allrecords),'files':allrecords,'complete_member_readback':True,'gzip_crc_eof_validated':True,'all_65_frozen_payload_pins_unchanged':True,'all_17_inspection_leaves_preserved':True,'inspection_success_log_decompression_verified':True,'native_operations':0}
with (R/'archive_verification.json').open('x') as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({k:x for k,x in v.items() if k!='files'}))
