from pathlib import Path
import json,hashlib,gzip,sys
leaf=Path(__file__).resolve().parent;root=leaf.parent.parent;cap=root/'inspection_captures';report=root/'payload_admission.json'
assert hashlib.sha256(report.read_bytes()).hexdigest()=='49986a3d48e0514994050610e23c7ec9a2424f7e72197f08ecc60b5dd03c0b2a'
print('Frozen report and exact capture manifest: payload_admission.json and inspection_manifest.json. This successful finalizer emits nothing after the seal; its actual process status is persisted by the enclosing shell.',flush=True)
sys.stderr.flush();(leaf/'exit_status.txt').write_text('0\n')
entries=[]
for p in [report]+sorted(p for p in cap.rglob('*') if p.is_file()):
 b=p.read_bytes();e={'path':str(p.relative_to(root)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
 if p.suffix=='.gz':
  d=gzip.decompress(b);e.update({'lossless_original_bytes':len(d),'lossless_original_sha256':hashlib.sha256(d).hexdigest()})
 entries.append(e)
base=sum(e['bytes'] for e in entries);m={'schema':'arc3-independent-inspection-freeze-v1','self_excluded':True,'files':entries,'allocation_excluding_manifest':base,'allocation_including_manifest':0,'allocation_limit_bytes':204800,'scope':'Final admission report plus all 17 finalized validator leaves. Failed leaves and exact sources retained. Successful output compactions preserve original bytes losslessly. No external publication authorized.'}
for i in range(4):
 b=(json.dumps(m,ensure_ascii=False,indent=2)+'\n').encode();m['allocation_including_manifest']=base+len(b)
b=(json.dumps(m,ensure_ascii=False,indent=2)+'\n').encode();assert base+len(b)==m['allocation_including_manifest'] and base+len(b)<=204800,(base,len(b))
with (root/'inspection_manifest.json').open('xb') as f:f.write(b)
