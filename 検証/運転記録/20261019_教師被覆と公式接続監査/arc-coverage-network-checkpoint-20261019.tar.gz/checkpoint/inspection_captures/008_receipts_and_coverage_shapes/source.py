from pathlib import Path,PurePosixPath
import json,hashlib,re,tarfile,ast,collections,urllib.parse
w=Path('/workspace/scratch/a94ff513b3af'); r=w/'arc-preservation-recovery-20261019'; a=w/'arc-teacher-coverage-audit-20261019'
def compact(x,depth=0):
 if isinstance(x,dict):return {k:(compact(v,depth+1) if depth<2 else ('dict:'+str(len(v)) if isinstance(v,dict) else 'list:'+str(len(v)) if isinstance(v,list) else v)) for k,v in x.items()}
 if isinstance(x,list):return {'length':len(x),'sample':compact(x[0],depth+1) if x and depth<2 else None}
 return x
m=json.loads((r/'publication_coverage_network/payload_manifest.json').read_text()); arc=next(x['source'] for x in m['files'] if x['archive_path'].endswith('.tar.gz'))
with tarfile.open(arc,'r:gz') as t:
 members=t.getmembers(); names=[x.name for x in members]; man=json.load(t.extractfile('MANIFEST.json')); pins={x['path']:x for x in man['files']}; issues=[]; secrets=[]; patterns=[rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',rb'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,})\b',rb'\bsk-(?:proj-)?[A-Za-z0-9_-]{30,}\b',rb'(?im)^\s*(?:set-cookie|cookie):\s*[^\s]',rb'(?i)authorization\s*[:=]\s*[\"\x27]?\s*bearer\s+[A-Za-z0-9_.-]{16,}']
 assert len(names)==len(set(names)) and set(names)==set(pins)|{'MANIFEST.json'}
 for q in members:
  assert q.isfile() and not PurePosixPath(q.name).is_absolute() and '..' not in PurePosixPath(q.name).parts
  assert q.name=='MANIFEST.json' or q.name in pins
  assert q.name.endswith(('.json','.md','.py','.js','.txt','/exitstatus'))
  b=t.extractfile(q).read()
  if q.name in pins and (len(b)!=pins[q.name]['bytes'] or hashlib.sha256(b).hexdigest()!=pins[q.name]['sha256']):issues.append(q.name)
  if any(re.search(z,b) for z in patterns):secrets.append({'member':q.name,'reason':'credential_or_cookie_pattern'})
  for u in re.findall(rb'https?://[^\s"<>]+',b):
   try:
    if any(k.lower() in {'sig','signature','token','access_token','api_key','apikey','key','x-amz-signature'} for k in urllib.parse.parse_qs(urllib.parse.urlsplit(u.decode()).query)):secrets.append({'member':q.name,'reason':'credential_query_key'})
   except (UnicodeDecodeError,ValueError):pass
  if q.name.endswith('.py'):ast.parse(b)
  if q.name.endswith('.json') and b.strip():json.loads(b)
 print('RECEIPT_RESULT',json.dumps({'regular_members':len(members),'pinned_nonmanifest':len(pins),'raw_bytes':sum(q.size for q in members),'hash_errors':issues,'secret_candidates':secrets,'scope':'All receipt payloads read and scanned; own stderr only, no SDK stderr; referenced archives not followed.'}))
for rel in ['reports/summary.json','reports_v2/summary.json','reports_v2/coverage_by_game.json','reports_v2/coverage_by_level.json','reports_v2/saved_initials.json','reports_v2/local_teacher_refs.json','reports_v2/failure_packet_coverage.json','reports_v2/public_corpora.json','evidence/prior_refs_v2.json']:
 x=json.loads((a/rel).read_text()); print('REPORT',rel,json.dumps(compact(x),ensure_ascii=False))
for p in [a/'audit_coverage.py',a/'audit_failure_packets.py']:
 tree=ast.parse(p.read_text()); vals=sorted({x.value for x in ast.walk(tree) if isinstance(x,ast.Constant) and isinstance(x.value,str) and any(y in x.value for y in ('.tar.gz','.json','.jsonl','archives/','remaining/'))});print('SOURCE_PATH_CONSTANTS',p.name,json.dumps(vals,ensure_ascii=False))
print('CAPTURE_BYTES',sum(p.stat().st_size for p in (r/'publication_coverage_network/inspection_captures').rglob('*') if p.is_file()))
