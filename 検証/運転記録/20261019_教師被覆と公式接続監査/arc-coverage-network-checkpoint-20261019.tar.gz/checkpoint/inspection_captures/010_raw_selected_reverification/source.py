from pathlib import Path
import json,tarfile,hashlib,base64,collections,resource
w=Path('/workspace/scratch/a94ff513b3af'); a=w/'arc-teacher-coverage-audit-20261019'; r=w/'arc-preservation-recovery-20261019'
load=lambda n:json.loads((a/'reports_v2'/n).read_text()); corp=load('public_corpora.json'); initial=load('saved_initials.json'); failure=load('failure_packet_coverage.json'); refs=failure['evidence_refs']; packet_refs={(x['archive'],x['member']):x for x in failure['packets']}; groups=collections.defaultdict(dict)
for kind,items in [('corpus',corp),('initial',initial),('failure',refs)]:
 for x in items:
  n=x['member'];assert not any(z in n.lower() for z in ('sdk','game_sources','stderr'))
  if kind=='corpus':assert n.endswith(('.jsonl','api_response_v1.body'))
  elif kind=='initial':assert n.startswith('arc-official-fresh-all25-20261013/') and n.endswith('.public.json')
  else:assert '/evidence/087b258ca57e41ff82229797bd8035b4/' in n and not n.endswith('.py')
  groups[x['archive']][n]=(kind,x)
print('CLASSIFIED_SELECTED',json.dumps({'corpora':len(corp),'initial_packet_copies':len(initial),'failure_members':len(refs),'failure_extensions':dict(collections.Counter(Path(x['member']).suffix for x in refs))}))
results=[]; init_parsed=[]; packets=[]; failures_verified=0; issues=[]
for ap,selected in sorted(groups.items()):
 with tarfile.open(ap,'r:gz') as t:
  ms=t.getmembers(); roots=[m for m in ms if m.name in {'manifest.json','MANIFEST.json'} or (Path(m.name).name.startswith('volume_') and m.name.endswith('_manifest.json'))];assert len(roots)==1,(ap,[m.name for m in roots])
  man=json.load(t.extractfile(roots[0])); entries=next(man[k] for k in ['files','entries','source_entries','payload'] if k in man); ix={e['path']:e for e in entries}; byname={m.name:m for m in ms}
  assert set(selected)<=set(ix) and set(selected)<=set(byname)
  for name,(kind,old) in selected.items():
   m=byname[name];assert m.isfile(); h=hashlib.sha256(); n=0
   if kind=='corpus':
    rows=frames=footers=0; states=collections.Counter(); gids=collections.Counter(); errors=[]; invalid_frames=0
    for line in t.extractfile(m):
     h.update(line);n+=len(line);rows+=1
     try:
      v=json.loads(line);d=v.get('data',v);fs=d.get('frame')
      if fs is None:footers+=1;continue
      assert isinstance(fs,list);frames+=len(fs);states[d.get('state')]+=1;gids[d.get('game_id')]+=1
      for f in fs:
       if not (isinstance(f,list) and len(f)==64 and all(isinstance(rr,list) and len(rr)==64 and all(type(vv)==int and 0<=vv<=15 for vv in rr) for rr in f)):invalid_frames+=1
     except (ValueError,AssertionError,AttributeError) as e:errors.append({'row':rows-1,'type':type(e).__name__})
    res={'member':name,'bytes':n,'sha256':h.hexdigest(),'rows':rows,'frames':frames,'states':dict(states),'game_ids':dict(gids),'footers':footers,'parse_errors':errors,'invalid_frames':invalid_frames}
    assert all(res[k]==old[k] for k in ['rows','frames','states','game_ids']),('corpus_summary',name)
    assert len(errors)==len(old['row_errors']) and invalid_frames==0
    assert n==old['actual_bytes'] and h.hexdigest()==old['actual_sha256'];results.append(res)
   else:
    b=t.extractfile(m).read();n=len(b);h.update(b);assert n==old['bytes'] and h.hexdigest()==old['sha256']
    if kind=='failure':failures_verified+=1
    if kind=='initial' or (ap,name) in packet_refs:
     p=json.loads(b);d=p['model_json'];fs=p['frames']; hashes=[]
     for f in fs:
      fb=base64.b64decode(f['base64'],validate=True);fh=hashlib.sha256(fb).hexdigest();assert len(fb)==4096 and fh==f['sha256'] and f['shape']==[64,64] and f['dtype']=='|i1' and max(fb)<=15;hashes.append(fh)
     q={'sha256':h.hexdigest(),'game_id':d['game_id'],'frames':len(fs),'state':d['state'],'progress':d['levels_completed'],'frame_hashes':hashes}
     if kind=='initial':assert q['frames']==old['frames'];init_parsed.append(q)
     else:
      expected=packet_refs[(ap,name)];assert len(fs)==expected['frames'] and d['state']==expected['state'] and hashes==expected['frame_sha256'];q['kind']=expected['kind'];packets.append(q)
   pin=ix[name];assert n==pin['bytes'] and h.hexdigest()==pin['sha256'],('archive_manifest',ap,name)
 print('ARCHIVE_VERIFIED',json.dumps({'archive':ap,'selected_members':len(selected),'manifest':roots[0].name}))
uniq={x['sha256']:x for x in init_parsed};responses=[x for x in packets if x['kind']=='response']
print('RAW_RESULTS',json.dumps({'corpora':results,'initial_packet_copies':len(init_parsed),'unique_initial_packets':len(uniq),'unique_initial_frames':sum(x['frames'] for x in uniq.values()),'initial_games':len({x['game_id'] for x in uniq.values()}),'failure_members_hash_verified':failures_verified,'failure_packets_verified':len(packets),'response_packets':len(responses),'response_frames':sum(x['frames'] for x in responses),'response_states':dict(collections.Counter(x['state'] for x in responses)),'response_progress':dict(collections.Counter(x['progress'] for x in responses)),'AS_limit_bytes':resource.getrlimit(resource.RLIMIT_AS),'RSS_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'limits':'Compressed/semantic failure evidence hashed only; no memory decompression, replay, or causal certification. No opaque members read.'},ensure_ascii=False))
print('CAPTURE_BYTES',sum(p.stat().st_size for p in (r/'publication_coverage_network/inspection_captures').rglob('*') if p.is_file()))
