from pathlib import Path
import json,tarfile,gzip,hashlib,re
w=Path('/workspace/scratch/a94ff513b3af');r=w/'arc-preservation-recovery-20261019';cap=r/'publication_coverage_network/inspection_captures'
p=cap/'001_authority_manifest/stdout.txt';b=p.read_bytes();z=gzip.compress(b,mtime=0)
with p.with_suffix('.txt.gz').open('xb') as f:f.write(z)
assert gzip.decompress(p.with_suffix('.txt.gz').read_bytes())==b;p.unlink();print('LOSSLESS_COMPACTION',json.dumps({'source':'001_authority_manifest/stdout.txt','preserved_as':'001_authority_manifest/stdout.txt.gz','sha256':hashlib.sha256(b).hexdigest(),'raw_bytes':len(b),'compressed_bytes':len(z)}))
with tarfile.open(r/'remaining/official-connection-checkpoint-sanitized-20261016.tar.gz','r:gz') as t:
 x=json.load(t.extractfile('manifest.json'));print('SOURCE_ENTRY_SAMPLE',json.dumps(x['source_entries'][0],ensure_ascii=False))
for rel in ['arc-official-root-route-audit-20261019/README.md','arc-official-root-route-audit-20261019/request_result.json','arc-official-public-fetch-20261019/list.receipt.json','arc-official-public-fetch-20261019/summary.json','arc-official-public-fetch-20261019/escalated01/platform_blocker.json','arc-official-public-fetch-20261019/remote_container01/transported_report.json','arc-official-reconnect-audit-20261019/reports/sdk_metadata_only_status.json']:
 print('NETWORK_DOCUMENT',rel,(w/rel).read_text())
p=w/'arc-official-reconnect-audit-20261019/README.md';print('RECONNECT_BOUNDARY_LINES','\n'.join(x for x in p.read_text().splitlines() if re.search(r'https?://|default|DNS|401|403|認証|Cookie|cookie|既定',x,re.I)))
print('CAPTURE_BYTES',sum(p.stat().st_size for p in cap.rglob('*') if p.is_file()))
