from pathlib import Path
import json,tarfile,re,hashlib,collections
w=Path('/workspace/scratch/a94ff513b3af');r=w/'arc-preservation-recovery-20261019';m=json.loads((r/'publication_coverage_network/payload_manifest.json').read_text()); observations=[]; secret_fields=[]
def walk(x,path='$'):
 if isinstance(x,dict):
  for k,v in x.items():
   if re.fullmatch(r'(?:api[_-]?key|access[_-]?token|refresh[_-]?token|password|secret|authorization|cookie|set-cookie)',str(k),re.I) and isinstance(v,str) and v and v.lower() not in {'none','empty','disabled','not used','not_read','[redacted]','bearer',''}:secret_fields.append({'file':current,'key_path':path+'.'+k,'value_length':len(v),'placeholder':bool(re.search(r'YOUR_|your_|example|placeholder|<|>|\$|^os\.|^process\.',v))})
   yield from walk(v,path+'.'+str(k))
 elif isinstance(x,list):
  for i,v in enumerate(x):yield from walk(v,path+'['+str(i)+']')
 elif isinstance(x,str):yield path,x

def inspect(name,b,kind):
 global current
 current=name;s=b.decode();hds=bool(re.search('HDS|学習系統|学習機械正本|機構作用既知解',s)); embedded=[]
 if name.endswith('.json') and b.strip():
  for kp,v in walk(json.loads(s)):
   if len(v)>800 and (re.search(r'(?:content|body|text|markdown|document|source)$',kp,re.I) or re.fullmatch(r'[A-Za-z0-9+/=\r\n]{800,}',v)):
    embedded.append({'key_path':kp,'characters':len(v),'sha256':hashlib.sha256(v.encode()).hexdigest(),'prefix':v[:100]})
 hits=[]
 if hds and (name.endswith(('.md','.py','.js')) or embedded):
  hits=[line[:400] for line in s.splitlines() if re.search('HDS|学習系統|学習機械正本|機構作用既知解',line)]
  hits=hits[:12]
 observations.append({'file':name,'class':kind,'mentions_hds':hds,'embedded_body_candidates':embedded,'hds_context':hits})
for x in m['files']:
 p=Path(x['source']);n=x['archive_path']
 if n.endswith('.tar.gz'):
  with tarfile.open(p,'r:gz') as t:
   man=json.load(t.extractfile('MANIFEST.json')); names=['MANIFEST.json']+[z['path'] for z in man['files']]
   for q in names:
    kind='owned_publication_source' if q.endswith(('.py','.js')) else 'publication_metadata_or_operational_document'
    inspect('receipt:'+q,t.extractfile(q).read(),kind)
 else:
  kind='owned_implementation_or_audit_source' if p.suffix=='.py' else 'package_metadata_and_public_docs' if p.name.endswith('.METADATA') else 'coverage_projection_or_pin_metadata' if 'teacher-coverage' in n and p.suffix=='.json' else 'owned_audit_document_or_metadata'
  inspect(n,p.read_bytes(),kind)
print('CLASS_COUNTS',json.dumps(dict(collections.Counter(x['class'] for x in observations))))
print('FILE_CLASSIFICATION',json.dumps([{k:v for k,v in x.items() if k not in {'hds_context','embedded_body_candidates'}} for x in observations],ensure_ascii=False))
print('CONTENT_CANDIDATES',json.dumps([x for x in observations if x['embedded_body_candidates'] or x['hds_context']],ensure_ascii=False))
print('SENSITIVE_FIELD_CANDIDATES',json.dumps(secret_fields,ensure_ascii=False))
print('CAPTURE_BYTES',sum(p.stat().st_size for p in (r/'publication_coverage_network/inspection_captures').rglob('*') if p.is_file()))
