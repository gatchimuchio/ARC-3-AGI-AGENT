from pathlib import Path
import json,tarfile,hashlib,gzip,re,resource,collections
r=Path('/workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019');root=r/'publication_coverage_network';cap=root/'inspection_captures';manifest=root/'payload_manifest.json';m=json.loads(manifest.read_text());bad=[]
for f in m['files']:
 b=Path(f['source']).read_bytes()
 if len(b)!=f['bytes'] or hashlib.sha256(b).hexdigest()!=f['sha256']:bad.append(f['archive_path'])
assert not bad and len(m['files'])==65 and sum(x['bytes'] for x in m['files'])==6468027
sensitive=[];decoded=[];trees=[]
def inspect(x,path,depth=0):
 if isinstance(x,dict):
  if isinstance(x.get('tree'),list):
   rows=x['tree'];assert all(set(z)<={'path','mode','type','sha','size','url'} for z in rows);trees.append({'location':path,'entries':len(rows),'canonical_hds_document_path_references':sum(z.get('path','').startswith('HDS/') and z.get('path','').endswith('.md') for z in rows),'file_bodies':0})
  for k,v in x.items():
   if re.fullmatch(r'(?:api[_-]?key|access[_-]?token|refresh[_-]?token|password|secret|authorization|cookie|set-cookie)',str(k),re.I) and isinstance(v,str) and v and v.lower() not in {'none','empty','disabled','not used','not_read','[redacted]','bearer'}:sensitive.append({'location':path+'.'+k,'length':len(v)})
   inspect(v,path+'.'+str(k),depth)
 elif isinstance(x,list):
  for i,v in enumerate(x):inspect(v,path+'['+str(i)+']',depth)
 elif isinstance(x,str) and depth<4 and x.lstrip().startswith(('{','[')):
  try:y=json.loads(x)
  except ValueError:return
  decoded.append({'location':path,'keys':list(y)[:16] if isinstance(y,dict) else 'list'});inspect(y,path+'<decoded>',depth+1)
arc=next(f['source'] for f in m['files'] if f['archive_path'].endswith('.tar.gz'))
with tarfile.open(arc,'r:gz') as t:
 man=json.load(t.extractfile('MANIFEST.json'))
 for f in man['files']:
  if f['path'].endswith('.json'):
   b=t.extractfile(f['path']).read()
   if b.strip():inspect(json.loads(b),'receipt:'+f['path'])
assert not sensitive
print('INNER_JSON_VERIFICATION',json.dumps({'decoded_json_strings':len(decoded),'tree_metadata':trees,'sensitive_field_candidates':sensitive,'decoded_top_level_shapes':decoded[:16]},ensure_ascii=False))
raw=json.loads(next(x[len('RAW_RESULTS '):] for x in (cap/'012_raw_selected_reverification_corrected/stdout.txt').read_text().splitlines() if x.startswith('RAW_RESULTS ')))
recomputed=json.loads(next(x[len('RECOMPUTED '):] for x in (cap/'009_coverage_recompute_plan/stdout.txt').read_text().splitlines() if x.startswith('RECOMPUTED ')))
report={
 'schema':'arc3-coverage-network-independent-admission-v1',
 'status':'CONTENT_SCOPE_PASS_WITH_CAPTURE_PROTOCOL_EXCEPTIONS',
 'publication_authorization':'Not granted by this report. Parent owns publication and current visibility/Owner-scope reconciliation.',
 'manifest':{'path':'payload_manifest.json','sha256':hashlib.sha256(manifest.read_bytes()).hexdigest(),'file_count':65,'raw_bytes':6468027,'all_size_sha256_pins_rechecked':True},
 'authority':{'all_six_documents_read':True,'paths':[str(p.relative_to(r)) for p in sorted((r/'authority').glob('*.md'))]+['main/AGENTS.md','main/運用/権限順序.md','main/制御/現在状態.json'],'strategy':None,'automatic_transition':False,'frozen_core':'HDS/学習系統/v0.4.2'},
 'content_safety':{'plain_payload_files':64,'owned_python_sources_ast_parsed':13,'package_METADATA_files':2,'receipt_archive_regular_members':70,'receipt_manifest_pinned_members':69,'receipt_member_hashes_all_match':True,'receipt_uncompressed_bytes':622142,'official_game_or_SDK_implementation_bodies_read_or_included':False,'SDK_stderr_read_or_included':False,'secret_or_transport_cookie_candidates':[],'methods':['Exact name classification before payload reads','Token/private-key/JWT/Authorization/Cookie pattern scans','Signed or credential-query URL scan within receipt members','Sensitive JSON key/value screen including decoded embedded receipt JSON','Full receipt manifest closure, regular-file and path-traversal checks'],'limits':'No mathematical guarantee against arbitrary obfuscation; no credential directories or credential sources accessed. Referenced arbitrary files/URLs were not followed.'},
 'hds_original_document_classification':{'canonical_original_specification_or_design_bodies_found':0,'plain_file_classes':{'owned_audit_document_or_metadata':31,'owned_implementation_or_audit_source':13,'coverage_projection_or_pin_metadata':18,'package_metadata_and_public_docs':2},'receipt_member_classes':{'publication_metadata_or_operational_document':60,'owned_publication_source':10},'reference_examples':['prior_refs.json and prior_refs_v2.json contain canonical prior-memory path/size/hash pins only','coverage matrices contain inventory and observation projections','goal6 sources contain implementation and public HDS import/API references','base_tree and new_tree receipt contain path/mode/type/SHA/size/URL metadata, including HDS document paths, but no blob bodies','Long embedded receipt strings decode to Git commit/tree/repository metadata, not canonical document text'],'tree_schema_checks':trees,'classification_capture':'inspection_captures/013_hds_original_document_screen/stdout.txt.gz','inspection_scope':'Only frozen 65 files, the 70 receipt members, and specifically selected public-recording/packet evidence; no whole-repository or arbitrary-reference audit. Authority capture contains operational Owner/AGENTS/current-state documents, not canonical HDS design originals.'},
 'coverage':{'retained_report_recomputation':recomputed,'independent_raw_reverification':raw,'boundaries':['25 games and 183 levels are historical inventory/index coverage, not current fresh success coverage','5112 is the retained aggregate initial-action count; full raw joins remain unavailable, not zero prior measurements','Only cd82, sb26, sk48 have verified public temporal recording chains within surveyed assets; the other 22 lack such verified chains within this survey','Nine known-success sequence records are historical indexed records, not fresh reruns or general learned ability','Old truncated sb26 recording overlaps the v2 artifact; do not sum both as independent trajectories','90 response actions and 1812 phases remain NOT_FINISHED; observed progress 6 does not certify six levels','451 XZ failure members were byte-hashed only; no memory decompression, replay, causality or teacher-boundary certification'],'not_repeated':['No SDK/native/HDS/game Action or fresh instance reproduction','No full 5112 raw reconstruction or per-level raw causal join','No canonical prior-memory source reopening outside the frozen payload','No whole-archive source/body inspection; only manifest metadata and selected public members','No temporal-adjacency/support/witness/applicability proof beyond retained report scope']},
 'network':{'new_requests':0,'retained_results':'DNS failures, pre-execution platform failure, and web-tool inaccessible/Internal Error; no HTTP response status/body obtained','current_inventory_obtained':False,'authentication_conclusion':None,'route_boundary':'arcprize.org benchmarking-client root and three.arcprize.org SDK/doc default coexist in retained public-interface observations. No global migration, current availability, or anonymous authorization conclusion. Exact upstream source commit/file bytes were not pinned.','retained_remote_report_transport_hash_verified_by_payload_pin':True,'historical_privacy_receipt':'Snapshot only, not proof of current repository visibility'},
 'execution':{'network_calls':0,'Git_or_Library_writes':0,'payload_source_imports_or_execution':0,'SDK_or_native_calls':0,'Action_calls':0,'opaque_reads':0,'bulk_extraction':False,'AS_limit_bytes':268435456,'raw_recheck_peak_RSS_KiB':raw['RSS_KiB']},
 'capture_protocol':{'strict_compliance':False,'initial_deviation':'Before capture 001, a name/size-only pwd/find listing ran without a fresh leaf. It read no payload bodies. Reported immediately to parent.','initial_exact_command':"pwd; find arc-preservation-recovery-20261019/authority -maxdepth 1 -type f -name '*.md' -print; find arc-preservation-recovery-20261019/publication_coverage_network -maxdepth 2 -type f -printf '%P %s bytes\\n' | sort",'failed_leaves_retained_unchanged':['002_payload_classify','003_payload_classify','004_payload_classify','005_payload_classify','010_raw_selected_reverification'],'failed_run_causes':'Fail-closed missing explicit owned filename classifications in 002-005; member/path manifest-schema mismatch in 010. Corrected only in fresh leaves.','temporary_disk_budget_exceedance':{'observed_bytes':270084,'limit_bytes':204800,'cause':'Successful 006 stdout unintentionally included a long first corpus record','remedy':'Exact successful stdout retained losslessly as gzip, with original-byte SHA-256 and lossless checks in fresh capture 007; successful 001 and 013 outputs similarly compacted in 011 and 014. Failed leaves and source files never overwritten.'},'capture_reads':'Results reviewed only after exit status was persisted. Sources are standalone validators, not executed payload scripts.','report_plus_capture_limit_bytes':204800}
}
out=root/'payload_admission.json';assert not out.exists();data=(json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode();before=sum(p.stat().st_size for p in cap.rglob('*') if p.is_file());assert before+len(data)+3000<=204800,(before,len(data))
with out.open('xb') as f:f.write(data)
assert json.loads(out.read_text())==report
print('FINAL_REPORT',json.dumps({'path':str(out),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'report_plus_captures_before_final_stdout_flush':before+len(data),'reserved_stdout_status_bytes':3000,'limit_bytes':204800,'content_scope_pass':True,'strict_capture_protocol_pass':False}))
