from pathlib import Path
import json,tarfile,collections
w=Path('/workspace/scratch/a94ff513b3af'); a=w/'arc-teacher-coverage-audit-20261019'; r=w/'arc-preservation-recovery-20261019'
load=lambda n:json.loads((a/n).read_text())
g=load('reports_v2/coverage_by_game.json')['games']; l=load('reports_v2/coverage_by_level.json'); s=load('reports_v2/saved_initials.json'); f=load('reports_v2/failure_packet_coverage.json'); c=load('reports_v2/public_corpora.json')
print('RECOMPUTED',json.dumps({'games':len(g),'indexed_levels_sum':sum(x['indexed_levels'] for x in g),'level_rows':len(l),'unique_level_keys':len({(x['game_id'],x['level']) for x in l}),'aggregate_actions_sum':sum(x['aggregate_first_action_count'] for x in g),'known_sequence_records':sum(len(x['known_success_records']) for x in g),'trajectory_games':[x['base_game_id'] for x in g if x['public_corpora']],'without_trajectory_games':[x['base_game_id'] for x in g if not x['public_corpora']],'initial_report_rows':len(s),'initial_unique_packet_hashes':len({x['sha256'] for x in s}),'initial_unique_frames':sum(x['frames'] for x in {x['sha256']:x for x in s}.values()),'failure_report_members':len(f['evidence_refs']),'failure_report_unique_members':len({(x['archive'],x['member']) for x in f['evidence_refs']}),'failure_packet_kind_counts':dict(collections.Counter(x['kind'] for x in f['packets'])),'failure_response_frames':sum(x['frames'] for x in f['packets'] if x['kind']=='response'),'failure_response_states':dict(collections.Counter(x['state'] for x in f['packets'] if x['kind']=='response'))},ensure_ascii=False))
print('CORPORA',json.dumps([{k:x.get(k) for k in ['archive','member','actual_bytes','actual_sha256','rows','frames','game_ids','states','row_errors','public_frames_validation_errors']} for x in c],ensure_ascii=False))
print('INITIAL_ARCHIVES',json.dumps(sorted({x['archive'] for x in s})))
print('FAILURE_ARCHIVES',json.dumps(f['archives']))
print('FAILURE_SOURCE', (a/'audit_failure_packets.py').read_text())
archives=sorted({x['archive'] for x in s+c+f['evidence_refs']})
for p in archives:
 with tarfile.open(p,'r:gz') as t:
  ms=t.getmembers(); manifests=[q for q in ms if Path(q.name).name.lower() in {'manifest.json','_manifest.json'}]
  print('ARCHIVE_METADATA',json.dumps({'path':p,'members':len(ms),'manifests':[{'name':q.name,'size':q.size} for q in manifests]}))
  for q in manifests:
   j=json.load(t.extractfile(q)); print('MANIFEST_SCHEMA',q.name,json.dumps({'type':type(j).__name__,'keys':list(j) if isinstance(j,dict) else None,'first':(j.get('files',j.get('entries',[]))[:1] if isinstance(j,dict) else j[:1])},ensure_ascii=False))
print('CAPTURE_BYTES',sum(p.stat().st_size for p in (r/'publication_coverage_network/inspection_captures').rglob('*') if p.is_file()))
