from pathlib import Path
import gzip,hashlib,json
r=Path('/workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019/publication_coverage_network/inspection_captures')
p=r/'006_payload_classify/stdout.txt'; b=p.read_bytes(); z=gzip.compress(b,mtime=0)
with (p.with_suffix('.txt.gz')).open('xb') as f:f.write(z)
assert gzip.decompress(p.with_suffix('.txt.gz').read_bytes())==b
p.unlink()
print(json.dumps({'source':'006_payload_classify/stdout.txt','preserved_as':'006_payload_classify/stdout.txt.gz','raw_bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'compressed_bytes':len(z),'verified_lossless':True,'failed_leaves_unchanged':True,'allocation_bytes_now':sum(x.stat().st_size for x in r.rglob('*') if x.is_file())}))
