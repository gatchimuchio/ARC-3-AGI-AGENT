from pathlib import Path
import gzip,hashlib,json
p=Path('/workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019/publication_coverage_network/inspection_captures/013_hds_original_document_screen/stdout.txt');b=p.read_bytes();z=gzip.compress(b,mtime=0)
with p.with_suffix('.txt.gz').open('xb') as f:f.write(z)
assert gzip.decompress(p.with_suffix('.txt.gz').read_bytes())==b;p.unlink()
print(json.dumps({'source':p.name,'preserved_as':p.with_suffix('.txt.gz').name,'raw_bytes':len(b),'compressed_bytes':len(z),'sha256':hashlib.sha256(b).hexdigest(),'verified_lossless':True}))
