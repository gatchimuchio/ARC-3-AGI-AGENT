from pathlib import Path
import gzip,hashlib,json
root=Path('/workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019/publication_coverage_network/inspection_captures')
for leaf in ['008_receipts_and_coverage_shapes','009_coverage_recompute_plan']:
 p=root/leaf/'stdout.txt';b=p.read_bytes();z=gzip.compress(b,mtime=0)
 with p.with_suffix('.txt.gz').open('xb') as f:f.write(z)
 assert gzip.decompress(p.with_suffix('.txt.gz').read_bytes())==b;p.unlink()
 print(json.dumps({'source':str(p.relative_to(root)),'preserved_as':str(p.with_suffix('.txt.gz').relative_to(root)),'raw_bytes':len(b),'compressed_bytes':len(z),'sha256':hashlib.sha256(b).hexdigest(),'verified_lossless':True}))
