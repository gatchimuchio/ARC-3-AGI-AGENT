from pathlib import Path
import json,hashlib,ast,re,tarfile,collections
r=Path('/workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019'); m=json.loads((r/'publication_coverage_network/payload_manifest.json').read_text())
classes={}; errors=[]; candidates=[]; ast_results=[]
owned={'audit_coverage.py','audit_coverage_attempt01.py','audit_failure_packets.py','audit_failure_packets_attempt01.py','collect_readonly.py','audit.py','download_opaque.py','fresh_all25_v1.py','goal6_知覚.py','goal6_関係.py','fetch_public.py'}
for f in m['files']:
 n=f['archive_path']; p=Path(f['source']); suffix=p.suffix
 c='owned_inert_source' if p.name in owned else 'package_metadata' if p.name.endswith('.METADATA') else 'receipt_archive' if n=='prior_publication_receipts/goal6_bridge_publication_receipts.tar.gz' else 'audit_document' if suffix in {'.json','.md'} or p.name=='failure_packets_attempt01.txt' else None
 assert c is not None,('UNCLASSIFIED',n)
 assert not any(x in n.lower() for x in ('stderr','site-packages/','game_sources/','opaque/')),(n,'scope')
 classes[n]=c
print('CLASSIFICATION',json.dumps(classes,ensure_ascii=False))
patterns={'private_key':rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----','github_token':rb'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,})\b','openai_key':rb'\bsk-(?:proj-)?[A-Za-z0-9_-]{30,}\b','aws_key':rb'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b','jwt':rb'\beyJ[A-Za-z0-9_-]{15,}\.[A-Za-z0-9_-]{15,}\.[A-Za-z0-9_-]{15,}\b','transport_cookie':rb'(?im)^\s*(?:set-cookie|cookie):\s*[^\s]','auth_bearer':rb'(?i)authorization\s*[:=]\s*[\"\x27]?\s*bearer\s+[A-Za-z0-9_.-]{16,}'}
for f in m['files']:
 p=Path(f['source']); b=p.read_bytes(); n=f['archive_path']; c=classes[n]
 if len(b)!=f['bytes'] or hashlib.sha256(b).hexdigest()!=f['sha256']: errors.append(n)
 if c=='receipt_archive':continue
 for k,pat in patterns.items():
  if re.search(pat,b):candidates.append({'file':n,'kind':k})
 if c=='owned_inert_source':
  tree=ast.parse(b,filename=n); ast_results.append({'file':n,'nodes':sum(1 for _ in ast.walk(tree)),'imports':sorted({x.name for y in ast.walk(tree) if isinstance(y,(ast.Import,ast.ImportFrom)) for x in y.names})})
print('INTEGRITY',json.dumps({'count':len(m['files']),'bytes':sum(f['bytes'] for f in m['files']),'mismatches':errors,'secret_pattern_candidates':candidates,'source_ast':ast_results},ensure_ascii=False))
for f in m['files']:
 n=f['archive_path']; p=Path(f['source'])
 if n.endswith('.json'):
  x=json.loads(p.read_text())
  if p.name in {'summary.json','request_result.json','list.receipt.json','platform_blocker.json','web_metadata_results.json','provenance.json','transported_report.json','sdk_metadata_only_status.json'}: print('JSON',n,json.dumps(x,ensure_ascii=False))
  elif 'teacher-coverage' in n and p.name!='MANIFEST.json':
   shape={k:(str(type(v).__name__),len(v) if hasattr(v,'__len__') else None) for k,v in x.items()} if isinstance(x,dict) else {'list_length':len(x),'first':x[:1]}
   print('SHAPE',n,json.dumps(shape,ensure_ascii=False))
for f in m['files']:
 if classes[f['archive_path']]=='receipt_archive':
  with tarfile.open(f['source'],'r:gz') as t:
   members=t.getmembers(); print('RECEIPT_MEMBERS',json.dumps([{'name':x.name,'size':x.size,'type':x.type.decode(errors='replace')} for x in members],ensure_ascii=False))
   for x in members:
    if Path(x.name).name=='MANIFEST.json':print('RECEIPT_MANIFEST',x.name,t.extractfile(x).read().decode())
print('CAPTURE_BYTES',sum(p.stat().st_size for p in (r/'publication_coverage_network/inspection_captures').rglob('*') if p.is_file()))
