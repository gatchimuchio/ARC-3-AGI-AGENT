from pathlib import Path
import json
r=Path('/workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019')
paths=sorted((r/'authority').glob('*.md'))+[r/'main/AGENTS.md',r/'main/運用/権限順序.md',r/'main/制御/現在状態.json']
for p in paths:
    print('\n=== AUTHORITY',p.relative_to(r),'===\n'+p.read_text())
p=r/'publication_coverage_network/payload_manifest.json'
x=json.loads(p.read_text())
print('\n=== MANIFEST ===\n'+json.dumps(x,ensure_ascii=False,indent=2))
