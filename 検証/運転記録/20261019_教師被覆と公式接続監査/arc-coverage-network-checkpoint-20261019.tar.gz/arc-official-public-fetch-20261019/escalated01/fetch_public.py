"""Bounded unauthenticated public fetch. Source bodies are opaque bytes only."""
import hashlib,json,os,re,resource,ssl,time,urllib.request,urllib.error
from pathlib import Path
resource.setrlimit(resource.RLIMIT_AS,(512*1048576,512*1048576))
R=Path(__file__).resolve().parent;ROOT='https://three.arcprize.org'
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*args,**kwargs):return None
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect(),urllib.request.HTTPSHandler(context=ssl.create_default_context()))
records=[];stop=False
class Stop(Exception):pass
def save(name,x):
 with (R/name).open('x') as f:json.dump(x,f,ensure_ascii=False,indent=2)
def get(path,name,opaque=False):
 global stop
 if stop:raise Stop('previous blocked request')
 assert path.startswith('/api/games') and '?' not in path and '#' not in path
 rec={'url':ROOT+path,'auth':'none','credentials_read_or_created':False,'opaque':opaque,'started_UTC':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'state':'started'};records.append(rec)
 save(name+'.intent.json',rec)
 try:
  req=urllib.request.Request(ROOT+path,headers={'Accept':'application/octet-stream' if opaque else 'application/json','User-Agent':'ARC3-public-evidence-audit/1'})
  try:response=opener.open(req,timeout=20)
  except urllib.error.HTTPError as e:
   rec['http_status']=e.code;rec['headers']={k:v for k,v in e.headers.items() if k.lower() in ('content-type','content-length','date','etag','last-modified')};e.close()
   rec['state']='AUTH_REQUIRED' if e.code in (401,403) else 'HTTP_STOP';stop=True;raise Stop(rec['state'])
  with response:
   rec['http_status']=response.status;rec['headers']={k:v for k,v in response.headers.items() if k.lower() in ('content-type','content-length','date','etag','last-modified')}
   if response.status!=200:stop=True;raise Stop('non200')
   cap=1048576 if opaque else 262144;count=0;h=hashlib.sha256();target=R/(name+('.opaque' if opaque else '.json'));rec['body_file']=target.name
   # All partial bytes persist; no source body decoding or printing.
   with target.open('xb') as f:
    while True:
     block=response.read(min(16384,cap-count+1))
     if not block:break
     f.write(block);count+=len(block);h.update(block)
     if count>cap:stop=True;raise Stop('response cap exceeded; partial retained')
    f.flush();os.fsync(f.fileno())
   rec.update({'bytes':count,'sha256':h.hexdigest(),'state':'RECEIVED'})
   if opaque:
    rec['matches_historical']=count==34381 and h.hexdigest()=='dafeabff60a3a99b5c93629f8da0d8f555b873ef16a522247d6197b1b3addbcb';return None
   return json.loads(target.read_bytes())
 except Stop:raise
 except Exception as e:
  stop=True;rec['state']='NETWORK_OR_VALIDATION_STOP';rec['exception_type']=type(e).__name__;rec['exception']=str(e);raise Stop(rec['state'])
 finally:
  rec['finished_UTC']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());save(name+'.receipt.json',rec)
summary={'SDK_imports':0,'Action':0,'credentials_read_or_created':0,'source_inspection':False,'current_inventory':None}
try:
 games=get('/api/games','list')
 if not isinstance(games,list):raise Stop('list schema not array')
 ids=[x.get('game_id') for x in games]
 if any(not isinstance(x,str) or not re.fullmatch('[a-z0-9]{4}-[a-z0-9]+',x) for x in ids) or len(set(ids))!=len(ids) or len(ids)>100:raise Stop('bounded versioned ID schema')
 details=[]
 for i,gid in enumerate(ids):
  value=get('/api/games/'+gid,'detail_%03d'%i)
  if not isinstance(value,dict) or value.get('game_id')!=gid:raise Stop('detail identity schema')
  baseline=value.get('baseline_actions')
  if not isinstance(baseline,list) or any(type(x)is not int or x<0 for x in baseline):raise Stop('baseline level schema')
  details.append(value)
 summary['current_inventory']={'games':len(games),'levels':sum(len(x['baseline_actions']) for x in details),'details':details}
 get('/api/games/cd82-fb555c5d/source','cd82_source',True)
 summary['state']='COMPLETE'
except Stop as e:summary.update({'state':'STOPPED','reason':str(e),'unattempted_work_retained':True})
summary.update({'requests':records,'AS':resource.getrlimit(resource.RLIMIT_AS),'RSS_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss});save('summary.json',summary)
print(json.dumps({'state':summary['state'],'reason':summary.get('reason'),'requests':[{'url':x['url'],'state':x['state'],'http_status':x.get('http_status'),'exception':x.get('exception')} for x in records]},ensure_ascii=False))
