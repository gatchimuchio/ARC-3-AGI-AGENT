import json,hashlib,collections
from pathlib import Path
R=Path(__file__).resolve().parent;B=R.parent
sha=lambda b:hashlib.sha256(b).hexdigest()
refs=[]
for rel in ['README.md','goal6_full_witness_joins.json','existing_four_row_full_witness_joins.json','control_source_verification.json','control_all58_phase_join_verification.json','control/goalset_teacher_pack_v2.json']:
 p=B/'arc-teacher-contrasts-20261019'/rel;b=p.read_bytes();refs.append({'path':str(p),'bytes':len(b),'sha256':sha(b)})
# Referenced local witnesses are readable and pinned, without duplicating large packets.
for folder,glob in [('witnesses','*.json'),('control','raw_row*.json')]:
 for p in sorted((B/'arc-teacher-contrasts-20261019'/folder).glob(glob)):
  b=p.read_bytes();refs.append({'path':str(p),'bytes':len(b),'sha256':sha(b)})
(R/'reports_v2/local_teacher_refs.json').write_text(json.dumps(refs,ensure_ascii=False,indent=2))
g=json.loads((R/'reports_v2/coverage_by_game.json').read_text())['games'];lev=json.loads((R/'reports_v2/coverage_by_level.json').read_text());failure=json.loads((R/'reports_v2/failure_packet_coverage.json').read_text())
for x in g:
 gid=x['base_game_id'];x['public_causal_teacher_status']='no complete causal teacher chain verified'
 x['role_relation_vocabulary']='prior index has no grounded role/relation records; initial pixels referenceable; action IDs do not establish effects'
 if gid=='cd82':x.update(public_causal_teacher_status='six locally joined historical goal6 teacher pairs; 112 phases, 35 interpretable / 77 unknown, see local_teacher_refs',role_relation_vocabulary='10x10 reference/target; tool color/direction; fixed geometric overwrite membership is an explicit prior; deficient/satisfied goal relations; repair-all and preserve-all endpoint predicates')
 if gid=='sb26':x.update(public_causal_teacher_status='four historical teachers fully joined; full 58-relation control pack joined to 59 recording rows / 1530 after phases; separate 90-action failed-closed live run',role_relation_vocabulary='structural cell/column/swatches/panel roles; complete goal pool; preparation/effect/repair/preservation queries; disputed or unsupported evidence must gate execution',historical_failed_run={'before_packets':90,'response_packets':90,'response_phases':1812,'all_states':'NOT_FINISHED','public_progress_values':list(range(7)),'all_selected_1797_member_hashes_verified':True,'semantic_replay_this_unit':False,'certified_new_levels':0,'detail':'reports_v2/failure_packet_coverage.json'})
 if gid=='sk48':x.update(public_causal_teacher_status='complete public recording available; historical chain teachers not fully causally rejoined in this audit',role_relation_vocabulary='public directional/click actions and endpoint progress available; chain relation labels require existing producer and phase witness rejoin; version 41055498 differs from prior d8078629')
for x in lev:
 if x['game_id']=='sb26':x['failure_run_public_position_observed']=x['level']-1 in range(7);x['failure_run_position_is_success_certificate']=False
(R/'coverage_matrix.json').write_text(json.dumps({'scope':'Historical accessible evidence only. IDs index provenance, never runtime policy. No raw5112 identity join. No fresh network inventory.','games':g,'levels':lev,'teacher_reference_file':'reports_v2/local_teacher_refs.json'},ensure_ascii=False,indent=2))
print('games',len(g),'levels',len(lev),'local_refs',len(refs),'bytes',sum(x['bytes']for x in refs))
