import base64,collections,hashlib,json,resource,tarfile
from pathlib import Path
resource.setrlimit(resource.RLIMIT_AS,(512*1048576,512*1048576))
R=Path(__file__).resolve().parent;B=R.parent
sha=lambda x:hashlib.sha256(x).hexdigest()
packets=[];refs=[];archives=[];counts=collections.Counter();errors=[]
for p in sorted((B/'arc-preservation-recovery-20261019/remaining').glob('*volume_0*_of_03.tar.gz')):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 manifest=None;local=[]
 with tarfile.open(p,'r|gz') as tf:
  for m in tf:
   if not m.isfile():continue
   if m.name.endswith('_manifest.json') and '/volume_' not in m.name and m.name.startswith('volume_'):
    manifest=json.load(tf.extractfile(m));continue
   if '/evidence/087b258ca57e41ff82229797bd8035b4/' not in m.name:continue
   selected= '/transport/' in m.name or '/failure/' in m.name or any(x in m.name for x in ('current_complete_semantic','full-candidates','unexecuted-','step_outcome','after_current_queries','RuntimeMemory','all_response_goal_effects')) or m.name.endswith('fresh-initial.public.json')
   if not selected:continue
   raw=tf.extractfile(m).read();r={'archive':str(p),'member':m.name,'bytes':len(raw),'sha256':sha(raw)};refs.append(r);local.append(r)
   kind=m.name.rsplit('/',1)[-1].split('.')[-2] if '/transport/'in m.name else 'saved_evidence';counts[kind]+=1
   if '/transport/'in m.name and m.name.endswith(('.before.json','.response.json')) or m.name.endswith('fresh-initial.public.json'):
    try:
     x=json.loads(raw);d=x['model_json'];fs=x['frames'];fr=[]
     for f in fs:
      b=base64.b64decode(f['base64'],validate=True);assert len(b)==4096 and sha(b)==f['sha256'] and f['shape']==[64,64] and f['dtype']=='|i1' and max(b)<=15;fr.append(sha(b))
     packets.append(dict(r,kind=kind,game_id=d['game_id'],levels_completed=d['levels_completed'],win_levels=d['win_levels'],state=d['state'],action_input=d['action_input'],guid=d['guid'],full_reset=d['full_reset'],frames=len(fs),frame_sha256=fr))
    except Exception as e:errors.append(dict(r,error=repr(e)))
 assert manifest is not None
 ix={x['path']:x for x in manifest['payload']}
 for r in local:r['manifest_verified']=r['member']in ix and all(r[k]==ix[r['member']][k]for k in ('bytes','sha256'))
 archives.append({'path':str(p),'bytes':p.stat().st_size,'sha256':h.hexdigest(),'selected':len(local),'all_selected_verified':all(x['manifest_verified']for x in local),'payload_entries':len(ix)})
bykind={k:{'packets':sum(x['kind']==k for x in packets),'frames':sum(x['frames']for x in packets if x['kind']==k),'progress':dict(collections.Counter(str(x['levels_completed'])for x in packets if x['kind']==k)),'states':dict(collections.Counter(x['state']for x in packets if x['kind']==k))} for k in sorted({x['kind'] for x in packets})}
out={'archives':archives,'counts':dict(counts),'packet_summary':bykind,'packet_errors':errors,'packets':packets,'evidence_refs':refs,'scope':'Public packet validation and byte hashes only. Semantic and compressed memory evidence referenceable; not replayed or causally revalidated. Failure remains failed-closed. No fresh success certification.','RSS_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(R/'reports_v2/failure_packet_coverage.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in out.items()if k not in ('packets','evidence_refs')},ensure_ascii=False))
