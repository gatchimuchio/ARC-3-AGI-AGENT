"""Stream only identified public recordings; never SDK/game/evaluator code."""
import base64,collections,hashlib,json,resource,tarfile,traceback
from pathlib import Path
resource.setrlimit(resource.RLIMIT_AS,(512*1048576,512*1048576))
R=Path(__file__).resolve().parent;B=R.parent

def sha(b):return hashlib.sha256(b).hexdigest()
def put(n,x):
 with (R/n).open('x') as f:json.dump(x,f,ensure_ascii=False,indent=2)
def ref(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
P=B/'ARC-3-AGI-AGENT/記憶/事前記憶/v0.4';m=json.loads((P/'マニフェスト.json').read_text())
for key in ('索引','統合正本'):assert sha((P/m[key]['path']).read_bytes())==m[key]['SHA256']
prior=json.loads((P/m['統合正本']['path']).read_text());levels=json.loads((P/m['索引']['path']).read_text())
put('evidence/prior_refs.json',{'manifest':ref(P/'マニフェスト.json'),'index':ref(P/m['索引']['path']),'canonical':ref(P/m['統合正本']['path']),'expected_hashes_verified':True})
archives=[B/'arc-preservation-recovery-20261019/remaining/arc-recovery-20261013-evidence.tar.gz',B/'ARC3_目標相対操作学習_20261013_v2.tar.gz',B/'arc-preservation-recovery-20261019/remaining/official-connection-checkpoint-sanitized-20261016.tar.gz']
corpora=[];initial=[];archives_checked=[]
def scan_recording(stream,member,archive):
 record={'archive':str(archive),'member':member.name,'declared_bytes':member.size,'rows':0,'frames':0,'actions':collections.Counter(),'states':collections.Counter(),'public_progress_values':collections.Counter(),'game_ids':collections.Counter(),'guid_count':0,'progress_increases':0,'progress_decreases':0,'same_guid_game_adjacent_pairs':0,'resets':0,'row_errors':[],'row_refs':[],'public_frames_validation_errors':[],'hidden_delta':'unknown; not inspected'}
 h=hashlib.sha256();offset=0;previous=None;guids=set()
 while True:
  raw=stream.readline(16*1048576+1)
  if not raw:break
  h.update(raw);rowno=record['rows'];record['rows']+=1
  rr={'row':rowno,'offset':offset,'bytes':len(raw),'sha256':sha(raw)};record['row_refs'].append(rr);offset+=len(raw)
  try:
   if len(raw)>16*1048576:raise ValueError('row exceeds admitted16MiB; content not parsed')
   parsed=json.loads(raw);d=parsed.get('data',parsed);frames=d.get('frame');assert isinstance(d,dict) and isinstance(frames,list)
   gid=d.get('game_id');state=d.get('state');action=d.get('action_input');guid=d.get('guid');score=d.get('score',d.get('levels_completed'))
   record['game_ids'][str(gid)]+=1;record['states'][str(state)]+=1
   record['actions'][str(action.get('id') if isinstance(action,dict) else None)]+=1
   if isinstance(guid,str):guids.add(guid)
   if type(score)is int:record['public_progress_values'][str(score)]+=1
   if d.get('full_reset') is True:record['resets']+=1
   rr.update({'game_id':gid,'public_state':state,'public_progress':score,'progress_field':'score' if 'score'in d else 'levels_completed' if 'levels_completed'in d else None,'frames':len(frames),'action_id':action.get('id') if isinstance(action,dict) else None,'frame_hashes':[]})
   for phase,f in enumerate(frames):
    if not isinstance(f,list) or not f or not all(isinstance(x,list) and len(x)==len(f[0]) for x in f) or not 1<=len(f)<=64 or not 1<=len(f[0])<=64 or any(type(v)is not int or not 0<=v<=15 for row in f for v in row):
     record['public_frames_validation_errors'].append({'row':rowno,'phase':phase,'error':'frame type/shape/palette invalid'});continue
    rr['frame_hashes'].append(sha(bytes(v for row in f for v in row)))
   record['frames']+=len(frames)
   if previous and guid==previous['guid'] and gid==previous['game_id'] and not d.get('full_reset',False):
    record['same_guid_game_adjacent_pairs']+=1
    old=previous['score']
    if type(old)is int and type(score)is int:
     record['progress_increases']+=score>old;record['progress_decreases']+=score<old
   previous={'guid':guid,'game_id':gid,'score':score}
  except Exception as e:
   record['row_errors'].append({'row':rowno,'offset':rr['offset'],'bytes':len(raw),'type':type(e).__name__,'args':e.args,'traceback':traceback.format_exc()});previous=None
 record['actual_bytes']=offset;record['actual_sha256']=h.hexdigest();record['guid_count']=len(guids)
 return record
for archive in archives:
 ah=hashlib.sha256()
 with archive.open('rb') as f:
  for chunk in iter(lambda:f.read(1048576),b''):ah.update(chunk)
 metadata=None;selected=[];headers=[]
 with tarfile.open(archive,'r|gz') as tf:
  for member in tf:
   if not member.isfile():continue
   headers.append({'member':member.name,'bytes':member.size})
   if member.name in ('manifest.json','MANIFEST.json'):
    assert member.size<4*1048576;metadata=json.load(tf.extractfile(member))
   elif ('/public-recordings/'in member.name and member.name.endswith('.jsonl')) or member.name in ('arc-column-teacher-recovery-20261013/public-recording-v2.jsonl','arc-column-teacher-recovery-20261013/public-recording.jsonl','arc-chain-public-recording-20261013/api_response_v1.body'):
    result=scan_recording(tf.extractfile(member),member,archive);corpora.append(result);selected.append(result)
   elif '/arc-official-fresh-all25-20261013/observation/'in '/'+member.name and member.name.endswith('.public.json'):
    raw=tf.extractfile(member).read();p=json.loads(raw);d=p['model_json'];errs=[]
    for i,fr in enumerate(p['frames']):
     b=base64.b64decode(fr['base64'],validate=True)
     if len(b)!=4096 or sha(b)!=fr['sha256'] or fr['shape']!=[64,64] or fr['dtype']!='|i1' or any(v>15 for v in b):errs.append(i)
    initial.append({'archive':str(archive),'member':member.name,'bytes':len(raw),'sha256':sha(raw),'game_id':d['game_id'],'levels_completed':d['levels_completed'],'win_levels':d['win_levels'],'state':d['state'],'available_actions':d['available_actions'],'frames':len(p['frames']),'frame_validation_errors':errs})
 entries=metadata.get('entries',metadata.get('files',metadata.get('source_entries',[])));index={x.get('path',x.get('member')):x for x in entries}
 for c in selected:
  pin=index.get(c['member']);c['manifest_pin']=pin;c['member_hash_verified']=bool(pin and pin['bytes']==c['actual_bytes'] and pin['sha256']==c['actual_sha256'])
 for c in initial:
  if c['archive']==str(archive):
   pin=index.get(c['member']);c['member_hash_verified']=bool(pin and pin['bytes']==c['bytes'] and pin['sha256']==c['sha256'])
 archives_checked.append({'path':str(archive),'bytes':archive.stat().st_size,'sha256':ah.hexdigest(),'metadata_index_entries':len(entries),'header_entries':len(headers),'raw_candidates':[x for x in headers if any(w in x['member'].lower() for w in ('recording','corpus','5112','first_action','trajectory'))]})
put('reports/public_corpora.json',corpora);put('reports/saved_initials.json',initial);put('reports/archive_scan.json',archives_checked)
# Report only verified public material, never hidden-change aggregate as a runtime predicate.
bygame={};known=prior['既知解']['records'];levelrows=levels['レベル索引']
for game in prior['ゲーム機構']:
 gid=game['ゲームID'];ag=prior['作用実測'].get(gid,{});cs=[x for x in corpora if any(k.split('-')[0]==gid for k in x['game_ids'])];init=[x for x in initial if x['game_id'].split('-')[0]==gid];uniq={x['sha256']:x for x in init}
 bygame[gid]={'base_game_id':gid,'versioned_prior_game_id':game['公式game_id'],'indexed_levels':sum(x[0]==gid for x in levelrows),'prior_action_ids':game['作用ID'],'aggregate_first_action_count':sum(x[0] for x in ag.values()),'aggregate_status_counts':dict(sum((collections.Counter(x[4]) for x in ag.values()),collections.Counter())),'aggregate_hidden_rates':'present but measurement provenance unavailable; excluded from runtime knowledge','raw5112_record_join':'not available in verified prior or surveyed corpus indexes','known_success_records':[{'level':x['レベル'],'length':x['長さ'],'historical_reproduced_flag':x['再現'],'before_after_witness':'not joined; sequence only, not runtime policy'} for x in known if x['ゲームID']==gid],'saved_initial_observations':[{'member':x['member'],'sha256':x['sha256'],'frames':x['frames'],'level_position':'levels_completed=0; initial only','manifest_verified':x['member_hash_verified']} for x in uniq.values()],'public_corpora':[{'member':x['member'],'rows':x['rows'],'frames':x['frames'],'sha256':x['actual_sha256'],'verified':x['member_hash_verified'],'parse_errors':len(x['row_errors']),'progress_values':x['public_progress_values'],'action_counts':x['actions'],'state_counts':x['states'],'prior5112_identity_join':False} for x in cs],'per_level_raw_coverage':'only initial observation level position verified; corpus score is not silently mapped to prior level IDs','HOLD':'not present as an environment field; native/pure HOLD evidence separate','causality':'public temporal adjacency only until predicate/witness/applicability joins established'}
put('reports/coverage_by_game.json',{'games':list(bygame.values()),'scope':'IDs only for indexes/provenance; not runtime route','raw_corpus_overlap':'old truncated column corpus is a preserved prefix/alternate artifact; do not sum it as independent evidence'})
lev=[]
for x in levelrows:
 lev.append({'game_id':x[0],'level':x[1],'action_ids':x[2],'baseline_actions':x[3],'board_dimensions_prior_only':x[4],'sprite_count_prior_only':x[5],'full_object_role_relation_record':'absent in prior','first_action_raw_join':'unavailable','saved_initial_position':x[1]==1,'known_success_sequence_record':any(k['ゲームID']==x[0] and k['レベル']==x[1] for k in known),'fresh_current_success':None,'causal_teacher_chain':'see per-game verified corpora; score-to-level mapping not assumed'})
put('reports/coverage_by_level.json',lev)
summary={'games':len(bygame),'levels':len(lev),'aggregate_action_count':sum(g['aggregate_first_action_count'] for g in bygame.values()),'known_sequence_records':len(known),'corpora':len(corpora),'all_corpus_hashes_match':all(x['member_hash_verified'] for x in corpora),'initial_unique_packets':len({x['sha256'] for x in initial}),'initial_unique_frames':sum(x['frames'] for x in {x['sha256']:x for x in initial}.values()),'raw5112_joined':0,'raw5112_unavailable_not_zero_measurements':True,'parse_failures':[{'member':x['member'],'errors':x['row_errors']} for x in corpora if x['row_errors']],'AS':resource.getrlimit(resource.RLIMIT_AS),'RSS_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
put('reports/summary.json',summary);print(json.dumps({k:v for k,v in summary.items() if k!='parse_failures'},ensure_ascii=False));print([(x['member'],dict(x['game_ids']),x['rows'],x['frames'],len(x['row_errors'])) for x in corpora])
