import pathlib,json,hashlib,os,sys,time,resource,signal,logging,http.client,shutil,re
logging.disable(logging.CRITICAL)
http.client.HTTPConnection.debuglevel=0
resource.setrlimit(resource.RLIMIT_AS,(134217728,134217728))
resource.setrlimit(resource.RLIMIT_CPU,(30,30))
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
ROOT=pathlib.Path(__file__).resolve().parent
A=ROOT.parent/'arc-official-availability-20261013'
C=ROOT.parent/'arc-chain-public-recording-20261013'
START=time.monotonic(); KEY=None; rows=[]; request_count=0
def stamp():return time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
def size(path):return sum(p.stat().st_size for p in path.rglob('*') if p.is_file())
def check():
    if time.monotonic()-START>=900:raise TimeoutError('wall')
    if size(C)>100663296:raise RuntimeError('C_cap')
    if shutil.disk_usage(ROOT).free<1321205760:raise RuntimeError('disk_floor')
    mem=int(next(x.split()[1] for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
    if mem<2147483648:raise RuntimeError('memory_floor')
    if size(ROOT)>66060288:raise RuntimeError('failure_reserve')
def put(name,data,evidence=True):
    if not isinstance(data,bytes):data=(json.dumps(data,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()
    if KEY and KEY.encode() in data:raise RuntimeError('credential_in_payload')
    if size(ROOT)+len(data)>67108864:raise RuntimeError('scope_cap')
    p=ROOT/name
    if p.exists():raise RuntimeError('immutable_path')
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
    return {'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def timeout(s,f):raise TimeoutError('deadline')
signal.signal(signal.SIGALRM,timeout);signal.signal(signal.SIGXCPU,timeout)
def get(path,cap,auth=False):
    global request_count
    import requests
    check();request_count+=1
    report={'endpoint':path,'started':stamp(),'state':'started'}
    put('request-%02d-start.json'%request_count,report)
    headers={'Accept':'application/json'}
    if auth:headers['X-Api-Key']=KEY
    signal.setitimer(signal.ITIMER_REAL,max(.01,min(25,900-(time.monotonic()-START))))
    try:
        with requests.get('https://three.arcprize.org'+path,headers=headers,stream=True,allow_redirects=False,timeout=(10,25)) as response:
            report['status']=response.status_code
            report['content_type']=response.headers.get('Content-Type','').split(';')[0][:128]
            if response.status_code!=200:raise RuntimeError('http_non_200')
            if path.endswith('/source') and report['content_type'] not in ('text/plain','text/x-python','application/x-python','application/octet-stream'):raise RuntimeError('source_media_type')
            chunks=[];n=0
            for chunk in response.iter_content(16384):
                n+=len(chunk)
                if n>cap:raise RuntimeError('response_cap')
                chunks.append(chunk)
            data=b''.join(chunks)
        report.update({'state':'received','bytes':len(data),'finished':stamp()})
        if path.endswith('/source'):report['sha256']=hashlib.sha256(data).hexdigest()
        return data,report
    except Exception as e:
        report.update({'state':'failed','error_type':type(e).__name__,'finished':stamp()})
        raise
    finally:
        signal.setitimer(signal.ITIMER_REAL,0)
        put('request-%02d-result.json'%request_count,report)
receipt={'schema':'official-opaque-bundles-receipt-v1','started':stamp(),'source_imports':0,'make_calls':0,'reset_calls':0,'HDS_calls':0,'game_actions':0,'credential_persisted':False}
exitcode=1
try:
    check()
    pins=json.loads((ROOT/'availability-pins.json').read_text())
    def verify_inputs():
        for name,pin in pins.items():
            data=(A/name).read_bytes()
            if len(data)!=pin['bytes'] or hashlib.sha256(data).hexdigest()!=pin['sha256']:raise RuntimeError('availability_changed')
    verify_inputs()
    joins=json.loads((A/'comparison-all25.json').read_text())
    for i,j in enumerate(joins):
        rows.append({'index':i,'game_id':j['live_game_id'],'state':'not_attempted','runtime_rule_applicability':'unverified'})
    if len(rows)!=25:raise RuntimeError('target_count')
    put('targets-before.json',rows)
    raw,_=get('/api/games/anonkey',65536)
    obj=json.loads(raw)
    if not isinstance(obj,dict) or set(obj)!={'api_key'} or not isinstance(obj['api_key'],str) or not obj['api_key']:raise RuntimeError('auth_contract')
    KEY=obj['api_key'];obj=None;raw=None
    source_total=0;metadata_total=0
    for row in rows:
        try:
            check()
            gid=row['game_id']
            if not re.fullmatch(r'[a-z0-9]{4}-[a-z0-9]+',gid):raise RuntimeError('game_path')
            base,version=gid.split('-',1)
            metadata=json.loads((A/('detail-%02d.json'%row['index'])).read_text())
            if metadata.get('game_id')!=gid:raise RuntimeError('metadata_version')
            klass=metadata.get('class_name') or base[0].upper()+base[1:]
            if not isinstance(klass,str) or not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*',klass):raise RuntimeError('class_path')
            prefix='environment_files/'+base+'/'+version+'/'
            target=ROOT/prefix
            if not target.resolve().is_relative_to(ROOT):raise RuntimeError('path_escape')
            row['class_name']=klass;row['class_name_origin']='metadata' if metadata.get('class_name') else 'SDK default capitalization'
            data,transport=get('/api/games/'+gid+'/source',2097152,True)
            data.decode('utf-8',errors='strict')
            if not data:raise RuntimeError('empty_source')
            if source_total+len(data)>52428800:raise RuntimeError('source_total')
            metadata.update({'local_dir':str(target),'date_downloaded':stamp(),'class_name':klass})
            metadata.setdefault('tags',[]);metadata.setdefault('baseline_actions',[])
            md=(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n').encode()
            if metadata_total+len(md)>2097152:raise RuntimeError('metadata_total')
            row['source']=put(prefix+klass.lower()+'.py',data,False)
            source_total+=len(data)
            row['metadata']=put(prefix+'metadata.json',md)
            metadata_total+=len(md)
            row['transport']=transport;row['utf8_valid']=True;row['state']='obtained_opaque'
            data=None
        except Exception as e:
            row['state']='failed';row['error_type']=type(e).__name__
        put('result-%02d.json'%row['index'],row)
        if time.monotonic()-START>=900:break
    verify_inputs()
    put('all25-results.json',rows)
    receipt.update({'state':'completed','targets':25,'obtained':sum(r['state']=='obtained_opaque' for r in rows),'failed':sum(r['state']=='failed' for r in rows),'not_attempted':sum(r['state']=='not_attempted' for r in rows),'source_bytes':source_total,'metadata_bytes':metadata_total,'availability_unchanged':True})
    exitcode=0 if receipt['obtained']==25 else 2
except Exception as e:
    receipt.update({'state':'failed','error_type':type(e).__name__})
    put('partial-results.json',rows)
finally:
    signal.setitimer(signal.ITIMER_REAL,0)
    receipt.update({'finished':stamp(),'duration_seconds':round(time.monotonic()-START,3),'process_exit_requested':exitcode,'request_count':request_count})
    put('receipt.json',receipt)
    put('file-manifest.json',[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(ROOT.rglob('*')) if p.is_file()])
    KEY=None
print(json.dumps(receipt,ensure_ascii=False,sort_keys=True))
sys.exit(exitcode)
