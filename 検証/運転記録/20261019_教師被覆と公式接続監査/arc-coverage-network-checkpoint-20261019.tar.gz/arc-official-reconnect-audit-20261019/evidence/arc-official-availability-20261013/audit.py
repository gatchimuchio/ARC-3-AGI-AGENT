import json, pathlib, hashlib, os, sys, time, logging, resource, signal, shutil, re, http.client
logging.disable(logging.CRITICAL)
http.client.HTTPConnection.debuglevel = 0
resource.setrlimit(resource.RLIMIT_AS, (134217728,134217728))
resource.setrlimit(resource.RLIMIT_CORE, (0,0))
resource.setrlimit(resource.RLIMIT_CPU, (30,30))
ROOT=pathlib.Path(__file__).resolve().parent
C=ROOT.parent/'arc-chain-public-recording-20261013'
CAP=4194304
RESERVE=524288
BASE='https://three.arcprize.org'
START=time.monotonic()
KEY=None
requests_log=[]
results=[]
games=[]
phase='preflight'
def stamp():
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
def scope_size():
    return sum(p.stat().st_size for p in ROOT.rglob('*') if p.is_file())
def check():
    cused=sum(p.stat().st_size for p in C.rglob('*') if p.is_file() and not p.is_symlink())
    if cused>100663296: raise RuntimeError('C_cap')
    if shutil.disk_usage(ROOT).free<1254096896: raise RuntimeError('disk_floor')
    available=int(next(l.split()[1] for l in pathlib.Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024
    if available<2147483648: raise RuntimeError('memory_floor')
    if scope_size()>CAP-RESERVE: raise RuntimeError('scope_headroom')
    return {'C_used_bytes':cused,'C_reserved_bytes':100663296,'disk_free_bytes':shutil.disk_usage(ROOT).free,'memory_available_bytes':available}
def put(name, data, emergency=False):
    if not isinstance(data,bytes): data=(json.dumps(data,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode()
    if KEY and KEY.encode() in data: raise RuntimeError('credential_content_blocked')
    target=ROOT/name
    if target.exists(): raise RuntimeError('immutable_output_exists')
    limit=CAP if emergency else CAP-RESERVE
    if scope_size()+len(data)>limit: raise RuntimeError('scope_cap')
    with target.open('xb') as f:
        f.write(data); f.flush(); os.fsync(f.fileno())
    return {'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def halt(signum,frame):
    raise TimeoutError('resource_deadline')
signal.signal(signal.SIGALRM,halt)
signal.signal(signal.SIGXCPU,halt)
signal.alarm(900)
def public_guard(obj):
    if isinstance(obj,dict):
        for key,value in obj.items():
            if re.search(r'api.?key|token|secret|password|credential|authorization|cookie',key,re.I): raise RuntimeError('sensitive_metadata_field')
            public_guard(value)
    elif isinstance(obj,list):
        for value in obj: public_guard(value)
    elif isinstance(obj,str) and KEY and KEY in obj: raise RuntimeError('credential_metadata_value')
def get(path,auth=False):
    import requests
    check()
    record={'path':path,'started':stamp(),'state':'started'}
    requests_log.append(record)
    put('request-%02d-start.json'%len(requests_log),record)
    headers={'Accept':'application/json'}
    if auth: headers['X-Api-Key']=KEY
    try:
        with requests.get(BASE+path,headers=headers,allow_redirects=False,stream=True,timeout=(10,25)) as response:
            record['status']=response.status_code
            if response.status_code!=200: raise RuntimeError('http_non_200')
            chunks=[]; n=0
            for chunk in response.iter_content(4096):
                n+=len(chunk)
                if n>65536: raise RuntimeError('response_cap')
                chunks.append(chunk)
            raw=b''.join(chunks)
        obj=json.loads(raw)
        record.update({'state':'received','bytes':len(raw),'finished':stamp()})
        if path!='/api/games/anonkey':
            public_guard(obj)
            record['sha256']=hashlib.sha256(raw).hexdigest()
        return obj,raw
    except Exception as e:
        record.update({'state':'failed','error_type':type(e).__name__,'finished':stamp()})
        raise
    finally:
        put('request-%02d-result.json'%len(requests_log),record,True)
def join_row(item, prior):
    gid=item['game_id']; base=gid.split('-',1)[0]
    rows=sorted(prior.get(base,[]),key=lambda r:r[1])
    baseline=[r[3] for r in rows]
    live=item.get('baseline_actions')
    return {'base_game_id':base,'live_game_id':gid,'prior_game_id':base if rows else None,'version_comparison':'unknown','version_reason':'pinned prior index has base identifiers only' if rows else 'prior missing','prior_baseline_actions':baseline,'live_baseline_actions':live,'baseline_comparison':'missing' if not rows or not isinstance(live,list) else ('equal' if baseline==live else 'different'),'prior_level_count':len(rows),'live_level_count':len(live) if isinstance(live,list) else None,'runtime_rule_applicability':'unverified','detail_state':'not_attempted'}
exitcode=1
report={'schema':'official-availability-receipt-v1','started':stamp(),'environment_initializations':0,'game_actions':0,'source_downloads':0,'HDS_calls':0,'credential_persisted':False}
try:
    report['preflight']=check()
    index_raw=(ROOT/'prior-index.json').read_bytes(); manifest=json.loads((ROOT/'prior-manifest.json').read_text())
    if hashlib.sha256(index_raw).hexdigest()!=manifest['索引']['SHA256']: raise RuntimeError('prior_digest')
    prior={}
    for row in json.loads(index_raw)['レベル索引']: prior.setdefault(row[0],[]).append(row)
    phase='anonymous_key'
    auth,raw=get('/api/games/anonkey')
    if not isinstance(auth,dict) or set(auth)!={'api_key'} or not isinstance(auth['api_key'],str) or not auth['api_key']: raise RuntimeError('auth_contract')
    KEY=auth['api_key']; auth=None; raw=None
    phase='public_list'
    games,raw=get('/api/games',True)
    if not isinstance(games,list) or len(games)!=25: raise RuntimeError('list_count')
    ids=[i.get('game_id') for i in games]
    if len(set(ids))!=25 or any(not isinstance(i,str) or not re.fullmatch(r'[a-z0-9]{4}-[a-z0-9]+',i) for i in ids): raise RuntimeError('list_ids')
    put('live-games.json',raw)
    results=[join_row(i,prior) for i in games]
    put('join-before-details.json',results)
    phase='public_details'
    for i,row in enumerate(results):
        try:
            detail,raw=get('/api/games/'+row['live_game_id'],True)
            if not isinstance(detail,dict): raise RuntimeError('detail_shape')
            put('detail-%02d.json'%i,raw)
            row['detail_state']='obtained'
            row['detail_game_id']=detail.get('game_id')
            row['detail_baseline_actions']=detail.get('baseline_actions')
            row['detail_id_matches_list']=detail.get('game_id')==row['live_game_id']
            row['detail_baseline_matches_list']=detail.get('baseline_actions')==row['live_baseline_actions']
        except Exception as e:
            row['detail_state']='failed'; row['detail_error_type']=type(e).__name__
        put('join-result-%02d.json'%i,row,True)
    for row in results:
        if row['base_game_id']=='sk48':
            row['separate_public_teacher_comparison']={'teacher_game_id':'sk48-41055498','live_game_id':row['live_game_id'],'version_comparison':'equal' if row['live_game_id']=='sk48-41055498' else 'different','source':'Parent task statement 2026-10-13','runtime_rule_applicability':'unverified'}
    put('comparison-all25.json',results)
    report.update({'state':'completed','game_count':len(results),'prior_level_count':sum(len(v) for v in prior.values()),'live_level_count':sum(len(i['baseline_actions']) for i in games),'detail_success':sum(r['detail_state']=='obtained' for r in results),'version_unknown':sum(r['version_comparison']=='unknown' for r in results),'baseline_equal':sum(r['baseline_comparison']=='equal' for r in results),'baseline_different':sum(r['baseline_comparison']=='different' for r in results)})
    exitcode=0 if report['detail_success']==25 else 2
except Exception as e:
    report.update({'state':'failed','phase':phase,'error_type':type(e).__name__})
    put('partial-results.json',results,True)
finally:
    signal.alarm(0)
    report['finished']=stamp();report['duration_seconds']=round(time.monotonic()-START,3)
    report['process_exit_requested']=exitcode;report['requests']=requests_log
    report['scope_bytes_before_receipt']=scope_size()
    try:
        put('receipt.json',report,True)
        put('file-manifest.json',[{'path':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(ROOT.iterdir()) if p.is_file()],True)
    except Exception as e:
        print(json.dumps({'receipt_write_error_type':type(e).__name__}));exitcode=3
    KEY=None
print(json.dumps({k:v for k,v in report.items() if k!='requests'},ensure_ascii=False,sort_keys=True))
sys.exit(exitcode)
