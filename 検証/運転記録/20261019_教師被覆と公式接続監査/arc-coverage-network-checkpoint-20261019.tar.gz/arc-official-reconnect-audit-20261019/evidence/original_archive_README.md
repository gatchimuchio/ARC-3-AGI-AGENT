# 公式接続復旧と公開鎖原票165相 checkpoint（2026-10-13）

## 目的
公開サンプルの規則・目的から操作教師を整理するため、公開原票への接続と公式SDKの初期観測経路を復旧し、その一次証拠を保存する。

## 収録と境界
C（arc-chain-public-recording-20261013）全体には公開原票、復旧source、純fixture、全165相の測定・独立監査・全失敗を収録。独立監査は全8原票行・全相・候補と重複・型順・unknown保持をPASSした。ただし固定prior知覚そのもののゲーム意味は独立実証していない。旧46教師との正確な対応と完成ラベルの由来は未証明（teacher_provenance_proved=false）。成功Actionであっても応答相ごとの状態差を落とさず、終端や成功だけから全途中の教師を補完しない。今回これをHDSへ新規教示していない。

availability全体、初回fresh scope全体（旧v3 FAIL含む）、全25fresh scope全体を収録。rootの25起動/25 actualexit0とは別に、独立監査PASSも収録した。25の一意GUID、27初期frames、全levels_completed=0、metadata win_levels総183。通常Action0、追加RESET0、HDS0。これは25初期可用性であり183レベル攻略ではない。新規clear0、runtime solver採用0。

初回v3はsocket.__new__拒否後にFAILした。実make到達は記録不足のため不明のまま。v4以降はsocket object生成のみ許し、通信bind/DNS/connect/send等は拒否。固定urllib3能力probeのbind拒否だけを実stack/版SHAで識別し非致命診断として保存する。全25に各1件の当該診断、cache mkdir FileExistsError計50recordを保存。PASSは初期公開観測取得と永続化の範囲であり、全SDK_IO失敗0の主張ではない。cache/tmpは再生成可能補助物で個別fsync保証なし。公開packet/失敗記録は独立読戻しの対象。

全25独立監査初回は報告容量assertで停止し、後続保存版に初回失敗工具を保持した。元観測を書き換えず、全SDK_IO原票は各receipt exactRef/JSONpathで参照する。

## 公式ゲームsource除外
公式bundleについてmetadata/log/script/manifestは収録するが、environment_files配下ゲーム.py25本の本文を一切収録しない。本文の読解も行わない。excluded_game_sources.jsonに各bytes/SHA256/公式URL/版と除外を保持。元manifest内のsource参照は取得証拠であって、このarchiveに本文が入っているという意味ではない。SDK版arc-agi0.9.9/arcengine0.9.3、公開FrameDataRaw全fieldとnumpy dtype/shape/bytesの保存を用いた。

opaque stdout/stderrは原bytesのまま収録し、内容を表示・意味解析していない。ゲーム内部/evaluator/hidden stateの解法利用は禁止。匿名keyはSDKprocessへ持ち込まず、通信・subprocess拒否のPython境界を記録する。これは任意native syscallに対するOS sandbox証明ではない。

## previous / current / delta / regression
previous: 旧環境資産の不在と公式初期接続未検証。current: 公開鎖原票の165全相証拠と公式25初期観測を保存・独立確認。delta: 接続可用性と記録完全性の復旧。能力差として旧Goal6/Paintingとの異条件比較はしない。先頭ar25は初回v4との全frame/公開意味状態回帰を確認し、GUID等fresh識別子差を別保存した。通常Actionによる攻略・未見転用・因果規則学習はこのcheckpointで実行していない。

## 既存checkpoint参照
Goal6学習と6教示例Query回帰の既存goal6-query-checkpoint.tar.gzは再重複しない。bytes862122、SHA256 483d69377cd9c82743e86e7c54b41b2bbb65fa615cc0dc89aedf34159a8c1500。今回の成果と成立範囲を混同しない。

## 完全性
manifest.jsonの全regular member順序・集合・bytes/SHAと元file identityを固定する。archive全memberを元bytesと再比較し、型・順序・集合一致とgzip全stream終端を確認する。source本文除外25件は別一覧。失敗artifact・旧版を削除せず収録し、部分archive失敗時も削除しない。
