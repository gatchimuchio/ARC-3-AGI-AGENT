import hashlib,json,tarfile,resource
from pathlib import Path
R=Path(__file__).resolve().parent;B=R.parent
A=B/'arc-preservation-recovery-20261019/remaining/official-connection-checkpoint-sanitized-20261016.tar.gz'
receipt=json.loads((A.parent/'remaining_origin_official_derivative.json').read_text());raw=A.read_bytes();assert len(raw)==receipt['output']['bytes'] and hashlib.sha256(raw).hexdigest()==receipt['output']['sha256']
wanted=['arc-official-availability-20261013/'+n for n in ['contract.json','live-games.json','prior-index.json','comparison-all25.json','audit.py']]+['arc-official-fresh-all25-20261013/prep/'+n for n in ['fresh_all25_contract_v1.json','fresh_all25_v1.py','all25_independent_audit.json']]+['arc-official-bundles-20261013/'+n for n in ['contract.json','availability-pins.json']]
items={};manifest=None
with tarfile.open(A,'r|gz') as tf:
 for m in tf:
  if m.name in wanted or m.name=='manifest.json':
   assert m.isfile() and m.size<1024*1024
   data=tf.extractfile(m).read(1024*1024)
   if m.name=='manifest.json':manifest=json.loads(data)
   else:items[m.name]=data
index={x['member']:x for x in manifest['source_entries']};records=[]
for name,data in items.items():
 x=index[name];assert len(data)==x['bytes'] and hashlib.sha256(data).hexdigest()==x['sha256'];p=R/'evidence'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);records.append(x)
metadata=[]
for d in sorted((B/'arc-sdk-venv/lib/python3.12/site-packages').glob('*.dist-info')):
 p=d/'METADATA'
 if p.exists():
  data=p.read_bytes();lines=data.decode().splitlines();fields=[x for x in lines if x.startswith(('Name:','Version:','Requires-Python:','Requires-Dist:','Project-URL:','Home-page:'))]
  record={'path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'fields':fields};metadata.append(record)
  if d.name.startswith(('arc_agi-','arcengine-')):(R/'evidence'/(d.name+'.METADATA')).write_bytes(data)
authority=[]
for p in list((B/'arc-preservation-recovery-20261019/authority').glob('*'))+list((B/'arc-preservation-recovery-20261019/main').rglob('*')):
 if p.is_file():
  b=p.read_bytes();authority.append({'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'reread':True})
report={'archive':receipt['output'],'selected_exact_members':records,'installed_metadata':metadata,'authority':authority,'AS':resource.getrlimit(resource.RLIMIT_AS),'RSS_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'SDK_imports':0,'network_calls':0,'credential_reads':0}
(R/'reports/read_inventory.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print('Verified exact own-source/public-contract members:',len(records),'Installed distributions metadata:',len(metadata))
