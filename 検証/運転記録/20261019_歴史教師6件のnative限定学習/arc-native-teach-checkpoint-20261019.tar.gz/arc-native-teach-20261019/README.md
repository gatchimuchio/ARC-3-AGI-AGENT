# Native teacher pilot preparation (not executed)

Status: HOLD pending independent static growth/guard review, exact regression closure, and parent's explicit execution admission. No native HDS import/restore/save/Query/processing has occurred here. No SDK, live Action, Git write, or HDS change.

## Frozen scope

- Exact external baseline: ../arc-native-query-20261019/query_retry02/poststate.json, 5,355,957 bytes, SHA256 f7e5f8c7518b43c7e53f6a1c43f108469c04f72e5d13eb30aa2fae987e2d6e6a. Counters6660, observations183, principles16. Read-only external source, no additional source copy charged outside reservations.
- Actual frozen HDS v0.4.2 source closure from the Query pilot, all12 Python modules pinned. User's Owner directives, AGENTS, hierarchy, current state and five prior review/contract READMEs reread. Strategy remains null; no automatic transition.
- Six audited historical goal6 teachers (1986bytes), six matched queries (1760bytes), four existing130–133 control queries. Four distinct goal6 conditions, all six rows preserved; FF,false twice; TF,false; FT,false; TT,true twice. No source ID/hash/path enters runtime content.
- Teachers are new to this descendant, not independent new observations. Endpoint public-score progress only; all statuses NOT_FINISHED. Fixed mask/action role prior,77 unknown phases; no continuous preservation, geometry correctness, causal necessity, fresh-instance or generalization claim.
- Planned sequence if all nine exact old-boundary regressions recovered:19 before Queries (6 goal6+4 control+9 regression),6 actual 処理する(外部入力),19 identical after Queries. Exactly44 total,38Query+6processing. No trimming duplicates or failures. Without recovered regression pack, no full-regression/adoption claim.

## Static growth proof

preflight_bound.py is pure source/data analysis, not native learning or replacement persistence. It asserts closed input facts and constructs dominating wire-format record shapes. The exact two inferred leaves and new boundary permit one forward candidate at prefixes3–6, no reverse candidate; forward tables change at3,4,5. No matching old boundary, no counterexample or strict-subset parent means no isolation/reopening branches. Conservatively count54 basic records,12 candidate records,9 adoption records,3 duplicated principle-history records,3 snapshots, and one spare structural unit =82. Each dominates under32768bytes, at record root indentation depth12; max explicit padded record13866bytes. Full-state bound=5,355,957+82*32768=8,042,933bytes <8MiB. This is a proposed analytical bound for independent review, not an observed outcome. Prefix failures cannot append more than completed sequence bound. Query modifies only paired counters (remaining4digits).

## Exact callable and evidence frontier

The original guard was Query-only and31 was packet-specific. This scoped derivative accepts a frozen exact method/native-byte input sequence, permits only 照会する or 処理する, and rejects any mismatch before invocation. It preserves pre-input fsync/readback, isolated decoding, invocation entry counter, returned counter, complete output/post-input capture, mutation test, detached result and latched failure. Processing takes the genuine intake→engine.実行→exhaust route; no synthetic Teach, label substitution or native core edits.

13 pure fixture tests cover exact44-call order, processing entry/return, preentry storage/decode failure, native failure, output encoding/storage/post-input storage failure, mutation, reentry, exact remaining suffix and latch. These are wrapper fixtures only. Native loaded closure/class/method/engine/intake/exhaust/codec binding still needs verification before first real call. Guard review of this derivative is separate from the passed Query-only repair.

## Proposed resource ledger, unchanged96MiB ceiling

512MiB AS,120s CPU/compute deadline,240s wall including failure finalization; no silent increase. Ten single-use8MiB native state reservations (80MiB): normal roundtrip; after19 before-queries; six per-teacher checkpoints; after19 after-queries; partial failure-state. Before each teacher is exactly previous retained checkpoint; no duplicate full save needed. Every original ledger/history prefix and all new support/refutation/principle/delta records can be compared from full checkpoints.

8MiB exact native reply/input evidence;1MiB combined metadata/stdout/stderr;1MiB worker failure;1MiB preencoded worker emergency;1MiB supervisor terminal =92MiB total fixed known-writer reservation. Remaining4MiB covers this preparation's code, exact small inputs, pins and final audit reports; actual aggregate admission measures existing bytes. Reply/input bound and final report budget remain to be closed. No other file writer allowed in child; external frozen state/source remain read-only. Reserved failure regions are disjoint; partial files/extents are retained, never reused.

Native Path.write_text truncates reserved state files;8MiB is a logical RLIMIT bound, not surviving physical preallocation. Free-space admission does not guarantee ENOSPC/I/O/machine-death persistence. Unknown exact frontier is reported UNKNOWN and forbids automatic resumption; inability to retain complete evidence yields HOLD, never successful acquisition or adoption. The worker must not set full_failure_retention_verified true as a claim against arbitrary filesystem failure.
