"""Pure static bound, not a native response or prediction."""
from preflight_bound import *
from collections import Counter
ids=set(s['状態履歴'][-1].values())
active=[x['値'] for x in principles if x['値']['原理識別子'] in ids]
assert len(active)==15
assert all(p['状態']['値']=='適用範囲付き暫定原理' and p['採用状態']['値']=='有効' for p in active)
# Global ambiguity detection really is scanned; uniqueness proves no multi-
# principle group even with empty boundary-specific evidence.
assert max(Counter((p['対象系境界'],p['結果経路']) for p in active).values())==1
assert max(Counter(p['対象系境界'] for p in active).values())==2
fields=('原理識別子','版','関係型','条件経路群','結果経路','適用範囲','親原理参照','改訂理由','除外反証参照群')
projections=[]
for p in active:
 q={k:p[k] for k in fields};q['状態']=p['状態']['値'];q['採用状態']=p['採用状態']['値'];q['除外反証参照群']=list(q['除外反証参照群']);projections.append(q)
new={k:P[k] for k in fields};new['状態']='X'*64;new['採用状態']='X'*64;new['除外反証参照群']=[];projections.append(new)
pred=dict(原理参照=R,結果経路=PATH,予測値=TEXT,条件値群=(TEXT,))
req=dict(結果経路=PATH,不足経路群=(PATH,),原理参照群=(R,),理由=TEXT,未知条件値群=(TEXT,))
# Both possibilities simultaneously is an overbound: max2 relevant old
# principles, max1 new. All result paths uniquely paired, hence no conflict.
reply=dat('外部出力',状態=TEXT,内容=dict(学習成立状態=TEXT,現在状態版=999999,予測群=[pred]*2,競合群=[],追加観測要求群=[req]*2,識別不能群=[],有効原理群=projections,係争中原理群=[],断定保留理由群=[TEXT]*6),追跡情報=dict(経験参照=R,照会参照=R,対象系境界='B'*512,学習判定=TEXT,台帳件数={k:999999 for k in s['台帳']}))
replybound=size_at_depth(reply,0)
assert replybound<65536,replybound
result={'native_calls':0,'active_old_principles':15,'active_after_max':16,'global_ambiguity_group_max':1,'matching_boundary_principles_max':2,'external_output_upper_bound_bytes':replybound,'reserved_per_reply_bytes':65536,'input_bound_pending_exact_regression':True,'max44_replies_bytes':44*65536,'evidence_reservation_bytes':8*1024**2,'not_actual_native_output':True}
(ROOT/'static_reply_bound.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,indent=2))
