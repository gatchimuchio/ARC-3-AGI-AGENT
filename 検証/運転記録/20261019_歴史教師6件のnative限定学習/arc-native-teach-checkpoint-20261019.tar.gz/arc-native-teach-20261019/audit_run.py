"""Post-run read-only native-wire audit; never imports or calls HDS."""
import json,pathlib,hashlib,resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
from read_run import records
R=pathlib.Path(__file__).resolve().parent

def dec(x):
 if isinstance(x,list):return [dec(v) for v in x]
 if isinstance(x,dict):
  if '__辞書__' in x:return {dec(k):dec(v) for k,v in x['__辞書__']}
  if '__組__' in x:return tuple(dec(v) for v in x['__組__'])
  return {k:dec(v) for k,v in x.items()}
 return x

def audit():
 run=R/'run01';rr=records(run/'evidence.reserve');data={m['name']:dec(json.loads(b)) for m,b in rr}
 config=json.loads((R/'proposed_config.json').read_bytes())
 outputs=[]
 for i,row in enumerate(config['plan'],1):
  method=row['method'];key=f'{i:02d}.{method}'
  inp=data[key+'.input'];after=data[key+'.input_after'];assert inp==after
  assert inp['__データ型__']=='外部入力' and inp['値']==row['input']
  out=data[key+'.output'];assert out['__データ型__']=='外部出力';outputs.append(out['値'])
 assert len(outputs)==44
 baseline=dec(json.loads((R.parent/'arc-native-query-20261019/query_retry02/poststate.json').read_bytes()))
 snapshots=[];last=baseline
 names=['normal_state','before_state']+[f'teach_{i:02d}_state' for i in range(1,7)]+['post_state']
 for name in names:
  path=run/(name+'.reserve');b=path.read_bytes();cur=dec(json.loads(b))
  for old in (baseline,last):
   for k,v in old['台帳'].items():assert cur['台帳'][k][:len(v)]==v
   for k,v in old['原理履歴'].items():assert cur['原理履歴'][k][:len(v)]==v
   assert cur['状態履歴'][:len(old['状態履歴'])]==old['状態履歴']
  snapshots.append({'name':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'counts':{k:len(v) for k,v in cur['台帳'].items()},'counters':cur['識別子状態'],'state_history_count':len(cur['状態履歴']),'principle_histories':{k:len(v) for k,v in cur['原理履歴'].items()}})
  last=cur
 final=last
 delta={'all_original_prefixes_unchanged':True,'ledger_appends':{k:v[len(baseline['台帳'].get(k,())):] for k,v in final['台帳'].items()},'principle_history_appends':{k:v[len(baseline['原理履歴'].get(k,[])):] for k,v in final['原理履歴'].items()},'state_history_appends':final['状態履歴'][len(baseline['状態履歴']):],'counters_before':baseline['識別子状態'],'counters_after':final['識別子状態']}
 def relevant(o):
  content=o['内容']
  return {k:content[k] for k in ('予測群','競合群','追加観測要求群','識別不能群','係争中原理群','断定保留理由群','学習成立状態')}|{'状態':o['状態']}
 target='公開進捗が増加';teachers=json.loads((R.parent/'arc-teacher-contrasts-20261019/goal6_teachers.runtime.json').read_bytes());goal=[]
 for i,t in enumerate(teachers):
  before=outputs[i];after=outputs[25+i]
  predicted=[p['予測値'] for p in after['内容']['予測群'] if tuple(p['結果経路'])==(target,)]
  goal.append({'row':i,'input':config['plan'][i]['input'],'teacher_outcome':t['内容'][target],'before':relevant(before),'after':relevant(after),'matching_single_prediction':predicted==[t['内容'][target]]})
 regression=[]
 for i in range(6,19):
  a,b=outputs[i],outputs[25+i]
  ap=a['内容']['有効原理群'];bp=b['内容']['有効原理群']
  regression.append({'query_ordinal':i+1,'category':'four_control' if i<10 else 'nine_boundary_smoke','condition':config['plan'][i]['input'],'relevant_output_equal':relevant(a)==relevant(b),'before':relevant(a),'after':relevant(b),'old_active_principle_projection_prefix_equal':bp[:len(ap)]==ap,'global_active_principles_added':bp[len(ap):],'state_version_before':a['内容']['現在状態版'],'state_version_after':b['内容']['現在状態版'],'trace_before':a['追跡情報'],'trace_after':b['追跡情報']})
 report={'status':'AUDITED_NATIVE_RESULTS','native_calls':44,'queries':38,'processing':6,'snapshots':snapshots,'goal6_same_condition_results':goal,'teacher_replies':[{'ordinal':i+1,'full_output':outputs[19+i]} for i in range(6)],'old_boundary_smoke_results':regression,'all_original_ledger_history_prefixes_unchanged':True,'all_goal6_teacher_predictions_match':all(x['matching_single_prediction'] for x in goal),'all13_smoke_relevant_outputs_equal':all(x['relevant_output_equal'] for x in regression),'limitations':['six historical observations new only to descendant','same four training conditions, not held-out generalization','fixed geometry and role prior;77 unknown phases','endpoint score progress, no full-game success','13 old-control/boundary smoke rows, not full prior-success regression','no SDK/liveAction/adoption']}
 files={'native_full_delta.json':json.dumps(delta,ensure_ascii=False,indent=2).encode(),'result_audit.json':json.dumps(report,ensure_ascii=False,indent=2).encode()}
 assert sum(map(len,files.values()))<=3*1024**2,'bounded reports exceeded; full source checkpoints retained'
 existing=sum(p.stat().st_size for p in R.rglob('*') if p.is_file())
 assert existing+sum(map(len,files.values()))<=96*1024**2
 for name,b in files.items():
  with (R/name).open('xb') as f:f.write(b)
 print(json.dumps({k:report[k] for k in ('native_calls','queries','processing','all_original_ledger_history_prefixes_unchanged','all_goal6_teacher_predictions_match','all13_smoke_relevant_outputs_equal')},indent=2))
if __name__=='__main__':audit()
