# Package import-attribute correction review

BOUNDED STATIC/PURE PASS for the narrow retry binding patch. No native retry is admitted or performed by this review. Initial run01 remains retained.

## Diagnosis

The persisted first-attempt failure says unexpected native module global during initialization, with entered/returned/fully-persisted counts all zero and empty call evidence. Its message omitted the offending name, so the exact offending original attribute cannot be recovered from that message alone. Static package source and an independent synthetic importlib reproduction show the defect: importing symbols from a submodule also attaches that module, including transitive submodules, to the root package. Those legitimate module attribute names are absent from the original AST declaration set.

## Narrow correction

The retry helper admits only direct child names from the exact twelve-module closure on the root package. Values must be module objects, identical to their sys.modules entry, with exact qualified name, pinned root path and source hash. All other globals still fail the existing gate. A foreign module with the same apparent name/path is rejected; this is not a blanket module exemption. The gate now reports module name, global name, value type and source path for unexpected globals. The caller, storage guard and native core are unchanged.

Independent tests execute the actual globals-gate AST prefix against synthetic module fixtures. Five cases cover accepted legitimate child, foreign same-name/path identity, unknown module with exact diagnostic details, module injected on a nonpackage, and wrong child path. All 25 earlier independent tests pass against the retry derivative. The 13 Guard and eight new supplied attribute tests also pass: 51 total tests under 512 MiB. These are wrapper/static checks, not native bootstrap observations.

The original run01 file sizes and hashes were captured before the patch and independently rechecked afterward. No old run or old source was modified by this reviewer. Original and retry manifests are separate.

## Admission limits

Actual native bootstrap remains untested after this patch and may still HOLD. Exact plan/input/source pins must be finalized before any separately admitted retry. Previous evidence-retention, UNKNOWN frontier, no automatic resume, narrow smoke regression and no runtime viability limitations remain unchanged.

The original 92 MiB reservations remain allocated. A separate retry's 96 MiB per-directory ceiling does not imply a 96 MiB aggregate bound across both trees. Parent must explicitly account for retained original bytes plus retry reservations before admitting another native execution.
