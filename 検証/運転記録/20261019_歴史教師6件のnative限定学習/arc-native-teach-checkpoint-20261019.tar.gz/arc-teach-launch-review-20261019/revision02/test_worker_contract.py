"""Replace load_native bootstrap and save sink with mock objects; no native import/call."""
import ast,sys,pathlib,json,copy,hashlib,resource,unittest,tempfile
from unittest.mock import patch
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
sys.dont_write_bytecode=True
ROOT=pathlib.Path('arc-native-teach-retry-20261019').resolve();sys.path.insert(0,str(ROOT))
import bounded_store as bs, binding
BASE=pathlib.Path('arc-teach-launch-review-20261019').resolve()
import launcher
ns=vars(launcher)
class Store:
 def __init__(self):self.rows=[];self.fail=None
 def append(self,r,n,b):
  if self.fail and self.fail(r,n):raise OSError('injected record write')
  self.rows.append((r,n,b));return {}
 def prepare_emergency(self,b):return b
 def raw_emergency(self,b):self.rows.append(('worker_emergency','raw',b))
class Tests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(dir=BASE);self.path=pathlib.Path(self.tmp.name);self.store=Store();self.saved=[];self.entered=[];self.mode='normal';self.nteach=0
  self.state={'台帳':{'観測台帳':list(range(183))},'状態履歴':[{}],'原理履歴':{},'識別子状態':{'照会':1,'学習判定':1}}
  def wire(x):return json.dumps(x,ensure_ascii=False,indent=2).encode()
  self.wire=wire;(self.path/'baseline').write_bytes(wire(self.state));ns['STATE']=self.path/'baseline'
  owner=self
  class Machine:
   @classmethod
   def 読み込む(cls,path):return cls()
   def 照会する(self,x):
    owner.entered.append('Q');owner.state['識別子状態']['照会']+=1;owner.state['識別子状態']['学習判定']+=1
    if owner.mode=='query_mutation':owner.state['台帳']['観測台帳'].append('unexpected')
    return x
   def 処理する(self,x):
    owner.entered.append('T');owner.nteach+=1;owner.state['台帳']['観測台帳'].append(x)
    if owner.mode=='interrupt' and owner.nteach==2:raise KeyboardInterrupt('mid Teach')
    if owner.mode=='prefix':owner.state['台帳']['観測台帳'][0]='changed'
    return x
   def 保存する(self,path):pass
  class Sink:
   def __init__(self,s):pass
   def save(self,region,*a,**kw):
    owner.saved.append(region);p=owner.path/region;p.write_bytes(wire(owner.state))
    if owner.mode=='save' and region=='teach_02_state':p.write_bytes(b'partial');raise OSError('save interrupted')
    if owner.mode=='readback' and region=='teach_02_state':p.write_bytes(b'{bad')
    return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
  ns['NativeSaveSink']=Sink;ns['load_native']=lambda:(Machine(),lambda **kw:kw,wire,json.loads,(self.path/'baseline').read_bytes(),copy.deepcopy(self.state))
  self.patch=patch.object(binding,'verify',lambda *a:True);self.patch.start()
  q=[{'method':'照会する','input':{'n':i}} for i in range(19)];t=[{'method':'処理する','input':{'t':i}} for i in range(6)]
  self.config={'plan':q+t+copy.deepcopy(q),'pins':{},'state_upper_bound_bytes':8*1024**2}
 def tearDown(self):self.patch.stop();self.tmp.cleanup()
 def runworker(self):ns['worker'](self.store,self.config)
 def failure(self):return json.loads(next(b for r,n,b in self.store.rows if n=='failure'))
 def test_normal_exact_sequence_and_checkpoints(self):
  self.runworker();self.assertEqual(self.entered,['Q']*19+['T']*6+['Q']*19);self.assertEqual(len(self.saved),9)
  self.assertEqual(json.loads(self.store.rows[-1][2])['fully_persisted_calls'],44)
 def test_interrupted_mid_teach_exact_frontier(self):
  self.mode='interrupt'
  with self.assertRaises(KeyboardInterrupt):self.runworker()
  f=self.failure();self.assertEqual((f['native_calls_entered'],f['native_calls_returned'],f['fully_persisted_calls']),(21,20,20));self.assertEqual(self.saved[-1],'failure_state');self.assertEqual(len(self.entered),21)
 def test_save_failure_no_followon(self):
  self.mode='save'
  with self.assertRaises(OSError):self.runworker()
  self.assertEqual(self.failure()['fully_persisted_calls'],21);self.assertEqual(self.saved[-1],'failure_state');self.assertEqual((self.path/'teach_02_state').read_bytes(),b'partial');self.assertEqual(len(self.entered),21)
 def test_corrupt_readback_no_followon(self):
  self.mode='readback'
  with self.assertRaises(json.JSONDecodeError):self.runworker()
  self.assertEqual(len(self.entered),21);self.assertEqual(self.saved[-1],'failure_state')
 def test_query_mutation_holds_before_teach(self):
  self.mode='query_mutation'
  with self.assertRaises(bs.HOLD):self.runworker()
  self.assertEqual(len(self.entered),19)
 def test_prefix_mutation_holds(self):
  self.mode='prefix'
  with self.assertRaises(bs.HOLD):self.runworker()
  self.assertEqual(len(self.entered),20)
 def test_bad_order_no_calls(self):
  self.config['plan'][0]['method']='処理する'
  with self.assertRaises(bs.HOLD):self.runworker()
  self.assertEqual(self.entered,[])
 def test_record_failure_after_return_no_followon(self):
  self.store.fail=lambda r,n:n=='20.処理する.output'
  with self.assertRaises(OSError):self.runworker()
  f=self.failure();self.assertEqual((f['native_calls_entered'],f['native_calls_returned'],f['fully_persisted_calls']),(20,20,19));self.assertEqual(len(self.entered),20)
 def test_preparation_failure_recorded_without_calls(self):
  self.store.prepare_emergency=lambda b:(_ for _ in ()).throw(MemoryError('preparation'))
  with self.assertRaises(MemoryError):self.runworker()
  self.assertEqual(self.entered,[]);self.assertEqual(self.failure()['native_calls_entered'],0)
 def test_encoding_exhaustion_raw_unknown_fallback(self):
  original=ns['json_bytes'];count=0
  def encode(x):
   nonlocal count
   count+=1
   if count>1:raise MemoryError('encoding exhaustion')
   return original(x)
  ns['json_bytes']=encode
  try:
   with self.assertRaises(MemoryError):self.runworker()
  finally:ns['json_bytes']=original
  self.assertEqual(self.entered,[])
  self.assertEqual(json.loads(self.store.rows[-1][2])['frontier'],'UNKNOWN')
if __name__=='__main__':unittest.main(verbosity=2)
