import pathlib,tempfile,importlib,sys,ast,json,hashlib,resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2);sys.dont_write_bytecode=True
base=pathlib.Path(__file__).resolve().parent
with tempfile.TemporaryDirectory(dir=base) as d:
 root=pathlib.Path(d);p=root/'review_synthetic_pkg';p.mkdir();(p/'__init__.py').write_text('from .leaf import C\n');(p/'leaf.py').write_text('from .nested import D\nclass C: pass\n');(p/'nested.py').write_text('class D: pass\n');sys.path.insert(0,d)
 m=importlib.import_module('review_synthetic_pkg')
 report={'synthetic_only':True,'package_public_names':sorted(k for k in vars(m) if not k.startswith('__')),'attached_leaf_identity':m.leaf is sys.modules['review_synthetic_pkg.leaf'],'attached_transitive_identity':m.nested is sys.modules['review_synthetic_pkg.nested'],'native_imports':0}
 assert report['package_public_names']==['C','leaf','nested'];assert report['attached_leaf_identity'] and report['attached_transitive_identity']
 print(json.dumps(report,indent=2));sys.path.remove(d)
 for name in list(sys.modules):
  if name.startswith('review_synthetic_pkg'):del sys.modules[name]
root=base.parent.parent/'arc-native-teach-20261019'
manifest={}
for p in sorted((root/'run01').glob('*')):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 manifest[p.name]={'bytes':p.stat().st_size,'sha256':h.hexdigest()}
(base/'retained_run01_before_patch.json').write_text(json.dumps(manifest,indent=2))
