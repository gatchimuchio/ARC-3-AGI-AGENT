"""Execute exact globals-gate AST prefix with synthetic modules only."""
import pathlib,sys,ast,types,hashlib,resource,tempfile,unittest
from unittest.mock import patch
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2);sys.dont_write_bytecode=True
ROOT=pathlib.Path('arc-native-teach-retry-20261019').resolve();sys.path.insert(0,str(ROOT));import binding
source=ast.parse((ROOT/'binding.py').read_text());verify=next(n for n in source.body if isinstance(n,ast.FunctionDef) and n.name=='verify');loop=next(n for n in verify.body if isinstance(n,ast.For) and isinstance(n.target,ast.Tuple))
end=next(i for i,n in enumerate(loop.body) if isinstance(n,ast.If) and isinstance(n.test,ast.Name) and n.test.id=='unexpected');loop.body=loop.body[:end+1]
fn=ast.FunctionDef(name='gate',args=ast.arguments(posonlyargs=[],args=[ast.arg(arg=n) for n in ('expected_modules','root','HDS_MODULE_PINS')],kwonlyargs=[],kw_defaults=[],defaults=[]),body=[loop],decorator_list=[])
ns=dict(vars(binding));exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])),'synthetic_gate','exec'),ns)
class Tests(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory(dir=pathlib.Path(__file__).resolve().parent);self.root=pathlib.Path(self.t.name)
  self.expected={'hds学習系統':'__init__.py','hds学習系統.子':'子.py'};self.pins={};self.mods={}
  for name,file in self.expected.items():
   p=self.root/file;p.write_text('');self.pins[file]=hashlib.sha256(p.read_bytes()).hexdigest();m=types.ModuleType(name);m.__file__=str(p);self.mods[name]=m
  self.pkg=self.mods['hds学習系統'];self.child=self.mods['hds学習系統.子'];self.pkg.子=self.child;self.p=patch.dict(sys.modules,self.mods);self.p.start()
 def tearDown(self):self.p.stop();self.t.cleanup()
 def gate(self):ns['gate'](self.expected,self.root,self.pins)
 def test_exact_package_child_passes_integrated_gate(self):self.gate()
 def test_foreign_same_name_and_path_rejected(self):
  self.pkg.子=types.ModuleType('hds学習系統.子');self.pkg.子.__file__=self.child.__file__
  with self.assertRaises(binding.HOLD):self.gate()
 def test_unknown_module_reports_exact_details(self):
  self.pkg.foreign=types.ModuleType('foreign');self.pkg.foreign.__file__='/synthetic/foreign.py'
  with self.assertRaises(binding.HOLD) as e:self.gate()
  self.assertEqual(e.exception.args,('unexpected native module global','hds学習系統','foreign','module','/synthetic/foreign.py'))
 def test_module_attribute_on_nonpackage_rejected(self):
  self.child.子=self.child
  with self.assertRaises(binding.HOLD) as e:self.gate()
  self.assertEqual(e.exception.args[1:3],('hds学習系統.子','子'))
 def test_wrong_child_path_rejected(self):
  self.child.__file__='/synthetic/wrong.py'
  with self.assertRaises(binding.HOLD):self.gate()
if __name__=='__main__':unittest.main(verbosity=2)
