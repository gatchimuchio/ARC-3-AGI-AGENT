"""Whole module-validation loop on synthetic Enum/dataclass sources only."""
import sys,pathlib,ast,tempfile,types,hashlib,unittest,resource,enum
from unittest.mock import patch
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2);sys.dont_write_bytecode=True
ROOT=pathlib.Path('arc-native-bootstrap-diagnostic-20261019').resolve();sys.path.insert(0,str(ROOT));import binding
s=ast.parse((ROOT/'binding.py').read_text());v=next(x for x in s.body if isinstance(x,ast.FunctionDef) and x.name=='verify');helper=next(x for x in v.body if isinstance(x,ast.FunctionDef) and x.name=='expected_code');loop=next(x for x in v.body if isinstance(x,ast.For) and isinstance(x.target,ast.Tuple))
fn=ast.FunctionDef(name='gate',args=ast.arguments(posonlyargs=[],args=[ast.arg(arg=n) for n in ('expected_modules','root','HDS_MODULE_PINS')],kwonlyargs=[],kw_defaults=[],defaults=[]),body=[helper,loop],decorator_list=[]);ns=dict(vars(binding));exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])),'synthetic_module_gate','exec'),ns)
class Tests(unittest.TestCase):
 def check(self,source,mutate=None):
  with tempfile.TemporaryDirectory(dir=pathlib.Path(__file__).resolve().parent) as d:
   root=pathlib.Path(d);p=root/'__init__.py';p.write_text(source);m=types.ModuleType('hds学習系統');m.__file__=str(p);exec(compile(source,str(p),'exec'),m.__dict__)
   if mutate:mutate(m)
   with patch.dict(sys.modules,{'hds学習系統':m}):ns['gate']({'hds学習系統':'__init__.py'},root,{'__init__.py':hashlib.sha256(p.read_bytes()).hexdigest()})
 def test_standard_enum_generated_members(self):self.check('from enum import Enum\nclass E(str,Enum):\n a="a"\n')
 def test_enum_foreign_generator_rejected(self):
  with self.assertRaises(binding.HOLD):self.check('from enum import Enum\nclass E(str,Enum):\n a="a"\n',lambda m:setattr(m.E,'_generate_next_value_',staticmethod(lambda *a:1)))
 def test_enum_right_function_wrong_descriptor_rejected(self):
  with self.assertRaises(binding.HOLD):self.check('from enum import Enum\nclass E(str,Enum):\n a="a"\n',lambda m:setattr(m.E,'_generate_next_value_',enum.Enum._generate_next_value_))
 def test_standard_frozen_dataclass_generated_members(self):self.check('from dataclasses import dataclass,field\n@dataclass(frozen=True)\nclass D:\n a:int\n b:list=field(default_factory=list)\n')
 def test_dataclass_foreign_init_rejected(self):
  with self.assertRaises(binding.HOLD):self.check('from dataclasses import dataclass\n@dataclass(frozen=True)\nclass D:\n a:int\n',lambda m:setattr(m.D,'__init__',lambda self:None))
if __name__=='__main__':unittest.main(verbosity=2)
