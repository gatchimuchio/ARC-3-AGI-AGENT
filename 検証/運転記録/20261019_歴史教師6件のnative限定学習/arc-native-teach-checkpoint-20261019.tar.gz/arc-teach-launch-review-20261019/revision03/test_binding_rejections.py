"""Synthetic module/source fixtures only; no native HDS source executes."""
import sys,pathlib,resource,unittest,tempfile,hashlib,types
from unittest.mock import patch
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2);sys.dont_write_bytecode=True
sys.path.insert(0,str(pathlib.Path('arc-native-bootstrap-diagnostic-20261019').resolve()))
import binding,source_allowlist
BASE=pathlib.Path('arc-teach-launch-review-20261019').resolve()
class Tests(unittest.TestCase):
 def reject(self,sources,mutate):
  with tempfile.TemporaryDirectory(dir=BASE) as d:
   root=pathlib.Path(d);mods={};pins={}
   for filename,source in sources.items():
    p=root/filename;p.write_text(source);pins[filename]=hashlib.sha256(p.read_bytes()).hexdigest();name='hds学習系統' if filename=='__init__.py' else 'hds学習系統.'+filename[:-3]
    m=types.ModuleType(name);m.__file__=str(p);exec(compile(source,str(p),'exec'),m.__dict__);mods[name]=m
   mutate(mods)
   with patch.dict(sys.modules,mods),patch.object(source_allowlist,'HDS_MODULE_PINS',pins),patch.object(binding,'verify_native_binding',lambda *a:None):
    with self.assertRaises(binding.HOLD):binding.verify(types.SimpleNamespace(保存する=lambda:None),root/'永続化.py',None,None)
 def test_foreign_function_replacement(self):
  self.reject({'__init__.py':'def f(): return 1\n'},lambda mods:setattr(mods['hds学習系統'],'f',lambda:2))
 def test_foreign_class_replacement(self):
  self.reject({'__init__.py':'class C:\n def f(self): return 1\n'},lambda mods:setattr(mods['hds学習系統'],'C',type('C',(),{})))
 def test_replaced_class_method(self):
  self.reject({'__init__.py':'class C:\n def f(self): return 1\n'},lambda mods:setattr(mods['hds学習系統'].C,'f',lambda self:2))
 def test_replaced_property(self):
  self.reject({'__init__.py':'class C:\n @property\n def value(self): return 1\n'},lambda mods:setattr(mods['hds学習系統'].C,'value',property(lambda self:2)))
 def test_deleted_private_method(self):
  self.reject({'__init__.py':'class C:\n def _private(self): return 1\n'},lambda mods:delattr(mods['hds学習系統'].C,'_private'))
 def test_noncallable_method_replacement(self):
  self.reject({'__init__.py':'class C:\n def f(self): return 1\n'},lambda mods:setattr(mods['hds学習系統'].C,'f',123))
if __name__=='__main__':unittest.main(verbosity=2)
