import sys,json,resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
sys.dont_write_bytecode=True
sys.path.insert(0,'arc-native-teach-20261019')
from guard import Guard
from bounded_store import json_bytes
class Machine:
 def 処理する(self,x): return {'genuine':True}
 def 照会する(self,x): return {'genuine':True}
m=Machine();g=Guard(m,json_bytes,json.loads,lambda n,b:None,[('処理する',b'{}')])
m.処理する=lambda x:{'replacement':True}
r=g.処理する({})
print(json.dumps({'initial_dynamic_replacement_executed':r,'frontier':g.progress()},ensure_ascii=False))
