"""Independent read-only framed-byte and native-wire evidence audit; no native imports."""
import pathlib,json,hashlib,struct,resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
B=pathlib.Path(__file__).resolve().parents[2];R=B/'arc-native-teach-final-20261019';O=pathlib.Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def normalized(x):
 if isinstance(x,list):return [normalized(v) for v in x]
 if isinstance(x,dict):
  if set(x)=={'__辞書__'}:return {normalized(k):normalized(v) for k,v in x['__辞書__']}
  if set(x)=={'__組__'}:return tuple(normalized(v) for v in x['__組__'])
  return {k:normalized(v) for k,v in x.items()}
 return x
def plain(x):return json.loads(json.dumps(x,ensure_ascii=False))
def wire(b):return normalized(json.loads(b))
def framed(path):
 out=[];offset=0
 with path.open('rb') as f:
  while True:
   header=f.read(8)
   if header==b'\0'*8 or not header:
    assert not any(f.read()),'nonzero trailing evidence';break
   assert len(header)==8;n=struct.unpack('>Q',header)[0];assert 0<n<1024
   rawhead=f.read(n);h=json.loads(rawhead);assert h['bytes']<=8*1024**2
   payload=f.read(h['bytes']);assert len(payload)==h['bytes'] and sha(payload)==h['sha256']
   out.append((h,payload,offset));offset+=8+n+len(payload)
 return out,offset
c=json.loads((R/'proposed_config.json').read_bytes());review=json.loads((O.parent/'revision04/reviewed_final_pilot_manifest.json').read_bytes())
assert sha((R/'proposed_config.json').read_bytes())==review['config_sha256']
for p,h in c['pins'].items():assert sha(pathlib.Path(p).read_bytes())==h,p
rows,used=framed(R/'run01/evidence.reserve');assert len(rows)==141
records={h['name']:(b,offset) for h,b,offset in rows};assert len(records)==141
outputs=[];maxin=0;maxout=0;lastoffset=-1
for i,row in enumerate(c['plan'],1):
 prefix=f'{i:02d}.{row["method"]}';a,ao=records[prefix+'.input'];z,zo=records[prefix+'.input_after'];b,bo=records[prefix+'.output'];assert lastoffset<ao<bo<zo;lastoffset=zo
 assert a==z;assert wire(a)=={'__データ型__':'外部入力','値':row['input']}
 output=wire(b);assert output['__データ型__']=='外部出力';outputs.append(output['値']);maxin=max(maxin,len(a));maxout=max(maxout,len(b))
assert maxin<=8192 and maxout<=65536
names=['normal_state','before_state']+[f'teach_{i:02d}_state' for i in range(1,7)]+['post_state']
baselinebytes=(B/'arc-native-query-20261019/query_retry02/poststate.json').read_bytes();baseline=wire(baselinebytes);previous=baseline;snapshots=[]
for index,name in enumerate(names):
 p=R/'run01'/(name+'.reserve');raw=p.read_bytes();assert len(raw)<=c['state_upper_bound_bytes'];current=wire(raw)
 if index==0:assert raw==baselinebytes
 for old in (baseline,previous):
  assert set(old['台帳'])<=set(current['台帳']) and set(old['原理履歴'])<=set(current['原理履歴'])
  for k,v in old['台帳'].items():assert current['台帳'][k][:len(v)]==v
  for k,v in old['原理履歴'].items():assert current['原理履歴'][k][:len(v)]==v
  assert current['状態履歴'][:len(old['状態履歴'])]==old['状態履歴']
 if name in ('before_state','post_state'):
  assert set(previous)==set(current)
  assert all(current[k]==previous[k] for k in current if k!='識別子状態')
  expected=dict(previous['識別子状態']);expected['照会']+=19;expected['学習判定']+=19;assert current['識別子状態']==expected
  assert len(current['台帳']['観測台帳'])==(183 if name=='before_state' else 189)
 if name.startswith('teach_'):assert len(current['台帳']['観測台帳'])==183+int(name[6:8])
 snap=wire(records['snapshot.'+name][0]);assert snap['receipt']['bytes']==len(raw) and snap['receipt']['sha256']==sha(raw)
 assert snap['ledger_slices']=={k:[len(previous['台帳'].get(k,())),len(v)] for k,v in current['台帳'].items()}
 assert snap['principle_history_slices']=={k:[len(previous['原理履歴'].get(k,())),len(v)] for k,v in current['原理履歴'].items()}
 assert snap['state_history_slice']==[len(previous['状態履歴']),len(current['状態履歴'])]
 snapshots.append({'name':name,'bytes':len(raw),'sha256':sha(raw),'observations':len(current['台帳']['観測台帳']),'principle_records':len(current['台帳']['原理台帳']),'counters':current['識別子状態']});previous=current
final=previous
expected_delta={'all_original_prefixes_unchanged':True,'ledger_appends':{k:v[len(baseline['台帳'].get(k,())):] for k,v in final['台帳'].items()},'principle_history_appends':{k:v[len(baseline['原理履歴'].get(k,[])):] for k,v in final['原理履歴'].items()},'state_history_appends':final['状態履歴'][len(baseline['状態履歴']):],'counters_before':baseline['識別子状態'],'counters_after':final['識別子状態']}
assert plain(expected_delta)==json.loads((R/'native_full_delta.json').read_bytes())
delta=expected_delta['ledger_appends'];newobs=[x['値'] for x in delta['観測台帳']]
for i,x in enumerate(newobs):assert x['原入力']==c['plan'][19+i]['input']['内容'] and x['対象系境界']==c['plan'][19+i]['input']['対象系境界'] and x['経験識別子']==f'経験-{184+i:06d}'
principles=[p['値'] for p in delta['原理台帳']];assert len(principles)==3 and len(set(p['系譜識別子'] for p in principles))==1
assert [p['版'] for p in principles]==[1,2,3]
assert [len(p['根拠参照群']) for p in principles]==[3,4,5]
assert [p['適用範囲']['条件種類数'] for p in principles]==[2,3,4]
assert all(p['反証参照群']==() and p['適用範囲']['条件数']==1 for p in principles)
last=principles[-1];assert last['条件経路群']==(('作用前の修復保全条件組',),) and last['結果経路']==('公開進捗が増加',)
assert last['根拠参照群']==tuple(f'経験-{i:06d}' for i in range(184,189))
assert delta['証拠台帳'][-1]['支持参照群']==tuple(f'経験-{i:06d}' for i in range(184,190))
assert len(delta['判断台帳'])==4 and all(x['判定']=='適合' for x in delta['判断台帳'])
labels=[];goal=[]
for i in range(6):
 before=outputs[i];after=outputs[25+i];assert before['状態']=='出力' and len(before['内容']['予測群'])==0
 predictions=after['内容']['予測群'];assert len(predictions)==1;p=predictions[0];label=c['plan'][19+i]['input']['内容']['公開進捗が増加'];assert p['予測値'] is label and p['原理参照']==last['原理識別子'];labels.append(label)
 goal.append({'row':i+1,'before_prediction_count':0,'after_label':label,'principle':p['原理参照']})
assert labels==[False,False,False,False,True,True]
keys=('予測群','競合群','追加観測要求群','識別不能群','係争中原理群','断定保留理由群','学習成立状態')
for i in range(6,19):
 a,b=outputs[i],outputs[25+i];assert a['状態']==b['状態'];assert all(a['内容'][k]==b['内容'][k] for k in keys);assert b['内容']['有効原理群'][:len(a['内容']['有効原理群'])]==a['内容']['有効原理群']
teachstatus=[x['内容']['学習成立状態'] for x in outputs[19:25]];assert teachstatus==['接続途上','接続途上','成立確認','成立確認','成立確認','接続途上']
workerreport=json.loads((R/'result_audit.json').read_bytes());assert [x['full_output'] for x in workerreport['teacher_replies']]==plain(outputs[19:25])
for i,g in enumerate(workerreport['goal6_same_condition_results']):assert g['teacher_outcome'] is labels[i] and g['matching_single_prediction']
assert workerreport['all13_smoke_relevant_outputs_equal'] and workerreport['all_original_ledger_history_prefixes_unchanged']
def projection(output):return {k:output['内容'][k] for k in keys}|{'状態':output['状態']}
for i,g in enumerate(workerreport['goal6_same_condition_results']):
 assert g['input']==c['plan'][i]['input'] and g['row']==i
 assert g['before']==plain(projection(outputs[i])) and g['after']==plain(projection(outputs[25+i]))
for i,g in enumerate(workerreport['old_boundary_smoke_results'],6):
 a,b=outputs[i],outputs[25+i]
 assert g['condition']==c['plan'][i]['input'] and g['query_ordinal']==i+1
 assert g['before']==plain(projection(a)) and g['after']==plain(projection(b))
 assert g['trace_before']==plain(a['追跡情報']) and g['trace_after']==plain(b['追跡情報'])
 assert g['global_active_principles_added']==plain(b['内容']['有効原理群'][len(a['内容']['有効原理群']):])
 assert g['old_active_principle_projection_prefix_equal'] and g['relevant_output_equal']
for a,b in zip(workerreport['snapshots'],snapshots):
 assert all(a[k]==b[k] for k in ('name','bytes','sha256','counters'))
 assert a['counts']['観測台帳']==b['observations'] and a['counts']['原理台帳']==b['principle_records']
mapping={json.loads(k[0]):v for k,v in last['対応値表']}
assert mapping=={c['plan'][i]['input']['内容']['作用前の修復保全条件組']:labels[i] for i in range(6)}

meta,_=framed(R/'run01/metadata_logs.reserve');complete=[wire(b) for h,b,o in meta if h['name']=='completed'];assert len(complete)==1;comp=complete[0];assert comp['native_calls_entered']==comp['native_calls_returned']==comp['fully_persisted_calls']==44
for name in ('worker_failure','worker_emergency'):assert framed(R/'run01'/(name+'.reserve'))[0]==[]
superv=framed(R/'run01/supervisor_failure.reserve')[0];assert len(superv)==1 and wire(superv[0][1])['status']=='PASS'
assert not any((R/'run01/failure_state.reserve').read_bytes())
prior=json.loads((O.parent/'revision03/retained_runs_before_patch.json').read_bytes())
for dirname,files in prior.items():
 for name,pin in files.items():
  p=B/dirname/'run01'/name;h=hashlib.sha256()
  with p.open('rb') as f:
   for chunk in iter(lambda:f.read(1024**2),b''):h.update(chunk)
  assert p.stat().st_size==pin['bytes'] and h.hexdigest()==pin['sha256']
dirs=['arc-native-teach-20261019','arc-native-teach-retry-20261019','arc-native-bootstrap-diagnostic-20261019','arc-native-teach-final-20261019'];sizes={d:sum(p.stat().st_size for p in (B/d).rglob('*') if p.is_file()) for d in dirs};assert sizes[dirs[-1]]<=96*1024**2 and sum(sizes.values())<=296*1024**2
report={'verdict':'BOUNDED_NATIVE_EVIDENCE_PASS','native_auditor_calls':0,'all_pins_verified':True,'all_original_previous_prefixes_verified':True,'query_only_semantic_states_unchanged':True,'failed_runs_unchanged':True,'framed_records':len(rows),'call_records':132,'snapshot_records':9,'evidence_used_bytes':used,'max_input_bytes':maxin,'max_reply_bytes':maxout,'snapshots':snapshots,'goal_after_labels':labels,'goal_distinct_conditions':len(set(c['plan'][i]['input']['内容']['作用前の修復保全条件組'] for i in range(6))),'teacher_statuses':teachstatus,'new_principle_lineages':1,'new_principle_versions':3,'final_principle_supports':list(last['根拠参照群']),'sixth_candidate_supports':list(delta['証拠台帳'][-1]['支持参照群']),'all13_smoke_relevant_equal':True,'ledger_appends':{k:len(v) for k,v in delta.items()},'resource_directory_bytes':sizes,'aggregate_bytes':sum(sizes.values()),'peak_audit_rss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'limitations':['same four training conditions, not held-out generalization','historical teachers new only to current descendant; zero new independent observations','fixed geometry/mask/roles and endpoint score labels remain supplied prior/projection','before reply was output with empty predictions, not native HOLD','sixth teacher retained/evaluated but no new principle version or support refresh','13-case smoke is not full prior-success regression','no SDK/Action/fullgame/crossgame capability evidence']}
(O/'audit_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='snapshots'},ensure_ascii=False,indent=2))
