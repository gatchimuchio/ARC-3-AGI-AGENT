# Independent completed native teacher evidence audit

## Verdict

BOUNDED NATIVE EVIDENCE PASS. This review independently reads retained bytes only: zero native imports, Query, Teach, save, SDK, Action or Git operations by the reviewer. All checks in audit.py pass under512MiB address space. This is a measured narrow learning/retrieval result, not generalization or runtime adoption.

## Verified result

Exactly44 native calls are fully captured:38 Query and six processing/Teach calls, in the frozen19Q/6T/19Q order. The141 framed evidence records comprise132 input/output/post-input records and nine checkpoint indices. Every payload hash and frame extent checks; evidence uses1,586,947B. Maximum native input505B and reply35,083B stay within the reviewed bounds. All original source/input pins match. Worker completion and supervisor terminal records agree on44 entered/returned/fully-persisted calls and PASS; worker failure/emergency records are absent and the failure-state slot is unused.

All nine full native states are parsed and independently matched to their persisted hash/size receipts. The initial roundtrip is byte-identical to the5,355,957B baseline. Every baseline and previous ledger, principle-history and state-history prefix is unchanged. Both19-Query batches change only the two specified counters by19; no other semantic state changes. The final state is5,558,643B. Observations increase183→189, and principle records16→19. Query counters6660→6698. Full native_full_delta.json exactly equals the independently derived whole-state difference.

Before teaching, the six matched Query outputs have status出力 with no predictions. This is not native HOLD. After teaching, all six return the expected F,F,F,F,T,T labels at the requested endpoint path, using principle原理-000019. They cover four distinct conditions and include duplicates.

There is one new deterministic-correspondence lineage, with versions1/2/3 created after teachers3/4/5. The table expands to2/3/4 observed condition values, with support lengths3/4/5. Its applicability is the native observed-condition-value boundary, one condition field, under the explicitly named fixed-geometry endpoint boundary. The exact final table matches all four teacher-condition mappings. This is actual new native state in the current descendant, not a manually substituted reply.

All six observations and completion histories are retained. Native teacher learning-status judgments are 接続途上, 接続途上, 成立確認, 成立確認, 成立確認, 接続途上. Teacher6 is observed and evaluated; candidate233's evidence/judgment includes supports184–189, but unchanged table means no new principle version. Final principlev3 retains supports184–188. This behavior is recorded, not repaired or hidden.

All13 old-boundary/control smoke cases retain identical relevant predictions/conflicts/requests/indistinguishability/HOLD-reason/learning-status/output-status fields. Global active-principle summaries and state versions legitimately reflect the new lineage; this is not whole-reply byte equality. Worker result_audit.json's teacher outputs, goal before/after projections, regression projections/traces and snapshot identities were independently crosschecked against raw records.

## Preservation and resources

Both earlier failed run01 directories were rehashed and remain byte-identical to prior reviewed manifests. The native fixed core and exact input packs remain unchanged. Final pilot tree stays below96MiB; combined original/retry/diagnostic/final trees are266,005,852B at audit time, below the explicitly admitted296MiB aggregate ceiling. Native state truncation released logical reserve extents as previously disclosed; no physical-persistence guarantee is inferred. Audit peak RSS is recorded in audit_report.json.

## Claim boundary

The six teachers are historical public observations newly introduced to this descendant; zero new independent observations were collected. Geometry/mask assumptions, roles and public-score endpoint labels are supplied prior/projection, not newly learned role or action semantics. The tests reuse the same four teaching conditions. No held-out generalization, necessity/sufficiency proof, continuous preservation, mask correctness, fresh-instance transfer, cross-game ability, live Action safety, or full-game success is established. The13 smoke cases are not complete prior-success regression.

The initial independent audit assertion mistakenly expected an empty tuple where the genuine output codec contains an empty list. first_audit_failure.log retains that reviewer failure. The assertion was corrected to check zero predictions without changing evidence; the complete final audit passes.
