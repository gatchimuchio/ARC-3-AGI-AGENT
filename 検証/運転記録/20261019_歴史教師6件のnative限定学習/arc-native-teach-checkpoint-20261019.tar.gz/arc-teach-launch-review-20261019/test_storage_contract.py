"""Pure mock writer tests; bypass native identity only, never import native modules."""
import sys,pathlib,resource,unittest,tempfile,inspect
from unittest.mock import patch
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
sys.dont_write_bytecode=True
ROOT=pathlib.Path('arc-native-teach-20261019').resolve();sys.path.insert(0,str(ROOT))
import bounded_store as b
from source_allowlist import PERSISTENCE_SHA256
import launcher
BASE=pathlib.Path('arc-teach-launch-review-20261019').resolve()
CORE=launcher.CORE/'hds学習系統'
class Writer:
 def __init__(self,fail=False):self.fail=fail
 def 保存する(self,path):
  path.write_bytes(b'partial' if self.fail else b'{}')
  if self.fail:raise ValueError('interrupted save')
class Tests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(dir=BASE);self.s=b.Store(pathlib.Path(self.tmp.name)/'run',{k:8192 for k in launcher.CAPACITIES});self.sink=b.NativeSaveSink(self.s)
  self.p1=patch.object(b,'verify_native_binding',lambda *a:None);self.p1.start()
  self.p2=patch.object(inspect,'getsourcefile',lambda fn:str(CORE/'系統.py'));self.p2.start()
 def tearDown(self):self.p2.stop();self.p1.stop();self.s.close();self.tmp.cleanup()
 def save(self,k,w):return self.sink.save(k,w.保存する,source_file=CORE/'永続化.py',expected_sha256=PERSISTENCE_SHA256)
 def test_ten_single_use_slots(self):
  self.assertEqual(len(launcher.STATE_REGIONS),10)
  old=resource.getrlimit(resource.RLIMIT_FSIZE)
  for k in launcher.STATE_REGIONS:
   self.assertEqual(self.save(k,Writer())['bytes'],2)
   with self.assertRaises(b.HOLD):self.save(k,Writer())
   self.assertEqual(resource.getrlimit(resource.RLIMIT_FSIZE),old)
 def test_interrupted_save_preserves_partial_and_limit(self):
  old=resource.getrlimit(resource.RLIMIT_FSIZE)
  with self.assertRaises(ValueError):self.save('teach_01_state',Writer(True))
  self.assertEqual(resource.getrlimit(resource.RLIMIT_FSIZE),old)
  self.assertEqual((self.s.root/'teach_01_state.reserve').read_bytes(),b'partial')
  with self.assertRaises(b.HOLD):self.save('teach_01_state',Writer())
  self.save('failure_state',Writer())
 def test_readback_failure_claims_extent(self):
  original=b.os.pread
  with patch.object(b.os,'pread',lambda *a:b'bad'):
   with self.assertRaises(OSError):self.s.append('evidence','one',b'first')
  offset=self.s.offsets['evidence'];self.s.append('evidence','two',b'second')
  self.assertGreater(self.s.offsets['evidence'],offset)
  with self.assertRaises(b.HOLD):self.s.append('evidence','one',b'other')
 def test_disjoint_failure_regions(self):
  for k in ('worker_failure','worker_emergency','supervisor_failure'):
   self.s.append(k,k,k.encode())
  for k in ('worker_failure','worker_emergency','supervisor_failure'):
   self.assertEqual(self.s.records(k)[0][1],k.encode())
 def test_capacity_exact_92_mib(self):
  self.assertEqual(sum(launcher.CAPACITIES.values()),92*1024**2)
  self.assertTrue(all(launcher.CAPACITIES[k]==8*1024**2 for k in launcher.STATE_REGIONS))
if __name__=='__main__':unittest.main(verbosity=2)
