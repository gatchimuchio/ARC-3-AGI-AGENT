# Exact teacher launcher independent review

## Verdict

Bounded PASS for the final static/pure caller and storage contracts, conditional on the frozen source/input/config pins in reviewed_manifest.json. This is not native execution admission, an observed native bootstrap/save result, a full prior-success regression, or an Action/live-environment viability claim. Parent must separately admit execution. The proposed configuration remains unadmitted.

Owner original and both additions, repository AGENTS, authority hierarchy, current state, previous guard-review README and teacher-review README were reread. Strategy remains null and automatic transition false. No native/HDS module was imported or executed; no native Query/Teach, SDK, Action, environment access, Git action, or worker-source modification occurred. Only this separate review directory was written. Pure tests run under 512 MiB address-space limits; review directory is below 96 MiB.

## Tests

25 independent tests pass: 10 worker-contract, five storage-contract, four supervisor-contract, six synthetic binding-rejection tests. All 13 provided Guard tests pass. See *_final.log. These counts measure checked wrapper scenarios, not learning or gameplay performance.

Worker tests replace only load_native and NativeSaveSink with explicitly synthetic contract fixtures. Storage tests replace native identity validation and source-location introspection while exercising the actual Store and NativeSaveSink write/limit plumbing with a mock writer. Binding rejection tests use tiny synthetic source/module declarations, never execute any actual native source. Supervisor tests mock fork/wait/kill; no native child is launched.

Verified scenarios include:
- Exactly 19 Query, six Teach, 19 byte-identical before/after Query inputs; no extra or reordered call; no automatic CLI; no execution without explicit parent admission.
- Detached immutable input bytes, persisted before entry, output and post-input persisted before follow-on, captured native method identities, latched failure, exact entered/returned/fully-persisted counts and unentered method suffix.
- Normal nine checkpoints, all ten single-use state reservations, interrupted second Teach frontier 21/20/20, returned-but-unpersisted Teach frontier 20/20/19, interrupted save with retained partial bytes, corrupt readback, changed prefixes, unexpected Query mutations, and no follow-on after each failure.
- Query-only checkpoint equality excludes only identifiers and requires exactly +19 Query/+19 learning-decision counters; other roots/fields must match. Baseline and previous ledger/history prefixes remain intact and bounded delta indices refer to full retained state files.
- Per-save file-size limits are restored after mock interrupted writes; claimed failed extents and state slots cannot be reused. Worker, emergency and supervisor evidence use physically separate regions.
- Fork/wait/terminal-record failures HOLD, close storage, kill/reap only a still-unreaped child, and never infer a zero frontier from child silence. Preparation failure records zero entries when known; encoding exhaustion uses preencoded UNKNOWN fallback.
- Synthetic foreign function/class replacement, method/property replacement, deleted private methods and noncallable method replacement are rejected by the repaired binding checks.

## Repairs found and verified

The initial captured probe reproduced dynamic method replacement being invoked after Guard construction. Final probe uses the originally captured method. Initial launcher accepted arbitrary 44/6 order and mutable configuration, lacked Query-only unchanged-state enforcement, and left supervisor/preparation failure gaps. These were repaired by the worker. Binding now verifies exact twelve module names/paths/source hashes, expected AST declarations and relative imported aliases independent of actual metadata, every declared class method/descriptor, properties, generated dataclass/Enum methods, component instance identities and codec type-module binding. Previous worker source versions remain retained by the worker.

The loaded native closure and generated-class comparison have not been exercised against real imported HDS modules during this review. Their first actual execution may still HOLD. This review does not replace that pre-call identity gate.

## Storage and failure limitations

Ten 8 MiB state slots total 80 MiB. Evidence 8 MiB plus four 1 MiB metadata/worker-failure/emergency/supervisor regions yields exactly 92 MiB fixed reservations. Admission measures existing preparation bytes and refuses totals above 96 MiB before creating a fresh run directory. This is a bound on the reviewed known writers and file lengths, not a filesystem-wide quota or hostile-code sandbox. Parent must prevent unrelated writers in that tree.

Native Path.write_text truncates state reservations, potentially releasing preallocated blocks. Free-space admission does not guarantee physical retention under arbitrary ENOSPC, kernel failure, abrupt machine death, or allocation failure. Emergency fallback also cannot guarantee a complete write: a partially claimed emergency region is not overwritten/reused. If the small-frontier append claims space then fails, raw fallback cannot reuse it; evidence can remain partial and frontier UNKNOWN. Every partial file/extent must remain retained. Unknown frontier prohibits automatic resumption.

The independent growth/reply proof and witness/regression reviews remain separate prerequisites. This launcher preserves and checks evidence; it cannot establish that historical teachers confer generalization, prior-success preservation, or safe runtime action selection. The 13 existing-boundary/control inputs are a narrow smoke regression, not complete prior-success coverage.
