import pathlib,json,hashlib,resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
base=pathlib.Path(__file__).resolve().parent;root=base.parent/'arc-native-teach-20261019'
config=json.loads((root/'proposed_config.json').read_bytes())
assert config['explicit_parent_admission'] is False
assert tuple(r['method'] for r in config['plan'])==('照会する',)*19+('処理する',)*6+('照会する',)*19
assert config['plan'][:19]==config['plan'][25:]
assert all(str(p) in config['pins'] for p in root.glob('*.py'))
for p,h in config['pins'].items():assert hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()==h,p
c=base.parent/'arc-teacher-contrasts-20261019'
q=sum([json.loads((c/p).read_bytes()) for p in ['goal6_matched_queries.runtime.json','existing_four_row_queries.runtime.json','regression_v2/nine_queries.runtime.json']],[])
t=json.loads((c/'goal6_teachers.runtime.json').read_bytes())
assert [r['input'] for r in config['plan'][:19]]==q
assert [r['input'] for r in config['plan'][19:25]]==t
existing=sum(p.stat().st_size for p in root.rglob('*') if p.is_file())
assert existing+92*1024**2+3*1024**2<=96*1024**2
files=list(root.glob('*.py'))+[root/'proposed_config.json',root/'proposed_admission.json']
report={'status':'BOUNDED_STATIC_PURE_PASS_NOT_EXECUTION_ADMISSION','independent_tests':25,'provided_guard_tests':13,'native_imports':0,'native_calls':0,'reviewed_files':{str(p):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files},'all_config_pins_verified':True,'exact_input_pack_verified':True,'existing_preparation_bytes':existing,'fixed_reservations_bytes':92*1024**2,'postrun_report_maximum_bytes':3*1024**2,'max_directory_bytes':96*1024**2,'limitations':['Real native bootstrap binding has not run','Known writer file-length bound, not physical disk guarantee','Full prior-success regression and runtime viability not established','Explicit parent execution admission still required']}
(base/'reviewed_manifest.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='reviewed_files'},ensure_ascii=False,indent=2))
