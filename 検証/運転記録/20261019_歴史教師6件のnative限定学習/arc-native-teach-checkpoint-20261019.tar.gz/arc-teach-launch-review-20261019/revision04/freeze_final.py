import pathlib,json,hashlib,resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
b=pathlib.Path(__file__).resolve().parent;new=pathlib.Path('arc-native-teach-final-20261019');old=pathlib.Path('arc-native-teach-20261019');retry=pathlib.Path('arc-native-teach-retry-20261019');diag=pathlib.Path('arc-native-bootstrap-diagnostic-20261019')
c=json.loads((new/'proposed_config.json').read_bytes());o=json.loads((old/'proposed_config.json').read_bytes());assert c['plan']==o['plan'];assert c['explicit_parent_admission'] is False
for key in ['state_upper_bound_bytes','evidence_upper_bound_bytes','evidence_reserved_bytes','source_bytes','baseline_counter']:assert c[key]==o[key],key
for p,h in c['pins'].items():assert hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()==h,p
for n in ['launcher.py','guard.py','source_allowlist.py']:assert (new/n).read_bytes()==(retry/n).read_bytes(),n
for n in ['binding.py','bounded_store.py','gate_metadata.py']:assert (new/n).read_bytes()==(diag/n).read_bytes(),n
receipt=json.loads((b/'verified_bootstrap_receipt.json').read_text())
for n in ['binding.py','bounded_store.py','gate_metadata.py','source_allowlist.py']:assert hashlib.sha256((new/n).read_bytes()).hexdigest()==receipt['files'][n]['sha256'],n
sizes={str(d):sum(p.stat().st_size for p in d.rglob('*') if p.is_file()) for d in [old,retry,diag,new]};future=95*1024**2;assert sizes[str(new)]+future<=96*1024**2;assert sum(sizes.values())+future<=296*1024**2
r={'status':'BOUNDED_FINAL_STATIC_PASS_ACTUAL_BOOTSTRAP_PASS_NOT_PILOT_ADMISSION','config_sha256':hashlib.sha256((new/'proposed_config.json').read_bytes()).hexdigest(),'explicit_parent_admission':False,'exact44plan_unchanged':True,'all_source_input_pins_match':True,'all_state_reply_bounds_unchanged':True,'caller_guard_unchanged_from_reviewed_retry':True,'binding_store_metadata_equal_actual_passed_bootstrap':True,'retained_directory_bytes':sizes,'future_new_reservations_plus_reports_bytes':future,'combined_actual_plus_future_bytes':sum(sizes.values())+future,'combined_limit_bytes':296*1024**2,'new_limit_bytes':96*1024**2}
r['files']={p.name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in list(new.glob('*.py'))+[new/'proposed_config.json',new/'proposed_admission.json']}
(b/'reviewed_final_pilot_manifest.json').write_text(json.dumps(r,indent=2));print(json.dumps({k:v for k,v in r.items() if k!='files'},indent=2))
