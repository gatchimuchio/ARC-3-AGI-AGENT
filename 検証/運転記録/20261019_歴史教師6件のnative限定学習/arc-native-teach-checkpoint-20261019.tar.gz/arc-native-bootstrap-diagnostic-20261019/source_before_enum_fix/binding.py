"""Exact caller/intake/engine/exhaust and component identity gate."""
from bounded_store import HOLD,verify_native_binding
from gate_metadata import failure
def detailed_hold(*reason):return failure(HOLD,*reason)
import sys,types,ast,pathlib,hashlib,dataclasses,enum,copy
def package_import_attributes(module,expected_modules,root,pins):
 """Only importlib's exact pinned direct children on the actual root package."""
 if module.__name__!='hds学習系統':return set()
 allowed=set()
 for full,filename in expected_modules.items():
  if not full.startswith('hds学習系統.') or full.count('.')!=1:continue
  attr=full.rsplit('.',1)[1]
  if attr not in vars(module):continue
  value=vars(module)[attr]
  path=getattr(value,'__file__',None) if isinstance(value,types.ModuleType) else None
  if (not isinstance(value,types.ModuleType) or value is not sys.modules.get(full)
      or value.__name__!=full or path is None
      or pathlib.Path(path).resolve()!=root/filename
      or hashlib.sha256((root/filename).read_bytes()).hexdigest()!=pins[filename]):
   raise detailed_hold('package submodule attribute mismatch',module.__name__,attr,type(value).__name__,path)
  allowed.add(attr)
 return allowed

def verify(machine,persistence_source,encode,decode):
 verify_native_binding(machine.保存する,persistence_source)
 from source_allowlist import HDS_MODULE_PINS
 root=pathlib.Path(persistence_source).resolve().parent
 expected_modules={'hds学習系統' if name=='__init__.py' else 'hds学習系統.'+name[:-3]:name for name in HDS_MODULE_PINS}
 actual_modules={name for name in sys.modules if name=='hds学習系統' or name.startswith('hds学習系統.')}
 if actual_modules!=set(expected_modules):raise detailed_hold('exact twelve-module closure required')
 def expected_code(path,qualname):
  code=compile(path.read_bytes(),str(path),'exec')
  def walk(c):
   if c.co_qualname==qualname:return c
   for v in c.co_consts:
    if isinstance(v,types.CodeType):
     found=walk(v)
     if found is not None:return found
  return walk(code)
 for name,filename in expected_modules.items():
  module=sys.modules[name];path=root/filename
  if pathlib.Path(module.__file__).resolve()!=path or hashlib.sha256(path.read_bytes()).hexdigest()!=HDS_MODULE_PINS[filename]:raise detailed_hold('exact module root/source')
  tree=ast.parse(path.read_text());declared=set()
  for node in tree.body:
   if isinstance(node,(ast.FunctionDef,ast.ClassDef)):declared.add(node.name)
   elif isinstance(node,(ast.Import,ast.ImportFrom)):
    for alias in node.names:declared.add(alias.asname or alias.name.split('.')[0])
   elif isinstance(node,(ast.Assign,ast.AnnAssign)):
    for target in (node.targets if isinstance(node,ast.Assign) else [node.target]):
     if isinstance(target,ast.Name):declared.add(target.id)
  imported_children=package_import_attributes(module,expected_modules,root,HDS_MODULE_PINS)
  unexpected=[k for k in vars(module) if k not in declared and k not in imported_children and not k.startswith('__')]
  if unexpected:
   key=unexpected[0];value=vars(module)[key]
   detail_path=getattr(value,'__file__',None) if isinstance(value,types.ModuleType) else getattr(getattr(value,'__code__',None),'co_filename',None)
   raise detailed_hold('unexpected native module global',name,key,type(value).__name__,detail_path)

  # Expected declaration/import metadata comes from pinned AST, never from
  # possibly replaced actual callable.__module__ attributes.
  for node in tree.body:
   if isinstance(node,ast.FunctionDef):
    fn=vars(module).get(node.name)
    if not isinstance(fn,types.FunctionType) or fn.__code__!=expected_code(path,node.name):raise detailed_hold('declared native function mismatch')
   elif isinstance(node,ast.ClassDef):
    cls=vars(module).get(node.name)
    if not isinstance(cls,type) or cls.__name__!=node.name or cls.__module__!=name:raise detailed_hold('declared native class mismatch')
    for member in node.body:
     if not isinstance(member,ast.FunctionDef):continue
     actual=vars(cls).get(member.name)
     decorator_names=[d.id for d in member.decorator_list if isinstance(d,ast.Name)]
     if 'property' in decorator_names:
      if not isinstance(actual,property):raise detailed_hold('declared native property absent')
      actual=actual.fget
     elif 'classmethod' in decorator_names:
      if not isinstance(actual,classmethod):raise detailed_hold('declared classmethod absent')
      actual=actual.__func__
     elif 'staticmethod' in decorator_names:
      if not isinstance(actual,staticmethod):raise detailed_hold('declared staticmethod absent')
      actual=actual.__func__
     if not isinstance(actual,types.FunctionType) or actual.__code__!=expected_code(path,node.name+'.'+member.name):raise detailed_hold('declared native method absent/replaced')

   elif isinstance(node,ast.ImportFrom) and node.level:
    if node.level!=1:raise detailed_hold('unexpected native relative import depth')
    for alias in node.names:
     local=alias.asname or alias.name
     if node.module is None:expected_value=sys.modules.get('hds学習系統.'+alias.name)
     else:
      target=sys.modules.get('hds学習系統.'+node.module)
      expected_value=getattr(target,alias.name,None) if target else None
     if expected_value is None or vars(module).get(local) is not expected_value:raise detailed_hold('declared native import alias mismatch')

  for key,value in vars(module).items():
   if isinstance(value,(types.FunctionType,type)) and getattr(value,'__module__','').startswith('hds学習系統'):
    defining=sys.modules.get(value.__module__)
    if defining is None or getattr(defining,value.__name__,None) is not value:raise detailed_hold('native alias mismatch')
   if isinstance(value,types.FunctionType) and value.__module__==name:
    if value.__code__!=expected_code(path,key):raise detailed_hold('native function code replaced')
   if isinstance(value,type) and value.__module__==name:
    for attr,method in vars(value).items():
     if isinstance(method,property):
      for accessor in (method.fget,method.fset,method.fdel):
       if accessor is not None and accessor.__code__!=expected_code(path,value.__name__+'.'+attr):raise detailed_hold('native property code replaced')
      continue
     if isinstance(method,(classmethod,staticmethod)):method=method.__func__
     if isinstance(method,types.FunctionType):
      expected=expected_code(path,value.__name__+'.'+attr)
      if expected is None:
       if issubclass(value,enum.Enum) and attr in ('__new__','__repr__','__str__','__format__') and method is getattr(enum.Enum,attr):continue
       if '__dataclass_fields__' not in vars(value) or attr not in ('__init__','__repr__','__eq__','__setattr__','__delattr__','__hash__'):raise detailed_hold('unexpected generated method')
       clone=dataclasses.make_dataclass(value.__name__,[(f.name,f.type,copy.copy(f)) for f in dataclasses.fields(value)],frozen=True)
       generated=getattr(clone,attr)
       if method.__code__!=generated.__code__:raise detailed_hold('dataclass generated method replaced')
       if hasattr(method,'__wrapped__') and method.__wrapped__.__code__!=generated.__wrapped__.__code__:raise detailed_hold('dataclass repr generated body replaced')
      elif method.__code__!=expected:raise detailed_hold('native class method code replaced')
 if sys.modules['hds学習系統.永続化'].型定義 is not sys.modules['hds学習系統.型']:raise detailed_hold('codec type registry module')
 persist=sys.modules['hds学習系統.永続化']
 if encode is not persist._符号化 or decode is not persist._復号:raise detailed_hold('native codec identity')
 expected=(
  (machine,'hds学習系統.系統','HDS学習系統',('処理する','照会する','保存する')),
  (machine.吸気系,'hds学習系統.吸気系','最小吸気系',('取り込む','_平坦化','_型名')),
  (machine.排気系,'hds学習系統.排気系','最小排気系',('排出する',)),
  (machine.エンジン,'hds学習系統.実行系','HDS学習実行系',('実行','照会','保存する')),
  (machine.エンジン.懐疑器,'hds学習系統.懐疑','標準懐疑器',('作用する',)),
  (machine.エンジン.推論器,'hds学習系統.推論','共通推論器',('導出する','不成立を確認する')),
  (machine.エンジン.検証器,'hds学習系統.検証','共通検証器',('検証する',)),
  (machine.エンジン.適応器,'hds学習系統.適応','共通適応器',('予測する','原理化する','識別不能を検出する')),
  (machine.エンジン.識別子,'hds学習系統.台帳','識別子生成器',('次',)),
  (machine.エンジン.台帳,'hds学習系統.台帳','追記専用台帳',('追記','取得','全取得')),
  (machine.エンジン.状態,'hds学習系統.台帳','状態管理器',('更新','履歴')),
 )
 for obj,module,cls,methods in expected:
  exact=getattr(sys.modules[module],cls)
  if type(obj) is not exact:raise detailed_hold('native component class identity')
  if any(callable(v) for v in vars(obj).values()):raise detailed_hold('instance callable override')
  for name in methods:
   raw=vars(exact).get(name);actual=getattr(obj,name)
   wanted=raw.__func__ if isinstance(raw,(staticmethod,classmethod)) else raw
   actual=getattr(actual,'__func__',actual)
   if actual is not wanted:raise detailed_hold('native component method identity')
 return True
