"""Explicitly admitted read-only native bootstrap diagnostic. No Query/Teach/save."""
import pathlib,sys,json,hashlib,os,resource,signal,time,shutil,types,enum
from gate_metadata import metadata
R=pathlib.Path(__file__).resolve().parent;B=R.parent;M=1024**2
CORE=B/'arc-native-query-20261019/frozen/HDS/学習系統/v0.4.2';STATE=B/'arc-native-query-20261019/query_retry02/poststate.json'

def child(fd):
 report={'native_imported':False,'native_restore_completed':False,'native_query_calls':0,'native_processing_calls':0,'native_save_calls':0,'automatic_retry':False}
 try:
  resource.setrlimit(resource.RLIMIT_AS,(512*M,)*2);resource.setrlimit(resource.RLIMIT_CPU,(30,30));resource.setrlimit(resource.RLIMIT_FSIZE,(M,M))
  def timeout(*a):raise TimeoutError('diagnostic deadline')
  signal.signal(signal.SIGALRM,timeout);signal.alarm(30)
  def no_writes(event,args):
   if event=='open' and isinstance(args[2],int) and args[2]&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND):raise RuntimeError('read-only diagnostic write denied')
   if event in ('os.remove','os.rename','os.mkdir','os.rmdir','os.link','os.symlink','os.truncate'):raise RuntimeError('read-only diagnostic mutation denied')
  sys.addaudithook(no_writes)
  from source_allowlist import HDS_MODULE_PINS
  for name,h in HDS_MODULE_PINS.items():assert hashlib.sha256((CORE/'hds学習系統'/name).read_bytes()).hexdigest()==h
  assert hashlib.sha256(STATE.read_bytes()).hexdigest()=='f7e5f8c7518b43c7e53f6a1c43f108469c04f72e5d13eb30aa2fae987e2d6e6a'
  sys.path.insert(0,str(CORE))
  from hds学習系統 import HDS学習系統
  from hds学習系統.永続化 import _符号化,_復号
  report['native_imported']=True
  machine=HDS学習系統.読み込む(STATE);report['native_restore_completed']=True
  enum_rows=[]
  for module_name,module in tuple(sys.modules.items()):
   if not module_name.startswith('hds学習系統'):continue
   for class_name,cls in vars(module).items():
    if not isinstance(cls,type) or cls.__module__!=module_name or not issubclass(cls,enum.Enum):continue
    for attr,raw in vars(cls).items():
     method=raw.__func__ if isinstance(raw,(classmethod,staticmethod)) else raw
     if isinstance(method,types.FunctionType):enum_rows.append({'class':class_name,'member':attr,'descriptor':type(raw).__name__,'method':metadata(method),'exact_stdlib_enum_identity':method is getattr(enum.Enum,attr,None)})
  report['actual_enum_methods']=enum_rows
  from binding import verify
  verify(machine,CORE/'hds学習系統/永続化.py',_符号化,_復号)
  report['status']='BINDING_PASS_NO_CALLS'
 except BaseException as error:
  report['status']='HOLD';report['error_type']=type(error).__name__;report['error_args']=error.args
  report['trace']=[{'file':t.tb_frame.f_code.co_filename,'function':t.tb_frame.f_code.co_qualname,'line':t.tb_lineno} for t in iter_trace(error.__traceback__)]
 report['peak_rss_KiB']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
 payload=json.dumps(report,ensure_ascii=False,indent=2).encode();assert len(payload)<M-8
 os.pwrite(fd,len(payload).to_bytes(8,'big')+payload,0);os.fsync(fd)
 os._exit(0)

def iter_trace(tb):
 while tb:
  yield tb;tb=tb.tb_next

def main():
 old=[B/'arc-native-teach-20261019',B/'arc-native-teach-retry-20261019']
 size=lambda p:sum(f.stat().st_size for f in p.rglob('*') if f.is_file())
 assert size(R)+2*M<8*M
 assert sum(map(size,old))+size(R)+2*M<200*M
 assert shutil.disk_usage(R).free>=1024**3+2*M
 path=R/'diagnostic02.reserve';fd=os.open(path,os.O_RDWR|os.O_CREAT|os.O_EXCL,0o600);os.posix_fallocate(fd,0,M);os.fsync(fd)
 pid=os.fork();start=time.monotonic()
 if pid==0:child(fd)
 killed=False
 while True:
  done,status=os.waitpid(pid,os.WNOHANG)
  if done:break
  if time.monotonic()-start>60:
   os.kill(pid,signal.SIGKILL);_,status=os.waitpid(pid,0);killed=True;break
  time.sleep(.02)
 n=int.from_bytes(os.pread(fd,8,0),'big');os.close(fd)
 result={'wait_status':status,'wall_seconds':time.monotonic()-start,'wall_killed':killed,'diagnostic_bytes':n,'native_query_calls':0,'native_processing_calls':0,'native_save_calls':0,'scope':'read-only import/restore/binding metadata only'}
 (R/'supervisor02.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
if __name__=='__main__':main()
