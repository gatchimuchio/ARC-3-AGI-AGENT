import ast, collections, hashlib, json, pathlib, resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
BASE=pathlib.Path(__file__).resolve().parent.parent
CORE=BASE/'arc-native-query-20261019/frozen/HDS/学習系統/v0.4.2/hds学習系統'
STATE=BASE/'arc-native-query-20261019/query_retry02/poststate.json'
TEACH=BASE/'arc-teacher-contrasts-20261019/goal6_teachers.runtime.json'
def dec(x):
 if isinstance(x,list):return [dec(v) for v in x]
 if isinstance(x,dict):
  if '__辞書__' in x:return {dec(k):dec(v) for k,v in x['__辞書__']}
  if '__組__' in x:return tuple(map(dec,x['__組__']))
  return {k:dec(v) for k,v in x.items()}
 return x
raw=json.loads(STATE.read_bytes()); s=dec(raw); ts=json.loads(TEACH.read_bytes())
fields={n.name:[f.target.id for f in n.body if isinstance(f,ast.AnnAssign)] for n in ast.parse((CORE/'型.py').read_text()).body if isinstance(n,ast.ClassDef) and any(isinstance(d,ast.Call) and isinstance(d.func,ast.Name) and d.func.id=='dataclass' for d in n.decorator_list)}
seen=collections.Counter(); bad=[]
def walk(x):
 if isinstance(x,dict):
  if '__データ型__' in x:
   name=x['__データ型__'];seen[name]+=1
   if list(x['値'])!=fields[name]:bad.append((name,list(x['値']),fields[name]))
  for v in x.values():walk(v)
 elif isinstance(x,list):
  for v in x:walk(v)
walk(raw)
assert not bad, bad[:3]
b=ts[0]['対象系境界']; assert len(ts)==6
assert all(set(t)=={'対象系境界','内容','主体','対象','目的','文脈'} and all(t[k] is None for k in ('主体','対象','目的')) and t['文脈']=={} for t in ts)
assert all(t['対象系境界']==b and len(t['内容'])==2 for t in ts)
assert not b.startswith('@HDS:')
assert all(isinstance(k,str) and not k.startswith('@HDS:') for t in ts for k in t['内容'])
assert all(isinstance(v,(str,bool)) for t in ts for v in t['内容'].values())
assert all(o['値']['対象系境界']!=b for o in s['台帳']['観測台帳'])
assert all(p['値']['対象系境界']!=b for ps in s['原理履歴'].values() for p in ps)
rows=[tuple(t['内容'].values()) for t in ts]; proofs=[]
for n in range(1,7):
 forward={}; reverse={}; fc=False;rc=False
 for a,z in rows[:n]:
  fc |= a in forward and forward[a]!=z;rc |= z in reverse and reverse[z]!=a
  forward[a]=z;reverse[z]=a
 proofs.append({'prefix':n,'forward':n>=3 and len(forward)>=2 and not fc,'reverse':n>=3 and len(reverse)>=2 and not rc,'table_rows':len(forward),'all_non_equivalent':all(a!=z for a,z in rows[:n])})
assert [p['forward'] for p in proofs]==[False,False,True,True,True,True]
assert not any(p['reverse'] for p in proofs)
lineage=repr((b,'決定的対応関係',((next(iter(ts[0]['内容'])),),),(list(ts[0]['内容'])[1],)))
assert len(lineage.encode())<=1024
result={'native_executions':0,'state_sha256':hashlib.sha256(STATE.read_bytes()).hexdigest(),'state_bytes':STATE.stat().st_size,'dataclass_counts':dict(seen),'all_existing_dataclass_fields_and_order_match_frozen_source':True,'state_top_fields':list(s),'identifier_counters':s['識別子状態'],'ledger_counts':{k:len(v) for k,v in s['台帳'].items()},'state_history_length':len(s['状態履歴']),'principle_history_lengths':{k:len(v) for k,v in s['原理履歴'].items()},'teacher_sha256':hashlib.sha256(TEACH.read_bytes()).hexdigest(),'teacher_only_content_boundary_keys':True,'new_boundary_absent_all_principle_history':True,'two_inferred_leaf_paths_four_total_observations':True,'prefix_facts':proofs,'lineage_bytes':len(lineage.encode()),'source_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in CORE.glob('*.py')},'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(BASE/'arc-teach-bound-review-20261019/static_audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in result.items() if k not in ('source_hashes','principle_history_lengths')},ensure_ascii=False,indent=2))
