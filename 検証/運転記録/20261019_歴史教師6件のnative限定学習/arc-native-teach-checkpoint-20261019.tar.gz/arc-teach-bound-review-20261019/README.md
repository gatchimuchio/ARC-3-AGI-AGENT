# Independent static native-teacher resource review

Status: BOUNDED PASS for static state-growth, external reply, and exact input byte envelopes. Final caller/resource admission remains separate and is not supplied by this review. No native import, restore, persistence, Query, Teach, SDK, Action, or Git change was performed. All execution was plain JSON/AST analysis under 512 MiB AS, with output restricted to this review directory and well below 96 MiB.

Read the Owner directive and both additions, nearest AGENTS, authority hierarchy, current state, teacher witness review, and native guard review. Strategy remains null and automatic transition false.

## State growth

The corrected preflight proof was copied and reproduced as reviewed_preflight_bound.py (source SHA256 b6179da339ad870372181a0a3e8175bd3f03a6083b9c67d1325cf9fdbb4af436). See static_growth_bound.json and preflight_reproduction.log. Independent audit_static.py checks baseline and teacher facts; see static_audit.json. Its first run stopped at an overstrict assertion about teacher top-level fields; corrected to require the actual null metadata and empty context, then passed. No native operation occurred on either run.

Baseline is 5,355,957 bytes, SHA256 f7e5f8c7518b43c7e53f6a1c43f108469c04f72e5d13eb30aa2fae987e2d6e6a. Every existing dataclass has exactly the frozen source field set and field order; restoration cannot silently add missing defaults. All seven persisted top-level fields are covered. Query changes paired counters only (6660 plus at most38; still four decimal digits). Other counters remain below six decimal digits. Identifier placeholders32 and timestamp32 dominate this sequence.

Independent data facts and frozen branch review establish two inferred leaves and two metadata observations per teacher; exact new boundary absent from all183 experiences and all principle history; deterministic forward candidate only at prefixes3–6; no reverse candidate, same-value relation, excluded-experience continuation, isolation, strict-subset parent, reopening, or residual branch. Actual lineage is199 UTF-8 bytes. Three distinct tables permit at most3 adoptions; the sixth duplicate does not create another principle version or refresh old support references. No preexisting history record is modified.

Per teacher: experience + cognitive + five doubts + learning + completion =9 ledger records, total54. Four candidates each append inference/evidence/judgment =12. Three adoptions each append principle/provisional/update =9; principle history duplicates3; snapshots3. Total81 new objects plus one32KiB structural reserve. All appended record roots are shallower than padding depth12. The explicit wire envelopes retain real field/key names, tuple/dictionary/dataclass wrappers, enum representations, nested aggregates, all references, and full old snapshot plus padded new lineage. Largest padded object13,866 bytes; each fits32KiB. Existing wrappers, one new lineage entry, commas and counter-width changes fit the separate32KiB spare. The corrected experience envelope uses false to dominate both boolean widths, and JSON-escaped source literal widths are checked.

Full-state conservative upper bound: 5,355,957 +82*32,768 =8,042,933 bytes <8,388,608. Prefix failure states cannot exceed this append count, including history appended before a later state update fails. This establishes a byte bound, not successful persistence or sufficient native execution RAM.

## Replies and allocation

Independent scan:15 current active principles, no isolated principles, at most2 per boundary, and exactly1 per (boundary,result path). Each has1 condition path. The new lineage is in a separate boundary. Therefore both prediction conflicts and global ambiguity groups are empty for this sequence, even though native ambiguity detection scans all active principles. Old native output-value JSON max8 bytes; condition-path JSON max72 bytes. Old active summaries must still all appear in the reply bound.

Worker reply_bound.py has the right broad shape: all15 exact old projections plus new padded projection,2 predictions and2 requests simultaneously,6 padded HOLD reasons, and combined Query/Teach trace keys. Proposed49,601 bytes <64KiB is conditional on final input scalar/path/boundary width assertions. Do not turn static boundary absence into an assumed native HOLD result or suppress actual negative/HOLD replies.

Ten single-use8MiB state slots plus8MiB evidence and four1MiB disjoint regions reserve92MiB. Source state must remain external read-only (worker confirmed), because a separate5.36MB copy would exceed the remaining4MiB. All preparation inputs/code/reports and prior failed partial allocations within the task allocation must be measured before admission; no retry reuses or deletes partial slots. Evidence framing overhead must be counted. Full teacher checkpoints suffice for later full-state deltas; another full serialized delta copy is not silently budgeted.

Final admission still needs the exact19+6+19 method/input plan, nine regression input pins/width bounds, complete caller/source hashes and native loaded binding checks, measured existing bytes plus all reservations <=96MiB, complete failure retention/frontier policy, and parent authorization. Storage caps/free-space checks do not guarantee allocator, ENOSPC, kernel, or machine failure survivability. Unknown frontier stays UNKNOWN and prohibits automatic resumption. No SDK/Action or runtime adoption follows from this review.

## Supplementary reproduction

Reviewed reply_bound.py SHA256 e5f9106caf07f30543f3815b0458cddbe2e353e8da44b6831eba9c62bf67e281 was copied as reviewed_reply_bound.py with only the import changed to the local reviewed preflight copy. Reproduction yields exactly49,601 bytes; output is in static_reply_bound.json/reply_reproduction.log. Thirteen provided pure guard fixtures were copied and rerun under512MiB AS; all pass (pure_guard_tests.log). These do not load native bindings or admit a launcher. Final regression scalar/path-width closure is still required.

## Final exact-input closure

The pending input-width condition is now closed by audit_inputs.py and input_audit.json. All6 teachers and19 query payloads were independently checked. The9 old-boundary queries are pinned at SHA25615e83ab6a7caacdcaf62c1585eef3f450de1bd6abc9da78276de9b0d45cec44c. All payloads have exactly the6 expected external-input fields, null subject/object/purpose, empty context, and flat content with ordinary non-reserved string keys and scalar string/bool values. Across all inputs: maximum native-shaped input505bytes, atom JSON50bytes, path JSON62bytes, boundary JSON152bytes. These are below the reply envelope's512/128/512 limits and8KiB input allowance. The49,601-byte external reply bound therefore closes for this frozen input set.

Conservative framed evidence allowance:44*65536 reply bytes +88*8192 input/postinput bytes +10*16384 snapshot indices +142*(256+8) frame overhead =3,805,808bytes <8MiB. Ten indices conservatively allow an extra failure receipt; normal flow uses9. No full-state delta duplication is budgeted. This review does not admit an altered caller that appends other large content.

The9 historical queries establish only one-case-per-existing-boundary smoke regression coverage. They do not establish exhaustive prior-success behavior or complete no-regression. Preserve every native outcome, including false/HOLD/negative/exception, without changing that scope. Final launcher/source/input pins, aggregate existing-byte measurement and92MiB reservations, known-writer/failure policy, and parent's explicit admission are still required before any native call.
