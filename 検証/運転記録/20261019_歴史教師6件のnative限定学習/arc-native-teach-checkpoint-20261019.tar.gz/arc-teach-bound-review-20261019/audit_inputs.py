import hashlib,json,pathlib,resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
B=pathlib.Path(__file__).resolve().parent.parent
paths=['goal6_teachers.runtime.json','goal6_matched_queries.runtime.json','existing_four_row_queries.runtime.json','regression_v2/nine_queries.runtime.json']
def enc(x):
 if isinstance(x,dict):return {'__辞書__':[[enc(k),enc(v)] for k,v in x.items()]}
 if isinstance(x,tuple):return {'__組__':[enc(v) for v in x]}
 if isinstance(x,list):return [enc(v) for v in x]
 return x
reports=[]; all_rows=[]
for path in paths:
 p=B/'arc-teacher-contrasts-20261019'/path; rows=json.loads(p.read_bytes());all_rows+=rows
 for t in rows:
  assert set(t)=={'内容','対象系境界','主体','対象','目的','文脈'}
  assert all(t[k] is None for k in ('主体','対象','目的')) and t['文脈']=={}
  assert isinstance(t['内容'],dict) and 1<=len(t['内容'])<=2
  assert all(isinstance(k,str) and not k.startswith('@HDS:') for k in t['内容'])
  assert all(isinstance(v,(bool,str)) for v in t['内容'].values())
 wire=[{'__データ型__':'外部入力','値':{k:enc(v) for k,v in t.items()}} for t in rows]
 report={'path':path,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'count':len(rows),'max_input_wire_bytes_indent2':max(len(json.dumps(w,ensure_ascii=False,indent=2).encode()) for w in wire),'max_atom_json_bytes':max(len(json.dumps(v,ensure_ascii=False).encode()) for t in rows for v in t['内容'].values()),'max_path_json_bytes':max(len(json.dumps(k,ensure_ascii=False).encode()) for t in rows for k in t['内容']),'max_boundary_json_bytes':max(len(json.dumps(t['対象系境界'],ensure_ascii=False).encode()) for t in rows)}
 assert report['max_input_wire_bytes_indent2']<8192
 assert report['max_atom_json_bytes']<=512 and report['max_path_json_bytes']<=128 and report['max_boundary_json_bytes']<=512
 reports.append(report)
assert [r['count'] for r in reports]==[6,6,4,9]
q=all_rows[6:]; assert len(q)==19
# Headers conservatively include 256-byte UTF-8 metadata plus8-byte prefix.
bound=44*65536+88*8192+10*16384+142*264
r={'native_executions':0,'inputs':reports,'exact_call_counts':{'queries_before':19,'teachers':6,'queries_after':19},'conservative_evidence_bytes_including_10_indices_and_all_frame_headers':bound,'evidence_reserved_bytes':8*1024**2,'pass':bound<8*1024**2,'limitations':'Nine old-boundary inputs are one-case-per-boundary smoke tests, not exhaustive behavioral regression.'}
(B/'arc-teach-bound-review-20261019/input_audit.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));print(json.dumps(r,ensure_ascii=False,indent=2))
