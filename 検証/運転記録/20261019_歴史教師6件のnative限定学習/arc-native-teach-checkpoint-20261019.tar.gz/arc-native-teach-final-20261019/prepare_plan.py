"""Freeze exact proposed sequence. Never admits or runs native work."""
import pathlib,json,hashlib,resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
R=pathlib.Path(__file__).resolve().parent; B=R.parent; C=B/'arc-teacher-contrasts-20261019'
sources=[C/'goal6_matched_queries.runtime.json',C/'existing_four_row_queries.runtime.json',C/'regression_v2/nine_queries.runtime.json',C/'goal6_teachers.runtime.json']
blocks=[json.loads(p.read_bytes()) for p in sources];assert list(map(len,blocks))==[6,4,9,6]
queries=sum(blocks[:3],[]);teachers=blocks[3]
plan=[{'method':'照会する','input':x} for x in queries]+[{'method':'処理する','input':x} for x in teachers]+[{'method':'照会する','input':x} for x in queries]
assert len(plan)==44
for row in plan:
 x=row['input'];assert set(x)=={'内容','対象系境界','主体','対象','目的','文脈'}
 assert all(x[k] is None for k in ('主体','対象','目的')) and x['文脈']=={}
 assert len(json.dumps(x['対象系境界'],ensure_ascii=False).encode())<=512
 assert isinstance(x['内容'],dict) and 1<=len(x['内容'])<=2
 for k,v in x['内容'].items():
  assert type(k) is str and len(json.dumps(k,ensure_ascii=False).encode())<=128
  assert type(v) in (bool,str) and len(json.dumps(v,ensure_ascii=False).encode())<=512
paths=sources+[B/'arc-native-query-20261019/query_retry02/poststate.json']+list((B/'arc-native-query-20261019/frozen/HDS/学習系統/v0.4.2/hds学習系統').glob('*.py'))+list(R.glob('*.py'))
config={'explicit_parent_admission':False,'state_upper_bound_bytes':8042933,'scope':'exact endpoint acquisition plus13-case old-boundary/control smoke regression only','plan':plan,'pins':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},'resource':{'AS_MiB':512,'directory_MiB':96,'aggregate_retained_plus_final_MiB':296,'fixed_reservations_MiB':92,'cpu_seconds':120,'wall_seconds':240},'evidence_upper_bound_bytes':3805808,'evidence_reserved_bytes':8388608,'source_bytes':5355957,'baseline_counter':6660,'regression_scope':'one exact archived native input each9boundary plus4control rows; no full prior-success regression claim'}
config['retained_previous_directories']=[str(B/name) for name in ('arc-native-teach-20261019','arc-native-teach-retry-20261019','arc-native-bootstrap-diagnostic-20261019')]
config['retained_manifests']={str(B/name/file):hashlib.sha256((B/name/file).read_bytes()).hexdigest() for name,file in [('arc-native-teach-20261019','failed_attempt_manifest.json'),('arc-native-teach-retry-20261019','failed_attempt_manifest.json'),('arc-native-bootstrap-diagnostic-20261019','bootstrap_pass_manifest.json')]}
(R/'proposed_config.json').write_text(json.dumps(config,ensure_ascii=False,indent=2))
summary={'calls':44,'queries':38,'processing':6,'before_queries':19,'after_queries':19,'source_pins':{str(p.relative_to(B)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},'native_executions':0,'explicit_parent_admission':False,'existing_directory_bytes':sum(p.stat().st_size for p in R.rglob('*') if p.is_file()),'fixed_reservations_bytes':92*1024**2,'max_directory_bytes':96*1024**2,'evidence_upper_bound_bytes':3805808}
assert summary['existing_directory_bytes']+summary['fixed_reservations_bytes']<=summary['max_directory_bytes']
(R/'proposed_admission.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));print(json.dumps(summary,ensure_ascii=False,indent=2))
