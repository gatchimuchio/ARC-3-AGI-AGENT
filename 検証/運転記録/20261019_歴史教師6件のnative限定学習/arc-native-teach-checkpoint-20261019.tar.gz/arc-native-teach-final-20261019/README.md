# Native teacher pilot after real bootstrap validation

Preparation only; parent full-pilot admission pending. Two earlier attempts retained intact: both held during bootstrap, with zero Query/processing/save. First omitted importlib-generated package attributes; second omitted Enum._generate_next_value_ staticmethod. A separate admitted read-only native bootstrap diagnosed the exact member and then passed the minimally corrected binding, with zero Query/processing/save. Actual metadata and full source versions are retained in ../arc-native-bootstrap-diagnostic-20261019.

This caller uses that actual-passed binding SHA43574797de492ef1a49b7498ee23a4ac410935b6c1dc0432baa7b43b17a52720 and detailed metadata-only failures. Launcher, Guard, exact44method/input plan, state6660, frozen nativev0.4.2, budgets and prefix checks are unchanged. Detailed bounded_store is behavior-equivalent on valid paths; only failure diagnostics changed. No native core changes.

Same analytical bounds: state<=8,042,933B under8MiB; reply<=49,601B under64KiB; input<=505B under8KiB; framed evidence<=3,805,808B under8MiB. Same6historical endpoint teachers,19before+6process+19after, four control and nine existing-boundary smoke regressions. Fixed mask prior and77 unknown phases; no fresh evidence, generalization, complete regression, adoption, SDK/liveAction/Git.

Proposed new96MiB ceiling includes fresh92MiB fixed reservations,3MiB reports and all preparation. Retained two96MiB attempt ceilings plus8MiB diagnostic plus new96MiB require explicit296MiB aggregate ceiling; no deletion/reuse of previous reserves. AS512MiB CPU120s wall240s; freefloor1GiB. Parent admission and final source review required before allocation/execution.
