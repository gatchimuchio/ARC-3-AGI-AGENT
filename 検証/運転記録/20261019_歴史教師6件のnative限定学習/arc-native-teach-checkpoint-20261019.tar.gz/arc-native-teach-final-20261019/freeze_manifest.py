import pathlib,json,hashlib,resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
B=pathlib.Path(__file__).resolve().parent.parent
roots=[B/x for x in ('arc-native-teach-20261019','arc-native-teach-retry-20261019','arc-native-bootstrap-diagnostic-20261019','arc-native-teach-final-20261019')];R=roots[-1]
def allzero(handle):return all(not any(b) for b in iter(lambda:handle.read(1024**2),b''))
entries=[]
for root in roots:
 for p in root.rglob('*.reserve'):
  size=p.stat().st_size;region=p.stem;framed=[]
  with p.open('rb') as f:
   first=f.read(8);f.seek(0)
   if root.name=='arc-native-bootstrap-diagnostic-20261019':
    n=int.from_bytes(f.read(8),'big');body=f.read(n);json.loads(body);prefix=8+n;kind='uint64_length_then_json';blank=allzero(f)
   elif region.endswith('_state'):
    if first==b'\0'*8:prefix=0;kind='unused_native_state_reservation';blank=allzero(f)
    else:json.load(f);prefix=size;kind='full_native_json_state';blank=True
   else:
    prefix=0;kind='framed_native_or_metadata_records'
    while True:
     hlen=f.read(8)
     if not hlen or hlen==b'\0'*8:f.seek(prefix);blank=allzero(f);break
     n=int.from_bytes(hlen,'big');assert n<=1024
     head=f.read(n);m=json.loads(head);payload=f.read(m['bytes']);assert len(payload)==m['bytes'] and hashlib.sha256(payload).hexdigest()==m['sha256']
     framed.append({'offset':prefix,'frame_bytes':8+n+len(payload),**m});prefix+=8+n+len(payload)
  assert blank
  capacity=1048576 if region in ('metadata_logs','worker_failure','worker_emergency','supervisor_failure') or root.name=='arc-native-bootstrap-diagnostic-20261019' else 8388608
  entries.append({'path':str(p.relative_to(B)),'actual_file_bytes':size,'logical_capacity_bytes':capacity,'valid_prefix_bytes':prefix,'tail_all_zero_or_no_tail':blank,'kind':kind,'records':framed})
index={'scope':'all3attempts and2bootstrap diagnostic outputs','no_deleted_or_reused_reservations':True,'outcome_independent_review':'pending','entries':entries}
with (R/'reserve_prefix_index.json').open('x') as f:json.dump(index,f,ensure_ascii=False,indent=2)
files={}
for root in roots:
 for p in root.rglob('*'):
  if not p.is_file():continue
  h=hashlib.sha256()
  with p.open('rb') as f:
   for b in iter(lambda:f.read(1024**2),b''):h.update(b)
  files[str(p.relative_to(B))]={'bytes':p.stat().st_size,'sha256':h.hexdigest()}
manifest={'status':'EXECUTED_BOUNDED_RESULT_INDEPENDENT_OUTCOME_REVIEW_PENDING','native_calls_final':44,'prior_failed_attempt_query_processing_calls':[0,0],'diagnostic_query_processing_save_calls':[0,0],'roots':[p.name for p in roots],'files':files,'referenced_external_inputs_and_source_pins':json.loads((R/'proposed_config.json').read_bytes())['pins'],'notes':['initial preparatory pre-fix sources partly missing, see preparation_history.md','all original full reservation bytes retained','one new lineage3versions, no generalization/adoption claim']}
with (R/'freeze_manifest.json').open('x') as f:json.dump(manifest,f,ensure_ascii=False,indent=2)
print('files',len(files),'total_bytes',sum(x['bytes'] for x in files.values()),'reserve_entries',len(entries),'manifest_bytes',(R/'freeze_manifest.json').stat().st_size)
