# Corrected native teacher pilot preparation

Status: no native retry admitted or executed. First attempt is retained unchanged under ../arc-native-teach-20261019/run01, with exact source/config pins and failed_attempt_manifest.json. It performed native codec/restore bootstrap, then held before the first Query or processing call at 'unexpected native module global'. Entered/returned/persisted calls are all0, no native save occurred. No learned state or result is claimed.

## Diagnosis and minimal correction

Static pinned __init__.py imports symbols from relative submodules; Python importlib also installs the loaded modules themselves as parent-package attributes. Transitive modules include 型,台帳,懐疑,推論,検証,適応,永続化,吸気系,排気系,実行系,系統. The prior AST-only declared-global list omitted these interpreter-generated package attributes. Independent reviewer agrees on this mechanism. The original exception did not name the rejected attribute, so its exact first name was not captured; this diagnosis is source/import-semantics based, not a second native observation.

Only binding.py changes native-launch behavior. package_import_attributes allows direct child attributes only on package hds学習系統, with exact expected module name, ModuleType, identity equal to sys.modules, exact pinned root/file and source hash. Other globals remain rejected. Errors retain rejected module/global/type/path, never arbitrary value contents. Eight synthetic tests pass, including foreign module identity/path/name/source and nonmodule rejection. The old source remains under source_before_patch. No HDS code, payload, method/count/order, or learning algorithm is changed.

## Exact experiment and resource plan

Same44-call plan:19Query(6goal6+4control+9boundary smoke),6 actual processing inputs,19 identical Queries. Same frozen state6660,5,355,957bytes. All earlier witness and static growth/reply reviews apply because source/input sequence unchanged: state<=8,042,933bytes; reply<=49,601bytes; exact input<=505bytes; framed evidence<=3,805,808bytes. Full per-teacher states and original ledger/history prefixes retained. Historical endpoints are not new observations or generalization; fixedmaskprior77unknownphases; nine old-boundary queries are smoke only.

New directory ceiling proposed96MiB, with fresh92MiB fixed reservations and3MiB final-report allowance. First directory's92MiB reservations are retained, never reused or erased. Combined two-directory ceiling proposed192MiB, explicitly requiring parent's separate admission. Actual sizes and free-space floor must be remeasured before any retry. 512MiB AS,120sCPU,240swall unchanged. No additional retry follows automatically. Filesystem failures can still prevent complete retention after native truncation; unknown frontier stays UNKNOWN. No SDK,liveAction,Git,adoption.
