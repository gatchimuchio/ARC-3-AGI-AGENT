#!/bin/sh
set -u
cd /workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019/publication_native_copy/inspection_runs/run04
ulimit -v 262144
ulimit -f 160
PYTHONDONTWRITEBYTECODE=1 python3 source.py >stdout.log 2>stderr.log
status=$?
printf '%s\n' "$status" >exit_status.txt
exit "$status"
