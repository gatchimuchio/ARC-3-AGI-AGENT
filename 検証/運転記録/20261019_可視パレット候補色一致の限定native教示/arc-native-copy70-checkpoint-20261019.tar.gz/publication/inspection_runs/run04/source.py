"""Final exact-list reconciliation and inert added-measurement content scan."""
import ast,collections,hashlib,json,pathlib,re,resource,sys
resource.setrlimit(resource.RLIMIT_AS,(256*1024**2,)*2)
resource.setrlimit(resource.RLIMIT_FSIZE,(80*1024,)*2)
sys.dont_write_bytecode=True
W=pathlib.Path('/workspace/scratch/a94ff513b3af');O=pathlib.Path(__file__).resolve().parent;P=O.parents[1]
sha=lambda b:hashlib.sha256(b).hexdigest()
finalraw=(P/'payload_manifest.json').read_bytes();assert sha(finalraw)=='2ea33604236055cd393f99a3fc42324e4a8d38ed874b7239ed5ddb482c87eff5'
final=json.loads(finalraw);partial=json.loads((P/'partial_payload_manifest.json').read_bytes());old={x['archive_path']:x for x in partial['files']};new={x['archive_path']:x for x in final['files']}
assert len(new)==len(final['files'])==358 and len(old)==284
assert all(new[k]==v for k,v in old.items())
allowp=W/'arc-copy-measurement-preservation-20261019/run01/allowlist.json';allowraw=allowp.read_bytes();assert sha(allowraw)=='2c42b60207e068d7cc9b51061c2dd31daa88d18f19c0db686a7d2b8c87980dd9'
allow=json.loads(allowraw);assert len(allow['files'])==68
allowed={x['path']:x for x in allow['files']};captureprefix='arc-copy-measurement-preservation-20261019/run01/'
added={k:v for k,v in new.items() if k not in old}
assert len(added)==74 and set(added)==set(allowed)|{captureprefix+x for x in ('allowlist.json','allowlist.py','exit_status.txt','source_before_execution.txt','stderr.txt','stdout.txt')}
assert all(added[k]['bytes']==v['bytes'] and added[k]['sha256']==v['sha256'] for k,v in allowed.items())
assert sum(v['bytes'] for v in new.values())==final['raw_bytes']==95287868
assert sum(v['bytes'] for v in allowed.values())==allow['total_bytes']==15999013
counts=collections.Counter();findings=collections.defaultdict(dict);files=[];asts=[];schemas=[];scalar_max=0;long_scalars={}
patterns={
 'private_key':re.compile(r'-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----'),
 'credential_token':re.compile(r'\b(?:AKIA[0-9A-Z]{16}|gh[pousr]_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{30,}|sk-(?:proj-)?[A-Za-z0-9_-]{20,}|xox[baprs]-[A-Za-z0-9-]{20,})\b'),
 'bearer':re.compile(r'(?i)\bBearer\s+[A-Za-z0-9._~+/-]{15,}'),
 'credential_assignment':re.compile(r'''(?i)(?:password|passwd|api[_-]?key|access[_-]?token|secret[_-]?key)\s*[=:]\s*["']?([^\s,"';}]{7,})'''),
 'email':re.compile(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}'),
 'sensitive_identity':re.compile(r'(?i)\b(?:SSN|social security|passport|credit.?card|bank.?account|IBAN)\b|マイナンバー|患者|診断|住所|電話番号'),
 'original_manuscript':re.compile(r'(?i)(?:HDS.{0,40}(?:original|manuscript|theory paper))|理論原稿|理論論文|HDS理論|HDS.{0,20}原稿'),
 'external_url':re.compile(r'https?://[^\s<>\"\)\]}]+'),
 'opaque_encoded':re.compile(r'(?<![A-Za-z0-9+/])[A-Za-z0-9+/]{160,}={0,2}(?![A-Za-z0-9+/])')}
def textscan(s,path,loc,scalar=False):
 global scalar_max
 counts['strings_scanned']+=1;counts['chars_scanned']+=len(s)
 if scalar:
  scalar_max=max(scalar_max,len(s))
  if len(s)>400:
   h=sha(s.encode());long_scalars.setdefault(h,{'path':path,'loc':loc,'chars':len(s),'start':s[:240],'end':s[-100:]})
   assert len(long_scalars)<60
 for kind,rx in patterns.items():
  for m in rx.finditer(s):
   key=m.group(0);v=findings[kind].setdefault(key,{'path':path,'loc':loc,'context':s[max(0,m.start()-80):m.end()+80][:500],'count':0});v['count']+=1
   assert len(findings[kind])<40
def walk(x,path,loc='$',depth=0):
 counts['json_nodes']+=1;assert depth<80
 if isinstance(x,dict):
  for k,v in x.items():textscan(k,path,loc+'.key',True);walk(v,path,loc+'.'+k,depth+1)
 elif isinstance(x,list):
  for i,v in enumerate(x):walk(v,path,loc+'['+str(i)+']',depth+1)
 elif isinstance(x,str):textscan(x,path,loc,True)
 elif x is not None:assert type(x)in(bool,int,float)
for path,e in new.items():
 p=pathlib.Path(e['source']);assert p==W/path and p.resolve()==p and p.is_file() and not p.is_symlink() and p.stat().st_nlink==1
 raw=p.read_bytes();assert len(raw)==e['bytes'] and sha(raw)==e['sha256'],path
 counts['all_files_reverified']+=1;counts['all_bytes_reverified']+=len(raw)
 if path not in added:del raw;continue
 counts['added_files']+=1;counts['added_bytes']+=len(raw)
 if p.suffix=='.json':
  obj=json.loads(raw);walk(obj,path)
  schemas.append({'path':path,'root_type':type(obj).__name__,'root_keys':list(obj)[:30] if isinstance(obj,dict) else None,'length':len(obj) if isinstance(obj,(dict,list))else None});del obj;kind='json'
 else:
  content=raw.decode('utf-8');textscan(content,path,'whole text')
  if p.suffix=='.py':
   tree=ast.parse(content,filename=path)
   for n in ast.walk(tree):
    if isinstance(n,ast.Constant) and isinstance(n.value,str):textscan(n.value,path,'AST '+str(n.lineno))
   asts.append({'path':path,'functions':[n.name for n in ast.walk(tree)if isinstance(n,ast.FunctionDef)],'imports':sorted({n.module or '' for n in ast.walk(tree)if isinstance(n,ast.ImportFrom)}|{a.name for n in ast.walk(tree)if isinstance(n,ast.Import)for a in n.names})});kind='python_ast'
  else:kind='markdown' if p.suffix=='.md' else 'own_text'
 files.append({'path':path,'kind':kind});counts[kind]+=1;del raw
S=W/'arc-widepaint-operation-teachers-20261019';Q=S/'copy6_qualified_v2/run01'
ancestor=json.loads((S/'run01/cohorts.json').read_bytes());qualified=json.loads((Q/'all6_cohorts_full584_joins.json').read_bytes());teachers=json.loads((Q/'teachers.runtime.json').read_bytes());queries=json.loads((Q/'queries.runtime.json').read_bytes())
assert len(ancestor)==85 and len(qualified)==len(teachers)==len(queries)==6
assert teachers==json.loads((W/'arc-copy-pilot-plan-20261019/teachers.runtime.json').read_bytes())
X='候補色は選択された可視パレット色と一致';Y='候補色は観測後の可視器具色と一致';B='公開パレット選択色役割と観測後器具色役割の候補色一致・既存可視配置範囲'
pairs={};candidate_count=negative=0;indices=set();sources=set()
for i,c in enumerate(qualified):
 j=c['original_cohort_index'];assert j not in indices;indices.add(j)
 orig=ancestor[j];assert c['all_members']==orig['all_members']
 assert len(c['outcomes'])==len(orig['all_outcomes'])==1
 assert teachers[i]==c['outcomes'][0]['teacher_runtime'] and queries[i]==c['query_runtime']
 assert sorted(c['outcomes'][0]['original_member_indices'])==list(range(len(c['all_members'])))
 for p in (teachers[i],queries[i]):
  assert set(p)=={'内容','対象系境界','主体','対象','目的','文脈'} and p['対象系境界']==B and p['文脈']=={}
  assert all(p[k]is None for k in ('主体','対象','目的')) and all(type(v)is bool for v in p['内容'].values())
 for member in c['all_members']:
  candidate_count+=1;pair=tuple(member['pair']);sources.add(pair[0])
  assert member['action']['id']==6
  selected=member['candidate_palette_color']==member['selected_palette_role_color'];observed=member['candidate_palette_color']==member['observed_result_tool_color']
  assert selected is teachers[i]['内容'][X] and observed is teachers[i]['内容'][Y] and selected is observed
  negative+=not selected
  fact=(member['old_tool_color'],member['selected_palette_role_color'],member['observed_result_tool_color'])
  assert pair not in pairs or pairs[pair]==fact;pairs[pair]=fact
assert indices=={i for i,c in enumerate(ancestor)if '候補色は参照役割色と一致' in c['observed_input_condition']}
assert candidate_count==584 and negative==483 and len(pairs)==101 and len(sources)==3
assert sum(a!=b for a,b,c in pairs.values())==98 and sum(a==b for a,b,c in pairs.values())==3
assert all(b==c for a,b,c in pairs.values())
readme=(P/'README.md').read_bytes();assert len(readme)==7135 and sha(readme)=='78da2d87396dda0625629663939d9a56dd95d785a23b811d7e214ee8aa8b09ef'
textscan(readme.decode(),'publisher README.md','whole text')
report={'status':'FINAL_PAYLOAD_SCAN_AND_MEASUREMENT_JOIN_PASS_REQUIRES_REVIEW','payload_manifest_sha256':sha(finalraw),'measurement_allowlist_sha256':sha(allowraw),'counts':dict(counts),'old284_identical_to_partial_manifest':True,'exact74_added_files':True,'findings':dict(findings),'maximum_json_scalar_characters':scalar_max,'long_json_scalars':list(long_scalars.values()),'added_file_classes':files,'added_source_AST':asts,'json_schemas':schemas,'measurement_semantics':{'mixed_ancestor_cohorts':85,'qualified_cohorts':6,'full_original_members_equal':True,'exact_teachers_equal_native_plan':True,'candidate_members':candidate_count,'negative_candidates':negative,'actual_palette_click_pairs':len(pairs),'recordings':len(sources),'changed_tool_clicks':98,'already_equal_clicks':3,'native_action_calls_by_inspector':0},'readme_sha256':sha(readme),'maxrss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'non_dereference':'External raw recordings, FileRefs, HDS source references and all excluded active work were not opened.'}
out=json.dumps(report,ensure_ascii=False,indent=2)+'\n';assert len(out.encode())<70*1024
(O/'final_scan.json').write_text(out)
print(json.dumps({k:v for k,v in report.items()if k not in ('added_file_classes','added_source_AST','json_schemas')},ensure_ascii=False,indent=2))
