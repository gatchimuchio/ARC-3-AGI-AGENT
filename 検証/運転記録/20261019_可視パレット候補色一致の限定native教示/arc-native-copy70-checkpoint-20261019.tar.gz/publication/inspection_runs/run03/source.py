"""Inspect native wire textual field classes without disclosing full state."""
import collections,hashlib,json,pathlib,resource,sys
resource.setrlimit(resource.RLIMIT_AS,(256*1024**2,)*2)
resource.setrlimit(resource.RLIMIT_FSIZE,(30*1024,)*2)
sys.dont_write_bytecode=True
W=pathlib.Path('/workspace/scratch/a94ff513b3af');O=pathlib.Path(__file__).resolve().parent
R=W/'arc-native-copy-20261019/run01';types=collections.Counter();enums=collections.Counter();long={};boundaries=set();maximum={'characters':0};count=0
def walk(x,loc='$'):
 global count,maximum
 if isinstance(x,dict):
  if '__データ型__' in x:types[x['__データ型__']]+=1
  if '__列挙__' in x:enums[(x['__列挙__'],str(x.get('値')))]+=1
  if '対象系境界' in x and isinstance(x['対象系境界'],str):boundaries.add(x['対象系境界'])
  for k,v in x.items():walk(v,loc+'.'+k)
 elif isinstance(x,list):
  for i,v in enumerate(x):walk(v,loc+'['+str(i)+']')
 elif isinstance(x,str):
  count+=1
  if len(x)>maximum['characters']:maximum={'characters':len(x),'location':loc,'value':x[:400]}
  if len(x)>200 and not (x.startswith("('") or len(x)==64):
   h=hashlib.sha256(x.encode()).hexdigest()
   if h not in long:long[h]={'characters':len(x),'location':loc,'value':x[:600]}
   assert len(long)<=40
for name in ['normal_state','before_state']+[f'teach_{i:02d}_state' for i in range(1,7)]+['post_state']:
 x=json.loads((R/(name+'.reserve')).read_bytes());walk(x);del x
report={'status':'NATIVE_WIRE_TEXT_TAXONOMY_COMPLETE','strings_seen':count,'data_types':dict(types),'enum_values':[{'type':k[0],'value':k[1],'count':v} for k,v in sorted(enums.items())],'boundaries':sorted(boundaries),'long_non_lineage_strings':list(long.values()),'maximum_string':maximum,'payload_modules_imported':0,'maxrss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
out=json.dumps(report,ensure_ascii=False,indent=2)+'\n';assert len(out.encode())<30*1024
(O/'taxonomy.json').write_text(out);print(out)
