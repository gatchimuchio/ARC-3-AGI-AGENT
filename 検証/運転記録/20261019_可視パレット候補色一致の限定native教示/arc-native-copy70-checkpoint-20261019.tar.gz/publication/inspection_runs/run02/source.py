"""Independent data-only semantic crosscheck within four closed roots."""
import collections, hashlib, json, pathlib, resource, struct, sys
resource.setrlimit(resource.RLIMIT_AS,(256*1024**2,)*2)
resource.setrlimit(resource.RLIMIT_FSIZE,(80*1024,)*2)
sys.dont_write_bytecode=True
W=pathlib.Path('/workspace/scratch/a94ff513b3af');R=W/'arc-native-copy-20261019';O=pathlib.Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def normal(x):
 if isinstance(x,list):return [normal(v) for v in x]
 if isinstance(x,dict):
  if set(x)=={'__辞書__'}:return {normal(k):normal(v) for k,v in x['__辞書__']}
  if set(x)=={'__組__'}:return tuple(normal(v) for v in x['__組__'])
  return {k:normal(v) for k,v in x.items()}
 return x
def read(p):return normal(json.loads(p.read_bytes()))
def plain(x):return json.loads(json.dumps(x,ensure_ascii=False))
def frames(p):
 out=[];used=0
 with p.open('rb') as f:
  while True:
   head=f.read(8)
   if not head or head==b'\0'*8:
    assert not any(f.read());break
   assert len(head)==8;n=struct.unpack('>Q',head)[0];assert 0<n<=256
   h=json.loads(f.read(n));assert set(h)=={'name','bytes','sha256'}
   payload=f.read(h['bytes']);assert len(payload)==h['bytes'] and sha(payload)==h['sha256']
   out.append((h,payload,used));used+=8+n+len(payload)
 return out,used
c=read(R/'proposed_config.json');rows,used=frames(R/'run01/evidence.reserve');assert len(rows)==219
byname={h['name']:(h,b,o) for h,b,o in rows};assert len(byname)==len(rows)
assert [x['method'] for x in c['plan']]==['照会する']*32+['処理する']*6+['照会する']*32
assert c['plan'][:32]==c['plan'][38:]
outputs=[];previous=-1;maxin=maxout=0
for i,row in enumerate(c['plan'],1):
 prefix=f'{i:02d}.'+row['method']
 ih,ib,io=byname[prefix+'.input'];oh,ob,oo=byname[prefix+'.output'];ah,ab,ao=byname[prefix+'.input_after']
 assert previous<io<oo<ao;previous=ao;assert ib==ab
 assert normal(json.loads(ib))=={'__データ型__':'外部入力','値':row['input']}
 out=normal(json.loads(ob));assert out['__データ型__']=='外部出力';outputs.append(out['値'])
 maxin=max(maxin,len(ib));maxout=max(maxout,len(ob))
 assert len(ib)<=8192 and len(ob)<=65536
states=['normal_state','before_state']+[f'teach_{i:02d}_state' for i in range(1,7)]+['post_state']
baseline=read(R/'run01/normal_state.reserve');old=baseline;statefacts=[]
for i,name in enumerate(states):
 p=R/'run01'/(name+'.reserve');s=read(p)
 assert set(s)==set(baseline)
 for original in (baseline,old):
  assert set(original['台帳'])<=set(s['台帳']) and set(original['原理履歴'])<=set(s['原理履歴'])
  for k,v in original['台帳'].items():assert s['台帳'][k][:len(v)]==v
  for k,v in original['原理履歴'].items():assert s['原理履歴'][k][:len(v)]==v
  assert s['状態履歴'][:len(original['状態履歴'])]==original['状態履歴']
 assert all(s[k]==baseline[k] for k in baseline if k not in ('台帳','原理履歴','状態履歴','識別子状態'))
 if name in ('before_state','post_state'):
  assert all(s[k]==old[k] for k in s if k!='識別子状態')
  target=dict(old['識別子状態']);target['照会']+=32;target['学習判定']+=32;assert s['識別子状態']==target
 snap=normal(json.loads(byname['snapshot.'+name][1]));assert snap['receipt']['sha256']==sha(p.read_bytes()) and snap['receipt']['bytes']==p.stat().st_size
 assert snap['ledger_slices']=={k:[len(old['台帳'].get(k,())),len(v)] for k,v in s['台帳'].items()}
 assert snap['principle_history_slices']=={k:[len(old['原理履歴'].get(k,())),len(v)] for k,v in s['原理履歴'].items()}
 assert snap['state_history_slice']==[len(old['状態履歴']),len(s['状態履歴'])]
 statefacts.append({'name':name,'experiences':len(s['台帳']['観測台帳']),'principle_records':len(s['台帳']['原理台帳']),'query_counter':s['識別子状態']['照会'],'bytes':p.stat().st_size})
 old=s
final=s
assert len(baseline['台帳']['観測台帳'])==204 and len(final['台帳']['観測台帳'])==210
assert len(baseline['台帳']['原理台帳'])==27 and len(final['台帳']['原理台帳'])==29
assert final['識別子状態']['照会']==final['識別子状態']['学習判定']==6822
delta={'old_prefixes_equal':True,'ledger_appends':{k:v[len(baseline['台帳'].get(k,())):] for k,v in final['台帳'].items()},'principle_history_appends':{k:v[len(baseline['原理履歴'].get(k,[])):] for k,v in final['原理履歴'].items()},'state_history_appends':final['状態履歴'][len(baseline['状態履歴']):]}
assert plain(delta)==json.loads((R/'native_full_delta.json').read_bytes())
source='候補色は選択された可視パレット色と一致';target='候補色は観測後の可視器具色と一致';boundary=c['plan'][0]['input']['対象系境界']
ps=[p['値'] for p in delta['ledger_appends']['原理台帳']];assert len(ps)==2
assert {(p['条件経路群'][0][0],p['結果経路'][0]) for p in ps}=={(source,target),(target,source)}
for p in ps:
 assert p['対象系境界']==boundary and p['版']==1 and p['関係型']=='同値関係'
 assert p['根拠参照群']==('経験-000205','経験-000206','経験-000207')
 assert p['反証参照群']==p['除外反証参照群']==()
 assert all(type(v)is bool and json.loads(k[0])is v for k,v in p['対応値表'])
for i,v in enumerate(delta['ledger_appends']['観測台帳']):
 p=v['値'];assert p['原入力']==c['plan'][i+32]['input']['内容'] and p['対象系境界']==boundary
 assert p['経験識別子']==f'経験-{205+i:06d}'
 assert type(p['原入力'][source])is bool and p['原入力'][source]is p['原入力'][target]
assert len(delta['state_history_appends'])==1
judgments=[o['内容']['学習成立状態'] for o in outputs[32:38]]
assert judgments==['接続途上','接続途上','成立確認','接続途上','接続途上','接続途上']
keys=('予測群','競合群','追加観測要求群','識別不能群','係争中原理群','断定保留理由群','学習成立状態')
rawmatches=[];oldmatches=[];diagnostics=[]
producer=json.loads((R/'result_audit.json').read_bytes())
assert producer['teacher_outputs']==plain(outputs[32:38])
for i in range(32):
 a,z=outputs[i],outputs[i+38];producerrow=producer['query_comparisons'][i]
 assert producerrow['before']==plain(a) and producerrow['after']==plain(z) and producerrow['input']==c['plan'][i]['input']
 rawmatches.append(byname[f'{i+1:02d}.照会する.output'][1]==byname[f'{i+39:02d}.照会する.output'][1])
 if i<2:
  assert a['状態']=='出力' and a['内容']['学習成立状態']=='適用外' and not a['内容']['予測群']
  preds=z['内容']['予測群'];assert len(preds)==1 and type(preds[0]['予測値'])is bool
  assert preds[0]['予測値']is c['plan'][i]['input']['内容'][source] and tuple(preds[0]['結果経路'])==(target,)
  diagnostics.append({'input':c['plan'][i]['input']['内容'][source],'prediction':preds[0]['予測値'],'before_status':a['状態'],'before_learning_status':a['内容']['学習成立状態']})
 else:
  match=a['状態']==z['状態'] and all(a['内容'][k]==z['内容'][k] for k in keys)
  assert match;oldmatches.append(match)
  assert z['内容']['有効原理群'][:len(a['内容']['有効原理群'])]==a['内容']['有効原理群']
assert not any(rawmatches[2:])
logs,_=frames(R/'run01/metadata_logs.reserve');done=[normal(json.loads(b)) for h,b,o in logs if h['name']=='completed'];assert len(done)==1
done=done[0];assert done['native_calls_entered']==done['native_calls_returned']==done['fully_persisted_calls']==70
assert done['entered_methods']==[r['method'] for r in c['plan']] and done['unprocessed_suffix']['exact_remaining_calls']==0
assert all(h['name'] in ('admission','completed') for h,b,o in logs),'unexpected native log requires separate classification'
sup,_=frames(R/'run01/supervisor_failure.reserve');assert len(sup)==1 and json.loads(sup[0][1])==read(R/'native_supervisor.json')
assert json.loads(sup[0][1])['status']=='PASS'
for name in ('worker_emergency','worker_failure','failure_state'):assert not any((R/'run01'/(name+'.reserve')).read_bytes())
failures={}
for root,leaf in [('arc-native-copy-20261019','execution01'),('arc-native-copy-20261019','execution02'),('arc-native-copy-20261019','finalize01'),('arc-native-copy-20261019','finalize02'),('arc-copy-launch-review-20261019','run01'),('arc-copy-launch-review-20261019','run02'),('arc-copy-launch-review-20261019','final_execution_audit/run01'),('arc-copy-launch-review-20261019','final_execution_audit/run02')]:
 f=W/root/leaf/'exit_status.txt';failures[root+'/'+leaf]=f.read_text().strip()
assert failures['arc-native-copy-20261019/execution01']=='1' and failures['arc-native-copy-20261019/execution02']=='0'
assert failures['arc-native-copy-20261019/finalize01']=='130' and failures['arc-native-copy-20261019/finalize02']=='0'
report={'status':'INDEPENDENT_CLOSED_ROOT_SEMANTIC_PASS','calls':70,'sequence':'32 Query / 6 Teach / 32 Query','frames':219,'states':statefacts,'delta_counts':{k:len(v) for k,v in delta['ledger_appends'].items()},'new_directed_boolean_v1_principles':2,'stored_supports':[205,206,207],'retained_teachers':6,'judgments':judgments,'diagnostics':diagnostics,'all30_old_projections_equal':all(oldmatches),'all30_raw_replies_different':not any(rawmatches[2:]),'old_state_prefixes_preserved':True,'query_only_exact_paired_counter_changes':32,'producer_full_delta_equal':True,'max_input_bytes':maxin,'max_reply_bytes':maxout,'evidence_used_bytes':used,'failure_statuses':failures,'inspector_native_calls':0,'payload_imports':0,'external_file_references_dereferenced':0,'maxrss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'scope':'Semantic evidence inspection only. Original source native method bodies, older external freeze artifacts and SDK sources are not opened or executed.'}
(O/'semantic_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))
