"""Seal reviewed local-only inspection; writes no payload and performs no native calls."""
import hashlib,json,pathlib,resource,sys
resource.setrlimit(resource.RLIMIT_AS,(256*1024**2,)*2)
resource.setrlimit(resource.RLIMIT_FSIZE,(128*1024,)*2)
sys.dont_write_bytecode=True
W=pathlib.Path('/workspace/scratch/a94ff513b3af');O=pathlib.Path(__file__).resolve().parent;P=O.parents[1]
sha=lambda b:hashlib.sha256(b).hexdigest()
M=P/'payload_manifest.json';raw=M.read_bytes();mh=sha(raw);assert mh=='2ea33604236055cd393f99a3fc42324e4a8d38ed874b7239ed5ddb482c87eff5';m=json.loads(raw)
for run in ('run01','run02','run03','run04'):
 assert (P/'inspection_runs'/run/'exit_status.txt').read_text().strip()=='0'
 assert not (P/'inspection_runs'/run/'stderr.log').read_bytes()
partial=json.loads((P/'partial_payload_manifest.json').read_bytes());old={e['archive_path'] for e in partial['files']}
scan=json.loads((P/'inspection_runs/run01/scan.json').read_bytes());sem=json.loads((P/'inspection_runs/run02/semantic_report.json').read_bytes());tax=json.loads((P/'inspection_runs/run03/taxonomy.json').read_bytes());add=json.loads((P/'inspection_runs/run04/final_scan.json').read_bytes())
assert sem['status']=='INDEPENDENT_CLOSED_ROOT_SEMANTIC_PASS' and not add['findings']
assert set(scan['findings'])=={'original_manuscript'} and list(scan['findings']['original_manuscript'])==['HDS/native proofs and core were unchanged. Original']
readme=P/'README.md';assert sha(readme.read_bytes())=='78da2d87396dda0625629663939d9a56dd95d785a23b811d7e214ee8aa8b09ef'
entries=[]
for e in m['files']:
 p=pathlib.Path(e['source']);b=p.read_bytes();assert len(b)==e['bytes'] and sha(b)==e['sha256']
 name=e['archive_path'];ext=p.suffix
 kind=('typed_native_state_or_framed_zero_tail' if ext=='.reserve' else 'python_AST_and_all_string_constants' if ext=='.py' else 'all_JSON_nodes_keys_and_scalars' if ext=='.json' else 'full_UTF8_document_or_own_log')
 entries.append([name,e['bytes'],e['sha256'],kind,'run01+run02' if name in old else 'run04'])
assert len(entries)==358
admission={
 'schema':'arc3-copy70-independent-content-admission-v1',
 'verdict':'PASS_LOCAL_CONTENT_ADMISSION_ONLY',
 'admitted_for_lossless_local_archive':True,
 'publication_authorized':False,
 'Git_or_Library_writes_authorized':False,
 'public_write_blocker':'Owner clarification about historical HDS-document disclosure remains unresolved; this content admission does not clear that separate authority gate.',
 'payload_manifest':{'path':'payload_manifest.json','bytes':len(raw),'sha256':mh,'files':358,'raw_bytes':95287868},
 'publisher_README':{'bytes':readme.stat().st_size,'sha256':sha(readme.read_bytes()),'content_boundaries_reviewed':True,'baseline_main_remote_identity':'Depends on publisher separate read-only baseline verification; not independently dereferenced in this inspection.'},
 'scope':{'four_closed_roots':m['closed_full_roots'],'measurement_allowlist_sha256':'2c42b60207e068d7cc9b51061c2dd31daa88d18f19c0db686a7d2b8c87980dd9','measurement_files':68,'allowlist_capture_files':6,'measurement_parent_recursion':False,'external_FileRef_dereferences':0},
 'content_review':{
  'complete_file_contents_inspected':True,
  'method':'Full UTF-8 own-source/Markdown/log reads, Python AST and string-constant inspection, complete JSON-node/key/scalar traversal, strict typed-state decoding, length-prefixed own-evidence validation, payload hashes and zero-tail verification, then independent semantic crosschecks. Hashes alone were not used as content admission.',
  'secrets_or_sensitive_personal_data_detected':False,
  'original_HDS_theory_manuscripts_detected':False,
  'classification':'Included material is own implementation and test sources, task-derived serialization/resource reasoning and measurement contracts, typed native runtime records, bounded measurement witnesses/provenance, own logs and checkpoint explanations. Resource envelopes and learned relation records are operational derivatives, not original theory manuscripts.',
  'reviewed_false_positive':'The sole original-manuscript pattern match is the retained sentence saying earlier HDS/native proofs and core were unchanged; no manuscript body is present.',
  'native_state_max_string_characters':tax['maximum_string']['characters'],
  'added_measurement_max_JSON_scalar_characters':add['maximum_json_scalar_characters'],
  'all_358_payload_pins_rechecked':True,
  'all_284_prior_file_records_unchanged':True,
  'all74_additions_exactly_allowlisted':True},
 'native_semantics':{'actual_call_sequence':'32 Query / 6 Teach / 32 Query','entered_returned_persisted':[70,70,70],'evidence_frames':219,'full_states':9,'experiences':[204,210],'principle_records':[27,29],'paired_query_counters':[6758,6822],'new_principles':'two directed Boolean identity lineages, version1 each','stored_supports':[205,206,207],'all_six_teachers_retained':True,'third_teacher_adaptation_only':True,'before_diagnostics':'出力 / 適用外, with no predictions; not HOLD','after_diagnostics':'one strict Boolean matching prediction for each of true and false','all30_old_relevant_projections_equal':True,'all30_old_raw_replies_differ':True,'all_old_state_prefixes_retained':True,'query_only_intervals':'only exact paired +32 counter changes','full_native_delta_rederived_equal':True},
 'measurement_semantics':add['measurement_semantics'],
 'failure_preservation':{'pre_fix01_bound01_bound02':'all retained; only COPY generator observation-envelope count defect corrected from2 to4','execution01':'preallocation/preimport path-root interpretation failure retained','execution02':'corrected admitted wrapper retained','finalize01':'report-only repeated-read interruption, exit130 retained','finalize02':'report recovery without native retry retained','review_failures':'original test-adaptation failure and missing-freeze precheck retained alongside corrected PASS','generic_measurement_namespace':'original HOLD and superseded qualified proposal retained'},
 'limitations':['No fresh environment observation, Action, goal-reference learning, causal uniqueness, broad generalization, game clear, or full prior-success regression is established.','Both Boolean values were already seen. The inverse relation exists in state but was not separately queried.','Mixed TURN/MASK ancestor rows remain immutable COPY provenance; no current TURN/MASK adoption is implied.','External raw recordings, prior native/core archives, original HDS source and SDK/game bodies or SDK stderr were not opened; external historical claims remain dependent on their retained reviewer reports and pins.','Strict file/type/semantic inspection is not a hostile-code sandbox or a physical-disk/ENOSPC durability guarantee.','Archived executable own-source files are evidence, not permission to run or import them.'],
 'resources':{'inspector_AS_limit_bytes':256*1024**2,'combined_publisher_inspector_AS_limit_bytes':512*1024**2,'inspector_max_observed_RSS_KiB':max(scan['maxrss_KiB'],sem['maxrss_KiB'],tax['maxrss_KiB'],add['maxrss_KiB']),'all_inspector_outputs_cap_bytes':300*1024},
 'inspector_mutations':{'native_calls':0,'SDK_calls':0,'Action_calls':0,'Query_calls':0,'Teach_calls':0,'restores':0,'payload_source_imports':0,'Git_calls':0,'Library_calls':0,'network_calls':0,'payload_file_writes':0}
}
adbytes=(json.dumps(admission,ensure_ascii=False,indent=2)+'\n').encode()
artifacts=[]
excluded={'inspection_runs/run05/stdout.log','inspection_runs/run05/stderr.log','inspection_runs/run05/exit_status.txt'}
for f in sorted((P/'inspection_runs').rglob('*')):
 if not f.is_file():continue
 rel=str(f.relative_to(P))
 if rel in excluded:continue
 b=f.read_bytes();artifacts.append([rel,len(b),sha(b)])
manifest={'schema':'arc3-copy70-inspection-closure-v1','payload_manifest_sha256':mh,'payload_columns':['archive_path','bytes','sha256','full_content_inspection','inspection_runs'],'payloads':entries,'inspection_artifact_columns':['path','bytes','sha256'],'inspection_artifacts':artifacts,'payload_admission':{'path':'payload_admission.json','bytes':len(adbytes),'sha256':sha(adbytes)},'closure_exclusions':['inspection_manifest.json self-reference',*sorted(excluded)],'closure_exclusion_reason':'Current seal-run terminal logs cannot be hashed before their own process exits; exact source and launcher are included. Parent may pin the completed terminal logs independently.'}
manbytes=(json.dumps(manifest,ensure_ascii=False,separators=(',',':'))+'\n').encode()
existing=sum(f.stat().st_size for f in (P/'inspection_runs').rglob('*')if f.is_file())
assert existing+len(adbytes)+len(manbytes)+2048<=300*1024,(existing,len(adbytes),len(manbytes))
(P/'payload_admission.json').write_bytes(adbytes);(P/'inspection_manifest.json').write_bytes(manbytes)
assert sha((P/'payload_admission.json').read_bytes())==sha(adbytes) and sha((P/'inspection_manifest.json').read_bytes())==sha(manbytes)
print(json.dumps({'verdict':admission['verdict'],'payload_manifest_sha256':mh,'payload_admission_bytes':len(adbytes),'payload_admission_sha256':sha(adbytes),'inspection_manifest_bytes':len(manbytes),'inspection_manifest_sha256':sha(manbytes),'inspector_bytes_before_terminal_logs':existing+len(adbytes)+len(manbytes),'public_write_permission':False},indent=2))
