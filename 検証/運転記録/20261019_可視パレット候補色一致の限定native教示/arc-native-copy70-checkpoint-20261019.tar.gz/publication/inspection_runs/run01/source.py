"""Inert bounded COPY evidence content inspection. Never imports payload modules."""
import ast, collections, hashlib, json, os, pathlib, re, resource, struct, sys
resource.setrlimit(resource.RLIMIT_AS, (256 * 1024**2,) * 2)
resource.setrlimit(resource.RLIMIT_FSIZE, (100 * 1024,) * 2)
sys.dont_write_bytecode = True
W = pathlib.Path('/workspace/scratch/a94ff513b3af')
O = pathlib.Path(__file__).resolve().parent
P = W / 'arc-preservation-recovery-20261019/publication_native_copy'
M = P / 'partial_payload_manifest.json'
manifest = json.loads(M.read_bytes())
ALLOWED = set(manifest['roots'])
assert ALLOWED == {'arc-native-copy-20261019','arc-copy-pilot-plan-20261019','arc-copy-bound-review-20261019','arc-copy-launch-review-20261019'}
sha = lambda x: hashlib.sha256(x).hexdigest()
findings = collections.defaultdict(dict)
counts = collections.Counter()
vocab = collections.Counter()
longest = []
file_summaries = []
ast_summaries = {}
json_schemas = {}
seen_content = set()
patterns = {
 'private_key': re.compile(r'-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----'),
 'credential_token': re.compile(r'\b(?:AKIA[0-9A-Z]{16}|gh[pousr]_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{30,}|sk-(?:proj-)?[A-Za-z0-9_-]{20,}|xox[baprs]-[A-Za-z0-9-]{20,})\b'),
 'bearer': re.compile(r'(?i)\bBearer\s+[A-Za-z0-9._~+/-]{15,}'),
 'credential_assignment': re.compile(r'''(?i)(?:password|passwd|api[_-]?key|access[_-]?token|secret[_-]?key)\s*[=:]\s*["']?([^\s,"';}]{7,})'''),
 'email': re.compile(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}'),
 'identity_or_finance': re.compile(r'(?i)\b(?:SSN|social security|passport|credit.?card|bank.?account|IBAN)\b|マイナンバー|患者|診断|住所|電話番号'),
 'original_manuscript': re.compile(r'(?i)(?:HDS.{0,40}(?:original|manuscript|theory paper))|原(?:始|本|典).*理論|理論原稿|理論論文|HDS理論|HDS.{0,20}原稿'),
 'external_url': re.compile(r'https?://[^\s<>\"\)\]}]+'),
 'opaque_encoded': re.compile(r'(?<![A-Za-z0-9+/])[A-Za-z0-9+/]{160,}={0,2}(?![A-Za-z0-9+/])')
}
def scan_string(s, path, loc):
 counts['strings_scanned'] += 1
 counts['string_chars_scanned'] += len(s)
 for kind, pattern in patterns.items():
  for m in pattern.finditer(s):
   key = m.group(0)
   if len(findings[kind]) >= 80 and key not in findings[kind]:
    raise ValueError('too many distinct review findings: ' + kind)
   e = findings[kind].setdefault(key, {'matches':0,'first_path':path,'location':loc,'context':s[max(0,m.start()-70):m.end()+70][:500]})
   e['matches'] += 1
 if len(s)>600 and '\n' in s:
  h=sha(s.encode())
  if h not in {x['sha256'] for x in longest}:
   longest.append({'sha256':h,'chars':len(s),'path':path,'location':loc,'start':s[:180],'end':s[-100:]})
   longest.sort(key=lambda x:x['chars'],reverse=True)
   del longest[25:]
def walk(x, path, loc='$', depth=0):
 assert depth < 80
 counts['json_nodes'] += 1
 if isinstance(x,dict):
  for k,v in x.items():
   assert isinstance(k,str)
   scan_string(k,path,loc+'.key')
   if k.startswith('__') and k.endswith('__'):vocab[k]+=1
   walk(v,path,loc+'.'+k,depth+1)
 elif isinstance(x,list):
  for i,v in enumerate(x):walk(v,path,loc+'['+str(i)+']',depth+1)
 elif isinstance(x,str):scan_string(x,path,loc)
 elif x is not None:assert type(x) in (bool,int,float)
def schema(x):
 if isinstance(x,dict):return {'type':'dict','keys':list(x)[:40]}
 if isinstance(x,list):return {'type':'list','length':len(x)}
 return {'type':type(x).__name__}
def normal(x):
 if isinstance(x,list):return [normal(v) for v in x]
 if isinstance(x,dict):
  if set(x)=={'__辞書__'}:return {normal(k):normal(v) for k,v in x['__辞書__']}
  if set(x)=={'__組__'}:return tuple(normal(v) for v in x['__組__'])
  return {k:normal(v) for k,v in x.items()}
 return x
def framed(raw,path):
 rows=[];i=0
 while i<len(raw):
  if raw[i:i+8] == b'\0'*8:
   assert not any(raw[i:]),'nonzero tail '+path
   break
  assert i+8<=len(raw)
  n=struct.unpack('>Q',raw[i:i+8])[0];assert 0<n<=1024
  start=i;i+=8;h=json.loads(raw[i:i+n]);i+=n
  assert set(h)=={'name','bytes','sha256'},(path,h.keys())
  assert type(h['bytes']) is int and 0<=h['bytes']<=8*1024**2
  body=raw[i:i+h['bytes']];i+=h['bytes']
  assert len(body)==h['bytes'] and sha(body)==h['sha256']
  obj=json.loads(body);walk(obj,path,'frame:'+h['name'])
  rows.append({'name':h['name'],'bytes':h['bytes'],'offset':start,'sha256':h['sha256']})
 return rows,i
index=json.loads((W/'arc-native-copy-20261019/reserve_prefix_index.json').read_bytes())
reservations={}
for entry in manifest['files']:
 path=entry['archive_path'];p=pathlib.Path(entry['source'])
 assert pathlib.PurePosixPath(path).parts[0] in ALLOWED
 assert p==W/path and p.resolve()==p and p.is_file() and not p.is_symlink()
 assert p.stat().st_nlink==1
 raw=p.read_bytes();assert len(raw)==entry['bytes'] and sha(raw)==entry['sha256'],path
 s={'path':path,'bytes':len(raw),'sha256':sha(raw)}
 counts['files']+=1;counts['bytes']+=len(raw)
 if p.suffix=='.reserve':
  meta=index[p.name];assert meta['bytes']==len(raw) and meta['sha256']==sha(raw)
  if meta['kind']=='full native JSON state':
   obj=json.loads(raw);walk(obj,path);state=normal(obj)
   reservations[p.name]={'kind':'native_state','top_keys':list(state),'ledgers':{k:len(v) for k,v in state['台帳'].items()},'principle_histories':len(state['原理履歴']),'state_histories':len(state['状態履歴']),'counters':state['識別子状態']}
   assert meta['valid_prefix_bytes']==len(raw)
   del obj,state
  else:
   rows,used=framed(raw,path);assert used==meta['valid_prefix_bytes']
   reservations[p.name]={'kind':'framed_or_zero','frames':len(rows),'valid_prefix_bytes':used,'zero_tail_bytes':len(raw)-used,'frame_names':[x['name'] for x in rows]}
  s['kind']=reservations[p.name]['kind']
 elif p.suffix=='.json':
  obj=json.loads(raw);walk(obj,path);s['kind']='json';json_schemas[path]=schema(obj);del obj
 else:
  content=raw.decode('utf-8');scan_string(content,path,'whole_text')
  if p.suffix=='.py':
   tree=ast.parse(content,filename=path)
   for n in ast.walk(tree):
    if isinstance(n,ast.Constant) and isinstance(n.value,str):scan_string(n.value,path,'AST line '+str(n.lineno))
   if sha(raw) not in ast_summaries:
    ast_summaries[sha(raw)]={'path':path,'imports':sorted({n.module or '' for n in ast.walk(tree) if isinstance(n,ast.ImportFrom)}|{a.name for n in ast.walk(tree) if isinstance(n,ast.Import) for a in n.names}),'functions':[n.name for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))],'classes':[n.name for n in ast.walk(tree) if isinstance(n,ast.ClassDef)],'lines':len(content.splitlines())}
   s['kind']='python_ast'
  elif p.suffix=='.md':s['kind']='markdown_full_text'
  else:s['kind']='own_text'
 counts[s['kind']]+=1;file_summaries.append(s)
 del raw
assert counts['files']==284
assert sha((W/'arc-native-copy-20261019/freeze_manifest.json').read_bytes())=='c09e8cb66f5d300413e86469da359aa052a8900de2650b8a580dacbec817df64'
assert sha((W/'arc-copy-launch-review-20261019/final_execution_audit/audit_report.json').read_bytes())=='732babe89a5ecd2978c0f073f5b100ae71ee10f6b93e55f0704470ca9326ac8c'
assert sha((W/'arc-copy-launch-review-20261019/final_execution_audit/verified_evidence_manifest.json').read_bytes())=='a792cf00dd66221935ed86eee02eec7755173c09bcd2b9feeefd493b76fba7a7'
result={'status':'INERT_PARTIAL_CONTENT_SCAN_COMPLETE_REQUIRES_REVIEW_AND_FINAL_MANIFEST','manifest_sha256':sha(M.read_bytes()),'counts':dict(counts),'typed_tags':dict(vocab),'findings':dict(findings),'long_multiline_strings':longest,'reservations':reservations,'unique_own_source_AST':list(ast_summaries.values()),'json_schemas':json_schemas,'native_calls':0,'imports_of_payload_sources':0,'file_ref_dereferences':0,'maxrss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
out=json.dumps(result,ensure_ascii=False,indent=2)+'\n';assert len(out.encode())<100*1024
(O/'scan.json').write_text(out)
small={k:result[k] for k in ('status','manifest_sha256','counts','typed_tags','findings','long_multiline_strings','maxrss_KiB')}
print(json.dumps(small,ensure_ascii=False,indent=2))
