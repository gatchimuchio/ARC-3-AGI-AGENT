from pathlib import Path
import json,hashlib
B=Path("/workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019/publication_native_copy")
for name,expected in [('payload_admission.json','4295d02ad0060c73f48224953e398dde79be6ee61c72783d4371e8c14bd5d2dd'),('inspection_manifest.json','4b4baa192ede74d4628a4da22876db2fd771a27612b3a1b31a2e29155316a31a')]:
 p=B/name;b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==expected
 print('FILE',name,len(b));print(b.decode())
print('CAPTURE_FILES')
for p in sorted((B/'inspection_runs').rglob('*')):
 if p.is_file():print(str(p.relative_to(B)),p.stat().st_size)
