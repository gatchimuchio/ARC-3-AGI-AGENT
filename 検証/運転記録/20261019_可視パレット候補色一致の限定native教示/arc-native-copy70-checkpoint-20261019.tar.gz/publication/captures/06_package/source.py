from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,gzip,resource,shutil
resource.setrlimit(resource.RLIMIT_AS,(268435456,268435456))
B=Path("/workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019/publication_native_copy");W=B.parent.parent
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while z:=f.read(1048576):h.update(z)
 return h.hexdigest()
P=json.loads((B/'payload_manifest.json').read_text());I=json.loads((B/'inspection_manifest.json').read_text())
assert P['file_count']==358 and P['raw_bytes']==95287868
assert sha(B/'payload_manifest.json')=='2ea33604236055cd393f99a3fc42324e4a8d38ed874b7239ed5ddb482c87eff5'
assert sha(B/'payload_admission.json')=='4295d02ad0060c73f48224953e398dde79be6ee61c72783d4371e8c14bd5d2dd'
assert sha(B/'inspection_manifest.json')=='4b4baa192ede74d4628a4da22876db2fd771a27612b3a1b31a2e29155316a31a'
assert sha(B/'README.md')=='78da2d87396dda0625629663939d9a56dd95d785a23b811d7e214ee8aa8b09ef'
assert (B/'inspection_runs/run05/exit_status.txt').read_text()=='0\n'
assert sha(B/'inspection_runs/run05/stdout.log')=='b7963be05d09e660ff30f4a07c8673e9464d52680bd0f560b3833c1e22bfcf4f'
assert (B/'inspection_runs/run05/stderr.log').stat().st_size==0
entries={}
def add(p,n,size=None,digest=None):
 p=Path(p);assert p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(W.resolve())
 assert '..'not in PurePosixPath(n).parts and not n.startswith('/') and n not in entries
 assert 'disclosure_'not in n and 'canonical-audit'not in n
 actual=(p.stat().st_size,sha(p))
 if size is not None:assert actual==(size,digest),str(p)
 entries[n]=(p,*actual)
for f in P['files']:add(f['source'],f['archive_path'],f['bytes'],f['sha256'])
assert {(f['archive_path'],f['bytes'],f['sha256']) for f in P['files']}=={tuple(f[:3]) for f in I['payloads']}
for n,size,digest in I['inspection_artifacts']:add(B/n,'publication/'+n,size,digest)
for n in ['payload_admission.json','inspection_manifest.json','README.md','resource_ledger.json','payload_manifest.json','partial_payload_manifest.json','inspection_runs/run05/exit_status.txt','inspection_runs/run05/stdout.log','inspection_runs/run05/stderr.log']:
 add(B/n,'publication/'+n)
for leaf in ['00_authority_resource','01_closed_root_inventory','02_summary_draft','03_final_allowlist_shape','04_freeze_final_payload','05_admission_readback']:
 for p in sorted((B/'captures'/leaf).iterdir()):add(p,'publication/'+str(p.relative_to(B)))
add(B/'captures/06_package/source.py','publication/captures/06_package/source.py')
add(B.parent/'baseline_verification_0420/baseline_report.json','publication/baseline_report.json')
A={'schema':'arc3-copy70-archive-allowlist-v1','status':'LOCAL_ONLY_PUBLICATION_PAUSED','original_files':358,'original_raw_bytes':95287868,'member_fields':['path','bytes','sha256'],'entries':[[n,v[1],v[2]] for n,v in sorted(entries.items())],'self_exclusion':'Manifest excludes its own hash; external verification pins this member.','scope':'Four closed roots plus explicit68measurement files and6allowlist capture files; no active-parent recursion, opaque source/output or private HDS disclosure receipts.','receipt_boundary':'Package exact source is included before execution. Its final logs and verification are external later receipts.'}
ap=B/'archive_manifest.json';ap.write_text(json.dumps(A,ensure_ascii=False,separators=(',',':'))+'\n');add(ap,'publication/archive_manifest.json')
out=B/'arc-native-copy70-checkpoint-20261019.tar.gz';assert not out.exists()
class Limited:
 def __init__(self,f):self.f=f;self.n=0
 def write(self,b):
  assert self.n+len(b)<=3145728,'payload archive cap';n=self.f.write(b);self.n+=n;return n
 def flush(self):self.f.flush()
with out.open('xb') as raw:
 with gzip.GzipFile(filename='',fileobj=Limited(raw),mode='wb',mtime=0,compresslevel=9) as gz:
  with tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT) as tf:
   for n,(p,size,digest) in sorted(entries.items()):
    assert p.stat().st_size==size and sha(p)==digest
    i=tarfile.TarInfo(n);i.size=size;i.mode=0o644;i.mtime=0;i.uid=i.gid=0;i.uname=i.gname=''
    with p.open('rb') as f:tf.addfile(i,f)
expected={n:(v[1],v[2]) for n,v in entries.items()};seen={}
with gzip.open(out,'rb') as gz:
 with tarfile.open(fileobj=gz,mode='r|') as tf:
  for m in tf:
   assert m.isfile() and m.name in expected and m.name not in seen
   h=hashlib.sha256();size=0
   with tf.extractfile(m) as f:
    while z:=f.read(1048576):h.update(z);size+=len(z)
   seen[m.name]=(size,h.hexdigest());assert seen[m.name]==expected[m.name]
 while gz.read(1048576):pass
assert expected==seen
for f in P['files']:assert sha(Path(f['source']))==f['sha256']
b=out.read_bytes()
v={'schema':'arc3-copy70-archive-verification-v1','status':'PASS_PRIVATE_ONLY','archive':{'path':str(out),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob_sha1':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()},'members':len(seen),'uncompressed_member_bytes':sum(size for size,h in seen.values()),'all358_originals_unchanged':True,'all_members_exact':True,'gzip_full_stream_crc_eof':True,'private_disclosure_and_active_roots_excluded':True,'AS_bytes':268435456,'max_rss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'archive_manifest_sha256':sha(ap),'package_native_calls':0,'Git_writes':0}
(B/'archive_verification.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
metadata=sum(p.stat().st_size for p in B.rglob('*') if p.is_file() and p!=out)
assert metadata<=1048576
print(json.dumps(v,ensure_ascii=False));print('metadata_bytes',metadata)
