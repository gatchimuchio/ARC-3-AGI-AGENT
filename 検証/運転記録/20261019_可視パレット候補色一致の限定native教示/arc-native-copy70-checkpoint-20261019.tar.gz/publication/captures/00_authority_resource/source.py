from pathlib import Path
import json,hashlib,shutil,resource
resource.setrlimit(resource.RLIMIT_AS,(268435456,268435456))
R=Path("/workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019");B=R/'publication_native_copy';W=R.parent
for n in ['authority/Owner指示書原文_20261009.md','authority/Owner追加指示原文_20261010T1907.md','authority/Owner追加指示原文_20261011T1904.md','main/AGENTS.md','main/運用/権限順序.md','main/制御/現在状態.json']:
 b=(R/n).read_bytes();print('\nAUTHORITY',n,len(b),hashlib.sha256(b).hexdigest());print(b.decode())
archives=sum(p.stat().st_size for p in R.rglob('*') if p.is_file() and p.name.endswith(('.tar.gz','.tar.xz','.zip')))
metadata=sum(p.stat().st_size for p in R.rglob('*') if p.is_file() and not p.name.endswith(('.tar.gz','.tar.xz','.zip')))
mem=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
ledger={'schema':'arc3-copy-preservation-resource-v1','archive_cap':3145728,'metadata_cap':1048576,'global_archive_cap':83886080,'global_metadata_cap':16777216,'global_archives_now':archives,'global_metadata_now':metadata,'old_mirror_reserved':12467596,'packager_AS':268435456,'inspector_AS':268435456,'combined_validation_AS':536870912,'disk_free':shutil.disk_usage(B).free,'disk_floor':1073741824,'MemAvailable':mem,'memory_floor':2147483648,'status':'LOCAL_ONLY_WAITING_OUTCOME_REVIEW_AND_EXACT_MEASUREMENT_ALLOWLIST','no_native_execution':True,'Git_writes_paused':True}
assert archives+3145728+12467596<=83886080
assert metadata+1048576<=16777216 and mem>2147483648+536870912
(B/'resource_ledger.json').write_text(json.dumps(ledger,indent=2)+'\n')
print('LEDGER',json.dumps(ledger))
for n in ['arc-native-copy-20261019/freeze_manifest.json','arc-native-copy-20261019/preparation_manifest.json']:
 p=W/n;b=p.read_bytes();m=json.loads(b);print('MANIFEST',n,len(b),hashlib.sha256(b).hexdigest(),'keys',list(m));print('SAMPLE',json.dumps(m,ensure_ascii=False)[:2500])
