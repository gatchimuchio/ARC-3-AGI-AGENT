from pathlib import Path
import json,hashlib,resource
resource.setrlimit(resource.RLIMIT_AS,(268435456,268435456))
B=Path("/workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019/publication_native_copy");W=B.parent.parent
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while z:=f.read(1048576):h.update(z)
 return h.hexdigest()
m=json.loads((B/'partial_payload_manifest.json').read_text());entries={f['archive_path']:f for f in m['files']}
p=W/'arc-copy-measurement-preservation-20261019/run01/allowlist.json'
assert sha(p)=='2c42b60207e068d7cc9b51061c2dd31daa88d18f19c0db686a7d2b8c87980dd9'
allow=json.loads(p.read_text());assert len(allow['files'])==68
def add(p,expected=None):
 assert p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(W.resolve())
 name=str(p.relative_to(W));n=p.stat().st_size;h=sha(p)
 if expected:assert (n,h)==(expected['bytes'],expected['sha256']),name
 f={'source':str(p),'archive_path':name,'bytes':n,'sha256':h}
 if name in entries:assert entries[name]==f
 else:entries[name]=f
for f in allow['files']:
 assert Path(f['path']).parts[0] in ['arc-widepaint-operation-teachers-20261019','arc-widepaint-operation-review-20261019']
 assert '..' not in Path(f['path']).parts and not Path(f['path']).is_absolute()
 add(W/f['path'],f)
for c in sorted(p.parent.iterdir()):
 assert c.is_file()
 add(c)
for f in entries.values():
 q=Path(f['source']);assert q.stat().st_size==f['bytes'] and sha(q)==f['sha256']
out={'schema':'arc3-copy70-completed-payload-v1','base_main':'2ca6531908551755988ade040840362684c96b14','status':'CLOSED_ORIGINALS_AWAITING_CONTENT_ADMISSION_PRIVATE_ONLY','file_count':len(entries),'raw_bytes':sum(f['bytes'] for f in entries.values()),'closed_full_roots':m['roots'],'measurement_allowlist':{'path':str(p),'sha256':sha(p),'files':68,'raw_bytes':allow['total_bytes'],'capture_files':6},'native_freeze_sha256':'c09e8cb66f5d300413e86469da359aa052a8900de2650b8a580dacbec817df64','outcome_audit_sha256':'732babe89a5ecd2978c0f073f5b100ae71ee10f6b93e55f0704470ca9326ac8c','measurement_scope':allow['scope'],'measurement_excluded':allow['excluded'],'prior_measurement_failures':allow['copy_measurement_failures'],'files':sorted(entries.values(),key=lambda f:f['archive_path']),'excluded_derived':m['excluded_derived'],'global_exclusions':['All private HDS disclosure/history audit roots and raw tool receipts','All opaque official game/SDK source, binary and stderr','Active TURN/MASK/target-observer work','Referenced external original corpus/native/core archives are not duplicated'],'Git_writes':0,'packager_native_calls':0}
(B/'payload_manifest.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
old=(B/'README.md').read_bytes();(B/'captures/04_freeze_final_payload/before_README.md').write_bytes(old)
text=old.decode()
scope='''## 保存範囲
原payloadは358 files / 95,287,868 bytes。native、pilot、bound review、caller reviewの4閉鎖rootと、測定producerが明示した68ファイルおよび6件のallowlist実行記録だけを収録する。測定parentを再帰取得しない。

初期のmixed-cohort ancestor JSONにはTURN/MASK行も含まれるが、COPY抽出の正確な由来を保つために元bytesのまま残す。これはその別操作を今回nativeで学習・採用したことを意味しない。generic namespaceのHOLD、qualified proposalの旧版と最終copy6_qualified_v2、およびreview run01/02/03/05を保持する。独立したtarget-observer、現在のTURN plan、関連しないMASK出力とその失敗は本checkpointの閉鎖範囲外であり、削除せず別の保全対象とする。

'''
assert out['file_count']==358 and out['raw_bytes']==95287868
assert '## 保存範囲' not in text
text=text.replace('## limitations\n',scope+'## limitations\n')
(B/'README.md').write_text(text)
print(json.dumps({'status':'FROZEN','files':out['file_count'],'raw_bytes':out['raw_bytes'],'manifest_bytes':(B/'payload_manifest.json').stat().st_size,'manifest_sha256':sha(B/'payload_manifest.json'),'readme_bytes':(B/'README.md').stat().st_size,'readme_sha256':sha(B/'README.md')},ensure_ascii=False))
