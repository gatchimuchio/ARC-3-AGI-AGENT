from pathlib import Path
import json,hashlib,resource
resource.setrlimit(resource.RLIMIT_AS,(268435456,268435456))
B=Path("/workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019/publication_native_copy");W=B.parent.parent
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while z:=f.read(1048576):h.update(z)
 return h.hexdigest()
roots=['arc-native-copy-20261019','arc-copy-pilot-plan-20261019','arc-copy-bound-review-20261019','arc-copy-launch-review-20261019']
entries=[];derived=[]
for root in roots:
 sub=[]
 for p in sorted((W/root).rglob('*')):
  assert not p.is_symlink(),str(p)
  if not p.is_file():continue
  rec={'source':str(p),'archive_path':str(p.relative_to(W)),'bytes':p.stat().st_size,'sha256':sha(p)}
  if '__pycache__'in p.parts or p.suffix=='.pyc':derived.append(rec)
  else:entries.append(rec);sub.append(rec)
 print(root,'files',len(sub),'bytes',sum(x['bytes'] for x in sub))
f=W/'arc-native-copy-20261019/freeze_manifest.json';assert sha(f)=='c09e8cb66f5d300413e86469da359aa052a8900de2650b8a580dacbec817df64'
m=json.loads(f.read_text())
for n,rec in m['files'].items():
 p=f.parent/n;assert p.stat().st_size==rec['bytes'] and sha(p)==rec['sha256']
assert len(m['files'])==114
review=W/'arc-copy-launch-review-20261019/final_execution_audit/audit_report.json'
assert sha(review)=='732babe89a5ecd2978c0f073f5b100ae71ee10f6b93e55f0704470ca9326ac8c'
for n in ['arc-native-copy-20261019/RESULT.md','arc-copy-launch-review-20261019/final_execution_audit/README.md','arc-copy-launch-review-20261019/final_execution_audit/audit_report.json']:
 print('\nDOCUMENT',n);print((W/n).read_text())
out={'status':'PARTIAL_ALLOWLIST_AWAITING_MEASUREMENT_CLOSURE','roots':roots,'files':entries,'excluded_derived':derived,'file_count':len(entries),'raw_bytes':sum(x['bytes'] for x in entries),'all114_native_freeze_pins_unchanged':True,'scope':'Only four explicitly closed roots; measurement/reviewer history added later from owner frozen allowlist.'}
(B/'partial_payload_manifest.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print('PARTIAL',len(entries),out['raw_bytes'],'derived',len(derived))
