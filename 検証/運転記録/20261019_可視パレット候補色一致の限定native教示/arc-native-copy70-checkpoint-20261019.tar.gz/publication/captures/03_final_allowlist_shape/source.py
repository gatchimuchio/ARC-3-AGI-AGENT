from pathlib import Path
import json,hashlib
B=Path("/workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019/publication_native_copy");W=B.parent.parent
p=W/'arc-copy-measurement-preservation-20261019/run01/allowlist.json'
b=p.read_bytes();assert hashlib.sha256(b).hexdigest()=='2c42b60207e068d7cc9b51061c2dd31daa88d18f19c0db686a7d2b8c87980dd9'
m=json.loads(b)
print('KEYS',list(m));print('HEADER',json.dumps({k:v for k,v in m.items() if k not in ['files']},ensure_ascii=False))
print('FILES_SAMPLE',json.dumps(m.get('files'),ensure_ascii=False)[:3000])
for p in sorted(p.parent.iterdir()): print('CAPTURE',p.name,p.stat().st_size)
