"""Read retained fixed frames from disk, independent of fork-local offsets."""
import struct,json,hashlib,pathlib
from bounded_store import HOLD

def records(path):
 out=[];offset=0
 with pathlib.Path(path).open('rb') as f:
  while True:
   head=f.read(8)
   if not head or head==b'\0'*8:break
   if len(head)!=8:raise HOLD('partial frame length')
   n=struct.unpack('>Q',head)[0]
   if n>1024:raise HOLD('partial/invalid frame header bound')
   h=f.read(n)
   try:meta=json.loads(h)
   except Exception as e:raise HOLD('partial/invalid frame header') from e
   if meta['bytes']>8*1024**2:raise HOLD('payload bound')
   payload=f.read(meta['bytes'])
   if len(payload)!=meta['bytes'] or hashlib.sha256(payload).hexdigest()!=meta['sha256']:raise HOLD('partial frame payload')
   out.append((meta,payload));offset+=8+n+len(payload)
 return out
