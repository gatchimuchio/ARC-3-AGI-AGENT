#!/bin/bash
cd /workspace/scratch/a94ff513b3af/arc-native-copy-20261019/pure01
export PYTHONDONTWRITEBYTECODE=1
ulimit -v 524288
python -m unittest -v test_guard test_import_attributes > stdout.log 2> stderr.log
s=$?; printf '%s\n' "$s" > exit_status.txt; exit "$s"
