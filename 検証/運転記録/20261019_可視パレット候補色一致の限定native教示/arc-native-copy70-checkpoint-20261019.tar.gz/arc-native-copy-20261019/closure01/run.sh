#!/bin/bash
cd /workspace/scratch/a94ff513b3af
python arc-native-copy-20261019/closure01/source.py > arc-native-copy-20261019/closure01/stdout.log 2> arc-native-copy-20261019/closure01/stderr.log
s=$?; printf '%s\n' "$s" > arc-native-copy-20261019/closure01/exit_status.txt; exit "$s"
