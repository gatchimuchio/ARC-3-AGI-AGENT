import pathlib,json,hashlib
R=pathlib.Path(__file__).resolve().parent.parent;B=R.parent;roots=[B/'arc-copy-pilot-plan-20261019',R];files={}
for root in roots:
 for p in sorted(root.rglob('*')):
  if not p.is_file() or p.name=='preparation_manifest.json' or p.parent.name=='closure01' and p.name in ('stdout.log','stderr.log','exit_status.txt'):continue
  files[str(p.relative_to(B))]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
manifest={'status':'COPY70_PREPARATION_COMPLETE_NO_NATIVE_ADMISSION','native_calls':0,'reservations_allocated':False,'config_sha256':hashlib.sha256((R/'proposed_config.json').read_bytes()).hexdigest(),'roots':[str(p.relative_to(B)) for p in roots],'files':files,'excluded':['self','closure01 stdout/stderr/exit receipt retained separately'],'total_bytes_excluding_manifest_and_closure_logs':sum(x['bytes'] for x in files.values())}
p=R/'preparation_manifest.json';p.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print(hashlib.sha256(p.read_bytes()).hexdigest())
