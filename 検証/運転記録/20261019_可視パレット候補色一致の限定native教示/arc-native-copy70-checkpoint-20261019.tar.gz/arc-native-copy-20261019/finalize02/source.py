"""Read-only output validation and bounded report generation; zero native calls."""
import pathlib,json,hashlib,sys,resource,shutil
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2);sys.dont_write_bytecode=True
R=pathlib.Path(__file__).resolve().parent.parent;B=R.parent;sys.path.insert(0,str(R));from read_run import records
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,x):(R/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
c=json.loads((R/'proposed_config.json').read_bytes());a=json.loads((R/'result_audit.json').read_bytes())
for p,h in c['pins'].items():assert H(pathlib.Path(p))==h
old=json.loads((B/'arc-native-identity-20261019/freeze_manifest.json').read_bytes())
for p,m in old['files'].items():
 f=B/'arc-native-identity-20261019'/p;assert f.stat().st_size==m['bytes'] and H(f)==m['sha256']
idx={}
for p in sorted((R/'run01').glob('*.reserve')):
 size=p.stat().st_size
 if p.stem in ('normal_state','before_state','post_state') or p.stem.startswith('teach_'):used=size;kind='full native JSON state'
 elif p.stem=='failure_state':used=0;kind='unused state reservation';assert not any(p.read_bytes())
 elif p.stem=='worker_emergency':
  raw=p.read_bytes();used=len(raw.rstrip(b'\0'));kind='prewritten emergency fallback (unused)'
 else:
  rr=records(p);used=sum(8+len(json.dumps(m,ensure_ascii=False,separators=(',',':')).encode())+len(b) for m,b in rr);kind='framed evidence/log';assert not any(p.read_bytes()[used:])
 idx[p.name]={'bytes':size,'valid_prefix_bytes':used,'kind':kind,'sha256':H(p)}
write('reserve_prefix_index.json',idx)
assert a['full_state_max_bytes']<=c['state_upper_bound_bytes'] and a['max_reply_bytes']<=c['reply_upper_bound_bytes']
assert idx['evidence.reserve']['valid_prefix_bytes']<=c['evidence_upper_bound_bytes']
assert a['entered_returned_persisted']['fully_persisted_calls']==70
retained={p:sum(f.stat().st_size for f in pathlib.Path(p).rglob('*') if f.is_file()) for p in c['retained_directories']}
unit=sum(f.stat().st_size for f in R.rglob('*') if f.is_file());assert unit+2*1024**2<96*1024**2;assert sum(retained.values())+96*1024**2<576*1024**2
report={'status':'PRODUCER_PASS_INDEPENDENT_REVIEW_PENDING','native_calls':70,'complete_evidence_frames':219,'full_snapshots':9,'state_slots':10,'evidence_used_bytes':idx['evidence.reserve']['valid_prefix_bytes'],'full_state_max_bytes':a['full_state_max_bytes'],'state_bound_bytes':c['state_upper_bound_bytes'],'max_reply_bytes':a['max_reply_bytes'],'reply_bound_bytes':c['reply_upper_bound_bytes'],'peak_child_rss_kib':a['entered_returned_persisted']['peak_rss_KiB'],'wall_seconds':a['supervisor']['wall_seconds'],'cpu_seconds':'not separately measured;120s cap enforced','unit_bytes_before_final_report':unit,'retained_bytes':retained,'aggregate_with_full96MiBunit':sum(retained.values())+96*1024**2,'aggregate_cap_bytes':576*1024**2,'previous_identity_frozen_files_unchanged':len(old['files']),'all43pins_unchanged':True,'free_bytes_after':shutil.disk_usage(R).free,'native_truncation_limitation':'known-writer logical bounds; no physical ENOSPC persistence guarantee','baseline_sha256':c['pins'][str(B/'arc-native-identity-20261019/run01/post_state.reserve')],'post_state_sha256':H(R/'run01/post_state.reserve')}
write('resource_validation.json',report)
(R/'RESULT.md').write_text('''# COPY70 completed: producer audit PASS, independent review pending

Exactly 32 Query, six processing calls, and the identical 32 Query completed. All70 entered, returned and persisted;219 frames and nine full states retained. The preflight execution01 path-root failure occurred before allocation or native import and remains unchanged; parent separately permitted the reviewed corrected execution02 wrapper. No further native calls are authorized by this result.

Six existing recording×Boolean cohorts produced two directed 同値関係 lineages, principles28 and29, each version1. Both support experiences205–207 and have no refutations. Teacher3 returned成立確認; other five接続途上. Experiences208–210 remain fully recorded even though unchanged correspondence did not refresh principle support. These are correlated cohorts from101 historical palette clicks/584candidate contrasts, including483negative candidate comparisons and3already-equal clicks; zero new environment observations.

Before learning, the two palette questions returned no prediction. Afterward each yields exactly one Boolean prediction matching its observed input. Both Boolean values were already represented; this is no unseen-domain test. All30 existing query inputs and their complete before/after replies are retained in result_audit.json. Their relevant projections (status,predictions,conflicts,observation requests,ambiguity,disputed principles,HOLD reasons,learning status) are equal. Raw replies differ due global principle summaries and trace/counter identifiers. This smoke set is not exhaustive prior-success regression.

The qualified namespace is selected visible palette candidate-role equality → observed visible tool candidate-role equality, plus the learned reverse relation. Palette/tool recognition, click offsets, action command, candidate-color interpretation, and measurement scope remain fixed observable adapter assumptions. No role discovery, geometry learning, fresh action permission, causal uniqueness, game clear or general transfer is established. Current fresh tool already matches the sole deficit color; goal-driven palette selection correctly remains HOLD rather than forcing a click.

Baseline204experiences/27principle records/counter6758 becomes210/29/6822. Every original/intermediate ledger and principle/history prefix is retained. Both query-only intervals differ only by exact paired+32 counters. Full native delta is in native_full_delta.json. Maximum state6,324,220B (growth207,876), reply47,312B, wall12.205s; all reviewed bounds pass. See resource_validation.json and reserve_prefix_index.json for exact resource and retained-prefix facts. Saved native files truncate reservations; physical ENOSPC retention is not guaranteed.

Original failed static bound01/pre_fix01 and corrected bound02 remain in arc-copy-pilot-plan-20261019. Its mechanical envelope-generation failure affected only this connection-layer proof; earlier HDS/native proofs and core were unchanged. Original preparation and review-pending wording is retained with later verdicts appended separately.
''')
print(json.dumps(report,ensure_ascii=False))
