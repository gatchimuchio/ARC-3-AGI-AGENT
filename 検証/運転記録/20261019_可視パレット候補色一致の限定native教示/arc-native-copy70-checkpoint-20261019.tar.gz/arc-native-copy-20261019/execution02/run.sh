#!/bin/bash
cd /workspace/scratch/a94ff513b3af
PYTHONDONTWRITEBYTECODE=1 python arc-native-copy-20261019/execution02/source.py > arc-native-copy-20261019/execution02/stdout.log 2> arc-native-copy-20261019/execution02/stderr.log
s=$?; printf '%s\n' "$s" > arc-native-copy-20261019/execution02/exit_status.txt
exit "$s"
