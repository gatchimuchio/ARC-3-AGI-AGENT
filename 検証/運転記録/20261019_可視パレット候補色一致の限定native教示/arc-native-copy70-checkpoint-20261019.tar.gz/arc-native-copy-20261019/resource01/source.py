import pathlib,json,math
R=pathlib.Path(__file__).resolve().parent.parent;B=R.parent
old=json.loads((B/'arc-native-identity-20261019/proposed_config.json').read_bytes())['retained_directories']
paths=old+[str(B/n) for n in ('arc-native-identity-20261019','arc-copy-pilot-plan-20261019','arc-widepaint-operation-teachers-20261019','arc-widepaint-operation-review-20261019')]
measured={p:sum(f.stat().st_size for f in pathlib.Path(p).rglob('*') if f.is_file()) for p in paths}
projected=sum(measured.values())+96*1024**2
proposal=math.ceil((projected+32*1024**2)/(64*1024**2))*64
out={'retained':measured,'retained_total_bytes':sum(measured.values()),'new_full_unit_bytes':96*1024**2,'retained_plus_full_unit':projected,'proposed_aggregate_MiB_with_review_growth_margin':proposal,'not_authorized':True}
(R/'retained_resource_proposal.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
