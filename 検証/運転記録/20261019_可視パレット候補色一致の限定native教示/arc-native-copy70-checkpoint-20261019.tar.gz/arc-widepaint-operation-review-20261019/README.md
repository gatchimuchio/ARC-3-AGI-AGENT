# Independent operation contract review

## Current verdict
Evidence reconstruction PASS; native admission pending exact qualified payload and caller review. Legacy COPY/MASK runtime bytes are not admitted by this report. No native calls or action permissions.

Fresh run01 independently checks all 22 original manifest pins, every cohort member against the previously independently audited full public inventory, all original row/frame joins, every distinct typed outcome, and exact one-time membership. Results: 85 cohorts; 584 palette candidate relations (101 positive/483 negative); 389 direction actions over 31 conditions; 9,566 identifiable target cells and 1,934 ambiguous retained cells; all 631 action contexts. Missing ([1,1],Action4) remains HOLD. No outcome-majority grouping is used.

Fresh run02 narrows the palette relation: all 101 actions are Action6 at a unique visible selected-color rectangle; exact local offsets were independently recalculated. All responses contain exactly one public frame. That frame has the same reference/target binding; actual tool color equals clicked palette color, target and direction are unchanged. 98 tool changes and 3 already-equal cases remain. All 530 nonpalette contexts are retained as controls; they are not claimed to be matched counterfactuals. Six recording×Boolean cohorts are correlated evidence, not six independent interventions.

## Semantic blocker and smallest admitted meaning
The existing generic reference/answer-role COPY name risks applying palette-to-tool observations to goal/reference mapping. Admission requires an explicit palette-specific boundary and candidate-equality fields, preserving every original member and outcome. The before-selected palette color and actual after-tool color are measured independently. The queried relation does not establish the visual role classifier, click mapping, fresh causal sufficiency, goal-color necessity, or unique action choice. Those remain separately scoped fixed priors and caller gates.

Likewise, legacy MASK overwrite wording cannot silently stand for an invisible write event or continuous persistence. Endpoint-value observations need qualified boundary semantics. Small target partial-observer work is separate, and the original four small cohorts remain held until its review closes. The two 95% small-progress observations remain true counterexamples to exact equality necessity for public progress.

## Reproducibility
run01 and run02 each preserve exact script, preexecution hash, stdout, stderr, and exit 0. Address space capped at 512 MiB. Review files only; no authority/core/native/Git changes. No fresh environment observations or demonstrated capability gain.
