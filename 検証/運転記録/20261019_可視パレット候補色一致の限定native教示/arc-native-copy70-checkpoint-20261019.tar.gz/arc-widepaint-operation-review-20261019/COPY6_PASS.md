# Qualified COPY6: bounded evidence and semantic PASS

The additive copy6_qualified_v2 package passes independent evidence and exact-payload review. It replaces the generic role namespace for this proposal only; original bytes and historical limitations remain preserved. All six original before-defined cohorts and all 584 candidate members are unchanged. Native admission is not granted by this report.

Exact reviewed manifest SHA256: 69fc8d090dd45c70d4d87590da4369e9161037104f01fd75e22addb24d66a54d.
Teacher file SHA256: 2d10a16363e3280c43524d66c28bb86536e55b199b28d7db371210394b6b067c; 1,891 bytes, max single compact teacher 315 bytes.
Query file SHA256: 8907775ea6615b9adc4d62656d9a003fec5f97c34b28233edd4a6ecf6acedb2c.

Boundary: 公開パレット選択色役割と観測後器具色役割の候補色一致・既存可視配置範囲.
Input: 候補色は選択された可視パレット色と一致, typed Boolean.
Outcome: 候補色は観測後の可視器具色と一致, typed Boolean.
No provenance, identity, location, archive index, game ID or hidden answer enters native content. The action number is an external action contract in witness metadata, not an answer label learned from its own classifier.

The learned relation, if later successfully installed, connects candidate equality at these measured roles. It cannot by itself prove role recognition, an action's necessity or uniqueness, fresh applicability, requested goal-color correctness, or reference-grid-to-goal mapping. Before click selection and exact supported local offset, independently known before/after tool roles, legal action availability and argument validation, supported visual grammar and unique roles remain caller prerequisites. Goal-needed color selection is a disclosed policy prior, not evidence that HDS learned a goal.

Before a native run: pin the exact closed 204 base state; review native resource envelope and new boundary payload closure; retain two Boolean queries and all 30 current-state regression queries before and after; preserve all failures, replies and state deltas. A native relation result grants no Action permission. Fresh action validation requires its own fresh packet, binding, authorization and full observation capture. Rebinding the goal invalidates old goal-derived candidates.

All three independent review runs exit 0 with scripts, preexecution hashes, stdout and stderr retained. Small MASK and TURN remain outside this COPY6 verdict. No new environment observations or performance claim.

## Exact proposed query plan addendum
Independent run05 checks plan SHA256 4e33b0c96267443097a37931809656469b7781d0f4bd09889f475911649992fd: 32 queries, 6 exact qualified teachers, 32 identical post-queries. The two Boolean palette questions precede 30 byte-equivalent structured query inputs from the earlier identity proposal, covering 12 existing boundaries. This is a bounded regression list, not exhaustive behavioral coverage of every state fact. Its semantic plan passes; base-state/native-resource/caller approval is separate.
