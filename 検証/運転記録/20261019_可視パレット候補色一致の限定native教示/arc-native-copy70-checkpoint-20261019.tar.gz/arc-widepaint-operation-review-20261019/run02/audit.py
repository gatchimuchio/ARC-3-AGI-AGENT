import resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
import pathlib,json,collections,hashlib
R=pathlib.Path(__file__).resolve().parent;B=R.parents[1];S=B/'arc-widepaint-operation-teachers-20261019/run01';load=lambda n:json.loads((S/n).read_text());cs=load('cohorts.json');bs=load('all631_action_bindings.json');pals=[c for c in cs if '候補色は参照役割色と一致' in c['observed_input_condition']];actions={};offs=collections.Counter()
for c in pals:
 for w in c['all_members']:
  pair=tuple(w['pair']);a=w['action'];selected=w['selected_palette_role_color'];assert a['id']==6;d=a['data'];rects=[p['矩形'] for p in w['before_palette'] if p['色']==selected];assert len(rects)==1
  x0,y0,x1,y1=rects[0];assert x0<=d['x']<x1 and y0<=d['y']<y1;off=['色選択',x1-x0,y1-y0,d['x']-x0,d['y']-y0];assert off==w['exact_click_relative_support'];assert len([p for p in w['before_palette'] if p['矩形'][0]<=d['x']<p['矩形'][2] and p['矩形'][1]<=d['y']<p['矩形'][3]])==1
  if pair not in actions:offs[tuple(off)]+=1;actions[pair]=w
for b in bs:
 if tuple(b['pair']) not in actions:continue
 assert b['before_role_fixed_hypothesis']=='色選択' and not b['scope_failures'] and not b['reset'] and not b['progress'];assert b['status_before']==b['status_after']=='NOT_FINISHED' and 6 in b['availability_before'];assert len(b['all_phase_checks'])==1 and b['endpoint_phase']==0
 e=b['observed_effect'];assert e['tool_after']==actions[tuple(b['pair'])]['selected_palette_role_color'] and not e['target_changed'] and not e['direction_changed']
 assert all(p['interpretable'] and p['same_reference_target_binding'] for p in b['all_phase_checks'])
result={'six_palette_cohorts':len(pals),'distinct_actions':len(actions),'all_clicks_unique_selected_rectangle':True,'all_offsets_exactly_recomputed':True,'all101_single_public_frame_response':True,'all_actual_tool_outcomes_and_preserved_target_direction':True,'informative_actions':sum(w['old_tool_color']!=w['selected_palette_role_color'] for w in actions.values()),'offsets':[[list(k),v] for k,v in offs.items()],'nonpalette_controls_retained':len(bs)-len(actions),'native_calls':0,'action_permission':False}
(R/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2))
