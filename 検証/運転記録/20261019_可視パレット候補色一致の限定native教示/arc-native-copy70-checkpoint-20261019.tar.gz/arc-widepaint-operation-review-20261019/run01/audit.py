import resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
import pathlib,json,gzip,hashlib,collections
R=pathlib.Path(__file__).resolve().parent; B=R.parents[1]; S=B/'arc-widepaint-operation-teachers-20261019'; I=B/'arc-widepaint-witness-inventory-20261019/run02'
def load(p):return json.loads(p.read_text())
def sig(x):return json.dumps(x,ensure_ascii=False,separators=(',',':'))
pins=[]
for x in load(S/'MANIFEST.json')['files']:
 p=S/x['path'];a=p.read_bytes();assert len(a)==x['bytes'] and hashlib.sha256(a).hexdigest()==x['sha256'];pins.append(x)
(R/'source_pins.json').write_text(json.dumps(pins,ensure_ascii=False,indent=2))
phases={};last={}
for l in gzip.open(I/'all_phases.jsonl.gz','rt'):
 p=json.loads(l);k=(p['source'],p['row']);phases[(*k,p['phase'])]=p;last[k]=p
pairs={}
for l in gzip.open(I/'all_action_pairs.jsonl.gz','rt'):
 p=json.loads(l);pairs[p['before']['source'],p['before']['row'],p['after']['row']]=p
cs=load(S/'run01/cohorts.json');ts=load(S/'run01/teachers.runtime.json');qs=load(S/'run01/queries.runtime.json');js=load(S/'run01/row_to_teacher_joins.json');us=load(S/'run01/all_unknowns.json');bs=load(S/'run01/all631_action_bindings.json')
assert len(bs)==len(pairs)==631 and {tuple(b['pair']) for b in bs}==set(pairs)
seen=collections.Counter();counts=collections.Counter();conditions=set();pals={};turns=set();cells=set();groupkeys=set()
for ci,c in enumerate(cs):
 key=(c['recording_provenance'],c['boundary'],sig(c['observed_input_condition']));assert key not in groupkeys;groupkeys.add(key)
 assert c['query_runtime']==qs[ci]
 for o in c['all_outcomes']:
  js0=[j for j in js if j['cohort_index']==ci and j['all_member_indices']==o['member_indices']];assert len(js0)==1;j=js0[0];t=ts[j['teacher_index']];assert t==o['teacher_runtime'];assert t['内容']==dict(c['observed_input_condition'],**o['observed_outcome'])
  assert set(t)=={'内容','対象系境界','主体','対象','目的','文脈'} and t['文脈']=={} and all(t[k] is None for k in ('主体','対象','目的'))
  for mi in o['member_indices']:
   seen[ci,mi]+=1;w=c['all_members'][mi];k=tuple(w['pair']);p=pairs[k];si,br,ar=k
   assert si==c['recording_provenance'] and w['action']==p['actual_public_action'] and w['before_ref']==p['before'] and w['after_ref']==p['after']
   bp=last[si,br];ep=phases[si,ar,w['endpoint_phase']];s=bp['scene'];a=ep['scene'];assert w['before_frame_sha256']==bp['frame_sha256'] and w['endpoint_frame_sha256']==ep['frame_sha256']
   if 'candidate_palette_color' in w:
    col=w['candidate_palette_color'];selected=p['role_fixed_prior']['色'];assert w['selected_palette_role_color']==selected and w['observed_result_tool_color']==a['器具色'] and w['old_tool_color']==s['器具色'];assert col in {q['色'] for q in s['色見本']}
    assert c['observed_input_condition']=={'候補色は参照役割色と一致':col==selected};assert o['observed_outcome']=={'候補色は結果役割色と一致':col==a['器具色']}
    assert (k,col) not in pals;pals[k,col]=1;counts['palette']+=1;counts['palette_true']+=col==selected
   elif 'xy' in w:
    x,y=w['xy'];old=s['対象'][y][x];new=a['対象'][y][x];tool=s['器具色'];assert (w['before'],w['observed_endpoint'],w['tool'])==(old,new,tool) and old!=tool and new in (old,tool)
    z=next(q for q in p['all_phase_checks'] if q['phase']==w['endpoint_phase']);v=next(q for q in z['mask_all100_attributions'] if q['xy']==[x,y]);assert w['fixed_geometric_membership']==v['membership_hypothesis'];assert c['observed_input_condition']=={'幾何領域候補に属する':v['membership_hypothesis']} and o['observed_outcome']=={'観測上この画素は器具色で上書き':new==tool}
    ck=(*k,x,y);assert ck not in cells;cells.add(ck);counts['identified_cells']+=1
   else:
    assert c['observed_input_condition']=={'現在方向と方向作用':sig([s['方向'],p['actual_public_action']['id']])} and o['observed_outcome']=={'後方向':sig(a['方向'])};conditions.add(sig([s['方向'],p['actual_public_action']['id']]));assert k not in turns;turns.add(k);counts['turn']+=1
for ci,c in enumerate(cs):assert all(seen[ci,mi]==1 for mi in range(len(c['all_members'])))
for k,p in pairs.items():
 if (p['role_fixed_prior'] or {}).get('役割')=='色選択':
  colors={q['色'] for q in last[k[0],k[1]]['scene']['色見本']};assert {col for pair,col in pals if pair==k}==colors
for w in us:
 if w['kind']=='MASK_cell':
  k=tuple(w['pair']);x,y=w['xy'];s=last[k[0],k[1]]['scene'];assert w['before']==w['tool']==s['対象'][y][x]==s['器具色'];ck=(*k,x,y);assert ck not in cells;cells.add(ck);counts['ambiguous_cells']+=1
assert len(cells)==11500 and counts['palette']==584 and counts['palette_true']==101 and counts['turn']==389 and counts['identified_cells']==9566 and counts['ambiguous_cells']==1934
assert len(conditions)==31 and '[[1,1],4]' not in conditions
out={'manifest_pins':len(pins),'cohorts':len(cs),'teacher_count':len(ts),'all_member_joins_once':True,'complete_palette_candidates':True,'counts':dict(counts),'all631_contexts':True,'missing_turn':[[1,1],4],'distinct_turn_conditions':len(conditions),'namespace_admission':'HOLD legacy COPY/MASK semantics unresolved','native_calls':0}
(R/'result.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps(out,ensure_ascii=False,indent=2))
