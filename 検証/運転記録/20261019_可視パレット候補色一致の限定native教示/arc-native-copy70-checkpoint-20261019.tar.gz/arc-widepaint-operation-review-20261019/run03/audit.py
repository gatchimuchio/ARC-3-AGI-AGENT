import resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
import pathlib,json,hashlib
R=pathlib.Path(__file__).resolve().parent;B=R.parents[1];S=B/'arc-widepaint-operation-teachers-20261019';Q=S/'copy6_qualified_v2';load=lambda p:json.loads(p.read_text());sig=lambda x:json.dumps(x,ensure_ascii=False,separators=(',',':'));pins=[]
for x in load(Q/'MANIFEST.json')['files']:
 p=Q/x['path'];b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==x['sha256'] and len(b)==x['bytes'];pins.append(x)
old=load(S/'run01/cohorts.json');new=load(Q/'run01/all6_cohorts_full584_joins.json');ts=load(Q/'run01/teachers.runtime.json');qs=load(Q/'run01/queries.runtime.json');assert len(new)==len(ts)==len(qs)==6
boundary='公開パレット選択色役割と観測後器具色役割の候補色一致・既存可視配置範囲';X='候補色は選択された可視パレット色と一致';Y='候補色は観測後の可視器具色と一致';seen=set();members=0
for i,c in enumerate(new):
 j=c['original_cohort_index'];assert j not in seen;seen.add(j);o=old[j];assert c['all_members']==o['all_members'];members+=len(c['all_members'])
 assert qs[i]==c['query_runtime'];assert qs[i]['内容']=={X:o['observed_input_condition']['候補色は参照役割色と一致']};assert ts[i]['内容']=={**qs[i]['内容'],Y:o['all_outcomes'][0]['observed_outcome']['候補色は結果役割色と一致']}
 assert len(c['outcomes'])==len(o['all_outcomes'])==1 and ts[i]==c['outcomes'][0]['teacher_runtime']
 for p in (qs[i],ts[i]):
  assert p['対象系境界']==boundary and p['文脈']=={} and all(p[k] is None for k in ('主体','対象','目的'));assert set(p)=={'内容','対象系境界','文脈','主体','対象','目的'} and all(type(v)is bool for v in p['内容'].values())
assert members==584 and seen=={i for i,c in enumerate(old) if '候補色は参照役割色と一致' in c['observed_input_condition']}
result={'verdict':'PASS qualified COPY6 evidence and exact payload semantics; native/caller/action gates separate','all584_original_members_unchanged':True,'all_six_original_cohorts_only':True,'teachers_sha256':hashlib.sha256((Q/'run01/teachers.runtime.json').read_bytes()).hexdigest(),'queries_sha256':hashlib.sha256((Q/'run01/queries.runtime.json').read_bytes()).hexdigest(),'manifest_sha256':hashlib.sha256((Q/'MANIFEST.json').read_bytes()).hexdigest(),'teacher_bytes':len((Q/'run01/teachers.runtime.json').read_bytes()),'max_single_teacher_bytes':max(len(sig(t).encode())for t in ts),'native_calls':0,'action_permission':False}
(R/'pins.json').write_text(json.dumps(pins,ensure_ascii=False,indent=2));(R/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2))
