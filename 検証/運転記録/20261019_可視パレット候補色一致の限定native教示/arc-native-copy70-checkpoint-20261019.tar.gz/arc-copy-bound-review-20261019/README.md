# Independent COPY6 static growth review

## Verdict

BOUNDED PASS for corrected static state/input/reply/evidence envelopes of the frozen70-call COPY6-only plan. Not native execution admission. No native/HDS import, restore, save, Query, Teach, SDK, Action, Git or core change occurred. Owner directive/additions, AGENTS, hierarchy and current state reread. Strategy remains null and automatic transition false. Publication pause is unaffected.

Review uses separate fresh run01 and run02 leaves; source, stdout, stderr and exit status retained. Both pure runs exit0; AS512MiB. run01 independently audits data/branches and retains the original faulty envelope source. run02 reproduces corrected worker envelopes, retaining both original copied source and its review copy (only BASE path adjusted for nested review directory). All review files are below96MiB.

## Found and corrected defect

The original experience wire envelope had only2 observations. Native intake of a two-leaf dictionary adds2 metadata observations plus2 inferred leaves, hence4 total. The original6,628,545-byte refined proof did not dominate its actual shape and was not accepted. Worker preserved pre_fix01/bound01 and changed the observation count only. Corrected per-experience upper bound increases1,700bytes, or10,200bytes over6 teachers. Independently reproduced corrected full-state bound is6,638,745bytes. No failed proof was deleted or represented as the final proof.

## Inputs and frozen branch facts

Baseline arc-native-identity-20261019/run01/post_state.reserve:6,116,344bytes, SHA25698992da7beb467584dca9e5b9541d179886c81bf07b1e5884af838e9ec9eb820. It contains204 experiences,27 principle ledger versions,20 active lineages, paired Query counters6758. Entire original dataclass field sets AND orders match frozen 型.py. All7 persisted top-level fields are covered, with no omitted restoration defaults.

The6 prettyprinted plan teachers are semantically identical, in order and content/boundary, to the1891-byte reviewed witness file SHA2562d10a16363e3280c43524d66c28bb86536e55b199b28d7db371210394b6b067c. Null metadata and empty strict dictionary context are verified. The longer2271-byte plan file is formatting, not a changed teacher. Every new teacher has exactly2 strict bool leaves, equal TT/FF; the2 new queries contain1 strict bool leaf. No int1/0 substitution is accepted by this audit. Remaining30 queries exactly equal the prior identity query pack. Exact plan is32 Query +6 Teach +identical32 Query =70 calls.

The new palette-selected/observed-tool-candidate boundary is absent from all204 old experiences and all old principle-history versions. It is not a target/reference identity boundary. Grouped historical cohorts do not authorize Action or change prior mask/role meaning.

Independent prefix analysis against the frozen algorithm establishes:
- 2 inferred paths, each with one possible opposite-path condition
- both forward and reverse relations are 同値関係
- 2 directed candidates at prefixes3,4,5,6:8 total candidate events
- initial two-row Boolean tables adopted only at teacher3:2 total adoptions,1 changed call,2 new lineages,1 version each
- repeated later evidence appends normal experience/doubts/learning and candidate evidence, but unchanged tables do not create versions or refresh stored principle support tuples
- old boundary mismatch excludes old principle mutation; strict equal Boolean pairs exclude new refutations and isolation
- no excluded-support continuation, isolated parent, strict-subset specialization, reopening or residual-capacity branch

Support references are at most6; doubts5; candidates/adoptions/update references2; new snapshot contains20 prior+2 new lineages. Counters remain within padded widths; Query pairs increase at most64 to6822. All references, history copies and intermediate failed-prefix appends are counted.

## Corrected native wire and state bound

Explicit envelopes retain native dataclass, enum, dictionary and tuple wrappers, real field/key names, complete old snapshot, extra lineages and nested paths. JSON uses ensure_ascii=False and indent2; escaped literal widths checked. Record roots are shallower than padded depth12. Each envelope has128-byte framing slack;32KiB additional slack covers new dictionary entries, punctuation and counter-width changes. Values, paths, IDs, times and enums are conservatively padded. The corrected experience has all4 observations.

6,116,344 baseline
+6*56,067 base records (experience+cognitive+5doubts+learning+completion)
+8*9,242 candidate records (inference+evidence+judgment)
+2*34,909 adoption records (2 full principle copies+provisional+update)
+1*9,477 state snapshot
+32,768 structural slack
=6,638,745bytes <8,388,608bytes.

This sums dominating explicit shapes, not compression or observed-size extrapolation. Failure prefixes cannot append more than these complete-sequence totals; ledger/history may be retained even if the later state update fails. It is a disk-byte bound, not successful execution or failure-finalization assurance.

## Replies, inputs and storage

Independent maximum native-shaped input552bytes, atom JSON50bytes, path JSON62bytes, boundary JSON152bytes, new lineage JSON249bytes. All are inside the proposed input/padding caps.

All20 existing active summaries remain represented plus2 padded new ones. Each (boundary,result path) group remains singleton, including reverse direction. All active principles are non-isolated; max2 apply to one boundary. Thus conflicts/global ambiguity/isolation arrays are empty for this closed sequence. Both directions are still accounted for; the result-present rule can suppress the reverse prediction for these queries, but the envelope conservatively allows2 predictions and2 requests simultaneously. It includes all old/new summaries,6 HOLD reasons and union of Query/Teach trace keys. Reproduced reply upper62,525bytes <65,536bytes.

70*65,536 reply bytes +140*8,192 input/postinput bytes +10*16,384 snapshot-index bytes +220*(256+8) frame bytes =5,956,320bytes <8MiB. This covers normal9 snapshots plus a spare failure receipt. It assumes the final reviewed caller emits only these bounded planned records; duplicate full-state deltas or extra unbounded traces are not included.

Proposed96MiB unit:10 single-use8MiB state slots +8MiB evidence +4 disjoint1MiB logs/failure regions =92MiB fixed reservation, leaving4MiB for ALL existing prep/code/input/report/partial-write bytes. Source state remains external read-only. No second copied baseline fits implicitly in the4MiB allowance. Failure slots/extents cannot be reused or discarded. Final admission must measure existing aggregate bytes and retained failed attempts. Active evidence prefix5,956,320bytes is compatible with unchanged8MiB RLIMIT_FSIZE.

The retained resource_proposal_v2.json has inherited pending128KiB reply metadata; it is not the final cap. This review accepts only64KiB reply accounting and the corrected6,638,745-byte state bound. A superseding final resource receipt should state that explicitly without deleting the old proposal.

## Pins and remaining gates

Final proof static_bound.py:f25c630e501f064654a9905cf6a4291d4b3f64b57f2ad53d0afe9fc0cd96333a
refine_bound.py:c35f63561ed208a659ce422db5abcc99f440b27a3ccde9f108064af135a9b06f
reply_bound.py:da362ede02f5d264671c2b708140181151bfc858e8f3a80d7a3bd79c1f913b57
proposed_plan.json:4e33b0c96267443097a37931809656469b7781d0f4bd09889f475911649992fd

Independent source hashes and data facts are in run01/audit.json; corrected reproduction results are in run02. Final native caller/binding freeze, snapshot/header caps, aggregate quota measurement, failure-frontier handling and explicit parent admission remain separate. The measurement review owns raw witness validity. This does not authorize palette identity as target/reference identity, exhaustive regression, runtime adoption, Action, publication or a new observation. Native outcomes, false/HOLD/errors and partial writes must all be retained. Unknown frontier stays UNKNOWN; no automatic resumption. Free-space floors cannot guarantee allocator/ENOSPC/kernel/machine-failure survival.
