"""Pure arithmetic refinement of retained conservative per-unit bound."""
import json,pathlib
r=pathlib.Path(__file__).resolve().parent;j=json.loads((r/'growth_proposal.json').read_bytes());e=j['envelopes']
base=e['experience']+e['cognitive']+5*e['doubt']+e['learning']+e['feedback']
candidate=e['inference']+e['evidence']+e['judgement'];adoption=2*e['principle']+e['provisional']+e['update']
bound=j['baseline_bytes']+6*base+j['candidate_events_upper']*candidate+j['adoptions_upper']*adoption+j['changed_calls_upper']*e['state_history_snapshot']+32768
assert bound<8*1024**2
out={'status':'STATIC_REFINED_PROPOSAL_REVIEW_REQUIRED','baseline_bytes':j['baseline_bytes'],'base_per_teacher':base,'candidate_per_event':candidate,'adoption_per_event':adoption,'state_snapshot':e['state_history_snapshot'],'wrapper_counter_slack':32768,'state_upper_bound_bytes':bound,'state_slot_bytes':8*1024**2,'slots':10,'state_reserved_bytes':10*8*1024**2,'evidence_proposed_bytes':8*1024**2,'failure_metadata_reserved_bytes':4*1024**2,'fixed_reservations_bytes':92*1024**2,'report_code_allowance_bytes':4*1024**2,'requested_new_native_unit_bytes':96*1024**2,'reply_cap_proposal':131072,'reply_proof_status':'PENDING separate exact projection envelope; do not admit native yet','native_execution_authorized':False}
(r/'resource_proposal_v2.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
