import ast,collections,hashlib,itertools,json,pathlib,resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
R=pathlib.Path(__file__).resolve().parent;B=R.parent.parent;P=B/'arc-copy-pilot-plan-20261019';C=B/'arc-native-query-20261019/frozen/HDS/学習系統/v0.4.2/hds学習系統';S=B/'arc-native-identity-20261019/run01/post_state.reserve'
def dec(x):
 if isinstance(x,list):return list(map(dec,x))
 if isinstance(x,dict):
  if '__辞書__' in x:return {dec(k):dec(v) for k,v in x['__辞書__']}
  if '__組__' in x:return tuple(map(dec,x['__組__']))
  return {k:dec(v) for k,v in x.items()}
 return x
def enc(x):
 if isinstance(x,dict):return {'__辞書__':[[enc(k),enc(v)] for k,v in x.items()]}
 if isinstance(x,tuple):return {'__組__':[enc(v) for v in x]}
 if isinstance(x,list):return list(map(enc,x))
 return x
def size(x):return len(json.dumps(x,ensure_ascii=False,indent=2).encode())
raw=json.loads(S.read_bytes());s=dec(raw);ts=json.loads((P/'teachers.runtime.json').read_bytes());qs=json.loads((P/'queries.runtime.json').read_bytes());plan=json.loads((P/'proposed_plan.json').read_bytes())['plan']
fields={n.name:[f.target.id for f in n.body if isinstance(f,ast.AnnAssign)] for n in ast.parse((C/'型.py').read_text()).body if isinstance(n,ast.ClassDef) and any(isinstance(d,ast.Call) and isinstance(d.func,ast.Name) and d.func.id=='dataclass' for d in n.decorator_list)}
counts=collections.Counter()
def walk(x):
 if isinstance(x,dict):
  if '__データ型__' in x:
   n=x['__データ型__'];assert list(x['値'])==fields[n];counts[n]+=1
  for v in x.values():walk(v)
 elif isinstance(x,list):
  for v in x:walk(v)
walk(raw)
assert len(ts)==6 and len(qs)==32 and len(plan)==70
assert qs[2:]==json.loads((B/'arc-identity-teacher-plan-20261019/queries.runtime.json').read_bytes())
assert plan==[{'method':'照会する','input':q} for q in qs]+[{'method':'処理する','input':t} for t in ts]+[{'method':'照会する','input':q} for q in qs]
bs={t['対象系境界'] for t in ts};assert len(bs)==1
assert all(e['値']['対象系境界'] not in bs for e in s['台帳']['観測台帳'])
assert all(p['値']['対象系境界'] not in bs for ps in s['原理履歴'].values() for p in ps)
assert s['最小支持数']==3 and s['最大条件数']==2
for t in ts+qs:
 assert set(t)=={'内容','対象系境界','主体','対象','目的','文脈'}
 assert type(t['内容']) is dict and type(t['文脈']) is dict and t['文脈']=={}
 assert all(t[k] is None for k in ('主体','対象','目的'))
 assert all(type(k) is str and not k.startswith('@HDS:') for k in t['内容'])
 assert all(type(v) in (str,bool,int) for v in t['内容'].values())
w=json.loads((B/'arc-widepaint-operation-teachers-20261019/copy6_qualified_v2/run01/teachers.runtime.json').read_bytes())
assert all(t['内容']==u['内容'] and t['対象系境界']==u['対象系境界'] for t,u in zip(ts,w)) and len(w)==len(ts)
for t in ts:
 assert len(t['内容'])==2 and all(type(v) is bool for v in t['内容'].values())
 assert len(set(t['内容'].values()))==1
for q in qs[:2]:assert len(q['内容'])==1 and all(type(v) is bool for v in q['内容'].values())
seen=collections.defaultdict(list);tables={};versions=collections.Counter();cand=adopt=changed=0;prefix=[]
for ordinal,t in enumerate(ts,1):
 b=t['対象系境界'];seen[b].append(t['内容']);paths=sorted(t['内容']);new=[]
 for source,dest in itertools.permutations(paths):
  pairs=[(x[source],x[dest]) for x in seen[b]]
  assert all(type(a) is bool and type(z) is bool and a==z for a,z in pairs)
  table=tuple(sorted(set(pairs)))
  if len(pairs)>=3 and len(table)>=2:
   cand+=1;key=(b,'同値関係',((source,),),(dest,))
   if tables.get(key)!=table:adopt+=1;versions[key]+=1;tables[key]=table;new.append(key)
 changed+=bool(new);prefix.append({'teacher':ordinal,'boundary_rows':len(seen[b]),'candidates':2 if len(seen[b])>=3 and len(set(next(iter(x.values())) for x in seen[b]))>=2 else 0,'adoptions':len(new)})
assert (cand,adopt,changed,len(versions))==(8,2,1,2)
active=[next(p['値'] for p in reversed(s['原理履歴'][k]) if p['値']['原理識別子']==v) for k,v in s['状態履歴'][-1].items()]
assert len(active)==20 and all(p['状態']['値']=='適用範囲付き暫定原理' and p['採用状態']['値']=='有効' for p in active)
g=collections.Counter((p['対象系境界'],p['結果経路']) for p in active)
for b,rel,conds,result in versions:g[(b,result)]+=1
assert max(g.values())==1
assert max(collections.Counter([p['対象系境界'] for p in active]+[k[0] for k in versions]).values())==2
assert all(len(p['条件経路群'])==1 for p in active)
widths={'input_wire':max(size({'__データ型__':'外部入力','値':{k:enc(v) for k,v in t.items()}}) for t in ts+qs),'atom_json':max(size(v) for t in ts+qs for v in t['内容'].values()),'path_json':max(size(k) for t in ts+qs for k in t['内容']),'boundary_json':max(size(t['対象系境界']) for t in ts+qs),'new_lineage_json':max(size(repr(k)) for k in versions)}
assert widths['input_wire']<8192 and widths['atom_json']<=512 and widths['path_json']<=128 and widths['boundary_json']<=256 and widths['new_lineage_json']<=1024
out={'status':'STATIC_DATA_AND_BRANCH_PASS','native_calls':0,'baseline_bytes':S.stat().st_size,'baseline_sha256':hashlib.sha256(S.read_bytes()).hexdigest(),'existing_dataclass_counts':dict(counts),'all_existing_fields_and_order_match':True,'counters':s['識別子状態'],'new_boundaries_absent_entire_history':True,'candidate_events':cand,'adoptions':adopt,'changed_calls':changed,'new_lineages':len(versions),'versions_per_new_lineage':[{'lineage':repr(k),'versions':v} for k,v in versions.items()],'prefix':prefix,'active_existing':len(active),'active_after_max':len(active)+len(versions),'max_boundary_output_group':max(g.values()),'input_widths':widths,'pins':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [P/'teachers.runtime.json',P/'queries.runtime.json',P/'proposed_plan.json',P/'static_bound.py',P/'refine_bound.py']},'frozen_source_pins':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in C.glob('*.py')},'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(R/'audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps(out,ensure_ascii=False,indent=2))
