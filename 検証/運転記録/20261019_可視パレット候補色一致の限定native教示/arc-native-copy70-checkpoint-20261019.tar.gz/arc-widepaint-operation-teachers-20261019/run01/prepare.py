import resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
import pathlib,json,gzip,hashlib,ast,collections,sys
R=pathlib.Path(__file__).resolve().parent;B=R.parents[1];I=B/'arc-widepaint-witness-inventory-20261019/run02';O=B/'arc-goal6-action-bridge-20261019/origins'
sys.path.insert(0,str(I));import bridge
constants={}
for node in ast.parse((O/'関係.py').read_text()).body:
 if isinstance(node,ast.Assign):
  for t in node.targets:
   if isinstance(t,ast.Name):
    try:constants[t.id]=ast.literal_eval(node.value)
    except ValueError:pass
sig=lambda x:json.dumps(x,ensure_ascii=False,separators=(',',':'))
def payload(boundary,x,y=None):return {'内容':x if y is None else {**x,**y},'対象系境界':boundary,'主体':None,'対象':None,'目的':None,'文脈':{}}
phases={};last={}
for line in gzip.open(I/'all_phases.jsonl.gz','rt'):
 p=json.loads(line);phases[(p['source'],p['row'],p['phase'])]=p;last[(p['source'],p['row'])]=p
cohorts={};unknown=[];bindings=[];counts=collections.Counter();offsets=collections.Counter()
def add(rec,boundary,x,y,witness,gate):
 key=sig([rec,boundary,x]);g=cohorts.setdefault(key,{'recording_provenance':rec,'boundary':boundary,'observed_input_condition':x,'query_runtime':payload(boundary,x),'all_outcomes':{},'all_members':[],'admission_gate':gate})
 assert g['admission_gate']==gate
 ys=sig(y)
 if ys not in g['all_outcomes']:g['all_outcomes'][ys]={'observed_outcome':y,'teacher_runtime':payload(boundary,x,y),'member_indices':[]}
 n=len(g['all_members']);g['all_members'].append(witness);g['all_outcomes'][ys]['member_indices'].append(n)
for line in gzip.open(I/'all_action_pairs.jsonl.gz','rt'):
 p=json.loads(line);si=p['before']['source'];br=p['before']['row'];ar=p['after']['row'];pair=[si,br,ar];before=last[(si,br)];s=before['scene'];role=(p['role_fixed_prior'] or {}).get('役割','unresolved');ep=phases.get((si,ar,p['last_interpretable_old_problem_phase']));a=ep['scene'] if ep else None
 gate=[]
 if s is None:gate.append('before interpretation unknown')
 if p['scope_error']:gate.append(p['scope_error'])
 if p['reset']:gate.append('reset')
 if p['public_identity_changed']:gate.append('public identity changed')
 if p['before_status']!='NOT_FINISHED':gate.append('before not running')
 if not before.get('template_match'):gate.append('before fixed template not supported')
 if a is None:gate.append('no bound measured endpoint')
 w={'pair':pair,'before_ref':p['before'],'after_ref':p['after'],'action':p['actual_public_action'],'before_phase':before['phase'],'endpoint_phase':ep['phase'] if ep else None,'before_frame_sha256':before['frame_sha256'],'endpoint_frame_sha256':ep['frame_sha256'] if ep else None}
 effect=None if a is None or s is None else {'target_changed':s['対象']!=a['対象'],'direction_changed':s['方向']!=a['方向'],'tool_changed':s['器具色']!=a['器具色'],'tool_before':s['器具色'],'tool_after':a['器具色'],'direction_before':s['方向'],'direction_after':a['方向'],'target_changed_cells':[[x,y] for y in range(10) for x in range(10) if s['対象'][y][x]!=a['対象'][y][x]]}
 binding={**w,'before_role_fixed_hypothesis':role,'observed_effect':effect,'scope_failures':gate,'visible_endpoint_equal':p['visible_endpoint_equal'],'status_before':p['before_status'],'status_after':p['after_status'],'availability_before':p['availability_before'],'availability_after':p['availability_after'],'progress':p['score_increased'],'reset':p['reset'],'all_phase_checks':[{k:v for k,v in z.items() if k!='mask_all100_attributions'} for z in p['all_phase_checks']],'necessary_or_unique_action_proved':False,'sufficient_in_fresh_state_proved':False,'hidden_state':'unknown','execution_permission':False}
 bindings.append(binding);counts['all_pairs']+=1;counts['role:'+role]+=1
 if gate:unknown.append({**w,'reason':gate,'kind':'pair_scope'});continue
 if role=='色選択':
  selected=p['role_fixed_prior']['色'];box=next(v['矩形'] for v in s['色見本'] if v['色']==selected);data=p['actual_public_action']['data'];off=['色選択',box[2]-box[0],box[3]-box[1],data['x']-box[0],data['y']-box[1]];offsets[sig(off)]+=1
  assert sig(off) in bridge.L['クリック支持相対位置']
  for color in sorted({v['色'] for v in s['色見本']}):
   x={constants['X']:color==selected};y={constants['Y']:color==a['器具色']};member={**w,'candidate_palette_color':color,'selected_palette_role_color':selected,'observed_result_tool_color':a['器具色'],'old_tool_color':s['器具色'],'causal_change_identifiable':s['器具色']!=selected,'exact_click_relative_support':off,'before_palette':s['色見本']}
   add(si,constants['COPY'],x,y,member,'historical observable relation only; fresh causal/role admission pending');counts['COPY_members']+=1;counts['COPY_negative_candidates']+=not x[constants['X']]
 elif role=='方向':
  x={constants['TX']:sig([s['方向'],p['actual_public_action']['id']])};y={constants['TY']:sig(a['方向'])};add(si,constants['TURN'],x,y,{**w,'direction_changed':effect['direction_changed'],'tool_preserved':not effect['tool_changed'],'target_preserved':not effect['target_changed']},'historical observable relation only; fresh causal/role admission pending');counts['TURN_members']+=1
 elif role in ('広域塗布','小域塗布'):
  if role=='小域塗布':
   box=s['小器具矩形群'][0];data=p['actual_public_action']['data'];off=[role,box[2]-box[0],box[3]-box[1],data['x']-box[0],data['y']-box[1]];assert sig(off) in bridge.L['クリック支持相対位置'];offsets[sig(off)]+=1;binding['exact_click_relative_support']=off
  for y in range(10):
   for x in range(10):
    old=s['対象'][y][x];new=a['対象'][y][x];tool=s['器具色'];m=bridge.P['membership'](s['方向'],x,y,10,role);member={**w,'xy':[x,y],'before':old,'observed_endpoint':new,'tool':tool,'direction':s['方向'],'fixed_geometric_membership':m,'maskmode':role}
    if old==tool or type(m)is not bool or new not in (old,tool):unknown.append({**member,'kind':'MASK_cell','reason':'unidentifiable prior equals tool' if old==tool else 'unknown geometry or third outcome'});counts['MASK_HOLD_cells']+=1;continue
    add(si,constants['MASK']+':'+role,{constants['MX']:m},{constants['MY']:new==tool},member,'wide paired-bound target endpoint only; causal/fresh admission pending' if role=='広域塗布' else 'HOLD small single-bound endpoint only; paired-bound target selector unresolved');counts['MASK_identifiable_cells']+=1
cs=list(cohorts.values());teachers=[];queries=[];joins=[]
for ci,c in enumerate(cs):
 c['all_outcomes']=list(c['all_outcomes'].values());c['contradiction']=len(c['all_outcomes'])>1;c['cohort_index']=ci;queries.append(c['query_runtime'])
 for o in c['all_outcomes']:
  ti=len(teachers);teachers.append(o['teacher_runtime']);joins.append({'teacher_index':ti,'query_index':ci,'cohort_index':ci,'all_member_indices':o['member_indices'],'admission_gate':c['admission_gate']})
assert counts['all_pairs']==631 and counts['TURN_members']==389 and counts['MASK_HOLD_cells']==1934 and counts['MASK_identifiable_cells']==9566
summary={'counts':dict(counts),'cohorts':len(cs),'cohorts_by_boundary':dict(collections.Counter(c['boundary'] for c in cs)),'typed_teacher_payloads':len(teachers),'contradictory_cohorts':sum(c['contradiction'] for c in cs),'all_exact_click_offsets':dict(offsets),'runtime_teacher_bytes':len(sig(teachers).encode()),'runtime_query_bytes':len(sig(queries).encode()),'max_single_teacher_bytes':max(len(sig(t).encode()) for t in teachers),'all631_binding_records':len(bindings),'all_unknown_records':len(unknown),'HDS_calls':0,'native_execution_admission':False}
for name,obj in [('cohorts.json',cs),('all631_action_bindings.json',bindings),('all_unknowns.json',unknown),('row_to_teacher_joins.json',joins),('summary.json',summary)]: (R/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2))
for name,obj in [('teachers.runtime.json',teachers),('queries.runtime.json',queries)]: (R/name).write_text(sig(obj))
inputs=[I/'all_phases.jsonl.gz',I/'all_action_pairs.jsonl.gz',I/'bridge.py',O/'関係.py',O/'予測.py',O/'固定文法.py',B/'arc-widepaint-witness-review-20261019/MANIFEST_v2.json',B/'arc-goal6-generalization-audit-20261019/MANIFEST.json']
(R/'input_pins.json').write_text(json.dumps([{'path':str(p.relative_to(B)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in inputs],ensure_ascii=False,indent=2));print(json.dumps(summary,ensure_ascii=False,indent=2))
