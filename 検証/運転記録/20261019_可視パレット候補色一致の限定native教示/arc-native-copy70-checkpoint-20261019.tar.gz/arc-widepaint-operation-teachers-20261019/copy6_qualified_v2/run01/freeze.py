import pathlib,json,hashlib,resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
R=pathlib.Path(__file__).resolve().parent;P=R.parents[1];qualified=json.loads((P/'qualified_contracts_v2/run01/qualified_cohorts.proposal.json').read_text());original=json.loads((P/'run01/cohorts.json').read_text());cohorts=[]
for q in qualified:
 if 'パレット' not in q['query_runtime']['対象系境界']:continue
 c=original[q['original_cohort_index']];cohorts.append({**q,'all_members':c['all_members'],'prerequisites':['before visible palette role unique','actual click at individually witnessed relative offset','before and after tool role independently known','strict action availability and coordinates','existing unique instrument/device template scope'],'causal_claim':'observable candidate role equality only; three already-equal clicks do not identify copying versus no-op'})
assert len(cohorts)==6 and sum(len(c['all_members']) for c in cohorts)==584
teachers=[o['teacher_runtime'] for c in cohorts for o in c['outcomes']];queries=[c['query_runtime'] for c in cohorts];sig=lambda o:json.dumps(o,ensure_ascii=False,separators=(',',':'))
for n,o in [('teachers.runtime.json',teachers),('queries.runtime.json',queries)]: (R/n).write_text(sig(o))
(R/'all6_cohorts_full584_joins.json').write_text(json.dumps(cohorts,ensure_ascii=False,indent=2));summary={'cohorts':6,'teacher_bytes':len(sig(teachers).encode()),'query_bytes':len(sig(queries).encode()),'max_single_teacher_bytes':max(len(sig(t).encode()) for t in teachers),'all_candidate_members':584,'actual_clicks':101,'informative_clicks':98,'already_equal_clicks':3,'negative_candidates':483,'native_calls':0,'admission':'pending independent review and native resource gates'};(R/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));print(json.dumps(summary,ensure_ascii=False,indent=2))
