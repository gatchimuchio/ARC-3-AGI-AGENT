# Audited operation teacher contracts, offline preparation only

## Result and adoption status
85 recording × observed-before-input cohorts preserve every distinct observed outcome and every member witness. No cohort has conflicting outcomes. Recording identity stays outside runtime content. No native call or action was performed, and none of these payloads is execution-admitted.

| Existing boundary | Cohorts | Underlying observations |
|---|---:|---:|
| COPY Boolean candidate-role identity | 6 | 584 palette candidates from all 101 clicks |
| TURN direction/action → direction | 69 | all 389 actions, 31 distinct condition keys |
| MASK wide geometry → identified overwrite | 6 | identifiable wide cells, with all ambiguous cells retained separately |
| MASK small geometry → identified overwrite | 4 | identifiable small cells, held for endpoint measurement gap |

There are 85 exact typed teacher payloads (16,933 UTF-8 bytes), 85 matched queries (14,695 bytes), maximum single teacher 239 bytes. Of these, 81 payloads (15,977 bytes as a compact JSON array) are prepared for later admission review; 4 small-MASK payloads (957 bytes) remain measurement-HOLD. The 81 are not permission to execute Teach: historical state closure, native resource bounds, causal applicability and contract interpretation still need their respective gates. A future 81-call admission would add at most 81 experience records if each call appends one; actual principles/state/reply growth must be proven separately from frozen core semantics. No native growth is measured here.

`run01/teachers.runtime.json` includes all 85, including held records, and MUST NOT be consumed blindly as an execution list. `run02/pending_admission_index.json` and `held_small_index.json` are explicit review partitions with original indexes. Original complete file remains intact.

## Historical learned-state closure first
The preservation writer confirmed during this preparation that no newly verified wide-paint learned HDS state closure is available. Historical Color3/Query3/Color12/Query1 and native29489/fixture18870 references remain unresolved. Source contracts and public observations are available; installed historical COPY/MASK/TURN principles are not established by those references. The currently closed goal6 descendant supports only its narrow endpoint correspondence and does not close these older states. This package is new derivation from existing historical public evidence, not newly collected independent experience or proof of already-installed relations.

## Exact existing contract reuse
Source names and keys are AST-read from the pinned own `関係.py`, without importing its HDS module. `予測.py` is inspected, not executed. The source uses:

- COPY: X `候補色は参照役割色と一致`, Y `候補色は結果役割色と一致`.
- TURN: X `現在方向と方向作用` serialized as [before direction, actual action number]; Y `後方向` serialized as observed after direction.
- MASK: separate `:広域塗布` and `:小域塗布` boundaries, X `幾何領域候補に属する`, Y `観測上この画素は器具色で上書き`.

For COPY, the source predictor's specific role interpretation is clicked palette color as reference-role color and observed tool color as result-role color. It queries every visible palette candidate. All 584 observed candidate relations are represented: 101 selected-role candidates and 483 negative candidates. Labels compare each candidate to the actual observed result tool color, not to a class label. All 98 differing-before-tool clicks are informative color changes; all 3 already-equal clicks remain truthful endpoint relations but cannot establish copying versus no-op causality. The package does not teach a different reference-grid-to-goal color mapping under this Boolean boundary.

TURN labels are actual endpoint direction measurements. All 120 unchanged-direction outcomes and 269 changed-direction outcomes remain. Grouping yields 69 recording-specific cohorts and 31 distinct before-direction/action keys. Missing ([1,1],4) is HOLD; no extrapolated 32nd payload exists.

MASK labels use before!=tool as the identification prerequisite. Across both modes all 11,500 cells are retained exactly once: 9,566 identifiable cells enter the observational cohorts; 1,934 before=tool cells are retained unlabelled HOLD. Membership comes from the existing fixed geometric hypothesis; outcome comes from the measured old-problem endpoint. No ambiguous same-color cell is turned into an overwrite positive. This is endpoint-value attribution, not proof of an invisible write event or uninterrupted preservation. If the native outcome key is interpreted as such an invisible event, admission must remain HOLD until its semantic scope is explicitly resolved without changing the core.

The existing predictor asks only Boolean geometry, not whether old!=tool. Therefore using these learned identifiable-cell relations on unidentifiable cells would be a separate inference. For value prediction, copying the same color versus preserving it yields the same value, but that does not justify an overwrite-causality claim. No runtime bridge modification makes that inference here.

## Cohort construction and complete joins
The cohort key is (recording provenance, exact typed boundary, exact observed input condition). It contains no after label. Every member enters first; all distinct outcomes are retained as separate payloads within that input cohort. No majority vote, success selection, minimum-support cutoff or top-k is used. A source-recording index is only a grouping/provenance field and never appears in the runtime payload.

`cohorts.json` contains all members with original byte/row/frame references, actual actions, candidate colors or cell coordinates, before values, observed outcomes and exact click local offsets. `row_to_teacher_joins.json` maps every teacher to its cohort, matched query and all supporting member indexes. Observations from the same action, frame or recording are correlated. Cohort counts and cell counts are not independent sample sizes and must not be multiplied into causal confidence.

`all631_action_bindings.json` retains every action pair, including all 516 nonpaint pairs, 23 unsupported clicks and 3 reset pairs. All available phase interpretation/binding facts, public status/availability/progress, visible endpoint equality, and hidden unknown remain. Raw full frames are referenced through the independently verified original inventory, not duplicated.

## Action binding: observed effects, not a tautological class label
The before-frame classifier supplies only a fixed role hypothesis. The separate actual effects show:

- Palette clicks: 98 tool-only changes and 3 no change in the parsed target/direction/tool fields.
- Direction actions: 269 direction-only changes and 120 no direction change.
- Wide paint: 90 target-only changes and 12 no target change.
- Small paint: 11 target-only changes and 2 no target change.
- Unsupported clicks: 23 preserve parsed target/tool/direction. Only 8 preserve the entire visible endpoint; 15 have other visible changes, so they are not labelled universal no-ops.
- Reset pairs: all 3 retained, with visible target/direction or target/tool changes; they are scope-excluded from operation teacher formation, not dropped as rival evidence.

All actual outcomes are indexed by `run02/all631_effect_contrasts.json`. Every valid click's exact before-visible rectangle, local offset and original coordinates are preserved. All 101 palette and 13 small clicks match existing exact-offset support. This supports only those observed relative offsets under the structural prior, not every pixel in the rectangle. The declared click mapping is an existing role hypothesis plus observed sufficient-in-those-context effects; it is not proof that this action is necessary, unique, or sufficient in a fresh state. No classifier label is simply taught back as its own evidence.

Nonpaint contrasts preserve target at their measured endpoints except resets. This is useful rival evidence, but the archive does not provide matched counterfactual actions for every identical complete state. Hidden state, action timing and other explanations remain unknown. No exclusivity claim or action authorization follows.

## Endpoint measurement scope
Wide MASK relies on the separately audited before-reference contiguous-prefix observer: select the terminal two frames of that prefix, require independently parsed same reference/target rectangles and equal target crops. All 102 wide actions pass; their pair happens to be phases13/14, but the selection contract is not hardcoded14 or chosen by matching a predicted output.

Small MASK has only one parsed old-bound terminal frame. Its preceding raw target crop matches but its object interpretation is unresolved. All 4 small cohorts remain HOLD. The needed improvement is a separately justified single-bound target identity selector or a second independent parsed binding. It must use before geometry/visible anchoring and response structure, not scan for a desired output or treat fixed-coordinate equality as continuous identity. This preparation does not invent that selector or force phase13 to pass.

Unknown phases remain unknown even when wide target endpoints pass. Endpoint stability is target-scoped and does not establish whole-environment stability, future persistence, hidden-state equality, or continuous preservation.

## Goal backward to prerequisite operations
1. Keep the actual public progress alternatives explicit. The original wide goal6 predicate has zero conflicts across all102 wide cases; cross-mode tuple-only progress has two counterexamples and remains HOLD. Exact reference equality is a common conservative endpoint among surviving hypotheses, not a proved necessary or fresh sufficient clear condition.
2. For a proposed target relation, derive required endpoint colors and preservation constraints from the CURRENT public frame. A prospective endpoint must be explicitly predicted with provenance, never imported from archive after labels.
3. A candidate paint footprint requires an applicable mask mode, observable instrument orientation/tool color, fixed-grammar scope, and an admitted target response observer. Palette selection can prepare the tool color via the observed role relation and supported exact offset. TURN can prepare orientation only through witnessed conditions; missing conditions remain HOLD.
4. Compose only supported relations and retain all legal candidates. No planner, chosen trajectory, lookup policy or heuristic candidate reduction is created by this package.
5. Before any action: fresh packet and legal availability/argument validation, unique roles, correct click target, target permission, native learned-state closure, applicability and full-response failure capture must all pass. Public progress/terminal/rebind invalidates the old goal.

## Reproducibility and limits
Both fresh run leaves preserve exact script, stdout, stderr and exit status. Both passed. `run02` checks every typed label/join, all631 unique pairs, all101 actual palette actions, all389 TURN actions and all11,500 mask cells exactly once. The package fits the 96MiB disk budget; both scripts set a 512MiB address-space limit. Input and output manifests are pinned. Original authorities, state, core, native artifacts and Git are unchanged. These counts are preparation evidence, not performance improvement.
