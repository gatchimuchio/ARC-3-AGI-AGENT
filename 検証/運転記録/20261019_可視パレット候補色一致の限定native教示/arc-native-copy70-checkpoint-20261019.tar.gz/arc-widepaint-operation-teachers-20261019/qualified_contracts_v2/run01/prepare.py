import pathlib,json,hashlib,resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
R=pathlib.Path(__file__).resolve().parent;P=R.parents[1];old=json.loads((P/'run01/cohorts.json').read_text());new=[]
for c in old:
 b=c['boundary'];x=c['observed_input_condition'];is_copy=b.startswith('公開色対応:');is_mask=b.startswith('公開塗布:')
 if not(is_copy or is_mask):continue
 boundary='公開パレット選択色役割と観測後器具色役割の候補色一致・既存可視配置範囲' if is_copy else '公開100対象・識別可能な事前色差・同参照幾何拘束二相可視終端色:'+b.rsplit(':',1)[1]
 xx={'候補色は選択された可視パレット色と一致':x['候補色は参照役割色と一致']} if is_copy else {'固定幾何候補に属する':x['幾何領域候補に属する'],'作用前対象色は作用前器具色と異なる':True}
 yykey='候補色は観測後の可視器具色と一致' if is_copy else '拘束された可視対象終端色は作用前器具色と一致'
 outcome=[]
 for o in c['all_outcomes']:
  old_y=next(iter(o['observed_outcome'].values()));content={**xx,yykey:old_y};outcome.append({'teacher_runtime':{'内容':content,'対象系境界':boundary,'主体':None,'対象':None,'目的':None,'文脈':{}},'original_member_indices':o['member_indices']})
 new.append({'original_cohort_index':c['cohort_index'],'recording_provenance':c['recording_provenance'],'query_runtime':{'内容':xx,'対象系境界':boundary,'主体':None,'対象':None,'目的':None,'文脈':{}},'outcomes':outcome,'members_join':'run01/cohorts.json: original_cohort_index/all_members','status':'proposal only; independent measurement and semantic admission required','no_invisible_write_claim':True,'action_permission':False})
(R/'qualified_cohorts.proposal.json').write_text(json.dumps(new,ensure_ascii=False,indent=2));ts=[o['teacher_runtime'] for c in new for o in c['outcomes']];qs=[c['query_runtime'] for c in new];wire=lambda o:json.dumps(o,ensure_ascii=False,separators=(',',':'))
for n,o in [('teachers.proposal.runtime.json',ts),('queries.proposal.runtime.json',qs)]: (R/n).write_text(wire(o))
summary={'qualified_COPY':sum('パレット' in c['query_runtime']['対象系境界'] for c in new),'qualified_MASK':sum('可視終端色' in c['query_runtime']['対象系境界'] for c in new),'teacher_bytes':len(wire(ts).encode()),'query_bytes':len(wire(qs).encode()),'max_single_teacher_bytes':max(len(wire(t).encode()) for t in ts),'native_calls':0,'old_payloads_unchanged':True};(R/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));print(json.dumps(summary,ensure_ascii=False,indent=2))
