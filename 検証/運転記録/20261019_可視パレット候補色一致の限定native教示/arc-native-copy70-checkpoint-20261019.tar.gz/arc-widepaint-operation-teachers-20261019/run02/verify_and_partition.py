import resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
import pathlib,json,collections,hashlib
R=pathlib.Path(__file__).resolve().parent;P=R.parent/'run01';read=lambda n:json.loads((P/n).read_text());cohorts=read('cohorts.json');bindings=read('all631_action_bindings.json');unknown=read('all_unknowns.json');teachers=read('teachers.runtime.json');queries=read('queries.runtime.json');joins=read('row_to_teacher_joins.json');sig=lambda o:json.dumps(o,ensure_ascii=False,separators=(',',':'))
assert len(bindings)==631 and len({tuple(b['pair']) for b in bindings})==631
pending=[];held=[];effects=collections.defaultdict(list);seen_members=collections.Counter();palette_actions={};turn_actions=set();maskcells=set()
for j in joins:
 c=cohorts[j['cohort_index']];t=teachers[j['teacher_index']];assert t['内容']=={**c['observed_input_condition'],**next(o['observed_outcome'] for o in c['all_outcomes'] if o['member_indices']==j['all_member_indices'])}
 assert queries[j['query_index']]==c['query_runtime']
 (held if c['admission_gate'].startswith('HOLD') else pending).append({'original_teacher_index':j['teacher_index'],'runtime':t,'gate':c['admission_gate']})
 for i in j['all_member_indices']:
  w=c['all_members'][i];seen_members[c['boundary']]+=1
  if 'candidate_palette_color' in w:
   assert t['内容']['候補色は参照役割色と一致']==(w['candidate_palette_color']==w['selected_palette_role_color'])
   assert t['内容']['候補色は結果役割色と一致']==(w['candidate_palette_color']==w['observed_result_tool_color'])
   palette_actions[tuple(w['pair'])]=w['causal_change_identifiable']
  elif 'xy' in w:
   assert w['before']!=w['tool'] and t['内容']['観測上この画素は器具色で上書き']==(w['observed_endpoint']==w['tool']);key=(*w['pair'],*w['xy']);assert key not in maskcells;maskcells.add(key)
  else:turn_actions.add(tuple(w['pair']))
for b in bindings:
 e=b['observed_effect'];key=sig([b['before_role_fixed_hypothesis'],None if e is None else [e['target_changed'],e['direction_changed'],e['tool_changed']]])
 effects[key].append({'pair':b['pair'],'actual_action':b['action'],'scope_failures':b['scope_failures'],'visible_endpoint_equal':b['visible_endpoint_equal'],'progress':b['progress']})
assert len(palette_actions)==101 and sum(palette_actions.values())==98 and len(turn_actions)==389 and len(maskcells)==9566
for u in unknown:
 if u['kind']=='MASK_cell':assert u['before']==u['tool'];key=(*u['pair'],*u['xy']);assert key not in maskcells;maskcells.add(key)
assert len(maskcells)==11500
summary={'all_cohort_join_checks':True,'all11500_mask_cells_exactly_once':True,'all631_pairs_exactly_once':True,'COPY_actual_actions':len(palette_actions),'COPY_informative_actions':sum(palette_actions.values()),'COPY_already_equal_actions':len(palette_actions)-sum(palette_actions.values()),'TURN_actual_actions':len(turn_actions),'pending_teacher_payloads':len(pending),'held_small_teacher_payloads':len(held),'pending_teacher_bytes':len(sig([x['runtime'] for x in pending]).encode()),'held_teacher_bytes':len(sig([x['runtime'] for x in held]).encode()),'effect_contrast_counts':{k:len(v) for k,v in effects.items()},'native_calls':0,'action_permission':False}
for n,o in [('verification.json',summary),('all631_effect_contrasts.json',dict(effects)),('pending_admission_index.json',pending),('held_small_index.json',held)]: (R/n).write_text(json.dumps(o,ensure_ascii=False,indent=2))
(R/'input_pins.json').write_text(json.dumps([{'path':str(p.relative_to(R.parent)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(P.glob('*.json'))],indent=2));print(json.dumps(summary,ensure_ascii=False,indent=2))
