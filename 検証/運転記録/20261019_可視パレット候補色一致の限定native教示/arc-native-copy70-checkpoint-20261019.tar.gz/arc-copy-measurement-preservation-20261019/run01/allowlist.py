import pathlib,json,hashlib,resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
R=pathlib.Path(__file__).resolve().parent;B=R.parents[1];O=B/'arc-widepaint-operation-teachers-20261019';V=B/'arc-widepaint-operation-review-20261019';paths=[]
def add(p):
 assert p.is_file();paths.append(p)
# Closed shared ancestors required to reconstruct the exact COPY slice. Mixed rows stay historical only.
for n in ['README.md','MANIFEST.json']:add(O/n)
for n in ['prepare.py','cohorts.json','teachers.runtime.json','queries.runtime.json','row_to_teacher_joins.json','summary.json','input_pins.json','stdout.txt','stderr.txt','exit_status.txt']:add(O/'run01'/n)
for n in ['verify_and_partition.py','verification.json','input_pins.json','stdout.txt','stderr.txt','exit_status.txt']:add(O/'run02'/n)
for sub in ['qualified_contracts_v2/run01','copy6_qualified_v2/run01']:
 for p in sorted((O/sub).iterdir()):
  if p.is_file():add(p)
add(O/'copy6_qualified_v2/MANIFEST.json')
for n in ['README.md','COPY6_PASS.md','MANIFEST.json']:add(V/n)
for sub in ['run01','run02','run03','run05']:
 for p in sorted((V/sub).iterdir()):
  if p.is_file():add(p)
files=[{'path':str(p.relative_to(B)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths];assert len({x['path'] for x in files})==len(files)
# Verify every file in the admitted COPY6 manifest unchanged.
cm=json.loads((O/'copy6_qualified_v2/MANIFEST.json').read_text())
for x in cm['files']:
 p=O/'copy6_qualified_v2'/x['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==x['sha256']
result={'files':files,'total_bytes':sum(x['bytes'] for x in files),'admitted_copy6_manifest_sha256':hashlib.sha256((O/'copy6_qualified_v2/MANIFEST.json').read_bytes()).hexdigest(),'scope':'closed COPY measurement history; fixed mixed ancestor rows required by exact COPY derivation retained as history only','excluded':['target_observer_v2/**','ADDENDUM_v*.md','MANIFEST_v2.json','MANIFEST_v3.json','run01/all631_action_bindings.json','run01/all_unknowns.json','run02/all631_effect_contrasts.json','run02/held_small_index.json','run02/pending_admission_index.json','review/run04/**','review/TARGET_OBSERVER_PASS.md','arc-turn69-teacher-plan-20261019/**','all native or public raw archives (external hash references only)'],'copy_measurement_failures':'no failed COPY script; original generic namespace HOLD and superseded shared qualified proposal retained; target-observer failures unrelated and excluded','native_calls':0}
(R/'allowlist.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps({'files':len(files),'total_bytes':result['total_bytes'],'copy_manifest_verified':True},indent=2))
