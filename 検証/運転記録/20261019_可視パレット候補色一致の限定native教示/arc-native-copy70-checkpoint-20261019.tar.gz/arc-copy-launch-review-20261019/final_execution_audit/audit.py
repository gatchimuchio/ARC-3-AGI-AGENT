"""Independent read-only framed-byte and native-wire evidence audit; no native imports."""
import pathlib,json,hashlib,struct,resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
B=pathlib.Path(__file__).resolve().parents[2];R=B/'arc-native-copy-20261019';O=pathlib.Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def normalized(x):
 if isinstance(x,list):return [normalized(v) for v in x]
 if isinstance(x,dict):
  if set(x)=={'__辞書__'}:return {normalized(k):normalized(v) for k,v in x['__辞書__']}
  if set(x)=={'__組__'}:return tuple(normalized(v) for v in x['__組__'])
  return {k:normalized(v) for k,v in x.items()}
 return x
def plain(x):return json.loads(json.dumps(x,ensure_ascii=False))
def wire(b):return normalized(json.loads(b))
def framed(path):
 out=[];offset=0
 with path.open('rb') as f:
  while True:
   header=f.read(8)
   if header==b'\0'*8 or not header:
    assert not any(f.read()),'nonzero trailing evidence';break
   assert len(header)==8;n=struct.unpack('>Q',header)[0];assert 0<n<1024
   rawhead=f.read(n);h=json.loads(rawhead);assert h['bytes']<=8*1024**2
   payload=f.read(h['bytes']);assert len(payload)==h['bytes'] and sha(payload)==h['sha256']
   out.append((h,payload,offset));offset+=8+n+len(payload)
 return out,offset
c=json.loads((R/'proposed_config.json').read_bytes());review=json.loads((O.parent/'reviewed_manifest.json').read_bytes())
assert sha((R/'proposed_config.json').read_bytes())=='721a996a9c639ccda4f89aeecbc476b702f03241d921528d8812096a1917aea1'
for p,h in c['pins'].items():assert sha(pathlib.Path(p).read_bytes())==h,p
rows,used=framed(R/'run01/evidence.reserve');assert len(rows)==219
assert all(h['bytes']<=16384 for h,b,o in rows if h['name'].startswith('snapshot.'))
records={h['name']:(b,offset) for h,b,offset in rows};assert len(records)==219
outputs=[];maxin=0;maxout=0;lastoffset=-1
for i,row in enumerate(c['plan'],1):
 prefix=f'{i:02d}.{row["method"]}';a,ao=records[prefix+'.input'];z,zo=records[prefix+'.input_after'];b,bo=records[prefix+'.output'];assert lastoffset<ao<bo<zo;lastoffset=zo
 assert a==z;assert wire(a)=={'__データ型__':'外部入力','値':row['input']}
 output=wire(b);assert output['__データ型__']=='外部出力';outputs.append(output['値']);maxin=max(maxin,len(a));maxout=max(maxout,len(b))
assert maxin<=8192 and maxout<=65536
names=['normal_state','before_state']+[f'teach_{i:02d}_state' for i in range(1,7)]+['post_state']
baselinebytes=(B/'arc-native-identity-20261019/run01/post_state.reserve').read_bytes();baseline=wire(baselinebytes);previous=baseline;snapshots=[]
for index,name in enumerate(names):
 p=R/'run01'/(name+'.reserve');raw=p.read_bytes();assert len(raw)<=c['state_upper_bound_bytes'];current=wire(raw)
 assert set(current)==set(baseline)
 assert all(current[k]==baseline[k] for k in baseline if k not in ('台帳','原理履歴','状態履歴','識別子状態'))
 if index==0:assert raw==baselinebytes
 for old in (baseline,previous):
  assert set(old['台帳'])<=set(current['台帳']) and set(old['原理履歴'])<=set(current['原理履歴'])
  for k,v in old['台帳'].items():assert current['台帳'][k][:len(v)]==v
  for k,v in old['原理履歴'].items():assert current['原理履歴'][k][:len(v)]==v
  assert current['状態履歴'][:len(old['状態履歴'])]==old['状態履歴']
 if name in ('before_state','post_state'):
  assert set(previous)==set(current)
  assert all(current[k]==previous[k] for k in current if k!='識別子状態')
  expected=dict(previous['識別子状態']);expected['照会']+=32;expected['学習判定']+=32;assert current['識別子状態']==expected
  assert len(current['台帳']['観測台帳'])==(204 if name=='before_state' else 210)
 if name.startswith('teach_'):assert len(current['台帳']['観測台帳'])==204+int(name[6:8])
 snap=wire(records['snapshot.'+name][0]);assert snap['receipt']['bytes']==len(raw) and snap['receipt']['sha256']==sha(raw)
 assert snap['ledger_slices']=={k:[len(previous['台帳'].get(k,())),len(v)] for k,v in current['台帳'].items()}
 assert snap['principle_history_slices']=={k:[len(previous['原理履歴'].get(k,())),len(v)] for k,v in current['原理履歴'].items()}
 assert snap['state_history_slice']==[len(previous['状態履歴']),len(current['状態履歴'])]
 snapshots.append({'name':name,'bytes':len(raw),'sha256':sha(raw),'observations':len(current['台帳']['観測台帳']),'principle_records':len(current['台帳']['原理台帳']),'counters':current['識別子状態']});previous=current
final=previous
assert len(final['台帳']['観測台帳'])==210 and len(final['台帳']['原理台帳'])==29
assert final['識別子状態']['照会']==final['識別子状態']['学習判定']==6822
expected_delta={'old_prefixes_equal':True,'ledger_appends':{k:v[len(baseline['台帳'].get(k,())):] for k,v in final['台帳'].items()},'principle_history_appends':{k:v[len(baseline['原理履歴'].get(k,[])):] for k,v in final['原理履歴'].items()},'state_history_appends':final['状態履歴'][len(baseline['状態履歴']):]}
assert plain(expected_delta)==json.loads((R/'native_full_delta.json').read_bytes())
delta=expected_delta['ledger_appends'];newobs=[x['値'] for x in delta['観測台帳']]
for i,x in enumerate(newobs):assert x['原入力']==c['plan'][32+i]['input']['内容'] and x['対象系境界']==c['plan'][32+i]['input']['対象系境界'] and x['経験識別子']==f'経験-{205+i:06d}'
principles=[p['値'] for p in delta['原理台帳']];assert len(principles)==2
source='候補色は選択された可視パレット色と一致';outcome='候補色は観測後の可視器具色と一致';boundary=c['plan'][0]['input']['対象系境界']
assert {(p['条件経路群'][0][0],p['結果経路'][0]) for p in principles}=={(source,outcome),(outcome,source)}
for p in principles:
 assert p['関係型']=='同値関係' and p['版']==1 and p['対象系境界']==boundary
 assert p['反証参照群']==() and p['除外反証参照群']==() and p['適用範囲']['条件数']==1
 assert all(type(v)is bool and json.loads(k[0]) is v for k,v in p['対応値表'])
 assert p['根拠参照群']==tuple(f'経験-{i:06d}' for i in range(205,208))
 assert final['状態履歴'][-1][p['系譜識別子']]==p['原理識別子']
 for x in newobs:assert x['対象系境界']==boundary and type(x['原入力'][source])is bool and x['原入力'][source] is x['原入力'][outcome]
assert len(expected_delta['state_history_appends'])==1
producer=json.loads((R/'result_audit.json').read_bytes());judgments=[o['内容']['学習成立状態'] for o in outputs[32:38]]
assert judgments==['接続途上','接続途上','成立確認','接続途上','接続途上','接続途上']
assert producer['teacher_outputs']==plain(outputs[32:38]) and producer['teacher_judgments']==judgments
keys=('予測群','競合群','追加観測要求群','識別不能群','係争中原理群','断定保留理由群','学習成立状態');raw_equal=[];diagnostics=[]
for i in range(32):
 before,after=outputs[i],outputs[i+38];r=producer['query_comparisons'][i]
 assert r['input']==c['plan'][i]['input'] and r['before']==plain(before) and r['after']==plain(after)
 raw_equal.append(records[f'{i+1:02d}.照会する.output'][0]==records[f'{i+39:02d}.照会する.output'][0])
 if i<2:
  assert before['状態']=='出力' and before['内容']['学習成立状態']=='適用外' and before['内容']['予測群']==[]
  pred=after['内容']['予測群'];assert len(pred)==1;pred=pred[0]
  value=c['plan'][i]['input']['内容'][source];assert type(pred['予測値'])is bool and pred['予測値'] is value and tuple(pred['結果経路'])==(outcome,)
  p=next(p for p in principles if p['原理識別子']==pred['原理参照']);assert p['条件経路群'][0][0]==source
  diagnostics.append({'before_status':before['状態'],'before_learning':before['内容']['学習成立状態'],'value':value,'prediction':pred['予測値'],'principle':pred['原理参照']})
 else:
  assert before['状態']==after['状態'] and all(before['内容'][k]==after['内容'][k] for k in keys)
  assert after['内容']['有効原理群'][:len(before['内容']['有効原理群'])]==before['内容']['有効原理群']
assert not any(raw_equal[2:])
meta,_=framed(R/'run01/metadata_logs.reserve');comp=[wire(b) for h,b,o in meta if h['name']=='completed'];assert len(comp)==1;comp=comp[0]
assert comp['native_calls_entered']==comp['native_calls_returned']==comp['fully_persisted_calls']==70 and comp['unprocessed_suffix']['exact_remaining_calls']==0
assert comp['entered_methods']==[r['method'] for r in c['plan']]
for name in ('worker_failure','worker_emergency'):assert framed(R/'run01'/(name+'.reserve'))[0]==[]
assert not any((R/'run01/failure_state.reserve').read_bytes())
sup=framed(R/'run01/supervisor_failure.reserve')[0];assert len(sup)==1;sup=wire(sup[0][1]);assert sup['status']=='PASS' and sup==json.loads((R/'native_supervisor.json').read_bytes())
verified={}
for root,manifest in [(B,B/'arc-native-teach-final-20261019/freeze_manifest.json'),(B/'arc-native-identity-20261019',B/'arc-native-identity-20261019/freeze_manifest.json'),(R,R/'freeze_manifest.json')]:
 m=json.loads(manifest.read_bytes())
 for rel,pin in m['files'].items():
  p=root/rel;assert p.stat().st_size==pin['bytes'] and sha(p.read_bytes())==pin['sha256'],str(p)
 verified[str(manifest)]=len(m['files'])
unit=sum(p.stat().st_size for p in R.rglob('*') if p.is_file());aggregate=unit+sum(p.stat().st_size for d in c['retained_directories'] for p in pathlib.Path(d).rglob('*') if p.is_file())
assert unit<96*1024**2 and aggregate<576*1024**2
assert used<c['evidence_upper_bound_bytes']<8*1024**2 and maxout==47312<c['reply_upper_bound_bytes']
assert snapshots[-1]['bytes']==6324220 and len(baselinebytes)==6116344
report={'verdict':'BOUNDED_COPY70_NATIVE_EVIDENCE_PASS','native_auditor_calls':0,'config_sha256':sha((R/'proposed_config.json').read_bytes()),'pins_verified':len(c['pins']),'calls':70,'queries':64,'teachers':6,'frames':219,'snapshots':snapshots,'old_prefixes_unchanged':True,'query_only_state_equal_except_exact_counters':True,'full_delta_verified':True,'final_counters':final['識別子状態'],'new_principles':plain(principles),'judgments':judgments,'diagnostics':diagnostics,'all30_old_relevant_projections_equal':True,'old_raw_equal':raw_equal[2:],'state_growth':207876,'max_reply_bytes':maxout,'evidence_used':used,'verified_manifests':verified,'unit_bytes':unit,'aggregate_bytes':aggregate,'supervisor':sup,'native_rss_KiB':comp['peak_rss_KiB'],'delta_counts':{k:len(v) for k,v in delta.items()}}
(O/'audit_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ('snapshots','new_principles')},ensure_ascii=False,indent=2))
