import sys,pathlib,ast,resource,unittest
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2);sys.dont_write_bytecode=True
ROOT=pathlib.Path('arc-native-copy-20261019').resolve();sys.path.insert(0,str(ROOT));import launcher
source=ast.parse((ROOT/'launcher.py').read_text());worker=next(n for n in source.body if isinstance(n,ast.FunctionDef) and n.name=='worker');t=next(n for n in worker.body if isinstance(n,ast.Try));persist=next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='persist')
ns=dict(vars(launcher));exec(compile(ast.fix_missing_locations(ast.Module(body=[persist],type_ignores=[])),'pure_persist','exec'),ns)
class Store:
 def __init__(self):self.rows=[]
 def append(self,*args):self.rows.append(args)
class Tests(unittest.TestCase):
 def setUp(self):self.s=Store();ns['store']=self.s
 def test_input_exact_cap(self):ns['persist']('01.照会する.input',b'x'*8192);self.assertEqual(len(self.s.rows),1)
 def test_input_excess_rejected(self):
  with self.assertRaises(launcher.HOLD):ns['persist']('01.照会する.input',b'x'*8193)
  self.assertFalse(self.s.rows)
 def test_output_bound62525_accepted(self):ns['persist']('01.照会する.output',b'x'*62525);self.assertEqual(len(self.s.rows),1)
 def test_output_exact64k_accepted(self):ns['persist']('01.照会する.output',b'x'*65536);self.assertEqual(len(self.s.rows),1)
 def test_output_over64k_rejected(self):
  with self.assertRaises(launcher.HOLD):ns['persist']('01.照会する.output',b'x'*65537)
  self.assertFalse(self.s.rows)
 def test_output_over128k_rejected(self):
  with self.assertRaises(launcher.HOLD):ns['persist']('01.照会する.output',b'x'*131073)
  self.assertFalse(self.s.rows)
 def test_snapshot_exact_cap(self):ns['persist']('snapshot.teach_15_state',b'x'*16384);self.assertEqual(len(self.s.rows),1)
 def test_snapshot_excess_rejected(self):
  with self.assertRaises(launcher.HOLD):ns['persist']('snapshot.teach_15_state',b'x'*16385)
  self.assertFalse(self.s.rows)
 def test_header_excess_rejected(self):
  with self.assertRaises(launcher.HOLD):ns['persist']('x'*300,b'a')
  self.assertFalse(self.s.rows)
if __name__=='__main__':unittest.main(verbosity=2)
