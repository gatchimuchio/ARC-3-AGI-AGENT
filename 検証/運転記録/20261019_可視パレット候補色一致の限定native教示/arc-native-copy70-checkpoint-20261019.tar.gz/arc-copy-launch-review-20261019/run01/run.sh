#!/bin/bash
set -e
for f in arc-copy-launch-review-20261019/test*.py; do python "$f"; done
