"""ONE explicitly parent-admitted COPY70 run; no retry path."""
import pathlib,json,hashlib,shutil,sys,resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2);sys.dont_write_bytecode=True
R=pathlib.Path(__file__).resolve().parent.parent;B=R.parent
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
EXPECTED='721a996a9c639ccda4f89aeecbc476b702f03241d921528d8812096a1917aea1'
raw=(R/'proposed_config.json').read_bytes();assert H(R/'proposed_config.json')==EXPECTED
assert H(R/'preparation_manifest.json')=='55a06baec1799d56ae8ab7c0ad239ff417bb0fa62b5d9fb2dcdd5f30718a287c'
assert H(R/'execution02/reviewed_manifest.json')=='8586a6858aefb51f8dfa5753c76fdf005f559f313e46cd2a53aee554c247eb9e'
config=json.loads(raw);assert config['explicit_parent_admission'] is False
for p,h in config['pins'].items():assert H(pathlib.Path(p))==h,p
# Explicit roots: identity producer closure uses paths relative to its own directory.
for manifest,root in [(R/'preparation_manifest.json',B),(B/'arc-native-identity-20261019/freeze_manifest.json',B/'arc-native-identity-20261019'),(R/'execution02/reviewed_manifest.json',B)]:
 root=root.resolve();assert root in (B.resolve(),(B/'arc-native-identity-20261019').resolve())
 for p,m in json.loads(manifest.read_bytes())['files'].items():
  relative=pathlib.Path(p);assert not relative.is_absolute() and '..' not in relative.parts
  f=(root/relative).resolve();assert f.is_relative_to(root)
  assert f.stat().st_size==m['bytes'] and H(f)==m['sha256'],p
baseline=B/'arc-native-identity-20261019/run01/post_state.reserve'
assert baseline.stat().st_size==6116344 and H(baseline)=='98992da7beb467584dca9e5b9541d179886c81bf07b1e5884af838e9ec9eb820'
assert not (R/'run01').exists()
retained={p:sum(f.stat().st_size for f in pathlib.Path(p).rglob('*') if f.is_file()) for p in config['retained_directories']}
prep=sum(f.stat().st_size for f in R.rglob('*') if f.is_file())
assert prep+92*1024**2+3*1024**2<96*1024**2
assert sum(retained.values())+96*1024**2<576*1024**2
assert shutil.disk_usage(R).free>=1024**3+92*1024**2
admission={'authority':'Explicit parent one-run COPY70 admission received 2026-10-19T04:20 UTC','config_sha256':EXPECTED,'calls':70,'sequence':'32Query/6processing/32Query','resource':config['resource'],'actual_retained_bytes':retained,'actual_preparation_bytes':prep,'free_bytes_before':shutil.disk_usage(R).free,'scope':config['scope'],'automatic_retry':False,'current_action_permission':False}
(R/'execution_admission.json').write_text(json.dumps(admission,ensure_ascii=False,indent=2)+'\n')
config['explicit_parent_admission']=True;sys.path.insert(0,str(R));import launcher
result=launcher.execute(config)
(R/'native_supervisor.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
assert (R/'proposed_config.json').read_bytes()==raw
print(json.dumps(result,ensure_ascii=False));raise SystemExit(0 if result['status']=='PASS' else 2)
