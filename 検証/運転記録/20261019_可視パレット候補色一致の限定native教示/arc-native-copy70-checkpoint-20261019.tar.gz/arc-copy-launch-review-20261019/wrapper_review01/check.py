import pathlib,json,hashlib,resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
B=pathlib.Path.cwd();R=B/'arc-native-copy-20261019';H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert H(R/'proposed_config.json')=='721a996a9c639ccda4f89aeecbc476b702f03241d921528d8812096a1917aea1'
assert (R/'launcher.py').read_bytes()==(R/'execution01/launcher.py').read_bytes()
n=0
for manifest,root in [(R/'preparation_manifest.json',B),(B/'arc-native-identity-20261019/freeze_manifest.json',B/'arc-native-identity-20261019'),(R/'execution02/reviewed_manifest.json',B)]:
 for p,m in json.loads(manifest.read_bytes())['files'].items():
  q=pathlib.Path(p);assert not q.is_absolute() and '..' not in q.parts
  f=(root/q).resolve();assert f.is_relative_to(root.resolve())
  assert f.stat().st_size==m['bytes'] and H(f)==m['sha256'];n+=1
print(json.dumps({'verified_files':n,'corrected_wrapper_sha256':H(R/'execution02/source.py'),'root_confinement':True,'config_launcher_unchanged':True,'native_calls':0}))
