import pathlib,json,hashlib,resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
P=pathlib.Path; root=P('arc-native-copy-20261019'); c=json.loads((root/'proposed_config.json').read_bytes());h=lambda p:hashlib.sha256(P(p).read_bytes()).hexdigest()
assert h(root/'proposed_config.json')=='721a996a9c639ccda4f89aeecbc476b702f03241d921528d8812096a1917aea1'
for p,d in c['pins'].items():assert h(p)==d,p
assert not c['explicit_parent_admission'] and not (root/'run01').exists()
p=c['plan'];old=json.loads(P('arc-native-identity-20261019/proposed_config.json').read_bytes())['plan']
assert p[2:32]==old[:30] and p[:32]==p[38:]
assert [r['method'] for r in p]==['照会する']*32+['処理する']*6+['照会する']*32
assert h(root/'binding.py')=='43574797de492ef1a49b7498ee23a4ac410935b6c1dc0432baa7b43b17a52720'
for n in ['binding.py','guard.py','bounded_store.py','gate_metadata.py','source_allowlist.py']:
 assert (root/n).read_bytes()==(P('arc-native-teach-final-20261019')/n).read_bytes(),n
assert c['state_upper_bound_bytes']==6638745 and c['reply_upper_bound_bytes']==62525 and c['evidence_upper_bound_bytes']==5956320
unit=sum(x.stat().st_size for x in root.rglob('*') if x.is_file())
retained=sum(x.stat().st_size for d in c['retained_directories'] for x in P(d).rglob('*') if x.is_file())
assert unit+92*1024**2<96*1024**2
assert retained+96*1024**2<576*1024**2
print(json.dumps({'pins':len(c['pins']),'config_sha256':h(root/'proposed_config.json'),'unchanged_passed_closure':True,'old30_inputs_identical':True,'nominal_frames':219,'unit_prep_bytes':unit,'retained_plus_full_new_unit':retained+96*1024**2,'proposed_aggregate':576*1024**2},indent=2))
