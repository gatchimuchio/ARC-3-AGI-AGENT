#!/bin/bash
set -e
cd arc-copy-launch-review-20261019/provided01
ulimit -v 524288
PYTHONDONTWRITEBYTECODE=1 python test_guard.py
PYTHONDONTWRITEBYTECODE=1 python test_import_attributes.py
