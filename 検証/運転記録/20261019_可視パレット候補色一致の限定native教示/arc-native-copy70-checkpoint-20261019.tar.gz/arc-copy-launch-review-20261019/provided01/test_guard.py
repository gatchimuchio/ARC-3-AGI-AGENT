import unittest,json
from guard import Guard
from bounded_store import HOLD,json_bytes
class Machine:
 def __init__(self):self.entries=[]
 def 照会する(self,x):self.entries.append(('照会する',x));return {'kind':'query','value':x}
 def 処理する(self,x):self.entries.append(('処理する',x));return {'kind':'process','value':x}
class Tests(unittest.TestCase):
 def guard(self,methods=('処理する','照会する'),machine=None,persist=None):
  m=machine or Machine();self.records=[]
  g=Guard(m,json_bytes,json.loads,persist or (lambda n,b:self.records.append((n,b))),[(k,json_bytes({'n':i})) for i,k in enumerate(methods)])
  return g,m
 def assert_latched(self,g):
  with self.assertRaises(HOLD):g.照会する({'n':1})
 def test_exact_processing_then_query(self):
  g,m=self.guard();a={'n':0};r=g.処理する(a);r['value']['n']=8
  self.assertEqual(a,{'n':0});self.assertEqual(m.entries[0][1],{'n':0});g.照会する({'n':1})
  self.assertEqual((g.calls,g.returned,g.completed),(2,2,2));self.assertEqual(len(self.records),6);self.assert_latched(g)
 def test_wrong_method_preentry(self):
  g,m=self.guard()
  with self.assertRaises(HOLD):g.照会する({'n':0})
  self.assertEqual(g.calls,0);self.assertFalse(m.entries);self.assert_latched(g)
 def test_wrong_input_preentry(self):
  g,m=self.guard()
  with self.assertRaises(HOLD):g.処理する({'n':8})
  self.assertEqual(g.calls,0);self.assertFalse(m.entries);self.assert_latched(g)
 def test_input_persistence_failure(self):
  def bad(*a):raise OSError('input store')
  g,m=self.guard(persist=bad)
  with self.assertRaises(OSError):g.処理する({'n':0})
  self.assertEqual((g.calls,g.returned,g.completed),(0,0,0));self.assertFalse(m.entries);self.assert_latched(g)
 def test_native_processing_exception(self):
  class Bad(Machine):
   def 処理する(self,x):raise ValueError('native partial change')
  g,m=self.guard(machine=Bad())
  with self.assertRaises(ValueError):g.処理する({'n':0})
  self.assertEqual((g.calls,g.returned,g.completed),(1,0,0));self.assert_latched(g)
 def test_output_persistence_failure(self):
  def bad(n,b):
   if n.endswith('.output'):raise OSError('output store')
  g,m=self.guard(persist=bad)
  with self.assertRaises(OSError):g.処理する({'n':0})
  self.assertEqual((g.calls,g.returned,g.completed),(1,1,0));self.assert_latched(g)
 def test_after_input_persistence_failure(self):
  def bad(n,b):
   if n.endswith('.input_after'):raise OSError('after input store')
  g,m=self.guard(persist=bad)
  with self.assertRaises(OSError):g.処理する({'n':0})
  self.assertEqual((g.calls,g.returned,g.completed),(1,1,0));self.assert_latched(g)
 def test_native_mutation(self):
  class Bad(Machine):
   def 処理する(self,x):x['n']=99;return x
  g,m=self.guard(machine=Bad())
  with self.assertRaises(HOLD):g.処理する({'n':0})
  self.assertEqual((g.calls,g.returned,g.completed),(1,1,0));self.assertEqual(len(self.records),3);self.assert_latched(g)
 def test_reentry(self):
  class Bad(Machine):
   def 処理する(self,x):return g.照会する({'n':1})
  g,m=self.guard(machine=Bad())
  with self.assertRaises(HOLD):g.処理する({'n':0})
  self.assertEqual((g.calls,g.returned,g.completed),(1,0,0));self.assert_latched(g)
 def test_exact_44_call_sequence(self):
  kinds=['照会する']*19+['処理する']*6+['照会する']*19
  g,m=self.guard(kinds)
  for i,k in enumerate(kinds):getattr(g,k)({'n':i})
  self.assertEqual((g.calls,g.returned,g.completed),(44,44,44));self.assertEqual(sum(k=='処理する' for k,x in m.entries),6)
  self.assertEqual(g.progress()['unprocessed_suffix']['exact_remaining_calls'],0);self.assert_latched(g)
 def test_finite_exact_suffix_on_failure(self):
  g,m=self.guard();g.処理する({'n':0});p=g.progress()
  self.assertEqual(p['entered_methods'],['処理する']);self.assertEqual(p['unprocessed_suffix']['methods'],['照会する'])
 def test_input_decode_failure_preentry(self):
  g,m=self.guard();g.decode=lambda b:(_ for _ in ()).throw(MemoryError())
  with self.assertRaises(MemoryError):g.処理する({'n':0})
  self.assertEqual((g.calls,g.returned,g.completed),(0,0,0));self.assert_latched(g)
 def test_output_encode_failure_after_return(self):
  g,m=self.guard();old=g.encode
  def enc(x):
   if 'kind' in x:raise MemoryError()
   return old(x)
  g.encode=enc
  with self.assertRaises(MemoryError):g.処理する({'n':0})
  self.assertEqual((g.calls,g.returned,g.completed),(1,1,0));self.assert_latched(g)
if __name__=='__main__':unittest.main(verbosity=2)
