"""Minimal exact-sequence Query/processing derivative; no native imports.
Preserves reviewed detached recorder semantics and failure latch.
"""
from bounded_store import HOLD
class Guard:
 def __init__(self,machine,encode,decode,persist,plan):
  self.machine=machine;self.encode=encode;self.decode=decode;self.persist=persist
  self.query=machine.照会する;self.process=machine.処理する
  self.plan=tuple((method,bytes(payload)) for method,payload in plan)
  if not self.plan or any(m not in ('照会する','処理する') for m,p in self.plan):raise HOLD('invalid exact plan')
  self.calls=0;self.returned=0;self.completed=0;self.busy=False;self.failed=False;self.pending=None
 def progress(self):
  return {'native_calls_entered':self.calls,'native_calls_returned':self.returned,
   'fully_persisted_calls':self.completed,'incomplete_entered_ordinal':self.calls if self.completed<self.calls else None,
   'pending_preentry_ordinal':self.pending if self.pending and self.pending>self.calls else None,
   'entered_methods':[m for m,p in self.plan[:self.calls]],
   'unprocessed_suffix':{'first_unentered_ordinal':self.calls+1,'exact_remaining_calls':len(self.plan)-self.calls,
    'methods':[m for m,p in self.plan[self.calls:]]},'automatic_resume':False}
 def _invoke(self,method,external):
  if self.failed or self.busy or self.calls>=len(self.plan):self.failed=True;raise HOLD('latched/reentry/budget')
  self.busy=True;self.pending=self.calls+1
  try:
   before=self.encode(external)
   if (method,before)!=self.plan[self.calls]:raise HOLD('exact method/input sequence mismatch')
   self.persist(f'{self.pending:02d}.{method}.input',before)
   isolated=self.decode(before)
   self.calls+=1
   # Only these two fixed frozen public methods are ever callable.
   if method=='処理する':reply=self.process(isolated)
   else:reply=self.query(isolated)
   self.returned+=1
   after=self.encode(isolated);output=self.encode(reply)
   self.persist(f'{self.calls:02d}.{method}.output',output)
   self.persist(f'{self.calls:02d}.{method}.input_after',after)
   if before!=after:raise HOLD('native input mutation')
   result=self.decode(output);self.completed+=1;self.pending=None
   return result
  except BaseException:self.failed=True;raise
  finally:self.busy=False
 def 照会する(self,external):return self._invoke('照会する',external)
 def 処理する(self,external):return self._invoke('処理する',external)
