"""Pure synthetic package checks, no frozen HDS source import/execution."""
import unittest,tempfile,pathlib,types,sys,hashlib
from binding import package_import_attributes
from bounded_store import HOLD
class Tests(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory();self.root=pathlib.Path(self.t.name).resolve();p=self.root/'型.py';p.write_text('synthetic fixture only')
  self.expected={'hds学習系統':'__init__.py','hds学習系統.型':'型.py'};self.pins={'型.py':hashlib.sha256(p.read_bytes()).hexdigest()}
  self.pkg=types.ModuleType('hds学習系統');self.child=types.ModuleType('hds学習系統.型');self.child.__file__=str(p)
  self.old=sys.modules.get('hds学習系統.型');sys.modules['hds学習系統.型']=self.child;self.pkg.型=self.child
 def tearDown(self):
  if self.old is None:sys.modules.pop('hds学習系統.型',None)
  else:sys.modules['hds学習系統.型']=self.old
  self.t.cleanup()
 def check(self):return package_import_attributes(self.pkg,self.expected,self.root,self.pins)
 def test_expected_module_attribute(self):self.assertEqual(self.check(),{'型'})
 def test_foreign_module_identity_rejected(self):
  self.pkg.型=types.ModuleType('hds学習系統.型');self.pkg.型.__file__=self.child.__file__
  with self.assertRaises(HOLD):self.check()
 def test_foreign_path_rejected(self):
  self.child.__file__=str(self.root/'other.py')
  with self.assertRaises(HOLD):self.check()
 def test_wrong_module_name_rejected(self):
  self.child.__name__='other'
  with self.assertRaises(HOLD):self.check()
 def test_nonmodule_rejected(self):
  self.pkg.型=lambda:None
  with self.assertRaises(HOLD):self.check()
 def test_changed_source_rejected(self):
  (self.root/'型.py').write_text('changed')
  with self.assertRaises(HOLD):self.check()
 def test_not_permitted_for_submodule(self):
  self.pkg.__name__='hds学習系統.系統';self.assertEqual(self.check(),set())
 def test_unknown_attribute_not_allowed(self):
  self.pkg.unknown=types.ModuleType('unknown');self.assertNotIn('unknown',self.check())
if __name__=='__main__':unittest.main(verbosity=2)
