"""Metadata-only diagnostics; never prints object values, constants or state."""
import hashlib,inspect,marshal,types,pathlib

def metadata(obj):
 out={'type':type(obj).__name__}
 for k in ('__name__','__module__','__qualname__','__file__'):
  v=getattr(obj,k,None)
  if isinstance(v,str):out[k]=v
 code=obj if isinstance(obj,types.CodeType) else getattr(obj,'__code__',None)
 if isinstance(code,types.CodeType):out['code']={'filename':code.co_filename,'qualname':code.co_qualname,'sha256':hashlib.sha256(marshal.dumps(code)).hexdigest()}
 return out

def failure(exc_type,*reason):
 frame=inspect.currentframe().f_back.f_back
 loc=frame.f_locals;context={'gate_function':frame.f_code.co_qualname,'gate_file':frame.f_code.co_filename}
 for key in ('name','key','attr','filename','module_name','qualname'):
  if isinstance(loc.get(key),str):context[key]=loc[key]
 for key in ('path','source','persistence_source'):
  if isinstance(loc.get(key),(str,pathlib.Path)):context[key]=str(loc[key])
 for key in ('value','method','fn','cls','actual','expected','owner','module','accessor','generated'):
  if key in loc:context[key]=metadata(loc[key])
 return exc_type(*reason,{'gate_context':context})
