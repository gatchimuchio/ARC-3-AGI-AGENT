"""Caller-side fixed allocation, preserving exact native bytes. Not an OS quota.
Single owner, reviewed Python writers only; no SDK or HDS imports.
"""
import hashlib, json, os, pathlib, resource, struct, threading, shutil

M = 1024**2
class HOLD(BaseException): pass
from gate_metadata import failure
def detailed_hold(*reason):return failure(HOLD,*reason)

def json_bytes(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode()

class Store:
    # Metadata AND stdout/stderr share this one enforced allocation.
    DEFAULT = {'evidence':16*M, 'metadata_logs':M, 'worker_failure':M,
               'supervisor_failure':M, 'worker_emergency':M, 'normal_state':8*M,
               'post_state':8*M, 'failure_state':8*M}
    def __init__(self, root, capacities=None, total_limit=96*M, existing_bytes=None):
        self.root = pathlib.Path(root)
        self.capacities = dict(self.DEFAULT if capacities is None else capacities)
        if any(type(n) is not int or n <= 0 for n in self.capacities.values()): raise detailed_hold('invalid capacities')
        measured=sum(p.stat().st_size for p in self.root.parent.rglob('*') if p.is_file())
        if existing_bytes is None: existing_bytes=measured
        if existing_bytes < measured: raise detailed_hold('existing bytes underreported')
        if existing_bytes < 0 or existing_bytes + sum(self.capacities.values()) > total_limit: raise detailed_hold('full reservation exceeds total admission')
        if shutil.disk_usage(self.root.parent).free < 1024**3 + sum(self.capacities.values()): raise detailed_hold('free storage floor plus full allocation')
        # New owned directory only; nothing from any previous run is reused.
        self.root.mkdir(mode=0o700, exist_ok=False)
        self.fds = {}; self.offsets = {}; self.names = set(); self.lock = threading.RLock()
        self.account = {'existing_bytes':existing_bytes,'reserved_bytes':sum(self.capacities.values()),
                        'total_limit':total_limit,'mode':'bounded reviewed writers; NOT OS hard quota',
                        'capacities':self.capacities}
        try:
            for name, size in self.capacities.items():
                fd = os.open(self.root/(name+'.reserve'), os.O_CREAT|os.O_EXCL|os.O_RDWR|os.O_NOFOLLOW, 0o600)
                self.fds[name] = fd; self.offsets[name] = 0
                os.posix_fallocate(fd, 0, size); os.fsync(fd)
            self.append('metadata_logs','admission',json_bytes(self.account))
            fd=os.open(self.root,os.O_RDONLY); os.fsync(fd); os.close(fd)
        except BaseException:
            self.close(); raise  # Retain every partial allocation.
    def append(self, region, name, payload):
        if type(payload) is not bytes: raise detailed_hold('exact bytes required')
        with self.lock:
            if name in self.names: raise detailed_hold('evidence name already used')
            head=json_bytes({'name':name,'bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest()})
            frame=struct.pack('>Q',len(head))+head+payload
            offset=self.offsets[region]
            if len(frame)>self.capacities[region]-offset: raise detailed_hold('region capacity: '+region)
            # Claim the full extent BEFORE writing; failed partial writes are never reused.
            self.offsets[region]+=len(frame); self.names.add(name)
            fd=self.fds[region]; done=0
            while done<len(frame):
                n=os.pwrite(fd,frame[done:],offset+done)
                if n<=0: raise OSError('short pwrite')
                done+=n
            os.fsync(fd)
            if os.pread(fd,len(frame),offset)!=frame: raise OSError('readback mismatch')
            return {'region':region,'offset':offset,'frame_bytes':len(frame)}
    def prepare_emergency(self, payload):
        head=json_bytes({'name':'precomputed_emergency','bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest()})
        frame=struct.pack('>Q',len(head))+head+payload
        if len(frame)>self.capacities['worker_emergency']: raise detailed_hold('emergency allocation')
        return frame
    def raw_emergency(self, frame):
        # Dedicated one-shot virgin region, preframed before worker work.
        # No JSON, traceback, concatenation, or filesystem allocation here.
        if self.offsets['worker_emergency']: return
        self.offsets['worker_emergency']=len(frame)
        if os.pwrite(self.fds['worker_emergency'],frame,0)!=len(frame): raise OSError('emergency short write')
        os.fsync(self.fds['worker_emergency'])
    def records(self, region):
        fd=self.fds[region]; offset=0; out=[]
        while offset<self.offsets[region]:
            n=struct.unpack('>Q',os.pread(fd,8,offset))[0]; offset+=8
            head=json.loads(os.pread(fd,n,offset)); offset+=n
            b=os.pread(fd,head['bytes'],offset); offset+=len(b)
            if len(b)!=head['bytes'] or hashlib.sha256(b).hexdigest()!=head['sha256']: raise detailed_hold('incomplete retained record')
            out.append((head,b))
        return out
    def close(self):
        for fd in self.fds.values(): os.close(fd)
        self.fds.clear()

class BoundedLog:
    def __init__(self,store,channel): self.store=store; self.channel=channel; self.n=0
    def write(self,text):
        if text:
            self.n+=1; self.store.append('metadata_logs',self.channel+str(self.n),text.encode())
        return len(text)
    def flush(self): pass

class NativeSaveSink:
    """Admit only exact native persistence's known single-file writer.
    The wrapper does not call it in pure tests. It needs a separate reserved
    state region; old artifacts are never opened. No generic path-writer mode.
    """
    def __init__(self, store): self.store=store; self.used=set()
    def save(self, region, writer, *, source_file, expected_sha256):
        # API source admission is caller supplied AND must equal the frozen
        # v0.4.2 persistence source pinned at implementation time.
        from source_allowlist import PERSISTENCE_SHA256
        source=pathlib.Path(source_file)
        if expected_sha256 != PERSISTENCE_SHA256 or hashlib.sha256(source.read_bytes()).hexdigest()!=PERSISTENCE_SHA256:
            raise detailed_hold('unreviewed/unbounded writer')
        import inspect
        from source_allowlist import SAVE_METHOD_PINS
        function=getattr(writer, '__func__', None)
        if function is None or function.__name__ != '保存する': raise detailed_hold('exact native bound save method required')
        codepath=pathlib.Path(inspect.getsourcefile(function))
        if SAVE_METHOD_PINS.get(codepath.name) != hashlib.sha256(codepath.read_bytes()).hexdigest(): raise detailed_hold('native API source pin')
        verify_native_binding(writer,source)
        with self.store.lock:
            if region not in ('normal_state','before_state','teach_01_state','teach_02_state','teach_03_state','teach_04_state','teach_05_state','teach_06_state','post_state','failure_state') or region in self.used or self.store.offsets[region]: raise detailed_hold('fresh state reservation required')
            self.used.add(region); self.store.offsets[region]=self.store.capacities[region]
            path=self.store.root/(region+'.reserve'); fd=self.store.fds[region]
            before=os.fstat(fd)
            if path.stat().st_ino != before.st_ino: raise detailed_hold('owned reservation identity')
            old=resource.getrlimit(resource.RLIMIT_FSIZE)
            cap=self.store.capacities[region]
            if old[1] != resource.RLIM_INFINITY and old[1]<cap: raise detailed_hold('state cap exceeds hard file limit')
            resource.setrlimit(resource.RLIMIT_FSIZE,(cap,old[1]))
            try:
                _allowed_native_paths.add(str(path.resolve()))
                writer(path)  # exact existing native API; no codec replacement
            finally:
                _allowed_native_paths.discard(str(path.resolve()))
                resource.setrlimit(resource.RLIMIT_FSIZE,old)
                os.fsync(fd)
                after=path.stat()
                if (after.st_dev,after.st_ino)!=(before.st_dev,before.st_ino) or after.st_size>cap: raise detailed_hold('native save violated owned reservation')
            return {'path':str(path),'bytes':after.st_size,'sha256':hashlib.sha256(os.pread(fd,after.st_size,0)).hexdigest()}


_allowed_native_paths=set()
def install_known_write_boundary():
    """Deny unadmitted Python path writers. Not a hostile native-code sandbox.
    Preallocated pwrite descriptors are held only by the reviewed Store.
    """
    import sys
    def audit(event,args):
        if event=='open':
            path,mode,flags=args
            writing=(flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)) if isinstance(flags,int) else False
            if writing and (not isinstance(path,(str,bytes,os.PathLike)) or str(pathlib.Path(path).resolve()) not in _allowed_native_paths):
                raise detailed_hold('unadmitted path writer')
        elif event in ('os.remove','os.rename','os.mkdir','os.rmdir','os.link','os.symlink','os.truncate'):
            raise detailed_hold('unadmitted filesystem mutation')
    sys.addaudithook(audit)

def verify_native_binding(writer, persistence_source):
    """Verify loaded code and delegation; source filenames alone grant nothing."""
    import sys,types
    from source_allowlist import SAVE_METHOD_PINS,PERSISTENCE_SHA256,HDS_MODULE_PINS
    def expected(path, qualname):
        code=compile(path.read_bytes(),str(path),'exec')
        def walk(c):
            if c.co_qualname==qualname: return c
            for child in c.co_consts:
                if isinstance(child,types.CodeType):
                    found=walk(child)
                    if found is not None:return found
        return walk(code)
    def verify_function(fn,path,pin,qualname):
        if not isinstance(fn,types.FunctionType) or hashlib.sha256(path.read_bytes()).hexdigest()!=pin or fn.__code__!=expected(path,qualname):raise detailed_hold('loaded native code mismatch')
    for name,loaded in tuple(sys.modules.items()):
        if not name.startswith('hds学習系統'): continue
        path=pathlib.Path(loaded.__file__)
        pin=HDS_MODULE_PINS.get(path.name)
        if pin is None or hashlib.sha256(path.read_bytes()).hexdigest()!=pin: raise detailed_hold('frozen module closure source')
        for key,value in tuple(vars(loaded).items()):
            if isinstance(value,types.FunctionType) and value.__module__==name:
                verify_function(value,path,pin,key)
            elif isinstance(value,type) and value.__module__==name:
                for attr,method in tuple(vars(value).items()):
                    if isinstance(method,(classmethod,staticmethod)):method=method.__func__
                    if isinstance(method,types.FunctionType) and method.__code__.co_filename==str(path):
                        verify_function(method,path,pin,value.__name__+'.'+attr)
    owner=getattr(writer,'__self__',None);fn=getattr(writer,'__func__',None)
    module_name=type(owner).__module__
    if module_name not in ('hds学習系統.系統','hds学習系統.実行系'):raise detailed_hold('native owner class')
    module=sys.modules.get(module_name);path=pathlib.Path(module.__file__)
    if getattr(module,type(owner).__name__,None) is not type(owner) or type(owner).__dict__.get('保存する') is not fn:raise detailed_hold('native class/method identity')
    verify_function(fn,path,SAVE_METHOD_PINS[path.name],type(owner).__name__+'.保存する')
    if module_name.endswith('.系統'):
        verify_native_binding(owner.エンジン.保存する,persistence_source)
    else:
        persistence=sys.modules.get('hds学習系統.永続化')
        if persistence is None or pathlib.Path(persistence.__file__).resolve()!=persistence_source.resolve():raise detailed_hold('persistence module identity')
        if fn.__globals__.get('書き出す') is not persistence.書き出す:raise detailed_hold('save delegation changed')
        verify_function(persistence.書き出す,persistence_source,PERSISTENCE_SHA256,'書き出す')
        verify_function(persistence._符号化,persistence_source,PERSISTENCE_SHA256,'_符号化')
        if persistence.書き出す.__globals__.get('_符号化') is not persistence._符号化:raise detailed_hold('codec delegation changed')
