#!/bin/bash
cd /workspace/scratch/a94ff513b3af
python arc-copy-pilot-plan-20261019/inventory01/source.py > arc-copy-pilot-plan-20261019/inventory01/stdout.log 2> arc-copy-pilot-plan-20261019/inventory01/stderr.log
s=$?; printf '%s\n' "$s" > arc-copy-pilot-plan-20261019/inventory01/exit_status.txt; exit "$s"
