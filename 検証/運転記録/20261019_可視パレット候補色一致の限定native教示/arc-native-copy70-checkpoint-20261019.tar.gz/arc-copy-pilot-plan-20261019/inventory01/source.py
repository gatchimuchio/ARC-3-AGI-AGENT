"""Read-only COPY proposal inventory, not an admission or native call."""
import pathlib,json,hashlib,resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
R=pathlib.Path(__file__).resolve().parent;B=R.parent.parent
p=B/'arc-widepaint-operation-teachers-20261019/qualified_contracts_v2/run01/teachers.proposal.runtime.json';a=json.loads(p.read_bytes());counts={}
for t in a:counts[t['対象系境界']]=counts.get(t['対象系境界'],0)+1
old=json.loads((B/'arc-native-identity-20261019/proposed_config.json').read_bytes());queries=old['plan'][:30]
assert len(queries)==30 and all(r['method']=='照会する' for r in queries)
state=B/'arc-native-identity-20261019/run01/post_state.reserve';assert state.stat().st_size==6116344 and hashlib.sha256(state.read_bytes()).hexdigest()=='98992da7beb467584dca9e5b9541d179886c81bf07b1e5884af838e9ec9eb820'
result={'proposal_boundaries_counts':counts,'proposal_first_rows':a[:6],'old_query_rows':len(queries),'old_boundary_count':len({r['input']['対象系境界'] for r in queries}),'state_bytes':state.stat().st_size,'state_sha256':hashlib.sha256(state.read_bytes()).hexdigest(),'native_calls':0}
(R/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False))
