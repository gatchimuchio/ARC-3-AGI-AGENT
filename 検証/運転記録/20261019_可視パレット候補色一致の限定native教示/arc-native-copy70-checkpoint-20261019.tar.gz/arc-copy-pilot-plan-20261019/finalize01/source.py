import pathlib,json,hashlib
R=pathlib.Path(__file__).resolve().parent.parent;B=R.parent
j=json.loads((R/'resource_proposal_v2.json').read_bytes());q=json.loads((R/'reply_proposal.json').read_bytes());j.update({'status':'STATIC_PROPOSAL_INDEPENDENT_REVIEW_PENDING','reply_cap_proposal':65536,'reply_proof_status':'provided in reply_proposal.json; independent review pending','reply_upper_bytes':q['reply_upper_bytes'],'evidence_upper_bytes':q['evidence_bound_bytes'],'source_experiences':204,'source_principle_versions':27,'source_counters':6758,'calls':70,'query_calls':64,'teacher_calls':6,'nominal_snapshots':9,'success_evidence_frames':219,'independent_measurement_pass':'arc-widepaint-operation-review-20261019/run03/result.json','current_state_sha256':'98992da7beb467584dca9e5b9541d179886c81bf07b1e5884af838e9ec9eb820'})
(R/'final_resource_proposal.json').write_text(json.dumps(j,indent=2)+'\n')
rows=[]
for n in ('teachers.runtime.json','queries.runtime.json','proposed_plan.json'):
 p=R/n;rows.append({'path':n,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(R/'payload_pins.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows))
