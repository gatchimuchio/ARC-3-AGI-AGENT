"""COPY6 exact offline candidate plan, semantic review/admission separate."""
import pathlib,json,hashlib,resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
R=pathlib.Path(__file__).resolve().parent.parent;B=R.parent;SRC=B/'arc-widepaint-operation-teachers-20261019/copy6_qualified_v2'
a=json.loads((SRC/'run01/teachers.runtime.json').read_bytes());assert len(a)==6
boundary=a[0]['対象系境界'];assert all(t['対象系境界']==boundary for t in a)
assert all(type(v)is bool for t in a for v in t['内容'].values());assert all(len(t['内容'])==2 and len(set(t['内容'].values()))==1 for t in a)
proposed=json.loads((SRC/'run01/queries.runtime.json').read_bytes());assert len(proposed)==6
q=[]
for x in proposed:
 if x not in q:q.append(x)
assert len(q)==2 and {next(iter(x['内容'].values())) for x in q}=={True,False}
old=json.loads((B/'arc-native-identity-20261019/proposed_config.json').read_bytes())['plan'][:30];assert all(x['method']=='照会する' for x in old)
q.extend(x['input'] for x in old);assert len(q)==32
plan=[{'method':'照会する','input':x} for x in q]+[{'method':'処理する','input':x} for x in a]+[{'method':'照会する','input':x} for x in q]
for n,x in [('teachers.runtime.json',a),('queries.runtime.json',q),('proposed_plan.json',{'explicit_native_admission':False,'plan':plan})]:(R/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
pins=[]
for p in sorted(SRC.rglob('*')):
 if p.is_file():pins.append({'path':str(p.relative_to(B)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(R/'measurement_source_pins.json').write_text(json.dumps(pins,ensure_ascii=False,indent=2)+'\n')
summary={'status':'OFFLINE_PROPOSED_MEASUREMENT_REVIEW_PENDING','teacher_count':6,'query_count_each_side':32,'total_native_calls_planned':70,'native_calls_executed':0,'palette_boundary':boundary,'input_fields':list(a[0]['内容']),'old_query_rows':30,'old_boundary_count':len({x['input']['対象系境界'] for x in old}),'all_clicks':101,'candidate_contrasts':584,'negative_candidates':483,'same_color_clicks':3,'grouping':'recording + before Boolean candidate/selected-role equality','new_environment_observations':0,'other_families':'entire original85cohort corpus retained; TURN/MASK not this plan'}
(R/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary,ensure_ascii=False))
