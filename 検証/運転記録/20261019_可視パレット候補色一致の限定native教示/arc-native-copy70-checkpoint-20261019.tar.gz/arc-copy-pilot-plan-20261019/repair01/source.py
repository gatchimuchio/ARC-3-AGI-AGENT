from pathlib import Path
R=Path(__file__).resolve().parent.parent;p=R/'static_bound.py';s=p.read_text();old="推論対象=False) for _ in range(2)]}";new="推論対象=False) for _ in range(4)]}";assert s.count(old)==1;s=s.replace(old,new);p.write_text(s)
print('Restored four native observations in exact-shaped experience envelope; only this field count changed.')
