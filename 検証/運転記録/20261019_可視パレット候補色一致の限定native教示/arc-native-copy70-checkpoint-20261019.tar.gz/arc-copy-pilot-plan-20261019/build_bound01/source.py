"""Generate pure COPY-specific serialization bounds from retained audited envelope source."""
from pathlib import Path
R=Path(__file__).resolve().parent.parent;B=R.parent
s=(B/'arc-identity-teacher-plan-20261019/static_bound.py').read_text()
changes=[("STATE=BASE/'arc-native-teach-final-20261019/run01/post_state.reserve'","STATE=BASE/'arc-native-identity-20261019/run01/post_state.reserve'"),('len(ts)==15','len(ts)==6'),("len(s['台帳']['観測台帳'])==189","len(s['台帳']['観測台帳'])==204"),("len(s['台帳']['原理台帳'])==19","len(s['台帳']['原理台帳'])==27"),('==6698','==6758'),('len(boundaries)==2','len(boundaries)==1'),('REFS=(R,)*15','REFS=(R,)*6'),('range(4)','range(2)'),('len(snapshot)==20','len(snapshot)==22'),('range(15)','range(6)'),("'条件種類数':15","'条件種類数':6"),('units=15*9','units=6*9')]
for a,b in changes:assert a in s,a;s=s.replace(a,b)
(R/'static_bound.py').write_text(s)
s=(B/'arc-identity-teacher-plan-20261019/refine_bound.py').read_text().replace('15*base','6*base').replace("'slots':19","'slots':10").replace('19*8*1024**2','10*8*1024**2').replace("'evidence_proposed_bytes':12*1024**2","'evidence_proposed_bytes':8*1024**2").replace('168*1024**2','92*1024**2').replace("'report_code_allowance_bytes':8*1024**2","'report_code_allowance_bytes':4*1024**2").replace('176*1024**2','96*1024**2')
(R/'refine_bound.py').write_text(s)
s=(B/'arc-identity-teacher-plan-20261019/reply_bound.py').read_text().replace('len(active)==16','len(active)==20').replace('range(4)','range(2)').replace("'active_old':16,'active_max':20","'active_old':20,'active_max':22").replace('131072','65536').replace('75*65536+150*8192+19*16384+244*264','70*65536+140*8192+10*16384+220*264').replace('12*1024**2','8*1024**2')
(R/'reply_bound.py').write_text(s)
print('Prepared static scripts only; no native imports.')
