#!/bin/bash
cd /workspace/scratch/a94ff513b3af
for script in static_bound refine_bound reply_bound; do
 python arc-copy-pilot-plan-20261019/$script.py > arc-copy-pilot-plan-20261019/bound02/$script.stdout.log 2> arc-copy-pilot-plan-20261019/bound02/$script.stderr.log
 s=$?; printf '%s\n' "$s" > arc-copy-pilot-plan-20261019/bound02/$script.exit_status.txt
 if [ "$s" -ne 0 ]; then exit "$s"; fi
done
