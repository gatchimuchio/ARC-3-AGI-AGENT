# Independent semantic rehost review

## Bounded result: PASS for relocation equivalence only

The separately named, unadopted semantic route preserves the selected existing algorithms. No new regression found within the audited pure/mock scope. Native execution and Action adoption remain gated.

- Read all three supplied Owner originals, AGENTS, hierarchy and current state before reviewing. No authority, core, Git or implementation changes.
- Independently verified all 13 origin/authority manifest records and compared the seven source origins directly to the separately preserved offline baseline. This is pinned local identity, not independent current remote HEAD verification.
- Reexecuted supplied suite in the review directory: 192 exact full output/query-trace/mock-memory comparisons plus three terminal/unsupported/malformed comparisons passed. The latter normalize traceback fields and are not byte-identical full-output claims. Raw traces remain available.
- Separate 32-case probe uses its own literal response oracle rather than derivative constants/result logic; all original-versus-derivative comparisons passed. Distinct function objects and original/derivative code filenames were checked. Reference candidate, family, semantic and fixed enumeration paths are independently compiled from originals. This is meaningful relocation equivalence, not independent evidence of algorithm correctness.
- Selected function/class AST identities and byte-identical preservation source hold. The reference invokes original `_bind_fixed`; the derivative receives the separately build-time transformed enumeration. Supplied test fixtures share the same mock responder, whose boundary constants partly come from the derivative, so those tests alone are not a wholly independent contract oracle. The added literal oracle mitigates that limitation for the exercised boundaries.
- Independent structural-count oracle checks inventory candidates + every slot when selection is visible + submission, and a mapping query for every candidate. Unique and multiple-goal effect and preservation boundaries are exercised. No top-k or heuristic deletion found. Candidate order is advisory, and every execution permission remains false. Completeness is within this existing restricted structural grammar, not all pixel/action interpretations or 25-game coverage.
- Permuted evidence references containing game/level/file/hash-like identities leave candidate targets/actions/effect decisions unchanged. Runtime semantic entry has no provenance/game-ID parameter. Evidence references establish support presence but their specific identifier values do not route solutions.
- AS limit: 512 MiB. Supplied rerun peak RSS: 60328 KiB. Review and then-current implementation directories combined approximately 21 MiB, below 96 MiB. No native HDS/SDK imports, native restore/Query/Teach, live Action or Git writes.

## Reproduced inherited weaknesses, not new relocation defects

A unique fixture still forms its goal pool and two structural candidates with eight mock queries when (independently) role predictions lack support references, goal-relation replies contain disputes, or goal-relation state is `UNKNOWN`. Both original and derivative behave identically. `family.照会` accepts a single prediction for any state other than `断定保留` and does not gate disputes, reasons or supporting references. `semantic_entry.RolesView` tightens role output state/disputes/reasons, but does not require role support references, and does not gate goal-relation replies. Thus the phrase “HDS-supported goal/roles” needs additional validation at an eventual binding. This unit must not silently fix the historical algorithm and still claim exact equivalence.

The outer permission flags stay false in all such probes; effect-query validation does gate its own state/support/conflict/dispute. Those facts prevent interpreting the above as an executed unsafe action, but do not establish a safe future adopter. Aggregate `全体採否` is not an all-errors HOLD latch: it is primarily dispute-based, and other candidate-level HOLD/UNKNOWN records remain. The semantic route has no native-persistence exception/reentry latch of its own. Callback exceptions outside its limited catches, and exhaustive-enumeration resource exhaustion, require an outer fail-closed recorder; query upper bounds are not CPU/memory bounds. Fixed perception dimensions, finite/repeating grammar and limited preservation operation classes remain fixed prior assumptions, not learned universal rules.

## Actual next gates

1. Explicitly bind this exact semantic route to the previously tested detached decision/persistence scaffold and rerun that scaffold's reentry, mutation, failure and no-follow-on-call tests against the exact combined methods.
2. Validate exact native reply contracts, evidence/support lineage and all goal/role HOLD conditions before any adopted selection. Reject unsafe/unknown replies in a separately named binding or declare an exact algorithm change and retest it; do not edit fixed HDS core.
3. Bound actual exhaustive workload and native serialization/restore/save resource use; establish native roundtrip/failure semantics with retained failure evidence.
4. Audit public-teacher provenance and source-to-Teach predicates, then execute only a separately scoped/authorized bounded native restore/Query/Teach pilot. Native query counters are not learning or transfer evidence.
5. Live SDK decision-to-action binding, after-observation, hidden-unknown status/reward/legality/level checks and fresh-instance causal regression remain separate gates. No capability improvement is established here.

Evidence: `supplied_rerun/report.json`, complete supplied raw traces, `probes.py`, `probes.json`, and `reviewed_hashes.json`. Reviewer wrote only this separate directory. Final delivery-manifest verification belongs to the artifact owner after finalization; reviewed code hashes identify the exact audited content.
