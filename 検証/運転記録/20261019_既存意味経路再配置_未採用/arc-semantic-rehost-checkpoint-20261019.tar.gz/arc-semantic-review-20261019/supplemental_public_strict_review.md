# Supplemental review: current strict public-input comparison

PASS. Independently inspected and reran the current saved-public-input diagnostic under a 512 MiB address-space limit. No native calls or implementation changes.

The previous reviewed file is preserved at `arc-semantic-rehost-20261019/reports/public01/check_saved_public_inputs.py`: 3869 bytes, SHA-256 `9c5c31c04945f89a93b9bcab0013b32156715a279aa4bc2a0e87747a4a4848be`.

Current `arc-semantic-rehost-20261019/tests/check_saved_public_inputs.py`: 3845 bytes, SHA-256 `eaed554daa03c6fd1483067f540b3dbcda812415032397a04d900cc92bc71e49`.

The sole diff is strengthening `assert pack(normalized(pair[0]))==pack(normalized(pair[1]))` to `assert pack(pair[0])==pack(pair[1])`. Thus traceback differences are no longer masked in this test. The unused normalized import remains harmless. No original runtime/derivative semantics changed.

The independent current rerun passed archive receipt validation, all 25 packet hashes and 27 frame phases, selecting one minimum-inventory structurally applicable terminal observation (four inventory tokens/four slots) without ID-based selection. Original/derivative raw packed result, trace and bounds are equal; equality was also checked directly in the saved report. This remains a mock-response equivalence diagnostic, not native learning/capability measurement.

The implementation's current verify_manifest.py returned PASS (13 verified origins, delivery manifest content checked by that verifier). Original review and reviewed_hashes.json were not overwritten. Their older test hash remains historical evidence; this supplement establishes review coverage for the exact current hash above.

Independent evidence: `public_strict_stdout.json` and `public_strict_current/public_input_report.json` plus its selected whole public packet, all in this separate review directory. No additional blocker to publication of the bounded artifact; all previously documented native/action-adoption gates remain.
