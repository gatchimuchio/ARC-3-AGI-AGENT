import ast, hashlib, importlib.util, json, sys
from pathlib import Path
from copy import deepcopy
ROOT=Path(__file__).resolve().parent.parent
R=ROOT/'arc-semantic-rehost-20261019'
spec=importlib.util.spec_from_file_location('fixture',R/'tests/test_equivalence.py');t=importlib.util.module_from_spec(spec);sys.modules['fixture']=t;spec.loader.exec_module(t)
ref=t.reference();new=t.route.構成する(t.External)
report={'pins':[],'distinct_executors':{},'cases':[],'errors':[]}
def check(v,label):
 if not v:report['errors'].append(label)
for p in json.loads((R/'origin_manifest.json').read_text())['files']:
 path=R/p['local_origin'] if 'local_origin'in p else Path(p['authority_reference'])
 raw=path.read_bytes();ok=len(raw)==p['bytes'] and hashlib.sha256(raw).hexdigest()==p['sha256'];check(ok,str(path));report['pins'].append({'path':str(path),'pass':ok})
 if 'destination'in p:check(raw==(ROOT/'arc-offline-restart-20261019/extracted/arc-restart-baseline-20261016'/p['destination']).read_bytes(),'baseline '+p['destination'])
for label,a,b in [('semantic',ref[2],new[2]),('family',ref[0].内容候補を構成する,new[0].内容候補を構成する),('candidate',ref[1].全作用候補を構成する,new[1].全作用候補を構成する)]:
 report['distinct_executors'][label]={'different_objects':a is not b,'original_file':a.__code__.co_filename,'derivative_file':b.__code__.co_filename};check(a is not b,label)
# Independent response oracle: use only exact incoming contract words; never call production result logic.
class Oracle:
 def __init__(self,variant='normal',tag='reference-A'):self.owner=self;self.calls=[];self.variant=variant;self.tag=tag
 def allow_frame(self,n):self.bound=n
 def 照会する(self,x):
  b=x.対象系境界;f=x.内容;state='出力'
  if '記号外形と展開役割'in b:k='列展開役割';v='参照' if f['記号は中空'] else '出力'
  elif '観測された解答作業と行動ID'in b:k='必要行動ID';v=1 if f['解答作業']=='完成列提出' else 6
  elif '目標長一致と提出受理'in b:k='提出が受理された';v=f['終端条件に応じた列が一致']
  elif '末相不足修復'in b:k='応答末相で不足が修復された';v=next(iter(f.values()))
  elif '末相準備成立'in b:k='応答末相で要求適合する在庫選択表示が成立';v=next(iter(f.values()))
  elif '全相保存'in b:k='応答全相で既充足枠が保持された';v=True
  elif '末相可解性保持修復'in b:k='応答末相で不足枠が減少し成立可能目標が残った';v=next(iter(f.values()))
  elif '在庫選択準備'in b:k='応答全相で実クリック在庫対象が選択表示された';v=next(iter(f.values()))
  elif '全相充填保存'in b:k='応答全相で操作前の全充填枠が保存された';v=True
  else:raise AssertionError(b)
  p={'結果経路':(k,),'予測値':v,'原理参照':self.tag};c={'予測群':[p],'係争中原理群':[],'断定保留理由群':[]}
  if self.variant=='role_no_support' and k=='列展開役割':p.pop('原理参照')
  if self.variant=='goal_dispute' and k=='提出が受理された':c['係争中原理群']=['disputed']
  if self.variant=='goal_unknown_state' and k=='提出が受理された':state='UNKNOWN'
  r=t.Reply(state,c,{'provenance':self.tag});self.calls.append((deepcopy(x),deepcopy(r)));return r
 def ask(self,b,f):
  r=self.照会する(t.External(deepcopy(f),b));return vars(r)
for kind in ('unique','empty','complete','multiple'):
 for selected in (False,True):
  for variant in ('normal','role_no_support','goal_dispute','goal_unknown_state'):
   pairs=[]
   for family,candidate,semantic in (ref[:3],new):
    m=Oracle(variant);r=semantic(family,candidate,t.frame(kind,selected),[1,6],m,m.ask,'NOT_FINISHED');pairs.append((r,m.calls))
    check(r['実行許可'] is False,'permission')
    cs=r.get('全作用候補')
    if cs:
     scene=r['場面'];expected=len(scene['在庫群'])+1+(sum(len(b['枠群']) for b in scene['容器群']) if r['選択観測']['selection'] is not None else 0)
     check(len(cs['全候補'])==expected,'candidate cardinality')
     check(all(c['照会全件'][0]['境界']=='公開列図式:観測された解答作業と行動ID' for c in cs['全候補']),'mapping per candidate')
   check(t.pack(pairs[0])==t.pack(pairs[1]),f'{kind}/{selected}/{variant}')
   r,calls=pairs[1];report['cases'].append({'kind':kind,'selected':selected,'variant':variant,'goal_state':r['全目標pool']['状態'],'candidate_count':len((r['全作用候補'] or {}).get('全候補',[])),'queries':len(calls),'all_boundaries':[x.対象系境界 for x,_ in calls],'permission':r['実行許可']})
# Provenance tag permutation changes only evidence fields, not candidate/action/effect outputs.
def decisions(r):
 return [(c['対象区分'],c['対象'],c['作用'],c['効果状態']) for c in r['全作用候補']['全候補']]
values=[]
for tag in ('game-A/level-1/file-X/hash-X','game-B/level-999/file-Y/hash-Y'):
 m=Oracle(tag=tag);family,candidate,semantic=new;values.append(decisions(semantic(family,candidate,t.frame('multiple',True),[1,6],m,m.ask,'NOT_FINISHED')))
check(values[0]==values[1],'provenance independence');report['provenance_permutation_pass']=values[0]==values[1]
report['status']='PASS' if not report['errors'] else 'FAIL'
(Path(__file__).parent/'probes.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({'status':report['status'],'errors':report['errors'],'cases':len(report['cases'])}))
