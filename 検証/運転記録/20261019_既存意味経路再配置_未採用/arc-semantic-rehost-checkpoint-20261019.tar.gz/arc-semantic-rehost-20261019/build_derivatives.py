"""Build explicit-injection derivatives; does not execute original modules."""
import ast, hashlib, json
from pathlib import Path
from copy import deepcopy
R=Path(__file__).resolve().parent
B=R.parent/'arc-offline-restart-20261019/extracted/arc-restart-baseline-20261016'
NAMES=['candidate_query_v5.py','candidate_goalset_v2.py','candidate_preservation_v1.py','goalset_common_v4.py','列図式規則.py','図式観測.py','ARC3境界.py']
pins=json.loads((B/'pins.json').read_text())['files'];manifest=[]
for name in NAMES:
 raw=(B/'source'/name).read_bytes();p=next(p for p in pins if p['destination']=='source/'+name)
 assert len(raw)==p['bytes'] and hashlib.sha256(raw).hexdigest()==p['sha256']
 dest=R/'origins'/name
 with dest.open('xb') as f:f.write(raw)
 manifest.append({**p,'local_origin':'origins/'+name})
for p in list((R.parent/'arc-preservation-recovery-20261019/authority').glob('*'))+list((R.parent/'arc-preservation-recovery-20261019/main').rglob('*')):
 if p.is_file():
  b=p.read_bytes();manifest.append({'authority_reference':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'read_at_unit_start':True})
(R/'origin_manifest.json').write_text(json.dumps({'main_as_supplied_by_parent':'ebd00822db48995e024fe3ea15ea71c976edac34','files':manifest},ensure_ascii=False,indent=2))
def tree(name):return ast.parse((R/'origins'/name).read_text())
def fragment(name,node):return ast.get_source_segment((R/'origins'/name).read_text(),node)
def factory(filename,name,args,imports,nodes,origin,exports,extra=''):
 body='\n\n'.join(fragment(origin,n) for n in nodes)
 code='"""未採用・明示依存注入派生。原文の選択関数本体は不変。"""\n'+imports+'\nfrom types import SimpleNamespace\n\ndef '+name+'('+args+'):\n'
 code+='\n'.join('    '+line if line else '' for line in (extra+'\n'+body).splitlines())+'\n'
 code+='    return SimpleNamespace('+', '.join(x+'='+x for x in exports)+')\n'
 (R/'source'/filename).write_text(code)
fam=tree('列図式規則.py');fn=['記号を読む','容器外形を観測する','図式を観測する','列を生成する','一致する','照会','内容候補を構成する','選択を読む']
const=['役割境界','目標境界','作用境界','構造境界','適用前提']
nodes=[n for n in fam.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in fn+['知覚不適用'] or isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in const for t in n.targets)]
factory('family_rehost.py','構成する','外部入力','from collections import Counter\nfrom copy import deepcopy\nimport itertools',nodes,'列図式規則.py',fn+const+['知覚不適用'])
# Preservation source is already pure; retain it byte for byte under a new name.
(R/'source/preservation_rehost.py').write_bytes((R/'origins/candidate_preservation_v1.py').read_bytes())
c=tree('goalset_common_v4.py');cn=['exact','require','goalset_pool','slot_map','skeleton','token_key','goalset_base','hit','goalset_preconditions']
cs=[n for n in c.body if isinstance(n,ast.Assign) and all(isinstance(t,ast.Name) and t.id not in ('FAMILY','LEGACY','legacy','_FIXED') for t in n.targets)]
nodes=cs+[n for n in c.body if isinstance(n,ast.FunctionDef) and n.name in cn]
factory('goalset_common_rehost.py','構成する','legacy, _FIXED','from copy import deepcopy\nfrom collections import Counter',nodes,'goalset_common_v4.py',cn+[n.targets[0].id for n in cs]+['legacy'])
# Exactly the original _bind_fixed transformation, moved to build time with injected source.
original=next(n for n in fam.body if isinstance(n,ast.FunctionDef) and n.name=='内容候補を構成する')
start=next(i for i,n in enumerate(original.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='slots' for t in n.targets))
suffix=deepcopy(original.body[start:]);ret=suffix[-1].value;keep=('状態','候補数','全数確認した相異なる割当数','候補','不採用理由集計','実行許可');pairs=[(k,v) for k,v in zip(ret.keys,ret.values) if k.value in keep];assert tuple(k.value for k,v in pairs)==keep
suffix[-1]=ast.Return(ast.Dict(keys=[k for k,v in pairs],values=[v for k,v in pairs]));args=ast.arguments(posonlyargs=[],args=[ast.arg(arg='scene'),ast.arg(arg='roles')],kwonlyargs=[],kw_defaults=[],defaults=[])
fixed=[deepcopy(n) for n in fam.body if isinstance(n,ast.FunctionDef) and n.name in ('列を生成する','一致する')]+[ast.FunctionDef(name='_enumerate',args=args,body=suffix,decorator_list=[])]
(R/'source/fixed_enumeration_rehost.py').write_text('"""既存_bind_fixedの同一AST変換。全列挙、不採用も保持。"""\nfrom collections import Counter\nimport itertools\n'+ast.unparse(ast.fix_missing_locations(ast.Module(body=fixed,type_ignores=[])))+'\n')
g=tree('candidate_goalset_v2.py');nodes=[n for n in g.body if isinstance(n,ast.FunctionDef)]
factory('goalset_candidate_rehost.py','構成する','common','from copy import deepcopy',nodes,'candidate_goalset_v2.py',['全作用候補を構成する','作用境界','目標境界'],extra='legacy=common.legacy\n作用境界=legacy.作用境界\n目標境界=legacy.目標境界')
s=next(n for n in tree('candidate_query_v5.py').body if isinstance(n,ast.FunctionDef) and n.name=='semantic_entry')
(R/'source/semantic_entry_rehost.py').write_text('"""原semantic_entry本体不変。実行/状態復元/旧loaderなし。"""\nfrom copy import deepcopy\nimport traceback\n\n'+fragment('candidate_query_v5.py',s)+'\n')
print('built explicitly injected semantic closure')
