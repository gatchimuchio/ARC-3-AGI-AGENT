"""Bounded saved public packet verification; no SDK, runtime, teacher extraction."""
import base64,hashlib,json,tarfile,sys
from pathlib import Path
from test_equivalence import R,route,External,reference,Machine,pack,normalized
root=R.parent/'arc-preservation-recovery-20261019/remaining'
archive=root/'official-connection-checkpoint-sanitized-20261016.tar.gz'
receipt=json.loads((root/'remaining_origin_official_derivative.json').read_text())
b=archive.read_bytes();assert len(b)==receipt['output']['bytes'] and hashlib.sha256(b).hexdigest()==receipt['output']['sha256']
out=R/'reports'/sys.argv[1];out.mkdir(exist_ok=False)
packets={};manifest=None
with tarfile.open(archive,'r|gz') as tf:
 for m in tf:
  wanted=m.name.startswith('arc-official-fresh-all25-20261013/observation/') and m.name.endswith('.public.json')
  if wanted or m.name=='manifest.json':
   assert m.isfile() and m.size<=1024*1024
   raw=tf.extractfile(m).read(1024*1024+1);assert len(raw)==m.size
   if wanted:packets[m.name]=raw
   else:manifest=json.loads(raw)
assert manifest and len(packets)==25
index={x['member']:x for x in manifest['source_entries']};f,c,s=route.構成する(External);records=[];eligible=[]
for name,raw in packets.items():
 item=index[name];assert len(raw)==item['bytes'] and hashlib.sha256(raw).hexdigest()==item['sha256']
 p=json.loads(raw);assert p['frame_count']==len(p['frames'])
 for phase,fr in enumerate(p['frames']):
  pixels=base64.b64decode(fr['base64'],validate=True)
  assert fr['dtype']=='|i1' and fr['order']=='C' and fr['shape']==[64,64] and len(pixels)==4096 and hashlib.sha256(pixels).hexdigest()==fr['sha256'] and all(x<=15 for x in pixels)
  frame=[list(pixels[j:j+64]) for j in range(0,4096,64)]
  r={'member':name,'sha256':item['sha256'],'bytes':len(raw),'phase':phase,'terminal_phase':phase==len(p['frames'])-1,'state':p['model_json'].get('state'),'applicability':None}
  try:
   scene=f.図式を観測する(frame);r.update({'applicability':'fixed family','inventory':len(scene['在庫群']),'slots':sum(len(b['枠群']) for b in scene['容器群'])})
   if r['terminal_phase'] and r['state']=='NOT_FINISHED':eligible.append((r,frame,p))
  except (ValueError,TypeError,KeyError) as e:r.update({'applicability':'HOLD','exception':{'type':type(e).__name__,'args':e.args}})
  records.append(r)
# A bounded new diagnostic workload, selected by structural size only, never a runtime solution route.
eligible.sort(key=lambda x:x[0]['inventory']);selected=eligible[0] if eligible else None
result={'archive':{'path':str(archive),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()},'packets':25,'phases':len(records),'all_applicability_records':records,'selection_scope':'One minimum-inventory applicable terminal observation for a bounded diagnostic, not capability coverage or runtime ID routing','selected':selected[0] if selected else None}
if selected:
 r,frame,p=selected
 assert r['inventory']<=8,'Full enumeration workload not admitted; no pruning'
 raw=packets[r['member']];(out/'selected_whole_public.json').write_bytes(raw)
 pair=[]
 for family,candidate,semantic in (reference()[:3],(f,c,s)):
  m=Machine('normal')
  # Source packets expose public available_actions as numeric strings/enums: do not invent conversions.
  actions=p['model_json']['available_actions']
  assert all(type(x)is int for x in actions),repr(actions)
  value=semantic(family,candidate,frame,actions,m,m.ask,p['model_json']['state'])
  pair.append({'result':value,'trace':m.calls,'bounds':m.bounds})
 assert pack(normalized(pair[0]))==pack(normalized(pair[1]))
 result['exact_semantic_comparison']=pack(pair)
result['status']='PASS';(out/'public_input_report.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in result.items() if k not in ('all_applicability_records','exact_semantic_comparison')},ensure_ascii=False))
