"""Read-only content verification. No import of any preserved launcher."""
import hashlib,json
from pathlib import Path
R=Path(__file__).resolve().parent

def verify_origins():
    manifest=json.loads((R/'origin_manifest.json').read_text())
    for item in manifest['files']:
        p=R/item['local_origin'] if 'local_origin'in item else Path(item['authority_reference'])
        if p.is_symlink():raise ValueError('symlink origin')
        b=p.read_bytes()
        if len(b)!=item['bytes'] or hashlib.sha256(b).hexdigest()!=item['sha256']:raise ValueError('origin differs: '+str(p))
    return len(manifest['files'])

def verify():
    n=verify_origins()
    m=R/'delivery_manifest.json'
    if m.exists():
        for item in json.loads(m.read_text())['files']:
            p=R/item['path']
            if p.is_symlink():raise ValueError('symlink delivery')
            b=p.read_bytes()
            if len(b)!=item['bytes'] or hashlib.sha256(b).hexdigest()!=item['sha256']:raise ValueError('delivery differs: '+str(p))
    return n
if __name__=='__main__':print(json.dumps({'verified_origins':verify(),'status':'PASS'}))
