"""Original AST reference versus explicit derivatives. No historical top level."""
import ast, base64, hashlib, itertools, json, resource, sys, traceback, types
from collections import Counter
from copy import deepcopy
from dataclasses import dataclass
from pathlib import Path
R=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(R))
from verify_manifest import verify_origins
verify_origins()
sys.path.insert(0,str(R/'source'))
import semantic_route_rehost as route
import fixed_enumeration_rehost as fixed
import preservation_rehost as preservation

@dataclass
class External:
    内容:dict
    対象系境界:str
@dataclass
class Reply:
    状態:str
    内容:dict
    追跡情報:dict

def pack(v):
    if isinstance(v,(External,Reply)):return {'__type__':type(v).__name__,'fields':pack(vars(v))}
    if isinstance(v,dict):return {'__dict__':[[pack(k),pack(x)] for k,x in v.items()]}
    if isinstance(v,tuple):return {'__tuple__':[pack(x) for x in v]}
    if isinstance(v,list):return [pack(x) for x in v]
    return v

def orig(name):return ast.parse((R/'origins'/name).read_bytes())
def execute(nodes,ns,name):
    exec(compile(ast.fix_missing_locations(ast.Module(body=deepcopy(nodes),type_ignores=[])),str(R/'origins'/name),'exec'),ns)
    return types.SimpleNamespace(**ns)
def constants(tree,excluded=()):
    return [n for n in tree.body if isinstance(n,ast.Assign) and all(isinstance(t,ast.Name) and t.id not in excluded for t in n.targets)]
def reference():
    f=orig('列図式規則.py');names={'記号を読む','容器外形を観測する','図式を観測する','列を生成する','一致する','照会','内容候補を構成する','選択を読む','知覚不適用'}
    ns={'Counter':Counter,'deepcopy':deepcopy,'itertools':itertools,'外部入力':External}
    family=execute(constants(f)+[n for n in f.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in names],ns,'列図式規則.py')
    p=orig('candidate_preservation_v1.py');legacy=execute(constants(p)+[n for n in p.body if isinstance(n,ast.FunctionDef)],{'deepcopy':deepcopy,'traceback':traceback},'candidate_preservation_v1.py')
    c=orig('goalset_common_v4.py');ns={'legacy':legacy,'Counter':Counter,'deepcopy':deepcopy,'itertools':itertools,'ast':ast,'FAMILY':{'path':str(R/'origins/列図式規則.py')},'read_pin':lambda r:(R/'origins/列図式規則.py').read_bytes()}
    common=execute(constants(c,('FAMILY','LEGACY','legacy','_FIXED'))+[n for n in c.body if isinstance(n,ast.FunctionDef) and n.name not in ('read_pin','load_pure')],ns,'goalset_common_v4.py')
    ns['_FIXED']=ns['_bind_fixed']()
    g=orig('candidate_goalset_v2.py');candidate=execute([n for n in g.body if isinstance(n,ast.FunctionDef)],{'common':common,'legacy':legacy,'deepcopy':deepcopy},'candidate_goalset_v2.py')
    q=orig('candidate_query_v5.py');semantic=execute([n for n in q.body if isinstance(n,ast.FunctionDef) and n.name=='semantic_entry'],{'deepcopy':deepcopy,'traceback':traceback},'candidate_query_v5.py').semantic_entry
    return family,candidate,semantic,common

class Machine:
    """Explicit fixture only; no native learning claim. Exact objects retained."""
    def __init__(self,mode):
        self.mode=mode;self.owner=self;self.calls=[];self.bounds=[];self.memory={'経験':[],'照会':0,'学習判定':0}
    def allow_frame(self,n):self.bounds.append(n)
    def 照会する(self,external):
        b=external.対象系境界;facts=external.内容
        if b=='公開列図式:記号外形と展開役割':key='列展開役割';value='参照' if facts['記号は中空'] else '出力'
        elif b==preservation.作用境界:key='必要行動ID';value=1 if facts['解答作業']=='完成列提出' else 6
        elif b==preservation.目標境界:key='提出が受理された';value=facts['終端条件に応じた列が一致']
        else:
            keys={preservation.準備境界:preservation.準備結果,preservation.修復境界:preservation.修復結果,preservation.保存境界:preservation.保存結果}
            from goalset_common_rehost import 構成する
            c=構成する(preservation,{'_enumerate':fixed._enumerate})
            keys.update({c.PREP_BOUNDARY:c.PREP_RESULT,c.REPAIR_BOUNDARY:c.REPAIR_RESULT,c.PRESERVE_BOUNDARY:c.PRESERVE_RESULT})
            key=keys[b];value=next(iter(facts.values()));value=value if type(value)is bool else True
        content={'予測群':[{'結果経路':(key,),'予測値':value,'原理参照':'fixture-principle'}],'係争中原理群':[],'断定保留理由群':[]}
        state='出力'
        # Role/goal queries retain learned fixture values; variants exercise all candidate gates.
        if b not in (preservation.目標境界,'公開列図式:記号外形と展開役割'):
            if self.mode=='hold':state='断定保留'
            if self.mode=='conflict':content['予測群'].append({'結果経路':(key,),'予測値':not value if type(value)is bool else 7,'経験参照':'fixture-conflict'})
            if self.mode=='disputed':content['係争中原理群']=['fixture-dispute']
            if self.mode=='unsupported':content['予測群'][0].pop('原理参照')
            if self.mode=='wrongtype':content['予測群'][0]['予測値']=True if key=='必要行動ID' else 1
            if self.mode=='negative' and type(value)is bool:content['予測群'][0]['予測値']=False
        if self.mode=='role_hold' and b=='公開列図式:記号外形と展開役割':state='断定保留'
        reply=Reply(state,content,{'fixture':True,'ordinal':len(self.calls)})
        self.calls.append((external,reply));self.memory['照会']+=1;self.memory['学習判定']+=1
        return reply
    def ask(self,b,f):
        r=self.照会する(External(deepcopy(f),b))
        return {'状態':r.状態,'内容':r.内容,'追跡情報':r.追跡情報,'実照会保存参照':{'fixture_ordinal':len(self.calls)-1}}

def frame(kind,selected=False):
    f=[[0]*64 for _ in range(64)]
    for x,c in ((3,2),(10,3)):
        for dy in range(6):
            for dx in range(6):
                if dy in (0,5) or dx in (0,5):f[2+dy][x+dx]=c
    def token(x,y,c):
        for dy in range(4):
            for dx in range(4):f[y+dy][x+dx]=c
    def box(y,c,root):
        for x in range(5,21):f[y][x]=c
        for yy in range(y,y+10):f[yy][5]=f[yy][20]=c
        if root:
            for yy in (y-1,y+10):
                for xx in (4,21):f[yy][xx]=9
    box(15,8,True);token(8,18,2)
    if kind in ('complete','multiple'):token(14,18,3)
    if kind=='multiple':box(30,7,False);tokens=[(10,50,4),(25,50,5)]
    elif kind=='complete':tokens=[]
    else:tokens=[(10,35,3 if kind=='unique' else 4)]
    for x,y,c in tokens:token(x,y,c)
    if selected and tokens:
        x,y,c=tokens[0]
        for dy in range(6):
            for dx in range(6):
                if dy in (0,5) or dx in (0,5):f[y-1+dy][x-1+dx]=9
    return f

def normalized(v):
    # Preserve exact raw traceback separately; origin/line differences are expected relocation metadata.
    if isinstance(v,dict):return {k:('<relocated traceback>' if k in ('traceback','全文') else normalized(x)) for k,x in v.items()}
    if isinstance(v,(list,tuple)):return type(v)(normalized(x) for x in v)
    return v

def main():
    out=R/'reports'/sys.argv[1];out.mkdir(exist_ok=False)
    ref=reference();new=route.構成する(External);records=[];errors=[]
    def check(label,condition):
        if not condition:errors.append(label)
    # Every selected original function/class body has exact AST equality in derivative.
    mappings={'列図式規則.py':'family_rehost.py','candidate_goalset_v2.py':'goalset_candidate_rehost.py','candidate_query_v5.py':'semantic_entry_rehost.py','goalset_common_v4.py':'goalset_common_rehost.py'}
    for origin,derived in mappings.items():
        old={n.name:n for n in orig(origin).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
        tree=ast.parse((R/'source'/derived).read_bytes())
        selected=[n for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in old]
        for n in selected:check('AST:'+origin+':'+n.name,ast.dump(n,include_attributes=False)==ast.dump(old[n.name],include_attributes=False))
    check('preservation bytes',(R/'source/preservation_rehost.py').read_bytes()==(R/'origins/candidate_preservation_v1.py').read_bytes())
    for kind,selected,mode,available in itertools.product(('unique','empty','complete','multiple'),(False,True),('normal','hold','conflict','disputed','unsupported','wrongtype','negative','role_hold'),([1,6],[1],[])):
        label=f'{kind}/{selected}/{mode}/{available}';f=frame(kind,selected);before=deepcopy(f);pair=[]
        for family,candidate,semantic in (ref[:3],new):
            m=Machine(mode);result=semantic(family,candidate,f,available,m,m.ask,'NOT_FINISHED')
            pair.append({'result':result,'calls':m.calls,'bounds':m.bounds,'memory':m.memory})
            check(label+':memory',m.memory['経験']==[] and m.memory['照会']==m.memory['学習判定']==len(m.calls))
            check(label+':no action',result['実行許可'] is False)
            cs=result.get('全作用候補')
            if cs:
                check(label+':all candidates',cs['助言順序']==list(range(len(cs['全候補']))) and all(c['実行許可'] is False for c in cs['全候補']))
            check(label+':frame unchanged',f==before)
        check(label+':exact full output/trace/memory',pack(pair[0])==pack(pair[1]))
        records.append({'case':label,'original':pack(pair[0]),'derivative':pack(pair[1])})
    for label,f,state in [('terminal',frame('unique'),'WIN'),('unsupported',[[0]*64 for _ in range(64)],'NOT_FINISHED'),('malformed',[],'NOT_FINISHED')]:
        pair=[]
        for family,candidate,semantic in (ref[:3],new):
            m=Machine('normal');pair.append({'result':semantic(family,candidate,f,[1,6],m,m.ask,state),'calls':m.calls})
        check(label+':normalized result',pack(normalized(pair[0]))==pack(normalized(pair[1])))
        check(label+':no queries',all(not x['calls'] for x in pair));records.append({'case':label,'original':pack(pair[0]),'derivative':pack(pair[1]),'traceback_difference':'relocated filename and line only; raw preserved'})
    with (out/'all_output_traces.json').open('x') as f:json.dump(records,f,ensure_ascii=False,separators=(',',':'))
    report={'status':'PASS' if not errors else 'FAIL','cases':len(records),'errors':errors,'exact_cases':len(records)-3,'exception_and_terminal_cases':3,'peak_RSS_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'AS':resource.getrlimit(resource.RLIMIT_AS),'native_Query':0,'Teach':0,'Action':0,'adopted':False}
    report['directory_bytes']=sum(p.stat().st_size for p in R.rglob('*') if p.is_file());check('96MiB disk',report['directory_bytes']<96*1048576)
    (out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False));return bool(errors)
if __name__=='__main__':sys.exit(main())
