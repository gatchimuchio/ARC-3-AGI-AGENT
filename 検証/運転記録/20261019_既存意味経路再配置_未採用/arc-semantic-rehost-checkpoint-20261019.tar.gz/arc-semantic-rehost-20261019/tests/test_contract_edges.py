"""Targeted preserved rejection, trace completeness and provenance-boundary checks."""
import inspect, json, resource, sys, ast
from copy import deepcopy
from pathlib import Path
from test_equivalence import R, reference, route, External, Machine, frame, pack, normalized, preservation

def run():
    out=R/'reports'/sys.argv[1];out.mkdir(exist_ok=False);records=[];errors=[]
    ref=reference();new=route.構成する(External)
    for label in ('duplicate_slot','role_integer','bad_available','bad_pool_count','bad_pool_assignment','input_callback_mutation','callback_value_error','callback_memory_error'):
        pair=[]
        for f,c,s in (ref[:3],new):
            scene=f.図式を観測する(frame('unique',True));m=Machine('normal');goal=f.内容候補を構成する(m,scene);roles={False:'出力',True:'参照'};selection={'selection':f.選択を読む(frame('unique',True),scene)};available=[1,6]
            if label=='duplicate_slot':scene['容器群'][0]['枠群'].append(deepcopy(scene['容器群'][0]['枠群'][0]))
            if label=='role_integer':roles={0:'出力',1:'参照'}
            if label=='bad_available':available=[True,6]
            if label=='bad_pool_count':goal['候補数']=99
            if label=='bad_pool_assignment':goal['候補'][0]['割当'][0]['位置']=[63,63]
            before=deepcopy((scene,goal,roles,selection,available));callbacks=[]
            def ask(b,facts):
                callbacks.append((b,deepcopy(facts)))
                if label=='input_callback_mutation':facts['mutation']=True
                if label=='callback_value_error':raise ValueError('fixture failure')
                if label=='callback_memory_error':raise MemoryError('fixture resource failure')
                return m.ask(b,facts)
            result=None;exception=None
            try:result=c.全作用候補を構成する(scene,goal,roles,selection,available,ask,f.一致する,保存照会=ask)
            except Exception as e:exception={'type':type(e).__name__,'args':e.args}
            after=(scene,goal,roles,selection,available)
            pair.append({'result':result,'exception':exception,'callbacks':callbacks,'before':before,'after':after})
            if pack(before)!=pack(after):errors.append(label+':input mutation')
        if pack(normalized(pair[0]))!=pack(normalized(pair[1])):errors.append(label+':equivalence')
        records.append({'case':label,'original':pack(pair[0]),'derivative':pack(pair[1])})
    # Confirm multi-goal fixture really reaches every mapping/effect/preservation family.
    coverage={};counts={}
    for kind,selected in [('unique',False),('unique',True),('multiple',False),('multiple',True),('empty',False),('complete',False)]:
        family,candidate,semantic=new;m=Machine('normal');r=semantic(family,candidate,frame(kind,selected),[1,6],m,m.ask,'NOT_FINISHED')
        key=f'{kind}/{selected}';coverage[key]=[x.対象系境界 for x,y in m.calls];counts[key]={'pool':r['全目標pool'].get('候補数'),'candidates':len(r['全作用候補']['全候補']),'calls':len(m.calls),'budget':m.bounds}
        if len(m.calls)>m.bounds[0]:errors.append(key+':budget')
    if counts['multiple/False']['pool']!=2:errors.append('multiple fixture not two goals')
    expected={ref[3].PREP_BOUNDARY,ref[3].REPAIR_BOUNDARY,ref[3].PRESERVE_BOUNDARY,preservation.準備境界,preservation.修復境界,preservation.保存境界,preservation.作用境界,preservation.目標境界}
    seen=set(x for values in coverage.values() for x in values)
    if not expected<=seen:errors.append('missing boundaries:'+str(expected-seen))
    # API structurally excludes provenance identity. Owner/evidence callback metadata stays out of facts.
    params=list(inspect.signature(new[2]).parameters)
    if params!=['family','candidate','frame','available','view','ask','public_state']:errors.append('semantic signature')
    identity_runs=[]
    for provenance in ({'game':'game-A','level':1,'file':'A','hash':'000'},{'game':'game-Z','level':99,'file':'Z','hash':'fff'}):
        m=Machine('normal');r=new[2](new[0],new[1],frame('unique'),[1,6],m,m.ask,'NOT_FINISHED');identity_runs.append({'provenance':provenance,'semantic':pack(r),'trace':pack(m.calls)})
    if identity_runs[0]['semantic']!=identity_runs[1]['semantic'] or identity_runs[0]['trace']!=identity_runs[1]['trace']:errors.append('identity separation')
    (out/'edge_traces.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
    (out/'coverage.json').write_text(json.dumps({'counts':counts,'boundaries':coverage,'identity_separation':identity_runs},ensure_ascii=False,indent=2))
    report={'status':'PASS' if not errors else 'FAIL','edge_cases':len(records),'errors':errors,'peak_RSS_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'AS':resource.getrlimit(resource.RLIMIT_AS),'native':False}
    (out/'report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report));return bool(errors)
if __name__=='__main__':sys.exit(run())
