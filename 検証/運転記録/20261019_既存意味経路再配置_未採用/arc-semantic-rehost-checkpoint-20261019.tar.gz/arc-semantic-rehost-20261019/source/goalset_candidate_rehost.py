"""未採用・明示依存注入派生。原文の選択関数本体は不変。"""
from copy import deepcopy
from types import SimpleNamespace

def 構成する(common):
    legacy=common.legacy
    作用境界=legacy.作用境界
    目標境界=legacy.目標境界
    def 全作用候補を構成する(図式,全目標pool,学習役割,選択観測,利用可能作用,照会,列一致,保存照会=None):
        pool=全目標pool.get('候補',[])
        # Exact old implementation for unique, empty, unresolved and malformed old schema.
        if type(pool)is not list or len(pool)<=1:
            return legacy.全作用候補を構成する(図式,全目標pool,学習役割,選択観測,利用可能作用,照会,列一致,保存照会)
        original=deepcopy((図式,全目標pool,学習役割,選択観測,利用可能作用))
        common.require(全目標pool.get('状態')=='複数解答候補' and type(全目標pool.get('候補数'))is int and 全目標pool['候補数']==len(pool),'複数全pool状態/件数')
        recomputed=common.goalset_pool(図式,学習役割)
        for k in ('状態','候補数','全数確認した相異なる割当数','候補','不採用理由集計','実行許可'):
            common.require(common.exact(全目標pool.get(k),recomputed[k]),'現在全列挙差:'+k)
        base=common.goalset_base(図式,pool)
        # The old path generates every original structural candidate and old action
        # mapping/submission query. It does not query unique-only effects for len>1.
        out=legacy.全作用候補を構成する(図式,全目標pool,学習役割,選択観測,利用可能作用,照会,列一致,保存照会)
        out['集合前提']=deepcopy(base)
        out['全体理由']=['非空複数目標集合の限定操作境界。全目標保持、一意経路の既充足とは別']
        for c in out['全候補']:
            action=c['作用'] or {'id':None,'data':{}}
            pre=common.goalset_preconditions(図式,選択観測,pool,action)
            c['集合候補前提']=deepcopy(pre)
            mapping=c['照会全件'][0]
            legal=(c['作用'] is not None and type(c['作用']['id'])is int and c['作用']['id']==6 and 6 in 利用可能作用
                   and mapping['状態']=='支持' and type(mapping['予測'])is int and mapping['予測']==6)
            def effect(boundary,key,value,result):
                c['前提'][key]=value
                q=legacy.効果を照会する(照会,boundary,{key:value},result,bool);c['照会全件'].append(q)
                c['効果状態']='効果支持' if q['状態']=='支持' and q['予測'] is True else '予測効果不成立' if q['状態']=='支持' and q['予測'] is False else q['状態']
                if c['効果状態']!='効果支持':c['理由'].append('集合境界の目的効果が未支持または負予測')
            if c['対象区分']=='在庫':
                c['理由']=[r for r in c['理由'] if not r.startswith('14準備境界外')]
                if legal and pre['準備適格']:
                    effect(common.PREP_BOUNDARY,common.PREP_INPUT,pre['準備入力'],common.PREP_RESULT)
                else:c['理由'].append('集合準備のbefore境界未成立')
            elif c['対象区分']=='枠':
                c['理由']=[r for r in c['理由'] if r!='一意目標境界未成立']
                if legal and pre['修復適格']:
                    effect(common.REPAIR_BOUNDARY,common.REPAIR_INPUT,pre['修復入力'],common.REPAIR_RESULT)
                else:c['理由'].append('集合修復のbefore境界外。実空欄のみ')
            record={'状態':'UNKNOWN','予測':None,'支持':[],'照会':None,'操作区分':pre['保存操作区分'],
                    '全充填枠':deepcopy(base['全充填枠']),'保存対象種別':'既充填'}
            c['保存条件']['全相保存予測']=record
            if c['対象区分']=='提出':
                record['理由']='複数目標境界の提出。終端免除を補わない';continue
            if not base['全充填枠']:
                record.update({'状態':'保存対象なし','理由':'既充填空集合。None、支持なし、照会なし'});continue
            if not legal or pre['保存操作区分'] is None:
                record['理由']='集合保存の二操作区分境界外';continue
            if 保存照会 is None:
                record['理由']='保存照会callback未提供';continue
            q=legacy.効果を照会する(保存照会,common.PRESERVE_BOUNDARY,{common.PRESERVE_INPUT:pre['保存操作区分']},common.PRESERVE_RESULT,bool)
            c['照会全件'].append(q)
            record.update({'状態':q['状態'],'予測':q['予測'],'支持':deepcopy(q['支持']),'照会':q,
                           '限界':'全充填保持の限定学習予測。目標可解性/hidden/普遍安全は別'})
        out['学習効果支持候補']=[c['候補番号'] for c in out['全候補'] if c['効果状態']=='効果支持']
        out['規則不確実性']=[]
        for c in out['全候補']:
            for q in c['照会全件']:
                if q['返却'] is not None:
                    content=legacy.値(q['返却'],'内容')
                    if content.get('係争中原理群'):out['規則不確実性'].append({'候補番号':c['候補番号'],'係争中原理群':deepcopy(content['係争中原理群'])})
        out['全体採否']='HOLD' if out['規則不確実性'] else '実行採否未実施'
        common.require(common.exact(original,(図式,全目標pool,学習役割,選択観測,利用可能作用)),'候補入力変更')
        return out
    return SimpleNamespace(全作用候補を構成する=全作用候補を構成する, 作用境界=作用境界, 目標境界=目標境界)
