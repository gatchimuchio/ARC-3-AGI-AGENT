"""既存_bind_fixedの同一AST変換。全列挙、不採用も保持。"""
from collections import Counter
import itertools
def 列を生成する(scene, 役割, 長さ):
    boxes = {b['色']: b for b in scene['容器群']}
    root = next((b for b in scene['容器群'] if b['起点']))
    out = []
    active = set()
    repeated = False
    ancestors = []
    for b in scene['容器群']:
        for s in b['枠群']:
            if s['記号'] is None:
                raise ValueError('未記入スロット')
            if 役割[s['記号']['中空']] == '参照' and s['記号']['色'] not in boxes:
                raise ValueError('参照先なし')

    def cycle(b, stack):
        if b['色'] in stack:
            return True
        return any((cycle(boxes[s['記号']['色']], stack + (b['色'],)) for s in b['枠群'] if 役割[s['記号']['中空']] == '参照'))
    cyclic = cycle(root, ())

    def finite(b):
        result = []
        for s in b['枠群']:
            t = s['記号']
            result.extend([t['色']] if 役割[t['中空']] == '出力' else finite(boxes[t['色']]))
        return result
    if not cyclic:
        full = finite(root)
        return {'出力列': full, '目標長到達': len(full) == 長さ, '生産的再入観測': False, '展開構造': '有限終端', '比較範囲': '全出力列', '過剰出力数': max(0, len(full) - 長さ)}

    def visit(b):
        nonlocal repeated
        key = (b['色'], len(out))
        if key in active:
            raise ValueError('非生産的循環:同じ参照先へ出力増加なしで再入')
        if b['色'] in ancestors:
            repeated = True
        active.add(key)
        ancestors.append(b['色'])
        for s in b['枠群']:
            if len(out) >= 長さ:
                break
            t = s['記号']
            op = 役割[t['中空']]
            if op == '出力':
                out.append(t['色'])
            elif op == '参照':
                visit(boxes[t['色']])
            else:
                raise ValueError('未知の役割')
        ancestors.pop()
        active.remove(key)
    visit(root)
    if not repeated:
        raise ValueError('循環候補だが目標長までに生産的再入未確認:判定範囲外')
    return {'出力列': out, '目標長到達': len(out) == 長さ, '生産的再入観測': repeated, '展開構造': '生産的反復', '比較範囲': '目標長前置列'}

def 一致する(scene, roles):
    try:
        r = 列を生成する(scene, roles, len(scene['目標列']))
        return (r['出力列'] == scene['目標列'], r)
    except ValueError as e:
        return (False, {'構造状態': 'HOLD', '理由': str(e)})

def _enumerate(scene, roles):
    slots = [s for b in scene['容器群'] for s in b['枠群'] if s['記号'] is None]
    tokens = [s['記号'] for s in scene['在庫群']]
    if len(slots) != len(tokens):
        raise ValueError('在庫と空欄の全単射文法が未成立')
    seen = set()
    solutions = []
    failures = Counter()
    tested = 0
    for perm in itertools.permutations(tokens):
        k = tuple(((t['色'], t['中空']) for t in perm))
        if k in seen:
            continue
        seen.add(k)
        tested += 1
        for s, t in zip(slots, perm):
            s['記号'] = t
        match, detail = 一致する(scene, roles)
        if match:
            solutions.append({'割当': [{'位置': s['位置'], '色': t['色'], '中空': t['中空']} for s, t in zip(slots, perm)], '列生成': detail})
        else:
            failures[detail.get('理由', '目標列不一致')] += 1
    for s in slots:
        s['記号'] = None
    return {'状態': '唯一解答候補' if len(solutions) == 1 else '複数解答候補' if solutions else 'HOLD', '候補数': len(solutions), '全数確認した相異なる割当数': tested, '候補': solutions, '不採用理由集計': dict(failures), '実行許可': False}
