"""原semantic_entry本体不変。実行/状態復元/旧loaderなし。"""
from copy import deepcopy
import traceback

def semantic_entry(family,candidate,frame,available,view,ask,public_state):
 """Reusable actual observation entry; evidence IDs are outside this function."""
 out={'適用性':'未確認','場面':None,'全目標pool':None,'学習役割':None,'選択観測':None,'全作用候補':None,'例外':[], '実行許可':False}
 if public_state!='NOT_FINISHED':
  out['保留理由']='現在の公開状態は進行中でない';return out
 try:scene=family.図式を観測する(frame)
 except family.知覚不適用 as e:
  out['適用性']='構造上不適用';out['例外'].append({'type':type(e).__name__,'args':e.args,'traceback':traceback.format_exc()});return out
 except (ValueError,KeyError,TypeError) as e:
  out['例外'].append({'type':type(e).__name__,'args':e.args,'traceback':traceback.format_exc()});return out
 out['場面']=deepcopy(scene);out['適用性']='固定知覚適合'
 n=len(scene['在庫群']);slots=sum(len(b['枠群']) for b in scene['容器群'])
 # Complete enumeration bound: pool <=4; candidate mapping+effect+optional preservation <=3*(N+S+1).
 out['全構造候補数上界']=n+slots+1;out['API数上界']=4+3*(n+slots+1)
 view.owner.allow_frame(out['API数上界'])
 roles={};role_records=[]
 class RolesView:
  def 照会する(self,external):
   result=view.照会する(external)
   if external.対象系境界==family.役割境界:
    role_records.append({'input':external,'reply':result})
    values=[p['予測値'] for p in result.内容.get('予測群',[]) if tuple(p['結果経路'])==('列展開役割',)]
    if result.状態=='出力' and values and all(v==values[0] for v in values) and not result.内容.get('係争中原理群') and not result.内容.get('断定保留理由群'):
     roles[external.内容['記号は中空']]=values[0]
   return result
 goal=family.内容候補を構成する(RolesView(),scene);out['全目標pool']=goal;out['役割全照会']=role_records;out['学習役割']=roles
 try:selection={'selection':family.選択を読む(frame,scene)}
 except (ValueError,KeyError,TypeError) as e:selection={'selection':None,'selection_unknown':{'type':type(e).__name__,'args':e.args,'traceback':traceback.format_exc()}}
 out['選択観測']=selection
 if len(roles)!=2:out['保留理由']='両学習役割未確定。全pool/全照会保持';return out
 out['全作用候補']=candidate.全作用候補を構成する(scene,goal,roles,selection,available,ask,family.一致する,保存照会=ask)
 return out
