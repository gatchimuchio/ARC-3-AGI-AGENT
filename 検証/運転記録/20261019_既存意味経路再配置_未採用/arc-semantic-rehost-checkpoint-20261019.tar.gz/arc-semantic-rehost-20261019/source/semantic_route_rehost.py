"""未採用・純粋照会用の既存意味経路の結線。native/作用口は存在しない。"""
import family_rehost
import preservation_rehost
import goalset_common_rehost
import goalset_candidate_rehost
import fixed_enumeration_rehost
from semantic_entry_rehost import semantic_entry

def 構成する(外部入力):
    family=family_rehost.構成する(外部入力)
    common=goalset_common_rehost.構成する(preservation_rehost, {'_enumerate':fixed_enumeration_rehost._enumerate})
    candidate=goalset_candidate_rehost.構成する(common)
    return family, candidate, semantic_entry
