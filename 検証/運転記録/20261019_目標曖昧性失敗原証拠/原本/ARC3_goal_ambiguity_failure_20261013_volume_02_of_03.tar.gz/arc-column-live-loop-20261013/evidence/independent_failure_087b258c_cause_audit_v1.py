import resource
resource.setrlimit(resource.RLIMIT_AS,(512<<20,512<<20))
import sys,ast,dataclasses,copy,hashlib,importlib.util,json,lzma,signal,time,traceback
from pathlib import Path
B=Path('/workspace/scratch/a94ff513b3af');L=B/'arc-column-live-loop-20261013';N='087b258ca57e41ff82229797bd8035b4';D=L/'evidence'/N;F=L/'failure'/N
CORE=B/'arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2';FAMILY=B/'arc-current-family-source-20261013'
sys.dont_write_bytecode=True
sys.path[:0]=[str(L/'source'),str(CORE),str(FAMILY),str(B/'arc-live-step-adapter-20261013')]
import loop_guard_v3 as g
from hds学習系統.永続化 import _符号化 as enc,_復号 as dec
from hds学習系統.型 import 外部出力,実行結果,学習成立状態
def sha(b):return hashlib.sha256(b).hexdigest()
def same(a,b):
 if type(a)is not type(b):return False
 if type(a)is dict:return list(a)==list(b) and all(same(a[k],b[k]) for k in a)
 if type(a)in(list,tuple):return len(a)==len(b) and all(same(x,y) for x,y in zip(a,b))
 return a==b
refs={}
def read(p):
 p=Path(p);st=p.stat();b=p.read_bytes();st2=p.stat()
 assert (st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns)==(st2.st_dev,st2.st_ino,st2.st_size,st2.st_mtime_ns,st2.st_ctime_ns)
 refs[str(p)]={'path':str(p),'bytes':len(b),'sha256':sha(b)};return b
def exact(r):
 b=read(r['path']);assert refs[r['path']]==r;return b
def packet(r):
 b=exact(r['file']);z=lzma.LZMADecompressor(memlimit=128<<20);raw=z.decompress(b,max_length=(16<<20)+1)
 assert z.eof and not z.unused_data and z.check==lzma.CHECK_CRC64 and len(raw)==r['rawbytes'] and sha(raw)==r['rawsha256']
 tag=json.loads(raw);v=dec(tag);assert same(enc(v),tag);return v
def load(name,p):
 sp=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
def main():
 signal.signal(signal.SIGALRM,lambda *a:(_ for _ in ()).throw(TimeoutError('independent cause600')));signal.alarm(600)
 g.guard('evidence',2<<20)
 gate=json.loads(read(L/'source'/('root_loop_release_'+N+'.json')));contract=json.loads(exact(gate['contract']))
 for r in contract['source_pins']+contract['core_and_family_pins']:exact(r)
 tool=json.loads(read(L/'evidence/actual_live_loop_tools_087b258c_v1.json'));notify=json.loads(tool['polls'][-1]['output'].splitlines()[0])
 manifest=packet(notify['failure_manifest']);assert manifest['complete_recovery'] is True
 initial=dec(json.loads(exact(gate['closed_baseline']['state'])))
 histories={p.原理識別子:p for h in initial['原理履歴'].values() for p in h}
 observations={e.経験識別子:e for e in initial['台帳']['観測台帳']}
 ex=CORE/'hds学習系統/排気系.py';fn=next(x for x in ast.walk(ast.parse(read(ex))) if isinstance(x,ast.FunctionDef) and x.name=='排出する')
 ns={'asdict':dataclasses.asdict,'Any':object,'外部出力':外部出力,'実行結果':実行結果,'学習成立状態':学習成立状態}
 exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])),str(ex),'exec'),ns)
 replay=[];raw_count=0;prediction_count=0;rule_support_count=0
 for link in manifest['calls']:
  reply=packet(link['reply']);cap=reply['capture']
  assert cap['profile_restored'] is True and len(cap['raw'])==len(cap['events'])==1 and cap['events'][0]['exact_code_self'] is True
  raw=cap['raw'][0];ret=cap['return'];assert same(enc(ns['排出する'](None,raw)),enc(ret));raw_count+=1
  for p in raw.有効原理群:
   assert same(enc(p),enc(histories[p.原理識別子])) and all(e in observations for e in p.根拠参照群+p.反証参照群);rule_support_count+=1
  for pred in raw.予測群:
   p=histories[pred.原理参照];assert p.対象系境界==reply['input'].対象系境界 and p.結果経路==pred.結果経路;prediction_count+=1
  if link['frame']==90:
   reply['input']=dataclasses.asdict(reply['input']);reply['capture']['return']=dataclasses.asdict(ret);reply['reference']=link;replay.append(reply)
 semref=manifest['components']['semantic'];sb=exact(semref)
 z=lzma.LZMADecompressor();sr=z.decompress(sb,max_length=(16<<20)+1);assert z.eof and not z.unused_data and z.check==lzma.CHECK_CRC64
 tag=json.loads(sr);saved=dec(tag);assert same(enc(saved),tag)
 pubref=manifest['components']['public'];public=json.loads(exact(pubref))
 from 接続 import 列図式規則 as family
 import adapter
 sem=load('audit087sem',B/'arc-column-live-pilot-20261013/source/pilot_semantics_v3.py')
 query=load('audit087query',Path(contract['query_entry']['path']))
 candidate=load('audit087candidate',Path(contract['candidate']['path']))
 work=load('audit087work',Path(contract['goal_work']['path']))
 boundary=adapter.load_boundary();cur=query.canonical_observation(boundary,public,90)
 assert all(q['origin']['観測指紋']==cur.指紋 and q['origin']['観測通番']==90 for q in replay)
 scene=family.図式を観測する(cur.最新盤面);assert same(enc(scene),enc(saved['場面']))
 result=sem.replay_current(cur,family,candidate,query.semantic_entry,replay,dataclasses.asdict,外部出力,saved)
 assert same(enc(result),enc(saved))
 observed_error=None
 try:sem.project_current(cur,result,work)
 except ValueError as e:observed_error={'type':type(e).__name__,'args':e.args}
 assert observed_error=={'type':'ValueError','args':('unique complete goal required',)}
 pool=result['全目標pool'];full=result['全作用候補']
 assert pool['候補数']==len(pool['候補'])==5 and pool['全数確認した相異なる割当数']==5040
 assert result['適用性']=='固定知覚適合' and result['例外']==[] and full['既充足走査完了'] is False
 assert full['既充足枠全件'] is None and full['全要求枠'] is None
 assert not (D/'transport'/'b42ced76cc934a38ab348f28c6fe6fa8.intent.json').exists()
 assert len(replay)==13 and len(manifest['calls'])==2234
 diag=packet(manifest['components']['diagnostics'])
 assert diag['ordinary_Action_attempted']==diag['ordinary_Action_returned']==90 and diag['make_attempted']==diag['make_returned']==1
 report={'schema':'column-loop-current-goal-ambiguity-independent-v1','status':'CAUSE_REPRODUCED_RUN_FAILED','nonce':N,
 'verified':{'all2234_raw_to_external_and_rule_support':True,'current_public_latest_frame_perception_exact':True,'all_current13_replies_pure_replay_full_type_order':True,'all5040_assignments_recomputed_full5_pool':True,'same_projection_ValueError_reproduced':True,'no_Action91_transport':True},
 'counts':{'queries':raw_count,'predictions_checked':prediction_count,'rule_support_checks':rule_support_count,'current_queries':len(replay),'all_assignments':5040,'goal_candidates':5,'Actions':90,'public_levels':public['model_json']['levels_completed'],'response_phases':public['frame_count']},
 'public':pubref,'semantic':semref,'scene':enc(scene),'goal_pool':enc(pool),'current_candidates_summary':[{'id':c['候補番号'],'operation':c['作業'],'effect':c['効果状態'],'reasons':c['理由']} for c in full['全候補']],
 'current_scan':{'complete':full['既充足走査完了'],'correct_slots':full['既充足枠全件'],'all_required_slots':full['全要求枠'],'column_match':enc(full['列判定']),'reasons':full['全体理由']},
 'error':observed_error,'cause':{'observation':'New public state has five exact output-equivalent assignments under unchanged learned roles; perception agrees and no parser exception.',
 'boundary':'Preparation/repair/preservation features require one fixed complete goal; multiple candidates deliberately produce UNKNOWN and no full-goal binding.',
 'integration':'loop_live_v11 step_cycle checks structural applicability only, then project_current requires unique complete goal. The supported ambiguity boundary becomes ValueError/failed_closed rather than a normal HOLD.',
 'not_proven':'Hidden environment acceptance of any unexecuted assignment; no game implementation examined.',
 'minimum_handling':'Preserve all five goals and unknowns and stop with explicit ambiguous-goal HOLD. Goal selection/consensus or multiple-goal teaching needs separately reviewed semantics; do not take first candidate automatically.'},
 'unfinished_suffix':manifest['unprocessed'],'suffix_interpretation':'All thirteen step90 semantic queries and after-query standard completed; final adoption/dossier/Action91 not reached. Generic remaining_candidate_queries text is conservative and not evidence of missing query replies.',
 'limitations':['Operational native run remains failed; observed level increments are not added as successful run capability.','Pure saved-reply replay and public perception only; no native HDS/SDK/Action.','No arbitrary live heap or unfinished local recovery claim.'],
 'refs':list(refs.values())}
 signal.alarm(0);b=(json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode();assert len(b)<2<<20
 r=g.save('evidence','independent_failure_087b258c_cause_v1.json',b);print(json.dumps({'status':report['status'],'report':r,'counts':report['counts']},ensure_ascii=False),flush=True)
if __name__=='__main__':
 try:main()
 except BaseException:
  signal.alarm(0);raw=traceback.format_exc().encode();print(raw.decode(),flush=True);g.save('failure','independent_failure_087b258c_cause_error_v1.txt',raw);raise
