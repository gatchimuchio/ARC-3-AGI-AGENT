"""Pure current-column dossier and measured-effect bridge.
No SDK/HDS imports or Action call. The runtime binds reviewed current-frame
replay, native journal readback and the existing final verifier separately.
"""
from copy import deepcopy
import json
from types import SimpleNamespace

PRESERVE_BOUNDARY='公開列図式・一意目標候補・既充足枠非空・可視対象操作の全相保存'
PRESERVE_INPUT='可視対象に対する操作区分'
PRESERVE_RESULT='応答全相で既充足枠が保持された'
CLASSES=('在庫選択表示なしのクリック','在庫選択済みの実枠クリック')
TERMINAL='受理による旧問題終端のため対象外'
ACTION_BOUNDARY='公開列図式:観測された解答作業と行動ID'
UNCERTAIN=('競合群','断定保留理由群','係争中原理群','追加観測要求群','識別不能群')

def exact(a,b):
    if type(a) is not type(b):return False
    if isinstance(a,dict):return len(a)==len(b) and all(exact(k,l) and exact(a[k],b[l]) for k,l in zip(a,b))
    if isinstance(a,(list,tuple)):return len(a)==len(b) and all(exact(x,y) for x,y in zip(a,b))
    return a==b

def require(value,reason):
    if not value:raise ValueError(reason)

def native_part(reply):
    require(type(reply)is dict and set(reply)=={'状態','内容','追跡情報','実照会保存参照'},'full native reply plus evidence reference required')
    return {k:deepcopy(reply[k]) for k in ('状態','内容','追跡情報')}

def reply_file(q):
    ref=q['返却']['実照会保存参照']
    require(ref['method']=='照会する','query reference method')
    return deepcopy(ref['reply']['file'])

class Replay:
    """Read-only ordered replay of ACTUAL durable query replies, never predictions.
    This object cannot call HDS. The immutable query list must come from the
    current live owner, with raw captures independently verified before dispatch.
    """
    def __init__(self,queries,external_projection,reply_type):
        self.queries=queries;self.project=external_projection;self.reply_type=reply_type;self.index=0
        self.owner=self;self.bound=None
    def allow_frame(self,n):self.bound=n
    def 照会する(self,external):
        require(self.index<len(self.queries),'reprojection requested an unsaved query')
        q=self.queries[self.index];self.index+=1
        require(q['method']=='照会する' and exact(self.project(external),q['input']),'reprojection whole input/type/order mismatch')
        ret=q['capture']['return']
        require(set(ret)=={'状態','内容','追跡情報'},'native external return schema')
        value=self.reply_type(**deepcopy(ret))
        require(exact(self.project(value),ret),'reply reconstruction type/value mismatch')
        return value
    def ask(self,boundary,facts):
        require(self.index<len(self.queries),'missing saved candidate query')
        q=self.queries[self.index]
        require(q['input']['対象系境界']==boundary and exact(q['input']['内容'],facts),'before-only candidate replay mismatch')
        self.index+=1
        ret=deepcopy(q['capture']['return'])
        ret['実照会保存参照']=deepcopy(q['reference'])
        return ret
    def finish(self):
        require(self.index==len(self.queries),'unconsumed original queries')
        require(type(self.bound)is int and self.index<=self.bound,'complete structural query budget')

def replay_current(current,family,candidate,entry,queries,external_projection,reply_type,original):
    replay=Replay(queries,external_projection,reply_type)
    result=entry(family,candidate,current.最新盤面,list(current.作用可能番号),replay,replay.ask,current.状態)
    replay.finish()
    require(exact(result,original),'current-frame replay differs from saved complete semantic result')
    return result

def project_current(current,result,work):
    require(result['適用性']=='固定知覚適合' and not result['例外'],'current structural applicability')
    full=result['全作用候補']
    require(full is not None and full['実行許可'] is False and full['自動選択'] is None,'candidate output incomplete')
    require(full['既充足走査完了'] is True,'unique complete goal required')
    scene=result['場面'];selection=result['選択観測']
    require('selection' in selection and 'selection_unknown' not in selection,'visible inventory selection unknown')
    pool=result['全目標pool']['候補']
    require(len(pool)==1,'unique goal boundary')
    pre=work.候補前提(scene,selection['selection'],pool,{'id':None,'data':{}})[0]
    current_slots=work.枠(scene);desired=dict(pre['要求枠'])
    correct=[{'位置':list(k),'現在記号':deepcopy(current_slots[k]),'要求記号':deepcopy(desired[k])} for k in pre['既充足枠']]
    require(exact(correct,full['既充足枠全件']),'all existing-correct slots changed')
    p={'利用可能作用':list(current.作用可能番号),'候補前提':{},'候補作用':{},'候補対象':{},
       '候補適用境界':{},'照会入力':{},'保存適用署名':{},'保存学習適用条件':{},
       '既充足走査完了':True,'既充足枠全件':correct,'現在列の目標一致':full['列判定']['一致']}
    ids=[]
    for c in full['全候補']:
        cid=str(c['候補番号']);require(cid not in ids,'duplicate candidate');ids.append(cid)
        require(c['実行許可'] is False,'candidate permission changed')
        p['候補前提'][cid]=deepcopy(c['前提'])
        p['候補作用'][cid]=None if c['作用'] is None else {'number':c['作用']['id'],'arguments':deepcopy(c['作用']['data'])}
        p['候補対象'][cid]=deepcopy(c['対象'])
        p['候補適用境界'][cid]=[q['境界'] for q in c['照会全件']]
        require(len(p['候補適用境界'][cid])==len(set(p['候補適用境界'][cid])),'duplicate query boundary in candidate')
        p['照会入力'][cid]={q['境界']:deepcopy(q['入力']) for q in c['照会全件']}
        preservation=c['保存条件']['全相保存予測']
        klass=preservation['操作区分']
        legal=klass in CLASSES and c['作用'] is not None and type(c['作用']['id'])is int and c['作用']['id']==6 and 6 in p['利用可能作用']
        p['保存学習適用条件'][cid]={'唯一目標候補':True,'操作境界成立':legal,'操作区分':klass}
        p['保存適用署名'][cid]={'目標要求全件':deepcopy(pre['要求枠']),'既充足枠':deepcopy(correct),
          '可視選択':deepcopy(selection),'操作区分':klass,'対象':deepcopy(c['対象']),
          '意味範囲':'現在の可視列図式のみ。hiddenと報酬は未観測'}
    require(ids==[str(i) for i in full['助言順序']],'candidate order mismatch')
    return p

def preservation_item(c,cid,p):
    prediction=c['保存条件']['全相保存予測']
    item={'由来':'未確認','保存値':None,'既充足枠':deepcopy(p['既充足枠全件']),
      '限界':['2観測操作区分の限定学習。反例未観測、普遍安全ではない'],
      '隠れ状態':'未観測','報酬':'未観測','適用署名':deepcopy(p['保存適用署名'][cid]),
      '測定参照群':[],'照会参照':None}
    if c['作業']=='完成列提出' and prediction['状態']=='旧scope終了予測のため保存対象外':
        item['由来']=TERMINAL
    elif not p['既充足枠全件']:
        require(prediction['予測'] is None and prediction['照会'] is None,'empty set must not borrow a preservation prediction')
        item['由来']='保存対象なし'
    elif prediction['状態']=='支持' and prediction['予測'] is True:
        q=prediction['照会']
        require(q['境界']==PRESERVE_BOUNDARY and q['結果葉']==PRESERVE_RESULT,'preservation query schema')
        require(exact(q['入力'],{PRESERVE_INPUT:prediction['操作区分']}),'preservation operation scope')
        item.update(由来='HDS実学習',保存値=True,照会参照=reply_file(q),境界=PRESERVE_BOUNDARY,
                    結果葉=PRESERVE_RESULT,入力=deepcopy(q['入力']))
    return item

def prepare_dossier(result,p,state_ref,version,fingerprint,public_ref,save,nonce):
    """save(name, object) writes full typed data using reviewed codec/guard.
    Returns HOLD with all material retained if no fully supported candidate.
    It does not authorize a step: existing independent verifier remains mandatory.
    """
    full=result['全作用候補'];checks={};technical=[]
    for c in full['全候補']:
        cid=str(c['候補番号']);refs=[]
        for q in c['照会全件']:
            native_part(q['返却'])
            usage='作用対応' if q['境界']==ACTION_BOUNDARY else '保存条件' if q['境界']==PRESERVE_BOUNDARY else '目標効果'
            refs.append({'用途':usage,'参照':reply_file(q)})
        item=preservation_item(c,cid,p)
        support=c['効果状態']=='効果支持' and item['由来']!='未確認'
        decision='支持' if support else '不採用' if c['効果状態'] in ('予測効果不成立','目標不一致HOLD') else '未確認'
        checks[cid]={'判定':decision,'理由':deepcopy(c['理由']) or ['実照会と現在前提に基づく候補分類'],
          '前提':deepcopy(c['前提']),'適用境界':deepcopy(p['候補適用境界'][cid]),'照会参照全件':refs,'保存条件':item}
        technical.append({'candidate_id':cid,'action':deepcopy(p['候補作用'][cid]),'execution_permission':False})
    fullref=save('full-candidates',full)
    measured=save('current-projection',{'観測指紋':fingerprint,'全公開観測参照':public_ref,'前境界':p})
    # The verifier fixes exact index ordering; no deduplication of correlated refs.
    index={'状態参照':state_ref,'全照会参照群':[x['参照'] for c in checks.values() for x in c['照会参照全件']],
           '全保存測定参照群':[]}
    # Preservation is already present in the full query list; no duplicate support entry.
    ir=save('support-index',index)
    d={'スキーマ':'最終採否証拠-v1','状態参照':state_ref,'状態版':version,'観測指紋':fingerprint,
       '前境界測定参照':measured,'全候補参照':fullref,'候補検査':checks,
       '順序規則':{'種類':'固定候補生成順','一手後':'必ず再観測再照会'},'支持索引参照':ir}
    dr=save('dossier',d);tr=save('technical-candidates',technical)
    admitted=[cid for cid,c in checks.items() if c['判定']=='支持']
    if not admitted:return {'status':'HOLD','dossier':dr,'all_candidates':tr,'reason':'支持済候補なし'}
    selected=admitted[0]
    rr={cid:save('unexecuted-'+cid,{'候補番号':cid,'判定':c['判定'],'理由':c['理由'],'実行':'未実行'})
        for cid,c in checks.items() if cid!=selected}
    record={'schema':'verified-final-adoption-v1','request_id':nonce,'observation_fingerprint':fingerprint,
      'hds_state_version':version,'candidate_set_ref':tr,'support_refs':[ir],'rejection_refs':rr,
      'final_adoption_ref':dr,'selected_candidate_id':selected,'action':deepcopy(p['候補作用'][selected])}
    return {'status':'pending-independent-verifier','record':record,'dossier':d,'projected':p}

def compare_effect(before_result,after_scenes,boundary,selected,work):
    """All returned phases, same old-goal correspondence, no after candidate query.
    after_scenes preserves each scene/selection or full perceptual failure.
    Unknown is never False or silently excluded. These are measured effects,
    not additional HDS teachers.
    """
    before=before_result['場面'];selection=before_result['選択観測']['selection']
    pool=before_result['全目標pool']['候補']
    require(len(pool)==1,'unique goal effect boundary')
    action=selected['作用'];pre=work.候補前提(before,selection,pool,action)[0]
    results=[]
    for i,phase in enumerate(after_scenes):
        entry={'相':i,'元観測':deepcopy(phase),'効果':None,'UNKNOWN':None}
        results.append(entry)
        if not boundary['旧問題継続確認']:
            entry['UNKNOWN']='公開境界移行。旧問題の保存/修復を割り当てない';continue
        scene=phase.get('scene')
        if scene is None or 'selection_unknown' in phase:
            entry['UNKNOWN']='全相の知覚または選択表示未確認';continue
        if not work.同型(work.構造(before),work.構造(scene)):
            entry['UNKNOWN']='旧目標と全枠の対応未確認';continue
        effect=work.候補効果(pre,scene,phase['selection'])
        # 14 preparation output is explicit visible inventory selection, with
        # a fully parsed None a negative. Do not overwrite legacy None field.
        sel=phase['selection']
        effect['準備末相候補']=False if sel is None else any(work.同型(sel['記号'],dict(pre['要求枠'])[k]) for k in pre['未充足枠'])
        entry['効果']=effect
    unknown=not results or any(x['UNKNOWN'] is not None for x in results)
    kept=pre['既充足枠']
    preservation=None if not kept else None if unknown else all(x['効果']['既充足が全て保持された'] is True for x in results)
    last=None if not results else results[-1]['効果']
    if selected['作業']=='完成列提出':actual=boundary['公開進捗あり']
    elif selected['作業']=='在庫記号を選択':actual=None if last is None else last['準備末相候補']
    elif selected['作業']=='選択記号を空欄へ割当':actual=None if last is None else last['不足が修復された']
    else:actual=None
    return {'全相':results,'目標前提':pre,'実測目的効果':actual,'全相既充足保存':preservation,
      '保存対象なし':not kept,'UNKNOWN':unknown,'隠れ状態':'未観測','報酬':'未観測',
      '追加教示':False,'新独立支持加算':0,'公開境界':deepcopy(boundary)}
