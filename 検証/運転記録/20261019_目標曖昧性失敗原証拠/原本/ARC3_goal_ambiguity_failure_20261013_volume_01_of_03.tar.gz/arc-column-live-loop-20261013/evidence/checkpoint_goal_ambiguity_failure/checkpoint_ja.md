# ARC3 一意目標境界失敗 checkpoint（2026-10-13）

run: 087b258ca57e41ff82229797bd8035b4 / session 21424。
状態: CLOSED / failed_closed / 実exit 1。全run成功ではない。

## 保存結果と停止原因
- 90 Actions、2,234 Queries、Teach 0、1,812公開応答相、93通常状態を保存。
- 照会・学習判定counterのみ2,479→4,713（+2,234）。知識は129経験のまま。
- 公開level値は0→6/8の途中観測。認定達成数1/183は据置で、6を追加しない。
- step90で5個の目標候補が成立。学習役割で生成する出力列は同じだが、枠への割当・具体的操作効果は同値ではない。未実行候補の環境受理は不明。
- 準備/修復/保存条件の接続境界は一意の完全目標を要求する。複数目標はUNKNOWNとなり、project_currentの「unique complete goal required」ValueErrorでfailed_closedになった。パーサ異常や資源期限停止とは異なる。
- step90の全13照会、全semantic、after-query標準状態は保存完了。5目標pool、9操作候補と未完走査の元値を保持。final adoption/dossier/Action91には進んでいない。
- summaryの汎用remaining_candidate_queries文は未返却照会の証拠ではない。cause監査のsuffix_interpretationにより上記完了範囲を明示する。

## 独立監査
運用保存監査: OPERATIONAL_RECOVERY_VERIFIED_RUN_FAILED、session52894・実exit0。2,234返却対と全replay、90軌跡鎖、93標準状態、6,266原参照 / 16,141参照出現、11,631 typed packet decode checksを検証。
原因監査: CAUSE_REPRODUCED_RUN_FAILED、session65270・実exit0。全2,234返却・22,340規則支持、現在13照会pure replay、全5,040割当からの5目標pool再計算、同ValueError、Action91未発行を確認。原因報告の328相は当該保存応答の相数で、run総数1,812相とは別。

「全回収」は列挙された公開相、照会、軌跡、通常状態、例外traceと保存成分の運用上の回復を指す。任意Python heap・code object・未保存localsの完全保存を意味しない。全過去1,812相の知覚/効果を新規再測定した監査ではなく、原因末相の知覚・全pool・現在semanticを独立再計算した。

## 収録範囲
閉鎖済み当該run/failure（opaque SDK除外）、loop_live_v11 / contract_v7 / rootgate、一致する接続層source pins、実工具、独立監査全source/report/clarificationを収録。監査v1 sourceは未実行で、実行済みはv2。clarificationのHOLD提案は提案記録であり採用済み変更ではない。進行中の新HOLD source・LS別教師集合設計は含めない。
SDK opaque・ゲーム実装・HDS中核本体は不読/未収録。HDS pin参照は維持し、再監査には外部固定baselineが必要。SDK/HDS/Actionを実行しない。元証拠は変更しない。

過去baselineは複製せずarchive hashで参照:
- ARC3_resource_failure_checkpoint_20261013.tar.gz: 6997ea0290620d809eac4c7c5a727786bc4b4f1c9babcdbd2bc6a07b93fda992
- ARC3_first_fresh_level_checkpoint_20261013.tar.gz: 5a063272f5eb967c051fb54e0d896f4d774aa54990b97f93627aec0445290b0d
- ARC3_compute_failure_checkpoint_20261013.tar.gz: 98bb631629373e59ba642ba65077a1dd3952a038d42331e43a2c483b383d902a

## 資源とarchive検証
出力合計64 MiB以内、L 2 GiB / evidenceカテゴリ2,000 MiB、globalfuture3,540 MiB + diskfloor1,024 MiB、RAM4,608 MiB + floor2,048 MiB、packaging AS512 MiB。stream archiveで全member bytes/hash、元source再照合、manifest一致、gzip全CRC/EOF読戻しを検証。展開複製・upload/sendなし。exact archive refsはverification_v1.json。
