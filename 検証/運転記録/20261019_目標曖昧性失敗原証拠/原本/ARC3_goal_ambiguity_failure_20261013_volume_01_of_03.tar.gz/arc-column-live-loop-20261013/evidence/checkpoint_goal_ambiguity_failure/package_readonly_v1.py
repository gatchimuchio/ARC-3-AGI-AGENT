import resource
resource.setrlimit(resource.RLIMIT_AS,(512<<20,512<<20))
resource.setrlimit(resource.RLIMIT_FSIZE,(60<<20,60<<20))
import json,hashlib,tarfile,gzip,os,time,io
from pathlib import Path
B=Path('/workspace/scratch/a94ff513b3af');L=B/'arc-column-live-loop-20261013';O=L/'evidence/checkpoint_goal_ambiguity_failure';N='087b258ca57e41ff82229797bd8035b4'
CAP=64<<20

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
def ref(p):return {'path':str(p.relative_to(B)),'bytes':p.stat().st_size,'sha256':sha(p)}
def total(d):return sum(p.stat().st_size for p in d.rglob('*') if p.is_file())
def guard():
 assert total(O)<=CAP
 assert total(L)+CAP<=2048<<20
 assert total(L/'evidence')+CAP<=2000<<20
 s=os.statvfs(B);assert s.f_bavail*s.f_frsize>=(3540+1024)*2**20
 mem=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
 assert mem>=(4608+2048)*2**20
 return {'available_disk_bytes':s.f_bavail*s.f_frsize,'available_ram_bytes':mem,'L_source_bytes':total(L),'output_bytes':total(O)}
pre=guard()
contract=json.loads((L/'source/loop_contract_v7.json').read_text())
files=set();excluded=[]
for d in (L/'evidence'/N,L/'failure'/N):
 for p in d.rglob('*'):
  if p.is_file():
   assert not p.is_symlink()
   if 'sdk-runtime' in p.parts:excluded.append({'path':str(p.relative_to(B)),'reason':'opaque SDK: body not opened','bytes_stat_only':p.stat().st_size})
   else:files.add(p)
for r in contract['source_pins']+contract['core_and_family_pins']:
 p=Path(r['path'])
 if 'HDS' in p.parts:
  excluded.append({'path':str(p.relative_to(B)),'reason':'HDS core: no body read/package; pinned reference only','recorded_pin':r});continue
 assert p.is_relative_to(B) and 'sdk-runtime' not in p.parts and 'environment_files' not in p.parts
 assert p.stat().st_size==r['bytes'] and sha(p)==r['sha256'],str(p)
 files.add(p)
for x in ['source/loop_contract_v7.json','source/root_loop_release_'+N+'.json','evidence/actual_live_loop_tools_087b258c_v1.json']:
 files.add(L/x)
files.update((L/'evidence').glob('independent_failure_087b258c_*'))
for name,size,h in [('independent_failure_087b258c_summary_v2.json',2445656,'1d956d63a277e9171e6ed7ed39f756cb6a874223d37ca65cceb9ff5011f471f6'),('independent_failure_087b258c_cause_v1.json',751070,'1ed490e0c695105f5f71a225aab7d475fac886107864197cfb511abd24378a22')]:
 p=L/'evidence'/name;assert p.stat().st_size==size and sha(p)==h
native=json.loads((L/'evidence/actual_live_loop_tools_087b258c_v1.json').read_text());assert native['actual_exit']==1 and native['status']=='failed_closed'
summary=json.loads((L/'evidence/independent_failure_087b258c_summary_v2.json').read_text())
assert summary['counts']['Actions']==90 and summary['counts']['native_queries']==2234 and summary['counts']['normal_states']==93 and summary['counts']['response_phases']==1812
report='# ARC3 一意目標境界失敗 checkpoint（2026-10-13）\n\nrun: 087b258ca57e41ff82229797bd8035b4 / session 21424。\n状態: CLOSED / failed_closed / 実exit 1。全run成功ではない。\n\n## 保存結果と停止原因\n- 90 Actions、2,234 Queries、Teach 0、1,812公開応答相、93通常状態を保存。\n- 照会・学習判定counterのみ2,479→4,713（+2,234）。知識は129経験のまま。\n- 公開level値は0→6/8の途中観測。認定達成数1/183は据置で、6を追加しない。\n- step90で5個の目標候補が成立。学習役割で生成する出力列は同じだが、枠への割当・具体的操作効果は同値ではない。未実行候補の環境受理は不明。\n- 準備/修復/保存条件の接続境界は一意の完全目標を要求する。複数目標はUNKNOWNとなり、project_currentの「unique complete goal required」ValueErrorでfailed_closedになった。パーサ異常や資源期限停止とは異なる。\n- step90の全13照会、全semantic、after-query標準状態は保存完了。5目標pool、9操作候補と未完走査の元値を保持。final adoption/dossier/Action91には進んでいない。\n- summaryの汎用remaining_candidate_queries文は未返却照会の証拠ではない。cause監査のsuffix_interpretationにより上記完了範囲を明示する。\n\n## 独立監査\n運用保存監査: OPERATIONAL_RECOVERY_VERIFIED_RUN_FAILED、session52894・実exit0。2,234返却対と全replay、90軌跡鎖、93標準状態、6,266原参照 / 16,141参照出現、11,631 typed packet decode checksを検証。\n原因監査: CAUSE_REPRODUCED_RUN_FAILED、session65270・実exit0。全2,234返却・22,340規則支持、現在13照会pure replay、全5,040割当からの5目標pool再計算、同ValueError、Action91未発行を確認。原因報告の328相は当該保存応答の相数で、run総数1,812相とは別。\n\n「全回収」は列挙された公開相、照会、軌跡、通常状態、例外traceと保存成分の運用上の回復を指す。任意Python heap・code object・未保存localsの完全保存を意味しない。全過去1,812相の知覚/効果を新規再測定した監査ではなく、原因末相の知覚・全pool・現在semanticを独立再計算した。\n\n## 収録範囲\n閉鎖済み当該run/failure（opaque SDK除外）、loop_live_v11 / contract_v7 / rootgate、一致する接続層source pins、実工具、独立監査全source/report/clarificationを収録。監査v1 sourceは未実行で、実行済みはv2。clarificationのHOLD提案は提案記録であり採用済み変更ではない。進行中の新HOLD source・LS別教師集合設計は含めない。\nSDK opaque・ゲーム実装・HDS中核本体は不読/未収録。HDS pin参照は維持し、再監査には外部固定baselineが必要。SDK/HDS/Actionを実行しない。元証拠は変更しない。\n\n過去baselineは複製せずarchive hashで参照:\n- ARC3_resource_failure_checkpoint_20261013.tar.gz: 6997ea0290620d809eac4c7c5a727786bc4b4f1c9babcdbd2bc6a07b93fda992\n- ARC3_first_fresh_level_checkpoint_20261013.tar.gz: 5a063272f5eb967c051fb54e0d896f4d774aa54990b97f93627aec0445290b0d\n- ARC3_compute_failure_checkpoint_20261013.tar.gz: 98bb631629373e59ba642ba65077a1dd3952a038d42331e43a2c483b383d902a\n\n## 資源とarchive検証\n出力合計64 MiB以内、L 2 GiB / evidenceカテゴリ2,000 MiB、globalfuture3,540 MiB + diskfloor1,024 MiB、RAM4,608 MiB + floor2,048 MiB、packaging AS512 MiB。stream archiveで全member bytes/hash、元source再照合、manifest一致、gzip全CRC/EOF読戻しを検証。展開複製・upload/sendなし。exact archive refsはverification_v1.json。\n'
reportp=O/'checkpoint_ja.md';reportp.write_text(report,encoding='utf-8');files.add(reportp);files.add(O/'package_readonly_v1.py')
rows=[ref(p) for p in sorted(files)];sourcebytes=sum(r['bytes'] for r in rows)
manifest={'schema':'arc3-goal-ambiguity-failure-checkpoint-v1','nonce':N,'status':'OPERATIONAL_RECOVERY_VERIFIED_RUN_FAILED','source_file_count':len(rows),'source_bytes':sourcebytes,'members':rows,'excluded':excluded,'external_baseline_archives':[{'name':'ARC3_resource_failure_checkpoint_20261013.tar.gz','sha256':'6997ea0290620d809eac4c7c5a727786bc4b4f1c9babcdbd2bc6a07b93fda992'},{'name':'ARC3_first_fresh_level_checkpoint_20261013.tar.gz','sha256':'5a063272f5eb967c051fb54e0d896f4d774aa54990b97f93627aec0445290b0d'}],'limits':{'output':CAP,'L':2048<<20,'evidence_category':2000<<20,'globalfuture':3540<<20,'disk_floor':1024<<20,'RAM_reserved':4608<<20,'RAM_floor':2048<<20,'packaging_AS':512<<20},'preflight':pre}
manifest['external_baseline_archives'].append({'name':'ARC3_compute_failure_checkpoint_20261013.tar.gz','sha256':'98bb631629373e59ba642ba65077a1dd3952a038d42331e43a2c483b383d902a'})
mp=O/'manifest_v1.json';mp.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');mr=ref(mp)
archive=O/'ARC3_goal_ambiguity_failure_checkpoint_20261013.tar.gz'
with archive.open('xb') as f:
 with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0,compresslevel=6) as gz:
  with tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT) as tar:
   for r in rows+[mr]:
    p=B/r['path'];assert p.stat().st_size==r['bytes'] and sha(p)==r['sha256']
    info=tar.gettarinfo(str(p),arcname=r['path']);info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
    with p.open('rb') as src:tar.addfile(info,src)
    assert p.stat().st_size==r['bytes'] and sha(p)==r['sha256']
    assert archive.stat().st_size+total(O)-archive.stat().st_size<CAP
want={r['path']:r for r in rows+[mr]};seen=set();readbytes=0
with tarfile.open(archive,'r|gz') as tar:
 for member in tar:
  assert member.isfile() and member.name in want and member.name not in seen
  seen.add(member.name);h=hashlib.sha256();n=0
  with tar.extractfile(member) as src:
   for b in iter(lambda:src.read(1<<20),b''):h.update(b);n+=len(b)
  r=want[member.name];assert n==member.size==r['bytes'] and h.hexdigest()==r['sha256'];readbytes+=n
assert seen==set(want)
# Explicit read through the entire gzip trailer and physical EOF; tar iteration alone is insufficient.
gzipbytes=0
with gzip.open(archive,'rb') as gz:
 for b in iter(lambda:gz.read(1<<20),b''):gzipbytes+=len(b)
assert json.loads(mp.read_text())==manifest
for r in rows+[mr]:assert (B/r['path']).stat().st_size==r['bytes'] and sha(B/r['path'])==r['sha256']
post=guard()
v={'schema':'arc3-checkpoint-readback-v1','status':'PASS','archive':ref(archive),'manifest':mr,'member_count':len(seen),'source_file_count':len(rows),'source_bytes':sourcebytes,'all_member_bytes':readbytes,'full_gzip_uncompressed_bytes':gzipbytes,'checks':{'all_member_sha256_and_bytes':True,'source_unchanged_sha256_and_bytes':True,'manifest_exact':True,'full_gzip_CRC_EOF':True,'no_full_extraction':True,'no_SDK_HDS_Action_execution':True,'no_opaque_body_reads':True},'preflight':pre,'postflight':post,'limits':manifest['limits']}
vp=O/'verification_v1.json';vp.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n');assert total(O)<=CAP
print(json.dumps(v,ensure_ascii=False));print('report',json.dumps(ref(reportp)));print('verification',json.dumps(ref(vp)));print('output_bytes',total(O))
