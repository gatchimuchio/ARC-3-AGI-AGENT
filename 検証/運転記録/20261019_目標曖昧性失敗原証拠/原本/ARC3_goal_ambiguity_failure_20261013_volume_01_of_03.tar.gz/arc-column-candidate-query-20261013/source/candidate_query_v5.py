"""All saved initial phases, same semantic column entry. Native gate required."""
import ast,base64,hashlib,importlib.util,json,lzma,os,resource,shutil,signal,sys,time,traceback
from pathlib import Path
from copy import deepcopy
B=Path('/workspace/scratch/a94ff513b3af');ROOT=B/'arc-column-candidate-query-20261013';MIB=1048576
FAMILY=B/'arc-current-family-source-20261013';CORE=B/'arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2'
OWNER=None
MANIFEST=json.loads((ROOT/'source/contract_v1.json').read_text())
MANIFEST['candidate']={'path': '/workspace/scratch/a94ff513b3af/arc-column-candidate-query-20261013/source/candidate_preservation_v1.py', 'bytes': 12814, 'sha256': 'a57f0490be3c186a072e9e80f41072581c3ecbfc7ef3aaae49283558281799f3'}

def guard(category=None,extra=0):
 caps={'source':4*MIB,'state_trace':48*MIB,'failure':12*MIB};used={}
 if ROOT.is_symlink():raise ValueError('root symlink')
 for k,cap in caps.items():
  p=ROOT/k;allfiles=list(p.rglob('*')) if p.exists() else []
  if p.is_symlink() or any(x.is_symlink() for x in allfiles):raise ValueError('scope symlink')
  used[k]=sum(x.stat().st_size for x in allfiles if x.is_file())
  if used[k]+(extra if category==k else 0)>cap:raise MemoryError('category '+k)
 if sum(used.values())+extra>64*MIB:raise MemoryError('64MiB scope')
 if shutil.disk_usage(B).free<(1476+1024)*MIB+extra:raise MemoryError('future1476MiB+diskfloor1GiB')
 mem=next(int(x.split()[1])*1024 for x in open('/proc/meminfo') if x.startswith('MemAvailable:'))
 if mem<(4608+2048)*MIB:raise MemoryError('RAM4.5GiB+floor2GiB')
 return used

def bind_helpers():
 r=MANIFEST['base'];p=Path(r['path']);raw=p.read_bytes()
 if len(raw)!=r['bytes'] or hashlib.sha256(raw).hexdigest()!=r['sha256']:raise ValueError('base exact pin')
 t=ast.parse(raw);names={'eq','jb','sha','identity','ref','fsyncdir','readref','capture_call','snapshot_value','frame_hash'}
 nodes=[n for n in t.body if isinstance(n,ast.FunctionDef) and n.name in names]
 nodes+=[n for n in t.body if isinstance(n,ast.ClassDef) and n.name=='Clock']
 old=next(n for n in t.body if isinstance(n,ast.ClassDef) and n.name=='Run');methods={'__init__','encoded','save','standard','markers','load_module'}
 body=[n for n in old.body if isinstance(n,ast.FunctionDef) and n.name in methods]
 if {n.name for n in body}!=methods:raise ValueError('base method closure')
 nodes.append(ast.ClassDef(name='BaseRun',bases=[],keywords=[],body=body,decorator_list=[]))
 tree=ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[]))
 ns=globals();exec(compile(tree,str(p),'exec'),ns)
bind_helpers()

def canonical_observation(boundary,packet,sequence):
 """Existing boundary fingerprint of the WHOLE public response; phase is separate."""
 if type(sequence)is not int or sequence<0:raise ValueError('explicit observation sequence')
 frames=[]
 for fr in packet['frames']:
  raw=base64.b64decode(fr['base64'],validate=True)
  if fr['dtype']!='|i1' or fr['order']!='C' or fr['shape']!=[64,64] or len(raw)!=4096 or hashlib.sha256(raw).hexdigest()!=fr['sha256'] or any(x>15 for x in raw):raise ValueError('whole observation frame closure')
  frames.append([list(raw[j:j+64]) for j in range(0,4096,64)])
 if packet['frame_count']!=len(frames):raise ValueError('whole phase count')
 public=deepcopy(packet['model_json']);public['frame']=frames
 return boundary.観測する(public,観測通番=sequence)

class View:
 def __init__(self,owner):self.owner=owner
 def 照会する(self,value):return self.owner.call('照会する',value)

def semantic_entry(family,candidate,frame,available,view,ask,public_state):
 """Reusable actual observation entry; evidence IDs are outside this function."""
 out={'適用性':'未確認','場面':None,'全目標pool':None,'学習役割':None,'選択観測':None,'全作用候補':None,'例外':[], '実行許可':False}
 if public_state!='NOT_FINISHED':
  out['保留理由']='現在の公開状態は進行中でない';return out
 try:scene=family.図式を観測する(frame)
 except family.知覚不適用 as e:
  out['適用性']='構造上不適用';out['例外'].append({'type':type(e).__name__,'args':e.args,'traceback':traceback.format_exc()});return out
 except (ValueError,KeyError,TypeError) as e:
  out['例外'].append({'type':type(e).__name__,'args':e.args,'traceback':traceback.format_exc()});return out
 out['場面']=deepcopy(scene);out['適用性']='固定知覚適合'
 n=len(scene['在庫群']);slots=sum(len(b['枠群']) for b in scene['容器群'])
 # Complete enumeration bound: pool <=4; candidate mapping+effect+optional preservation <=3*(N+S+1).
 out['全構造候補数上界']=n+slots+1;out['API数上界']=4+3*(n+slots+1)
 view.owner.allow_frame(out['API数上界'])
 roles={};role_records=[]
 class RolesView:
  def 照会する(self,external):
   result=view.照会する(external)
   if external.対象系境界==family.役割境界:
    role_records.append({'input':external,'reply':result})
    values=[p['予測値'] for p in result.内容.get('予測群',[]) if tuple(p['結果経路'])==('列展開役割',)]
    if result.状態=='出力' and values and all(v==values[0] for v in values) and not result.内容.get('係争中原理群') and not result.内容.get('断定保留理由群'):
     roles[external.内容['記号は中空']]=values[0]
   return result
 goal=family.内容候補を構成する(RolesView(),scene);out['全目標pool']=goal;out['役割全照会']=role_records;out['学習役割']=roles
 try:selection={'selection':family.選択を読む(frame,scene)}
 except (ValueError,KeyError,TypeError) as e:selection={'selection':None,'selection_unknown':{'type':type(e).__name__,'args':e.args,'traceback':traceback.format_exc()}}
 out['選択観測']=selection
 if len(roles)!=2:out['保留理由']='両学習役割未確定。全pool/全照会保持';return out
 out['全作用候補']=candidate.全作用候補を構成する(scene,goal,roles,selection,available,ask,family.一致する,保存照会=ask)
 return out

class Run(BaseRun):
 def __init__(self):
  super().__init__();self.frame_budget=0;self.frame_calls=0;self.frame_results=[];self.input_closures=[];self.failed_suffix=[];self.observation_origin=None;self.candidate_codes=set()
 def allow_frame(self,count):
  if type(count)is not int or count<4:raise ValueError('finite structural budget')
  self.frame_budget=count
 def call(self,method,external):
  if method!='照会する':raise PermissionError('Teach/Action forbidden')
  if self.frame_calls>=self.frame_budget or len(self.calls)>=262144:raise MemoryError('complete-enumeration API stop; incomplete suffix retained')
  i=len(self.calls);context=self.current
  origin=deepcopy(self.observation_origin);origin.update({'候補番号':None,'用途':'目標pool','境界':external.対象系境界,'復元状態参照':self.gate['final_state']})
  f=sys._getframe()
  while f:
   if f.f_code in self.candidate_codes:
    c=f.f_locals.get('c')
    if not isinstance(c,dict) or type(c.get('候補番号'))is not int:raise ValueError('candidate origin closure')
    origin['候補番号']=c['候補番号'];origin['用途']='作用対応' if external.対象系境界==self.candidate.作用境界 else '候補効果';break
   f=f.f_back
  del f
  self.current={'ordinal':i,'frame':self.frame_ordinal,'method':method,'input':external,'origin':origin,'before':self.markers(),'capture':{}}
  intent=self.save('api_%06d_intent'%i,self.current)
  result=capture_call(self.machine,method,external,self.current['capture']);self.current['after']=self.markers()
  reply=self.save('api_%06d_reply'%i,self.current)
  self.calls.append({'ordinal':i,'frame':self.frame_ordinal,'method':method,'intent':intent,'reply':reply});self.frame_calls+=1
  self.current=context;return result
 def ask(self,boundary,facts):
  r=self.call('照会する',self.native.外部入力(deepcopy(facts),boundary))
  return {'状態':r.状態,'内容':r.内容,'追跡情報':r.追跡情報,'実照会保存参照':deepcopy(self.calls[-1])}
 def preflight(self,path,digest):
  g=json.loads(readref({'path':str(path),'bytes':Path(path).stat().st_size,'sha256':digest},65536));self.gate=g
  if g['schema']!='column-candidate-query-release-v1' or g['enabled']is not True or g['source_sha256']!=sha(__file__):raise PermissionError('root gate')
  if not isinstance(g['nonce'],str) or len(g['nonce'])!=32 or any(x not in '0123456789abcdef' for x in g['nonce']):raise ValueError('nonce')
  if g['limits']!={'AS':512*MIB,'compute':600,'save':120,'max_API':262144} or time.time()>g['admission_deadline_epoch']:raise PermissionError('finite gate')
  if g.get('latest_training_closed_and_independently_adopted')is not True:raise PermissionError('latest-state root adoption missing')
  for r in MANIFEST['dependencies']+[MANIFEST['candidate'],MANIFEST['fresh_preflight']]:readref(r,8*MIB)
  for name in ('final_state','preparation_actual_exit','preparation_independent_audit'):
   r=g[name];readref(r,16*MIB);self.input_closures.append({'kind':name,'ref':r,'identity':identity(r['path'])})
  # Exact latest final state/closure identities are supplied by root, never synthesized.
  packet=g['preparation_completion'];blob=readref(packet['file'],16*MIB);z=lzma.LZMADecompressor();raw=z.decompress(blob,max_length=16*MIB+1)
  if not z.eof or z.unused_data or z.check!=lzma.CHECK_CRC64 or len(raw)!=packet['rawbytes'] or hashlib.sha256(raw).hexdigest()!=packet['rawsha256']:raise ValueError('preparation complete CRC64/raw closure')
  completed=json.loads(raw)
  if completed.get('schema')!=g['baseline_expected']['schema'] or completed.get('status')!='complete' or completed.get('errors')!=[] or completed.get('teach_calls')!=g['baseline_expected']['teach_calls'] or completed.get('query_calls')!=g['baseline_expected']['query_calls'] or completed.get('Action')!=0 or completed.get('states',[])[-1:]!=[g['final_state']]:raise ValueError('actual latest training completion/finalstate')
  self.input_closures.append({'kind':'preparation_completion','ref':packet['file'],'identity':identity(packet['file']['path'])})
  audit=json.loads(readref(g['preparation_independent_audit'],16*MIB))
  if audit.get('status')!='PASS' or audit.get('errors')!=[]:raise ValueError('independent preparation PASS')
  if not g.get('independent_required_true_fields') or not isinstance(g.get('independent_schema'),str) or audit.get('schema')!=g['independent_schema']:raise ValueError('root exact independent schema/checks required')
  if any(audit.get('verified',{}).get(k)is not True for k in g['independent_required_true_fields']):raise ValueError('independent required complete verification')
  if audit.get('nonce')!=completed.get('nonce') or audit.get('completion')!=packet['file'] or audit.get('actual_exit')!=g['preparation_actual_exit'] or audit.get('states',[])[-1:]!=[g['final_state']]:raise ValueError('independent audit exact completion/state/exit/nonce joins')
  ex=json.loads(readref(g['preparation_actual_exit'],MIB))
  if ex.get('exit_code')!=0 or 'UTCEND ' not in ex.get('output',''):raise ValueError('actual latest native close')
  if json.loads(ex['output'].splitlines()[0]).get('receipt')!=packet:raise ValueError('actual close receipt exact join')
  guard();sys.dont_write_bytecode=True;sys.path.insert(0,str(CORE));sys.path.insert(0,str(FAMILY))
  import hds学習系統 as native
  import hds学習系統.永続化 as persistence
  from 接続 import 列図式規則 as family
  if Path(native.__file__).resolve()!=CORE/'hds学習系統/__init__.py' or Path(family.__file__).resolve()!=FAMILY/'接続/列図式規則.py':raise ValueError('import identities')
  self.native=native;self.enc=persistence._符号化;self.dec=persistence._復号;self.family=family
  self.candidate=self.load_module('pinned_column_candidates_v3',Path(MANIFEST['candidate']['path']))
  import types
  code=self.candidate.全作用候補を構成する.__code__
  self.candidate_codes={x for x in code.co_consts if isinstance(x,types.CodeType) and x.co_name in ('add','effect','preserve')}
  if len(self.candidate_codes)!=3:raise ValueError('pinned candidate origin code identities')
  from 接続.図式観測 import _作用番号
  self.action_number=_作用番号
  from 接続 import ARC3境界 as boundary
  wanted=[r for r in MANIFEST['dependencies'] if r['path'].endswith('/接続/ARC3境界.py')]
  if len(wanted)!=1 or ref(Path(boundary.__file__))!=wanted[0]:raise ValueError('actual boundary module pin')
  sequences=g['observation_sequences'];expected_observations=[]
  for entry in MANIFEST['fresh_frames']:
   if entry['observation'] not in expected_observations:expected_observations.append(entry['observation'])
  if not isinstance(sequences,list) or [x['observation'] for x in sequences]!=expected_observations or any(type(x['sequence'])is not int or x['sequence']<0 for x in sequences):raise ValueError('exact whole-observation sequence bindings')
  self.fresh=[];coverage=set()
  for entry in MANIFEST['fresh_frames']:
   case=json.loads(readref(entry['case']));obs=json.loads(readref(entry['observation']));index=entry['phase'];fr=obs['frames'][index]
   raw=base64.b64decode(fr['base64'],validate=True)
   if fr['dtype']!='|i1' or fr['order']!='C' or fr['shape']!=[64,64] or len(raw)!=4096 or hashlib.sha256(raw).hexdigest()!=fr['sha256'] or fr['sha256']!=entry['pixel_sha256'] or any(x>15 for x in raw):raise ValueError('saved raw frame exact')
   sequence=next(x['sequence'] for x in sequences if x['observation']==entry['observation']);canonical=canonical_observation(boundary,obs,sequence)
   key=(entry['observation']['path'],index)
   if key in coverage:raise ValueError('duplicate frame')
   coverage.add(key);frame=[list(raw[j:j+64]) for j in range(0,4096,64)];actions=[self.action_number(x) for x in obs['model_json']['available_actions']]
   # Metadata indices retained outside semantic entry, no ID branch.
   self.fresh.append({'evidence':entry,'frame':frame,'actions':actions,'public_state':obs['model_json'].get('state'),'phase_count':len(obs['frames']),'terminal_phase':index==len(obs['frames'])-1,'observation_sequence':canonical.観測通番,'boundary_fingerprint':canonical.指紋})
   self.input_closures.append({'kind':'observation','ref':entry['observation'],'identity':identity(entry['observation']['path'])})
  if len(self.fresh)!=27 or len({x['evidence']['observation']['path'] for x in self.fresh})!=25:raise ValueError('all27/25 coverage')
 def execute(self):
  self.machine=self.native.HDS学習系統.読み込む(self.gate['final_state']['path']);first,initial=self.standard('restored_before')
  if first['bytes']!=self.gate['final_state']['bytes'] or first['sha256']!=self.gate['final_state']['sha256']:raise ValueError('normal restore raw exact')
  view=View(self)
  for i,item in enumerate(self.fresh):
   self.frame_ordinal=i;self.frame_calls=0;self.frame_budget=0;self.phase='all_candidates';self.current={'ordinal':i,'input':item}
   origin={'公開観測参照':item['evidence']['observation'],'相':item['evidence']['phase'],'画素SHA256':item['evidence']['pixel_sha256'],'利用可能作用':item['actions'],'公開状態':item['public_state'],'全相数':item['phase_count'],'末相':item['terminal_phase']}
   self.observation_origin={**origin,'公開観測全体SHA256':item['evidence']['observation']['sha256'],'診断相指紋':hashlib.sha256(jb(origin)).hexdigest(),'観測指紋':item['boundary_fingerprint'],'ARC3境界観測指紋':item['boundary_fingerprint'],'観測通番':item['observation_sequence'],'live採否可能':False,'指紋注記':'既存ARC3境界.観測するの全応答指紋。通番はgate明示。保存診断でありliveには実現在観測との完全一致が必要'}
   self.current['origin']=self.observation_origin
   self.save('frame_%02d_input'%i,self.current)
   result=semantic_entry(self.family,self.candidate,item['frame'],item['actions'],view,self.ask,item['public_state'])
   result['actual_API_count']=self.frame_calls
   result['phase_scope']={'末相':item['terminal_phase'],'相':item['evidence']['phase'],'全相数':item['phase_count'],'診断のみ':True,'live採否可能':False}
   if result.get('適用性')=='固定知覚適合' and not item['terminal_phase']:result['非末相注意']='候補は仮想診断。現在状態/Actionへ昇格禁止'
   self.frame_results.append(self.save('frame_%02d_result'%i,{'ordinal':i,'evidence':item['evidence'],'result':result}));self.current=None
  last,final=self.standard('after_all_queries');expected=self.dec(self.enc(initial))
  for k in ('照会','学習判定'):expected['識別子状態'][k]=expected['識別子状態'].get(k,0)+len(self.calls)
  if not eq(self.enc(expected),self.enc(final)):raise ValueError('full state except pairedQuery counters')
  for x in self.input_closures:
   readref(x['ref'],16*MIB)
   if identity(x['ref']['path'])!=x['identity']:raise ValueError('input identity changed')
  terminal={'schema':'column-all-candidate-query-completion-v1','nonce':self.gate['nonce'],'status':'complete','errors':[],
    'frames':self.frame_results,'frame_count':27,'api_calls':self.calls,'states':self.state_refs,'Teach':0,'Query':len(self.calls),'Action':0,
    'unprocessed_suffix':[],'state_only_paired_Query_counter_change':True,'closure_refs':self.input_closures,'limits':'all candidates retained; learned effects are not execution adoption or fresh success'}
  r=self.save('completion',terminal,codec=False);self.complete=True;return r

def run(path,digest):
 global OWNER
 if OWNER is not None:raise RuntimeError('single run')
 soft,hard=resource.getrlimit(resource.RLIMIT_AS)
 if not 0<soft<=512*MIB or not 0<hard<=512*MIB:raise PermissionError('AS before native import')
 OWNER=Run();OWNER.clock.enter('compute')
 try:
  OWNER.preflight(path,digest);r=OWNER.execute();OWNER.clock.stop();print(json.dumps({'status':'complete','receipt':r,'Query':len(OWNER.calls),'Action':0}),flush=True);return r
 except BaseException as e:
  OWNER.clock.stop();OWNER.exceptions.append(e);OWNER.errors.append({'type':type(e).__name__,'args':e.args,'traceback':traceback.format_exc()})
  print(json.dumps({'status':'failed_held','errors':OWNER.errors,'frame':OWNER.frame_ordinal},ensure_ascii=False),flush=True)
  try:OWNER.failure=OWNER.save('failure',{'errors':OWNER.errors,'current':OWNER.current,'pending':OWNER.pending,'saved_frames':OWNER.frame_results,'unprocessed_suffix':list(range(len(OWNER.frame_results),27))},'failure')
  except BaseException as e:OWNER.exceptions.append(e);print(traceback.format_exc(),flush=True)
  finally:OWNER.clock.stop()
  while True:time.sleep(3600)
