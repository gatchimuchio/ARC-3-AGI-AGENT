"""純粋な最終採否検査。HDS/SDK/環境を呼ばず、候補の許可を書き換えない。
信頼根は呼出側が独立監査した参照一覧と現在観測の純粋再投影関数。
要求自身が新しい信頼根を作ることはできない。
"""
import copy
import hashlib
import json
import lzma
from pathlib import Path
from adapter import Refusal, raw_json, digest

提出境界='公開列図式:有限全列または生産的反復の目標長一致と提出受理'
提出入力='終端条件に応じた列が一致'
提出結果='提出が受理された'
終端保存区分='受理による旧問題終端のため対象外'

保存境界='公開列図式・一意目標候補・既充足枠非空・可視対象操作の全相保存'
保存入力='可視対象に対する操作区分'
保存結果='応答全相で既充足枠が保持された'
保存操作区分=('在庫選択表示なしのクリック','在庫選択済みの実枠クリック')

不確実項目=('競合群','断定保留理由群','係争中原理群','追加観測要求群','識別不能群')

def 要件(value,reason):
    if not value: raise Refusal(reason)

def 同値(a,b):
    if type(a) is not type(b): return False
    if isinstance(a,dict): return a.keys()==b.keys() and all(同値(a[k],b[k]) for k in a)
    if isinstance(a,(list,tuple)): return len(a)==len(b) and all(同値(x,y) for x,y in zip(a,b))
    return a==b

def 復号(x):
    """保存用タグだけを復号。型のimport/eval/オブジェクト復元なし。"""
    if isinstance(x,list): return [復号(v) for v in x]
    if not isinstance(x,dict): return x
    if set(x)=={'__辞書__'}:
        out={}
        for k,v in x['__辞書__']:
            k=復号(k)
            if isinstance(k,list):k=tuple(k)
            要件(isinstance(k,(str,int,bool,tuple)) and k not in out,'辞書鍵不正/重複')
            out[k]=復号(v)
        return out
    if set(x)=={'__組__'}: return [復号(v) for v in x['__組__']]
    if set(x) in ({'__データ型__','値'},{'__列挙__','値'}): return 復号(x['値'])
    return {k:復号(v) for k,v in x.items()}

def 経路値(x,path):
    for key in path: x=x[key]
    return x

class 固定証拠:
    def __init__(self,refs,roots):
        self.roots=tuple(Path(p).resolve() for p in roots)
        self.refs={str(Path(r['path']).resolve()):copy.deepcopy(r) for r in refs}
    def 読む(self,ref):
        要件(set(ref)=={'path','bytes','sha256'},'証拠参照形式')
        p=Path(ref['path']).resolve()
        要件(p.suffix in ('.json','.xz'),'JSON証拠以外の本文は読まない')
        要件(any(p.is_relative_to(r) for r in self.roots),'証拠allowlist外')
        要件(self.refs.get(str(p))==ref,'独立固定されていない証拠')
        要件(type(ref['bytes'])is int and 0<=ref['bytes']<=8<<20,'証拠容量')
        with p.open('rb') as f: raw=f.read((8<<20)+1)
        要件(len(raw)==ref['bytes'] and digest(raw)==ref['sha256'],'証拠改変')
        if p.suffix=='.xz':
            dec=lzma.LZMADecompressor(memlimit=64<<20);raw=dec.decompress(raw,max_length=(16<<20)+1)
            要件(dec.eof and not dec.unused_data and len(raw)<=16<<20,'証拠展開上限/多重stream')
        return 復号(json.loads(raw))

    def 包絡を読む(self,packet):
        要件(set(packet)=={'file','rawbytes','rawsha256'},'PacketRef形式')
        decoded=self.読む(packet['file'])
        p=Path(packet['file']['path']);raw=p.read_bytes()
        要件(digest(raw)==packet['file']['sha256'] and len(raw)==packet['file']['bytes'],'PacketRef読戻し差')
        if p.suffix=='.xz':
            z=lzma.LZMADecompressor(memlimit=64<<20);raw=z.decompress(raw,max_length=(16<<20)+1)
            要件(z.eof and not z.unused_data and z.check==lzma.CHECK_CRC64,'PacketRef圧縮境界')
        要件(type(packet['rawbytes'])is int and len(raw)==packet['rawbytes']<=16<<20 and digest(raw)==packet['rawsha256'],'PacketRef raw差')
        要件(同値(復号(json.loads(raw)),decoded),'PacketRef復号差')
        return decoded

def 返却原票を検査(store,q,entry,saved):
    ret=q['返却'];要件(set(ret)=={'状態','内容','追跡情報','実照会保存参照'},'実照会4field形式')
    link=ret['実照会保存参照']
    要件(set(link)=={'ordinal','frame','method','intent','reply'},'実照会保存参照形式')
    要件(link['reply']['file']==entry['参照'],'候補replyと採否参照差')
    要件(link['method']=='照会する' and type(link['ordinal'])is int and type(link['frame'])is int,'実照会索引形式')
    要件(同値(store.包絡を読む(link['reply']),saved),'reply包絡差')
    intent=store.包絡を読む(link['intent'])
    for k in ('ordinal','frame','method'):
        要件(同値(link[k],saved[k]) and 同値(link[k],intent[k]),'実照会索引差')
    for k in ('input','origin','before'):
        要件(同値(intent[k],saved[k]),'intent/reply入力境界差')
    要件(intent['capture']=={},'intentに事後返却が混入')
    native={k:ret[k] for k in ('状態','内容','追跡情報')}
    要件(同値(native,saved['capture']['return']),'native3fieldと保存原票差')
    return native

def 状態を検査(state,version):
    要件(type(version)is int and type(version)is not bool,'native状態版の型')
    要件(state.get('形式版')==3,'native保存形式未対応')
    hist=state['状態履歴'];要件(len(hist)-1==version,'状態版不一致')
    active={};experiences={}
    for lineage,pid in hist[-1].items():
        entries=state['原理履歴'][lineage]
        p=entries[-1]
        要件(p['原理識別子']==pid and p['採用状態']=='有効','有効原理履歴不一致')
        active[pid]=p
    for exp in state['台帳']['観測台帳']:
        key=exp['経験識別子'];要件(key not in experiences,'経験重複');experiences[key]=exp
    return active,experiences

def native照会を検査(saved,state,version,boundary,facts,key,expected):
    """本物の保存schemaを対象に、raw/排気/状態/原理版/支持経験を交差確認。"""
    active,experiences=状態を検査(state,version)
    要件(saved['method']=='照会する','学習返答は照会の代用不可')
    要件(saved['input']['対象系境界']==boundary and 同値(saved['input']['内容'],facts),'照会前提/境界不一致')
    cap=saved['capture'];要件(len(cap['raw'])==1,'native返却数')
    raw=cap['raw'][0];ret=cap['return'];out=ret['内容']
    要件(ret['状態']=='出力','native出力でない')
    要件(raw['現在状態版']==version and out['現在状態版']==version,'照会状態版不一致')
    learning=raw['学習過程']
    要件(learning['学習前状態版']==version==learning['学習後状態版'],'照会で状態変化')
    要件(raw['追跡情報']['対象系境界']==boundary and ret['追跡情報']==raw['追跡情報'],'照会追跡不一致')
    for name in 不確実項目:
        要件(name in raw and name in out and raw[name]==[] and out[name]==[], 'native HOLD:'+name)
    要件(同値(raw['予測群'],out['予測群']),'排気とraw予測差')
    rp={p['原理識別子']:p for p in raw['有効原理群']}
    要件(set(rp)==set(active),'照会と状態の有効原理集合差')
    for pid,p in rp.items(): 要件(同値(p,active[pid]),'原理版/本文差')
    public={p['原理識別子']:p for p in out['有効原理群']}
    要件(set(public)==set(active),'排気原理集合差')
    for pid,p in public.items():
        要件(all(同値(v,active[pid].get(k)) for k,v in p.items()),'排気原理版/内容差')
    selected=[p for p in raw['予測群'] if p['結果経路']==[key]]
    要件(selected and all(同値(p['予測値'],expected) for p in selected),'目標予測欠落/負予測/競合')
    support=[]
    for pred in selected:
        p=active[pred['原理参照']]
        要件(p['対象系境界']==boundary and p['結果経路']==[key],'原理適用境界差')
        要件(p['反証参照群']==[] and p.get('除外反証参照群',[])==[],'原理反証あり')
        values=[経路値(facts,path) for path in p['条件経路群']]
        要件(同値(values,pred['条件値群']),'原理条件値差')
        要件(p['根拠参照群'],'実支持経験欠落')
        matches=[]
        for eid in p['根拠参照群']:
            要件(eid in experiences,'支持参照が存在しない')
            exp=experiences[eid]
            要件(exp['対象系境界']==boundary,'支持経験境界差')
            measured=exp['原入力'];condition=[経路値(measured,path) for path in p['条件経路群']]
            if 同値(condition,values):
                要件(同値(経路値(measured,[key]),expected),'同条件支持の反証')
                matches.append(eid)
        # 未測定値への一般化をこの最小検査器は行わない。
        要件(matches,'この条件値に一致する測定支持なし')
        support.append({'原理参照':p['原理識別子'],'原理版':p['版'],'全支持経験':p['根拠参照群'],'同条件支持経験':matches,'適用範囲':p['適用範囲']})
    return {'予測':expected,'結果葉':key,'支持':support,'全予測':raw['予測群'],'照会参照':raw['追跡情報']['照会参照']}

class 最終採否検査:
    """project_currentは固定/監査済みの純知覚。bool許可callbackではない。
    dossierには全候補・全照会・前境界測定・保存条件測定の参照を要求する。
    """
    def __init__(self,store,state_ref,dossier_ref,project_current):
        self.store=store;self.state_ref=state_ref;self.dossier_ref=dossier_ref
        self.project_current=project_current
    def __call__(self,record,evidence,current,version):
        d=self.store.読む(self.dossier_ref);state=self.store.読む(self.state_ref)
        要件(d['スキーマ']=='最終採否証拠-v1','採否証拠形式')
        要件(record['final_adoption_ref']==self.dossier_ref,'最終採否の固定参照差')
        要件(record['support_refs']==[d['支持索引参照']],'実支持索引の参照差')
        support_index=self.store.読む(d['支持索引参照'])
        expected_index={'状態参照':self.state_ref,
            '全照会参照群':[x['参照'] for c in d['候補検査'].values() for x in c['照会参照全件']],
            '全保存測定参照群':[r for c in d['候補検査'].values() if c['判定']=='支持' for r in c['保存条件']['測定参照群']]}
        要件(support_index==expected_index and evidence['supports']==[support_index],'実支持索引内容差')
        要件(d['状態参照']==self.state_ref and d['状態版']==version,'採否状態参照差')
        要件(d['観測指紋']==current.指紋==record['observation_fingerprint'],'古い観測')
        要件(record['hds_state_version']==version,'要求状態版差')
        状態を検査(state,version)
        measured=self.store.読む(d['前境界測定参照'])
        要件(measured['観測指紋']==current.指紋,'測定対象が古い')
        self.store.読む(measured['全公開観測参照'])
        projected=self.project_current(current)
        要件(同値(projected,measured['前境界']),'現在観測の再投影差')
        要件(projected['利用可能作用']==list(current.作用可能番号),'公開作用差')
        full=self.store.読む(d['全候補参照'])
        要件(full['実行許可']is False and full['自動選択']is None,'候補許可改変')
        要件(full['全体採否']!='HOLD' and full['規則不確実性']==[],'全体HOLD')
        original=full['全候補'];ids=[str(c['候補番号']) for c in original]
        要件(len(ids)==len(set(ids)) and ids,'候補集合不正')
        要件([c['candidate_id'] for c in evidence['candidates']]==ids,'全候補脱落/順序差')
        checks=d['候補検査'];要件(set(checks)==set(ids),'全候補理由欠損')
        admitted=[]
        for c,technical in zip(original,evidence['candidates']):
            cid=str(c['候補番号']);check=checks[cid]
            要件(c['実行許可']is False and technical['execution_permission']is False,'候補許可上書き')
            action=None if c['作用']is None else {'number':c['作用']['id'],'arguments':c['作用']['data']}
            要件(technical['action']==action,'作用写像差')
            要件(同値(projected['候補作用'][cid],action) and 同値(projected['候補対象'][cid],c['対象']),'現場作用/対象不一致')
            要件(check['理由'] and check['判定']in ('支持','不採用','未確認'),'候補採否理由不足')
            qs=c['照会全件'];refs=check['照会参照全件']
            要件(len(qs)==len(refs),'未実行枝を含む全照会欠落')
            for q,entry in zip(qs,refs):
                saved=self.store.読む(entry['参照'])
                origin=saved.get('origin',{})
                要件(origin.get('live採否可能')is True,'保存診断照会はlive採否に流用しない')
                要件(origin.get('観測指紋')==current.指紋 and origin.get('公開観測参照')==measured['全公開観測参照'] and origin.get('復元状態参照')==self.state_ref,'別観測/旧回帰照会の流用')
                要件(saved['method']=='照会する' and saved['input']['対象系境界']==q['境界'] and 同値(saved['input']['内容'],q['入力']),'全照会入力差')
                cap=saved['capture'];要件(len(cap['raw'])==1,'全照会raw欠落')
                要件(cap['raw'][0]['現在状態版']==version and cap['return']['内容']['現在状態版']==version,'未実行枝の旧状態照会')
                返却原票を検査(self.store,q,entry,saved)
                for name in 不確実項目:
                    要件(cap['raw'][0].get(name)==[] and cap['return']['内容'].get(name)==[],'全候補照会のHOLD')
                要件(cap['return']['状態']!='断定保留','未実行枝nativeHOLD')
            if check['判定']!='支持': continue
            要件(c['効果状態']=='効果支持','局所効果未支持')
            要件(action is not None and action['number']in projected['利用可能作用'] and action['number']!=0,'公開作用外')
            要件(同値(check['前提'],c['前提']) and 同値(projected['候補前提'][cid],check['前提']),'現場前提不一致')
            要件(projected['候補適用境界'][cid]==check['適用境界'],'現場適用境界不一致')
            qs=c['照会全件'];refs=check['照会参照全件'];要件(len(qs)==len(refs) and qs,'照会全件欠落')
            roles=set()
            for q,entry in zip(qs,refs):
                要件(q['状態']=='支持','支持以外のnative照会')
                要件(q['境界']in check['適用境界'],'証明外の照会境界')
                要件(同値(projected['照会入力'][cid][q['境界']],q['入力']),'再投影照会入力差')
                expected=q['予測'];role=entry['用途'];roles.add(role)
                if role=='目標効果':要件(expected is True,'正の目標効果がない')
                elif role=='作用対応':要件(type(expected)is int and expected==action['number'],'作用対応予測差')
                elif role=='保存条件':
                    要件(check['保存条件']['由来']=='HDS実学習' and entry['参照']==check['保存条件']['照会参照'],'保存照会の一対一参照差')
                    要件(q['境界']==保存境界 and q['結果葉']==保存結果 and expected is True,'保存照会内容差')
                else:raise Refusal('照会用途未対応')
                saved=self.store.読む(entry['参照'])
                result=native照会を検査(saved,state,version,q['境界'],q['入力'],q['結果葉'],expected)
                返却原票を検査(self.store,q,entry,saved)
                要件(同値(result['全予測'],q['返却']['内容']['予測群']),'予測原票差')
            expected_roles={'作用対応','目標効果'}
            if check['保存条件']['由来']=='HDS実学習':expected_roles.add('保存条件')
            要件(roles==expected_roles,'作用対応/目標効果/保存照会の欠落')
            要件(sum(e['用途']=='保存条件' for e in refs)==(1 if '保存条件'in expected_roles else 0),'保存照会は一対一であること')
            self._保存検査(check['保存条件'],projected,cid,state,version,current.指紋,measured['全公開観測参照'],c)
            admitted.append(cid)
        scheduler=d['順序規則']
        要件(scheduler=={'種類':'固定候補生成順','一手後':'必ず再観測再照会'},'順序規則未対応')
        要件(admitted,'支持済候補なし')
        selected=record['selected_candidate_id'];要件(selected==admitted[0],'支持済集合の固定順序違反')
        chosen=next(x for x in evidence['candidates'] if x['candidate_id']==selected)
        要件(record['action']==chosen['action'],'選択作用差')
        要件(set(evidence['rejections'])==set(ids)-{selected},'未実行枝欠落')
        for cid,value in evidence['rejections'].items():
            要件(value=={'候補番号':cid,'判定':checks[cid]['判定'],'理由':checks[cid]['理由'],'実行':'未実行'},'未実行理由差')
        要件(evidence['adoption']==d,'最終採否参照差')
        return {'verified':True,'record_sha256':digest(raw_json(record)),'observation_fingerprint':current.指紋,'hds_state_version':version}
    def _保存検査(self,item,projected,cid,state,version,fingerprint,public_ref,candidate=None):
        要件(item['限界'] and item['隠れ状態']=='未観測' and item['報酬']=='未観測','保存限界欠落')
        要件(projected['既充足走査完了']is True,'現在の既充足集合が網羅未確認')
        correct=projected['既充足枠全件']
        要件(type(correct)is list,'既充足集合形式')
        要件(同値(item['既充足枠'],correct),'現在既充足集合と保存対象の差')
        要件(同値(item['適用署名'],projected['保存適用署名'][cid]),'保存適用範囲外')
        if item['由来']==終端保存区分:
            要件(candidate is not None and candidate['作業']=='完成列提出' and candidate['対象']is None,'提出以外の旧scope終端免除')
            要件(projected['現在列の目標一致']is True and candidate['前提'].get(提出入力)is True,'現在列の目標一致未成立')
            要件(candidate['作用']['id']not in (0,6) and candidate['作用']['data']=={},'提出作用対応不正')
            proof=[q for q in candidate['照会全件'] if q['境界']==提出境界 and q['結果葉']==提出結果]
            要件(proof and all(q['状態']=='支持' and q['予測']is True and 同値(q['入力'],{提出入力:True}) for q in proof),'既存提出受理の正予測不足')
            action_proof=[q for q in candidate['照会全件'] if q['境界']=='公開列図式:観測された解答作業と行動ID' and q['結果葉']=='必要行動ID']
            要件(action_proof and all(q['状態']=='支持' and type(q['予測'])is int and q['予測']==candidate['作用']['id'] and 同値(q['入力'],{'解答作業':'完成列提出'}) for q in action_proof),'学習済提出Action対応不足')
            # 呼出元で全照会の同版同観測native/raw/実支持を検査済み。
            要件(item['保存値']is None and item['測定参照群']==[] and item.get('照会参照')is None,'旧scope終端を保存Trueに読み替えない')
            return {'状態':終端保存区分,'保存値':None,'受理予測後の公開進捗照合が必要':True,'hidden':'未観測'}
        if item['由来']=='保存対象なし':
            要件(correct==[] and item['保存値']is None,'実在する保存対象を空集合に偽装')
            要件(item['測定参照群']==[] and item.get('照会参照')is None,'空集合の保存支持を捏造')
            return {'状態':'保存対象なし','保存値':None,'実支持':[],'hidden':'未観測'}
        要件(correct and item['保存値']is True,'空集合の保存Trueまたは負保存')
        if item['由来']=='HDS実学習':
            # 24教材のbefore-only境界。値Trueを教材packから直接借用しない。
            scope=projected['保存学習適用条件'][cid]
            要件(scope['唯一目標候補']is True and scope['操作境界成立']is True,'24保存教材の前境界外')
            operation=scope['操作区分'];要件(operation in 保存操作区分,'24保存教材の操作区分外')
            facts={保存入力:operation}
            要件(item['境界']==保存境界 and item['結果葉']==保存結果 and 同値(item['入力'],facts),'保存照会の24scope写像差')
            要件(item['測定参照群']==[],'学習支持と観測支持を混同')
            saved=self.store.読む(item['照会参照']);origin=saved.get('origin',{})
            要件(origin.get('live採否可能')is True,'保存診断の保存照会はlive採否に流用しない')
            要件(origin.get('観測指紋')==fingerprint and origin.get('公開観測参照')==public_ref and origin.get('復元状態参照')==self.state_ref,'保存照会の観測/状態参照差')
            return native照会を検査(saved,state,version,保存境界,facts,保存結果,True)
        要件(item['由来']=='公開観測による限定支持','保存支持の由来未対応')
        要件(item['測定参照群'],'既充足保存の測定支持なし')
        for ref in item['測定参照群']:
            m=self.store.読む(ref)
            要件(同値(m['操作前適用署名'],item['適用署名']),'保存教師の前境界差')
            要件(m['条件採否時点']=='作用前','after条件による選別')
            for r in m['全公開観測参照群']:self.store.読む(r)
            要件(m['全公開観測参照群'] and m['全既充足走査完了']is True and type(m['全応答相数'])is int and m['全応答相数']>0,'保存測定対象欠落')
            要件(同値([x['対象'] for x in m['既充足対象全件']],correct),'測定の全既充足対象と現場集合差')
            for x in m['既充足対象全件']:
                要件(len(x['観測後全相'])==m['全応答相数'] and all(同値(x['観測前'],y) for y in x['観測後全相']),'既充足の可視破壊/測定欠落')

def 日本語記憶へ(result,adoption,before_ref,intent_ref,semantic):
    """raw保存結果から正本候補を作る。採用/因果/成功を自動認定しない。"""
    a=result.get('analysis',{});holds=list(a.get('HOLD',[]))
    if result.get('status')!='recorded':holds.append('作用結果または保存が未確定')
    comparison=semantic.get('予測実測比較',{'状態':'未確認','根拠参照':[]})
    terminating=isinstance(semantic['保存条件'],dict) and semantic['保存条件'].get('由来')==終端保存区分
    if terminating:
        progress=(type(a.get('levels_delta'))is int and a['levels_delta']>0) or a.get('state_after')=='WIN'
        comparison={'状態':'一致' if progress else '不一致','予測':'提出受理による公開進捗または終端',
          '実測':{'完了数差':a.get('levels_delta'),'公開状態':a.get('state_after')},
          '根拠参照':[result['public_response']] if result.get('public_response') else [],
          '旧scope':'受理による終端/移行観測' if progress else '受理進捗未確認'}

    if comparison.get('状態')!='一致' or not comparison.get('根拠参照'):holds.append('予測と実測の意味比較未成立')
    return {'スキーマ':'ARC3作用経験-v1','対象':semantic['対象'],'役割':semantic['役割'],'関係':semantic['関係'],
      '観測前状態':{'指紋':adoption['observation_fingerprint'],'全公開観測参照':before_ref},
      '前提':semantic['前提'],'作用':adoption['action'],'選択理由':semantic['選択理由'],
      '予測':semantic['予測'],'予測実測比較':comparison,'保存条件':semantic['保存条件'],
      '観測後状態':{'指紋':result.get('observation_fingerprint'),'全公開観測参照':result.get('public_response')},
      '実測差分':{'初相':a.get('first_response_delta'),'全相間':a.get('phase_deltas'),'応答相数':a.get('response_phases'),
       '作用可能番号前':a.get('available_before'),'作用可能番号後':a.get('available_after'),
       '状態前':a.get('state_before'),'状態後':a.get('state_after'),'完了数差':a.get('levels_delta')},
      '失敗':{'公開失敗':a.get('failure_observed'),'未確定':result.get('status')!='recorded'},'HOLD':holds,
      '未観測':{'隠れ状態差':'未観測','報酬':'未観測','完了が生じた相':'未特定'},
      '因果候補':semantic.get('因果候補',[]),'反証':semantic.get('反証',[]),'因果確定':False,
      '未実行枝':copy.deepcopy(adoption['rejection_refs']),'適用範囲':semantic['適用範囲'],
      '由来':{'主体':'現在agent','状態版':adoption['hds_state_version'],'全候補':adoption['candidate_set_ref'],
       '実支持':adoption['support_refs'],'最終採否':adoption['final_adoption_ref'],'作用前intent':intent_ref,
       '意味再投影参照':semantic['由来参照']},'継続可能':result.get('status')=='recorded' and not holds and not a.get('failure_observed',True) and a.get('state_after')=='NOT_FINISHED',
      '再観測再照会が必要':True,'追加学習':False,'成功認定':False}
