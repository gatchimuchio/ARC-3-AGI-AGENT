"""列の目標要求と作業効果の純比較。HDS照会/原票IO/作用/方針採用なし。
入力は検証済みLS全相と、別native段階が保存したbefore限定全照会。
候補未成立は固定全単射文法の限界。修復不能・正解policyへ昇格しない。
"""
from copy import deepcopy
import traceback

def 同型(a,b):
    if type(a) is not type(b): return False
    if isinstance(a,dict):
        return len(a)==len(b) and all(同型(k,l) and 同型(a[k],b[l]) for k,l in zip(a,b))
    if isinstance(a,(list,tuple)): return len(a)==len(b) and all(同型(x,y) for x,y in zip(a,b))
    return a==b

def 失敗(e):
    return {'型':type(e).__name__,'引数':e.args,'全文':traceback.format_exc()}

def 構造(s):
    return {'背景色':s['背景色'],'目標列':s['目標列'],'容器群':[
      {'色':b['色'],'位置':b['位置'],'起点':b['起点'],'枠位置':[x['位置'] for x in b['枠群']]}
      for b in s['容器群']]}

def 枠(s):
    pairs=[(tuple(x['位置']),x['記号']) for b in s['容器群'] for x in b['枠群']]
    if len({k for k,v in pairs})!=len(pairs): raise ValueError('枠位置重複')
    return dict(pairs)

def 完了数(row):
    # 道具/列図式教師検証.py 完了数と同じ旧新alias契約。元metadataは別途全保持。
    if 'score'in row and 'levels_completed'in row and row['score']!=row['levels_completed']:
        raise ValueError('公開level新旧項目の矛盾')
    v=row.get('levels_completed',row.get('score'))
    if type(v)is not int or v<0: raise ValueError('公開完了数欠損/不正')
    return v

def 厳密進捗(a,b):
    x,y=完了数(a),完了数(b)
    return y>x if y>=x else None

def 境界(a,b):
    identity=all(type(a.get(k))is str and a[k] and a[k]==b.get(k) for k in ('guid','game_id'))
    reset=type(b.get('full_reset'))is bool and b['full_reset'] is False
    x,y=完了数(a),完了数(b)
    levels=y>=x
    return {'同一公開実行':identity,'RESET非該当明示':reset,'完了数比較可能':levels,
      '正規化完了数':[x,y],
      '旧問題継続確認':identity and reset and levels and x==y,
      '公開進捗あり':厳密進捗(a,b) if identity and reset else None}

def 目標照会を検査(capture,phase):
    if capture is None: return None,None,'before照会未提供'
    # 実FileRefの読戻し/pin/状態closureは後続caller責務。ここで真正性を捏造しない。
    if capture['前相画素SHA256']!=phase['frame_sha256_uint8']: raise ValueError('照会前相不一致')
    if not capture['実照会参照'] or not capture['役割支持参照']: raise ValueError('実照会/支持参照欠損')
    records=capture['学習役割'];roles={}
    for r in records:
        k=r['記号は中空'];v=r['列展開役割']
        if type(k)is not bool or k in roles or v not in ('参照','出力'): raise ValueError('学習役割型/重複')
        roles[k]=v
    if len(roles)!=2: raise ValueError('両外形の実学習役割不足')
    result=capture['全内容候補返却']
    pool=result.get('候補',[])
    if type(pool)is not list: raise ValueError('全候補形式')
    if '候補数'in result and result['候補数']!=len(pool): raise ValueError('候補数不一致')
    return pool,roles,('一意' if len(pool)==1 else '当該生成文法で未成立' if not pool else '複数候補UNKNOWN')

def 候補前提(scene,selection,pool,action):
    current=枠(scene);out=[];data=action.get('data',{}) if isinstance(action,dict) else {}
    xy=(data.get('x'),data.get('y'))
    for i,p in enumerate(pool):
        desired=dict(current);assign=p['割当'];seen=set()
        for x in assign:
            k=tuple(x['位置'])
            if k not in current or current[k] is not None or k in seen: raise ValueError('全割当の対象範囲不整合')
            seen.add(k);desired[k]={'色':x['色'],'中空':x['中空']}
        if seen!={k for k,v in current.items() if v is None}: raise ValueError('全空欄割当欠損')
        target=[k for k in current if all(type(v)is int for v in xy) and k[0]-1<=xy[0]<k[0]+5 and k[1]-1<=xy[1]<k[1]+5]
        needs=[k for k,v in current.items() if not 同型(v,desired[k])]
        fits=None if selection is None else any(同型(selection['記号'],desired[k]) for k in needs)
        actualfit=None
        if selection is not None and len(target)==1:
            actualfit=target[0] in needs and 同型(selection['記号'],desired[target[0]])
        out.append({'候補番号':i,'元候補':deepcopy(p),'要求枠':list(desired.items()),
          '未充足枠':needs,'既充足枠':[k for k in current if k not in needs],
          '選択記号が未充足要求に適合':fits,'公開座標の枠候補':target,
          '実対象への選択記号適合':actualfit})
    return out

def 候補効果(pre,after,selection):
    actual=枠(after);desired=dict(pre['要求枠']);needs=pre['未充足枠'];kept=pre['既充足枠']
    if set(actual)!=set(desired): raise ValueError('前後枠対応欠損')
    repaired=[k for k in needs if 同型(actual[k],desired[k])]
    broken=[k for k in kept if not 同型(actual[k],desired[k])]
    remaining=[k for k in desired if not 同型(actual[k],desired[k])]
    return {'候補番号':pre['候補番号'],'修復枠':repaired,'破壊枠':broken,'残未充足枠':remaining,
      '不足が修復された':bool(repaired) if needs else None,
      '既充足が全て保持された':not broken if kept else None,
      '要求適合する選択状態':None if selection is None else any(同型(selection['記号'],desired[k]) for k in remaining),
      '選択知覚の範囲':'既存在庫外周のみ。充填に選択が必要という因果必要性は未証明',
      '空集合注記':{'不足対象なし':not needs,'保存対象なし':not kept}}

def 作用を比較する(before,after,event,capture=None,既存一致関数=None):
    """before/afterはLS rowsの全相包絡。元例外・全相・実測作業を保持。"""
    if after['row']!=before['row']+1 or event['row']!=after['row']: raise ValueError('隣接行不一致')
    r={'行':after['row'],'前行':before['row'],'全前相':deepcopy(before['phases']),
       '全後相':deepcopy(after['phases']),'原票行参照':[{k:q[k] for k in ('row','byte_offset','line_bytes','line_sha256')} for q in (before,after)],
       '公開前後metadata':[deepcopy(before['metadata']),deepcopy(after['metadata'])],
       '公開Action':deepcopy(event.get('action')),'既存全作用実測':deepcopy(event),
       '前提':{},'各相効果':[],'全目標照会':deepcopy(capture),'例外':[],
       '教師投入':False,'正解policy':None,'新独立支持':0}
    b=境界(before['metadata'],after['metadata']);r['境界']=b
    if not before['phases']:r['前提']['UNKNOWN']='before相欠損';return r
    phase=before['phases'][-1];scene=phase.get('scene');pool=roles=None;pre=[]
    try:
        pool,roles,status=目標照会を検査(capture,phase)
        r['前提']['目標pool状態']=status
        if scene is None:r['前提']['UNKNOWN']='before知覚不成立'
        else:
            r['前提'].update({'空欄数':sum(v is None for v in 枠(scene).values()),
              '現在選択':deepcopy(phase.get('selection')),'選択UNKNOWN':phase.get('selection_unknown'),
              '選択知覚の範囲':'既存在庫外周のみ。Noneは全選択なしを意味しない。既記入枠選択は未同定',
              '現在列一致':None,'現在列判定':None})
            if roles is not None:
                if 既存一致関数 is None: raise ValueError('固定pin既存一致関数が必要')
                match,detail=既存一致関数(deepcopy(scene),roles)
                r['前提']['現在列判定']=detail
                r['前提']['現在列一致']=None if detail.get('構造状態')=='HOLD' else match
            if pool is not None:
                pre=候補前提(scene,phase.get('selection'),pool,event.get('action'))
                r['前提']['全候補比較']=pre
                r['前提']['集約適合']=pre[0] if len(pre)==1 else None
    except (ValueError,TypeError,KeyError,IndexError) as e:r['例外'].append({'段階':'前提','実例外':失敗(e)})
    for p in after['phases']:
        item={'相':p['phase'],'相内構造一致':None,'旧scope効果確認':False,'全候補効果':[],'例外':[]}
        r['各相効果'].append(item)
        try:
            s=p.get('scene')
            if scene is None or s is None:item['UNKNOWN']='前後知覚不成立';continue
            same=同型(構造(scene),構造(s));item['相内構造一致']=same
            item['旧scope効果確認']=same and b['旧問題継続確認']
            if not item['旧scope効果確認']:
                item['UNKNOWN']='旧問題対応未確認。進捗はevent単位、各相へ受理ラベルを付けない';continue
            if pool is None:item['UNKNOWN']='目標照会未提供';continue
            for q in pre:item['全候補効果'].append(候補効果(q,s,p.get('selection')))
            item['集約効果']=item['全候補効果'][0] if len(pre)==1 else None
            if len(pre)!=1:item['UNKNOWN']='目標未成立/複数。全候補効果は保存するが一意化しない'
        except (ValueError,TypeError,KeyError,IndexError) as e:item['例外'].append(失敗(e))
    return r

def 全59作用(detail,captures=None,既存一致関数=None):
    """保存済み全相への純比較。公開原票の再parseもHDS呼出しも行わない。"""
    captures={} if captures is None else captures
    if any(type(k)is not int or not 1<=k<=59 for k in captures): raise ValueError('照会行範囲')
    rows={r['row']:r for r in detail['rows']};events={e['row']:e for e in detail['events']}
    if any(i not in rows for i in range(60)) or any(i not in events for i in range(1,60)): raise ValueError('全59作用の原資料欠損')
    result=[]
    for i in range(1,60):result.append(作用を比較する(rows[i-1],rows[i],events[i],captures.get(i),既存一致関数))
    return {'種別':'列目標作業教師候補観測-v1','原票':deepcopy(detail['raw_recording']),
      '作用群':result,'全行順':list(range(1,60)),'未処理suffix':[],
      'HDS呼出し':0,'正解policy教示':0,'支持独立性':'同一原票/作用内相は相関。新規支持加算なし'}
