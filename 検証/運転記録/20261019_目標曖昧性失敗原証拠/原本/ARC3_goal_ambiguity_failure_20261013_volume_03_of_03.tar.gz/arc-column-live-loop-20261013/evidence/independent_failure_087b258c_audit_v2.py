import resource
resource.setrlimit(resource.RLIMIT_AS,(512<<20,512<<20))
import sys,json,lzma,hashlib,base64,copy,dataclasses,signal,traceback
from pathlib import Path
B=Path('/workspace/scratch/a94ff513b3af');L=B/'arc-column-live-loop-20261013';N='087b258ca57e41ff82229797bd8035b4';D=L/'evidence'/N;F=L/'failure'/N
sys.path[:0]=[str(L/'source'),str(B/'arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2')]
import loop_guard_v3 as guard
from hds学習系統.永続化 import _符号化 as enc,_復号 as dec
def sha(b):return hashlib.sha256(b).hexdigest()
def js(b):return json.loads(b)
def same(a,b):
 if type(a)is not type(b):return False
 if type(a)is dict:return list(a)==list(b) and all(same(a[k],b[k]) for k in a)
 if type(a)in(list,tuple):return len(a)==len(b) and all(same(x,y) for x,y in zip(a,b))
 return a==b
inventory={}; refs={}; decoded_count=0
def read(p):
 p=Path(p);s=p.stat();b=p.read_bytes();assert (p.stat().st_dev,p.stat().st_ino,p.stat().st_size,p.stat().st_mtime_ns,p.stat().st_ctime_ns)==(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
 inventory[str(p)]={'path':str(p),'bytes':len(b),'sha256':sha(b)}
 return b
def exact(r):
 key=r['path']
 if 'sdk-runtime' in Path(key).parts:
  assert Path(key).stat().st_size==r['bytes'];return
 if key not in inventory:read(key)
 assert inventory[key]=={k:r[k] for k in ('path','bytes','sha256')}
 refs[key]=inventory[key]
def unzip(b):
 z=lzma.LZMADecompressor(memlimit=128<<20);raw=z.decompress(b,max_length=(16<<20)+1)
 assert z.eof and not z.unused_data and z.check==lzma.CHECK_CRC64 and len(raw)<=16<<20
 return raw
def typed(b):
 global decoded_count
 raw=unzip(b);tag=js(raw);v=dec(tag);assert same(enc(v),tag);decoded_count+=1
 return v,raw
def walk(x):
 if dataclasses.is_dataclass(x):
  for f in dataclasses.fields(x):walk(getattr(x,f.name))
 elif type(x)is dict:
  if {'path','bytes','sha256'}<=x.keys() and type(x['path'])is str:exact(x)
  if {'file','rawbytes','rawsha256'}<=x.keys():
   exact(x['file']);raw=unzip(Path(x['file']['path']).read_bytes());assert len(raw)==x['rawbytes'] and sha(raw)==x['rawsha256']
  for v in x.values():walk(v)
 elif type(x)in(list,tuple):
  for v in x:walk(v)
def public(v):
 if 'frames' not in v or 'model_json' not in v:return
 assert v['frame_count']==len(v['frames'])
 for i,f in enumerate(v['frames']):
  b=base64.b64decode(f['base64'],validate=True)
  assert f['ordinal']==i and len(b)==f['bytes'] and sha(b)==f['sha256']
  assert f['dtype']=='|i1' and f['shape']==[64,64] and len(b)==4096 and f['order']=='C'
def main():
 signal.signal(signal.SIGALRM,lambda *a:(_ for _ in ()).throw(TimeoutError('audit600')))
 signal.alarm(600);guard.guard('evidence',4<<20)
 tp=L/'evidence/actual_live_loop_tools_087b258c_v1.json';tools=js(read(tp))
 assert inventory[str(tp)]['sha256']=='a7724c9063a0971d1c5bb760ccbde878a4382c88929c4029391f99b7b9995571'
 assert tools['actual_exit']==1 and tools['status']=='failed_closed' and tools['launch']['session_id']==21424
 terminal=tools['polls'][-1];assert terminal['exit_code']==1
 notify=js(terminal['output'].splitlines()[0]);assert notify['status']=='failed_closed'
 mr=notify['failure_manifest'];exact(mr['file'])
 assert mr['file']['sha256']=='7e95610edeac6f86db7b5f74a8f26b6b1abf110af95aa06495467c49a5536ea4'
 manifest,raw=typed(Path(mr['file']['path']).read_bytes())
 assert len(raw)==mr['rawbytes']==10999059 and sha(raw)==mr['rawsha256']=='2ea89602f55517891ff7ff832ea49d2664ac9b6cf9dd7a35434d3673a63341b3'
 assert manifest['complete_recovery'] is True and manifest['recovery_errors']==[]
 assert manifest['nonce']==N and manifest['errors'][0]['type']=='ValueError'
 assert manifest['errors'][0]['args']==('unique complete goal required',)
 assert len(manifest['calls'])==2234 and len(manifest['states'])==93
 gate=js(read(L/'source'/('root_loop_release_'+N+'.json')))
 contract=js(read(gate['contract']['path']));exact(gate['contract'])
 for r in contract['source_pins']+contract['core_and_family_pins']:exact(r)
 assert gate['closed_baseline']['state']['sha256']=='00d4407485adfb5a00f8cd95135f0438839d43e8fd117c97c43cab3c9f5f1afc'
 intents={};replies={};steps=[];states=[];publics=[];opaque=[];query_meta={}
 for folder in (D,F):
  for p in sorted(folder.rglob('*')):
   if not p.is_file():continue
   if 'sdk-runtime' in p.parts:
    opaque.append({'path':str(p),'bytes':p.stat().st_size,'read':False});continue
   b=read(p);v=None
   if p.name.endswith('.typed.json.xz'):
    v,raw=typed(b)
    if '_query_' in p.name:
     if p.name.endswith('_intent.typed.json.xz'):intents[v['ordinal']]=p
     elif p.name.endswith('_reply.typed.json.xz'):replies[v['ordinal']]=p
    if p.name.endswith('_step_outcome.typed.json.xz'):steps.append((p,v))
   elif p.name.endswith('.standard.json'):
    tag=js(b);v=dec(tag);assert same(enc(v),tag);states.append(p)
   elif p.suffix=='.json':
    v=js(b);public(v)
    if type(v)is dict and 'frames'in v and 'model_json'in v:publics.append((p,v))
   if v is not None:walk(v)
 assert len(intents)==len(replies)==2234 and sorted(replies)==list(range(2234))
 assert len(steps)==90 and len(states)==93
 initial=dec(js(Path(next(p for p in states if p.name=='restored_before_current_queries.standard.json')).read_bytes()))
 assert initial['識別子状態']['照会']==initial['識別子状態']['学習判定']==2479
 sr=[]
 for p in states:
  v=dec(js(p.read_bytes()))
  n=v['識別子状態']['照会']-2479;expected=copy.deepcopy(initial)
  for k in ('照会','学習判定'):expected['識別子状態'][k]+=n
  assert same(enc(v),enc(expected))
  sr.append({'ref':inventory[str(p)],'native_queries':n,'counter':2479+n})
 for i in range(2234):
  ip=intents[i];rp=replies[i];a,_=typed(ip.read_bytes());b,_=typed(rp.read_bytes());link=manifest['calls'][i]
  assert link['ordinal']==i and link['frame']==b['frame']
  assert link['intent']['file']==inventory[str(ip)] and link['reply']['file']==inventory[str(rp)]
  for k in ('ordinal','frame','method','input','origin','before'):assert same(enc(a[k]),enc(b[k]))
  assert b['method']=='照会する' and b['capture']['raw'] and 'return'in b['capture']
  before=copy.deepcopy(b['before']);assert before['identifiers']['照会']==before['identifiers']['学習判定']==2479+i
  for k in ('照会','学習判定'):before['identifiers'][k]+=1
  assert same(before,b['after'])
  assert b['origin']['観測通番']==b['frame'] and b['origin']['live採否可能'] is True
  query_meta[i]={'frame':b['frame'],'origin':b['origin']}
 assert same(manifest['components']['all_replay_records'],manifest['calls'])
 # Reconstruct every complete replay individually with original dataclass/asdict transform.
 replay_sizes=[]
 for link in manifest['components']['all_replay_records']:
  record,_=typed(replies[link['ordinal']].read_bytes())
  record['input']=dataclasses.asdict(record['input'])
  record['capture']['return']=dataclasses.asdict(record['capture']['return'])
  record['reference']=copy.deepcopy(link)
  tagged=enc(record);assert same(enc(dec(tagged)),tagged)
  replay_sizes.append(len(json.dumps(tagged,ensure_ascii=False).encode()))
 assert manifest['components']['trajectory']==[inventory[str(p)] for p,_ in steps]
 assert manifest['states']==[r['ref'] for r in sr]
 last=None;ss=[]
 for j,(p,s) in enumerate(steps):
  assert int(p.name.split('_')[1])==j
  if last:assert s['before_state']==last['state'] and s['before_public']==last['step']['public_response']
  qs=[b for b in query_meta.values() if b['frame']==j]
  assert qs and all(q['origin']['公開観測参照']==s['before_public'] and q['origin']['復元状態参照']==s['before_state'] for q in qs)
  response=js(Path(s['step']['public_response']['path']).read_bytes());public(response);a=s['step']['analysis']
  assert a['response_phases']==len(response['frames']) and a['completed_after']==response['model_json']['levels_completed']
  ss.append({'ordinal':j,'outcome':inventory[str(p)],'status':s['status'],'queries':len(qs),'request_id':s['request_id'],'action':s['step']['action'],'phases':a['response_phases'],'levels_before':a['completed_before'],'levels_after':a['completed_after'],'before_public':s['before_public'],'response':s['step']['public_response'],'state':s['state'],'memory':s['memory'],'comparison':s['comparison']})
  last=s
 assert same(enc(manifest['last_step']),enc(last['step']))
 assert all(q['origin']['公開観測参照']==last['step']['public_response'] for q in query_meta.values() if q['frame']==90)
 assert len(list((D/'transport').glob('*.response.json')))==90
 assert not (D/'completion.json').exists()
 components=manifest['components'];decoded_components={}
 for key in ('trace','current_query','diagnostics','prepared'):
  r=components[key];v,_=typed(Path(r['file']['path']).read_bytes());decoded_components[key]=v
 assert same(enc(decoded_components['trace']),enc(manifest['errors']))
 assert decoded_components['current_query'] is None # all current queries returned; failure in pure projection
 assert manifest['pending_description'] is None
 diag=decoded_components['diagnostics']
 publicfail=js(Path(components['public']['path']).read_bytes());public(publicfail)
 lastpub=js(Path(last['step']['public_response']['path']).read_bytes())
 assert publicfail['nonce']==N and lastpub['nonce']==last['request_id']
 assert {k:v for k,v in publicfail.items() if k!='nonce'}=={k:v for k,v in lastpub.items() if k!='nonce'}
 assert publicfail['model_json']['levels_completed']==6 and publicfail['model_json']['state']=='NOT_FINISHED'
 assert components['normal_state']==sr[-1]['ref'] and sr[-1]['counter']==4713
 assert len(manifest['durable_refs_in_original_order'])==6266
 for r in manifest['components']['verified_all_references']:exact(r)
 assert len(manifest['components']['verified_all_references'])==16141
 scope=manifest['recovery_scope'];assert 'not_saved'in scope and 'unfinished' in scope['not_saved']
 report={'schema':'column-loop-failed-closed-independent-audit-v1','status':'OPERATIONAL_RECOVERY_VERIFIED_RUN_FAILED','nonce':N,'native_success':False,'actual_exit':1,'actual_tools':inventory[str(tp)],'manifest':mr,
 'verified':{'all_saved_packet_CRC_EOF_type_order':True,'all_nonopaque_FileRefs_and_manifest_order':True,'2234_intent_raw_external_reply_marker_pairs':True,'replay_reconstruction_all2234_type_order':True,'90_trajectory_public_state_origin_chains':True,'93_normal_states_only_two_counters2479_to4713':True,'failure_components_and_actual_exit_join':True},
 'counts':{'Actions':90,'native_queries':2234,'normal_states':93,'typed_packet_decode_checks':decoded_count,'response_phases':sum(x['phases'] for x in ss),'final_counter':4713,'durable_refs':len(manifest['durable_refs_in_original_order']),'verified_reference_occurrences':len(manifest['components']['verified_all_references']),'replay_reconstructed_rawbytes':sum(replay_sizes)},
 'steps':ss,'states':sr,'failure_normal_state':components['normal_state'],'failure_public':components['public'],'failure_diagnostics':components['diagnostics'],'unprocessed_suffix':manifest['unprocessed'],'recovery_scope':scope,'errors_original':manifest['errors'],
 'limitations':['Failed run despite six observed intermediate level increments; not game success.','Operational evidence reconstruction verified; original arbitrary heap and incomplete candidate traceback locals are unavailable after exit1.','Reconstructed replay uses exact saved reply plus fixed dataclass/asdict transform; no original live heap remains for a new direct heap comparison.','Opaque SDK files not opened; only their sizes checked against recorded refs.','This recovery audit verifies stored public frames, chain and components; no native/SDK rerun and no remeasurement of all candidate semantics.'],
 'diagnostics_saved':diag,'inventory':list(inventory.values()),'opaque_stat_only':opaque}
 signal.alarm(0);raw=(json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode();assert len(raw)<4<<20
 r=guard.save('evidence','independent_failure_087b258c_summary_v2.json',raw)
 print(json.dumps({'status':report['status'],'report':r,'counts':report['counts']},ensure_ascii=False),flush=True)
if __name__=='__main__':
 try:main()
 except BaseException:
  signal.alarm(0);raw=traceback.format_exc().encode();print(raw.decode(),flush=True)
  guard.save('failure','independent_failure_087b258c_audit_error_v2.txt',raw);raise
