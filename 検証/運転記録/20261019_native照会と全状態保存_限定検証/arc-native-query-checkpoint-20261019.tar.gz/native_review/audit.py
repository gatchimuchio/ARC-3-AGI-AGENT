import pathlib,json,hashlib,sys,copy,dataclasses,itertools,collections
R=pathlib.Path('/workspace/scratch/a94ff513b3af/arc-native-query-20261019'); O=pathlib.Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
pins=json.loads((R/'pins.json').read_text());checked=[]
for p in pins['files']:
 b=(R/p['local']).read_bytes();assert len(b)==p['bytes'] and sha(b)==p['sha256'];assert pathlib.Path(p['source']).read_bytes()==b;checked.append(p['local'])
for a,b in [('worker.py','worker_source.py'),('guard.py','guard_source.py'),('supervise.py','supervisor_source.py')]:assert (R/a).read_bytes()==(R/'query_retry02'/b).read_bytes()
sys.path[:0]=[str(R/'frozen/HDS/学習系統/v0.4.2'),str(R/'semantic')]
from hds学習系統.永続化 import _復号,_符号化
import family_rehost
def no_native(*args,**kwargs):raise AssertionError("No native construction or calls allowed")
grammar=family_rehost.構成する(no_native)
raw=(R/'state/after_all_queries.standard.json').read_bytes()
for d in ['profile','query','query_retry02']:assert (R/d/'normal_roundtrip.json').read_bytes()==raw
pre=_復号(json.loads(raw));post=_復号(json.loads((R/'query_retry02/poststate.json').read_bytes()));diff=[]
def compare(a,b,p=()):
 assert type(a) is type(b),(p,type(a),type(b))
 if dataclasses.is_dataclass(a):
  for f in dataclasses.fields(a):compare(getattr(a,f.name),getattr(b,f.name),p+(f.name,))
 elif isinstance(a,dict):
  assert len(a)==len(b)
  for (k,v),(l,w) in zip(a.items(),b.items()):assert type(k) is type(l) and k==l;compare(v,w,p+(k,))
 elif isinstance(a,(list,tuple)):
  assert len(a)==len(b)
  for i,(v,w) in enumerate(zip(a,b)):compare(v,w,p+(i,))
 elif a!=b:diff.append([p,a,b])
compare(pre,post);assert diff==[[('識別子状態','照会'),6647,6660],[('識別子状態','学習判定'),6647,6660]],diff
idx=json.loads((R/'query_retry02/evidence_index.json').read_text());data=(R/'query_retry02/evidence.bin').read_bytes();objects={};end=0
for x in idx:
 assert x['offset']==end and x['name'] not in objects;end+=x['bytes'];b=data[x['offset']:end];assert sha(b)==x['sha256'];assert json.loads((R/'query_retry02'/(x['name']+'.receipt.json')).read_text())==x
 v=_復号(json.loads(b));assert json.dumps(_符号化(v),ensure_ascii=False,separators=(',',':')).encode()==b;objects[x['name']]=v
assert end==251453 and not any(data[end:]);assert len(idx)==40
for i in range(1,14):compare(objects[f'{i:02}.input'],objects[f'{i:02}.input_after'])
assert len(diff)==2
result=objects['semantic_result'];scene=copy.deepcopy(result['場面']);roles=result['学習役割'];slots=[s for b in scene['容器群'] for s in b['枠群'] if s['記号'] is None];tokens=[s['記号'] for s in scene['在庫群']];rows=[];seen=set()
for perm in itertools.permutations(tokens):
 key=tuple((t['色'],t['中空']) for t in perm)
 if key in seen:continue
 seen.add(key)
 for s,t in zip(slots,perm):s['記号']=t
 match,detail=grammar.一致する(scene,roles)
 rows.append({'ordinal':len(rows),'assignment':[{'position':s['位置'],'color':t['色'],'hollow':t['中空']} for s,t in zip(slots,perm)],'match':match,'reason':None if match else detail.get('理由','目標列不一致'),'detail':detail})
assert len(rows)==24 and sum(x['match'] for x in rows)==result['全目標pool']['候補数']
accepted=[{'割当':[{'位置':a['position'],'色':a['color'],'中空':a['hollow']} for a in x['assignment']],'列生成':x['detail']} for x in rows if x['match']]
assert accepted==result['全目標pool']['候補']
failures=dict(collections.Counter(x['detail'].get('理由','目標列不一致') for x in rows if not x['match']));assert failures==result['全目標pool']['不採用理由集計']
(O/'reconstructed_assignments.json').write_text(json.dumps({'provenance':'Pure supplemental reconstruction from recorded native roles and scene using exact pinned grammar. Not an original runtime per-rejection trace. No native calls.','rows':rows},ensure_ascii=False,indent=2))
flags=[]
def walk(x):
 if isinstance(x,dict):
  for k,v in x.items():
   if k=='実行許可':flags.append(v)
   walk(v)
 elif isinstance(x,(tuple,list)):
  for v in x:walk(v)
walk(result);assert len(flags)==9 and all(x is False for x in flags)
assert sha((R/'profile/failure.reserve').read_bytes())=='b8afa926a7c59525eac86a9455517900da526099eaaf534c01bc1769f58cf67c'
assert sha((R/'query/failure.reserve').read_bytes())=='6b184161c8ccccd3f89779985fd507eccd11cf2e7dd1ea6a87e15c927767f640'
manifest=json.loads((R/'delivery_manifest.json').read_text())
for item in manifest['files']:
 b=(R/item['path']).read_bytes();assert len(b)==item['bytes'] and sha(b)==item['sha256']
old=json.loads((R/'final_gate_report.json').read_text())
for r in old.get('original_reserves',[]):assert sha((R/r['path']).read_bytes())==r['whole_sha256']
report={'checked_pins':checked,'source_snapshots_equal':True,'normal_roundtrips_exact_bytes':len(raw),'full_recursive_type_value_order_differences':diff,'evidence_records':len(idx),'evidence_bytes':end,'queries':13,'all_input_after_unchanged':True,'all_permission_flags_false':len(flags),'assignments_reconstructed':24,'accepted_assignments':sum(x['match'] for x in rows),'failures':failures,'original_reserves_hashes_match':True,'directory_bytes':sum(x.stat().st_size for x in R.rglob('*') if x.is_file()),'no_native_calls_in_review':True}
(O/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2))
