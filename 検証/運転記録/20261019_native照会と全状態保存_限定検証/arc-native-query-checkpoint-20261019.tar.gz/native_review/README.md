# Independent native Query/save review

## Verdict

BOUNDED PASS for the completed saved-diagnostic Query/save run, with a qualified full-record gate: the original runtime retained only rejection aggregates for 23 assignments. `reconstructed_assignments.json` now retains all 24 exact assignments, generated sequence/details, match status and rejection reason, independently reconstructed with the exact pinned family grammar and recorded native role answers. Its accepted assignment/details and rejection histogram equal the original result. This is retrospective deterministic evidence, not a claim of original per-rejection runtime capture. Future runs must capture every assignment/detail/HOLD inline without changing enumeration or pruning.

No native Query/Teach, SDK, Action, Git write, or modification to pilot artifacts occurred in this review. `audit.py` uses only source inspection, hashing, native codec decode/encode and pure family grammar evaluation.

## Independently established

- All 34 input/source/authority pins match both local copies and source bytes. The 12 frozen HDS Python modules are unchanged. Actual successful runner, guard and supervisor match their retained snapshots. Final delivery manifest hashes verify.
- All three native restore/save outputs equal the exact 5,355,957-byte source. Full recursive decoded comparison, including dataclass types, dict key order, sequence types/order and every ledger/history field, differs only at paired Query/judgement counters 6647→6660. Existing 183 observations, 16 principles and every history are identical.
- 40 contiguous exact native-codec records and individual receipts verify; 251,453 used evidence bytes, followed only by reserved zeros. All 13 input/output pairs are present and each post-input equals its pre-input. Nine nested execution-permission flags are false. Five structural action candidates retain their complete native query replies, including UNKNOWN submission behavior; four effect-supported candidates are not action permission.
- All 24 assignments are deterministically reconstructed: one accepted, 23 target-sequence mismatches, zero structural HOLDs for this packet. Full records are provided, not only aggregates.
- Supervisor exit 0, 1.7920 s wall, 88,452 KiB peak RSS; limits recorded as 512 MiB AS, 112 MiB aggregate, 120 s compute/120 s finalization, ≤31 Query calls. Actual execution entered 13. These are observed small-workload measurements, not Teach capacity guarantees.
- Initial contradictory 8 MiB per-file/16 MiB evidence allocation failure and subsequent 96 MiB aggregate admission failure remain. Initial profile/query failure-reserve whole hashes are unchanged, including nonzero status prefixes; no reuse. Corrected 112 MiB budget is separately recorded. Parent supplies remote main-start verification; this audit does not independently contact remote Git.

## Restrictions and future-launcher gaps

The inherited unsupported-role/UNKNOWN-goal cases remain diagnostic limitations. This packet does not establish behavior for all unsupported cases and does not authorize live action. No learning, transfer, additional solved level or ability gain is established.

Completed-run evidence passes, but this is not a blanket robust-launcher approval. Directory-size sampling is not a race-free hard quota. The 1 MiB metadata/log allocation is a planning allowance rather than an enforced combined cap. The emergency reserve contains supervisor status only; arbitrary failure recording still writes a fresh failure.json and does not use reserved space. Mid-route failure suffix uses the local `calls` variable, assigned only after route return, so it can incorrectly label the entire route unprocessed even though `native_calls_entered` is positive. These paths did not fail in the successful run. Before a larger/Teach run, make failure evidence, exact consumed-prefix/unprocessed-suffix and total allocation guarantees explicit and tested. Preserve every prior artifact.

## Precise next Teach admission

1. Choose one bounded existing goal-relative operation boundary and freeze a complete positive/negative/HOLD contrast set. Audit each row's exact public whole-before/whole-after witness join, action target/coordinates, roles/relations, goal, prerequisite, all visible/status/legal-action/level changes and exposed reward/success/failure; hidden deltas remain unknown where unobserved. Do not promote teacher assertions to necessary causality without contrast witnesses.
2. Freeze exact teacher count/bytes, native input objects, before/after Query inputs, applicable identity/surface variants and prior-success regressions. Keep identity/path/hash/replay metadata outside runtime routing features.
3. Separately admit measured/conservative native Teach state/evidence growth and complete failure/partial-save retention. The 112 MiB Query allowance and Query RSS are not Teach authorization or a growth bound. Resolve the future-launcher gaps and inline per-assignment capture first.
4. Use real frozen `処理する(外部入力)` on a separate owned descendant, recording every input, judgement/support/refutation/applicability and full state/principle delta, including negative learning/HOLD. Preserve all prior ledger/history prefixes and prove durable full-state save/readback. Run frozen same-condition before/after queries and regression evidence. Independent review closes the bounded Teach unit; no automatic SDK/Action transition.
