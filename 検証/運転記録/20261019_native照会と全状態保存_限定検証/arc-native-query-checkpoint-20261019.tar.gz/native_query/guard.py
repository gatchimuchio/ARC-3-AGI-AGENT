"""Single-owner detached native-codec callback; any exception latches outer HOLD."""
class OuterHOLD(BaseException):pass
class Guard:
 def __init__(self,machine,encode,decode,persist):
  self.machine=machine;self.encode=encode;self.decode=decode;self.persist=persist;self.owner=self;self.calls=0;self.busy=False;self.failed=False;self.bound=None
 def allow_frame(self,bound):
  if self.bound is not None or bound!=31:raise OuterHOLD('Unexpected frame query bound')
  self.bound=bound
 def 照会する(self,external):
  if self.failed or self.busy or self.bound is None or self.calls>=self.bound:self.failed=True;raise OuterHOLD('latched/reentry/budget')
  self.busy=True
  try:
   before=self.encode(external);self.persist(f'{self.calls+1:02d}.input',before)
   isolated=self.decode(before);self.calls+=1
   reply=self.machine.照会する(isolated)
   after=self.encode(isolated);output=self.encode(reply)
   self.persist(f'{self.calls:02d}.output',output)
   self.persist(f'{self.calls:02d}.input_after',after)
   if before!=after:raise OuterHOLD('native input mutation')
   return self.decode(output)
  except BaseException:
   self.failed=True;raise
  finally:self.busy=False
