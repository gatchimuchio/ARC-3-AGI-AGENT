import sys,os,json,pathlib,time,signal,hashlib,dataclasses,enum,traceback,resource
R=pathlib.Path(__file__).resolve().parent; mode=sys.argv[1]; O=R/mode
sys.path[:0]=[str(R/'frozen/HDS/学習系統/v0.4.2'),str(R/'semantic')]
start=time.monotonic(); calls=0;machine=None
class OuterHOLD(BaseException):pass
def timeout(*args):raise OuterHOLD('phase deadline')
signal.signal(signal.SIGALRM,timeout);signal.alarm(120)
def durable(name,b):
 p=O/name
 with p.open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
 fd=os.open(O,os.O_RDONLY);os.fsync(fd);os.close(fd)
 return {'file':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def js(x):return json.dumps(x,ensure_ascii=False,indent=2).encode()
def typed(a,b):
 assert type(a) is type(b),(type(a),type(b))
 if dataclasses.is_dataclass(a):
  for f in dataclasses.fields(a):typed(getattr(a,f.name),getattr(b,f.name))
 elif isinstance(a,dict):
  assert len(a)==len(b)
  for (k,v),(l,w) in zip(a.items(),b.items()):typed(k,l);typed(v,w)
 elif isinstance(a,(tuple,list)):
  assert len(a)==len(b)
  for v,w in zip(a,b):typed(v,w)
 else:assert a==b
try:
 for pin in json.loads((R/'pins.json').read_text())['files']:
  b=(R/pin['local']).read_bytes();assert len(b)==pin['bytes'] and hashlib.sha256(b).hexdigest()==pin['sha256']
 from hds学習系統 import HDS学習系統,外部入力
 from hds学習系統.永続化 import _符号化,_復号
 source=R/'state/after_all_queries.standard.json'; raw=source.read_bytes(); encoded=json.loads(raw); decoded=_復号(encoded)
 assert js(_符号化(decoded))==raw
 typed(decoded,_復号(_符号化(decoded)))
 durable('codec.json',js({'exact_encoded_bytes':True,'recursive_native_type_value_order':True,'state_bytes':len(raw),'counters':decoded['識別子状態']}))
 machine=HDS学習系統.読み込む(source)
 def save(name):
  p=O/name;assert not p.exists()
  resource.setrlimit(resource.RLIMIT_FSIZE,(8*1024**2,16*1024**2))
  try:machine.保存する(p)
  finally:resource.setrlimit(resource.RLIMIT_FSIZE,(16*1024**2,)*2)
  with p.open('rb') as f:b=f.read();os.fsync(f.fileno())
  fd=os.open(O,os.O_RDONLY);os.fsync(fd);os.close(fd)
  assert len(b)<=8*1024**2
  return b
 roundtrip=save('normal_roundtrip.json');assert roundtrip==raw
 typed(decoded,_復号(json.loads(roundtrip)))
 if mode=='profile':
  durable('result.json',js({'status':'PASS','native_query_calls':0,'normal_restore_save_exact_bytes':True,'recursive_type_order_equality':True,'elapsed':time.monotonic()-start,'rss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'ledger_counts':{k:len(v) for k,v in decoded['台帳'].items()},'principle_histories':len(decoded['原理履歴'])}))
 else:
  assert mode=='query_retry02' and json.loads((R/'profile/result.json').read_text())['status']=='PASS'
  import base64,importlib,copy
  from guard import Guard
  import semantic_route_rehost
  boundary=importlib.import_module('ARC3境界')
  packet=json.loads((R/'inputs/public.json').read_text());frames=[]
  assert packet['frame_count']==len(packet['frames'])==1
  for ordinal,fr in enumerate(packet['frames']):
   pixels=base64.b64decode(fr['base64'],validate=True)
   assert fr['ordinal']==ordinal and fr['dtype']=='|i1' and fr['shape']==[64,64] and fr['order']=='C' and fr['bytes']==len(pixels)==4096
   assert hashlib.sha256(pixels).hexdigest()==fr['sha256']
   frames.append([list(pixels[j:j+64]) for j in range(0,4096,64)])
  public=copy.deepcopy(packet['model_json']);public['frame']=frames
  observation=boundary.観測する(public,観測通番=0)
  assert len(observation.盤面列)==1 and observation.最新盤面==tuple(map(tuple,frames[-1]))
  family,candidate,semantic=semantic_route_rehost.構成する(外部入力)
  scene=family.図式を観測する(frames[-1]);assert len(scene['在庫群'])==4 and sum(len(x['枠群']) for x in scene['容器群'])==4
  durable('observation.json',js({'packet_sha256':hashlib.sha256((R/'inputs/public.json').read_bytes()).hexdigest(),'observation_sequence':0,'all_frames':dataclasses.asdict(observation),'terminal_phase':0,'authority':'saved diagnostic only','inventory':4,'slots':4,'assignment_bound':24,'query_upper_bound':31}))
  # Separately admitted codec/save profile established allocation feasibility, not future production capacity.
  # Fixed preallocated 16 MiB ledger reserves all exact inputs/outputs and final semantic result.
  evidence=O/'evidence.bin';fd=os.open(evidence,os.O_CREAT|os.O_EXCL|os.O_RDWR,0o600);os.posix_fallocate(fd,0,16*1024**2);os.fsync(fd)
  offset=0;index=[]
  def encode(x):return json.dumps(_符号化(x),ensure_ascii=False,separators=(',',':')).encode()
  def decode(b):return _復号(json.loads(b))
  def persist(name,b):
   global offset
   if offset+len(b)>16*1024**2:raise OuterHOLD('complete evidence exceeds reserved allocation')
   written=0
   while written<len(b):written+=os.pwrite(fd,b[written:],offset+written)
   os.fsync(fd);assert os.pread(fd,len(b),offset)==b
   receipt={'name':name,'offset':offset,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()};offset+=len(b);index.append(receipt)
   durable(name+'.receipt.json',js(receipt))
  view=Guard(machine,encode,decode,persist)
  # Guard contract probes use fixtures only; no native call or state mutation.
  class Dummy:
   n=0
   def 照会する(self,x):self.n+=1;return x
  d=Dummy();g=Guard(d,encode,decode,lambda n,b:(_ for _ in ()).throw(OSError('injected recorder error')));g.allow_frame(31)
  for _ in range(2):
   try:g.照会する(外部入力({'x':True},'fixture'))
   except BaseException:pass
  assert g.failed and d.n==0
  durable('admission.json',js({'no_query_profile_passed':True,'normal_restore_save_exact_bytes':True,'evidence_preallocated_bytes':16*1024**2,'failure_preallocated_bytes':16*1024**2,'directory_limit':112*1024**2,'per_state_limit':8*1024**2,'max_queries':31,'recorder_failure_no_follow_on_native_call':True,'allocation_policy':'complete allocation or outer HOLD, never truncate/prune','diagnostic_only':True}))
  remaining=max(1,int(120-time.monotonic()+start-json.loads((R/'profile/supervisor.json').read_text())['wall_seconds']));signal.alarm(remaining)
  result=semantic(family,candidate,frames[-1],list(observation.作用可能番号),view,lambda b,f:view.照会する(外部入力(f,b)),observation.状態)
  calls=view.calls
  assert not view.failed and result['実行許可'] is False
  persist('semantic_result',encode(result));durable('evidence_index.json',js(index));os.close(fd)
  signal.alarm(120)
  postraw=save('poststate.json');post=_復号(json.loads(postraw));expected=copy.deepcopy(decoded)
  for key in ('照会','学習判定'):expected['識別子状態'][key]+=calls
  typed(expected,post)
  assert js(_符号化(post))==postraw
  for pin in json.loads((R/'pins.json').read_text())['files']:
   assert hashlib.sha256((R/pin['local']).read_bytes()).hexdigest()==pin['sha256']
  durable('result.json',js({'status':'PASS','native_query_calls':calls,'full_native_type_value_order_state_equal_except_paired_counters':True,'normal_restore_save_exact_bytes':True,'pre_counters':decoded['識別子状態'],'post_counters':post['識別子状態'],'ledger_counts':{k:len(v) for k,v in post['台帳'].items()},'evidence_bytes_used':offset,'elapsed_seconds':time.monotonic()-start,'rss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'all_permission_flags_false':True,'goal_pool_status':result.get('全目標pool',{}).get('状態'),'assignment_count':result.get('全目標pool',{}).get('全数確認した相異なる割当数'),'native_learning':False,'live_action':False}))
except BaseException as e:
 signal.alarm(120)
 failure={'status':'HOLD','type':type(e).__name__,'args':repr(e.args),'traceback':traceback.format_exc(),'native_calls_entered':getattr(locals().get('view'), 'calls',calls),'unprocessed_suffix':'entire route' if calls==0 else 'remaining dynamic route; do not resume automatically'}
 durable('failure.json',js(failure))
 if machine is not None and getattr(locals().get('view'),'calls',0):
  try:save('failure_state.json')
  except BaseException as save_error:durable('failure_save_error.json',js({'type':type(save_error).__name__,'args':repr(save_error.args)}))
 print(failure['traceback'],file=sys.stderr);sys.exit(1)
finally:signal.alarm(0)
