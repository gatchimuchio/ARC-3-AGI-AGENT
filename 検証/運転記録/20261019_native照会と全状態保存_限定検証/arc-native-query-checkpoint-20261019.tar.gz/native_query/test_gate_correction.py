import os,sys,resource,json,subprocess,pathlib
from guard import Guard,OuterHOLD
R=pathlib.Path(__file__).resolve().parent
code='''import os,resource,json
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
resource.setrlimit(resource.RLIMIT_FSIZE,(16*1024**2,)*2)
f=os.memfd_create('pure-allocation-boundary');os.posix_fallocate(f,0,16*1024**2)
try:os.pwrite(f,b'x',16*1024**2)
except OSError as e:assert e.errno==27
else:raise AssertionError('16 MiB limit not enforced')
resource.setrlimit(resource.RLIMIT_FSIZE,(8*1024**2,16*1024**2))
g=os.memfd_create('state-boundary')
try:os.pwrite(g,b'x',8*1024**2)
except OSError as e:assert e.errno==27
else:raise AssertionError('8 MiB state limit not enforced')
print('PASS')'''
r=subprocess.run([sys.executable,'-B','-c',code],capture_output=True,text=True);assert r.returncode==0,(r.returncode,r.stderr)
enc=lambda x:json.dumps(x,ensure_ascii=False).encode();dec=json.loads
class Machine:
 def __init__(self,kind):self.n=0;self.kind=kind
 def 照会する(self,x):
  self.n+=1
  if self.kind=='mutation':x['x']=2
  if self.kind=='native_failure':raise ValueError('injected native failure')
  if self.kind=='reentry':self.g.照会する({'x':1})
  return x
results=[]
for kind in ('normal','mutation','native_failure','reentry','input_recorder_failure','output_recorder_failure'):
 m=Machine(kind);records=[]
 def persist(n,b):
  if kind=='input_recorder_failure' or (kind=='output_recorder_failure' and n.endswith('output')):raise OSError('injected')
  records.append([n,b.decode()])
 g=Guard(m,enc,dec,persist);m.g=g;g.allow_frame(31)
 try:reply=g.照会する({'x':1})
 except BaseException:assert kind!='normal'
 else:assert kind=='normal' and reply=={'x':1}
 if kind!='normal':
  count=m.n
  try:g.照会する({'x':1})
  except BaseException:pass
  else:raise AssertionError('failed latch did not stop next call')
  assert m.n==count and g.failed
 results.append({'kind':kind,'calls':m.n,'records':records,'pass':True})
(R/'correction_tests.json').write_text(json.dumps({'resource_child_returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'guard_tests':results},ensure_ascii=False,indent=2));print('PASS')
