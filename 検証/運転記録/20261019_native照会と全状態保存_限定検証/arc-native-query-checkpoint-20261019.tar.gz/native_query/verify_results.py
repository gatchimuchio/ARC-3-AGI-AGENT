import pathlib,sys,json,hashlib,collections,resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
R=pathlib.Path(__file__).resolve().parent;O=R/'query_retry02'
sys.path.insert(0,str(R/'frozen/HDS/学習系統/v0.4.2'))
from hds学習系統.永続化 import _復号,_符号化
index=json.loads((O/'evidence_index.json').read_text());data=(O/'evidence.bin').read_bytes();objects={}
for x in index:
 b=data[x['offset']:x['offset']+x['bytes']];assert hashlib.sha256(b).hexdigest()==x['sha256'];v=_復号(json.loads(b));assert json.dumps(_符号化(v),ensure_ascii=False,separators=(',',':')).encode()==b;objects[x['name']]=v
inputs=[v for k,v in objects.items() if k.endswith('.input')];outputs=[v for k,v in objects.items() if k.endswith('.output')];assert len(inputs)==len(outputs)==13
result=objects['semantic_result'];flags=[]
def walk(x):
 if isinstance(x,dict):
  for k,v in x.items():
   if k=='実行許可':flags.append(v)
   walk(v)
 elif isinstance(x,(tuple,list)):
  for v in x:walk(v)
walk(result);assert flags and all(x is False for x in flags)
pre=json.loads((R/'state/after_all_queries.standard.json').read_text());post=json.loads((O/'poststate.json').read_text());diff=[]
def compare(a,b,p=()):
 if type(a)!=type(b):diff.append([p,a,b]);return
 if isinstance(a,dict):
  assert list(a)==list(b)
  for k in a:compare(a[k],b[k],p+(k,))
 elif isinstance(a,list):
  assert len(a)==len(b)
  for i,(v,w) in enumerate(zip(a,b)):compare(v,w,p+(i,))
 elif a!=b:diff.append([p,a,b])
compare(pre,post);assert len(diff)==2 and all(a==6647 and b==6660 for p,a,b in diff)
ca=result['全作用候補'];summary={'status':'PASS','codec_readback_all_records':len(index),'native_inputs':len(inputs),'native_outputs':len(outputs),'query_boundaries':dict(collections.Counter(x.対象系境界 for x in inputs)),'reply_states':dict(collections.Counter(x.状態 for x in outputs)),'execution_flags_checked':len(flags),'all_flags_false':True,'exact_serialized_state_deltas':diff,'whole_candidate_result_keys':list(ca),'goal_pool_status':result['全目標pool']['状態'],'all_assignments_examined':result['全目標pool']['全数確認した相異なる割当数'],'candidate_summary':[{k:v for k,v in c.items() if k in ('区分','効果状態','理由','実行許可','保存')} for c in ca.get('候補',ca.get('全候補',[]))]}
(R/'trace_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));print(json.dumps(summary,ensure_ascii=False,indent=2))
