import sys,os,json,pathlib,time,signal,hashlib,dataclasses,enum,traceback,resource
R=pathlib.Path(__file__).resolve().parent; mode=sys.argv[1]; O=R/mode
sys.path[:0]=[str(R/'frozen/HDS/学習系統/v0.4.2'),str(R/'semantic')]
start=time.monotonic(); calls=0;machine=None
class OuterHOLD(BaseException):pass
def timeout(*args):raise OuterHOLD('phase deadline')
signal.signal(signal.SIGALRM,timeout);signal.alarm(120)
def durable(name,b):
 p=O/name
 with p.open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
 fd=os.open(O,os.O_RDONLY);os.fsync(fd);os.close(fd)
 return {'file':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def js(x):return json.dumps(x,ensure_ascii=False,indent=2).encode()
def typed(a,b):
 assert type(a) is type(b),(type(a),type(b))
 if dataclasses.is_dataclass(a):
  for f in dataclasses.fields(a):typed(getattr(a,f.name),getattr(b,f.name))
 elif isinstance(a,dict):
  assert len(a)==len(b)
  for (k,v),(l,w) in zip(a.items(),b.items()):typed(k,l);typed(v,w)
 elif isinstance(a,(tuple,list)):
  assert len(a)==len(b)
  for v,w in zip(a,b):typed(v,w)
 else:assert a==b
try:
 for pin in json.loads((R/'pins.json').read_text())['files']:
  b=(R/pin['local']).read_bytes();assert len(b)==pin['bytes'] and hashlib.sha256(b).hexdigest()==pin['sha256']
 from hds学習系統 import HDS学習系統,外部入力
 from hds学習系統.永続化 import _符号化,_復号
 source=R/'state/after_all_queries.standard.json'; raw=source.read_bytes(); encoded=json.loads(raw); decoded=_復号(encoded)
 assert js(_符号化(decoded))==raw
 typed(decoded,_復号(_符号化(decoded)))
 durable('codec.json',js({'exact_encoded_bytes':True,'recursive_native_type_value_order':True,'state_bytes':len(raw),'counters':decoded['識別子状態']}))
 machine=HDS学習系統.読み込む(source)
 def save(name):
  p=O/name;assert not p.exists();machine.保存する(p)
  with p.open('rb') as f:b=f.read();os.fsync(f.fileno())
  fd=os.open(O,os.O_RDONLY);os.fsync(fd);os.close(fd)
  assert len(b)<=8*1024**2
  return b
 roundtrip=save('normal_roundtrip.json');assert roundtrip==raw
 typed(decoded,_復号(json.loads(roundtrip)))
 if mode=='profile':
  durable('result.json',js({'status':'PASS','native_query_calls':0,'normal_restore_save_exact_bytes':True,'recursive_type_order_equality':True,'elapsed':time.monotonic()-start,'rss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'ledger_counts':{k:len(v) for k,v in decoded['台帳'].items()},'principle_histories':len(decoded['原理履歴'])}))
 else:raise OuterHOLD('Query implementation not admitted yet')
except BaseException as e:
 signal.alarm(120)
 failure={'status':'HOLD','type':type(e).__name__,'args':repr(e.args),'traceback':traceback.format_exc(),'native_calls_entered':calls,'unprocessed_suffix':'entire route' if calls==0 else 'remaining dynamic route; do not resume automatically'}
 durable('failure.json',js(failure));print(failure['traceback'],file=sys.stderr);sys.exit(1)
finally:signal.alarm(0)
