import pathlib,json,hashlib,ast,shutil,sys,os
R=pathlib.Path(__file__).resolve().parent; W=R.parent; B=W/'arc-offline-restart-20261019/extracted/arc-restart-baseline-20261016'; S=W/'arc-semantic-rehost-20261019'
records=[]
def cp(p,q,expected=None):
 b=p.read_bytes();h=hashlib.sha256(b).hexdigest()
 if expected:assert len(b)==expected['bytes'] and h==expected['sha256']
 q=R/q;q.parent.mkdir(parents=True,exist_ok=True)
 with q.open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
 records.append({'source':str(p),'local':str(q.relative_to(R)),'bytes':len(b),'sha256':h,'original_pin':expected})
for x in json.loads((B/'pins.json').read_text())['files']:
 if x['destination'].startswith(('frozen/','state/')):cp(B/x['destination'],pathlib.Path(x['destination']),x)
for p in sorted((S/'source').glob('*.py')):cp(p,pathlib.Path('semantic')/p.name)
for name in ['origin_manifest.json','delivery_manifest.json','native_pilot_gate.md','README.md']:cp(S/name,pathlib.Path('provenance')/name)
cp(S/'origins/ARC3境界.py',pathlib.Path('semantic/ARC3境界.py'))
cp(S/'reports/public02/selected_whole_public.json',pathlib.Path('inputs/public.json'),{'bytes':6627,'sha256':'ce4c2950ac1d3fd1abbd67bb84196397777d080f2f0c6258245be8241b25cdab'})
imports=[]
for p in sorted((R/'frozen').rglob('*.py')):
 tree=ast.parse(p.read_text())
 for n in ast.walk(tree):
  if isinstance(n,(ast.Import,ast.ImportFrom)):
   names=[n.module or ''] if isinstance(n,ast.ImportFrom) else [a.name for a in n.names]
   for name in names:
    local=isinstance(n,ast.ImportFrom) and n.level>0
    assert local or name.split('.')[0] in sys.stdlib_module_names,name
    imports.append({'file':str(p.relative_to(R)),'module':name,'relative':local})
assert len(list((R/'frozen').rglob('*.py')))==12
for p in (W/'arc-preservation-recovery-20261019/authority').glob('*'):cp(p,pathlib.Path('authority')/p.name)
for name in ['AGENTS.md','運用/権限順序.md','制御/現在状態.json']:cp(W/'arc-preservation-recovery-20261019/main'/name,pathlib.Path('authority')/name)
(R/'pins.json').write_text(json.dumps({'main_at_start':'06961ee02d43329aee746d763cf19d651f97bcaa','main_verification':'sole writer independent remote readback; parent confirmed','files':records,'imports':imports},ensure_ascii=False,indent=2))
print(len(records),sum(x['bytes'] for x in records))
