"""Outer retained supervisor. No HDS imports. Hard AS/CPU/file ceilings, wall and directory checks."""
import os,sys,time,json,resource,subprocess,pathlib,signal
R=pathlib.Path(__file__).resolve().parent; mode=sys.argv[1]; out=R/mode;out.mkdir(exist_ok=False)
def durable(p,b):
 with p.open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
 fd=os.open(p.parent,os.O_RDONLY);os.fsync(fd);os.close(fd)
current=sum(x.stat().st_size for x in R.rglob('*') if x.is_file())
# Conservative remaining maximum: two 8 MiB states, 16 MiB evidence, 16 MiB failure reserve, 1 MiB all metadata/logs.
assert current+49*1024**2<=96*1024**2,(current,'insufficient full allocation budget')
assert mode!='query_retry01' or json.loads((R/'correction_tests.json').read_text())['resource_child_returncode']==0
reserve=out/'failure.reserve'
with reserve.open('xb') as f:os.posix_fallocate(f.fileno(),0,16*1024*1024);os.fsync(f.fileno())
# Preallocation is retained, including on success; no evidence file is deleted.
cpu_budget=120
if mode.startswith('query'):
 prior=json.loads((R/'profile/supervisor.json').read_text());assert prior['status']=='PASS'
 prior_failed=json.loads((R/'query/supervisor.json').read_text())
 prior['child_user_seconds']+=prior_failed['child_user_seconds'];prior['child_system_seconds']+=prior_failed['child_system_seconds']
 cpu_budget=120-__import__('math').ceil(prior['child_user_seconds']+prior['child_system_seconds'])
def limits():
 resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
 resource.setrlimit(resource.RLIMIT_CPU,(cpu_budget,cpu_budget))
 resource.setrlimit(resource.RLIMIT_FSIZE,(16*1024**2,)*2)
start=time.monotonic(); before=resource.getrusage(resource.RUSAGE_CHILDREN)
with (out/'stdout.log').open('xb') as so,(out/'stderr.log').open('xb') as se:
 p=subprocess.Popen([sys.executable,'-B',str(R/'worker.py'),mode],stdout=so,stderr=se,preexec_fn=limits,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},start_new_session=True)
 reason=None;peak=0
 while p.poll() is None:
  size=sum(x.stat().st_size for x in R.rglob('*') if x.is_file());peak=max(peak,size)
  if size>96*1024**2:reason='directory ceiling'
  if time.monotonic()-start>240:reason='compute plus finalization wall ceiling'
  if reason:os.killpg(p.pid,signal.SIGKILL);break
  time.sleep(.05)
 rc=p.wait();so.flush();se.flush();os.fsync(so.fileno());os.fsync(se.fileno())
after=resource.getrusage(resource.RUSAGE_CHILDREN)
report={'mode':mode,'returncode':rc,'outer_reason':reason,'wall_seconds':time.monotonic()-start,'child_user_seconds':after.ru_utime-before.ru_utime,'child_system_seconds':after.ru_stime-before.ru_stime,'peak_child_rss_KiB':after.ru_maxrss,'peak_directory_bytes_sampled':peak,'status':'PASS' if rc==0 and not reason else 'HOLD','AS_limit_bytes':512*1024**2,'directory_limit_bytes':96*1024**2,'compute_seconds_limit':120,'finalization_seconds_limit':120}
# Rewrite only the explicit preallocated failure/status reserve, preserving all worker artifacts.
b=json.dumps(report,ensure_ascii=False,indent=2).encode()
with reserve.open('r+b') as f:f.write(b);f.flush();os.fsync(f.fileno())
durable(out/'supervisor.json',b);print(b.decode());sys.exit(0 if report['status']=='PASS' else 1)
