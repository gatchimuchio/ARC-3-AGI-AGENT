# Missing pre-fix evidence disclosure

This additive audit does not change any completed repair, review, source, log or reserve. It does not claim complete original failure-history preservation.

## Search and result

The repair author inspected files in arc-native-guard-repair-20261019 and arc-native-guard-review-20261019, and searched permitted workspace/shared and /tmp paths for bounded_store/launcher names and backup/original/before/snapshot files. No exact pre-fix repair bounded_store.py or launcher.py was recovered. Denied session storage was not read. The original pilot guard is preserved as guard_before.py, but that file is NOT either missing repair source version. Later Teach copies differ and are descendants, not recovered originals.

The missing source versions were edited in place before separate snapshots were saved. Therefore no authenticated whole-file pre-fix digest, exact whole-file diff or bit-for-bit replay of those repair versions can be supplied. Current reviewed sources are authentic retained files; they cannot replace those missing versions.

## Defect 1: child/parent emergency overwrite

Original retained evidence:
- arc-native-guard-review-20261019/probes.py: the original probe source.
- arc-native-guard-review-20261019/probes.log: contains `fork first retained record: supervisor_terminal fallback overwritten: True`.
- arc-native-guard-review-20261019/fork_fallback/: original reserved files from that probe, including supervisor_failure.reserve.

Missing: exact pre-fix bounded_store.py and launcher.py used by that probe. The child fallback bytes overwritten by parent terminal were not recovered; their absence is itself the observed defect and must not be presented as retained failure content.

Reconstructed source-level delta, NOT an original patch or snapshot:
- Before: worker fallback and parent terminal both append to supervisor_failure; each process has its own inherited offset zero.
- After: worker_failure, worker_emergency and supervisor_failure are separate physical regions with exclusive process ownership. Child fallback cannot be overwritten by parent terminal.
- Current regression test_guard.Tests.test_fork_failure_and_parent_status_disjoint_on_disk verifies both surviving records directly from files.

This reconstruction is supported by the retained original probe/reserves/log, current code and the repair author's tool/message history. It is not a reconstructed source file advertised as original.

## Defect 2: encoding failure bypasses protected capture

Missing: exact pre-fix launcher.py and original output/reserves proving the initial diagnostic-encoding MemoryError execution. The audit found no encoding_failure directory and no corresponding initial output line in probes.log. probes.py contains the intended injection, but source code alone does not prove that stage executed.

Retained post-fix evidence only:
- adversarial_tests.py and adversarial_tests.log / adversarial_tests_final.log.
- encoding_failure_v2/ and encoding_failure_final/ reserves.
- Current launcher.py and test_guard.py.

These establish post-fix regression behavior, not a substitute for the absent original failure observation.

Reconstructed source-level delta, NOT an original patch or snapshot:
- Before: fallback = json_bytes(progress) was evaluated in the outer exception handler before its protected diagnostic try; an allocation/encoding exception could replace the original failure and bypass retention.
- After: a small UNKNOWN frame is prepared before operations; progress encoding is protected; failed full diagnostics use worker_emergency; a preframed raw one-shot fallback avoids JSON/traceback construction. Remaining allocation/kernel/filesystem failures are explicitly possible and preserve the original exception rather than claim impossible retention guarantees.
- Independent post-fix injection verifies that ValueError remains primary and a preencoded UNKNOWN record survives MemoryError in later diagnostic encoding.

This defect's initial mechanism is supported by author/reviewer source inspection and subsequent regression, with missing original runtime evidence explicitly unresolved.

## Other retained failure history

pure_tests_attempt04.log remains in the repair directory and records the admission-limit mismatch in test_no_reuse_old_run after stricter existing-byte accounting. No attempt log was deleted. Attempts 05–07 and later independent tests pass. Those logs do not authenticate the missing source snapshots.

## Integrity and reporting scope

observed_files.json gives paths, sizes and SHA-256 hashes of every repair/review file observed during this audit. It is a new audit manifest, not a replacement for the original reviewed manifest. No missing bytes were invented. Do not describe this packet as complete original failure history. The qualified statement is: retained original fork-failure evidence, retained original test-failure log, post-fix regressions, and an explicit gap for pre-fix source snapshots and initial encoding-failure output.
