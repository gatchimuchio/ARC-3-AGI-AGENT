import sys, pathlib, os, json, tempfile, struct, resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
sys.dont_write_bytecode=True
sys.path.insert(0,str(pathlib.Path('arc-native-guard-repair-20261019').resolve()))
from bounded_store import Store,json_bytes,HOLD
from launcher import run,supervise
base=pathlib.Path('arc-native-guard-review-20261019')
def first(path):
 with path.open('rb') as f:
  n=struct.unpack('>Q',f.read(8))[0];h=json.loads(f.read(n));return h,json.loads(f.read(h['bytes']))
s=Store(base/'fork_fallback',{k:8192 for k in Store.DEFAULT},total_limit=100000)
def worker():
 def route(*a): raise ValueError('x'*9000)
 run(s,None,json_bytes,json.loads,route,admitted=True)
r=supervise(s,worker)
h,p=first(s.root/'supervisor_failure.reserve')
print('fork first retained record:',h['name'],'fallback overwritten:',h['name']=='supervisor_terminal')
s.close()
import launcher
s=Store(base/'encoding_failure',{k:8192 for k in Store.DEFAULT},total_limit=100000)
original=launcher.json_bytes
calls=0
def fail_second(v):
 global calls
 calls+=1
 if calls>=2:raise MemoryError('injected diagnostic encoding exhaustion')
 return original(v)
launcher.json_bytes=fail_second
try:run(s,None,json_bytes,json.loads,lambda *a:(_ for _ in ()).throw(ValueError('original')),admitted=True)
except BaseException as e:print('encoding failure escaped:',type(e).__name__,'failure records:',len(s.records('worker_failure'))+len(s.records('supervisor_failure')))
s.close()
