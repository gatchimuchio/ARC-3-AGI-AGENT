import sys,pathlib,json,resource,unittest
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
sys.dont_write_bytecode=True
sys.path.insert(0,str(pathlib.Path('arc-native-guard-repair-20261019').resolve()))
from bounded_store import Store,json_bytes,HOLD
from guard import Guard
from launcher import run,supervise
import launcher
BASE=pathlib.Path('arc-native-guard-review-20261019')
class Review(unittest.TestCase):
 def store(self,name):
  return Store(BASE/name,{k:8192 for k in Store.DEFAULT},total_limit=96*1024**2)
 def test_encoding_failure_uses_preencoded_fallback(self):
  s=self.store('encoding_failure_final');original=launcher.json_bytes;calls=0
  def fail(v):
   nonlocal calls
   calls+=1
   if calls>=2:raise MemoryError('injected encoding exhaustion')
   return original(v)
  launcher.json_bytes=fail
  try:
   with self.assertRaises(ValueError):run(s,None,json_bytes,json.loads,lambda *a:(_ for _ in ()).throw(ValueError('original')),admitted=True)
   self.assertEqual(json.loads(s.records('worker_emergency')[0][1])['call_accounting'],'unknown; inspect retained inputs; never resume')
  finally:launcher.json_bytes=original;s.close()
 def test_after_return_record_failure_exact_and_latched(self):
  class Machine:
   calls=0
   def 照会する(self,x):self.calls+=1;return x
  m=Machine()
  def persist(n,b):
   if n.endswith('.output'):raise OSError('injected output storage failure')
  g=Guard(m,json_bytes,json.loads,persist);g.allow_frame(31)
  with self.assertRaises(OSError):g.照会する({})
  p=g.progress();self.assertEqual((p['native_calls_entered'],p['native_calls_returned'],p['fully_persisted_calls']),(1,1,0))
  with self.assertRaises(HOLD):g.照会する({})
  self.assertEqual(m.calls,1)
if __name__=='__main__':unittest.main(verbosity=2)
