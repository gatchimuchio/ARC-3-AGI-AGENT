import unittest,tempfile,pathlib,json,os,hashlib,signal
from bounded_store import Store,HOLD,NativeSaveSink,json_bytes
from guard import Guard
from launcher import run,supervise
CAPS={k:8192 for k in Store.DEFAULT}
def new(root,caps=None):return Store(pathlib.Path(root)/'run',caps or CAPS,total_limit=200000)
class Tests(unittest.TestCase):
 def test_reservation_rejects_before_materialization(self):
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d)/'run'
   with self.assertRaises(HOLD):Store(p,{'a':101},total_limit=100)
   self.assertFalse(p.exists())
 def test_cap_append_immutable_and_no_new_file(self):
  with tempfile.TemporaryDirectory() as d:
   s=new(d);s.append('evidence','one',b'x');before=(s.root/'evidence.reserve').read_bytes();files=list(s.root.iterdir())
   with self.assertRaises(HOLD):s.append('evidence','two',b'x'*8192)
   self.assertEqual(before,(s.root/'evidence.reserve').read_bytes());self.assertEqual(files,list(s.root.iterdir()))
   with self.assertRaises(HOLD):s.append('evidence','one',b'z')
   self.assertEqual(sum(p.stat().st_size for p in files),sum(CAPS.values()));s.close()
 def test_failure_counts_and_dedicated_reserve(self):
  class Machine:
   n=0
   def 照会する(self,x):
    self.n+=1
    if self.n==2:raise ValueError('fixture failure')
    return x
  with tempfile.TemporaryDirectory() as d:
   s=new(d);m=Machine()
   def route(g,observer):g.allow_frame(31);g.照会する({'a':1});g.照会する({'a':2})
   with self.assertRaises(ValueError):run(s,m,json_bytes,json.loads,route,admitted=True)
   r=json.loads(s.records('worker_failure')[0][1]);self.assertEqual((r['native_calls_entered'],r['native_calls_returned'],r['fully_persisted_calls']),(2,1,1));self.assertEqual(r['unprocessed_suffix']['first_unentered_ordinal'],3)
   self.assertFalse((s.root/'failure.json').exists());self.assertEqual(len(s.records('evidence')),4);s.close()
 def test_recorder_failure_before_entry_latches(self):
  class Machine:
   def 照会する(self,x):raise AssertionError('must not enter')
  g=Guard(Machine(),json_bytes,json.loads,lambda *a:(_ for _ in ()).throw(OSError('full')));g.allow_frame(31)
  with self.assertRaises(OSError):g.照会する({})
  self.assertEqual(g.calls,0)
  with self.assertRaises(HOLD):g.照会する({})
 def test_metadata_and_logs_combined_bound(self):
  from bounded_store import BoundedLog
  with tempfile.TemporaryDirectory() as d:
   s=new(d);before=len(s.records('metadata_logs'));l=BoundedLog(s,'stdout')
   with self.assertRaises(HOLD):l.write('x'*8192)
   self.assertEqual(before,len(s.records('metadata_logs')));s.close()
 def test_no_reuse_old_run(self):
  with tempfile.TemporaryDirectory() as d:
   s=new(d);s.close()
   with self.assertRaises(FileExistsError):new(d)
 def test_unbounded_writer_fail_closed(self):
  with tempfile.TemporaryDirectory() as d:
   s=new(d);calls=[]
   with self.assertRaises(HOLD):NativeSaveSink(s).save('normal_state',lambda p:calls.append(p),source_file=__file__,expected_sha256='bad')
   self.assertEqual(calls,[]);s.close()
 def test_diagnostic_oversize_fallback(self):
  with tempfile.TemporaryDirectory() as d:
   s=new(d)
   def route(*args):raise ValueError('x'*9000)
   with self.assertRaises(ValueError):run(s,None,json_bytes,json.loads,route,admitted=True)
   self.assertEqual(json.loads(s.records('worker_emergency')[0][1])['status'],'HOLD');s.close()
 def test_external_admission_required(self):
  with tempfile.TemporaryDirectory() as d:
   s=new(d)
   with self.assertRaises(HOLD):run(s,None,None,None,None)
   s.close()
 def test_supervisor_kill_unknown_not_zero(self):
  import time
  with tempfile.TemporaryDirectory() as d:
   s=new(d);report=supervise(s,lambda:time.sleep(2),wall_seconds=.03)
   self.assertEqual(report['status'],'HOLD');self.assertTrue(report['wall_killed']);self.assertIn('UNKNOWN',report['call_frontier']);s.close()
 def test_integrated_route_replays_13_and_retains_24(self):
  from test_trace import load_fixture_records,semantic_modules,ROOT,RECORDED,RecordingFixture,外部入力,fixture_bytes,decode_fixture
  from copy import deepcopy
  records,raw=load_fixture_records(); observation=json.loads((RECORDED/'observation.json').read_text())['all_frames']
  with tempfile.TemporaryDirectory() as d:
   caps=dict(CAPS);caps['evidence']=1024**2
   s=Store(pathlib.Path(d)/'run',caps,total_limit=2*1024**2)
   replay=RecordingFixture(records,raw)
   with semantic_modules(ROOT/'semantic') as semantic:
    def route(g,observer):
     family,candidate,entry=semantic.構成する(外部入力,observer=observer)
     return entry(family,candidate,deepcopy(observation['盤面列'][-1]),list(observation['作用可能番号']),g,lambda b,f:g.照会する(外部入力(f,b)),observation['状態'])
    result=run(s,replay,fixture_bytes,lambda b:decode_fixture(json.loads(b)),route,admitted=True)
   self.assertEqual(fixture_bytes(result),raw['semantic_result']);self.assertEqual(replay.calls,13)
   rows=[json.loads(b) for h,b in s.records('evidence') if h['name'].startswith('assignment.')]
   self.assertEqual(rows,json.loads((ROOT.parent/'arc-native-review-20261019/reconstructed_assignments.json').read_text())['rows']);s.close()
 def test_fork_failure_and_parent_status_disjoint_on_disk(self):
  import struct
  with tempfile.TemporaryDirectory() as d:
   s=new(d)
   def worker():
    def route(*args):raise ValueError('x'*9000)
    run(s,None,json_bytes,json.loads,route,admitted=True)
   report=supervise(s,worker)
   self.assertEqual(report['status'],'HOLD')
   def disk_record(region):
    fd=s.fds[region];n=struct.unpack('>Q',os.pread(fd,8,0))[0];h=json.loads(os.pread(fd,n,8));return h,json.loads(os.pread(fd,h['bytes'],8+n))
   h,f=disk_record('worker_emergency');self.assertEqual(h['name'],'failure_diagnostic_unavailable');self.assertEqual(f['native_calls_entered'],0)
   h,r=disk_record('supervisor_failure');self.assertEqual(h['name'],'supervisor_terminal');self.assertEqual(r['status'],'HOLD');s.close()
 def test_child_denies_unknown_path_writer(self):
  with tempfile.TemporaryDirectory() as d:
   s=new(d);p=s.root/'unbounded.bin'
   report=supervise(s,lambda:p.write_bytes(b'bad'))
   self.assertEqual(report['status'],'HOLD');self.assertFalse(p.exists());s.close()
if __name__=='__main__':unittest.main(verbosity=2)
