"""Pure observer regression. Fixture replay only; no HDS, SDK, Teach, or live action.

Run with: python -B arc-native-guard-repair-20261019/test_trace.py
This file creates no evidence, changes no original, and caps its own address space.
"""
from collections import Counter
from contextlib import contextmanager
from copy import deepcopy
from dataclasses import dataclass, field, fields, is_dataclass
import hashlib
import importlib
import importlib.abc
import json
from pathlib import Path
import resource
import sys
import unittest


ROOT = Path(__file__).resolve().parent
ORIGINAL = ROOT.parent / "arc-native-query-20261019"
RECORDED = ORIGINAL / "query_retry02"
REFERENCE = ROOT.parent / "arc-native-review-20261019/reconstructed_assignments.json"
MODULES = tuple(path.stem for path in (ORIGINAL / "semantic").glob("*.py"))


@dataclass
class 外部入力:
    """Fixture data record. This is not the native HDS class."""
    内容: object
    対象系境界: object
    主体: object = None
    対象: object = None
    目的: object = None
    文脈: object = field(default_factory=dict)


@dataclass
class 外部出力:
    """Fixture data record. This is not the native HDS class."""
    状態: object
    内容: object
    追跡情報: object


def decode_fixture(value):
    """Decode only the recorded fixture vocabulary, without native imports."""
    if isinstance(value, list):
        return [decode_fixture(item) for item in value]
    if isinstance(value, dict):
        if set(value) == {"__辞書__"}:
            return {decode_fixture(key): decode_fixture(item)
                    for key, item in value["__辞書__"]}
        if set(value) == {"__組__"}:
            return tuple(decode_fixture(item) for item in value["__組__"])
        if set(value) == {"__データ型__", "値"}:
            cls = {"外部入力": 外部入力, "外部出力": 外部出力}[value["__データ型__"]]
            return cls(**{key: decode_fixture(item) for key, item in value["値"].items()})
        raise AssertionError(f"Unexpected fixture encoding: {list(value)}")
    return value


def encode_fixture(value):
    if is_dataclass(value):
        return {"__データ型__": type(value).__name__,
                "値": {item.name: encode_fixture(getattr(value, item.name))
                       for item in fields(value)}}
    if isinstance(value, dict):
        return {"__辞書__": [[encode_fixture(key), encode_fixture(item)]
                            for key, item in value.items()]}
    if isinstance(value, tuple):
        return {"__組__": [encode_fixture(item) for item in value]}
    if isinstance(value, list):
        return [encode_fixture(item) for item in value]
    return value


def fixture_bytes(value):
    return json.dumps(encode_fixture(value), ensure_ascii=False,
                      separators=(",", ":")).encode()


def load_fixture_records():
    records, raw = {}, {}
    expected_offset = 0
    with (RECORDED / "evidence.bin").open("rb") as source:
        for item in json.loads((RECORDED / "evidence_index.json").read_text()):
            assert item["offset"] == expected_offset
            expected_offset += item["bytes"]
            source.seek(item["offset"])
            data = source.read(item["bytes"])
            assert hashlib.sha256(data).hexdigest() == item["sha256"]
            receipt = json.loads((RECORDED / (item["name"] + ".receipt.json")).read_text())
            assert receipt == item
            value = decode_fixture(json.loads(data))
            assert fixture_bytes(value) == data
            records[item["name"]] = value
            raw[item["name"]] = data
    assert expected_offset == 251453 and len(records) == 40
    return records, raw


class DenyNativeImports(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        root = fullname.split(".", 1)[0]
        if root.startswith(("hds", "arc_agi", "arcengine", "arcade")):
            raise AssertionError("Native or SDK import forbidden in fixture tests: " + fullname)
        return None


@contextmanager
def semantic_modules(directory):
    saved_modules = {name: sys.modules.get(name) for name in MODULES}
    saved_path = list(sys.path)
    saved_bytecode = sys.dont_write_bytecode
    blocker = DenyNativeImports()
    try:
        sys.dont_write_bytecode = True
        for name in MODULES:
            sys.modules.pop(name, None)
        sys.meta_path.insert(0, blocker)
        sys.path.insert(0, str(directory))
        yield importlib.import_module("semantic_route_rehost")
    finally:
        sys.path[:] = saved_path
        sys.dont_write_bytecode = saved_bytecode
        sys.meta_path.remove(blocker)
        for name, module in saved_modules.items():
            sys.modules.pop(name, None)
            if module is not None:
                sys.modules[name] = module


class RecordingFixture:
    """Checks exact recorded input and returns recorded reply, never calls HDS."""
    def __init__(self, records, raw):
        self.records, self.raw = records, raw
        self.calls, self.frame_bounds = 0, []
        self.owner = self

    def allow_frame(self, bound):
        self.frame_bounds.append(bound)

    def 照会する(self, external):
        self.calls += 1
        prefix = f"{self.calls:02}"
        assert fixture_bytes(external) == self.raw[prefix + ".input"]
        assert self.raw[prefix + ".input"] == self.raw[prefix + ".input_after"]
        return deepcopy(self.records[prefix + ".output"])


class TraceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.records, cls.raw = load_fixture_records()
        cls.expected_rows = json.loads(REFERENCE.read_text())["rows"]
        cls.saved_result = cls.records["semantic_result"]
        cls.observation = json.loads((RECORDED / "observation.json").read_text())["all_frames"]

    def run_family(self, route, *, scene=None, observer=None, original=False):
        kwargs = {} if original else {"observer": observer}
        family, _, _ = route.構成する(外部入力, **kwargs)
        if scene is None:
            scene = deepcopy(self.saved_result["場面"])
        replay = RecordingFixture(self.records, self.raw)
        result = family.内容候補を構成する(replay, scene)
        self.assertEqual(replay.calls, 4)
        return result, scene

    def run_route(self, directory, *, observer=None, original=False):
        with semantic_modules(directory) as route:
            kwargs = {} if original else {"observer": observer}
            family, candidate, entry = route.構成する(外部入力, **kwargs)
            replay = RecordingFixture(self.records, self.raw)
            result = entry(family, candidate, deepcopy(self.observation["盤面列"][-1]),
                           list(self.observation["作用可能番号"]), replay,
                           lambda boundary, facts: replay.照会する(外部入力(facts, boundary)),
                           self.observation["状態"])
        self.assertEqual(replay.calls, 13)
        self.assertEqual(replay.frame_bounds, [31])
        self.assertEqual(fixture_bytes(result), self.raw["semantic_result"])
        return result

    def test_original_sources_and_derivative_identity(self):
        changed = []
        pins = json.loads((ROOT / "semantic/source_hashes.json").read_text())["files"]
        self.assertEqual(len(pins), 8)
        for item in pins:
            original = (ORIGINAL / "semantic" / item["path"]).read_bytes()
            derivative = (ROOT / "semantic" / item["path"]).read_bytes()
            self.assertEqual(len(original), item["source_bytes"])
            self.assertEqual(hashlib.sha256(original).hexdigest(), item["source_sha256"])
            self.assertEqual(len(derivative), item["derivative_bytes"])
            self.assertEqual(hashlib.sha256(derivative).hexdigest(), item["derivative_sha256"])
            if original != derivative:
                changed.append(item["path"])
        self.assertEqual(changed, ["family_rehost.py", "semantic_route_rehost.py"])

    def test_all_24_rows_exact_and_inline(self):
        scene = deepcopy(self.saved_result["場面"])
        empty_slots = [slot for box in scene["容器群"] for slot in box["枠群"]
                       if slot["記号"] is None]
        rows = []

        def observe(row):
            self.assertEqual(row["ordinal"], len(rows))
            current = [{"position": slot["位置"], "color": slot["記号"]["色"],
                        "hollow": slot["記号"]["中空"]} for slot in empty_slots]
            self.assertEqual(row["assignment"], current)
            rows.append(row)

        with semantic_modules(ROOT / "semantic") as route:
            result, scene = self.run_family(route, scene=scene, observer=observe)
        self.assertEqual(rows, self.expected_rows)
        self.assertEqual(len(rows), 24)
        self.assertEqual(sum(row["match"] for row in rows), 1)
        self.assertEqual(fixture_bytes(result), fixture_bytes(self.saved_result["全目標pool"]))
        self.assertTrue(all(slot["記号"] is None for slot in empty_slots))
        reasons = Counter(row["reason"] for row in rows if not row["match"])
        self.assertEqual(dict(reasons), result["不採用理由集計"])

    def test_full_route_original_default_and_observed_exact(self):
        original = self.run_route(ORIGINAL / "semantic", original=True)
        default = self.run_route(ROOT / "semantic", original=True)
        disabled = self.run_route(ROOT / "semantic")
        rows = []
        observed = self.run_route(ROOT / "semantic", observer=rows.append)
        self.assertEqual(fixture_bytes(original), fixture_bytes(default))
        self.assertEqual(fixture_bytes(original), fixture_bytes(disabled))
        self.assertEqual(fixture_bytes(original), fixture_bytes(observed))
        self.assertEqual(rows, self.expected_rows)

    def test_observer_data_is_detached_and_return_value_ignored(self):
        rows = []

        def destructive_observer(row):
            rows.append(deepcopy(row))
            for assignment in row["assignment"]:
                assignment["position"][:] = [-1, -1]
                assignment["color"] = -1
            row["detail"].clear()
            row.clear()
            return False

        result = self.run_route(ROOT / "semantic", observer=destructive_observer)
        self.assertEqual(rows, self.expected_rows)
        self.assertEqual(fixture_bytes(result), self.raw["semantic_result"])

    def test_observer_failure_propagates_without_more_queries(self):
        class TraceFailure(Exception):
            pass

        rows = []

        def failed_observer(row):
            rows.append(row)
            if len(rows) == 7:
                raise TraceFailure("injected trace sink failure")

        with semantic_modules(ROOT / "semantic") as route:
            family, candidate, entry = route.構成する(外部入力, observer=failed_observer)
            replay = RecordingFixture(self.records, self.raw)
            with self.assertRaisesRegex(TraceFailure, "injected trace sink failure"):
                entry(family, candidate, deepcopy(self.observation["盤面列"][-1]),
                      list(self.observation["作用可能番号"]), replay,
                      lambda boundary, facts: replay.照会する(外部入力(facts, boundary)),
                      self.observation["状態"])
        self.assertEqual(replay.calls, 4)
        self.assertEqual(rows, self.expected_rows[:7])

    def test_duplicates_emit_only_unique_assignments(self):
        scene = deepcopy(self.saved_result["場面"])
        scene["在庫群"][1]["記号"] = deepcopy(scene["在庫群"][0]["記号"])
        with semantic_modules(ORIGINAL / "semantic") as route:
            original, _ = self.run_family(route, scene=deepcopy(scene), original=True)
        rows = []
        with semantic_modules(ROOT / "semantic") as route:
            observed, _ = self.run_family(route, scene=deepcopy(scene), observer=rows.append)
        self.assertEqual(fixture_bytes(original), fixture_bytes(observed))
        self.assertEqual(len(rows), 12)
        self.assertEqual([row["ordinal"] for row in rows], list(range(12)))
        self.assertEqual(len({json.dumps(row["assignment"]) for row in rows}), 12)

    def test_rejection_detail_is_emitted_in_full(self):
        scene = deepcopy(self.saved_result["場面"])
        scene["在庫群"][0]["記号"] = {"色": 1, "中空": True}
        self.assertNotIn(1, [box["色"] for box in scene["容器群"]])
        with semantic_modules(ORIGINAL / "semantic") as route:
            original, _ = self.run_family(route, scene=deepcopy(scene), original=True)
        rows = []
        with semantic_modules(ROOT / "semantic") as route:
            observed, _ = self.run_family(route, scene=deepcopy(scene), observer=rows.append)
        self.assertEqual(fixture_bytes(original), fixture_bytes(observed))
        self.assertEqual(len(rows), 24)
        for row in rows:
            self.assertFalse(row["match"])
            self.assertEqual(row["reason"], "参照先なし")
            self.assertEqual(row["detail"], {"構造状態": "HOLD", "理由": "参照先なし"})

    def test_no_native_modules_loaded_and_directory_budget(self):
        self.assertFalse(any(name.split(".", 1)[0].startswith(("hds", "arc_agi", "arcengine"))
                             for name in sys.modules))
        self.assertLessEqual(sum(path.stat().st_size for path in ROOT.rglob("*")
                                 if path.is_file()), 96 * 1024**2)


if __name__ == "__main__":
    sys.dont_write_bytecode = True
    resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
    unittest.main(verbosity=2)
