"""Detached, latched native boundary; exact entered/returned/persisted prefix."""
from bounded_store import HOLD, json_bytes
class Guard:
 def __init__(self,machine,encode,decode,persist):
  self.owner=self;self.machine=machine;self.encode=encode;self.decode=decode;self.persist=persist
  self.calls=0;self.returned=0;self.completed=0;self.busy=False;self.failed=False;self.bound=None;self.pending=None
 def allow_frame(self,bound):
  if self.bound is not None or bound!=31:raise HOLD('unexpected frame bound')
  self.bound=bound
 def progress(self):
  return {'native_calls_entered':self.calls,'native_calls_returned':self.returned,
          'fully_persisted_calls':self.completed,'incomplete_entered_ordinal':self.calls if self.completed<self.calls else None,
          'pending_preentry_ordinal':self.pending if self.pending and self.pending>self.calls else None,
          'unprocessed_suffix':{'first_unentered_ordinal':self.calls+1,'remaining_dynamic_count':'unknown until route enumeration',
                                'maximum_remaining_calls':None if self.bound is None else self.bound-self.calls},
          'automatic_resume':False}
 def 照会する(self,external):
  if self.failed or self.busy or self.bound is None or self.calls>=self.bound:self.failed=True;raise HOLD('latched/reentry/budget')
  self.busy=True; self.pending=self.calls+1
  try:
   before=self.encode(external);self.persist(f'{self.pending:02d}.input',before)
   isolated=self.decode(before)
   # Count at actual invocation boundary, not at semantic route return.
   self.calls+=1
   reply=self.machine.照会する(isolated);self.returned+=1
   after=self.encode(isolated);output=self.encode(reply)
   self.persist(f'{self.calls:02d}.output',output)
   self.persist(f'{self.calls:02d}.input_after',after)
   if before!=after:raise HOLD('native input mutation')
   result=self.decode(output);self.completed+=1;self.pending=None
   return result
  except BaseException:self.failed=True;raise
  finally:self.busy=False
