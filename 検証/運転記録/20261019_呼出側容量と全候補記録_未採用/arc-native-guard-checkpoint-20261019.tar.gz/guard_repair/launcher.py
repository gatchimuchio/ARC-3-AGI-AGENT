"""Minimal caller-side integration. Pure fixture-tested; no native launch CLI.
Use only reviewed bounded writers in a fresh single-owner process. A caller
must separately admit native count/state growth and public teacher witnesses.
"""
import contextlib,resource,signal
from bounded_store import Store, BoundedLog, HOLD, json_bytes
from guard import Guard

def run(store, machine, encode, decode, route, *, admitted=False, state_save=None):
    if not admitted: raise HOLD('external witness and growth admission required')
    guard=Guard(machine,encode,decode,lambda n,b:store.append('evidence',n,b))
    observer=lambda row:store.append('evidence','assignment.%08d'%row['ordinal'],json_bytes(row))
    # Emergency diagnostic already encoded BEFORE entering any operation.
    fallback=json_bytes({'status':'HOLD','failure':'diagnostic encoding failed','call_accounting':'unknown; inspect retained inputs; never resume'})
    emergency_frame=store.prepare_emergency(fallback)
    try:
        if state_save is not None: state_save("normal_state")
        with contextlib.redirect_stdout(BoundedLog(store,'stdout')),contextlib.redirect_stderr(BoundedLog(store,'stderr')):
            result=route(guard,observer)
        store.append('evidence','semantic_result',encode(result))
        if state_save is not None: state_save('post_state')
        store.append('metadata_logs','success',json_bytes({'status':'PASS',**guard.progress()}))
        return result
    except BaseException as error:
        guard.failed=True
        # Exact small frontier is encoded before potentially large error args.
        try: fallback=json_bytes({'status':'HOLD','failure':'diagnostic encoding failed',**guard.progress()})
        except BaseException: pass
        try:
            payload=json_bytes({'status':'HOLD','type':type(error).__name__,'args':repr(error.args),**guard.progress()})
            store.append('worker_failure','failure',payload)
        except BaseException:
            try: store.append('worker_emergency','failure_diagnostic_unavailable',fallback)
            except BaseException:
                try: store.raw_emergency(emergency_frame)
                except BaseException: pass  # Preserve primary exception; parent reports unknown.
        if state_save is not None and guard.calls:
            try: state_save('failure_state')
            except BaseException as secondary:
                try: store.append('worker_failure','failure_state_error',json_bytes({'type':type(secondary).__name__,**guard.progress()}))
                except BaseException: pass
        raise

def set_process_limits():
    resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
    resource.setrlimit(resource.RLIMIT_CPU,(120,120))
    # A hard file cap supplements reservations; it is not a directory quota.
    resource.setrlimit(resource.RLIMIT_FSIZE,(16*1024**2,)*2)

def supervise(store, worker, wall_seconds=240):
    """Own fixed-reservation child only; NOT arbitrary commands/SDK writers.
    SIGKILL cannot expose Python's exact call frontier. Report it unknown rather
    than falsely claim zero; retained input/output records bound the ambiguity.
    """
    import os,time
    pid=os.fork()
    if pid==0:
        try:
            set_process_limits()
            from bounded_store import install_known_write_boundary
            install_known_write_boundary()
            def deadline(*unused): raise HOLD('compute deadline')
            signal.signal(signal.SIGALRM,deadline);signal.alarm(120)
            worker()
            os._exit(0)
        except BaseException:
            os._exit(1)
    start=time.monotonic();killed=False
    while True:
        done,status=os.waitpid(pid,os.WNOHANG)
        if done: break
        if time.monotonic()-start>wall_seconds:
            os.kill(pid,signal.SIGKILL);_,status=os.waitpid(pid,0);killed=True;break
        time.sleep(.01)
    report={'status':'PASS' if status==0 else 'HOLD','wait_status':status,'wall_killed':killed,
            'call_frontier':'use exact worker failure record if present; otherwise UNKNOWN, never infer zero',
            'byte_enforcement':'fixed owned reservations for reviewed writers only; no OS aggregate quota'}
    store.append('supervisor_failure','supervisor_terminal',json_bytes(report))
    return report


def launch_native(store, machine, encode, decode, route, *, admission):
    """Binding ready for separately reviewed bounded admission; never auto-run.
    Frozen native API and native codec remain caller-provided and unchanged.
    """
    from bounded_store import NativeSaveSink
    from source_allowlist import PERSISTENCE_SHA256
    required=('public_witness_verified','state_growth_verified','full_failure_retention_verified','writer_inventory_verified')
    if any(admission.get(k) is not True for k in required): raise HOLD('incomplete external native admission')
    if admission.get('max_native_calls') != 31: raise HOLD('route count admission')
    sink=NativeSaveSink(store)
    def save(region):
        return sink.save(region,machine.保存する,source_file=admission['persistence_source'],expected_sha256=PERSISTENCE_SHA256)
    return supervise(store,lambda:run(store,machine,encode,decode,route,admitted=True,state_save=save))
