"""未採用・明示依存注入派生。全列挙・採否を保持し任意の観測口を追加。"""
from collections import Counter
from copy import deepcopy
import itertools
from types import SimpleNamespace

def 構成する(外部入力, *, observer=None):

    役割境界='公開列図式:記号外形と展開役割'

    目標境界='公開列図式:有限全列または生産的反復の目標長一致と提出受理'

    作用境界='公開列図式:観測された解答作業と行動ID'

    構造境界='公開列図式:枠付き順序スロット・在庫記号・目標列'

    class 知覚不適用(ValueError):
        pass

    適用前提=['4画素記号・6画素枠間隔・10画素容器の固定知覚仮説',
              '同色容器参照・標識付き起点・行順目標列の固定仮説',
              '有限全列/生産的反復前置列という固定操作語彙',
              'HDSが記号役割・受理関係・作業行動IDを支持しHOLDしない']

    def 記号を読む(f,x,y,bg):
     a=[r[x:x+4] for r in f[y:y+4]]
     if len(a)!=4 or any(len(r)!=4 for r in a):raise ValueError('記号寸法不成立')
     flat=[v for r in a for v in r];rim=[a[dy][dx] for dy in range(4) for dx in range(4) if dy in (0,3) or dx in (0,3)];center=[a[dy][dx] for dy in (1,2) for dx in (1,2)]
     if len(set(flat))==1 and flat[0]!=bg:return {'色':flat[0],'中空':False}
     if len(set(rim))==1 and rim[0]!=bg and set(center)=={bg}:return {'色':rim[0],'中空':True}
     if set(rim)=={bg} and len(set(center))==1:return None
     raise ValueError('記号文法不成立')

    def 容器外形を観測する(frame,bg):
     h=len(frame);w=len(frame[0])
     boxes=[]
     for y in range(h-9):
      x=0
      while x<w:
       c=frame[y][x];end=x+1
       while end<w and frame[y][end]==c:end+=1
       n=end-x
       if c!=bg and n>=16 and (n-4)%6==0 and all(frame[yy][x]==c and frame[yy][end-1]==c for yy in range(y,y+10)):
        brackets=[frame[y-1][x-1] if x and y else bg,frame[y-1][end] if end<w and y else bg,frame[y+10][x-1] if x and y+10<h else bg,frame[y+10][end] if end<w and y+10<h else bg]
        selected=len(set(brackets))==1 and brackets[0] not in (bg,c)
        slots=[]
        for j in range((n-4)//6):
         xx=x+3+6*j;yy=y+3
         slots.append({'位置':[xx,yy],'記号':None})
        boxes.append({'色':c,'位置':[x,y],'起点':selected,'枠群':slots})
       x=end
     return boxes

    def 図式を観測する(frame):
     if not frame or not frame[0] or any(len(r)!=len(frame[0]) for r in frame):raise ValueError('空または非矩形盤面')
     h=len(frame);w=len(frame[0]);counts=Counter(v for r in frame for v in r).most_common()
     if len(counts)>1 and counts[0][1]==counts[1][1]:raise ValueError('背景候補同数で未確定')
     bg=counts[0][0]
     boxes=容器外形を観測する(frame,bg)
     if not boxes:raise 知覚不適用('固定文法の枠付き容器が観測できない')
     if not any(b['起点'] for b in boxes):raise 知覚不適用('固定文法に必須の四隅標識付き起点が存在しない')
     for b in boxes:
      for slot in b['枠群']:
       slot['記号']=記号を読む(frame,*slot['位置'],bg)
     if sum(b['起点'] for b in boxes)!=1:raise ValueError('標識付き起点/容器を一意に確認できない')
     if len({b['色'] for b in boxes})!=len(boxes):raise ValueError('同色容器の参照先が複数')
     top=min(b['位置'][1] for b in boxes);bottom=max(b['位置'][1]+10 for b in boxes)
     target=[]
     for y in range(top-5):
      for x in range(w-5):
       c=frame[y][x]
       if c==bg:continue
       rim=[frame[y+dy][x+dx] for dy in range(6) for dx in range(6) if dy in (0,5) or dx in (0,5)]
       inside={frame[y+dy][x+dx] for dy in range(1,5) for dx in range(1,5)}
       if len(set(rim))==1 and len(inside)==1 and c not in inside:target.append((y,x,c))
     if not target:raise 知覚不適用('固定文法の目標記号行がない')
     target_rows=sorted({y for y,x,c in target})
     if any(b-a!=7 for a,b in zip(target_rows,target_rows[1:])):raise ValueError('目標行間隔が不明')
     inventory=[]
     for y in range(bottom,h-3):
      for x in range(w-3):
       try:t=記号を読む(frame,x,y,bg)
       except ValueError:continue
       if t is not None:inventory.append({'位置':[x,y],'記号':t})
     # all 4x4 tokens are disjoint; ambiguous overlapping instances reject
     for i,a in enumerate(inventory):
      for b in inventory[i+1:]:
       if abs(a['位置'][0]-b['位置'][0])<4 and abs(a['位置'][1]-b['位置'][1])<4:raise ValueError('在庫記号の解釈領域が重複')
     return {'背景色':bg,'目標列':[c for y,x,c in sorted(target)],'容器群':boxes,'在庫群':inventory}

    def 列を生成する(scene,役割,長さ):
     boxes={b['色']:b for b in scene['容器群']};root=next(b for b in scene['容器群'] if b['起点']);out=[];active=set();repeated=False;ancestors=[]
     # Shape validity is checked before interpreting, including unreachable slots.
     for b in scene['容器群']:
      for s in b['枠群']:
       if s['記号'] is None:raise ValueError('未記入スロット')
       if 役割[s['記号']['中空']]=='参照' and s['記号']['色'] not in boxes:raise ValueError('参照先なし')
     def cycle(b,stack):
      if b['色'] in stack:return True
      return any(cycle(boxes[s['記号']['色']],stack+(b['色'],)) for s in b['枠群'] if 役割[s['記号']['中空']]=='参照')
     cyclic=cycle(root,())
     def finite(b):
      result=[]
      for s in b['枠群']:
       t=s['記号']
       result.extend([t['色']] if 役割[t['中空']]=='出力' else finite(boxes[t['色']]))
      return result
     if not cyclic:
      full=finite(root)
      return {'出力列':full,'目標長到達':len(full)==長さ,'生産的再入観測':False,'展開構造':'有限終端','比較範囲':'全出力列','過剰出力数':max(0,len(full)-長さ)}
     def visit(b):
      nonlocal repeated
      key=(b['色'],len(out))
      if key in active:raise ValueError('非生産的循環:同じ参照先へ出力増加なしで再入')
      if b['色'] in ancestors:repeated=True
      active.add(key);ancestors.append(b['色'])
      for s in b['枠群']:
       if len(out)>=長さ:break
       t=s['記号'];op=役割[t['中空']]
       if op=='出力':out.append(t['色'])
       elif op=='参照':visit(boxes[t['色']])
       else:raise ValueError('未知の役割')
      ancestors.pop();active.remove(key)
     visit(root)
     if not repeated:raise ValueError('循環候補だが目標長までに生産的再入未確認:判定範囲外')
     return {'出力列':out,'目標長到達':len(out)==長さ,'生産的再入観測':repeated,'展開構造':'生産的反復','比較範囲':'目標長前置列'}

    def 一致する(scene,roles):
     try:
      r=列を生成する(scene,roles,len(scene['目標列']));return r['出力列']==scene['目標列'],r
     except ValueError as e:return False,{'構造状態':'HOLD','理由':str(e)}

    def 照会(h,boundary,facts,key):
     r=h.照会する(外部入力(facts,boundary));p=[q for q in r.内容.get('予測群',[]) if tuple(q['結果経路'])==(key,)];values={q['予測値'] for q in p}
     return (next(iter(values)) if r.状態!='断定保留' and len(values)==1 else None),{'状態':r.状態,'予測':p,'保留理由':r.内容.get('断定保留理由群',[])}

    def 内容候補を構成する(h,scene):
     roles={};queries={}
     for hollow in (False,True):roles[hollow],queries['中空' if hollow else '塗り潰し']=照会(h,役割境界,{'記号は中空':hollow},'列展開役割')
     if any(v is None for v in roles.values()):return {'状態':'HOLD','理由':'展開役割未学習または係争','照会':queries}
     yes,yq=照会(h,目標境界,{'終端条件に応じた列が一致':True},'提出が受理された');no,nq=照会(h,目標境界,{'終端条件に応じた列が一致':False},'提出が受理された')
     if yes is not True or no is not False:return {'状態':'HOLD','理由':'提出受理関係が未成立','正例照会':yq,'負例照会':nq}
     slots=[s for b in scene['容器群'] for s in b['枠群'] if s['記号'] is None];tokens=[s['記号'] for s in scene['在庫群']]
     if len(slots)!=len(tokens):raise ValueError('在庫と空欄の全単射文法が未成立')
     seen=set();solutions=[];failures=Counter();tested=0
     for perm in itertools.permutations(tokens):
      k=tuple((t['色'],t['中空']) for t in perm)
      if k in seen:continue
      seen.add(k);tested+=1
      for s,t in zip(slots,perm):s['記号']=t
      match,detail=一致する(scene,roles)
      # 全列挙の各判定をその場で通知。複製により観測側の変更を隔離する。
      # 観測失敗は伝播し、不完全な記録のまま完了扱いにはしない。
      if observer is not None:
       observer(deepcopy({'ordinal':tested-1,'assignment':[{'position':s['位置'],'color':t['色'],'hollow':t['中空']} for s,t in zip(slots,perm)],'match':match,'reason':None if match else detail.get('理由','目標列不一致'),'detail':detail}))
      if match:solutions.append({'割当':[{'位置':s['位置'],'色':t['色'],'中空':t['中空']} for s,t in zip(slots,perm)],'列生成':detail})
      else:failures[detail.get('理由','目標列不一致')]+=1
     for s in slots:s['記号']=None
     return {'状態':'唯一解答候補' if len(solutions)==1 else '複数解答候補' if solutions else 'HOLD','候補数':len(solutions),'全数確認した相異なる割当数':tested,'候補':solutions,'不採用理由集計':dict(failures),'実行許可':False,'作用対象':solutions[0]['割当'][0] if len(solutions)==1 and solutions[0]['割当'] else None,'照会':queries,'正例照会':yq,'負例照会':nq,'注意':'複数候補は目標列上で同値。未実行候補の環境受理を実測したとは主張しない'}

    def 選択を読む(frame,scene):
     choices=[]
     for item in scene['在庫群']:
      x,y=item['位置'];bg=scene['背景色']
      if x<1 or y<1 or x+4>=len(frame[0]) or y+4>=len(frame):continue
      rim=[frame[y-1+dy][x-1+dx] for dy in range(6) for dx in range(6) if dy in (0,5) or dx in (0,5)]
      if len(set(rim))==1 and rim[0] not in (bg,item['記号']['色']):choices.append(item)
     if len(choices)>1:raise ValueError('選択中在庫が複数候補')
     return choices[0] if choices else None
    return SimpleNamespace(記号を読む=記号を読む, 容器外形を観測する=容器外形を観測する, 図式を観測する=図式を観測する, 列を生成する=列を生成する, 一致する=一致する, 照会=照会, 内容候補を構成する=内容候補を構成する, 選択を読む=選択を読む, 役割境界=役割境界, 目標境界=目標境界, 作用境界=作用境界, 構造境界=構造境界, 適用前提=適用前提, 知覚不適用=知覚不適用)
