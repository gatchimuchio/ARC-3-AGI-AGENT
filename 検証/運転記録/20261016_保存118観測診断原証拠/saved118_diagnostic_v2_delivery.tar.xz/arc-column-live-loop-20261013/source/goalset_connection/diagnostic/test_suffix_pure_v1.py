"""Suffix59 source-only tests; immutable FAILED prefix and no native calls."""
import ast,copy,hashlib,json,resource,runpy,types
from pathlib import Path
resource.setrlimit(resource.RLIMIT_AS,(512<<20,512<<20))
D=Path('/workspace/scratch/a94ff513b3af/arc-column-live-loop-20261013/source/goalset_connection/diagnostic')
cat=runpy.run_path(str(D/'catalog_v1.py'));h=runpy.run_path(str(D/'suffix_harness_disabled_v1.py'));pc=runpy.run_path(str(D/'prefix_closure_v1.py'));closure=pc['verify']()
allitems=cat['catalog']();items=allitems[59:];assert len(items)==59 and sum(x['bound']for x in items)==2567
c=cat['module']('suffix_pure_candidate','candidate');common=c.common;all_origins=[]
ns={'cat':cat,'h':h,'c':c,'common':common,'all_origins':all_origins,'copy':copy,'types':types}
t=ast.parse((D/'test_pure_v8.py').read_text());nodes=[copy.deepcopy(n) for n in t.body if isinstance(n,(ast.ClassDef,ast.FunctionDef)) and n.name in ('External','Fixture','run')]
exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),'suffix_synthetic_semantic','exec'),ns);cat['ns']['外部入力']=ns['External']
results={};checks=[];measurements=[]
for item in items:
 r,f=ns['run'](item);assert r['実行許可']is False and f.bound==item['bound'] and len(f.calls)<=f.bound
 for k,v in item['expected_pool'].items():assert cat['exact'](r['全目標pool'][k],v)
 assert all(x['origin']['live採否可能']is False for x in f.calls)
 results[item['ordinal']]=(r,f);measurements.append({'original_ordinal':item['ordinal'],'bound':f.bound,'synthetic_queries':len(f.calls),'candidate_count':len(r['全作用候補']['全候補'])})
assert sum(m['synthetic_queries']for m in measurements)==767
checks.append('all59_source_ordinals59to117_whole_pools_candidates_and_false_origins')
def rejects(name,fn):
 try:fn()
 except (ValueError,MemoryError,PermissionError):checks.append(name);return
 raise AssertionError(name)
x=h['Run']();x.clock.stop()
for n in ('main','native_permission'):rejects('disabled_'+n,h[n])
for n in ('preflight','execute','_query_after_admission','_initialize_after_admission','_prepare_native_bindings','_execute_after_admission','preserve_failure_components'):
 rejects('disabled_'+n,lambda n=n:getattr(x,n)(None) if n in ('_query_after_admission','_initialize_after_admission') else getattr(x,n)())
x.check_packet_budget('api_000000_intent','evidence',16384);rejects('intent_full16KiB_cap',lambda:x.check_packet_budget('api_000000_intent','evidence',16385))
x.check_packet_budget('api_000000_reply','evidence',112*1024);rejects('reply112KiB_unchanged',lambda:x.check_packet_budget('api_000000_reply','evidence',112*1024+1))
for v in (True,-1,2568):rejects('suffix_counter_strict_'+str(v),lambda v=v:h['expected_state']({'識別子状態':{'照会':5880,'学習判定':5880}},v,copy.deepcopy,copy.deepcopy))
assert h['expected_state']({'識別子状態':{'照会':5880,'学習判定':5880}},2567,copy.deepcopy,copy.deepcopy)['識別子状態']['照会']==8447
# Actual full suffix loop AST with native guard removed ONLY in this pure test,
# injected synthetic semantic responses, and in-memory save/normal-state stubs.
ht=ast.parse((D/'suffix_harness_disabled_v1.py').read_text());rc=next(n for n in ht.body if isinstance(n,ast.ClassDef) and n.name=='Run')
method=copy.deepcopy(next(n for n in rc.body if isinstance(n,ast.FunctionDef) and n.name=='_execute_after_admission'))
assert method.body[0].value.func.id=='native_permission';method.body.pop(0)
nsloop=dict(h);saved={}
def semantic(family,candidate,frame,actions,view,ask,state):
 r,f=results[view.frame_ordinal];view.frame_calls=len(f.calls);view.calls.extend({'synthetic':True,'ordinal':len(view.calls)+i,'original_frame':view.frame_ordinal}for i in range(len(f.calls)));return copy.deepcopy(r)
nsloop['semantic_entry']=semantic
exec(compile(ast.fix_missing_locations(ast.Module(body=[method],type_ignores=[])),'pure_suffix_execution_loop','exec'),nsloop)
fake=types.SimpleNamespace(items=items,frame_results=[],calls=[],family=cat['family'],candidate=c,ask=None,input_closures=[],prefix_closure=closure,gate={'nonce':'pure-fixture-not-a-root-gate'},initial={'識別子状態':{'照会':5880,'学習判定':5880}},enc=copy.deepcopy,dec=copy.deepcopy,state_refs=[],complete=False)
def save(name,value,*args,**kwargs):saved[name]=value;return {'synthetic_ref':name}
fake.save=save
fake.standard=lambda name:({'bytes':5355957,'synthetic_ref':name},h['expected_state'](fake.initial,len(fake.calls),copy.deepcopy,copy.deepcopy))
nsloop['_execute_after_admission'](fake);completed=saved['completion']
assert completed['schema']=='saved59-suffix-candidate-diagnostic-completion-v1' and completed['frame_count']==59 and completed['processed_original_ordinals']==list(range(59,118))
assert completed['Query']==767 and completed['final_paired_counter']==6647 and completed['all118_complete_claim']is False and completed['all118_integration_requires_independent_audit']is True
assert [int(n.split('_')[1])for n in saved if n.startswith('frame_')and n.endswith('_result')]==list(range(59,118))
assert completed['prefix_failure_closure']['prefix_status']=='FAILED';checks.append('actual_loop_suffix_only_completion_not_full118_and_counter5880plusactual')
# Exact raw-only dependency prefix remains all65 materials +20 actual core/family.
assert len(h['actual_native_dependency_pins']())==20
bad=copy.deepcopy(pc['REFS']['latest_state']);bad['sha256']='0'*64;rejects('prefix_state_ref_tamper',lambda:pc['read'](bad))
bad=copy.deepcopy(pc['REFS']['summary']);bad['sha256']='0'*64;rejects('prefix_summary_ref_tamper',lambda:pc['read'](bad))
assert not any(k.startswith('hds学習系統') or k=='arcengine' for k in __import__('sys').modules)
report={'schema':'saved59-suffix-source-pure-v1','status':'PASS','checks':checks,'measurements':measurements,'suffix_observations':59,'Query_upper_bound':2567,'synthetic_queries':767,'baseline_counter':5880,'max_final_counter':8447,'prefix_closure':closure,'native':0,'restore':0,'Query':0,'Teach':0,'Action':0,'SDK':0,'all118_complete_claim':False}
b=(json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode();r=h['scope'].save('evidence','saved59_suffix_source_pure_report_v1.json',b);print(json.dumps({'status':'PASS','report':r,'checks':len(checks),'observations':59,'bound':2567,'synthetic_queries':767}))
