"""Synthetic branch checks and saved raw perception. No native HDS/SDK calls."""
import ast,copy,hashlib,json,resource,runpy,time,types
from pathlib import Path
resource.setrlimit(resource.RLIMIT_AS,(512<<20,512<<20))
D=Path('/workspace/scratch/a94ff513b3af/arc-column-live-loop-20261013/source/goalset_connection/diagnostic');start=time.monotonic()
cat=runpy.run_path(str(D/'catalog_v1.py'));h=runpy.run_path(str(D/'harness_disabled_v4.py'))
items=cat['catalog']();c=cat['module']('diagnostic_pure_candidates','candidate');common=c.common
class External:
 def __init__(self,facts,boundary):self.内容=facts;self.対象系境界=boundary
cat['ns']['外部入力']=External
RESULTS=[];negatives=[];queries=0;all_origins=[]
class Fixture:
 def __init__(self,item,mode='normal'):
  self.item=item;self.mode=mode;self.calls=[];self.owner=self;self.bound=0;self.codes=h['candidate_code_set'](c)
 def allow_frame(self,n):self.bound=n
 def 照会する(self,e):
  origin=h['current_origin'](self.item['origin'],e,self.codes,c.作用境界,{c.legacy.保存境界,common.PRESERVE_BOUNDARY})
  assert origin['live採否可能'] is False
  b=e.対象系境界;facts=e.内容
  if b==cat['ns']['役割境界']:key='列展開役割';v='参照' if facts['記号は中空'] else '出力'
  elif b==c.目標境界:key='提出が受理された';v=facts['終端条件に応じた列が一致']
  elif b==c.作用境界:key='必要行動ID';v=5 if facts['解答作業']=='完成列提出' else 6
  elif b==common.PREP_BOUNDARY:key=common.PREP_RESULT;v=facts[common.PREP_INPUT]
  elif b==common.REPAIR_BOUNDARY:key=common.REPAIR_RESULT;v=facts[common.REPAIR_INPUT]
  elif b==common.PRESERVE_BOUNDARY:key=common.PRESERVE_RESULT;v=True
  elif b==c.legacy.準備境界:key=c.legacy.準備結果;v=facts[c.legacy.準備入力]
  elif b==c.legacy.修復境界:key=c.legacy.修復結果;v=facts[c.legacy.修復入力]
  elif b==c.legacy.保存境界:key=c.legacy.保存結果;v=True
  else:raise AssertionError(b)
  content={'予測群':[{'結果経路':(key,),'予測値':v,'原理参照':'synthetic-pure-not-native'}]};state='出力'
  if self.mode=='unknown_effect' and b not in (cat['ns']['役割境界'],c.目標境界,c.作用境界):content={'予測群':[]}
  if self.mode=='hold_mapping' and b==c.作用境界:state='断定保留';content={'予測群':[],'断定保留理由群':['synthetic-HOLD']}
  self.calls.append({'boundary':b,'facts':copy.deepcopy(facts),'origin':origin,'state':state,'value':v});all_origins.append(origin)
  return types.SimpleNamespace(状態=state,内容=content,追跡情報={'fixture_only':True})
 def ask(self,b,f):
  r=self.照会する(External(copy.deepcopy(f),b));return {'状態':r.状態,'内容':r.内容,'追跡情報':r.追跡情報}
def run(item,mode='normal'):
 f=Fixture(item,mode);r=h['semantic_entry'](cat['family'],c,item['frame'],item['actions'],f,f.ask,item['public_state']);return r,f
for item in items:
 r,f=run(item);assert r['適用性']=='固定知覚適合' and r['実行許可']is False
 assert f.bound==item['bound'] and len(f.calls)<=f.bound
 p=r['全目標pool']
 for k,v in item['expected_pool'].items():assert cat['exact'](p[k],v),(item['ordinal'],k)
 full=r['全作用候補'];assert full['実行許可']is False and full['自動選択']is None
 for cand in full['全候補']:
  assert cand['実行許可']is False
  assert len(cand['照会全件'])<=3
  for q in cand['照会全件']:assert q['返却']is not None
 assert len(full['全候補'])<=item['structural_candidates']
 RESULTS.append({'ordinal':item['ordinal'],'label':item['label'],'bound':f.bound,'synthetic_calls':len(f.calls),'pool':p.get('候補数'),'all_candidates':len(full['全候補']),'negative_predictions':sum(q.get('予測')is False for x in full['全候補'] for q in x['照会全件']),'unknown_candidates':sum(x['効果状態']=='UNKNOWN' for x in full['全候補']),'origin_live_adoption':False})
 queries+=len(f.calls)
def rejects(name,fn):
 try:fn()
 except (ValueError,PermissionError,MemoryError,TypeError):negatives.append(name);return
 raise AssertionError('did not reject '+name)
for name in ('main','native_permission'):
 rejects('disabled_'+name,lambda n=name:h[n]())
x=h['Run']();x.clock.stop()
for name in ('preflight','execute','_query_after_admission','_initialize_after_admission','_execute_after_admission','preserve_failure_components','_prepare_native_bindings'):
 rejects('disabled_'+name,lambda n=name:getattr(x,n)(None) if n in ('_query_after_admission','_initialize_after_admission') else getattr(x,n)())
for n in (True,-1,4886):rejects('counter_'+str(n),lambda n=n:h['expected_state']({'識別子状態':{'照会':4887,'学習判定':4887}},n,copy.deepcopy,copy.deepcopy))
assert h['expected_state']({'識別子状態':{'照会':4887,'学習判定':4887},'台帳':[]},4885,copy.deepcopy,copy.deepcopy)=={'識別子状態':{'照会':9772,'学習判定':9772},'台帳':[]}
for name,limit in [('api_000001_intent',8192),('api_000001_reply',114688),('frame_000_result',524288),('frame_000_input',32768)]:
 x.check_packet_budget(name,'evidence',limit);rejects('oversize_'+name,lambda n=name,l=limit:x.check_packet_budget(n,'evidence',l+1))
for value in (None,True):
 bad=copy.deepcopy(items[-1]['origin']);bad['live採否可能']=value
 rejects('forged_live_origin_'+str(value),lambda b=bad:h['current_origin'](b,External({},c.作用境界),set(),c.作用境界,set()))
# Deliberate public pixel/type and alias conflicts use the same exact parser.
data={'game_id':'test','state':'NOT_FINISHED','frame':[copy.deepcopy(items[0]['frame'])],'score':0,'win_score':8,'available_actions':[5,6,7]}
for name,mut in [('pixel_bool',lambda d:d['frame'][0][0].__setitem__(0,True)),('phase_missing',lambda d:d.__setitem__('frame',[])),('available_bool',lambda d:d.__setitem__('available_actions',[True])),('alias_conflict',lambda d:d.__setitem__('levels_completed',1)),('score_bool',lambda d:d.__setitem__('score',True))]:
 bad=copy.deepcopy(data);mut(bad);rejects(name,lambda d=bad:cat['before_public'](d,0,cat['PINS']['raw']))
# Pinned raw/case/stop references cannot silently be changed.
for key in ('raw','pack','stop_intent','stop_public','state'):
 bad=copy.deepcopy(cat['PINS'][key]);bad['sha256']='0'*64;rejects('pin_tamper_'+key,lambda b=bad:cat['read'](b))
for mode in ('unknown_effect','hold_mapping'):
 r,f=run(items[-1],mode);assert r['実行許可']is False and r['全作用候補']['実行許可']is False
 assert len(r['全作用候補']['全候補'])==RESULTS[-1]['all_candidates'];assert all(x['origin']['live採否可能']is False for x in f.calls)
 negatives.append(mode+'_all_candidates_retained')
# Actual teacher negatives must remain represented in source measurements, not
# fed as expected outputs to these synthetic branch fixtures.
assert any(x['negative_predictions'] for x in RESULTS)
assert all(x['origin_live_adoption']is False for x in RESULTS)
# Exercise failure decomposition as a pure fixture with injected save/standard.
ht=ast.parse((D/'harness_disabled_v4.py').read_text());rc=next(n for n in ht.body if isinstance(n,ast.ClassDef) and n.name=='Run')
fm=copy.deepcopy(next(n for n in rc.body if isinstance(n,ast.FunctionDef) and n.name=='preserve_failure_components'))
assert isinstance(fm.body[1],ast.Expr) and isinstance(fm.body[1].value,ast.Call) and fm.body[1].value.func.id=='native_permission'
fm.body.pop(1);scope={};exec(compile(ast.fix_missing_locations(ast.Module(body=[fm],type_ignores=[])),'pure_failure_extraction','exec'),scope)
fake=types.SimpleNamespace(clock=types.SimpleNamespace(stop=lambda:None,remaining={'save':1000}),errors=[],completed_queries=0,calls=[],frame_results=[])
fake.current={'ordinal':0,'frame':0,'origin':{'live採否可能':False},'before':{'counter':4887},'after':{'counter':4888},'input':{'a':1},'capture':{'raw':[{'full':'raw'}],'return':{'full':'external'},'events':['exact-event'],'profile_restored':True}}
fake.pending={'name':'frame_000_result','value':{'all_candidates':['oversized-full-pending']}};original_pending=fake.pending;original_current=fake.current;saved={}
def save(name,value,category='evidence',codec=True):
 saved[name]=copy.deepcopy(value);fake.pending={'name':name,'value':value};return {'fixture':name}
fake.save=save;fake.standard=lambda name:({'fixture':'state'},{'識別子状態':{'照会':4888,'学習判定':4888}})
scope['preserve_failure_components'](fake)
assert saved['failure_component_current_metadata']['capture_metadata']=={'events':['exact-event'],'profile_restored':True}
assert saved['failure_component_current_metadata']['after']=={'counter':4888}
assert saved['failure_component_pending_value']==original_pending['value']
assert fake.held_failure_pending is original_pending and fake.held_failure_current is original_current
assert saved['failure_manifest']['actual_Query_delta_from_4887']==1 and saved['failure_manifest']['returned_capture_calls']==0
assert saved['failure_manifest']['unprocessed_suffix']==list(range(118));negatives.append('capture_side_exception_actual_counter_and_complete_pending_retention')
x.check_packet_budget('failure_component_input','evidence',16<<20);rejects('failure_component_input_cap',lambda:x.check_packet_budget('failure_component_input','evidence',(16<<20)+1))
report={'schema':'saved118-diagnostic-source-pure-v1','status':'PASS','errors':[],'all118':RESULTS,'strict_query_upper_bound':4885,'synthetic_fixture_calls':queries,'negative_checks':negatives,'max_observation_bound':max(x['bound']for x in items),'baseline_counter':4887,'max_final_counter':9772,'native':0,'HDS_restores':0,'Query':0,'Teach':0,'Action':0,'SDK':0,'runtime_enabled':False,'elapsed_seconds':time.monotonic()-start,'limitations':['Synthetic replies only, not learned support or actual native queries.','All118 raw before perceptions rejoined to exact public sources; IDs/labels never enter semantic solver arguments.','Native preflight remains unconditional refusal. A future root-admitted source must supply verified native bindings and actual tools receipts.']}
raw=(json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode();r=h['scope'].save('evidence','saved118_diagnostic_pure_report_v4.json',raw);print(json.dumps({'status':'PASS','report':r,'bound':4885,'synthetic_calls':queries,'negative_checks':len(negatives),'seconds':report['elapsed_seconds']}))
