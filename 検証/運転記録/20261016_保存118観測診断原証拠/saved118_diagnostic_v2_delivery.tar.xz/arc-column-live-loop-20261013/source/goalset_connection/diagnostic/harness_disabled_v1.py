"""Disabled saved-observation native harness source. All public native entries refuse.
Existing all27 capture/codec/standard save and semantic entry are exact AST reused.
No SDK, GameAction, Teach, reset, or environment access exists in this harness.
"""
import ast,base64,copy,hashlib,importlib.util,json,lzma,os,resource,shutil,signal,sys,time,traceback,types
from pathlib import Path
from copy import deepcopy
B=Path('/workspace/scratch/a94ff513b3af');ROOT=B/'arc-column-live-loop-20261013';D=ROOT/'source/goalset_connection/diagnostic';MIB=1<<20
RUNTIME_AUTHORIZED=False
PINS=json.loads((D/'pins_v1.json').read_text())

def native_permission():
 raise PermissionError('SOURCE/PURE ONLY: saved118 native Query gate not issued')
def load_pure(name,key):
 r=PINS[key];p=Path(r['path']);b=p.read_bytes()
 if p.is_symlink() or len(b)!=r['bytes'] or hashlib.sha256(b).hexdigest()!=r['sha256']:raise ValueError('source pin')
 m=types.ModuleType(name);m.__file__=str(p);sys.modules[name]=m;exec(compile(b,str(p),'exec'),m.__dict__);return m
scope=load_pure('diagnostic_resource_guard','guard')
# Deliberately excludes old all27 imports/preflight/restore and all game code.
t=ast.parse(Path(PINS['base']['path']).read_bytes())
if hashlib.sha256(Path(PINS['base']['path']).read_bytes()).hexdigest()!=PINS['base']['sha256']:raise ValueError('base exact pin')
names={'eq','jb','sha','identity','ref','fsyncdir','readref','capture_call','snapshot_value','frame_hash','Clock'}
nodes=[copy.deepcopy(n) for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in names]
old=next(n for n in t.body if isinstance(n,ast.ClassDef) and n.name=='Run')
methods={'__init__','encoded','save','standard','markers'}
body=[copy.deepcopy(n) for n in old.body if isinstance(n,ast.FunctionDef) and n.name in methods]
if {n.name for n in nodes}!=names or {n.name for n in body}!=methods:raise ValueError('base AST closure')
# Only output namespace/cap changes. Capture, codec, write/CRC/readback and normal
# native persistence body remain inherited. Source versions are never overwritten.
class Storage(ast.NodeTransformer):
 def visit_Constant(self,n):
  if n.value=='state_trace':return ast.copy_location(ast.Constant('evidence'),n)
  return n
for n in body:
 Storage().visit(n)
 if n.name=='save':
  for sub in ast.walk(n):
   if isinstance(sub,ast.Compare) and isinstance(sub.left,ast.BinOp) and isinstance(sub.left.left,ast.Attribute) and sub.left.left.attr=='trace_bytes':
    sub.comparators[0]=ast.parse('800*MIB',mode='eval').body
  i=next(i for i,x in enumerate(n.body[2].body) if False) if False else None
  # Insert a cap check immediately after lzma.compress, before any write.
  tr=next(x for x in n.body if isinstance(x,ast.Try))
  at=next(i for i,x in enumerate(tr.body) if isinstance(x,ast.Assign) and any(isinstance(z,ast.Name) and z.id=='blob' for z in x.targets))
  tr.body[at+1:at+1]=ast.parse('self.check_packet_budget(name,category,len(blob))').body
nodes.append(ast.ClassDef(name='BaseRun',bases=[],keywords=[],body=body,decorator_list=[]))
exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),PINS['base']['path'],'exec'),globals())
q=Path(PINS['query']['path']).read_bytes()
if len(q)!=PINS['query']['bytes'] or hashlib.sha256(q).hexdigest()!=PINS['query']['sha256']:raise ValueError('query source pin')
t=ast.parse(q);nodes=[copy.deepcopy(n) for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='semantic_entry']
if len(nodes)!=1:raise ValueError('semantic AST closure')
exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),PINS['query']['path'],'exec'),globals())
OWNER=None

def guard(category=None,extra=0):
 result=scope.guard(category,extra)
 if OWNER is not None and OWNER.start_usage is not None:
  now=result['used']
  for k,cap in [('evidence',800*MIB),('failure',4*MIB)]:
   if now[k]-OWNER.start_usage[k]+(extra if category==k else 0)>cap:raise MemoryError('incremental '+k+' budget')
 return result

def candidate_code_set(candidate):
 out=set()
 def walk(code):
  if isinstance(code,types.CodeType):
   out.add(code)
   for c in code.co_consts:walk(c)
 walk(candidate.全作用候補を構成する.__code__);walk(candidate.legacy.全作用候補を構成する.__code__)
 return out

def current_origin(base,external,codes,action_boundary,preserve_boundaries):
 origin=deepcopy(base)
 if origin.get('live採否可能')is not False:raise ValueError('diagnostic origin must remain false')
 origin.update({'候補番号':None,'用途':'目標pool','境界':external.対象系境界})
 f=sys._getframe()
 try:
  while f:
   if f.f_code in codes and isinstance(f.f_locals.get('c'),dict):
    c=f.f_locals['c']
    if type(c.get('候補番号'))is not int:raise ValueError('candidate origin type')
    origin['候補番号']=c['候補番号'];origin['用途']='作用対応' if external.対象系境界==action_boundary else '保存' if external.対象系境界 in preserve_boundaries else '候補効果';break
   f=f.f_back
 finally:del f
 if external.対象系境界 not in ('公開列図式:記号外形と展開役割','公開列図式:有限全列または生産的反復の目標長一致と提出受理') and origin['候補番号'] is None:raise ValueError('candidate origin missing')
 return origin

def expected_state(initial,count,enc,dec):
 if type(count)is not int or not 0<=count<=4885:raise ValueError('strict query count')
 expected=dec(enc(initial))
 for k in ('照会','学習判定'):expected['識別子状態'][k]=expected['識別子状態'].get(k,0)+count
 return expected

class Run(BaseRun):
 def __init__(self):
  super().__init__();self.clock.remaining={'compute':7200.0,'save':3600.0,'failure':120.0};self.start_usage=None;self.frame_results=[];self.frame_budget=0;self.frame_calls=0;self.items=[];self.origin=None;self.initial=None;self.input_closures=[];self.completed_queries=0
 def preflight(self,*args,**kwargs):native_permission()
 def execute(self,*args,**kwargs):native_permission()
 def allow_frame(self,n):
  if type(n)is not int or not 4<=n<=58 or len(self.calls)+n>4885:raise MemoryError('strict frame/full query bound')
  self.frame_budget=n
 def check_packet_budget(self,name,category,size):
  if category=='failure':cap=4*MIB
  elif name.endswith('_intent'):cap=8*1024
  elif name.endswith('_reply'):cap=112*1024
  elif name.endswith('_result'):cap=512*1024
  elif name.endswith('_input'):cap=32*1024
  elif name.startswith('failure_component_'):cap=16*MIB
  else:cap=32*MIB
  if size>cap:raise MemoryError('individual complete packet cap: '+name)
 @property
 def owner(self):return self
 def 照会する(self,external):
  native_permission()
  return self._query_after_admission(external)
 def _query_after_admission(self,external):
  native_permission()
  if self.frame_calls>=self.frame_budget or len(self.calls)>=4885:raise MemoryError('full enumeration cap')
  i=len(self.calls);origin=current_origin(self.origin,external,self.candidate_codes,self.candidate.作用境界,{self.candidate.legacy.保存境界,self.candidate.common.PRESERVE_BOUNDARY})
  origin['復元状態参照']=PINS['state'];origin['直前Query通番']=i-1
  self.current={'ordinal':i,'frame':self.frame_ordinal,'method':'照会する','input':external,'origin':origin,'before':self.markers(),'capture':{}}
  intent=self.save('api_%06d_intent'%i,self.current)
  answer=capture_call(self.machine,'照会する',external,self.current['capture']);self.completed_queries+=1
  self.current['after']=self.markers()
  reply=self.save('api_%06d_reply'%i,self.current)
  self.calls.append({'ordinal':i,'frame':self.frame_ordinal,'method':'照会する','intent':intent,'reply':reply});self.frame_calls+=1
  expected=expected_state(self.initial,len(self.calls),self.enc,self.dec)
  if not eq(self.enc(expected),self.enc(snapshot_value(self.machine))):raise ValueError('per-query complete native state differs beyond paired counters')
  self.current=None;return answer
 def ask(self,boundary,facts):
  r=self.照会する(self.native.外部入力(deepcopy(facts),boundary));return {'状態':r.状態,'内容':r.内容,'追跡情報':r.追跡情報,'実照会保存参照':deepcopy(self.calls[-1])}
 def _initialize_after_admission(self,catalog_module):
  native_permission()
  closure=load_pure('saved_diagnostic_latest_closure','closure').verify()
  if closure['runtime_authorized']is not False or closure['closed_state']!=PINS['state']:raise ValueError('exact4887 closure')
  self.start_usage=scope.guard()['used'];self.items=catalog_module.catalog()
  # A future root-admitted version must pin all core/family dependencies and real
  # native import identities BEFORE this body; disabled version never imports.
  self.candidate=load_pure('saved_diagnostic_candidate','candidate');self.candidate_codes=candidate_code_set(self.candidate)
  self.machine=self.native.HDS学習系統.読み込む(PINS['state']['path'])
  first,self.initial=self.standard('restored_before')
  if first['bytes']!=PINS['state']['bytes'] or first['sha256']!=PINS['state']['sha256']:raise ValueError('exact standard restore')
  return closure
 def _execute_after_admission(self):
  native_permission()
  for i,item in enumerate(self.items):
   self.frame_ordinal=i;self.frame_calls=0;self.frame_budget=0;self.origin=deepcopy(item['origin'])
   self.save('frame_%03d_input'%i,{k:v for k,v in item.items() if k not in ('frame','scene','selection','expected_pool')})
   # Only current pixels/public availability/state flow into solver. Labels and
   # expected teacher pools are evidence joins and never solution inputs.
   result=semantic_entry(self.family,self.candidate,item['frame'],item['actions'],self,self.ask,item['public_state'])
   if result.get('API数上界')!=item['bound'] or self.frame_calls>item['bound']:raise ValueError('current structural bound differs')
   result['actual_API_count']=self.frame_calls;result['phase_scope']={'診断のみ':True,'live採否可能':False,'相':item['origin']['相'],'全相数':item['origin']['全相数'],'末相':True}
   self.frame_results.append(self.save('frame_%03d_result'%i,{'ordinal':i,'origin':self.origin,'result':result}))
  last,final=self.standard('after_all_queries')
  if not eq(self.enc(expected_state(self.initial,len(self.calls),self.enc,self.dec)),self.enc(final)):raise ValueError('final complete state equality')
  if last['bytes']!=5355957:raise ValueError('same-digit standard size differs')
  complete={'schema':'saved118-all-candidate-diagnostic-completion-v1','status':'complete','errors':[],'nonce':self.gate['nonce'],'frames':self.frame_results,'frame_count':118,'api_calls':self.calls,'states':self.state_refs,'Teach':0,'Query':len(self.calls),'Action':0,'SDK':0,'unprocessed_suffix':[],'diagnostic_origin_live_adoption':False,'next_fresh_baseline':last,'final_paired_counter':4887+len(self.calls),'full_state_only_paired_counters':True}
  receipt=self.save('completion',complete,codec=False);self.complete=True;return receipt
 def preserve_failure_components(self):
  """No aggregate duplicate. All failures stay visible; no cleanup/replay."""
  native_permission()
  self.clock.stop();self.clock.remaining['save']=min(self.clock.remaining['save'],120.0)
  manifest={'status':'failed_held','errors':self.errors,'completed_Query':self.completed_queries,'durably_receipted_Query':len(self.calls),'saved_frames':self.frame_results,'unprocessed_suffix':list(range(len(self.frame_results),118)),'components':{},'state':None,'live採否可能':False}
  if self.current is not None:
   # Each object is encoded independently. Failed components remain in current.
   parts={'input':self.current.get('input'),'raw':self.current.get('capture',{}).get('raw'),'external_return':self.current.get('capture',{}).get('return')}
   for name,value in parts.items():
    try:manifest['components'][name]=self.save('failure_component_'+name,value)
    except BaseException as e:manifest['components'][name]={'unsaved':True,'type':type(e).__name__,'message':str(e)}
  try:manifest['state']=self.standard('failure_latest')[0]
  except BaseException as e:manifest['state']={'unsaved':True,'type':type(e).__name__,'message':str(e)}
  return self.save('failure_manifest',manifest,'failure',codec=False)

def main(*args,**kwargs):native_permission()
if __name__=='__main__':main()
