"""Pure lossless intent-size measurement: all118 origins and every candidate input.
Saved typed bytes only. No HDS imports, state restore, native API or SDK.
"""
import ast,copy,hashlib,json,lzma,resource,runpy,time,types
from pathlib import Path
resource.setrlimit(resource.RLIMIT_AS,(512<<20,512<<20))
B=Path('/workspace/scratch/a94ff513b3af');L=B/'arc-column-live-loop-20261013';D=L/'source/goalset_connection/diagnostic';N='793242337c714081b4f642f1e0db3663';F=L/'evidence'/N
cat=runpy.run_path(str(D/'catalog_v1.py'));h=runpy.run_path(str(D/'harness_disabled_v7.py'));items=cat['catalog']();c=cat['module']('cap_measure_candidate','candidate');common=c.common
all_origins=[];ns={'cat':cat,'h':h,'c':c,'common':common,'all_origins':all_origins,'copy':copy,'types':types}
t=ast.parse((D/'test_pure_v8.py').read_text());nodes=[copy.deepcopy(n) for n in t.body if isinstance(n,(ast.ClassDef,ast.FunctionDef)) and n.name in ('External','Fixture','run')];assert len(nodes)==3
exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),'pure_cap_fixture','exec'),ns);cat['ns']['外部入力']=ns['External']
def read_packet(p):
 z=lzma.LZMADecompressor(memlimit=128<<20);raw=z.decompress(p.read_bytes(),max_length=(16<<20)+1);assert z.eof and not z.unused_data and z.check==lzma.CHECK_CRC64;return json.loads(raw)
def td(x):return dict(x['__辞書__'])
def enc(x):
 if isinstance(x,dict):return {'__辞書__':[[enc(k),enc(v)] for k,v in x.items()]}
 if isinstance(x,tuple):return {'__組__':[enc(v) for v in x]}
 if isinstance(x,list):return [enc(v) for v in x]
 assert x is None or type(x)in (str,int,bool);return x
def jb(x):return json.dumps(x,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()
def pack_size(x):
 raw=jb(x);blob=lzma.compress(raw,preset=0,check=lzma.CHECK_CRC64);assert lzma.decompress(blob)==raw;return len(raw),len(blob)
def ref(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
meta=read_packet(F/'failure_component_current_metadata.json.xz');mt=td(meta);inp=read_packet(F/'failure_component_input.json.xz')
assert td(mt['capture_metadata'])=={} and 'after'not in mt
# Match exact original current construction key order in immutable native source.
recovered={'__辞書__':[['ordinal',mt['ordinal']],['frame',mt['frame']],['method',mt['method']],['input',inp],['origin',mt['origin']],['before',mt['before']],['capture',{'__辞書__':[]}]]}
recovered_raw,recovered_compressed=pack_size(recovered);assert recovered_compressed>8192 and recovered_compressed<=16384
baseline=ref(F/'failure_latest.standard.json');before=cat['untag'](mt['before']);assert before['identifiers']['照会']==before['identifiers']['学習判定']==5880
records=[];count=0
for item in items:
 result,fixture=ns['run'](item)
 for q in fixture.calls:
  origin=copy.deepcopy(q['origin']);origin['復元状態参照']=baseline;origin['直前Query通番']=count-1
  markers=copy.deepcopy(before)
  for k in ('照会','学習判定'):markers['identifiers'][k]=5880+count
  external={'__データ型__':'外部入力','値':{'内容':enc(q['facts']),'対象系境界':q['boundary'],'主体':None,'対象':None,'目的':None,'文脈':enc({})}}
  value={'__辞書__':[['ordinal',count],['frame',item['ordinal']],['method','照会する'],['input',external],['origin',enc(origin)],['before',enc(markers)],['capture',enc({})]]}
  raw,compressed=pack_size(value);assert compressed<=16384
  records.append({'observation':item['ordinal'],'candidate':origin['候補番号'],'purpose':origin['用途'],'boundary':q['boundary'],'input':q['facts'],'phase_count':origin['全相数'],'rawbytes':raw,'compressed_bytes':compressed});count+=1
assert count==1760
suffix_bound=sum(x['bound']for x in items[59:]);assert max(r['compressed_bytes']for r in records)<=16384
report={'schema':'saved118-all-origin-candidate-intent-cap-pure-v1','status':'PASS','native':0,'restore':0,'Query':0,'Teach':0,'SDK':0,'Action':0,'observations':118,'all_synthetic_query_inputs':count,'max_compressed_bytes':max(r['compressed_bytes']for r in records),'max_rawbytes':max(r['rawbytes']for r in records),'cap_bytes':16384,'all_measurements':records,'recovered_failed_intent':{'rawbytes':recovered_raw,'compressed_bytes':recovered_compressed,'rawsha256':hashlib.sha256(jb(recovered)).hexdigest(),'current_metadata':ref(F/'failure_component_current_metadata.json.xz'),'input_component':ref(F/'failure_component_input.json.xz'),'capture_metadata_empty':True,'old_intent_cap_rejects':True,'new_intent_cap_preserves_complete':True,'reconstruction':'Exact current key order from immutable source plus all saved typed metadata/input; no native response was produced.'},'suffix':{'first':59,'last':117,'observations':59,'strict_Query_upper_bound':suffix_bound,'synthetic_calls':sum(x['observation']>=59 for x in records),'baseline_counter':5880,'max_end_counter':5880+suffix_bound},'budget':{'additional_intent_allowance_bytes':4885*8192,'all118_worst_evidence_with_normal_anomaly':830912949,'evidence_cap':800<<20},'limitations':['Synthetic replies select the same fixed learned role/action mappings as audited native prefix; these are not native queries or new learned support.','Every current observation, candidate input and all phase hashes are retained losslessly; no origin-ref compaction or pruning.','The old failed run remains FAILED and may only be used as independently audited prefix evidence.']}
p=L/'evidence/saved118_all_intent_cap_measurement_v1.json';b=(json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode();r=h['scope'].save('evidence',p.name,b);print(json.dumps({'status':'PASS','report':r,'max_compressed_bytes':report['max_compressed_bytes'],'recovered_failed_intent_bytes':recovered_compressed,'suffix':report['suffix']}))
