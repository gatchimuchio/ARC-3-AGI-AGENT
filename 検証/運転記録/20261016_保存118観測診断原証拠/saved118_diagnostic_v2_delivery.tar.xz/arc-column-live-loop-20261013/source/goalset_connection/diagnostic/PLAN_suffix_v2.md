# FAILED prefixの後続59観測: source/pure・別root gate待ち

元79324233はFAILEDのまま。実59観測、993Query、counter4887→5880、経験183。次intentは実Query前の保存上限8KiBで停止。全失敗成分と正常state5880を独立監査し、許可された一回のCtrl-Cでowner exit130。元記録を修正・削除・成功へ改称しない。

新nonceで原観測index59..117（59件）だけを診断する。前59件は再Queryせず、ゲーム解法には使わない。before全目標/全候補/負・未知/HOLDを同じ候補入口へ渡す。全originと全相hashをそのまま保持する。予算のためoriginを縮約しない。

開始stateは5355957B SHA90bd34cfeb8e5cfdda28760af8e7ce1f113ecd6362dac5c0936c98819a1cf3fb、counter5880。prefix_closure_v1は監査PASS7項目、真の監査exit0、owner exit130、全2113記録、元正常stateとのpairedcounter以外完全一致をjoinする。

厳密Query上界2567（残59の4+3*(N+S+1)を合計）。最大counter8447、通常stateの桁数不変。pure fixtureの767は実native件数ではない。

intent capのみ8→16KiB。全118×全1760候補/役割入力を同一型タグ・全phasehash・5880markersで純圧縮測定し、最大8360B、失敗intentの全型/全内容復元8352B。全量が16KiBに収まることを確認。reply112KiB/result512KiB/input32KiB/raw16MiB等の他capは不変。いずれか超過で完全なfailedcurrent/pending/正常stateを別成分として保持し停止する。

追加evidence800MiB/failure4MiB/source1MiB、L合計2048MiB/source16/evidence2000/failure32は据置。
- suffix2567×(intent16KiB+reply112KiB)
- result59×512KiB、input59×32KiB
- 正常state2×5355957B
- 個別失敗4×16MiB+metadata2MiB+state8MiB
- 補助32MiB、異常終端normal拡張3032651B
以上のsuffix専用保守上界は494221749B。全118で再計算した場合でも830912949B<800MiBだが、今回全118再実行を許可しない。
AS512MiB、compute7200/save3600/failure120秒、future3732MiB+diskfloor1024MiB/RAM4608+floor2048MiBを維持。

completion schemaはsaved59-suffix-candidate-diagnostic-completion-v1。frame_count59、原index59..117、実Query数、counter5880+実Query、all118_complete_claim=Falseを明示。prefix59+suffix59の全118達成は、原順/重複欠落なし/全raw/支持/反証/HOLD/二つのserial状態chainを独立監査した別summaryでのみ示す。元prefixのFAILEDを変えない。

native/SDK/Teach/Actionは禁止のまま。source/pureレビュー後、rootがこの診断suffixだけの新gateを発行するまで復元/実Queryはしない。live coordinatorは常時disabledのまま、診断返答のlive採否はFalse。
