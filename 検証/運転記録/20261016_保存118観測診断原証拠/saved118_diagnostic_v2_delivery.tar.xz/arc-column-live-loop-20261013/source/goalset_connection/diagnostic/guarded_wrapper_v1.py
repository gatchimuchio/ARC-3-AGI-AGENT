"""Saved-observation Query-only wrapper. No root release is created here.
Native entry is reachable only after exact external root gate + independent review.
The disabled harness/coordinator remain unchanged historical source files.
"""
import hashlib,json,os,resource,sys,time,types,traceback
from pathlib import Path
D=Path('/workspace/scratch/a94ff513b3af/arc-column-live-loop-20261013/source/goalset_connection/diagnostic');L=D.parents[2];M=1<<20
CONTRACT={'path':str(D/'disabled_contract_v1.json'),'bytes':7929,'sha256':'7c148119e5a7fb3c54ea1c77c7846206e24a763d6740acf8c22069b732b4bacd'}
ACTIVE=None

def require(ok,why):
 if ok is not True:raise PermissionError(why)
def digest(b):return hashlib.sha256(b).hexdigest()
def exact(a,b):
 if type(a)is not type(b):return False
 if isinstance(a,dict):return list(a)==list(b) and all(exact(a[k],b[k]) for k in a)
 if isinstance(a,list):return len(a)==len(b) and all(exact(x,y) for x,y in zip(a,b))
 return a==b
def read(r,cap=80*M):
 require(type(r)is dict and set(r)=={'path','bytes','sha256'},'exact FileRef schema')
 p=Path(r['path']);require(p.is_absolute() and not p.is_symlink() and type(r['bytes'])is int and 0<=r['bytes']<=cap,'absolute bounded FileRef')
 b=p.read_bytes();require(len(b)==r['bytes'] and digest(b)==r['sha256'],'exact FileRef bytes');return b

def validate_gate(g,contract,source_ref,now,review):
 require(type(g)is dict and g.get('schema')=='saved118-query-only-root-release-v1','gate schema')
 require(g.get('enabled')is True and g.get('root_authorized_native_Query_only')is True,'explicit root Query authorization')
 require(g.get('root_adopted_latest4887')is True,'root latest closure adoption')
 require(g.get('live_adoption')is False and g.get('diagnostic_only')is True,'diagnostic origin must not authorize Action')
 require(exact(g.get('source'),source_ref) and exact(g.get('contract'),CONTRACT),'source/contract exact gate')
 require(exact(g.get('baseline'),contract['baseline']) and g.get('baseline_counter')==4887 and type(g.get('baseline_counter'))is int,'exact latest baseline')
 require(exact(g.get('limits'),contract['limits']),'finite fixed Query/Teach/Action/SDK/resource limits')
 require(type(g.get('nonce'))is str and len(g['nonce'])==32 and all(x in '0123456789abcdef' for x in g['nonce']),'nonce')
 require(type(g.get('admission_deadline_epoch'))in (int,float) and type(now)in (int,float) and now<=g['admission_deadline_epoch'],'admission expiry')
 require(contract.get('enabled')is False and contract.get('runtime_authorized')is False,'immutable disabled source contract')
 require(review.get('status')=='PASS' and review.get('errors')==[],'independent source review PASS')
 checks=g.get('independent_review_required_fields')
 require(type(checks)is list and bool(checks) and len(set(checks))==len(checks) and all(type(k)is str and review.get('checks',{}).get(k)is True for k in checks),'all root-required independent checks')
 require(g.get('post_native_independent_support_audit_required')is True and g.get('next_fresh_requires_new_root_gate')is True,'native closure is not future fresh release')
 return True

def load(name,r):
 m=types.ModuleType(name);m.__file__=r['path'];sys.modules[name]=m;exec(compile(read(r),r['path'],'exec'),m.__dict__);return m

def admission(path,sha):
 p=Path(path);require(p.is_absolute(),'outer root gate path must be absolute')
 require(not p.is_symlink() and p.stat().st_size<=65536,'root gate bounded nonsymlink')
 raw=p.read_bytes();require(digest(raw)==sha,'root gate exact hash')
 g=json.loads(raw);contract=json.loads(read(CONTRACT));source=Path(__file__).read_bytes()
 source_ref={'path':str(Path(__file__).resolve()),'bytes':len(source),'sha256':digest(source)}
 review=json.loads(read(g['independent_source_review'],8*M))
 validate_gate(g,contract,source_ref,time.time(),review)
 for r in contract['source_pins']+contract['dependency_pins']:read(r)
 soft,hard=resource.getrlimit(resource.RLIMIT_AS);require(0<soft<=512*M and 0<hard<=512*M,'AS512 before native import')
 return g,contract,{'path':str(p),'bytes':len(raw),'sha256':sha},source_ref

def main(path,sha):
 global ACTIVE
 require(ACTIVE is None,'one serial admission per process')
 g,contract,gate_ref,source_ref=admission(path,sha)
 refs={Path(r['path']).name:r for r in contract['source_pins']}
 h=load('saved118_guarded_disabled_harness',refs['harness_disabled_v5.py'])
 cat=load('saved118_guarded_catalog',refs['catalog_v1.py'])
 h.scope.guard()
 run=None
 def permit():
  require(ACTIVE is not None and ACTIVE['gate']==gate_ref,'root gate capability absent')
  # Admission expiry is checked at admission; finite aggregate timers bound work.
  # Full hashes are rechecked before completion. No repeated native side effects.
  require(ACTIVE['source']==source_ref and ACTIVE['Query_only']is True,'source-bound Query capability')
 h.native_permission=permit
 class GuardedRun(h.Run):
  def __init__(self):super().__init__();self.native_error=None
  def _query_after_admission(self,external):
   if self.native_error is not None:raise RuntimeError('previous native failure latched')
   try:return super()._query_after_admission(external)
   except BaseException as e:
    self.native_error=e
    # Legacy candidate diagnostics catch ValueError; native failures must escape
    # that catch so no subsequent candidate silently queries a corrupted state.
    raise RuntimeError('native Query/capture/state invariant failed') from e
 ACTIVE={'gate':gate_ref,'source':source_ref,'Query_only':True}
 try:
  # A used nonce fails before restore and cannot restart from an old baseline.
  for category in ('evidence','failure'):
   parent=L/category;require(parent.is_dir() and not parent.is_symlink(),'existing scope category')
   folder=parent/g['nonce'];folder.mkdir(exist_ok=False);h.fsyncdir(parent)
  run=GuardedRun();run.gate=g;run.clock.enter('compute')
  closure=run._initialize_after_admission(cat)
  run.input_closures.extend({'ref':r,'identity':h.identity(r['path'])} for r in [gate_ref,source_ref,CONTRACT,g['independent_source_review']]+contract['source_pins'])
  run.save('root_gate_and_latest_closure',{'root_gate':gate_ref,'source':source_ref,'contract':CONTRACT,'closure':closure,'diagnostic_only':True,'live採否可能':False},codec=False)
  receipt=run._execute_after_admission();run.clock.stop()
  print(json.dumps({'status':'complete','receipt':receipt,'Query':len(run.calls),'Teach':0,'Action':0,'SDK':0,'next_baseline':run.state_refs[-1],'live採否可能':False}),flush=True)
  return receipt
 except BaseException as e:
  if run is None:raise
  run.clock.stop();run.exceptions.append(e);run.errors.append({'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()})
  try:failure=run.preserve_failure_components()
  except BaseException as x:failure={'unsaved':True,'type':type(x).__name__,'message':str(x)}
  finally:run.clock.stop()
  print(json.dumps({'status':'failed_held','failure':failure,'errors':run.errors,'diagnostic_only':True,'live採否可能':False}),flush=True)
  # Retain the genuine in-flight objects until root completes recovery. No
  # further native calls, no replay, no automatic restart or old-state restore.
  while True:time.sleep(3600)

if __name__=='__main__':
 resource.setrlimit(resource.RLIMIT_AS,(512*M,512*M))
 require(len(sys.argv)==3,'absolute root gate path and exact SHA required')
 main(sys.argv[1],sys.argv[2])
