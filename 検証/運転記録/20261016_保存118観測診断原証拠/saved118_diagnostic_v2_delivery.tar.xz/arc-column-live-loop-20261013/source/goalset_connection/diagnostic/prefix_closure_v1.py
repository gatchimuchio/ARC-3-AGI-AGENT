"""Pure closure for terminated FAILED prefix59/Query993/latest5880. Never runs HDS."""
import copy,hashlib,json,lzma,types
from pathlib import Path
D=Path('/workspace/scratch/a94ff513b3af/arc-column-live-loop-20261013/source/goalset_connection/diagnostic')
REFS_FILE={'path':str(D/'resume_refs_v1.json'),'bytes':1887,'sha256':'c4d4e964a95f7a21ad91c4d121ae1ce8155cda3d7d853179087184f2751906b7'}
M=1<<20

def require(v,msg):
 if v is not True:raise ValueError(msg)
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(65536),b''):h.update(b)
 return h.hexdigest()
def read(r,cap=16*M):
 p=Path(r['path']);require(type(r['bytes'])is int and r['bytes']<=cap and not p.is_symlink() and p.stat().st_size==r['bytes'] and sha(p)==r['sha256'],'exact bounded prefix FileRef');return p.read_bytes()
REFS=json.loads(read(REFS_FILE))
def exact(a,b):
 if type(a)is not type(b):return False
 if isinstance(a,dict):return list(a)==list(b) and all(exact(a[k],b[k]) for k in a)
 if isinstance(a,list):return len(a)==len(b) and all(exact(x,y) for x,y in zip(a,b))
 return a==b
def packet(r):
 z=lzma.LZMADecompressor(memlimit=128*M);raw=z.decompress(read(r['file']),max_length=16*M+1)
 require(z.eof and not z.unused_data and z.check==lzma.CHECK_CRC64 and len(raw)==r['rawbytes'] and hashlib.sha256(raw).hexdigest()==r['rawsha256'],'prefix packet CRC/raw closure');return json.loads(raw)
def td(v):
 require(type(v)is dict and list(v)==['__辞書__'],'typed dictionary');return dict(v['__辞書__'])

def verify():
 report=json.loads(read(REFS['summary']));audit=json.loads(read(REFS['audit_tools']));native=json.loads(read(REFS['native_terminal_tools']))
 require(report['schema']=='independent-saved118-native-failed-prefix-audit-v1' and report['status']=='PASS_FAILURE_PREFIX' and report['errors']==[],'independent exact prefix audit')
 require(len(report['verified'])==7 and all(v is True for v in report['verified'].values()),'all7 prefix checks')
 require(report['nonce']=='793242337c714081b4f642f1e0db3663' and exact(report['latest_closed_state'],REFS['latest_state']),'prefix nonce/latest state')
 counts=report['counts'];require(all(counts[k]==v and type(counts[k])is int for k,v in {'Query':993,'Teach':0,'Action':0,'SDK':0,'frames':59,'unprocessed_frames':59,'experiences':183,'counter_before':4887,'counter_after':5880,'failed_intent_compressed_bytes':8352,'native_by_auditor':0,'restore_by_auditor':0}.items()),'prefix exact counts')
 require([f['ordinal']for f in report['frames']]==list(range(59)) and [q['ordinal']for q in report['all_queries']]==list(range(993)),'complete original prefix order')
 finalaudit=audit['polls'][-1];require(finalaudit.get('exit_code')==0 and json.loads(finalaudit['output'].splitlines()[0])['report']==REFS['summary'],'genuine independent exit0/report')
 require(audit['launch']['session_id']==72540 and all(p.get('session_id',72540)==72540 for p in audit['polls']),'audit session join')
 require(native['launch']['session_id']==20866 and native['polls'][-1].get('exit_code')==130 and native['polls'][-1]['chunk_id']=='9e854f','owner terminated authorized single interrupt')
 require(all(p.get('session_id',20866)==20866 for p in native['polls']),'native session join')
 failures=[]
 for p in native['polls']:
  for line in p.get('output','').splitlines():
   if line.startswith('{'):
    x=json.loads(line)
    if x.get('status')=='failed_held':failures.append(x)
 require(len(failures)==1 and exact(failures[0]['failure'],report['failure']),'genuine failure receipt join')
 failure=packet(report['failure']);require(failure['status']=='failed_held' and failure['unprocessed_suffix']==list(range(59,118)) and failure['returned_capture_calls']==failure['durably_receipted_Query']==993,'prefix FAILED and entire suffix')
 require(failure['live採否可能']is False and failure['actual_Query_delta_from_4887']==993 and exact(failure['state'],REFS['latest_state']),'no live permission/latest failure state')
 require(failure['pending_is_current']is True and failure['pending_name']=='api_000993_intent','failed before994th Query')
 require(packet(failure['components']['raw']) is None and packet(failure['components']['external_return']) is None,'no unsaved native return')
 for r in [failure['current_metadata'],failure['components']['input']]:packet(r)
 original=json.loads(read(REFS['original_state']));start=json.loads(read(report['states'][0]));latest=json.loads(read(REFS['latest_state']))
 require(exact(original,start),'prefix restored original4887 exact')
 expected=copy.deepcopy(original);ids=td(expected)['識別子状態']
 for p in ids['__辞書__']:
  if p[0] in ('照会','学習判定'):require(type(p[1])is int and p[1]==4887,'original paired counter');p[1]+=993
 require(exact(expected,latest),'all full state fields/type/order/history unchanged except993 paired counters')
 require(td(td(latest)['識別子状態'])['経験']==183,'experience183 is not level count')
 manifest=json.loads(read(REFS['manifest']));require(manifest['original_status']=='FAILED' and manifest['file_count']==2113 and len(manifest['files'])==2113,'all original files retained')
 require(len({r['path']for r in manifest['files']})==2113,'no duplicate original evidence refs')
 for r in manifest['files']:
  p=Path(r['path']);require(not p.is_symlink() and p.stat().st_size==r['bytes'] and sha(p)==r['sha256'],'all2113 original prefix file bytes unchanged')
 measurement=json.loads(read(REFS['cap_measurement']));require(measurement['status']=='PASS' and measurement['observations']==118 and measurement['all_synthetic_query_inputs']==1760 and measurement['max_compressed_bytes']==8360 and measurement['cap_bytes']==16384,'all118 full intent compression proof')
 require(measurement['suffix']['strict_Query_upper_bound']==2567 and measurement['suffix']['observations']==59,'suffix finite bound')
 return {'schema':'saved59-suffix-prefix-closure-v1','status':'PASS','runtime_authorized':False,'closed_state':REFS['latest_state'],'counter':5880,'experience_count':183,'prefix_status':'FAILED','prefix_observations':59,'prefix_queries':993,'suffix_ordinals':list(range(59,118)),'suffix_query_upper_bound':2567,'references':REFS,'original_file_manifest':REFS['manifest'],'all118_integration_required':True}
