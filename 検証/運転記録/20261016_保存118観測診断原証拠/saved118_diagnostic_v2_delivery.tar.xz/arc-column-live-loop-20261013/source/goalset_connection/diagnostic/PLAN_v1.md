# 保存観測全候補診断: source/pureのみ

native/restore/Query/Teach/SDK/Actionは未許可。main/preflight/executeは無条件拒否。
対象は確定教師packのPT59 + LS58の全117 before末相、および実失敗087b step90 currentの末相。教師Action・after成果は照会入力へ渡さない。全117を個別に再照会し、同一画素も統合しない。元公開応答の全相数・全画素hash・完全metadata・原票FileRef/行offset/hashを保持する。PT caseとLS analysisへ厳密joinし、再知覚/全poolを比較する。

## Query上界
各現在の在庫N、全枠Sについて4+3*(N+S+1)。役割/受理4、全構造候補ごと作用対応1、適格効果最大1、非空保存最大1。旧一意と集合を同じ候補へ重複照会しない。PT+LS合計4827、停止N8/S9の58、計4885。これは上限であり達成件数ではない。負予測・UNKNOWN・HOLD・未実行候補を省略しない。

## 確定上限予算
L source16MiB/evidence2000MiB/failure32MiB/total2048MiB内。追加source1MiB/evidence800MiB/failure4MiB。開始時source8556630/evidence894729208/failure16247695B。
- 4885組 intent8KiB + reply112KiBの個別圧縮ハード上限:600268800B
- 118全候補結果×512KiB:61865984B
- 118入力記録×32KiB:3866624B
- 通常状態2枚×5355957B:10711914B。counter4887→最大9772で桁数不変。異常時は次項へ。
- 失敗時個別raw/外部返却/現在入力の3個×16MiB、および異常正常形式state8MiB:58720256B（evidence内）
- completion/input closure/補助結果計32MiB:33554432B
- 計768988010B <800MiB=838860800B。差額69872790Bは追加画像や新native scopeに流用しない。
- failure4MiBは軽量manifest/trace/suffixのみ。巨大current heapを二重encodeしない。保存不能個別componentはprocess内に保持し、failed-heldのままrootへ報告。保存成功・全診断完了を捏造しない。

圧縮率は仮定しない。個別上限または全体上限超過は完全suffixを残すresource failure。切り詰め・candidate pruning・低解像度化は禁止。
AS512MiB、compute7200/save3600/failure120秒。global future3732MiB+diskfloor1024MiB、MemAvailable4608+2048MiB。各callの全状態をbaseline複製+pairedcounterだけとの差として検証する既存loop方式を再利用。start/endだけnormalstateを保存し、各call before/after markerとraw/externalを保持する。query原票は同じnormalstateを復元した実シリアルchainであり、診断originのlive採否可能=Falseを全記録に保持。

開始baselineはb6752d after_queries.standard.json5355957B SHA034f37fd76bf3f379db5ef71db9a285273ccbbdb4a3ac40796d101901abd5d29、経験183/counter4887。closure/latest_closed_state_v2.pyの実証joinを再利用。終了counterは4887+実Query数。終了normalstateが次freshの唯一baselineとなり、4887へ戻さない。終了baseline採用には別独立監査とroot gateが必要。
