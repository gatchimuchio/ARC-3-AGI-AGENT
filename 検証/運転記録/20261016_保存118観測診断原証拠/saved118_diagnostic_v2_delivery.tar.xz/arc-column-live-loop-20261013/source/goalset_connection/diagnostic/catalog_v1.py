"""118 saved public before observations; pure parsing/perception only. No native imports."""
import ast,base64,collections,copy,hashlib,itertools,json,lzma,sys,types
from pathlib import Path
D=Path('/workspace/scratch/a94ff513b3af/arc-column-live-loop-20261013/source/goalset_connection/diagnostic')
PINS=json.loads((D/'pins_v1.json').read_text())
M=1<<20

def require(v,msg):
 if v is not True:raise ValueError(msg)
def sha(b):return hashlib.sha256(b).hexdigest()
def jb(v):return json.dumps(v,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()
def exact(a,b):
 if type(a)is not type(b):return False
 if isinstance(a,dict):return list(a)==list(b) and all(exact(a[k],b[k]) for k in a)
 if isinstance(a,(tuple,list)):return len(a)==len(b) and all(exact(x,y) for x,y in zip(a,b))
 return a==b
def read(r):
 p=Path(r['path']);require(not p.is_symlink(),'symlink');b=p.read_bytes();require(len(b)==r['bytes'] and sha(b)==r['sha256'],'FileRef');return b
def untag(x):
 if isinstance(x,list):return [untag(v) for v in x]
 if isinstance(x,dict):
  if set(x)=={'__辞書__'}:return {untag(k):untag(v) for k,v in x['__辞書__']}
  if set(x)=={'__組__'}:return tuple(untag(v) for v in x['__組__'])
  if set(x) in ({'__データ型__','値'},{'__列挙__','値'}):return untag(x['値'])
  return {k:untag(v) for k,v in x.items()}
 return x
def packet(r):
 z=lzma.LZMADecompressor(memlimit=128*M);raw=z.decompress(read(r),max_length=16*M+1)
 require(z.eof and not z.unused_data and z.check==lzma.CHECK_CRC64 and len(raw)<=16*M,'packet CRC/EOF/raw cap');return untag(json.loads(raw))
def module(name,key):
 r=PINS[key];m=types.ModuleType(name);m.__file__=r['path'];sys.modules[name]=m;exec(compile(read(r),r['path'],'exec'),m.__dict__);return m
common=module('saved_diagnostic_common','common')
perception=module('saved_diagnostic_perception','perception')
boundary=module('saved_diagnostic_boundary','boundary')
# Same family definitions, removing all imports and non-pure action functions.
NAMES={'記号を読む','容器外形を観測する','図式を観測する','列を生成する','一致する','選択を読む','照会','内容候補を構成する'}
tree=ast.parse(read(PINS['family']));nodes=[copy.deepcopy(n) for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and (n.name in NAMES or n.name=='知覚不適用')]
# Injected external-input type is supplied only by a future gated native setup or pure fixture.
ns={'Counter':collections.Counter,'deepcopy':copy.deepcopy,'itertools':itertools,'成分群':perception.成分群,'役割境界':'公開列図式:記号外形と展開役割','目標境界':'公開列図式:有限全列または生産的反復の目標長一致と提出受理'}
exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),PINS['family']['path'],'exec'),ns)
family=types.SimpleNamespace(**ns)

def pixels(frame):
 require(type(frame)is list and len(frame)==64 and all(type(r)is list and len(r)==64 for r in frame),'frame64x64')
 require(all(type(v)is int and 0<=v<=15 for row in frame for v in row),'strict public pixels')
 return bytes(v for row in frame for v in row)

def before_public(data,sequence,reference):
 require(type(data)is dict and type(data.get('frame'))is list and bool(data['frame']),'whole response frames')
 hashes=[sha(pixels(f)) for f in data['frame']]
 normalized=copy.deepcopy(data)
 # Historical public recording uses these declared aliases; preserve both in evidence.
 aliases={}
 for old,new in [('score','levels_completed'),('win_score','win_levels')]:
  if old in normalized:
   require(type(normalized[old])is int and normalized[old]>=0,'historical counter type')
   if new in normalized:require(normalized[new]==normalized[old] and type(normalized[new])is int,'counter alias conflict')
   normalized[new]=normalized[old];aliases[old]=new
 current=boundary.観測する(normalized,観測通番=sequence)
 frame=data['frame'][-1];scene=family.図式を観測する(frame)
 try:selection={'selection':family.選択を読む(frame,scene)}
 except (ValueError,KeyError,TypeError) as e:selection={'selection':None,'selection_unknown':{'type':type(e).__name__,'message':str(e)}}
 n=len(scene['在庫群']);s=sum(len(b['枠群']) for b in scene['容器群'])
 metadata={k:copy.deepcopy(v) for k,v in data.items() if k!='frame'}
 origin={'公開観測参照':reference,'公開観測全体SHA256':reference['sha256'],'観測通番':sequence,'観測指紋':current.指紋,'ARC3境界観測指紋':current.指紋,'相':len(hashes)-1,'全相数':len(hashes),'末相':True,'画素SHA256':hashes[-1],'全相画素SHA256':hashes,'利用可能作用':list(current.作用可能番号),'公開状態':current.状態,'live採否可能':False,'診断のみ':True,'歴史公開field明示対応':aliases}
 return {'frame':frame,'actions':list(current.作用可能番号),'public_state':current.状態,'origin':origin,'metadata':metadata,'scene':scene,'selection':selection,'bound':4+3*(n+s+1),'structural_candidates':n+s+1}

def raw_lines(wanted):
 r=PINS['raw'];p=Path(r['path']);h=hashlib.sha256();out={};offset=0
 with p.open('rb') as f:
  for index,line in enumerate(f):
   h.update(line)
   if index in wanted:out[index]={'line':line,'offset':offset,'bytes':len(line),'sha256':sha(line)}
   offset+=len(line)
 require(offset==r['bytes'] and h.hexdigest()==r['sha256'],'original entire recording hash')
 require(set(out)==set(wanted),'all raw rows present');return out

def catalog():
 pack=json.loads(read(PINS['pack']));meas=json.loads(read(PINS['measurements']));analysis=json.loads(read(PINS['analysis']))
 require(len(pack['all117'])==117 and exact([c['measurement']for c in pack['all117']],meas['all117_before_and_all_after_measurements']),'all117 measurement exact join')
 require(exact(pack['raw_source'],PINS['raw']),'raw source ref join')
 wanted=[c['row']-1 for c in pack['all117']];raw=raw_lines(wanted);items=[]
 for ordinal,case in enumerate(pack['all117']):
  m=case['measurement'];row=case['row'];r=raw[row-1];data=json.loads(r['line'])['data']
  rawref={**PINS['raw'],'row':row-1,'offset':r['offset'],'row_bytes':r['bytes'],'row_sha256':r['sha256']}
  item=before_public(data,ordinal,rawref)
  if case['source']=='PT':
   saved=packet(m['case_ref']);envelope=saved['全pool包絡'];obs=saved['教師候補観測'];old=obs['全前相'][-1]
   require(envelope['before_row']==row-1 and envelope['action_row']==row,'PT row join')
   rr=envelope['raw_row'];require(rr=={'offset':r['offset'],'bytes':r['bytes'],'sha256':r['sha256']},'PT exact raw line join')
   require(envelope['phase']==len(data['frame'])-1 and envelope['frame_sha256_uint8']==item['origin']['画素SHA256'],'PT terminal phase/hash')
   scene=old['scene'];selected=old.get('selection');pool=envelope['goal_pool']
   source_ref=m['case_ref']
  else:
   ar=m['all_pool_reference'];previous=analysis['全行'][ar['row_index']-1];ph=previous['全相'][-1]
   require(previous['行']==row-1 and previous['byte_offset']==r['offset'] and previous['bytes']==r['bytes'] and previous['lineSHA256']==r['sha256'],'LS exact raw row join')
   require(ph['相']==len(data['frame'])-1 and ph['画素SHA256']==item['origin']['画素SHA256'],'LS terminal phase/hash')
   stored=analysis['全場面候補集合'][ar['before_scene_key']];scene=stored['場面'];selected=ph['測定'].get('在庫選択');pool=common.goalset_pool(scene,{False:'出力',True:'参照'});source_ref=PINS['analysis']
  require(exact(item['scene'],scene) and exact(item['selection']['selection'],selected) and exact(selected,m['selected_before']),'raw perception/selection same as source')
  recomputed=common.goalset_pool(item['scene'],{False:'出力',True:'参照'})
  for k in ('状態','候補数','全数確認した相異なる割当数','候補','不採用理由集計','実行許可'):require(exact(recomputed[k],pool[k]),'all goal pool join '+k)
  require(recomputed['候補数']==m['pool'],'117 measured pool count')
  item.update({'ordinal':ordinal,'label':{'source':case['source'],'row':row},'source_evidence':source_ref,'expected_pool':recomputed})
  # The teacher Action and outcome do not appear in item or solver arguments.
  items.append(item)
 stop=packet(PINS['stop_intent']);saved=packet(PINS['stop_semantic']);public=json.loads(read(PINS['stop_public']))
 require(exact(stop['origin']['公開観測参照'],PINS['stop_public']),'actual stop intent-public join')
 frames=[]
 for f in public['frames']:
  b=base64.b64decode(f['base64'],validate=True)
  require(f['dtype']=='|i1' and f['order']=='C' and f['shape']==[64,64] and len(b)==4096 and sha(b)==f['sha256'],'stop all raw phase bytes')
  frames.append([list(b[i:i+64]) for i in range(0,4096,64)])
 require(public['frame_count']==len(frames),'stop full phase count');data=copy.deepcopy(public['model_json']);data['frame']=frames
 item=before_public(data,stop['origin']['観測通番'],PINS['stop_public'])
 require(item['origin']['観測指紋']==stop['origin']['観測指紋'] and item['origin']['相']==stop['origin']['相'],'actual stopping current exact fingerprint')
 require(exact(item['scene'],saved['場面']) and exact(item['selection'],saved['選択観測']),'stop new perception exact')
 pool=common.goalset_pool(item['scene'],{False:'出力',True:'参照'})
 for k in ('状態','候補数','全数確認した相異なる割当数','候補','不採用理由集計','実行許可'):require(exact(pool[k],saved['全目標pool'][k]),'stop whole goal pool')
 require(pool['候補数']==5 and pool['全数確認した相異なる割当数']==5040 and item['bound']==58,'stop5goal bound')
 item.update({'ordinal':117,'label':{'source':'actual_stopping_current','step':90},'source_evidence':PINS['stop_intent'],'expected_pool':pool});items.append(item)
 require(len(items)==118 and sum(x['bound'] for x in items)==4885,'exact118/4885')
 return items
