"""Gate validation only: never creates an enabled gate or calls main/admission."""
import ast,copy,hashlib,json,resource,runpy,sys
from pathlib import Path
resource.setrlimit(resource.RLIMIT_AS,(512<<20,512<<20))
D=Path('/workspace/scratch/a94ff513b3af/arc-column-live-loop-20261013/source/goalset_connection/diagnostic');s=runpy.run_path(str(D/'guarded_wrapper_v2.py'))
c=json.loads(s['read'](s['CONTRACT']));sr={'path':'/synthetic-pure-only/source','bytes':0,'sha256':'0'*64};review={'schema':'synthetic-independent-review','status':'PASS_SOURCE_PURE_ONLY','checks':{'all':True}}
g={'schema':'saved118-query-only-root-release-v1','enabled':True,'root_authorized_native_Query_only':True,'root_adopted_latest4887':True,'live_adoption':False,'diagnostic_only':True,'source':sr,'contract':s['CONTRACT'],'baseline':c['baseline'],'baseline_counter':4887,'limits':c['limits'],'nonce':'a'*32,'admission_deadline_epoch':200,'independent_review_required_fields':['all'],'independent_review_expected_status':'PASS_SOURCE_PURE_ONLY','independent_review_expected_schema':'synthetic-independent-review','post_native_independent_support_audit_required':True,'next_fresh_requires_new_root_gate':True}
assert s['validate_gate'](g,c,sr,100,review) is True
checks=[]
def bad(name,mutate):
 x=copy.deepcopy(g);mutate(x)
 try:s['validate_gate'](x,c,sr,100,review)
 except (PermissionError,ValueError,TypeError):checks.append(name);return
 raise AssertionError(name)
for key in ('enabled','root_authorized_native_Query_only','root_adopted_latest4887','diagnostic_only','post_native_independent_support_audit_required','next_fresh_requires_new_root_gate'):
 bad(key+'_false',lambda x,k=key:x.__setitem__(k,False));bad(key+'_int',lambda x,k=key:x.__setitem__(k,1))
for val in (True,None,0):bad('live_false_'+str(val),lambda x,v=val:x.__setitem__('live_adoption',v))
for key in ('source','contract','baseline'):bad(key+'_tamper',lambda x,k=key:x[k].__setitem__('sha256','f'*64))
for val in (4886,4888,True,'4887'):bad('baseline_counter_'+str(val),lambda x,v=val:x.__setitem__('baseline_counter',v))
for k in c['limits']:bad('limit_'+k,lambda x,k=k:x['limits'].__setitem__(k,x['limits'][k]+1))
for val in (99,float('inf'),float('nan'),True,'200'):bad('deadline_'+str(val),lambda x,v=val:x.__setitem__('admission_deadline_epoch',v))
for val in ('a'*31,'A'*32,'g'*32,None):bad('nonce_'+str(val),lambda x,v=val:x.__setitem__('nonce',v))
for val in ([],['missing'],['all','all']):bad('review_checks_'+str(val),lambda x,v=val:x.__setitem__('independent_review_required_fields',v))
bad('review_status',lambda x:x.__setitem__('independent_review_expected_status','COMPLETE'));bad('review_schema',lambda x:x.__setitem__('independent_review_expected_schema','wrong'))
# Type/AST only: restoring and SDK never entered by pure tests.
assert not any(k.startswith('hds学習系統') or k=='arcengine' for k in sys.modules)
t=ast.parse((D/'guarded_wrapper_v2.py').read_text());assert not any(isinstance(n,ast.Import) and any(a.name in ('arcengine','arc_agi') for a in n.names) for n in ast.walk(t))
# Immutable disabled harness is still independently refusing.
h=runpy.run_path(str(D/'harness_disabled_v5.py'))
try:h['main']()
except PermissionError:checks.append('disabled_harness_still_refuses')
else:raise AssertionError('disabled mutated')
report={'schema':'saved118-guarded-wrapper-pure-v1','status':'PASS','errors':[],'checks':checks,'count':len(checks),'native':0,'restore':0,'Query':0,'Teach':0,'SDK':0,'Action':0,'enabled_gate_created':False,'synthetic_in_memory_gate_only':True,'wrapper_source':{'path':str(D/'guarded_wrapper_v2.py'),'bytes':(D/'guarded_wrapper_v2.py').stat().st_size,'sha256':hashlib.sha256((D/'guarded_wrapper_v2.py').read_bytes()).hexdigest()},'contract':s['CONTRACT']}
b=(json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode();r=h['scope'].save('evidence','saved118_guarded_wrapper_pure_report_v1.json',b);print(json.dumps({'status':'PASS','report':r,'checks':len(checks)}))
