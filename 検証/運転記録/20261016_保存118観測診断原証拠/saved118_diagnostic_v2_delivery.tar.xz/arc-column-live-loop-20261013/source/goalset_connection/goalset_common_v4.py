"""集合境界の純前提・固定列挙。native/SDK/ゲーム実装をimportしない。"""
import ast
from collections import Counter
from copy import deepcopy
import hashlib
import itertools
from pathlib import Path
import types

FAMILY={'path':'/workspace/scratch/a94ff513b3af/arc-current-family-source-20261013/接続/列図式規則.py','bytes':20302,'sha256':'d303b314446d22c604008d590636cccf6e1d140fbd365f22ff018b55d97de399'}
LEGACY={'path':'/workspace/scratch/a94ff513b3af/arc-column-candidate-query-20261013/source/candidate_preservation_v1.py','bytes':12814,'sha256':'a57f0490be3c186a072e9e80f41072581c3ecbfc7ef3aaae49283558281799f3'}
REPAIR_BOUNDARY='公開列図式・成立可能目標集合非空・在庫選択済み実空欄クリックの末相可解性保持修復'
REPAIR_INPUT='実対象割当と整合する成立可能目標がある'
REPAIR_RESULT='応答末相で不足枠が減少し成立可能目標が残った'
PREP_BOUNDARY='公開列図式・成立可能目標集合非空・可視在庫未選択・既学習クリック作用の在庫選択準備'
PREP_INPUT='実クリック対象は利用可能な在庫対象である'
PREP_RESULT='応答全相で実クリック在庫対象が選択表示された'
PRESERVE_BOUNDARY='公開列図式・成立可能目標集合非空・既充填枠非空・未選択実在庫または選択済実空欄クリックの全相充填保存'
PRESERVE_INPUT='実操作種別'
PRESERVE_RESULT='応答全相で操作前の全充填枠が保存された'
CLASSES=('可視在庫未選択時の実在庫クリック','可視在庫選択時の実空欄クリック')
BASE_KEYS=('全目標候補','全充填枠','全空欄','全枠対応','非空目標集合確認')

def exact(a,b):
    if type(a)is not type(b):return False
    if isinstance(a,dict):return list(a)==list(b) and all(exact(a[k],b[k]) for k in a)
    if isinstance(a,(list,tuple)):return len(a)==len(b) and all(exact(x,y) for x,y in zip(a,b))
    return a==b

def require(v,reason):
    if not v:raise ValueError('集合境界: '+reason)

def read_pin(r):
    p=Path(r['path']);require(not p.is_symlink(),'依存symlink')
    b=p.read_bytes();require(len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256'],'依存FileRef差')
    return b

def load_pure(name,r):
    m=types.ModuleType(name);m.__file__=r['path']
    exec(compile(read_pin(r),r['path'],'exec'),m.__dict__)
    return m

legacy=load_pure('goalset_immutable_candidate_v1',LEGACY)

def _bind_fixed():
    tree=ast.parse(read_pin(FAMILY));names=('列を生成する','一致する')
    nodes=[deepcopy(n) for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
    require(len(nodes)==2,'固定列生成AST集合')
    original=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='内容候補を構成する')
    starts=[i for i,n in enumerate(original.body) if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='slots' for x in n.targets)]
    require(len(starts)==1 and isinstance(original.body[-1],ast.Return),'固定全単射AST境界')
    suffix=deepcopy(original.body[starts[0]:]);ret=suffix[-1].value
    keep=('状態','候補数','全数確認した相異なる割当数','候補','不採用理由集計','実行許可')
    pairs=[(k,v) for k,v in zip(ret.keys,ret.values) if isinstance(k,ast.Constant) and k.value in keep]
    require(tuple(k.value for k,v in pairs)==keep,'固定列挙結果schema')
    suffix[-1]=ast.Return(ast.Dict(keys=[k for k,v in pairs],values=[v for k,v in pairs]))
    args=ast.arguments(posonlyargs=[],args=[ast.arg(arg='scene'),ast.arg(arg='roles')],kwonlyargs=[],kw_defaults=[],defaults=[])
    nodes.append(ast.FunctionDef(name='_enumerate',args=args,body=suffix,decorator_list=[]))
    ns={'Counter':Counter,'itertools':itertools};exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),FAMILY['path'],'exec'),ns)
    return ns
_FIXED=_bind_fixed()

def goalset_pool(scene,roles):
    require(type(roles)is dict and set(roles)=={False,True} and all(type(k)is bool for k in roles),'現在役割bool全件')
    require(all(v in ('出力','参照') for v in roles.values()),'現在役割値')
    original=deepcopy(scene);result=_FIXED['_enumerate'](deepcopy(scene),deepcopy(roles))
    require(exact(scene,original),'全列挙入力変更')
    return result

def slot_map(scene):
    items=[s for b in scene['容器群'] for s in b['枠群']];out={}
    for s in items:
        require(type(s)is dict and type(s['位置'])is list and len(s['位置'])==2 and all(type(v)is int for v in s['位置']),'枠位置型')
        k=tuple(s['位置']);require(k not in out,'重複枠位置');out[k]=deepcopy(s['記号'])
    return out

def skeleton(scene):
    return {'目標列':deepcopy(scene['目標列']),'容器群':[{'色':b['色'],'位置':deepcopy(b['位置']),'起点':b['起点'],'枠群':[deepcopy(s['位置']) for s in b['枠群']]} for b in scene['容器群']]}

def token_key(t):
    require(type(t)is dict and set(t)=={'色','中空'} and type(t['色'])is int and type(t['中空'])is bool,'記号型')
    return (t['色'],t['中空'])

def goalset_base(scene,pool):
    require(type(pool)is list and len(pool)>0,'非空全目標集合')
    slots=slot_map(scene);empty=[k for k,t in slots.items() if t is None]
    for t in slots.values():
        if t is not None:token_key(t)
    inv=scene['在庫群'];require(type(inv)is list and len(inv)==len(empty),'全在庫/全空欄単射数')
    inventory=Counter(token_key(t['記号']) for t in inv)
    seen=set()
    for goal in pool:
        require(type(goal)is dict and type(goal['割当'])is list and type(goal['列生成'])is dict,'全目標schema')
        assigned={}
        for a in goal['割当']:
            require(type(a)is dict and set(a)=={'位置','色','中空'} and type(a['位置'])is list and len(a['位置'])==2 and all(type(x)is int for x in a['位置']),'割当schema')
            k=tuple(a['位置']);require(k in empty and k not in assigned,'空欄への一意割当')
            t={'色':a['色'],'中空':a['中空']};token_key(t);assigned[k]=t
        require(set(assigned)==set(empty),'全空欄割当欠損')
        require(Counter(token_key(t) for t in assigned.values())==inventory,'在庫全単射差')
        serial=tuple((k,token_key(assigned[k])) for k in empty);require(serial not in seen,'重複目標割当');seen.add(serial)
        require(goal['列生成'].get('出力列')==scene['目標列'],'目標出力列差')
    return {'全目標候補':deepcopy(pool),'全充填枠':[{'位置':list(k),'現在記号':deepcopy(t)} for k,t in slots.items() if t is not None],
            '全空欄':[list(k) for k in empty],'全枠対応':[{'位置':list(k),'現在記号':deepcopy(t)} for k,t in slots.items()], '非空目標集合確認':True}

def hit(pos,pt):
    return len(pt)==2 and all(type(x)is int for x in pt) and pos[0]-1<=pt[0]<pos[0]+5 and pos[1]-1<=pt[1]<pos[1]+5

def goalset_preconditions(scene,selection,pool,action):
    out=goalset_base(scene,pool);slots=slot_map(scene);inv=scene['在庫群']
    require(type(selection)is dict and type(action)is dict,'選択/作用schema')
    known='selection'in selection and 'selection_unknown'not in selection;selected=selection.get('selection')
    visible=known and selected is not None and sum(exact(selected,t) for t in inv)==1
    out.update({'選択対応確認':bool(known and (selected is None or visible)),'実対象区分':None,'実対象':None,'実対象一意':False,
                '修復適格':False,'修復入力':None,'準備適格':False,'準備入力':None,'保存操作区分':None})
    data=action.get('data',{});num=action.get('id');pt=(data.get('x'),data.get('y')) if type(data)is dict else (None,None)
    if type(num)is not int or num!=6 or not all(type(v)is int and 0<=v<64 for v in pt):return out
    hits=[('在庫',t) for t in inv if hit(t['位置'],pt)]
    hits += [('実空欄' if t is None else '既充填枠',{'位置':list(k),'記号':deepcopy(t)}) for k,t in slots.items() if hit(k,pt)]
    if known and selected is None and out['全空欄'] and len(hits)<=1:
        out['準備適格']=True;out['準備入力']=bool(len(hits)==1 and hits[0][0]=='在庫')
    if len(hits)!=1:return out
    kind,target=hits[0];out.update({'実対象区分':kind,'実対象':deepcopy(target),'実対象一意':True})
    prep=known and selected is None and bool(out['全空欄']) and kind=='在庫';repair=visible and kind=='実空欄'
    out['修復適格']=bool(repair)
    if prep:out['準備入力']=True;out['保存操作区分']=CLASSES[0]
    if repair:
        k=tuple(target['位置']);token=selected['記号']
        out['修復入力']=any(any(tuple(a['位置'])==k and exact({'色':a['色'],'中空':a['中空']},token) for a in goal['割当']) for goal in pool)
        out['保存操作区分']=CLASSES[1]
    return out
