"""b6752d29閉鎖状態の純粋な証拠結合。実行許可は常にFalse。
標準ライブラリだけを使い、保存済みJSONの型タグを保持する。
HDS/SDK/ゲームのimport、復元、Teach/Query/Actionを一切行わない。
"""
import hashlib
import json
import lzma
import os
from pathlib import Path
import resource
import shutil
import stat

B = Path('/workspace/scratch/a94ff513b3af')
L = B / 'arc-column-live-loop-20261013'
HERE = L / 'source/goalset_connection/closure'
M = 1 << 20
NONCE = 'b6752d29848b4a86990c441935ae5363'
RUNTIME_AUTHORIZED = False
SUMMARY = {'path':str(L/'evidence/independent_prepsave_b6752d29_summary_v1.json'),'bytes':2743610,'sha256':'a959ea48d12976ca5c1f336e22e787736138615966ffa90a4dc13a1ed0349b08'}
AUDIT_TOOLS = {'path':str(L/'evidence/independent_prepsave_b6752d29_actual_tools_v1.json'),'bytes':3689,'sha256':'451aaf9c644c545e1d45d9680a9b2d79cd26a036e7f6e3b616a1e58510e55e12'}
AUDITOR = {'path':str(L/'evidence/independent_prepsave_native_audit_v4.py'),'bytes':21382,'sha256':'9e8bb8ef0e3c5cd09205a6ef4e157bbb23fb75c267cf24cae49ac40286482e5f'}
VERIFIED = (
 'actual_terminal_exit0_and_prior_pre_native_launch_failure_preserved',
 'three_normal_states_all_old133_prefixes_and_only112_query_counter_changes',
 'all50_before_only_two_leaf_teachers_35_actions_all26_120_raw_phases_and_old62_plan',
 'all162_intent_raw_external_type_order_support_prediction_and_new_experience_joins',
 'new50_strict_complete_predictions_zero_uncertainty_and_old62_all8_semantic_fields',
 'preparation_forward_inverse_preservation_constant_fixed_supports_all_candidate_refutation_quarantine_evidence',
 'all_saved_packet_CRC_EOF_refs_core_bytes_and_file_identity_unchanged',
)
STATE_SCHEMAS = {
 '経験記録':('経験識別子','対象系境界','原入力','観測群','主体','対象','目的','時点'),
 '観測事実':('経路','値','値型','推論対象'),
 '懐疑記録':('懐疑識別子','経験参照','焦点','作用内容','参照経験群','時点','対象経路群','要求操作群','発火根拠'),
 '学習過程記録':('学習識別子','学習前状態版','学習後状態版','経験参照','懐疑参照群','推論候補参照群','採用原理参照群','再開放原理参照群','学習成立状態','時点','係争化原理参照群','状態変化理由群','対象系境界','主体参照','対象期間','学習前状態スナップショット','保持記憶参照群','更新記録参照群','観測限界','観測限界参照群'),
 '原理記録':('原理識別子','対象系境界','系譜識別子','版','状態','関係型','条件経路群','結果経路','対応表','対応値表','根拠参照群','反証参照群','適用範囲','再開放条件','時点','親原理参照','改訂理由','除外反証参照群','解決理由','解決主体','採用状態'),
}
ENUMS = {'学習成立状態':{'成立確認','接続途上'},'原理状態':{'適用範囲付き暫定原理'},'採用状態':{'有効'}}
COUNTS = {'Teach':50,'Query':112,'Action':0,'native_API_by_auditor':0,'machine_restore_by_auditor':0,'experience_before':133,'experience_after':183,'counter_before':4775,'counter_after':4887,'distinct_source_actions':35,'overlap':15,'raw_preparation_phases':26,'raw_preservation_phases':120,'regressions':{'new_query':{'correct':50,'wrong':0,'missing':0,'extra':0,'HOLD':0},'old62_regression':{'correct':62,'wrong':0,'missing':0,'extra':0,'HOLD':0}}}

class ClosureError(ValueError):
    pass

def require(condition, reason):
    if condition is not True:
        raise ClosureError(reason)

def same(a, b):
    if type(a) is not type(b): return False
    if type(a) is dict:
        return list(a) == list(b) and all(same(a[k], b[k]) for k in a)
    if type(a) is list:
        return len(a) == len(b) and all(same(x,y) for x,y in zip(a,b))
    return a == b

def digest(data): return hashlib.sha256(data).hexdigest()

def pairs_unique(pairs):
    result = {}
    for k,v in pairs:
        require(type(k) is str and k not in result,'JSON duplicate/non-string key')
        result[k] = v
    return result

def loads(data):
    def reject(value): raise ClosureError('JSON non-finite value: '+value)
    return json.loads(data, object_pairs_hook=pairs_unique, parse_constant=reject)

def td(value):
    require(type(value) is dict and list(value)==['__辞書__'] and type(value['__辞書__']) is list,'tagged dictionary')
    for pair in value['__辞書__']:
        require(type(pair) is list and len(pair)==2,'tagged dictionary pair')
    return pairs_unique(value['__辞書__'])

def ts(value):
    require(type(value) is dict and list(value)==['__組__'] and type(value['__組__']) is list,'tagged tuple')
    return value['__組__']

def record(value, name):
    require(type(value) is dict and list(value)==['__データ型__','値'] and value['__データ型__']==name and type(value['値']) is dict,'record '+name)
    return value['値']

def typed_state(value):
    if value is None or type(value) in (str,int,bool): return
    if type(value) is list:
        for v in value: typed_state(v)
        return
    require(type(value) is dict,'state scalar type')
    if list(value)==['__辞書__']:
        for v in td(value).values(): typed_state(v)
    elif list(value)==['__組__']:
        for v in ts(value): typed_state(v)
    elif list(value)==['__データ型__','値']:
        name=value['__データ型__']
        require(name in STATE_SCHEMAS and type(value['値']) is dict and tuple(value['値'])==STATE_SCHEMAS[name],'state record fields/type')
        for v in value['値'].values(): typed_state(v)
    elif list(value)==['__列挙__','値']:
        require(type(value['__列挙__']) is str and value['__列挙__'] in ENUMS and value['値'] in ENUMS[value['__列挙__']],'state enum type/value')
    else: raise ClosureError('unknown state tag or raw mapping')

def safe_path(path):
    require(type(path) is str,'FileRef path type')
    p=Path(path)
    require(p.is_absolute() and str(p)==path and '..' not in p.parts and p.is_relative_to(B),'FileRef outside workspace')
    for ancestor in [p,*p.parents]:
        require(not ancestor.is_symlink(),'symlink in evidence path')
        if ancestor==B: break
    return p

def identity(st): return (st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns)

def ref_schema(ref):
    require(type(ref) is dict and set(ref)=={'path','bytes','sha256'},'FileRef schema')
    require(type(ref['bytes']) is int and 0<=ref['bytes']<=128*M,'FileRef byte range/type')
    h=ref['sha256']; require(type(h) is str and len(h)==64 and all(x in '0123456789abcdef' for x in h),'FileRef SHA256')

class Reader:
    def __init__(self): self.seen={}
    def exact(self, ref, retain=True):
        ref_schema(ref); p=safe_path(ref['path']); before=p.stat()
        require(stat.S_ISREG(before.st_mode) and before.st_size==ref['bytes'],'FileRef size/type')
        require(not retain or before.st_size<=16*M,'retained input bound')
        fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW); h=hashlib.sha256(); blocks=[]; count=0
        try:
            require(identity(os.fstat(fd))==identity(before),'FileRef open identity')
            while True:
                block=os.read(fd,1*M)
                if not block: break
                count+=len(block); require(count<=ref['bytes'],'FileRef grew')
                h.update(block)
                if retain: blocks.append(block)
            require(identity(os.fstat(fd))==identity(before),'FileRef changed while read')
        finally: os.close(fd)
        require(identity(p.stat())==identity(before) and count==ref['bytes'] and h.hexdigest()==ref['sha256'],'FileRef bytes/hash/identity')
        old=self.seen.get(str(p))
        require(old is None or same(old['ref'],ref) and old['identity']==identity(before),'conflicting/replaced FileRef')
        self.seen[str(p)]={'ref':dict(ref),'identity':identity(before)}
        return b''.join(blocks) if retain else None
    def json(self,ref): return loads(self.exact(ref))
    def packet(self,ref):
        require(type(ref) is dict and set(ref)=={'file','rawbytes','rawsha256'},'packet schema')
        require(type(ref['rawbytes']) is int and 0<=ref['rawbytes']<=16*M,'packet raw limit/type')
        compressed=self.exact(ref['file']); dec=lzma.LZMADecompressor(format=lzma.FORMAT_XZ,memlimit=64*M)
        try: raw=dec.decompress(compressed,max_length=ref['rawbytes']+1)
        except lzma.LZMAError as exc: raise ClosureError('packet XZ/CRC') from exc
        require(dec.eof and not dec.unused_data and len(raw)==ref['rawbytes'] and digest(raw)==ref['rawsha256'],'packet CRC/EOF/raw pin')
        return loads(raw)
    def unchanged(self):
        for item in list(self.seen.values()): self.exact(item['ref'],False)


def resource_guard(extra=0):
    require(type(extra) is int and 0<=extra<1*M,'small source output budget')
    caps={'source':16*M,'evidence':2000*M,'failure':32*M}; used={}
    for category,cap in caps.items():
        root=L/category; require(not root.is_symlink(),'resource directory symlink'); n=0
        for p in root.rglob('*'):
            require(not p.is_symlink(),'resource file symlink')
            if p.is_file(): n+=p.stat().st_size
        used[category]=n
        require(n+(extra if category=='source' else 0)<=cap,'resource category '+category)
    require(sum(used.values())+extra<=2048*M,'resource total 2048 MiB')
    disk=shutil.disk_usage(B).free
    mem=next(int(x.split()[1])*1024 for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:'))
    require(disk>=(3732+1024)*M+extra,'future disk reserve + floor')
    require(mem>=(4608+2048)*M,'full runtime RAM reserve + floor')
    return {'used_bytes':used,'disk_free_bytes':disk,'MemAvailable_bytes':mem,'limits_MiB':{'total':2048,'source':16,'evidence':2000,'failure':32,'future_disk':3732,'disk_floor':1024,'RAM_reserve':4608,'RAM_floor':2048,'pure_AS':512}}


def check_summary(s):
    require(s['schema']=='column-goalset-prepsave-independent-audit-v1' and s['nonce']==NONCE and s['status']=='PASS' and same(s['errors'],[]),'independent summary header')
    require(tuple(s['verified'])==VERIFIED and all(v is True for v in s['verified'].values()),'exact seven independent verified fields')
    require(same(s['counts'],COUNTS) and type(s['actual_exit']) is int and s['actual_exit']==0,'independent counts/exit')


def terminal(launch,polls,session,launch_chunk,terminal_chunk):
    require(type(launch) is dict and type(polls) is list and bool(polls),'real launch/polls')
    require(type(launch.get('session_id')) is int and launch['session_id']==session and launch.get('chunk_id')==launch_chunk and 'exit_code' not in launch,'real launch session')
    all_events=[launch,*polls]
    for event in all_events[:-1]:
        require(event.get('session_id')==session and type(event.get('session_id')) is int and 'exit_code' not in event and event.get('output')=='','nonterminal session continuity')
    final=all_events[-1]
    require(final.get('chunk_id')==terminal_chunk and type(final.get('exit_code')) is int and final['exit_code']==0 and 'session_id' not in final,'unique final tool exit')
    lines=[]
    for line in final['output'].splitlines():
        try: item=loads(line)
        except (ValueError,TypeError): continue
        if type(item) is dict: lines.append(item)
    require(len(lines)==1,'unique terminal JSON receipt')
    return lines[0]


def check_tools(s,native,audit,reader):
    require(native['schema']=='prepsave-native-actual-tools-v1' and native['nonce']==NONCE and native['status']=='complete' and native['automatic_retry'] is False,'native header')
    require(type(native['actual_exit']) is int and native['actual_exit']==0,'native actual exit')
    n=terminal(native['launch'],native['polls'],53211,'856334','fc1643')
    require(same(n,{'status':'complete','receipt':s['completion'],'Teach':50,'Query':112,'Action':0}),'native final receipt/status/counts')
    require(same(native['prior_failures'],s['prior_launch_failures']) and len(s['prior_launch_failures'])==2,'native previous failures retained')
    for ref in s['prior_launch_failures']: reader.exact(ref,False)
    require(audit['schema']=='column-prepsave-independent-actual-tools-v1' and type(audit['actual_exit']) is int and audit['actual_exit']==0 and type(audit['native_API']) is int and audit['native_API']==0,'audit tools header')
    runs=audit['runs'];require(type(runs) is list and len(runs)==3,'audit three runs including failures')
    for run,version in zip(runs[:2],('v2','v3')):
        require(run['source']==version and type(run['launch']['exit_code']) is int and run['launch']['exit_code']==1 and run['polls']==[],'prior audit failure preserved')
        failure=loads(run['launch']['output'].splitlines()[0]);require(failure['status']=='FAIL','prior audit failure status');reader.exact(failure['failure'],False)
    final=runs[-1];require(final['source']=='arc-column-live-loop-20261013/evidence/independent_prepsave_native_audit_v4.py','audit final source')
    a=terminal(final['launch'],final['polls'],7229,'312361','1f0a41')
    require(same(a,{'status':'PASS','report':SUMMARY,'counts':s['counts']}),'independent final report receipt')


def check_completion(s,c):
    require(c['schema']=='column-goalset-prepsave-completion-v1' and c['nonce']==s['nonce']==NONCE and c['status']=='complete' and same(c['errors'],[]),'completion header/nonce/status/errors')
    require(same(c['states'],s['states']) and len(c['states'])==3,'completion three state refs')
    expected={'teach_calls':50,'query_calls':112,'old_regression_queries':62,'new_queries':50,'Action':0,'new_clear':0,'paired_counter_before':4775,'paired_counter_after':4887}
    for k,v in expected.items(): require(type(c[k]) is int and c[k]==v,'completion '+k)
    require(c['old133_all_prefixes_unchanged'] is True and c['regression_pass'] is True and same(c['failed_scoring_indices'],[]),'completion regression/prefix flags')
    require(c['states'][0]['bytes']==3765619 and c['states'][0]['sha256']=='98c3acf28a9d893641135beb29c55b43e6c5d8f3d036e43c25698811f275a0ba','known 4775 baseline')
    require(c['states'][1]['bytes']==5355957 and c['states'][1]['sha256']=='7d209d71e199200f04011b4899bde53c83aaa3238625f5d2a8d0667350f8e7bc','trained full-state pin')
    require(c['states'][2]['bytes']==5355957 and c['states'][2]['sha256']=='034f37fd76bf3f379db5ef71db9a285273ccbbdb4a3ac40796d101901abd5d29','final full-state pin')


def state_snapshot(state):
    s=td(state);return {'__辞書__':[
      ['identifiers',s['識別子状態']],
      ['ledger_lengths',{'__辞書__':[[k,len(ts(v))] for k,v in td(s['台帳']).items()]}],
      ['principle_history_lengths',{'__辞書__':[[k,len(v)] for k,v in td(s['原理履歴']).items()]}],
      ['state_history_length',len(ts(s['状態履歴']))]]}


def check_states(s,states):
    for state in states: typed_state(state)
    old,trained,final=map(td,states)
    require(list(old)==list(trained)==list(final)==['形式版','最小支持数','最大条件数','識別子状態','台帳','状態履歴','原理履歴'],'state root fields')
    for key,val in (('形式版',3),('最小支持数',3),('最大条件数',2)):
        require(all(type(d[key]) is int and d[key]==val for d in (old,trained,final)),'state fixed setting '+key)
    oi,ti,fi=(td(d['識別子状態']) for d in (old,trained,final))
    require(oi['経験']==133 and ti['経験']==fi['経験']==183,'state experience counts')
    for key in ('照会','学習判定'): require(oi[key]==ti[key]==4775 and fi[key]==4887,'paired counter '+key)
    require(list(ti)==list(fi),'identifier field closure')
    for k in ti:
        require(type(ti[k]) is int and type(fi[k]) is int and fi[k]==ti[k]+(112 if k in ('照会','学習判定') else 0),'only audited counter effects '+k)
    for k in trained:
        if k!='識別子状態': require(same(trained[k],final[k]),'queries changed state '+k)
    ol,tl=td(old['台帳']),td(trained['台帳']);require(list(ol)==list(tl),'ledger field closure')
    deltas={'__辞書__':[]}
    for k in ol:
        before,after=ts(ol[k]),ts(tl[k]);require(same(after[:len(before)],before),'old ledger prefix '+k)
        deltas['__辞書__'].append([k,{'__組__':after[len(before):]}])
    require(same(deltas,s['new_ledger_entries']),'all and only independently audited new ledger effects')
    require(len(ts(ol['観測台帳']))==133 and len(ts(tl['観測台帳']))==183,'observed counts')
    oh,th=td(old['原理履歴']),td(trained['原理履歴']); changed=[]
    for k,vs in oh.items(): require(k in th and same(th[k][:len(vs)],vs),'old principle history prefix')
    for k,vs in th.items():
        require(type(vs) is list,'principle version sequence type');changed.extend(vs[len(oh.get(k,[])):])
    require(same(changed,s['changed_principles']) and len(changed)==3,'audited changed principle versions')
    history=ts(old['状態履歴']);require(same(ts(trained['状態履歴'])[:len(history)],history),'old state history prefix')
    observed={record(x,'経験記録')['経験識別子']:record(x,'経験記録') for x in ts(tl['観測台帳'])}
    require(len(observed)==183,'unique observed experiences')
    def support(v):
        if type(v) is dict:
            fields=td(v) if list(v)==['__辞書__'] else v
            for k,x in fields.items():
                if k in ('支持参照群','根拠参照群','反証参照群','除外反証参照群','経験参照群'):
                    require(all(type(r) is str and r in observed for r in ts(x)),'unobserved support/refutation reference')
                support(x)
        elif type(v) is list:
            for x in v:support(x)
    support(deltas)
    learned=[]
    for tag in changed:
        p=record(tag,'原理記録');refs=ts(p['根拠参照群'])
        require(type(p['版']) is int and p['版']==1 and len(refs)==3 and not ts(p['反証参照群']) and not ts(p['除外反証参照群']),'actual saved rule support/version/refutation')
        require(all(observed[r]['対象系境界']==p['対象系境界'] for r in refs),'support boundary join')
        learned.append({k:p[k] for k in ('原理識別子','版','対象系境界','関係型','条件経路群','結果経路','根拠参照群','反証参照群','除外反証参照群','採用状態')})
    return learned


def check_calls(c,states,reader):
    calls=c['api_calls'];require(type(calls) is list and len(calls)==162,'162 captured API calls')
    previous=state_snapshot(states[0]); trained_snapshot=state_snapshot(states[1]);final_snapshot=state_snapshot(states[2])
    observed=ts(td(td(states[1])['台帳'])['観測台帳'])
    for i,item in enumerate(calls):
        phase='new_teach' if i<50 else 'new_query' if i<100 else 'old62_regression';method='処理する' if i<50 else '照会する'
        require(type(item['ordinal']) is int and item['ordinal']==i and item['method']==method and item['phase']==phase,'captured API order')
        intent=td(reader.packet(item['intent']));reply=td(reader.packet(item['reply']))
        for k in ('ordinal','phase','frame_ordinal','method','input','origin','before'):require(same(intent[k],reply[k]),'intent/reply join '+k)
        require(reply['ordinal']==reply['frame_ordinal']==i and type(reply['ordinal']) is int and type(reply['frame_ordinal']) is int and reply['phase']==phase and reply['method']==method,'reply ordinal/phase/method')
        require(same(reply['before'],previous),'captured counter chain')
        before,after=td(reply['before']),td(reply['after']);bi,ai=td(before['identifiers']),td(after['identifiers'])
        require(list(bi)==list(ai) and all(type(v) is int for v in [*bi.values(),*ai.values()]),'API identifier schema/type')
        cap=td(reply['capture']);ret=record(cap['return'],'外部出力')
        if i<50:
            require(ai['経験']==bi['経験']+1 and all(ai[k]==bi[k] for k in ('照会','学習判定')),'Teach paired counter/experience change')
            exp=record(observed[133+i],'経験記録');input_value=record(reply['input'],'外部入力')
            require(same(exp['原入力'],input_value['内容']) and exp['対象系境界']==input_value['対象系境界'],'Teach new experience raw input')
            require(td(ret['追跡情報'])['経験参照']==exp['経験識別子'],'Teach external experience receipt')
        else:
            for k in bi:require(ai[k]==bi[k]+(1 if k in ('照会','学習判定') else 0),'Query only paired counter increment')
            for k in before:
                if k!='identifiers':require(same(before[k],after[k]),'Query unexpected state effect')
        previous=reply['after']
        if i==49:require(same(previous,trained_snapshot),'Teach terminal saved state join')
    require(same(previous,final_snapshot),'Query terminal saved state join')


def verify():
    resources=resource_guard();r=Reader();s=r.json(SUMMARY);check_summary(s);r.exact(AUDITOR,False)
    c=r.packet(s['completion']);check_completion(s,c)
    native=r.json(s['actual_tools']);audit=r.json(AUDIT_TOOLS);check_tools(s,native,audit,r)
    states=[r.json(ref) for ref in c['states']]
    baseline=r.exact(c['baseline_state']);require(baseline==r.exact(c['states'][0]),'exact restored baseline bytes')
    ba=r.json(c['baseline_audit']);require(ba['status']=='PASS' and same(ba['errors'],[]) and same(ba['states'][-1],c['baseline_state']) and bool(ba['verified']) and all(v is True for v in ba['verified'].values()),'previous independently closed state join')
    learned=check_states(s,states);check_calls(c,states,r)
    # Only hash the already audited dependency files; never import their contents.
    refs=s['references'];require(type(refs) is list and len(refs)==495,'independent reference closure count')
    for ref in refs:r.exact(ref,False)
    r.unchanged();resources_after=resource_guard()
    return {'schema':'goalset-latest-closed-state-pure-join-v1','status':'PASS','errors':[], 'nonce':NONCE,
      'closed_state_verified':True,'runtime_authorized':False,'enabled_gate':False,'coordinator_preflight':'unconditional_refusal_unchanged',
      'summary':SUMMARY,'audit_actual_tools':AUDIT_TOOLS,'auditor_source':AUDITOR,'completion':s['completion'],'native_actual_tools':s['actual_tools'],
      'closed_state':c['states'][-1],'baseline_state':c['baseline_state'],'counts':s['counts'],
      'required_verified_fields':list(VERIFIED),'verified_field_count':len(VERIFIED),
      'verified_count_note':'The exact pinned independent report has seven verified fields; no eighth field is invented.',
      'learned_rule_versions_from_actual_state':learned,
      'checks':{'native_real_terminal':True,'independent_real_terminal':True,'prior_failures_preserved':True,'three_full_state_bytes_and_typed_tags':True,'baseline4775_exact_join':True,'all_old133_prefixes':True,'all_and_only_audited_ledger_deltas':True,'all162_capture_counter_chains':True,'only112_paired_query_counter_changes':True,'saved_support_and_refutation_references':True,'all495_audited_file_refs':True,'all_read_files_rehashed_unchanged':True},
      'pure_operations':{'native_imports':0,'HDS_restores':0,'Teach':0,'Query':0,'Action':0,'SDK':0,'game_implementation_reads':0},
      'resources_before':resources,'resources_after':resources_after,
      'limitations':['This verifies the exact existing closure and its independent audit, not an authorization to execute.', 'No new support identifiers, teacher evidence, future predictions, or live feasibility claims are synthesized.','Fifty teachers came from 35 correlated historical public Actions with 15 cross-relation overlaps.','The independent auditor performed semantic/pixel checks; this join does not rerun that auditor or native learning.']}


def save_new(name,value):
    require(Path(name).name==name,'output basename')
    data=(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode();resource_guard(len(data))
    require(HERE.is_dir() and not HERE.is_symlink(),'output directory')
    path=HERE/name
    with path.open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
    fd=os.open(HERE,os.O_RDONLY)
    try:os.fsync(fd)
    finally:os.close(fd)
    require(path.read_bytes()==data,'output full readback');resource_guard()
    return {'path':str(path),'bytes':len(data),'sha256':digest(data)}


def main():
    resource.setrlimit(resource.RLIMIT_AS,(512*M,512*M))
    result=verify()
    print(json.dumps(result,ensure_ascii=False,allow_nan=False))

if __name__=='__main__':main()
