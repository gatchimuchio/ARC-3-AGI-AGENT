"""Read-only whole saved118 native diagnostic audit. No machine or native API."""
import resource
resource.setrlimit(resource.RLIMIT_AS,(512<<20,512<<20))
import ast,copy,dataclasses,hashlib,json,os,runpy,signal,sys,time,traceback,types
from pathlib import Path
B=Path('/workspace/scratch/a94ff513b3af');L=B/'arc-column-live-loop-20261013';S=L/'source/goalset_connection/diagnostic';M=1<<20
for p in sorted((B/'arc-recovery-authority-20261013').glob('Owner*.md')):p.read_bytes()
for p in ['AGENTS.md','運用/権限順序.md','制御/現在状態.json']:(B/'arc-recovery-main-20261013/repository'/p).read_bytes()
BASE=B/'arc-column-learning-audit-20261013/source/audit_v1.py';raw=BASE.read_bytes();assert hashlib.sha256(raw).hexdigest()=='e95c8a8307be21b9dc9981685fe84d2b41c0a8216b38f45361e47f4a0d267324'
exec(compile(raw.decode().split('def main():',1)[0],str(BASE),'exec'),globals())
L=B/'arc-column-live-loop-20261013';S=L/'source/goalset_connection/diagnostic';A=L
scope=runpy.run_path(str(L/'source/goalset_connection/resource_guard_v1.py'))
def out(name,v,category='evidence'):
 b=(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode();assert len(b)<=M
 return scope['save'](category,name,b)
def main():
 global enc,dec,CURSOR,D
 signal.signal(signal.SIGALRM,timeout);signal.alarm(600)
 receipt_raw=Path(sys.argv[1]).read_bytes();assert digest(receipt_raw)==sys.argv[2];receipt=js(receipt_raw)
 N=receipt['nonce'];assert N=='793242337c714081b4f642f1e0db3663';D=L/'evidence'/N;failure=packet(receipt['failure'],False);tool=js(exact(receipt['actual_tools']))
 assert failure['status']=='failed_held' and failure['durably_receipted_Query']==failure['returned_capture_calls']==failure['actual_Query_delta_from_4887']==993
 assert len(failure['saved_frames'])==59 and failure['unprocessed_suffix']==list(range(59,118)) and failure['live採否可能']is False
 def fileref(p):
  b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':digest(b)}
 def packetref(p):
  r=fileref(p);b=unpack(exact(r));return {'file':r,'rawbytes':len(b),'rawsha256':digest(b)}
 links=[{'ordinal':i,'frame':-1,'method':'照会する','intent':packetref(D/('api_%06d_intent.json.xz'%i)),'reply':packetref(D/('api_%06d_reply.json.xz'%i))} for i in range(993)]
 c={'nonce':N,'Query':993,'frames':failure['saved_frames'],'states':[fileref(D/'restored_before.standard.json'),failure['state']],'api_calls':links,'next_fresh_baseline':failure['state'],'final_paired_counter':5880,'full_state_only_paired_counters':True}

 terminals=[];exits=[]
 def scan(x):
  if isinstance(x,dict):
   if 'exit_code'in x and x['exit_code']is not None:exits.append(x['exit_code'])
   if isinstance(x.get('output'),str):
    for line in x['output'].splitlines():
     try:y=js(line)
     except (ValueError,TypeError):continue
     if isinstance(y,dict) and y.get('failure')==receipt['failure']:terminals.append(y)
   for v in x.values():scan(v)
  elif isinstance(x,list):
   for v in x:scan(v)
 scan({'launch':tool['launch'],'polls':tool.get('polls',[])})
 assert exits==[] and len(terminals)==1 and terminals[0]['status']=='failed_held'
 CHECKS['genuine_execution_failed_held_packet_join_no_terminal_exit_yet']=True
 contract=js(plain(S/'disabled_contract_v2.json'))
 for r in contract['source_pins']+contract['dependency_pins']:exact(r,80*M)
 sys.dont_write_bytecode=True;sys.path.insert(0,str(CORE))
 import hds学習系統.永続化 as codec
 from hds学習系統.型 import 外部出力,実行結果,学習成立状態,外部入力
 enc,dec=codec._符号化,codec._復号
 vf=runpy.run_path(str(L/'source/goalset_connection/verifier/final_adoption_goalset_v2.py'))
 states=[]
 for r in c['states']:
  b=exact(r);tag=js(b);value=dec(tag);assert same(enc(value),tag) and json.dumps(tag,ensure_ascii=False,indent=2).encode()==b;states.append(value)
 assert len(states)==2;initial,final=states
 assert exact(c['states'][0])==exact(contract['baseline'])
 expected=dec(enc(initial))
 for k in ('照会','学習判定'):
  assert initial['識別子状態'][k]==4887;expected['識別子状態'][k]+=c['Query']
 assert same(enc(expected),enc(final)) and len(final['台帳']['観測台帳'])==183 and final['識別子状態']['経験']==183
 assert c['next_fresh_baseline']==c['states'][-1] and c['final_paired_counter']==4887+c['Query'] and c['full_state_only_paired_counters']is True
 state=vf['復号'](enc(final));version=len(state['状態履歴'])-1;active,experiences=vf['状態を検査'](state,version)
 CHECKS['both_normal_states_full_type_order_only_paired_counters_and_latest_baseline']=True
 cat=runpy.run_path(str(S/'catalog_v1.py'));h=runpy.run_path(str(S/'harness_disabled_v7.py'));items=cat['catalog']();candidate=cat['module']('independent_native_audit_candidate','candidate');cat['ns']['外部入力']=外部入力
 codes=h['candidate_code_set'](candidate)
 exhaust=CORE/'hds学習系統/排気系.py';fn=next(n for n in ast.walk(ast.parse(exhaust.read_bytes()))if isinstance(n,ast.FunctionDef)and n.name=='排出する')
 ns={'asdict':dataclasses.asdict,'Any':object,'外部出力':外部出力,'実行結果':実行結果,'学習成立状態':学習成立状態};exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])),str(exhaust),'exec'),ns)
 last=None;ordinal=0;query_summary=[];support_patterns={};frames=[];files_expected={'root_gate_and_latest_closure.json.xz','restored_before.standard.json','failure_latest.standard.json','frame_059_input.json.xz','failure_component_input.json.xz','failure_component_raw.json.xz','failure_component_external_return.json.xz','failure_component_current_metadata.json.xz'}
 def markers(s,counter):
  ids=copy.deepcopy(s['識別子状態']);ids['照会']=ids['学習判定']=counter
  return {'identifiers':ids,'ledger_lengths':{k:len(v) for k,v in s['台帳'].items()},'principle_history_lengths':{k:len(v) for k,v in s['原理履歴'].items()},'state_history_length':len(s['状態履歴'])}
 for item,frame_ref in zip(items,c['frames']):
  frame=item['ordinal'];CURSOR='frame_'+str(frame);start=ordinal
  stored=packet(frame_ref);inp=pfile('frame_%03d_input.json.xz'%frame)
  assert same(enc(inp),enc({k:v for k,v in item.items()if k not in ('frame','scene','selection','expected_pool')}))
  assert stored['ordinal']==frame and same(enc(stored['origin']),enc(item['origin']))
  class Replay:
   owner=None
   def __init__(self):self.owner=self;self.bound=None
   def allow_frame(self,n):assert type(n)is int and n==item['bound'];self.bound=n
   def 照会する(self,external):
    nonlocal ordinal,last
    assert ordinal-start<self.bound and ordinal<c['Query']
    link=c['api_calls'][ordinal];link['frame']=frame;assert link['ordinal']==ordinal and link['method']=='照会する'
    it=packet(link['intent']);r=packet(link['reply'])
    assert set(it)=={'ordinal','frame','method','input','origin','before','capture'} and set(r)==set(it)|{'after'}
    for k in ('ordinal','frame','method','input','origin','before'):assert same(enc(it[k]),enc(r[k]))
    assert it['capture']=={} and same(enc(r['input']),enc(external))
    origin=h['current_origin'](item['origin'],external,codes,candidate.作用境界,{candidate.legacy.保存境界,candidate.common.PRESERVE_BOUNDARY})
    origin['復元状態参照']=contract['baseline'];origin['直前Query通番']=ordinal-1
    assert same(enc(origin),enc(r['origin'])) and origin['live採否可能']is False
    assert same(r['before'],markers(initial,4887+ordinal)) and same(r['after'],markers(initial,4888+ordinal))
    if last is not None:assert same(last,r['before'])
    last=r['after'];cap=r['capture'];assert cap['profile_restored']is True and len(cap['raw'])==len(cap['events'])==1
    event=cap['events'][0];assert event['function']=='排出する' and event['exact_code_self']is True and Path(event['filename'])==exhaust and event['firstlineno']==fn.lineno
    raw=cap['raw'][0];ret=cap['return'];assert same(enc(ns['排出する'](None,raw)),enc(ret))
    assert raw.現在状態版==version and raw.学習過程.学習前状態版==raw.学習過程.学習後状態版==version and raw.学習過程.学習成立状態.value=='適用外'
    plain=vf['復号'](enc(r));pr=plain['capture']['raw'][0];pe=plain['capture']['return']
    assert set(p['原理識別子']for p in pr['有効原理群'])==set(active)
    for p in pr['有効原理群']:
     assert vf['同値'](p,active[p['原理識別子']])
     assert all(e in experiences for e in p['根拠参照群']+p['反証参照群']+p['除外反証参照群'])
    holds={k:pr[k] for k in vf['不確実項目']}
    for k,v in holds.items():assert vf['同値'](v,pe['内容'][k])
    predictions=pr['予測群'];audited=[]
    for prediction in predictions:
     assert len(prediction['結果経路'])==1
     checked=vf['native照会を検査'](plain,state,version,external.対象系境界,external.内容,prediction['結果経路'][0],prediction['予測値'])
     pattern={'boundary':external.対象系境界,'facts':external.内容,'key':prediction['結果経路'][0],'value':prediction['予測値'],'supports':checked['支持']}
     key=digest(jb(pattern));support_patterns[key]=pattern;audited.append(key)
    query_summary.append({'ordinal':ordinal,'frame':frame,'candidate':origin['候補番号'],'purpose':origin['用途'],'state':ret.状態,'prediction_support_keys':audited,'whole_HOLD':holds})
    files_expected.update(Path(x['file']['path']).name for x in (link['intent'],link['reply']))
    ordinal+=1;return ret
   def ask(self,b,f):
    ret=self.照会する(外部入力(copy.deepcopy(f),b));return {'状態':ret.状態,'内容':ret.内容,'追跡情報':ret.追跡情報,'実照会保存参照':copy.deepcopy(c['api_calls'][ordinal-1])}
  replay=Replay();result=h['semantic_entry'](cat['family'],candidate,item['frame'],item['actions'],replay,replay.ask,item['public_state'])
  result['actual_API_count']=ordinal-start;result['phase_scope']={'診断のみ':True,'live採否可能':False,'相':item['origin']['相'],'全相数':item['origin']['全相数'],'末相':True}
  assert same(enc(result),enc(stored['result'])) and result['実行許可']is False
  full=result.get('全作用候補');frames.append({'ordinal':frame,'label':item['label'],'Query':ordinal-start,'bound':item['bound'],'goals':result['全目標pool']['候補数'],'candidate_count':len(full['全候補'])if full else 0,'whole_adoption':full['全体採否']if full else None,'all_candidate_effects':[x['効果状態']for x in full['全候補']]if full else []})
  if full:assert full['実行許可']is False and full['自動選択']is None
  files_expected.update(['frame_%03d_input.json.xz'%frame,Path(frame_ref['file']['path']).name])
 assert ordinal==c['Query']==len(c['api_calls']) and len(frames)==59
 CHECKS['all59_completed_exact_public_before_only_semantic_replay_full_candidate_order_and_HOLD']=True
 CHECKS['all_query_intent_raw_external_codec_exhaust_origin_markers_principles_support_refutation_whole_HOLD']=True
 root=pfile('root_gate_and_latest_closure.json.xz',False)
 for key in ('root_gate','source','contract'):exact(root[key])
 for r in contract['source_pins']+contract['dependency_pins']:exact(r,80*M)
 metadata=packet(failure['current_metadata']);external=packet(failure['components']['input']);assert packet(failure['components']['raw'])is None and packet(failure['components']['external_return'])is None
 assert metadata['ordinal']==993 and metadata['frame']==59 and metadata['method']=='照会する' and metadata['capture_metadata']=={} and 'after'not in metadata
 assert same(metadata['before'],markers(initial,5880)) and same(metadata['before'],last)
 assert failure['pending_name']=='api_000993_intent' and failure['pending_is_current']is True
 item=items[59];input_record=pfile('frame_059_input.json.xz');assert same(enc(input_record),enc({k:v for k,v in item.items()if k not in ('frame','scene','selection','expected_pool')}))
 expected_origin=copy.deepcopy(item['origin']);expected_origin.update({'候補番号':None,'用途':'目標pool','境界':external.対象系境界,'復元状態参照':contract['baseline'],'直前Query通番':992})
 assert same(enc(metadata['origin']),enc(expected_origin)) and len(item['origin']['全相画素SHA256'])==328
 assert external.対象系境界=='公開列図式:記号外形と展開役割' and same(external.内容,{'記号は中空':False})
 failed_current={k:v for k,v in metadata.items()if k!='capture_metadata'};failed_current['input']=external;failed_current['capture']={}
 # Reconstruct exact original insertion order for the refused complete intent.
 failed_current={k:failed_current[k]for k in ('ordinal','frame','method','input','origin','before','capture')}
 refused_bytes=len(lzma.compress(jb(enc(failed_current)),preset=0,check=lzma.CHECK_CRC64));assert refused_bytes>8192
 assert not (D/'api_000993_intent.json.xz').exists() and not (D/'api_000993_reply.json.xz').exists()
 assert failure['actual_identifiers_from_saved_normal']==final['識別子状態']
 CHECKS['failed_current_complete_metadata_input_empty_capture_counter5880_and_328phase_origin_recovered']=True
 CHECKS['failure_before994th_native_call_full_unprocessed59to117_suffix_preserved']=True
 assert set(p.name for p in D.iterdir()if p.is_file())==files_expected
 for p,i in IDENT.items():assert ident(Path(p))==i
 CHECKS['complete_files_manifest_and_all_input_source_identities_unchanged']=True
 result={'schema':'independent-saved118-native-failed-prefix-audit-v1','status':'PASS_FAILURE_PREFIX','errors':[],'nonce':N,'verified':CHECKS,'failure':receipt['failure'],'actual_tools':receipt['actual_tools'],'actual_exit':None,'states':c['states'],'latest_closed_state':c['next_fresh_baseline'],'counts':{'Query':c['Query'],'Teach':0,'Action':0,'SDK':0,'frames':59,'unprocessed_frames':59,'failed_intent_compressed_bytes':refused_bytes,'experiences':183,'counter_before':4887,'counter_after':c['final_paired_counter'],'prediction_support_patterns':len(support_patterns),'native_by_auditor':0,'restore_by_auditor':0},'frames':frames,'all_queries':query_summary,'support_patterns':support_patterns,'elapsed_seconds':time.monotonic()-START,'limitations':['Failed run remains failed-held, not a completed118 diagnostic; all59 completed observations and993 queries independently audited. All59 remaining observations must still be covered from5880.','All in-flight native evidence is fully recovered; root may authorize stopping retained owner without losing native data.','Diagnostic saved observations only; live adoption false throughout.','No new clear or transfer capability established.','Latest serial counter must be the next baseline; fresh execution requires a separate root gate.']}
 ref=out('independent_saved118_failure_prefix_summary_v1.json',result);signal.alarm(0);print(json.dumps({'status':'PASS','report':ref,'counts':result['counts']}),flush=True)
try:main()
except BaseException:
 signal.alarm(0);r=out('independent_saved118_failure_prefix_audit_failure_v1.json',{'status':'FAIL','cursor':CURSOR,'verified':CHECKS,'traceback':traceback.format_exc()});print(json.dumps({'status':'FAIL','failure':r}),flush=True);raise
