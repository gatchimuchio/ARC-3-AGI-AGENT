"""Integrate independently audited FAILED prefix and completed suffix. Read only."""
import resource
resource.setrlimit(resource.RLIMIT_AS,(512<<20,512<<20))
import hashlib,json,os,runpy,sys,traceback
from pathlib import Path
B=Path('/workspace/scratch/a94ff513b3af');L=B/'arc-column-live-loop-20261013';S=L/'source/goalset_connection/diagnostic'
for p in sorted((B/'arc-recovery-authority-20261013').glob('Owner*.md')):p.read_bytes()
for p in ['AGENTS.md','運用/権限順序.md','制御/現在状態.json']:(B/'arc-recovery-main-20261013/repository'/p).read_bytes()
def digest(b):return hashlib.sha256(b).hexdigest()
def read(r):
 p=Path(r['path']);b=p.read_bytes();assert not p.is_symlink() and len(b)==r['bytes']and digest(b)==r['sha256'];return b
def exact(a,b):
 if type(a)is not type(b):return False
 if isinstance(a,dict):return list(a)==list(b)and all(exact(a[k],b[k])for k in a)
 if isinstance(a,list):return len(a)==len(b)and all(exact(x,y)for x,y in zip(a,b))
 return a==b
def td(x):return dict(x['__辞書__'])
def main():
 raw=Path(sys.argv[1]).read_bytes();assert digest(raw)==sys.argv[2];r=json.loads(raw)
 closure=runpy.run_path(str(S/'prefix_closure_v1.py'))['verify']();p=json.loads(read(r['prefix_summary']));s=json.loads(read(r['suffix_summary']));tools=json.loads(read(r['suffix_audit_tools']))
 assert r['prefix_summary']==closure['references']['summary']and p['status']=='PASS_FAILURE_PREFIX'and p['errors']==[]and s['status']=='PASS'and s['errors']==[]
 assert all(x is True for x in p['verified'].values()) and all(x is True for x in s['verified'].values())
 assert s['schema']=='independent-saved59-native-suffix-audit-v1'and s['nonce']=='76fb30b532aa412bab83d5aa1cd6df23'and s['actual_exit']==0
 exits=[];matches=[]
 for x in [tools['launch']]+tools.get('polls',[]):
  if x.get('exit_code')is not None:exits.append(x['exit_code'])
  for line in x.get('output','').splitlines():
   try:v=json.loads(line)
   except(ValueError,TypeError):continue
   if isinstance(v,dict)and v.get('report')==r['suffix_summary']:matches.append(v)
 assert exits==[0]and len(matches)==1 and matches[0]['status']=='PASS'
 assert p['counts']['Query']==993 and p['counts']['counter_before']==4887 and p['counts']['counter_after']==s['counts']['counter_before']==5880
 assert p['counts']['frames']==s['counts']['frames']==59 and p['counts']['experiences']==s['counts']['experiences']==183
 total=p['counts']['Query']+s['counts']['Query'];end=s['counts']['counter_after'];assert end==4887+total
 for x in [p,s]:assert x['counts']['Teach']==x['counts']['Action']==x['counts']['SDK']==x['counts']['native_by_auditor']==x['counts']['restore_by_auditor']==0
 frames=p['frames']+s['frames'];assert [x['ordinal']for x in frames]==list(range(118))
 assert [x['ordinal']for x in p['all_queries']]==list(range(993))and [x['ordinal']for x in s['all_queries']]==list(range(s['counts']['Query']))
 assert all(q['frame']in range(59)for q in p['all_queries'])and all(q['frame']in range(59,118)for q in s['all_queries'])
 assert sum(f['Query']for f in frames)==total
 for f in frames:assert f['Query']<=f['bound']
 assert sum(f['bound']for f in frames)==4885
 start=json.loads(read(p['states'][0]));middle=json.loads(read(p['latest_closed_state']));suffixstart=json.loads(read(s['states'][0]));final=json.loads(read(s['latest_closed_state']))
 assert exact(middle,suffixstart)
 def changed(source,n):
  obj=json.loads(json.dumps(source,ensure_ascii=False));ids=td(obj)['識別子状態']
  for pair in ids['__辞書__']:
   if pair[0]in('照会','学習判定'):pair[1]+=n
  return obj
 assert exact(changed(start,993),middle)and exact(changed(middle,s['counts']['Query']),final)and exact(changed(start,total),final)
 assert td(td(final)['識別子状態'])['照会']==td(td(final)['識別子状態'])['学習判定']==end
 patterns=dict(p['support_patterns'])
 for k,v in s['support_patterns'].items():
  if k in patterns:assert exact(patterns[k],v)
  else:patterns[k]=v
 for segment in [p,s]:
  for q in segment['all_queries']:
   for k in q['prediction_support_keys']:assert k in patterns
 nonempty_HOLD=[{'segment':'failed_prefix'if segment is p else'completed_suffix','ordinal':q['ordinal'],'frame':q['frame'],'whole_HOLD':q['whole_HOLD']}for segment in [p,s]for q in segment['all_queries']if any(q['whole_HOLD'].values())]
 report={'schema':'independent-saved118-combined-native-diagnostic-audit-v1','status':'PASS','errors':[],'integration_kind':'FAILED_prefix59_plus_completed_suffix59','original_prefix_status':'FAILED','native_segment_count':2,'segments':{'prefix_summary':r['prefix_summary'],'prefix_audit_tools':closure['references']['audit_tools'],'prefix_native_terminal_tools':closure['references']['native_terminal_tools'],'suffix_summary':r['suffix_summary'],'suffix_audit_tools':r['suffix_audit_tools'],'suffix_native_actual_tools':s['actual_tools'],'suffix_completion':s['completion']},'verified':{'original118_ordered_no_omission_or_duplicate':True,'all_native_queries_audited_raw_external_type_order_origin':True,'all_current_candidates_and_full_goal_pools_replayed_without_pruning':True,'all_principle_versions_same_condition_support_refutation_whole_HOLD':True,'prefix_failed_status_and_all2113_original_files_preserved':True,'prefix_native_exit130_and_both_independent_audits_exit0_joined':True,'suffix_native_terminal_exit0_joined':True,'both_serial_counter_chains_and_whole_state_counter_only_equality':True,'diagnostic_origins_not_live_adoption':True,'latest_serial_state_only_next_baseline':True},'counts':{'observations':118,'Query':total,'prefix_Query':993,'suffix_Query':s['counts']['Query'],'Teach':0,'Action':0,'SDK':0,'experiences':183,'counter_before':4887,'counter_middle':5880,'counter_after':end,'native_by_auditor':0,'restore_by_auditor':0},'states':[p['states'][0],p['latest_closed_state'],s['latest_closed_state']],'latest_closed_state':s['latest_closed_state'],'frames':frames,'support_patterns':patterns,'nonempty_HOLD_queries':nonempty_HOLD,'limitations':['All118 saved-observation diagnostic coverage, not a fresh clear or evidence of new transfer capability.','Original79324233 run remains FAILED; this is a separate integration across preserved serial segments.','Fixed full-bijection goal enumeration and first-supported order remain priors, not learned policy.','Fresh runtime must independently obtain a new root gate and Query its own exact current observations.']}
 scope=runpy.run_path(str(L/'source/goalset_connection/resource_guard_v1.py'));b=(json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode();assert len(b)<1<<20
 out=scope['save']('evidence','independent_saved118_combined_native_summary_v2.json',b);print(json.dumps({'status':'PASS','report':out,'counts':report['counts'],'latest_closed_state':report['latest_closed_state']}))
try:main()
except BaseException:
 scope=runpy.run_path(str(L/'source/goalset_connection/resource_guard_v1.py'));out=scope['save']('evidence','independent_saved118_combined_audit_failure_v2.json',(json.dumps({'status':'FAIL','traceback':traceback.format_exc()},ensure_ascii=False,indent=2)+'\n').encode());print(json.dumps({'status':'FAIL','failure':out}));raise
