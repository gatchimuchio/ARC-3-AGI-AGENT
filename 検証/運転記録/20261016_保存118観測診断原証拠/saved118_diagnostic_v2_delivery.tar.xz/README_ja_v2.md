# saved118 保存観測診断 checkpoint

## 目的・由来
保存済み118観測の Query-only 診断、二つの原失敗、監査、原本・source・gates・実道具記録を圧縮保存する。これは新しい成功能力の証明ではない。manifest は全tar memberの原path・byte数・SHA256と、収録しない依存の正確な externalFileRefs を持つ。原本は変更せず直接streamで読んだ。raw複製treeは作成しない。

## previous / current / delta
previous は paired counter4887、経験183。失敗prefix59観測の実Query993により5880、残りsuffix59観測の実Query767により6647。合計118観測を元順序で各一回、native Query1760件のraw支持・反証・HOLD・current origin・full goal poolを独立監査済み。経験183は不変。状態変化はpaired counterだけ。17種類の支持patternを確認したが能力向上件数へ読み替えない。

## 回帰・制限
native HOLD fields は0。ただしunsupported候補を削除せず保持した。旧current停止点では全9候補中8 preparationが支持、submissionはUNKNOWN。Teach/SDK/Actionはすべて0。fresh成功・ゲーム間転用は主張しない。診断originはlive permissionではなく、freshには新current Queryと別の完全gateが必要。rootは6647状態を最新baselineとしてのみ採用し、fresh gateは未成立。HDS・core・authorityは無変更。可変fresh sourceは一切収録しない。

## 失敗と修正
634eb135はpublic corpusをcode8MiB capで誤分類したpre-native失敗。79324233は完全intent8352Bが8KiB capを超え失敗し、独立した回収監査後、実行担当が一度Ctrl-Cで終了し、実際の終了コード130を保存。どちらも原FAILEDを保持する。完全intent16KiBへの修正は118観測の全数測定（最大8360B）に基づき、originの切詰めはない。suffix76fb30b5は正常exit0。source段階のIndentationErrorと修正前後、過去reviewも省略しない。

## 復元・検証
archive はworkspace相対pathの単一tar.xz（CRC64）。verification_v2.json は全member byte/SHA照合、XZ全CRC/EOF、原本再照合、依存再照合、資源予約の結果を示す。外部依存はmanifestのexact FileRefを別途確保して照合する。archiveの展開やsource実行は自動では行わない。archiveはauthorityの代替ではない。
