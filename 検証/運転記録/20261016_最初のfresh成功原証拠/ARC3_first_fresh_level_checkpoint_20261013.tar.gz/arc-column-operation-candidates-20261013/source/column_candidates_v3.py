"""全可視対象の未実行候補。固定助言順序とHDS効果支持を分離。
原票/ID/状態復元/SDKに依存しない。照会callbackは後日同一HDSを注入。
"""
from copy import deepcopy
import traceback
作用境界='公開列図式:観測された解答作業と行動ID'
目標境界='公開列図式:有限全列または生産的反復の目標長一致と提出受理'
修復境界='公開列図式・一意目標候補・在庫選択と実枠クリックの末相不足修復'
修復入力='実対象への選択記号適合'
修復結果='応答末相で不足が修復された'
準備境界='公開列図式・一意目標候補・在庫選択表示なし・既学習クリック作用の末相準備成立'
準備入力='実クリック在庫記号が未充足要求に適合'
準備結果='応答末相で要求適合する在庫選択表示が成立'

def 同型(a,b):
 if type(a)is not type(b):return False
 if isinstance(a,dict):return len(a)==len(b) and all(同型(k,l) and 同型(a[k],b[l]) for k,l in zip(a,b))
 if isinstance(a,(tuple,list)):return len(a)==len(b) and all(同型(x,y) for x,y in zip(a,b))
 return a==b

def 支持参照(v):
 out=[]
 def walk(x):
  if isinstance(x,dict):
   for k,w in x.items():
    if k in ('原理参照','経験参照') and isinstance(w,str):out.append(w)
    else:walk(w)
  elif isinstance(x,(list,tuple)):
   for w in x:walk(w)
 walk(v);return list(dict.fromkeys(out))

def 値(v,k):return v[k] if isinstance(v,dict) else getattr(v,k)

def 効果を照会する(callback,boundary,facts,key,typ):
 sent=deepcopy(facts);before=deepcopy(sent)
 r={'境界':boundary,'入力':deepcopy(facts),'結果葉':key,'返却':None,'予測':None,'支持':[],'状態':'UNKNOWN','例外':None}
 try:
  reply=callback(boundary,sent);r['返却']=deepcopy(reply)
  if not 同型(sent,before):raise ValueError('callbackが照会入力を変更')
  state=値(reply,'状態');content=値(reply,'内容')
  predictions=content.get('予測群',[])
  chosen=[p for p in predictions if tuple(p['結果経路'])==(key,)]
  r['対象予測全件']=deepcopy(chosen)
  r['対象外予測全件']=deepcopy([p for p in predictions if tuple(p['結果経路'])!=(key,)])
  if state=='断定保留' or content.get('係争中原理群') or content.get('断定保留理由群'):
   r['状態']='HOLD';return r
  if state!='出力':
   r['理由']='公開返却状態が出力ではない';return r
  if not chosen or any(type(p['予測値'])is not typ for p in chosen):return r
  if any(not 同型(chosen[0]['予測値'],p['予測値']) for p in chosen):r['状態']='競合HOLD';return r
  refs=支持参照(chosen)
  if not refs:return r
  r.update({'状態':'支持','予測':chosen[0]['予測値'],'支持':refs});return r
 except (ValueError,TypeError,KeyError,AttributeError) as e:
  r['例外']={'型':type(e).__name__,'引数':e.args,'全文':traceback.format_exc()};return r

def 中心(target):
 p=target['位置']
 if not isinstance(p,(list,tuple)) or len(p)!=2 or any(type(x)is not int for x in p):raise ValueError('位置形式')
 x,y=p[0]+2,p[1]+2
 if not 0<=x<64 or not 0<=y<64:raise ValueError('中心座標範囲')
 return {'x':x,'y':y}

def 全作用候補を構成する(図式,全目標pool,学習役割,選択観測,利用可能作用,照会,列一致):
 """引数は現在公開知覚だけ。after/原票行/ゲームIDを受け取らない。"""
 original=deepcopy((図式,全目標pool,学習役割,選択観測,利用可能作用))
 scene=deepcopy(図式);goal=deepcopy(全目標pool)
 out={'目標pool全件':goal,'学習役割':deepcopy(学習役割),'選択観測':deepcopy(選択観測),'全候補':[],
      '未対応作用群':[{'区分':'既記入枠置換/複数枠交換','理由':'不足修復boolは全既存枠で照会可能。置換の内容/保存/採用は未同定'},
                    {'区分':'在庫表示以外の選択','理由':'現知覚は在庫外周限定'}],
      '列判定':None,'全体理由':[],'助言順序':[],'自動選択':None,'実行許可':False,
      '順序の由来':'固定の生成順。学習policyではない。全候補を保持し、順序だけを返す',
      '実行後条件':'別途承認された一手だけを実行し、必ず再観測/再照会。未実行枝は未検証のまま保持'}
 if not isinstance(利用可能作用,(list,tuple)) or any(type(x)is not int or not 0<=x<=7 for x in 利用可能作用) or len(set(利用可能作用))!=len(利用可能作用):raise ValueError('available_actions形式')
 if not isinstance(学習役割,dict) or len(学習役割)!=2 or any(type(k)is not bool or v not in ('出力','参照') for k,v in 学習役割.items()):raise ValueError('実学習役割の明示が必要')
 pool=goal.get('候補',[])
 if type(pool)is not list or ('候補数'in goal and (type(goal['候補数'])is not int or goal['候補数']!=len(pool))):raise ValueError('pool数/型')
 unique=len(pool)==1 and goal.get('状態')=='唯一解答候補'
 if not unique:out['全体理由'].append('目標候補0/複数/未成立。全pool保持、現境界では効果照会UNKNOWN')
 slots=[x for b in scene['容器群'] for x in b['枠群']];inv=scene['在庫群']
 current={tuple(x['位置']):x['記号'] for x in slots}
 if len(current)!=len(slots):raise ValueError('重複枠')
 desired={};needs=[]
 if unique:
  for a in pool[0]['割当']:
   k=tuple(a['位置'])
   if k in desired or k not in current or current[k] is not None:raise ValueError('goal空欄全割当形式')
   desired[k]={'色':a['色'],'中空':a['中空']};needs.append(k)
  if set(desired)!={k for k,v in current.items() if v is None}:raise ValueError('全空欄割当欠損')
 selected=選択観測.get('selection');known='selection'in 選択観測 and 'selection_unknown'not in 選択観測
 visible=known and selected is not None and any(同型(selected,t) for t in inv)
 if selected is not None and not visible:out['全体理由'].append('選択在庫の対応UNKNOWN')
 try:
  match,detail=列一致(deepcopy(scene),deepcopy(学習役割))
  out['列判定']={'一致':None if detail.get('構造状態')=='HOLD' else match,'全返却':deepcopy(detail)}
 except (ValueError,TypeError,KeyError) as e:out['列判定']={'一致':None,'例外':{'型':type(e).__name__,'引数':e.args,'全文':traceback.format_exc()}}
 def add(kind,target,operation):
  c={'候補番号':len(out['全候補']),'作業':operation,'対象区分':kind,'対象':deepcopy(target),'作用':None,
     '前提':{},'照会全件':[],'理由':[],'効果状態':'UNKNOWN','実行許可':False,
     '保存条件':{'既充足への実影響':'この効果葉だけでは未証明','隠れ状態差':'未観測','報酬':'未観測'},
     '座標由来':'既存4px対象の中心+2。全画素同値性は主張しない'}
  out['全候補'].append(c)
  q=効果を照会する(照会,作用境界,{'解答作業':operation},'必要行動ID',int);c['照会全件'].append(q)
  if q['状態']!='支持':c['理由'].append('作業Action対応未支持');return c,False
  number=q['予測'];data={} if target is None else 中心(target)
  c['作用']={'id':number,'data':data}
  if number not in 利用可能作用:c['理由'].append('公開available外');return c,False
  if target is not None and number!=6:c['理由'].append('既存座標Action契約外');return c,False
  if target is None and number==6:c['理由'].append('提出の非座標契約不成立');return c,False
  return c,True
 def effect(c,boundary,facts,key):
  c['前提'].update(facts);q=効果を照会する(照会,boundary,facts,key,bool);c['照会全件'].append(q)
  c['効果状態']='効果支持' if q['状態']=='支持' and q['予測'] is True else '予測効果不成立' if q['状態']=='支持' and q['予測'] is False else q['状態']
  if c['効果状態']!='効果支持':c['理由'].append('目的効果の支持不成立または負予測')
 for token in inv:
  c,legal=add('在庫',token,'在庫記号を選択')
  if not(unique and known and selected is None and needs):c['理由'].append('14準備境界外：一意目標/未充足/在庫選択表示なしの確認が必要');continue
  fits=any(同型(token['記号'],desired[k]) for k in needs)
  c['前提'][準備入力]=fits
  if legal:effect(c,準備境界,{準備入力:fits},準備結果)
 if visible:
  for slot in slots:
   c,legal=add('枠',slot,'選択記号を空欄へ割当')
   if slot['記号'] is not None:c['理由'].append('既記入枠：不足修復boolのみ照会。置換内容/保存条件/実行採用UNKNOWN')
   if not unique:c['理由'].append('一意目標境界未成立');continue
   k=tuple(slot['位置']);fits=k in desired and 同型(selected['記号'],desired[k]);c['前提'][修復入力]=fits
   if legal:effect(c,修復境界,{修復入力:fits},修復結果)
 else:out['未対応作用群'].append({'区分':'枠クリック効果','理由':'可視在庫選択未確認。Noneは他の選択状態なしを意味しない'})
 c,legal=add('提出',None,'完成列提出');value=out['列判定']['一致'];c['前提']['終端条件に応じた列が一致']=value
 if legal and type(value)is bool:
  effect(c,目標境界,{'終端条件に応じた列が一致':value},'提出が受理された')
  if value is not True:c['理由'].append('現在列の目標一致が未成立');c['効果状態']='目標不一致HOLD'
 else:c['理由'].append('現在列またはAction対応UNKNOWN')
 # Advisory serialization order only: no slice/top-k, no unchosen record deletion.
 out['助言順序']=[c['候補番号'] for c in out['全候補']]
 out['学習効果支持候補']=[c['候補番号'] for c in out['全候補'] if c['効果状態']=='効果支持']
 out['規則不確実性']=[]
 for c in out['全候補']:
  for q in c['照会全件']:
   if q['返却'] is not None:
    content=値(q['返却'],'内容')
    if content.get('係争中原理群'):out['規則不確実性'].append({'候補番号':c['候補番号'],'係争中原理群':deepcopy(content['係争中原理群'])})
 out['全体採否']='HOLD' if out['規則不確実性'] else '実行採否未実施'
 if not 同型(original,(図式,全目標pool,学習役割,選択観測,利用可能作用)):raise ValueError('入力変更')
 return out
