import resource
resource.setrlimit(resource.RLIMIT_AS,(512<<20,512<<20))
import ast,base64,copy,dataclasses,hashlib,importlib.util,json,lzma,os,signal,sys,time,traceback
from pathlib import Path
B=Path('/workspace/scratch/a94ff513b3af');P=B/'arc-column-live-pilot-20261013';N='502f9dd64c29158c6189c4efa50c107d';D=P/'evidence'/N
BASE=B/'arc-column-learning-audit-20261013/source/audit_v1.py'
base=BASE.read_bytes()
assert hashlib.sha256(base).hexdigest()=='e95c8a8307be21b9dc9981685fe84d2b41c0a8216b38f45361e47f4a0d267324'
exec(compile(base.decode().split('def main():',1)[0],str(BASE),'exec'),globals())
P=B/'arc-column-live-pilot-20261013';N='502f9dd64c29158c6189c4efa50c107d';D=P/'evidence'/N
sys.path.insert(0,str(P/'source'));import pilot_guard_v4 as g
def out(name,value):
 raw=(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode()
 return g.save('evidence','independent_pilot_502f9dd6_'+name,raw)
def main():
 global enc,dec,CURSOR
 signal.signal(signal.SIGALRM,timeout);signal.alarm(300);g.guard('evidence',1<<20)
 c=js(exact({'path':str(D/'completion.json'),'bytes':25138,'sha256':'a0d6fb9edece589cfba27415e6e605aa96dd505163553a40edf85b9aa64ca646'}))
 tools=js(exact({'path':str(P/'evidence/actual_live_tools_502f9dd6_v1.json'),'bytes':817,'sha256':'d6079f8dba2fb67b1118f9a82abf7a4388a1262ce9259aa78180568cb2ec40d5'}))
 assert tools['launch']['session_id']==97422 and tools['actual_exit']==0 and tools['polls'][-1]['exit_code']==0
 assert js(tools['polls'][-1]['output'].splitlines()[0])['receipt']==REFS[str(D/'completion.json')]
 gate=js(plain(P/'source'/('root_live_release_'+N+'.json')));contract=js(exact(gate['contract']))
 assert gate['enabled'] is True and c['nonce']==N and c['status']=='recorded' and c['errors']==[]
 for r in contract['source_pins']+contract['core_and_family_pins']:exact(r,8*M)
 assert c['baseline']==gate['closed_baseline']
 for key in ('state','audit','actual_exit'):exact(c['baseline'][key],8*M)
 oldc=packet(c['baseline']['completion'],False);assert oldc['states'][-1]==c['baseline']['state']
 sys.dont_write_bytecode=True;sys.path[:0]=[str(CORE),str(F),str(B/'arc-live-step-adapter-20261013')]
 import hds学習系統.永続化 as codec
 from hds学習系統.型 import 外部出力,実行結果,学習成立状態
 from 接続 import 列図式規則 as family
 enc,dec=codec._符号化,codec._復号
 import adapter
 final=load('audit_final',B/'arc-live-step-adapter-20261013/final_adoption_v4.py')
 sem=load('audit_semantics',P/'source/pilot_semantics_v3.py')
 query=load('audit_query_entry',Path(contract['query_entry']['path']))
 work=load('audit_work',Path(contract['goal_work']['path']))
 boundary=adapter.load_boundary()
 states=[]
 for r in c['states']:
  raw=exact(r);tag=js(raw);value=dec(tag)
  assert same(enc(value),tag) and json.dumps(tag,ensure_ascii=False,indent=2).encode()==raw
  states.append(value)
 assert len(states)==3 and c['states'][0]['sha256']==c['baseline']['state']['sha256']
 expected=dec(enc(states[0]))
 assert c['Query']==len(c['calls'])==13 and c['Teach']==0 and c['Action_attempted']==c['Action_returned']==1
 for k in ('照会','学習判定'):expected['識別子状態'][k]+=13
 assert same(enc(expected),enc(states[1])) and same(enc(states[1]),enc(states[2]))
 CHECKS['all_three_normal_states_latest_restore_and_only_two_counters_plus13']=True
 for r in c['all_saved_refs']:exact(r)
 def pub(r,seq):
  value=js(exact(r));assert value['nonce']==N and value['frame_count']==len(value['frames'])
  def decode(v):
   if type(v)is not dict:return v
   if 'dict'in v:return {decode(k):decode(x) for k,x in v['dict']}
   if 'list'in v:return [decode(x) for x in v['list']]
   if 'tuple'in v:return tuple(decode(x) for x in v['tuple'])
   if 'enum'in v:return decode(v['value'])
   if 'float'in v:return float.fromhex(v['float'])
   raise ValueError('public tag')
  assert same(decode(value['model_python_typed']),value['model_json'])
  for i,f in enumerate(value['frames']):
   raw=base64.b64decode(f['base64'],validate=True)
   assert f['ordinal']==i and f['bytes']==len(raw)==4096 and digest(raw)==f['sha256'] and f['dtype']=='|i1' and f['shape']==[64,64] and f['order']=='C'
  return value,query.canonical_observation(boundary,value,seq)
 before,bcur=pub(c['current_public'],0);after,acur=pub(c['step']['public_response'],1)
 assert bcur.実行識別子==acur.実行識別子 and bcur.ゲーム識別子==acur.ゲーム識別子
 assert same(js(plain(D/'transport'/(N+'.before.json'))),before)
 CURSOR='all native replies'
 ex=CORE/'hds学習系統/排気系.py';fn=next(x for x in ast.walk(ast.parse(ex.read_bytes())) if isinstance(x,ast.FunctionDef) and x.name=='排出する')
 ns={'asdict':dataclasses.asdict,'Any':object,'外部出力':外部出力,'実行結果':実行結果,'学習成立状態':学習成立状態}
 exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])),str(ex),'exec'),ns)
 histories={p.原理識別子:p for h in states[0]['原理履歴'].values() for p in h}
 observations={e.経験識別子:e for e in states[0]['台帳']['観測台帳']}
 replay=[];previous=None;predictions=[]
 for i,link in enumerate(c['calls']):
  assert link['ordinal']==i and link['frame']==0 and link['method']=='照会する'
  intent=packet(link['intent']);reply=packet(link['reply'])
  for k in ('ordinal','frame','method','input','origin','before'):assert same(enc(intent[k]),enc(reply[k]))
  assert intent['capture']=={} and reply['origin']['live採否可能'] is True
  assert reply['origin']['観測指紋']==bcur.指紋 and reply['origin']['公開観測参照']==c['current_public'] and reply['origin']['復元状態参照']==c['baseline']['state']
  cap=reply['capture'];assert cap['profile_restored'] is True and len(cap['raw'])==len(cap['events'])==1
  assert cap['events'][0]['exact_code_self'] is True and cap['events'][0]['function']=='排出する'
  raw=cap['raw'][0];ret=cap['return'];assert same(enc(ns['排出する'](None,raw)),enc(ret))
  if previous is not None:assert same(previous,reply['before'])
  previous=reply['after']
  beforemark=copy.deepcopy(reply['before'])
  for k in ('照会','学習判定'):beforemark['identifiers'][k]=beforemark['identifiers'].get(k,0)+1
  assert same(beforemark,reply['after'])
  for p in raw.有効原理群:
   assert same(enc(p),enc(histories[p.原理識別子]))
   assert all(e in observations for e in p.根拠参照群+p.反証参照群)
  for pred in raw.予測群:
   p=histories[pred.原理参照];assert p.対象系境界==reply['input'].対象系境界 and pred.結果経路==p.結果経路
  rr=copy.deepcopy(reply);rr['input']=dataclasses.asdict(reply['input']);rr['capture']['return']=dataclasses.asdict(ret);rr['reference']=link;replay.append(rr)
  predictions.append({'ordinal':i,'input':dataclasses.asdict(reply['input']),'return':dataclasses.asdict(ret)})
 CHECKS['all13_current_native_intent_raw_external_support_markers']=True
 semantic=pfile('current_complete_semantic.typed.json.xz')
 def reproj(current):
  result=sem.replay_current(current,family,loadcandidate,query.semantic_entry,replay,dataclasses.asdict,外部出力,semantic)
  return final.復号(enc(sem.project_current(current,result,work)))
 loadcandidate=load('audit_candidates',Path(contract['candidate']['path']))
 projected=reproj(bcur)
 intent=js(plain(D/'transport'/(N+'.intent.json')));record=intent['adoption'];evidence=intent['all_evidence']
 store=final.固定証拠(list(REFS.values()),[P,B/'arc-column-candidate-query-20261013'])
 verify=final.最終採否検査(store,c['baseline']['state'],record['final_adoption_ref'],reproj)
 att=verify(record,evidence,bcur,len(states[0]['状態履歴'])-1)
 assert att==intent['attestation']
 assert same(c['step']['action'],record['action']) and record['action']['number'] in bcur.作用可能番号
 assert js(plain(D/'transport'/(N+'.dispatch.json')))['action']==record['action']
 assert js(plain(D/'transport'/('consumed-'+bcur.指紋+'.json')))['observation']==bcur.指紋
 assert js(plain(D/'transport'/(N+'.result.json')))==c['step'] # transport uses sorted JSON keys; both original byte orders retained
 calc=adapter.phases(bcur,acur,record['action']['number']);assert json.loads(json.dumps(calc,ensure_ascii=False))==c['step']['analysis']
 assert after['model_json']['action_input']['id']==record['action']['number'] and after['model_json']['action_input']['data']==record['action']['arguments']
 CHECKS['complete_candidates_current_reprojection_final_gate_and_actual_transport_join']=True
 CURSOR='all public response semantic effects'
 phases=[]
 for i,frame in enumerate(acur.盤面列):
  scene=family.図式を観測する(frame);selection=family.選択を読む(frame,scene)
  phases.append({'phase':i,'scene':scene,'selection':selection,'public_response_ref':c['step']['public_response'],'JSONpath':['frames',i]})
 chosen=next(x for x in semantic['全作用候補']['全候補'] if str(x['候補番号'])==record['selected_candidate_id'])
 bound=work.境界(before['model_json'],after['model_json'])
 measured=sem.compare_effect(semantic,phases,bound,chosen,work)
 saved_measure=packet(c['result']['comparison']);assert same(enc(measured),enc(saved_measure))
 memory=packet(c['result']['memory'])
 preservation=evidence['adoption']['候補検査'][record['selected_candidate_id']]['保存条件']
 consistent=measured['実測目的効果'] is True and (preservation['保存値'] is None or measured['全相既充足保存'] is True) and not measured['UNKNOWN']
 language={'対象':chosen['対象'],'役割':semantic['学習役割'],'関係':semantic['全目標pool'],'前提':chosen['前提'],'選択理由':['支持済集合の固定候補生成順。学習policyではない'],'予測':chosen['照会全件'],'保存条件':preservation,'適用範囲':sem.project_current(bcur,semantic,work)['保存適用署名'][record['selected_candidate_id']],'由来参照':[c['result']['comparison']['file'],record['final_adoption_ref']],'予測実測比較':{'状態':'一致' if consistent else '未確認' if measured['実測目的効果'] is None else '不一致','全実測':measured,'根拠参照':[c['result']['comparison']['file']]}}
 runtime_step=copy.deepcopy(c['step']);runtime_step['analysis']=calc
 rebuilt=final.日本語記憶へ(runtime_step,record,c['current_public'],REFS[str(D/'transport'/(N+'.intent.json'))],language)
 # The final verifier decodes saved tuple tags to lists; language original is retained by codec.
 assert same(enc(rebuilt),enc(memory))
 assert memory['HOLD']==[] and memory['追加学習'] is False and memory['成功認定'] is False
 CHECKS['all_public_phases_goal_effects_memory_HOLD_reconstructed']=True
 diagnostics=js(exact(c['sdk_diagnostics']))
 assert diagnostics['make_attempted']==diagnostics['make_returned']==diagnostics['ordinary_Action_attempted']==diagnostics['ordinary_Action_returned']==1
 assert diagnostics['denials']==diagnostics['exceptions']==diagnostics['sdk_events']==[]
 # Opaque SDK streams and game implementations are never opened by this audit.
 for r in diagnostics['opaque_streams']:assert Path(r['path']).stat().st_size==r['bytes']
 for p,i in IDENT.items():assert ident(Path(p))==i
 for r in contract['source_pins']+contract['core_and_family_pins']:exact(r,8*M)
 CHECKS['source_identity_final_state_actual_exit_and_opaque_not_read']=True
 result={'schema':'column-live-pilot-independent-audit-v1','status':'PASS','errors':[],'nonce':N,'completion':REFS[str(D/'completion.json')],'actual_tools':REFS[str(P/'evidence/actual_live_tools_502f9dd6_v1.json')],'verified':CHECKS,'counts':{'Query':13,'Action':1,'Teach':0,'response_phases':len(phases),'candidate_count':len(semantic['全作用候補']['全候補']),'auditor_native_calls':0},'selected':enc(chosen),'measured':enc(measured),'memory':enc(memory),'states':c['states'],'public_before':before['model_json'],'public_after':after['model_json'],'SDK_diagnostics':diagnostics,'references':list(REFS.values()),'limits':['Same-owner source and durable dispatch/reply chain verified; no independent execution of SDK or HDS.','Opaque stream bodies and game implementation bodies not read; opaque sizes only checked.','Progress0 is not level clear; hidden state/reward remain unobserved.','Original failed owner2505 retained separately.'],'elapsed_seconds':time.monotonic()-START}
 r=out('summary_v2.json',result);signal.alarm(0);print(json.dumps({'status':'PASS','report':r,'counts':result['counts'],'progress':calc['levels_delta']},ensure_ascii=False))
try:main()
except BaseException:
 signal.alarm(0)
 r=out('failure_v2.json',{'status':'FAIL','cursor':CURSOR,'checks':CHECKS,'traceback':traceback.format_exc()})
 print(json.dumps({'status':'FAIL','failure':r}));raise
