PINS={'adapter': 'f18d9d33191749a5c6e731f58f534936a73b6e9162c1363fc5424c92e80e09d7', 'final': '1a6b5987886f8ae2a2fb85695455698d58797ceb9ef7635bdcaf7715d3a9238d', 'semantics': '1b3f23bfe847cc452fdd9367700686e325025ad9a74194c168ad5d9ba4f076cb', 'entry': '7e92d5c73d3b3b002c2e2dcb09b526950d9c2c1caf881838ce38f8cbd48b7aba', 'work': '8427b6cf7498613c548e6ac883ebfe800ffa6c43b25ded7488d45facdb9f34be', 'family': 'd303b314446d22c604008d590636cccf6e1d140fbd365f22ff018b55d97de399', 'codec': '8aa431b3012424fd8347c5b3d93a5fbf2218d35020836f5d40abb427f9d6da0d'}
"""Synthetic end-to-end evidence seam. No SDK or HDS import/API.
Uses real pure semantic entry/candidate enumeration, dossier writer, final
verifier, transport and public capture. Only perception/native replies/env
are synthetic. Every case and its files remain immutable.
"""
import resource
resource.setrlimit(resource.RLIMIT_AS,(512<<20,512<<20))
import ast,copy,dataclasses,enum,hashlib,importlib.util,itertools,json,lzma,os,signal,sys,traceback
from pathlib import Path
from collections import Counter
from types import SimpleNamespace
B=Path('/workspace/scratch/a94ff513b3af')
S=B/'arc-column-live-pilot-20261013'
sys.path.insert(0,str(S/'source'))
import pilot_guard_v2 as guard
guard.guard()
signal.signal(signal.SIGALRM,lambda *a:(_ for _ in ()).throw(TimeoutError('pilot fake120')))
signal.alarm(120)
def load(name,path,pin):
    raw=path.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=pin:raise ValueError('source pin '+name)
    m=importlib.util.module_from_spec(importlib.util.spec_from_file_location(name,path))
    sys.modules[name]=m;exec(compile(raw,str(path),'exec'),m.__dict__);return m
sys.path.insert(0,str(B/'arc-live-step-adapter-20261013'))
adapter=load('adapter',B/'arc-live-step-adapter-20261013/adapter.py',PINS['adapter'])
final=load('pilot_final',B/'arc-live-step-adapter-20261013/final_adoption_v4.py',PINS['final'])
sem=load('pilot_semantics',S/'source/pilot_semantics_v3.py',PINS['semantics'])
query=load('pilot_fake_entry',B/'arc-column-candidate-query-20261013/source/candidate_query_v5.py',PINS['entry'])
candidate=load('pilot_fake_candidates',Path(query.MANIFEST['candidate']['path']),query.MANIFEST['candidate']['sha256'])
work=load('pilot_work',B/'arc-column-goal-work-measurement-20261013/source/column_goal_work_v2.py',PINS['work'])
import numpy as np
@dataclasses.dataclass
class Input:
    内容:dict
    対象系境界:str
@dataclasses.dataclass
class Reply:
    状態:str
    内容:dict
    追跡情報:dict
family_path=B/'arc-current-family-source-20261013/接続/列図式規則.py'
raw=family_path.read_bytes()
if hashlib.sha256(raw).hexdigest()!=PINS['family']:raise ValueError('family pin')
tree=ast.parse(raw)
names={'列を生成する','一致する','照会','内容候補を構成する'}
nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names or isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id in ('役割境界','目標境界') for x in n.targets)]
ns={'deepcopy':copy.deepcopy,'Counter':Counter,'itertools':itertools,'外部入力':Input}
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(family_path),'exec'),ns)
codecpath=B/'arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/永続化.py'
raw=codecpath.read_bytes()
if hashlib.sha256(raw).hexdigest()!=PINS['codec']:raise ValueError('codec pin')
cn={'Any':object,'Enum':enum.Enum,'is_dataclass':dataclasses.is_dataclass,'fields':dataclasses.fields}
nodes=[n for n in ast.parse(raw).body if isinstance(n,ast.FunctionDef) and n.name=='_符号化']
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(codecpath),'exec'),cn)
encode=cn['_符号化']
def plain(x):return final.復号(encode(x))
def js(x):return json.dumps(x,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()
CASES=[];EXCEPTIONS=[]
class Observation:
    model_fields={k:None for k in ('game_id','state','levels_completed','win_levels','action_input','guid','full_reset','available_actions')}
    def __init__(self,marker=0,guid='synthetic-current'):
        self.game_id='synthetic-no-solver-id';self.state='NOT_FINISHED';self.levels_completed=0;self.win_levels=2
        self.action_input={'id':6,'data':{'x':5,'y':22}};self.guid=guid;self.full_reset=False;self.available_actions=[5,6]
        self.frame=[np.zeros((64,64),dtype=np.int8)];self.frame[0][0,0]=marker
    def model_dump(self,**kw):return {k:copy.deepcopy(getattr(self,k)) for k in self.model_fields}
class Actions:
    ACTION5='ACTION5';ACTION6='ACTION6'
class Env:
    def __init__(self,response,error=None):self.response=response;self.error=error;self.calls=[]
    def step(self,action,data,reasoning):
        self.calls.append({'action':action,'data':data,'reasoning':reasoning})
        if self.error:raise self.error
        return self.response
class CheckedJournal(adapter.Journal):
    def save(self,name,value,raw=False):
        data=value if raw else adapter.raw_json(value)
        guard.guard('evidence',len(data))
        return super().save(name,value,raw=raw)
SCENE={'背景色':0,'目標列':[2,3,4,5],'容器群':[{'色':1,'位置':[0,0],'起点':True,'枠群':[{'位置':[3+6*i,3],'記号':None} for i in range(4)]}],'在庫群':[{'位置':[3+8*i,20],'記号':{'色':i+2,'中空':False}} for i in range(4)]}
class NotApplicable(ValueError):pass

def scenario(name,mode='normal'):
    guard.guard();folder=S/'evidence'/name
    folder.mkdir(parents=True,exist_ok=False);guard.fsyncdir(folder.parent)
    refs=[];saved=[];query_records=[]
    def save(label,value,tagged=False):
        raw=js(encode(value) if tagged else value);guard.guard('evidence',len(raw))
        p=folder/(label+'.json')
        with p.open('xb')as f:f.write(raw);f.flush();os.fsync(f.fileno())
        guard.fsyncdir(folder)
        if p.read_bytes()!=raw:raise OSError('fixture exact readback')
        r={'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()};refs.append(r)
        return r
    def packet(label,value):
        r=save(label,value,True);return {'file':r,'rawbytes':r['bytes'],'rawsha256':r['sha256']}
    scene=copy.deepcopy(SCENE)
    if mode in ('nonempty','preserve_false'):
        scene['容器群'][0]['枠群'][3]['記号']=copy.deepcopy(scene['在庫群'][3]['記号']);scene['在庫群']=scene['在庫群'][:3]
    obs=Observation();boundary=adapter.load_boundary();current=boundary.観測する(obs,観測通番=0)
    public=save('public-before',json.loads(adapter.capture_public(obs,np,name)))
    specifications=[
      ('role',ns['役割境界'],'記号は中空','列展開役割',[(False,'出力'),(True,'参照')]),
      ('action',candidate.作用境界,'解答作業','必要行動ID',[('在庫記号を選択',6),('選択記号を空欄へ割当',6),('完成列提出',5)]),
      ('accept',candidate.目標境界,'終端条件に応じた列が一致','提出が受理された',[(False,False),(True,True)]),
      ('prep',candidate.準備境界,candidate.準備入力,candidate.準備結果,[(False,False),(True,True)]),
      ('repair',candidate.修復境界,candidate.修復入力,candidate.修復結果,[(False,False),(True,True)]),
      ('preserve',candidate.保存境界,candidate.保存入力,candidate.保存結果,[(x,True) for x in candidate.保存区分])]
    state={'形式版':3,'状態履歴':[{},{}],'原理履歴':{},'台帳':{'観測台帳':[]}}
    lookup={}
    for pid,b,x,y,pairs in specifications:
        ids=[]
        for i,(a,z) in enumerate(pairs):
            eid=pid+str(i);ids.append(eid);state['台帳']['観測台帳'].append({'経験識別子':eid,'対象系境界':b,'原入力':{x:a,y:z}})
        p={'原理識別子':pid,'対象系境界':b,'結果経路':[y],'条件経路群':[[x]],'版':1,'採用状態':'有効','根拠参照群':ids,'反証参照群':[],'適用範囲':{'fixture':True}}
        state['状態履歴'][-1][pid]=pid;state['原理履歴'][pid]=[p];lookup[b]=(p,x,y,pairs)
    sr=save('state',state,True)
    class Owner:
        def __init__(self):self.owner=self;self.bound=None
        def allow_frame(self,n):self.bound=n
        def 照会する(self,value):
            i=len(query_records)
            if self.bound is None or i>=self.bound:raise ValueError('fake complete-query bound')
            inp=dataclasses.asdict(value);p,x,y,pairs=lookup[value.対象系境界];a=value.内容[x]
            matches=[z for k,z in pairs if sem.exact(k,a)]
            if len(matches)!=1:raise ValueError('fake unknown condition')
            z=matches[0]
            if mode=='preserve_false' and value.対象系境界==candidate.保存境界:z=False
            preds=[{'原理参照':p['原理識別子'],'結果経路':[y],'予測値':z,'条件値群':[a]}]
            raw={'現在状態版':1,'学習過程':{'学習前状態版':1,'学習後状態版':1},'追跡情報':{'対象系境界':value.対象系境界,'照会参照':'fakeq'+str(i)},'予測群':preds,
              '有効原理群':[x[0] for x in state['原理履歴'].values()],**{n:[] for n in final.不確実項目}}
            ret=Reply('出力',{k:copy.deepcopy(v) for k,v in raw.items() if k not in ('追跡情報','学習過程')},raw['追跡情報'])
            if mode=='hold' and value.対象系境界==candidate.準備境界:
                ret.状態='断定保留';ret.内容['断定保留理由群']=['fixture hold'];raw['断定保留理由群']=['fixture hold']
            origin={'観測指紋':current.指紋,'公開観測参照':public,'復元状態参照':sr,'live採否可能':True}
            record={'ordinal':i,'frame':0,'method':'照会する','input':inp,'origin':origin,'before':{'counter':i},'capture':{}}
            intent=packet('q%03d_intent'%i,record)
            record['capture']={'raw':[raw],'return':dataclasses.asdict(ret)}
            record['after']={'counter':i+1};rp=packet('q%03d_reply'%i,record)
            link={'ordinal':i,'frame':0,'method':'照会する','intent':intent,'reply':rp}
            query_records.append(dict(copy.deepcopy(record),reference=link));self.last=link
            return ret
        def ask(self,b,f):
            ret=self.照会する(Input(f,b));return dict(dataclasses.asdict(ret),実照会保存参照=copy.deepcopy(self.last))
    owner=Owner()
    family=SimpleNamespace(**{k:ns[k] for k in names},役割境界=ns['役割境界'],知覚不適用=NotApplicable,
       図式を観測する=lambda frame:copy.deepcopy(scene),
       選択を読む=lambda frame,s:copy.deepcopy(s['在庫群'][0]) if frame[0][0]==1 else None)
    original=query.semantic_entry(family,candidate,current.最新盤面,list(current.作用可能番号),owner,owner.ask,current.状態)
    save('complete-semantic-result',original,True)
    rep=sem.replay_current(current,family,candidate,query.semantic_entry,query_records,dataclasses.asdict,Reply,original)
    projection=sem.project_current(current,rep,work)
    save('complete-projection',projection,True)
    dsave=lambda label,value:save(label,value,label=='full-candidates')
    dossier=sem.prepare_dossier(rep,projection,sr,1,current.指紋,public,dsave,'a'*32)
    base={'name':name,'mode':mode,'all_query_records':query_records,'semantic':original,'projection':projection,'dossier':dossier,'real_native':0,'realSDK':0}
    if mode in ('hold','preserve_false'):
        sem.require(dossier['status']=='HOLD','unsafe candidate must not dispatch')
        return dict(base,status='PASS',fake_Action=0)
    record=dossier['record']
    store=final.固定証拠(refs,[folder])
    def pure_project(actual):
        result=sem.replay_current(actual,family,candidate,query.semantic_entry,query_records,dataclasses.asdict,Reply,original)
        return plain(sem.project_current(actual,result,work))
    verifier=final.最終採否検査(store,sr,record['final_adoption_ref'],pure_project)
    journal=CheckedJournal(folder/'transport',cap=104<<20,budget_root=S/'evidence')
    transport=adapter.OneStepTransport(journal,verifier=verifier,evidence_roots=[folder],np=np,resource_check=guard.guard)
    after=Observation(marker=1,guid='different' if mode=='guid' else 'synthetic-current')
    env=Env(None if mode=='none' else after,TimeoutError('synthetic step timeout') if mode=='timeout' else None)
    if mode=='stale':record['observation_fingerprint']='0'*64
    if mode=='missing_branch':record['rejection_refs'].pop(next(iter(record['rejection_refs'])))
    if mode=='forged_reply':
        record['action']['number']=5
    if mode in ('stale','missing_branch','forged_reply'):
        try:transport.run(env,Actions,record,observe_current=lambda:(obs,0),hds_version=lambda:1)
        except (adapter.Refusal,adapter.OutcomeUnknown) as e:
            EXCEPTIONS.append(e);base['expected_exception']={'type':type(e).__name__,'traceback':traceback.format_exc()}
        else:raise AssertionError('negative admitted')
        sem.require(not env.calls,'invalid adoption reached step')
        return dict(base,status='PASS',fake_Action=0)
    try:result=transport.run(env,Actions,record,observe_current=lambda:(obs,0),hds_version=lambda:1)
    except adapter.OutcomeUnknown as e:
        EXCEPTIONS.append(e);base['expected_exception']={'type':type(e).__name__,'traceback':traceback.format_exc(),'record':e.record}
        if mode not in ('none','timeout'):raise
        sem.require(len(env.calls)==1,'unknown must retain one dispatched attempt')
        return dict(base,status='PASS',fake_Action=1)
    sem.require(len(env.calls)==1,'one step only')
    chosen=rep['全作用候補']['全候補'][int(record['selected_candidate_id'])]
    phases=[{'scene':copy.deepcopy(scene),'selection':copy.deepcopy(scene['在庫群'][0])}]
    b=work.境界(obs.model_dump(),after.model_dump())
    measured=sem.compare_effect(rep,phases,b,chosen,work)
    if mode=='guid':sem.require(measured['実測目的効果'] is None and measured['UNKNOWN'],'identity break must remain unknown')
    else:sem.require(measured['実測目的効果'] is True,'preparation measurement')
    if not projection['既充足枠全件']:sem.require(measured['全相既充足保存'] is None,'empty set not True')
    semantic={'対象':chosen['対象'],'役割':rep['学習役割'],'関係':rep['全目標pool'],'前提':chosen['前提'],
      '選択理由':['固定候補生成順'],'予測':chosen['照会全件'],'保存条件':dossier['dossier']['候補検査'][record['selected_candidate_id']]['保存条件'],
      '適用範囲':{'可視列のみ':True},'由来参照':[record['final_adoption_ref']],
      '予測実測比較':{'状態':'一致' if measured['実測目的効果'] is True and not measured['UNKNOWN'] else '未確認','根拠参照':[result['public_response']]}}
    intent_path=folder/'transport'/('a'*32+'.intent.json');raw=intent_path.read_bytes()
    intentref={'path':str(intent_path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
    memory=final.日本語記憶へ(result,record,public,intentref,semantic);save('memory',memory,True)
    if mode=='guid':sem.require(memory['HOLD'],'GUID mismatch memory HOLD')
    # Retrying the original current observation must be refused, never a second fake call.
    try:transport.run(env,Actions,record,observe_current=lambda:(obs,0),hds_version=lambda:1)
    except adapter.Refusal as e:EXCEPTIONS.append(e)
    else:raise AssertionError('repeat accepted')
    sem.require(len(env.calls)==1,'repeat performed second step')
    return dict(base,status='PASS',fake_Action=1,result=result,comparison=measured,memory=memory,env_calls=env.calls)
for mode in ('normal','nonempty','hold','preserve_false','stale','missing_branch','forged_reply','guid','none','timeout'):
    try:CASES.append(scenario('fixture-v2-'+mode,mode))
    except BaseException as e:
        EXCEPTIONS.append(e);CASES.append({'name':mode,'status':'FAIL','exception':{'type':type(e).__name__,'args':e.args,'traceback':traceback.format_exc()}})
        break
out={'schema':'column-pilot-pure-integration-v1','status':'PASS' if len(CASES)==10 and all(x['status']=='PASS' for x in CASES) else 'FAIL',
     'cases':CASES,'realSDK':0,'realHDS':0,'realAction':0,'limits':['Synthetic perceptions/replies/environment only. No live factory or native restore was executed.','Full concrete transport/semantic replay and final verifier are tested, not learned prediction correctness.']}
raw=js(encode(out));blob=lzma.compress(raw,check=lzma.CHECK_CRC64,preset=0)
r=guard.save('evidence','fake_e2e_v2.typed.json.xz',blob)
z=lzma.LZMADecompressor();back=z.decompress(Path(r['path']).read_bytes(),max_length=16<<20)
assert z.eof and not z.unused_data and z.check==lzma.CHECK_CRC64 and back==raw
print(json.dumps({'status':out['status'],'count':len(CASES),'report':r,'rawbytes':len(raw),'rawsha256':hashlib.sha256(raw).hexdigest(),'failures':[x for x in CASES if x['status']=='FAIL']},ensure_ascii=False),flush=True)
if out['status']!='PASS':raise AssertionError('synthetic integration failed, all artifacts retained')
