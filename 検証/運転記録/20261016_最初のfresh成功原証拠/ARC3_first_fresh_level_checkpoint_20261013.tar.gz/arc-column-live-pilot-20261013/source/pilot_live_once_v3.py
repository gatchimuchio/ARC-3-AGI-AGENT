"""One fresh instance, current queries, independent adoption, at most one Action.
Real invocation requires an exact, separately approved root gate. Import is
stdlib-only. HDS core and SDK are loaded only after the complete gate preflight.
"""
import ast,copy,dataclasses,hashlib,importlib.util,json,lzma,os,resource,signal,sys,time,traceback,types
from pathlib import Path
import pilot_guard_v3 as guard
from pilot_fresh_factory_v3 import FreshRuntime,read,ref,jsonbytes
import pilot_semantics_v3 as semantics
B=guard.B;ROOT=guard.ROOT;M=1048576
OWNER=None
def same(a,b):return semantics.exact(a,b)
def module(name,r):
    raw=read(r,8*M);sp=importlib.util.spec_from_file_location(name,r['path'])
    m=importlib.util.module_from_spec(sp);sys.modules[name]=m;exec(compile(raw,r['path'],'exec'),m.__dict__);return m
def rawpacket(p):
    blob=read(p['file'],16*M);z=lzma.LZMADecompressor(memlimit=128*M);raw=z.decompress(blob,max_length=16*M+1)
    if not z.eof or z.unused_data or z.check!=lzma.CHECK_CRC64 or len(raw)!=p['rawbytes'] or hashlib.sha256(raw).hexdigest()!=p['rawsha256']:raise ValueError('PacketRef full CRC64/EOF/raw')
    return raw
def closure(g):
    b=g['closed_baseline'];state=read(b['state'],8*M)
    completion=json.loads(rawpacket(b['completion']))
    audit=json.loads(read(b['audit'],M));exittool=json.loads(read(b['actual_exit'],M))
    if completion.get('schema')!='column-all-candidate-query-completion-v1' or completion.get('status')!='complete' or completion.get('errors')!=[]:raise ValueError('latest diagnostic completion')
    if completion.get('Teach')!=0 or completion.get('Action')!=0 or completion.get('frame_count')!=27 or completion.get('unprocessed_suffix')!=[] or completion.get('state_only_paired_Query_counter_change')is not True:raise ValueError('diagnostic full closure')
    if completion['states'][-1]!=b['state']:raise ValueError('latest final state not completion final')
    if audit.get('schema')!=b['audit_schema'] or audit.get('status')!='PASS' or audit.get('errors')!=[]:raise ValueError('independent diagnostic PASS')
    # Exact root-reviewed JSON paths; values are references/counts, not learned predictions.
    if audit.get('schema')!='column-all-candidate-query-independent-audit-v1' or audit.get('nonce')!=completion['nonce'] or audit.get('completion')!=b['completion'] or audit.get('states',[])[-1:]!=[b['state']]:raise ValueError('diagnostic audit actual object joins')
    required=('normal_restore_and_all_state_only_paired_Query_counters','all_actual_queries_raw_external_support_and_profile_joins','all27_phase25_observations_full_pixels_canonical_fingerprint_sequence1_terminal','all_candidates_full_saved_reply_replay_negative_HOLD_and_nonlive_scope','all_files_CRC64_EOF_types_order_sources_unchanged')
    if any(audit.get('verified',{}).get(k)is not True for k in required):raise ValueError('diagnostic audit full verification flags')
    for join in b['audit_joins']:
        x=audit
        for k in join['path']:x=x[k]
        if not same(x,join['equals']):raise ValueError('independent closure join')
    if not b['audit_joins']:raise ValueError('independent joins missing')
    if exittool.get('exit_code')!=0:raise ValueError('diagnostic owner has not closed')
    lines=exittool.get('output','').splitlines()
    objects=[]
    for line in lines:
        try:objects.append(json.loads(line))
        except ValueError:pass
    if not any(type(x)is dict and x.get('receipt')==b['completion'] and x.get('status') in ('complete','closed') for x in objects):raise ValueError('actual exit exact completion join')
    if g.get('latest_closed_diagnostic_root_adopted')is not True:raise PermissionError('latest diagnostic root adoption')
    return state

class Run:
    def __init__(self):
        self.calls=[];self.replay_records=[];self.refs=[];self.states=[];self.errors=[];self.pending=None
        self.factory=None;self.machine=None;self.complete=False;self.step_result=None;self.current=None;self.failing=False
    def save_raw(self,name,data):
        if Path(name).name!=name or len(data)>16*M:raise ValueError('bounded evidence filename')
        self.clock.enter('failure_save' if self.failing else 'save');self.pending={'name':name,'raw':data}
        try:
            category='failure' if self.failing else 'evidence'
            guard.guard(category,len(data));p=(self.failure_folder if self.failing else self.folder)/name
            with p.open('xb') as f:
                if f.write(data)!=len(data):raise OSError('short write')
                f.flush();os.fsync(f.fileno())
            guard.fsyncdir(p.parent)
            if p.read_bytes()!=data:raise OSError('exact evidence readback')
            r=ref(p);self.refs.append(r);self.pending=None;return r
        finally:self.clock.enter('failure_save' if self.failing else 'compute')
    def save(self,name,value,raw=False):
        return self.save_raw(name,value if raw else jsonbytes(value))
    def packet(self,name,value):
        raw=jsonbytes(self.enc(value))
        if len(raw)>16*M:raise MemoryError('complete typed raw16MiB')
        blob=lzma.compress(raw,preset=0,check=lzma.CHECK_CRC64);r=self.save_raw(name+'.typed.json.xz',blob)
        p={'file':r,'rawbytes':len(raw),'rawsha256':hashlib.sha256(raw).hexdigest()}
        if rawpacket(p)!=raw:raise ValueError('full typed packet readback')
        if not same(self.enc(self.dec(json.loads(raw))),self.enc(value)):raise ValueError('typed value/order roundtrip')
        return p
    def standard(self,label):
        self.clock.enter('failure_save' if self.failing else 'save');p=(self.failure_folder if self.failing else self.folder)/(label+'.standard.json');self.pending={'standard':str(p)}
        try:
            guard.guard('failure' if self.failing else 'evidence',8*M)
            fd=os.open(p,os.O_CREAT|os.O_EXCL|os.O_WRONLY|os.O_NOFOLLOW,0o600);before=os.fstat(fd);os.close(fd)
            old=resource.getrlimit(resource.RLIMIT_FSIZE)
            try:resource.setrlimit(resource.RLIMIT_FSIZE,(8*M,old[1]));self.machine.保存する(p)
            finally:resource.setrlimit(resource.RLIMIT_FSIZE,old)
            fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
            try:
                after=os.fstat(fd)
                if (before.st_dev,before.st_ino)!=(after.st_dev,after.st_ino) or after.st_size>8*M:raise ValueError('normal state inode/cap')
                os.fsync(fd)
            finally:os.close(fd)
            guard.fsyncdir(p.parent);raw=p.read_bytes();value=self.dec(json.loads(raw))
            if json.dumps(self.enc(value),ensure_ascii=False,indent=2).encode()!=raw:raise ValueError('normal standard exact bytes')
            if not same(self.enc(value),self.enc(self.query.snapshot_value(self.machine))):raise ValueError('normal standard complete live snapshot')
            r=ref(p);self.refs.append(r);self.states.append(r);self.pending=None;return r,value
        finally:self.clock.enter('failure_save' if self.failing else 'compute')
    def markers(self):
        e=self.machine.エンジン
        return {'identifiers':e.識別子.状態を書き出す(),'ledger_lengths':{k:len(v) for k,v in e.台帳.全取得().items()},
          'principle_history_lengths':{k:len(v) for k,v in e._原理履歴.items()},'state_history_length':len(e.状態.履歴())}
    def version(self):return len(self.machine.エンジン.状態.履歴())-1
    def allow_frame(self,n):
        if type(n)is not int or n<4 or n>self.gate['limits']['max_queries']:raise MemoryError('complete enumeration cannot fit query gate')
        self.bound=n
    @property
    def owner(self):return self
    def 照会する(self,external):
        if self.bound is None or len(self.calls)>=self.bound:raise MemoryError('all-candidate query bound')
        i=len(self.calls);origin=copy.deepcopy(self.origin)
        self.current={'ordinal':i,'frame':0,'method':'照会する','input':external,'origin':origin,'before':self.markers(),'capture':{}}
        intent=self.packet('query_%04d_intent'%i,self.current)
        answer=self.query.capture_call(self.machine,'照会する',external,self.current['capture'])
        self.current['after']=self.markers()
        reply=self.packet('query_%04d_reply'%i,self.current)
        link={'ordinal':i,'frame':0,'method':'照会する','intent':intent,'reply':reply};self.calls.append(link)
        replay=copy.deepcopy(self.current);replay['input']=dataclasses.asdict(external)
        replay['capture']['return']=dataclasses.asdict(answer);replay['reference']=copy.deepcopy(link)
        self.replay_records.append(replay)
        # The complete state is immutable except paired query counters.
        expected=self.dec(self.enc(self.initial))
        for k in ('照会','学習判定'):expected['識別子状態'][k]=expected['識別子状態'].get(k,0)+len(self.calls)
        if not same(self.enc(expected),self.enc(self.query.snapshot_value(self.machine))):raise ValueError('per-query full state/ledger/history changed')
        self.current=None;return answer
    def ask(self,boundary,facts):
        answer=self.照会する(self.native.外部入力(copy.deepcopy(facts),boundary))
        return {'状態':answer.状態,'内容':answer.内容,'追跡情報':answer.追跡情報,'実照会保存参照':copy.deepcopy(self.calls[-1])}
    def preflight(self,path,pin):
        raw=Path(path).read_bytes()
        if hashlib.sha256(raw).hexdigest()!=pin or len(raw)>65536:raise ValueError('exact pilot root gate')
        g=json.loads(raw);self.gate=g
        if g['schema']!='column-live-one-action-release-v1' or g['enabled']is not True:raise PermissionError('root live release')
        if g['limits']!={'AS':1<<30,'compute':900,'save':120,'failure_save':120,'Action':1,'Teach':0,'max_queries':4096}:raise PermissionError('fixed finite live limits')
        soft,hard=resource.getrlimit(resource.RLIMIT_AS)
        if not 0<soft<=1<<30 or not 0<hard<=1<<30:raise PermissionError('AS required before all imports')
        if time.time()>g['admission_deadline_epoch']:raise PermissionError('expired admission')
        self.nonce=g['nonce']
        if type(self.nonce)is not str or len(self.nonce)!=32 or any(x not in '0123456789abcdef' for x in self.nonce):raise ValueError('nonce')
        if read(g['source'])!=Path(__file__).read_bytes():raise ValueError('actual coordinator source')
        contract=json.loads(read(g['contract'],M))
        for r in contract['source_pins']:read(r,8*M)
        for r in contract['core_and_family_pins']:read(r,8*M)
        self.contract=contract;guard.guard()
        import shutil
        if shutil.disk_usage(B).free<(1492+1024)*M:raise MemoryError('latest globalfuture1492MiB plus physical1GiB')
        self.baseline_raw=closure(g)
        self.folder=ROOT/'evidence'/self.nonce
        self.folder.mkdir(exist_ok=False);guard.fsyncdir(self.folder.parent)
        (ROOT/'failure').mkdir(exist_ok=True);self.failure_folder=ROOT/'failure'/self.nonce
        self.failure_folder.mkdir(exist_ok=False);guard.fsyncdir(self.failure_folder.parent)
        # All directories used by ordinary evidence writes and transport must
        # pre-exist before installing the inherited SDK audit hook.
        self.transport_directory=self.folder/'transport';self.transport_directory.mkdir();guard.fsyncdir(self.folder)
        self.query=module('pilot_current_query',contract['query_entry'])
        self.clock=self.query.Clock();self.clock.remaining={'compute':900.0,'save':120.0};self.clock.enter('compute')
        self.candidate=module('pilot_candidates',contract['candidate'])
        self.work=module('pilot_goal_work',contract['goal_work'])
        sys.path.insert(0,str(B/'arc-live-step-adapter-20261013'))
        self.adapter=module('adapter',contract['transport'])
        self.final=module('pilot_final_adoption',contract['final_adoption'])
        self.boundary=self.adapter.load_boundary()
        sys.dont_write_bytecode=True
        core=B/'arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2'
        familyroot=B/'arc-current-family-source-20261013'
        sys.path.insert(0,str(core));sys.path.insert(0,str(familyroot))
        import hds学習系統 as native
        import hds学習系統.永続化 as persistence
        from 接続 import 列図式規則 as family
        if Path(native.__file__).resolve()!=core/'hds学習系統/__init__.py' or Path(family.__file__).resolve()!=familyroot/'接続/列図式規則.py':raise ValueError('actual import source identities')
        self.native=native;self.enc=persistence._符号化;self.dec=persistence._復号;self.family=family
        self.bound=None
        # Target is joined from a prior public structural applicability report.
        # Its identifier routes SDK.make only and never enters semantic input.
        applicability=json.loads(read(g['structural_applicability'],M))
        oldpublic=json.loads(read(applicability['元観測'],8*M))
        if applicability['照合状態']!='固定知覚に適合':raise ValueError('prior structural applicability')
        metadata=json.loads(read(g['metadata'],M))
        target=oldpublic['model_json']['game_id']
        if metadata['game_id']!=target:raise ValueError('structural public metadata target join')
        audit=json.loads(read(g['bundle_audit'],M))
        if audit.get('status')!='PASS' or audit.get('errors') or audit['schema']!='official-bundles-independent-audit-v1':raise ValueError('opaque bundle independent audit')
        targets=[x for x in audit['all_targets'] if x['game_id']==target]
        if len(targets)!=1 or targets[0]['metadata']!=g['metadata']:raise ValueError('opaque bundle metadata selection')
        if g['opaque_bundle_files']!=[x['source'] for x in audit['all_targets']]:raise ValueError('all25 opaque bundle source joins')
        for r in g['opaque_bundle_files']:
            read(r,2*M) # Exact bytes hash only; never decode/display/AST.
        self.target=target;self.metadata=metadata
        self.factory=FreshRuntime(self.nonce,self.folder/'sdk-runtime',self.save)
        # Journal.__init__ mkdir uses exist_ok=True, still emits an audit event.
        # Construct it BEFORE factory installs the inherited no-mkdir hook.
        run=self
        class GuardedJournal(self.adapter.Journal):
            def save(self,name,value,raw=False):
                data=value if raw else run.adapter.raw_json(value)
                guard.guard('evidence',len(data))
                return super().save(name,value,raw=raw)
        self.journal=GuardedJournal(self.transport_directory,cap=104*M,budget_root=ROOT/'evidence')
    def execute(self):
        self.factory.prepare()
        observation=self.factory.initialize(self.target,self.metadata)
        current=self.boundary.観測する(observation,観測通番=0)
        self.public_ref=self.factory.initial_ref
        self.machine=self.native.HDS学習系統.読み込む(self.gate['closed_baseline']['state']['path'])
        first,self.initial=self.standard('restored_before_current_queries')
        if Path(first['path']).read_bytes()!=self.baseline_raw:raise ValueError('latest closed diagnostic normal restore bytes')
        self.origin={'観測指紋':current.指紋,'公開観測参照':self.public_ref,'復元状態参照':self.gate['closed_baseline']['state'],
                     '観測通番':0,'相':len(current.盤面列)-1,'全相数':len(current.盤面列),'live採否可能':True}
        semantic=self.query.semantic_entry(self.family,self.candidate,current.最新盤面,list(current.作用可能番号),self,self.ask,current.状態)
        self.semantic=semantic;self.packet('current_complete_semantic',semantic)
        afterquery,queryvalue=self.standard('after_current_queries')
        if semantic.get('適用性')!='固定知覚適合' or semantic.get('全作用候補')is None:
            return self.finish('HOLD',{'reason':'current structural/goal/role interpretation incomplete'})
        # All native replies for this exact current frame were durably saved.
        # Replay is pure: no second HDS call, no new support, no old-frame reply.
        def replay(actual):
            return semantics.replay_current(actual,self.family,self.candidate,self.query.semantic_entry,self.replay_records,
                  dataclasses.asdict,self.native.外部出力,semantic)
        def project(actual):
            return self.final.復号(self.enc(semantics.project_current(actual,replay(actual),self.work)))
        projected=semantics.project_current(current,replay(current),self.work)
        def dsave(name,value):
            if name=='full-candidates':return self.packet(name,value)['file']
            return self.save(name+'.json',value)
        prepared=semantics.prepare_dossier(semantic,projected,self.gate['closed_baseline']['state'],
                      self.version(),current.指紋,self.public_ref,dsave,self.nonce)
        self.prepared=prepared
        if prepared['status']=='HOLD':return self.finish('HOLD',prepared)
        record=prepared['record'];store=self.final.固定証拠(self.refs+[self.gate['closed_baseline']['state']],[ROOT,self.gate['closed_baseline']['state']['path'].rsplit('/',1)[0]])
        verifier=self.final.最終採否検査(store,self.gate['closed_baseline']['state'],record['final_adoption_ref'],project)
        transport=self.adapter.OneStepTransport(self.journal,verifier=verifier,evidence_roots=[self.folder],
                           np=self.factory.np,resource_check=guard.guard)
        self.step_result=transport.run(self.factory,self.factory.GameAction,record,
                   observe_current=self.factory.observe_current,hds_version=self.version)
        response=self.factory.current
        after=self.boundary.観測する(response,観測通番=1)
        phases=[]
        for i,frame in enumerate(after.盤面列):
            p={'phase':i,'scene':None,'selection':None,'public_response_ref':self.step_result['public_response'],'JSONpath':['frames',i]}
            try:
                p['scene']=self.family.図式を観測する(frame)
                try:p['selection']=self.family.選択を読む(frame,p['scene'])
                except (ValueError,KeyError,TypeError) as e:p['selection_unknown']={'type':type(e).__name__,'args':e.args,'traceback':traceback.format_exc()}
            except (self.family.知覚不適用,ValueError,KeyError,TypeError) as e:p['perception_error']={'type':type(e).__name__,'args':e.args,'traceback':traceback.format_exc()}
            phases.append(p)
        beforemeta=observation.model_dump(exclude={'frame'},mode='json');aftermeta=response.model_dump(exclude={'frame'},mode='json')
        boundary=self.work.境界(beforemeta,aftermeta)
        chosen=next(c for c in semantic['全作用候補']['全候補'] if str(c['候補番号'])==record['selected_candidate_id'])
        measured=semantics.compare_effect(semantic,phases,boundary,chosen,self.work);measuredref=self.packet('all_response_goal_effects',measured)
        preservation=prepared['dossier']['候補検査'][record['selected_candidate_id']]['保存条件']
        expected_preservation=preservation['保存値']
        consistent=measured['実測目的効果'] is True and (expected_preservation is None or measured['全相既充足保存'] is True) and not measured['UNKNOWN']
        language={'対象':chosen['対象'],'役割':semantic['学習役割'],'関係':semantic['全目標pool'],
          '前提':chosen['前提'],'選択理由':['支持済集合の固定候補生成順。学習policyではない'],
          '予測':chosen['照会全件'],'保存条件':preservation,'適用範囲':projected['保存適用署名'][record['selected_candidate_id']],
          '由来参照':[measuredref['file'],record['final_adoption_ref']],
          '予測実測比較':{'状態':'一致' if consistent else '未確認' if measured['実測目的効果'] is None else '不一致',
                           '全実測':measured,'根拠参照':[measuredref['file']]}}
        intent=ref(self.transport_directory/(self.nonce+'.intent.json'))
        memory=self.final.日本語記憶へ(self.step_result,record,self.public_ref,intent,language)
        self.memory_ref=self.packet('Japanese_RuntimeMemory',memory)
        return self.finish('recorded' if not memory['HOLD'] else 'HOLD',{'memory':self.memory_ref,'comparison':measuredref})
    def finish(self,status,result):
        last,value=self.standard('normal_final')
        expected=self.dec(self.enc(self.initial))
        for k in ('照会','学習判定'):expected['識別子状態'][k]=expected['識別子状態'].get(k,0)+len(self.calls)
        if not same(self.enc(expected),self.enc(value)):raise ValueError('final complete knowledge/ledger/history closure')
        for pinned in self.contract['source_pins']+self.contract['core_and_family_pins']:read(pinned,8*M)
        for name in ('state','audit','actual_exit'):read(self.gate['closed_baseline'][name],8*M)
        rawpacket(self.gate['closed_baseline']['completion'])
        diagnostics=self.factory.diagnostics();dr=self.save('sdk_diagnostics.json',diagnostics)
        io_failure=any(x.get('write_error') for x in diagnostics['sdk_io'])
        if diagnostics['sdk_events'] or diagnostics['denials'] or diagnostics['exceptions'] or io_failure:status='HOLD'
        result={'schema':'column-live-one-action-completion-v1','nonce':self.nonce,'status':status,'errors':[],
          'baseline':self.gate['closed_baseline'],'states':self.states,'calls':self.calls,'current_public':self.public_ref,
          'Action_attempted':self.factory.step_attempted,'Action_returned':self.factory.step_returned,'Query':len(self.calls),'Teach':0,
          'result':result,'step':self.step_result,'sdk_diagnostics':dr,'all_saved_refs':copy.deepcopy(self.refs),
          'hidden':'未観測','reward':'未観測','new_independent_support':0,'next_step':'必ず再観測再照会。追加教示は別承認'}
        r=self.save('completion.json',result);self.complete=True;return r
    def failure(self,e):
        self.failure_origin={'pending':self.pending,'current_query':self.current}
        self.errors.append({'type':type(e).__name__,'args':e.args,'traceback':traceback.format_exc()})
        # A response may have returned before SDK phase fsync/guard failed.
        # Recover the public packet from the SAME owner; never call env again.
        if self.factory is not None and self.factory.current is not None:
            try:self.save('failure_current_public.json',self.factory.public_bytes(self.factory.current),raw=True)
            except BaseException as second:self.errors.append({'type':type(second).__name__,'args':second.args,'traceback':traceback.format_exc()})
        if self.machine is not None:
            try:self.standard('failure_normal_state')
            except BaseException as second:self.errors.append({'type':type(second).__name__,'args':second.args,'traceback':traceback.format_exc()})
        failure_context=dict(self.failure_origin)
        original_pending=self.failure_origin['pending']
        if isinstance(original_pending,dict) and type(original_pending.get('raw')) is bytes:
            # Standard HDS codec intentionally has no bytes tag. Preserve
            # pending serialized bytes verbatim, then join by exact FileRef.
            pending_ref=self.save_raw('failure_original_pending.bytes',original_pending['raw'])
            failure_context['pending']={**original_pending,'raw':{'representation':'exact-byte-file','ref':pending_ref}}
        self.packet('failure_full_owner_evidence',{'errors':self.errors,'original_failure_context':failure_context,'recovery_current_query':self.current,'recovery_pending':self.pending,
            'calls':self.calls,'states':self.states,'semantic':getattr(self,'semantic',None),'prepared':getattr(self,'prepared',None),
            'step':self.step_result,'diagnostics':None if self.factory is None else self.factory.diagnostics()})
def main(path,pin):
    global OWNER
    if OWNER is not None:raise RuntimeError('one owner, no rerun')
    OWNER=Run()
    try:
        OWNER.preflight(path,pin);result=OWNER.execute();OWNER.clock.stop()
        print(json.dumps({'status':'complete','receipt':result,'Action':OWNER.factory.step_attempted}),flush=True)
        return result
    except BaseException as e:
        try:
            OWNER.failing=True
            if hasattr(OWNER,'clock'):OWNER.clock.stop();OWNER.clock.remaining['failure_save']=120;OWNER.clock.enter('failure_save')
            if hasattr(OWNER,'enc'):OWNER.failure(e)
            else:guard.save('failure','preflight_'+str(time.time_ns())+'.json',jsonbytes({'type':type(e).__name__,'args':e.args,'traceback':traceback.format_exc()}))
        except BaseException as second:
            OWNER.errors.append({'secondary_type':type(second).__name__,'secondary_traceback':traceback.format_exc()})
        finally:
            if hasattr(OWNER,'clock'):OWNER.clock.stop()
        print(json.dumps({'status':'failed_held','errors':OWNER.errors,'automatic_retry':False},ensure_ascii=False),flush=True)
        while True:time.sleep(3600)
if __name__=='__main__':main(sys.argv[1],sys.argv[2])
