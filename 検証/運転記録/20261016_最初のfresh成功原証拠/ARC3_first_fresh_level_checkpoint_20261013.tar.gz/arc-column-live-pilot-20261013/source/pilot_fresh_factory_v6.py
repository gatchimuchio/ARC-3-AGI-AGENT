"""Pinned fresh OFFLINE factory for the reviewed one-step pilot.
Source-only until a separate root gate invokes the live coordinator.
Game source is never inspected here; only exact opaque file hashing is allowed.
Python audit hooks are not an OS sandbox and that limitation is explicit.
"""
import ast,base64,contextlib,hashlib,json,logging,os,resource,signal,stat,sys,time
from pathlib import Path
import pilot_guard_v4 as guard

B=guard.B
CAPTURE=B/'arc-official-fresh-all25-20261013/prep/fresh_all25_v1.py'
CAPTURE_SHA='52904ce9357a933c2f53daf0cd23b5672dfdb30aef50844f89daa8b56a824516'
SITE=B/'arc-sdk-venv/lib/python3.12/site-packages'
BUNDLES=B/'arc-official-bundles-20261013'
def digest(data):return hashlib.sha256(data).hexdigest()
def ref(path):
    p=Path(path);raw=p.read_bytes()
    return {'path':str(p),'bytes':len(raw),'sha256':digest(raw)}
def read(ref,cap=16<<20):
    if set(ref)!={'path','bytes','sha256'} or type(ref['bytes'])is not int or not 0<=ref['bytes']<=cap:raise ValueError('exact bounded FileRef')
    p=Path(ref['path'])
    if p.is_symlink():raise ValueError('reference symlink')
    raw=p.read_bytes()
    if len(raw)!=ref['bytes'] or digest(raw)!=ref['sha256']:raise ValueError('source/reference changed')
    return raw
def jsonbytes(value):return json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()

class FreshRuntime:
    def __init__(self,nonce,evidence_directory,save):
        self.nonce=nonce;self.directory=Path(evidence_directory);self.save=save
        self.ns=None;self.installed=False;self.make_attempted=0;self.make_returned=0
        self.step_attempted=0;self.step_returned=0;self.env=None;self.current=None
        self.sequence=0;self.opaque=[];self.phase_index=0;self.errors=[]
    def prepare(self):
        guard.guard('evidence',8<<20)
        if self.directory.is_symlink() or not self.directory.resolve().is_relative_to(guard.ROOT/'evidence'):raise ValueError('factory namespace')
        self.directory.mkdir(exist_ok=False)
        for name in ('work','home','cache','tmp','sdk_recordings'):
            (self.directory/name).mkdir(exist_ok=False)
        guard.fsyncdir(self.directory);guard.fsyncdir(self.directory.parent)
        raw=CAPTURE.read_bytes()
        if digest(raw)!=CAPTURE_SHA:raise ValueError('official capture pin')
        t=ast.parse(raw)
        names={'sha','safe_exception','sdk_path','sdk_budget','io_record','release_fd','install_sdk_io_observers','audit_hook',
               'typed','preserve_observation','verify_packet'}
        classes={'SafeSDKHandler'}
        nodes=[n for n in t.body if isinstance(n,ast.FunctionDef) and n.name in names or isinstance(n,ast.ClassDef) and n.name in classes]
        if {n.name for n in nodes}!=names|classes:raise ValueError('fixed SDK IO/capture AST coverage')
        constants={}
        for n in t.body:
            if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='SDK_FILES':
                constants=ast.literal_eval(n.value)
        if len(constants)!=7:raise ValueError('SDK pin coverage')
        for name,pin in constants.items():
            if digest((SITE/name).read_bytes())!=pin:raise ValueError('SDK library pin')
        owner={'stage':'created','exceptions':[],'sdk_events':[],'denials':[],'observation':None,
               'packet':None,'frames':[],'saved':[],'sdk_io':[],'nonfatal_network_diagnostics':[]}
        ns={'__name__':'pinned_sdk_io_bridge','__file__':str(CAPTURE),'base64':base64,'hashlib':hashlib,'json':json,'logging':logging,
            'os':os,'resource':resource,'signal':signal,'stat':stat,'sys':sys,'time':time,'Path':Path,'BASE':B,'SCOPE':guard.ROOT,
            'SITE':SITE,'SDK_FILES':constants,'SDK_PHASE':False,'WRITE_PHASE':True,'OWNER':owner,'NONCE':self.nonce,
            'SDK_DIRS':tuple(self.directory/n for n in ('cache','tmp','sdk_recordings')),
            'SDK_RESERVATIONS':{},'SDK_FDS':{},'QUARANTINE':[],'json_bytes':jsonbytes}
        # Original sdk_budget has category 'prep'; map this one documented
        # caller category to the pilot evidence allowance without lowering cap.
        def admit(category=None,additional=0):
            if category not in (None,'prep'):raise ValueError('unexpected inherited category')
            return guard.guard('evidence' if category else None,additional)
        ns['admit']=admit
        exec(compile(ast.Module(body=nodes,type_ignores=[]),str(CAPTURE),'exec'),ns)
        self.ns=ns
        env={'PATH':str(B/'arc-sdk-venv/bin')+':/usr/bin:/bin','HOME':str(self.directory/'home'),
          'TMPDIR':str(self.directory/'tmp'),'XDG_CACHE_HOME':str(self.directory/'cache'),'MPLCONFIGDIR':str(self.directory/'cache'),
          'LANG':'C.UTF-8','LC_ALL':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1','OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1',
          'MKL_NUM_THREADS':'1','NUMEXPR_NUM_THREADS':'1','VECLIB_MAXIMUM_THREADS':'1','BLIS_NUM_THREADS':'1',
          'OPERATION_MODE':'offline','MPL_IGNORE_SYSTEM_FONTS':'1'}
        os.environ.clear();os.environ.update(env);sys.dont_write_bytecode=True
        os.chdir(self.directory/'work')
        handler=ns['SafeSDKHandler']()
        logging.disable(logging.NOTSET);root=logging.getLogger();root.handlers[:]=[handler];root.setLevel(logging.ERROR)
        logger=logging.getLogger('column-live-sdk');logger.handlers[:]=[handler];logger.propagate=False;logger.setLevel(logging.ERROR)
        self.logger=logger
        ns['install_sdk_io_observers']();sys.addaudithook(ns['audit_hook']);self.installed=True

    @contextlib.contextmanager
    def sdk_phase(self,label):
        if not self.installed:raise ValueError('factory not prepared')
        if getattr(self,'failed_streams',None):raise RuntimeError('opaque flush failure is terminal; no SDK retry')
        guard.guard('evidence',2<<20)
        ns=self.ns;ns['OWNER']['stage']=label
        sys.stdout.flush();sys.stderr.flush()
        saved=[os.dup(1),os.dup(2)];paths=[]
        for number,name in ((1,'stdout'),(2,'stderr')):
            p=self.directory/(str(self.phase_index)+'_'+name+'.opaque')
            fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600);os.dup2(fd,number);os.close(fd)
            paths.append(p);self.opaque.append(p);ns['QUARANTINE'].append(p)
        self.phase_index+=1
        old=resource.getrlimit(resource.RLIMIT_FSIZE)
        resource.setrlimit(resource.RLIMIT_FSIZE,(1<<20,old[1]))
        ns['SDK_PHASE']=True;ns['WRITE_PHASE']=False
        try:yield
        except BaseException as e:
            ns['OWNER']['exceptions'].append(e)
            self.errors.append(ns['safe_exception'](e))
            # Do not let a top-level traceback show opaque game source lines.
            raise RuntimeError('SDK operation failed; sanitized original exception retained') from None
        finally:
            flush_error=None
            for stream in (sys.stdout,sys.stderr):
                try:stream.flush()
                except BaseException as e:
                    ns['OWNER']['exceptions'].append(e);self.errors.append(ns['safe_exception'](e));flush_error=e
            ns['SDK_PHASE']=False;ns['WRITE_PHASE']=True
            resource.setrlimit(resource.RLIMIT_FSIZE,old)
            for number,fd in zip((1,2),saved):
                try:os.fsync(number)
                except OSError:pass
                if flush_error is None:os.dup2(fd,number);os.close(fd)
            if flush_error is not None:
                # Keep original buffered streams and fd1/fd2 isolated forever.
                # Fresh clean text wrappers report only outer sanitized diagnostics.
                self.failed_streams=(sys.stdout,sys.stderr)
                self.safe_outer_streams=[]
                for fd in saved:
                    self.safe_outer_streams.append(os.fdopen(fd,'w',buffering=1,encoding='utf-8',errors='backslashreplace'))
                sys.stdout,sys.stderr=self.safe_outer_streams
            for p in paths:
                guard.fsyncdir(p.parent)
                if p.stat().st_size>1<<20:raise MemoryError('opaque stream cap')
            guard.guard()
            if flush_error is not None:raise RuntimeError('opaque stream flush failed; original diagnostic retained') from None

    def initialize(self,target,metadata):
        if self.make_attempted:raise ValueError('fresh make already attempted; no retry')
        try:
            with self.sdk_phase('SDK_import_and_make'):
                import numpy as np
                from arc_agi import Arcade,OperationMode
                from arcengine import FrameDataRaw,GameAction
                self.np=np;self.GameAction=GameAction;self.FrameDataRaw=FrameDataRaw
                self.arcade=Arcade(arc_api_key='',operation_mode=OperationMode.OFFLINE,
                    environments_dir=str(BUNDLES/'environment_files'),recordings_dir=str(self.directory/'sdk_recordings'),logger=self.logger)
                if self.arcade.operation_mode!=OperationMode.OFFLINE or self.arcade.arc_api_key!='':raise ValueError('offline empty credentials')
                self.make_attempted+=1
                self.env=self.arcade.make(target,seed=0,save_recording=False,include_frame_data=True,render_mode=None,renderer=None)
                self.make_returned+=1
                if self.env is None:raise ValueError('fresh make returned None')
                self.current=self.env.observation_space
                if type(self.current)is not FrameDataRaw or self.current.is_empty():raise ValueError('public initial observation missing')
                # Capture BEFORE subsequent consistency failures.
                self.initial_bytes=self.public_bytes(self.current)
        finally:
            if hasattr(self,'initial_bytes'):
                self.initial_ref=self.save('fresh-initial.public.json',self.initial_bytes,raw=True)
        if self.current.game_id!=target or metadata['game_id']!=target:raise ValueError('public target/version join')
        if self.current.action_input.id.value!=0 or self.current.levels_completed!=0:raise ValueError('not fresh from start')
        if type(self.current.win_levels)is not int or self.current.win_levels!=len(metadata['baseline_actions']):raise ValueError('public level metadata')
        if self.ns['OWNER']['sdk_events'] or self.ns['OWNER']['denials']:raise RuntimeError('SDK diagnostics require HOLD after public capture')
        return self.current

    def public_bytes(self,obs):
        packet=self.ns['preserve_observation'](obs,self.np);raw=jsonbytes(packet)
        self.ns['verify_packet'](raw,obs,self.np)
        if len(raw)>8<<20:raise MemoryError('whole public packet cap')
        return raw

    def observe_current(self):
        if self.env is None:raise ValueError('no current environment')
        # Property read only. No constructor, RESET, step or HDS call.
        obs=self.env.observation_space
        if obs is None:raise ValueError('current public observation unavailable')
        return obs,self.sequence

    def step(self,action,data,reasoning):
        if self.step_attempted>=1:raise PermissionError('process-wide ordinary Action cap1; no retry')
        self.step_attempted+=1
        with self.sdk_phase('ordinary_Action'):
            response=self.env.step(action,data=data,reasoning=reasoning)
            self.step_returned+=1
            # Keep exact response even if later public persistence fails.
            self.current=response
        if response is not None:self.sequence+=1
        return response

    def diagnostics(self):
        o=self.ns['OWNER']
        return {'make_attempted':self.make_attempted,'make_returned':self.make_returned,
          'ordinary_Action_attempted':self.step_attempted,'ordinary_Action_returned':self.step_returned,
          'sdk_events':o['sdk_events'],'sdk_io':o['sdk_io'],'denials':o['denials'],
          'nonfatal_network_diagnostics':o['nonfatal_network_diagnostics'],'exceptions':self.errors,
          'opaque_streams':[ref(p) for p in self.opaque],
          'cache_files':[ref(p) for root in self.ns['SDK_DIRS'] for p in sorted(root.rglob('*')) if p.is_file()],
          'cache_durability':'auxiliary cache is not primary evidence; fsync of every cache file is not guaranteed',
          'containment':'Python audit hooks; no OS/native syscall sandbox claim'}
