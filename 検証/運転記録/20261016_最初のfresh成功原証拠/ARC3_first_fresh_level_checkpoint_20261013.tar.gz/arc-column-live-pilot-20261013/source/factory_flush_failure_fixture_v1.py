"""Synthetic flush failure isolation only; no SDK/HDS."""
import resource
resource.setrlimit(resource.RLIMIT_AS,(512<<20,512<<20))
import sys,os,json,hashlib,signal
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
import pilot_guard_v3 as g
signal.signal(signal.SIGALRM,lambda *a:(_ for _ in ()).throw(TimeoutError('pure120')));signal.alarm(120)
p=Path(__file__).parent/'pilot_fresh_factory_v5.py';raw=p.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='4431fc34bc5bb0151e12c7c81549a3120720c7ad84e9e1c527bcda9404a3db43'
ns={'__name__':'pure_failure'};exec(compile(raw,str(p),'exec'),ns)
root=g.ROOT/'evidence'/'factory-flush-failure-v1';g.guard('evidence',2<<20);root.mkdir(exist_ok=False);g.fsyncdir(root.parent)
r=ns['FreshRuntime']('f'*32,root,lambda *a,**k:None);r.installed=True
r.ns={'OWNER':{'stage':'pure','exceptions':[]},'SDK_PHASE':False,'WRITE_PHASE':True,'QUARANTINE':[],'safe_exception':lambda e:{'type':type(e).__name__}}
original=(sys.stdout,sys.stderr)
class FailFlush:
    def __init__(self,stream):self.stream=stream;self.calls=0
    def write(self,x):return self.stream.write(x)
    def flush(self):
        self.calls+=1
        if self.calls==2:raise OSError('synthetic flush failure')
        return self.stream.flush()
sys.stdout=FailFlush(original[0])
caught=None
try:
    with r.sdk_phase('synthetic_failure'):
        sys.stdout.write('SYNTHETIC_UNFLUSHED_SECRET')
        r.current={'public':'retained'}
except RuntimeError as e:caught=str(e)
assert caught=='opaque stream flush failed; original diagnostic retained'
assert r.current=={'public':'retained'} and len(r.ns['OWNER']['exceptions'])==1
assert sys.stdout is not r.failed_streams[0] and sys.stderr is not r.failed_streams[1]
assert os.fstat(1).st_ino==(root/'0_stdout.opaque').stat().st_ino
# A late flush of the retained old buffer still lands in opaque fd1.
r.failed_streams[0].flush()
assert (root/'0_stdout.opaque').read_bytes()==b'SYNTHETIC_UNFLUSHED_SECRET'
blocked=False
try:
    with r.sdk_phase('forbidden_retry'):pass
except RuntimeError:blocked=True
assert blocked and r.phase_index==1
out={'schema':'pilot-flush-failure-pure-v1','status':'PASS','SDK':0,'HDS':0,'Action':0,'failed_buffer_retained':True,'late_flush_stays_opaque':True,'outer_streams_are_fresh':True,'public_response_retained':True,'SDK_retry_blocked':True,'opaque':[ns['ref'](p) for p in r.opaque],'sanitized_errors':r.errors,'caught':caught}
rr=g.save('evidence','factory_flush_failure_fixture_v1.json',json.dumps(out,ensure_ascii=False,indent=2).encode())
print(json.dumps({'status':'PASS','report':rr}),flush=True)
