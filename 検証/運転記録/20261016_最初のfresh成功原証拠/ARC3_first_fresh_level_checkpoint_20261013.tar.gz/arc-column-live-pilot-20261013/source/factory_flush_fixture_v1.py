"""Real fd/buffer flush seam, synthetic text only. No SDK/HDS import or Action."""
import resource
resource.setrlimit(resource.RLIMIT_AS,(512<<20,512<<20))
import contextlib,hashlib,importlib.util,json,os,sys,traceback,signal
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
import pilot_guard_v3 as g
signal.signal(signal.SIGALRM,lambda *a:(_ for _ in ()).throw(TimeoutError('pure flush120')));signal.alarm(120)
g.guard('evidence',2<<20)
p=Path(__file__).parent/'pilot_fresh_factory_v4.py';raw=p.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='aef335ab1036f42346476105e1bad0c4d6b6bb77b5decdc4f96a9199a9f55bbc'
ns={'__name__':'pure_factory_flush'};exec(compile(raw,str(p),'exec'),ns)
root=g.ROOT/'evidence'/'factory-flush-fixture-v1';root.mkdir(exist_ok=False);g.fsyncdir(root.parent)
r=ns['FreshRuntime']('f'*32,root,lambda *a,**k:None)
r.installed=True
r.ns={'OWNER':{'stage':'fixture','exceptions':[]},'SDK_PHASE':False,'WRITE_PHASE':True,'QUARANTINE':[],
      'safe_exception':lambda e:{'type':type(e).__name__,'text_omitted':True}}
before=[(os.fstat(fd).st_dev,os.fstat(fd).st_ino) for fd in (1,2)]
limit=resource.getrlimit(resource.RLIMIT_FSIZE)
out={'schema':'pilot-opaque-flush-pure-v1','status':'FAIL','errors':[],'SDK':0,'HDS':0,'Action':0}
try:
    with r.sdk_phase('synthetic_fd_only'):
        sys.stdout.write('SYNTHETIC_BUFFERED_STDOUT')
        sys.stderr.write('SYNTHETIC_BUFFERED_STDERR')
    after=[(os.fstat(fd).st_dev,os.fstat(fd).st_ino) for fd in (1,2)]
    assert before==after and resource.getrlimit(resource.RLIMIT_FSIZE)==limit
    values=[(root/'0_stdout.opaque').read_bytes(),(root/'0_stderr.opaque').read_bytes()]
    assert values==[b'SYNTHETIC_BUFFERED_STDOUT',b'SYNTHETIC_BUFFERED_STDERR']
    assert r.ns['SDK_PHASE'] is False and r.ns['WRITE_PHASE'] is True
    out.update(status='PASS',fd_identity_before=before,fd_identity_after=after,
       limit_restored=True,opaque=[ns['ref'](p) for p in r.opaque],
       buffered_bytes_fully_in_opaque=True,SDK_audit_observer_installation=False)
except BaseException as e:
    out['errors'].append({'type':type(e).__name__,'traceback':traceback.format_exc()})
rr=g.save('evidence','factory_flush_fixture_v1.json',json.dumps(out,ensure_ascii=False,indent=2).encode())
print(json.dumps({'status':out['status'],'report':rr}),flush=True)
if out['status']!='PASS':raise AssertionError('full flush fixture failure saved')
