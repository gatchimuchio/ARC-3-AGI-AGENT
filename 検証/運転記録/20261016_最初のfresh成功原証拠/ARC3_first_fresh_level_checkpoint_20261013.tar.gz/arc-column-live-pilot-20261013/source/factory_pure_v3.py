"""Factory seam pure tests. Fake modules/context only; no SDK or native imports."""
import resource
resource.setrlimit(resource.RLIMIT_AS,(512<<20,512<<20))
import ast,contextlib,hashlib,importlib.util,json,os,sys,traceback,types
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
import pilot_guard_v3 as g
g.guard()
import shutil
if shutil.disk_usage(g.B).free<(1492+1024)*1048576:raise MemoryError('latest global reservation')
p=Path(__file__).parent/'pilot_fresh_factory_v3.py'
raw=p.read_bytes()
if hashlib.sha256(raw).hexdigest()!='b7647625d722fe8f558846842d6e9acc3bfedbae5a62c2a3575166a22c6ea4f9':raise ValueError('factory pin')
ns={'__name__':'factory_test'};exec(compile(raw,str(p),'exec'),ns)
Factory=ns['FreshRuntime'];CASES=[]
class Public:
    def __init__(self,target='synthetic'):
        self.game_id=target;self.action_input=types.SimpleNamespace(id=types.SimpleNamespace(value=0));self.levels_completed=0;self.win_levels=1
    def is_empty(self):return False
class Env:
    def __init__(self,obs):self.observation_space=obs;self.calls=[]
    def step(self,*args,**kw):self.calls.append((args,kw));return Public()
class Mode:OFFLINE='offline'
FAKES=[]
class Arcade:
    def __init__(self,**kw):self.operation_mode=kw['operation_mode'];self.arc_api_key=kw['arc_api_key'];self.args=kw;FAKES.append(self)
    def make(self,*args,**kw):self.make_args=(args,kw);return Env(Public())
def build(final_error=False):
    saved=[];r=Factory('0'*32,g.ROOT/'evidence'/'synthetic-not-created',lambda n,x,raw=False:saved.append((n,x,raw)) or {'saved':n})
    r.installed=True;r.logger=None;r.ns={'OWNER':{'sdk_events':[],'denials':[]}}
    @contextlib.contextmanager
    def phase(label):
        yield
        if final_error:raise OSError('synthetic fsync failure')
    r.sdk_phase=phase;r.public_bytes=lambda obs:json.dumps({'actual_public_game':obs.game_id}).encode()
    return r,saved
def check(name,fn):
    try:CASES.append({'name':name,'status':'PASS','result':fn()})
    except BaseException as e:CASES.append({'name':name,'status':'FAIL','error':{'type':type(e).__name__,'traceback':traceback.format_exc()}})
original={n:sys.modules.get(n) for n in ('numpy','arc_agi','arcengine')}
sys.modules['numpy']=types.ModuleType('numpy')
arc=types.ModuleType('arc_agi');arc.Arcade=Arcade;arc.OperationMode=Mode;sys.modules['arc_agi']=arc
engine=types.ModuleType('arcengine');engine.FrameDataRaw=Public;engine.GameAction=object;sys.modules['arcengine']=engine
def positive():
    r,s=build();obs=r.initialize('synthetic',{'game_id':'synthetic','baseline_actions':[1]})
    assert len(s)==1 and r.make_attempted==r.make_returned==1
    before=r.observe_current();assert before==(obs,0)
    r.step('fake-action',{},'reason');assert r.step_attempted==r.step_returned==1 and r.sequence==1
    try:r.step('again',{},'reason')
    except PermissionError:pass
    else:raise AssertionError('second Action')
    assert len(r.env.calls)==1
    return {'saved':s,'make':FAKES[-1].make_args,'step_calls':r.env.calls,'sequence':r.sequence}
def initial_invalid():
    r,s=build()
    try:r.initialize('wrong',{'game_id':'wrong','baseline_actions':[1]})
    except ValueError as e:trace=traceback.format_exc()
    else:raise AssertionError('invalid target')
    assert len(s)==1 and r.current is not None
    return {'saved':s,'expected_fulltrace':trace,'make_attempted':r.make_attempted}
def init_finally():
    r,s=build(True)
    try:r.initialize('synthetic',{'game_id':'synthetic','baseline_actions':[1]})
    except OSError:trace=traceback.format_exc()
    else:raise AssertionError('fsync failure')
    assert len(s)==1 and r.current is not None
    return {'saved':s,'expected_fulltrace':trace}
def step_finally():
    r,s=build();r.initialize('synthetic',{'game_id':'synthetic','baseline_actions':[1]})
    @contextlib.contextmanager
    def bad(label):
        yield
        raise OSError('phase close failed')
    r.sdk_phase=bad
    try:r.step('fake',{},'r')
    except OSError:trace=traceback.format_exc()
    else:raise AssertionError('close failure missing')
    assert r.current is not None and len(r.env.calls)==1 and r.step_attempted==1
    try:r.step('fake',{},'r')
    except PermissionError:pass
    else:raise AssertionError('retry')
    return {'current_public':r.public_bytes(r.current).decode(),'calls':r.env.calls,'expected_fulltrace':trace}
try:
    check('fresh initialize plus one ordinary Action and repeat refusal',positive)
    check('initial consistency error follows full public save',initial_invalid)
    check('SDK phase finalization failure still saves initial public',init_finally)
    check('step returned response retained after finalization failure',step_finally)
finally:
    for n,old in original.items():
        if old is None:sys.modules.pop(n,None)
        else:sys.modules[n]=old
tree=ast.parse(raw)
envassign=next(n for n in ast.walk(tree) if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='env' for x in n.targets) and isinstance(n.value,ast.Dict))
envkeys=[ast.literal_eval(k) for k in envassign.value.keys]
assert not any(k in envkeys for k in ('ARC_API_KEY','API_KEY','OPENAI_API_KEY','AWS_SECRET_ACCESS_KEY'))
CASES.append({'name':'STATIC env allowlist has no credential inheritance keys','status':'PASS','keys':envkeys,'runtime_env_clear_tested':False})
# Execute only the existing audit_hook function against explicit event tuples;
# no installation, real file writes, sockets, subprocesses or SDK execution.
capture=g.B/'arc-official-fresh-all25-20261013/prep/fresh_all25_v1.py'
cr=capture.read_bytes()
assert hashlib.sha256(cr).hexdigest()=='52904ce9357a933c2f53daf0cd23b5672dfdb30aef50844f89daa8b56a824516'
hn={'Path':Path,'os':os,'sys':sys,'SDK_PHASE':False,'WRITE_PHASE':True,'SCOPE':g.ROOT,
    'OWNER':{'denials':[],'stage':'synthetic_hook'},'SDK_DIRS':(),'SDK_FDS':{},'admit':lambda *a:None}
nodes=[n for n in ast.parse(cr).body if isinstance(n,ast.FunctionDef) and n.name in ('audit_hook','sdk_path')]
assert len(nodes)==2
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(capture),'exec'),hn)
for label,event,args,denied in [
 ('permitted own evidence open','open',(str(g.ROOT/'evidence'/'never-opened'),'wb',os.O_WRONLY),False),
 ('outside write denied','open',('/tmp/never-opened','wb',os.O_WRONLY),True),
 ('credential env read denied','open',(str(g.ROOT/'.env'),'r',0),True),
 ('network denied','socket.connect',(),True),
 ('subprocess denied','subprocess.Popen',(),True),
 ('late nonSDK mkdir denied','os.mkdir',(str(g.ROOT/'evidence'/'never-created'),511,-1),True)]:
    actual=False;trace=None
    try:hn['audit_hook'](event,args)
    except PermissionError:actual=True;trace=traceback.format_exc()
    except BaseException as e:
        CASES.append({'name':label,'status':'FAIL','unexpected_type':type(e).__name__,'fulltrace':traceback.format_exc()});continue
    CASES.append({'name':label,'status':'PASS' if actual==denied else 'FAIL','event':event,'args':args,
                  'expected_denial':denied,'actual_denial':actual,'fulltrace':trace})
CASES.append({'name':'full guard latest1492 resource check','status':'PASS','result':g.guard()})
out={'schema':'pilot-factory-pure-seam-v1','status':'PASS' if all(x['status']=='PASS' for x in CASES) else 'FAIL','cases':CASES,
 'realSDK':0,'realHDS':0,'realAction':0,'limitations':['SDK module imports replaced by explicit synthetic modules for four runtime cases.','Actual SDK startup, I/O audit callbacks and resource failures are not executed here; inherited source pins and static audit remain required.']}
r=g.save('evidence','factory_pure_v3.json',json.dumps(out,ensure_ascii=False,indent=2).encode());print(json.dumps({'status':out['status'],'report':r,'cases':len(CASES)}))
if out['status']!='PASS':raise AssertionError('full pure failure retained')
