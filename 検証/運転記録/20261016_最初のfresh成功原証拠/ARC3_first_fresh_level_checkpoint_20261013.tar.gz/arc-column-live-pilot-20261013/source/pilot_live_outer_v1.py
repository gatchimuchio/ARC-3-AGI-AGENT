"""Root-gated live entry. AS is set before importing the coordinator."""
import resource
resource.setrlimit(resource.RLIMIT_AS,(1<<30,1<<30))
import hashlib,json,sys,os
from pathlib import Path
sys.dont_write_bytecode=True
def read(ref):
    p=Path(ref['path']);raw=p.read_bytes()
    if p.is_symlink() or len(raw)!=ref['bytes'] or hashlib.sha256(raw).hexdigest()!=ref['sha256']:raise ValueError('exact source gate pin')
    return raw
graw=Path(sys.argv[1]).read_bytes()
if hashlib.sha256(graw).hexdigest()!=sys.argv[2]:raise ValueError('root gate SHA')
g=json.loads(graw)
if g['schema']!='column-live-one-action-release-v1' or g['enabled']is not True:raise PermissionError('live release missing')
if read(g['outer'])!=Path(__file__).read_bytes():raise ValueError('actual outer source')
contract=json.loads(read(g['contract']))
for ref in contract['source_pins']:read(ref)
source=read(g['source'])
sys.path.insert(0,str(Path(__file__).parent))
ns={'__name__':'pilot_live_main','__file__':g['source']['path']}
exec(compile(source,g['source']['path'],'exec'),ns)
receipt=ns['main'](sys.argv[1],sys.argv[2])
print('UTCEND '+__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),flush=True)
