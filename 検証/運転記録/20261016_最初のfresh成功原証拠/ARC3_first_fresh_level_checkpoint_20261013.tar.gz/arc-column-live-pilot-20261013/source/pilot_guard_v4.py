"""Finite pilot scope guard; no SDK/HDS import."""
from pathlib import Path
import os,shutil,hashlib
B=Path('/workspace/scratch/a94ff513b3af')
ROOT=B/'arc-column-live-pilot-20261013'
M=1048576
CAPS={'source':8*M,'evidence':104*M,'failure':16*M}
def guard(category=None,extra=0):
    if type(extra)is not int or extra<0:raise ValueError('prospective bytes')
    if ROOT.is_symlink():raise ValueError('scope symlink')
    used={}
    for k,cap in CAPS.items():
        p=ROOT/k
        if p.is_symlink():raise ValueError('category symlink')
        entries=list(p.rglob('*')) if p.exists() else []
        if any(x.is_symlink() for x in entries):raise ValueError('file symlink')
        used[k]=sum(x.stat().st_size for x in entries if x.is_file())
        if used[k]+(extra if category==k else 0)>cap:raise MemoryError('category '+k)
    if sum(used.values())+extra>128*M:raise MemoryError('pilot total')
    free=shutil.disk_usage(B).free
    if free<(1492+1024)*M+extra:raise MemoryError('all future1492MiB + physical1GiB')
    mem=next(int(x.split()[1])*1024 for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:'))
    if mem<(5632+2048)*M:raise MemoryError('full RAM5.5GiB + floor2GiB')
    return {'used':used,'disk_free':free,'MemAvailable':mem,'future_disk':1492*M,'reserved_RAM':5632*M}
def fsyncdir(p):
    f=os.open(p,os.O_RDONLY)
    try:os.fsync(f)
    finally:os.close(f)
def save(category,name,data):
    if Path(name).name!=name or category not in CAPS:raise ValueError('write namespace')
    guard(category,len(data))
    ROOT.mkdir(exist_ok=True);fsyncdir(B)
    (ROOT/category).mkdir(exist_ok=True);fsyncdir(ROOT)
    p=ROOT/category/name
    with p.open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
    fsyncdir(p.parent)
    if p.read_bytes()!=data:raise OSError('full readback')
    guard()
    return {'path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
