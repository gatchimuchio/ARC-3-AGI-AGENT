import os,sys,resource,pathlib,json,hashlib,tarfile,gzip,io,lzma,time
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
B=pathlib.Path('/workspace/scratch/a94ff513b3af');O=B/'arc-column-live-loop-20261013/evidence/checkpoint_first_level';L=B/'arc-column-live-loop-20261013';P=B/'arc-column-live-pilot-20261013';R=L/'evidence/d7bbc7465f691c7bb7bb6e5a76089762';quota=32*1024**2
files=set();excluded=[]
def add(p):
 p=pathlib.Path(p)
 if p.is_file():
  if '.opaque' in p.name or 'sdk-runtime' in p.parts or 'environment_files' in p.parts:excluded.append({'path':str(p.relative_to(B)),'bytes':p.stat().st_size,'reason':'opaque or game bundle body excluded; not opened'});return
  assert not p.is_symlink();files.add(p)
def tree(p):
 for x in p.rglob('*'): add(x)
def read(p):return json.loads(p.read_text())
def digest(p):
 h=hashlib.sha256();n=0
 with p.open('rb') as f:
  while x:=f.read(65536):h.update(x);n+=len(x)
 return n,h.hexdigest()
def dump(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
# Closed runs and failure/preparation history only. Explicit version cutoff excludes active later work.
for p in [R,P/'evidence/502f9dd64c29158c6189c4efa50c107d',P/'failure/2a1f6f20880913b61706edfff74d3a84']:tree(p)
for p in P.joinpath('source').iterdir():add(p)
for p in P.joinpath('evidence').iterdir():
 if p.is_file():add(p)
 elif p.name.startswith(('fixture-','factory-flush-')):tree(p)
loopnames=['loop_fresh_factory_v1.py','loop_outer_v1.py','loop_live_v1.py','loop_live_v2.py','loop_live_v3.py','loop_contract_v1.json','loop_contract_v2.json','loop_guard_v1.py','pilot_to_loop_v1.diff','loop_v1_v2.diff','loop_v2_v3.diff','root_loop_release_d7bbc7465f691c7bb7bb6e5a76089762.json']
loopnames += [f'loop_pure_e2e_v{i}.py' for i in range(1,6)]
for n in loopnames:add(L/'source'/n)
for n in ['preparation_actual_tools_v1.json','actual_live_loop_tools_d7bbc746_v1.json','independent_loop_d7bbc746_summary_v1.json','independent_loop_d7bbc746_actual_tools_v1.json','independent_loop_d7bbc746_audit_v1.py']+[f'pure_loop_v{i}.typed.json.xz' for i in range(1,6)]:add(L/'evidence'/n)
for p in L.joinpath('evidence').iterdir():
 if p.is_dir() and p.name.startswith(tuple(f'pure-loop-v{i}-' for i in range(1,6))):tree(p)
for p in (B/'arc-recovery-authority-20261013').iterdir():add(p)
for n in ['AGENTS.md','運用/権限順序.md','制御/現在状態.json']:add(B/'arc-recovery-main-20261013/repository'/n)
contracts=[read(L/'source/loop_contract_v2.json'),read(P/'source/pilot_contract_v4.json')]
pinchecks=[]
for c in contracts:
 for ref in c['source_pins']+c['core_and_family_pins']:
  p=pathlib.Path(ref['path']);n,h=digest(p);assert (n,h)==(ref['bytes'],ref['sha256']),str(p);add(p);pinchecks.append(ref)
for name in ['column_perception_case_18.json']:add(B/'arc-current-family-source-20261013'/name)
add(B/'arc-official-fresh-initial-20261013/prep/bundle_independent_audit_v1.json')
add(B/'arc-column-operation-candidates-20261013/source/column_candidates_v3.py')
d=read(R/'completion.json');audit=read(L/'evidence/independent_loop_d7bbc746_summary_v1.json')
steps=[];lines=[]
for i,t in enumerate(d['trajectory']):
 dossier=read(next(R.glob(f'step_{i:02d}_*_dossier.json')));cands=read(next(R.glob(f'step_{i:02d}_*_technical-candidates.json')));a=t['step']['action'];ids=[c['candidate_id'] for c in cands if c['action']==a];assert len(ids)==1;cid=ids[0];selected=dossier['候補検査'][cid];s=audit['steps'][i]
 steps.append({'step':i,'selected_candidate':cid,'selected_reason_and_support':selected,'all_candidate_inspections':dossier['候補検査'],'trajectory':t,'independent_audit':s})
 lines.append(f"手 {i+1}（step_{i:02d}）: {s['selected_operation']}。Action {a['number']} {json.dumps(a['arguments'],ensure_ascii=False)}。Query {s['Query']}、応答 {s['response_phases']} 相。採用候補 {cid}。前提 {json.dumps(selected['前提'],ensure_ascii=False)}。未実行候補 {','.join(t['step']['unexecuted_candidate_ids']) or 'なし'}。\n  支持根拠: {','.join(x['用途'] for x in selected['照会参照全件'])} の当該状態への実照会。保存条件の由来: {selected['保存条件']['由来']}。\n  原票: step_{i:02d}_{t['request_id']}_dossier.json、同接頭辞 support-index.json / full-candidates.typed.json.xz / Japanese_RuntimeMemory.typed.json.xz、transport/{t['request_id']}.before.json と .response.json。")
dump(O/'各手の採用根拠と全候補.json',steps)
report='''ARC3 最初の fresh レベル成功チェックポイント
2026年10月13日 UTC

1 結論
固定した HDS v0.4.2 を用い、fresh instance の同一環境で観測、全候補の照会、採否、Action、再観測を繰り返し、公開 completed levels の 0 から 1 への遷移を確認した。9 Actions、126 Queries、Teach 0。独立監査は PASS。最初の成功1レベルであり、全183レベルに対して約0.55%。25ゲーム走破、対象ゲームの全8レベル完了、未見問題への転用を示す結果ではない。

2 固定した基底と学習
main基底は 9ce1830494bb80f5d820fbad61ca9096954a04c6。HDS中核 v0.4.2 は変更していない。事前78経験に修復13、準備14、保存24の教師経験を加えた129経験を保持した状態を使用した。これらの教師原票と学習閉包は既に別送したCP3に記録済みで、本書では巨大な既送録画を重複収録しない。実運転中の追加 Teach は0で、今回の生の経験は新しい学習済み支持として昇格させていない。
対象は公開教師と同じ初期盤面。別fresh instanceでの完全な9手再現は、このチェックポイント時点では未実施。初回成功と独立読取監査を、別実行での再現成功と読み替えない。

3 確認できた差分
先行パイロット 502f9dd64c29158c6189c4efa50c107d は fresh 1 Action、13 Queries、Teach 0 で準備操作が成立し、公開レベル数は0のまま。独立監査 PASS。
本ループ d7bbc7465f691c7bb7bb6e5a76089762 は、そこから引き継いだ学習機状態を新しい環境に接続して9手を実行し、公開レベル数が1になった。全150応答相（最終提出118相）を保存。11個の正常状態における学習知識と履歴は保持され、照会カウンタだけが378から504へ増加した。これは同一条件の統制比較による汎化性能改善率ではない。

4 各手の判断と原票
候補の固定生成順で支持された候補を選ぶ方針は呼出側の方針であり、学習済み選択方策だとは主張しない。毎手、新しい公開観測を投影し直し、当該状態へのHDS実照会と適用前提で採否している。全候補、非採用理由、支持索引、照会の生入出力、前後公開観測、日本語Runtime Memoryを収録した。以下の原票名はループのnonceディレクトリ内を指す。

'''+ '\n\n'.join(lines)+'''

5 終端と UNKNOWN の扱い
completion.current_public は最後のAction直前の参照であり、最終公開応答ではない。CONTINUEのときだけ current_public が更新され、成功終了は更新より前に保存されるためである。最終応答は completion.step.public_response、具体的には transport/e0440a5fbd9345aabb609eafe68bf290.response.json（673181 bytes、SHA256 241dca1bb994d2f30aa2363d4248cd0cf7986df0074ed6eae24d03f4767475b8）。最終応答欠落ではない。
提出は、現在の列が終端条件に一致するとの支持と採否に基づく。提出後は旧問題の意味範囲が終了するため、旧範囲の UNKNOWN を保持し、通常の保存条件を成功へ改変しない。レベル成功の根拠は、採用済み提出の公開応答における completed levels の増加である。終端演出中の知覚例外・不適用も原票に残している。hidden state と reward は未観測。そこから隠れた因果や報酬を推測していない。

6 失敗と限界
先行起動 2a1f6f20880913b61706edfff74d3a84 は環境make前に ModuleNotFoundError で失敗した。モジュール名はUNKNOWNのまま扱い、当時のowner 2505と失敗証拠を保持した。Action再試行による回復ではなく、後続の別許可起動で既存の公式接続用venvを使った。元の失敗原票、actual tool receipts、監査の途中失敗、純粋fixtureの旧失敗とソース版を含めた。opaque SDK出力の本文とゲーム実装は収録・読解していない。
成功軌跡の新しい学習規則化、別盤面・別ゲーム転用、完全fresh再現、残り182レベルの成功はいずれも未確認。現在の新ループ版の実装・試験はこのチェックポイントに含めない。

7 検証と再読方法
source_manifest.json の各相対path、bytes、SHA256で原票を対応付ける。元JSON内の絶対pathは /workspace/scratch/a94ff513b3af/ をアーカイブ展開先に置き換えて参照できる。各手の採用根拠と全候補.json は全候補の検査と生原票参照を一覧化したもの。契約、release、core/source pins、独立監査ソースと結果を同梱した。
証拠の再読はSDKやHDSやActionを呼ばずに行える。本アーカイブは読取監査用の閉じた証拠集合であり、ゲーム実装、SDK実行環境と以前の教師全記録は別管理。再実行にはそれらのpin一致および新しい実行許可が必要で、古いreleaseを再利用しない。外部参照と除外理由は source_manifest.json に明記した。

8 資源上限
追加保存は既存ループscope512 MiB（source16、evidence464、failure32）内のcheckpoint用32 MiB以下。新しい外部quotaは増やさない。global disk future2004 MiBとfloor1024 MiB、RAM reserved5632 MiBとfloor2048 MiBを前提とし、包装workerのASを512 MiBに制限した。アーカイブ生成、SHA計算、読戻しは64 KiB単位で流し、全展開コピーは作らない。
検証結果と完成アーカイブのbytes/SHA256は archive_validation.json を参照。gzip全量EOF/CRC、tar全member、manifestとの一致、各memberと元ファイルの全byte再読を検査する。これは新たなゲーム再実行ではない。
'''
(O/'最初のレベル成功報告.txt').write_text(report)
add(O/'各手の採用根拠と全候補.json');add(O/'最初のレベル成功報告.txt');add(O/'build_checkpoint.py')
# Collect file references from closed metadata; unresolved prior references explicitly remain external.
external={}
def refs(x):
 if isinstance(x,dict):
  if isinstance(x.get('path'),str) and 'bytes' in x and 'sha256' in x:
   p=pathlib.Path(x['path'])
   if p not in files:external[str(p)]={**x,'reason':'excluded opaque/game bundle' if 'environment_files' in p.parts or '.opaque' in p.name else ('external SDK installation' if 'arc-sdk-venv' in p.parts else 'prior CP3 or earlier dependency; reference retained, outside checkpoint evidence closure')}
  for v in x.values():refs(v)
 elif isinstance(x,list):
  for v in x:refs(v)
for p in sorted(files):
 if p.suffix=='.json' and p.stat().st_size<2*1024**2:
  try:refs(read(p))
  except (ValueError,UnicodeError):pass
entries=[]
for p in sorted(files):
 n,h=digest(p);entries.append({'path':str(p.relative_to(B)),'bytes':n,'sha256':h})
manifest={'schema':'arc3-first-level-checkpoint-v1','cutoff':'closed d7bbc746 loop with loop_live_v3 and loop_contract_v2; closed pilot502f; no subsequent version','archive_purpose':'self-contained public evidence audit; not standalone SDK runtime or repeat authorization','files':entries,'source_pin_checks':len(pinchecks),'external_refs':list(external.values()),'excluded_bodies':excluded,'limits':{'additional_quota_bytes':quota,'worker_AS_bytes':512*1024**2,'source16_evidence464_failure32_MiB':True,'global_disk_future_MiB':2004,'disk_floor_MiB':1024,'RAM_reserved_MiB':5632,'RAM_floor_MiB':2048}}
dump(O/'source_manifest.json',manifest)
files.add(O/'source_manifest.json')
archive=O/'ARC3_first_fresh_level_checkpoint_20261013.tar.gz'
with archive.open('wb') as out:
 with gzip.GzipFile(filename='',mode='wb',fileobj=out,mtime=0,compresslevel=6) as gz:
  with tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT) as tar:
   for p in sorted(files):
    info=tar.gettarinfo(str(p),arcname=str(p.relative_to(B)));info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
    with p.open('rb') as f:tar.addfile(info,f)
    assert out.tell()<quota-1024**2
# Full gzip decompression through EOF including CRC validation.
uncompressed=0
with gzip.open(archive,'rb') as f:
 while b:=f.read(65536):uncompressed+=len(b)
expected={str(p.relative_to(B)):p for p in files};seen=[];checked=0
with tarfile.open(archive,mode='r|gz') as tar:
 for m in tar:
  assert m.isfile() and m.name in expected and m.name not in seen
  p=expected[m.name];assert m.size==p.stat().st_size;h=hashlib.sha256();n=0
  with p.open('rb') as src:
   f=tar.extractfile(m)
   while b:=f.read(65536):assert b==src.read(len(b));h.update(b);n+=len(b)
   assert src.read(1)==b''
  if m.name!=str((O/'source_manifest.json').relative_to(B)):
   e=next(e for e in entries if e['path']==m.name);assert n==e['bytes'] and h.hexdigest()==e['sha256']
  seen.append(m.name);checked+=n
assert set(seen)==set(expected)
n,h=digest(archive);total=sum(p.stat().st_size for p in O.iterdir() if p.is_file());assert total<quota
v={'status':'PASS','archive':str(archive),'archive_bytes':n,'archive_sha256':h,'member_count':len(seen),'member_bytes_full_readback':checked,'gzip_decompressed_bytes_through_EOF':uncompressed,'gzip_CRC_and_EOF':'PASS','tar_all_members':'PASS','manifest_bytes_sha256':'PASS','all_members_exact_source_byte_readback':'PASS','source_pin_checks':len(pinchecks),'checkpoint_total_bytes_before_validation':total,'quota_bytes':quota,'no_SDK_HDS_Action_or_Git_write':True,'excluded_opaque_bodies_not_opened':True,'source_manifest_sha256':digest(O/'source_manifest.json')[1]}
dump(O/'archive_validation.json',v);print(json.dumps(v,ensure_ascii=False))
