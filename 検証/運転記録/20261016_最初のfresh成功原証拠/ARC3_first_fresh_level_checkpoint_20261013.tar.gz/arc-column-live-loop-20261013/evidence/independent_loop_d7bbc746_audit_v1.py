import resource
resource.setrlimit(resource.RLIMIT_AS,(512<<20,512<<20))
import ast,base64,copy,dataclasses,hashlib,importlib.util,json,lzma,os,signal,sys,time,traceback
from pathlib import Path
B=Path('/workspace/scratch/a94ff513b3af');P=B/'arc-column-live-loop-20261013';N='d7bbc7465f691c7bb7bb6e5a76089762';D=P/'evidence'/N
BASE=B/'arc-column-learning-audit-20261013/source/audit_v1.py'
base=BASE.read_bytes()
assert hashlib.sha256(base).hexdigest()=='e95c8a8307be21b9dc9981685fe84d2b41c0a8216b38f45361e47f4a0d267324'
exec(compile(base.decode().split('def main():',1)[0],str(BASE),'exec'),globals())
P=B/'arc-column-live-loop-20261013';N='d7bbc7465f691c7bb7bb6e5a76089762';D=P/'evidence'/N
sys.path.insert(0,str(P/'source'));import loop_guard_v1 as g
def out(name,value):
 raw=(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode()
 return g.save('evidence','independent_loop_d7bbc746_'+name,raw)
def main():
 global enc,dec,CURSOR
 signal.signal(signal.SIGALRM,timeout);signal.alarm(300);g.guard('evidence',2<<20)
 cref={'path':str(D/'completion.json'),'bytes':369036,'sha256':'9fd648729823dae0a4471d8307dc9151d5edfa2d8b286ea3330abee9bd296345'}
 c=js(exact(cref))
 toolref={'path':str(P/'evidence/actual_live_loop_tools_d7bbc746_v1.json'),'bytes':1561,'sha256':'7152eaa208a780a77e1e163214ff3942354a0ffaead6e22ecb13930b89fe6e9c'}
 tools=js(exact(toolref))
 assert tools['actual_exit']==0
 exits=[x for x in tools['polls'] if x.get('exit_code')==0];assert len(exits)==1
 assert js(exits[0]['output'].splitlines()[0])['receipt']==cref
 gate=js(plain(P/'source'/('root_loop_release_'+N+'.json')));contract=js(exact(gate['contract']))
 for r in contract['source_pins']+contract['core_and_family_pins']:exact(r,8*M)
 assert c['baseline']==gate['closed_baseline'] and c['status']=='LEVEL_SUCCESS' and c['errors']==[]
 assert c['Teach']==0 and c['Query']==len(c['calls'])==126 and c['Action_attempted']==c['Action_returned']==len(c['trajectory'])==9
 sys.dont_write_bytecode=True;sys.path[:0]=[str(CORE),str(F),str(B/'arc-live-step-adapter-20261013')]
 import hds学習系統.永続化 as codec
 from hds学習系統.型 import 外部出力,実行結果,学習成立状態
 from 接続 import 列図式規則 as family
 enc,dec=codec._符号化,codec._復号
 import adapter
 final=load('audit_loop_final',B/'arc-live-step-adapter-20261013/final_adoption_v4.py')
 sem=load('audit_loop_semantics',B/'arc-column-live-pilot-20261013/source/pilot_semantics_v3.py')
 query=load('audit_loop_query',Path(contract['query_entry']['path']))
 work=load('audit_loop_work',Path(contract['goal_work']['path']))
 candidate=load('audit_loop_candidates',Path(contract['candidate']['path']))
 boundary=adapter.load_boundary()
 def standard(r):
  raw=exact(r);tag=js(raw);v=dec(tag)
  assert same(enc(v),tag) and json.dumps(tag,ensure_ascii=False,indent=2).encode()==raw
  return v
 initial=standard(c['states'][0]);assert c['states'][0]['sha256']==c['baseline']['state']['sha256']
 prior=js(exact(c['baseline']['audit']));assert prior['status']=='PASS' and all(prior['verified'].values()) and prior['states'][-1]==c['baseline']['state']
 exact(c['baseline']['state']);exact(c['baseline']['completion']);exact(c['baseline']['actual_tools'])
 for r in c['all_saved_refs']:exact(r)
 def public(r,seq):
  v=js(exact(r));assert v['frame_count']==len(v['frames'])
  def decpub(x):
   if type(x)is not dict:return x
   if 'dict'in x:return {decpub(k):decpub(y) for k,y in x['dict']}
   if 'list'in x:return [decpub(y) for y in x['list']]
   if 'tuple'in x:return tuple(decpub(y) for y in x['tuple'])
   if 'enum'in x:return decpub(x['value'])
   if 'float'in x:return float.fromhex(x['float'])
   raise ValueError('public tag')
  assert same(decpub(v['model_python_typed']),v['model_json'])
  for i,f in enumerate(v['frames']):
   raw=base64.b64decode(f['base64'],validate=True)
   assert i==f['ordinal'] and f['dtype']=='|i1' and f['shape']==[64,64] and f['order']=='C' and len(raw)==f['bytes']==4096 and digest(raw)==f['sha256']
  return v,query.canonical_observation(boundary,v,seq)
 ex=CORE/'hds学習系統/排気系.py';fn=next(x for x in ast.walk(ast.parse(ex.read_bytes())) if isinstance(x,ast.FunctionDef) and x.name=='排出する')
 ns={'asdict':dataclasses.asdict,'Any':object,'外部出力':外部出力,'実行結果':実行結果,'学習成立状態':学習成立状態}
 exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])),str(ex),'exec'),ns)
 histories={p.原理識別子:p for h in initial['原理履歴'].values() for p in h}
 observations={e.経験識別子:e for e in initial['台帳']['観測台帳']}
 previous_mark=None;ordinal=0;reports=[];totalphases=0;trace_checks=[]
 for si,t in enumerate(c['trajectory']):
  CURSOR='step_'+str(si);rid=t['request_id'];prefix='step_%02d_%s_'%(si,rid)
  assert len(rid)==32 and len({x['request_id'] for x in c['trajectory']})==9
  def pf(name):return pfile(prefix+name)
  before,bcur=public(t['before_public'],si);after,acur=public(t['step']['public_response'],si+1)
  assert after['nonce']==rid
  if si:
   assert t['before_public']==c['trajectory'][si-1]['step']['public_response']
   assert t['before_state']==c['trajectory'][si-1]['state']
  else:assert t['before_state']==c['states'][0] and before['nonce']==N
  assert t['before_state']==c['states'][si] and t['state']==c['states'][si+1]
  assert bcur.ゲーム識別子==acur.ゲーム識別子 and bcur.実行識別子==acur.実行識別子
  replay=[];links=[x for x in c['calls'] if x['frame']==si]
  for link in links:
   assert link['ordinal']==ordinal and link['method']=='照会する'
   intent=packet(link['intent']);reply=packet(link['reply'])
   for k in ('ordinal','frame','method','input','origin','before'):assert same(enc(intent[k]),enc(reply[k]))
   assert intent['capture']=={} and reply['origin']['live採否可能'] is True
   assert reply['origin']['観測指紋']==bcur.指紋 and reply['origin']['公開観測参照']==t['before_public'] and reply['origin']['復元状態参照']==t['before_state'] and reply['origin']['観測通番']==si
   cap=reply['capture'];assert cap['profile_restored'] is True and len(cap['raw'])==len(cap['events'])==1 and cap['events'][0]['exact_code_self'] is True
   raw=cap['raw'][0];ret=cap['return'];assert same(enc(ns['排出する'](None,raw)),enc(ret))
   if previous_mark is not None:assert same(previous_mark,reply['before'])
   expected_mark=copy.deepcopy(reply['before'])
   for k in ('照会','学習判定'):expected_mark['identifiers'][k]=expected_mark['identifiers'].get(k,0)+1
   assert same(expected_mark,reply['after']);previous_mark=reply['after']
   for p in raw.有効原理群:
    assert same(enc(p),enc(histories[p.原理識別子])) and all(e in observations for e in p.根拠参照群+p.反証参照群)
   for pred in raw.予測群:
    p=histories[pred.原理参照];assert p.対象系境界==reply['input'].対象系境界 and p.結果経路==pred.結果経路
   rr=copy.deepcopy(reply);rr['input']=dataclasses.asdict(reply['input']);rr['capture']['return']=dataclasses.asdict(ret);rr['reference']=link;replay.append(rr);ordinal+=1
  st=standard(t['state']);expected=dec(enc(initial))
  for k in ('照会','学習判定'):expected['識別子状態'][k]+=ordinal
  assert same(enc(st),enc(expected))
  semantic=pf('current_complete_semantic.typed.json.xz')
  def project(actual):
   value=sem.replay_current(actual,family,candidate,query.semantic_entry,replay,dataclasses.asdict,外部出力,semantic)
   return final.復号(enc(sem.project_current(actual,value,work)))
  projected=project(bcur)
  intent=js(plain(D/'transport'/(rid+'.intent.json')));record=intent['adoption'];evidence=intent['all_evidence']
  store=final.固定証拠(list(REFS.values()),[P])
  verifier=final.最終採否検査(store,t['before_state'],record['final_adoption_ref'],project)
  assert verifier(record,evidence,bcur,len(initial['状態履歴'])-1)==intent['attestation']
  assert record['request_id']==rid and record['observation_fingerprint']==bcur.指紋
  assert js(plain(D/'transport'/(rid+'.dispatch.json')))['action']==record['action']==t['step']['action']
  assert js(plain(D/'transport'/('consumed-'+bcur.指紋+'.json')))['request_id']==rid
  assert js(plain(D/'transport'/(rid+'.result.json')))==t['step']
  beforecopy=js(plain(D/'transport'/(rid+'.before.json')))
  # Transport recaptures the same public value with this step's nonce.
  expectedcopy=copy.deepcopy(before);expectedcopy['nonce']=rid
  assert same(beforecopy,expectedcopy)
  analysis=adapter.phases(bcur,acur,record['action']['number'])
  assert json.loads(json.dumps(analysis,ensure_ascii=False))==t['step']['analysis']
  assert after['model_json']['action_input']['id']==record['action']['number'] and after['model_json']['action_input']['data']==record['action']['arguments']
  saved_measure=packet(t['comparison']);phases=[]
  for pi,fr in enumerate(acur.盤面列):
   original=saved_measure['全相'][pi]['元観測']
   p={'phase':pi,'scene':None,'selection':None,'public_response_ref':t['step']['public_response'],'JSONpath':['frames',pi]}
   try:
    p['scene']=family.図式を観測する(fr)
    try:p['selection']=family.選択を読む(fr,p['scene'])
    except (ValueError,KeyError,TypeError) as e:
     error=original['selection_unknown'];assert error['type']==type(e).__name__ and same(error['args'],e.args) and type(error['traceback'])is str and error['traceback']
     p['selection_unknown']=copy.deepcopy(error);trace_checks.append([si,pi,'selection',error['type']])
   except (family.知覚不適用,ValueError,KeyError,TypeError) as e:
    error=original['perception_error'];assert error['type']==type(e).__name__ and same(error['args'],e.args) and type(error['traceback'])is str and error['traceback']
    p['perception_error']=copy.deepcopy(error);trace_checks.append([si,pi,'perception',error['type']])
   assert same(enc(p),enc(original));phases.append(p)
  totalphases+=len(phases)
  chosen=next(x for x in semantic['全作用候補']['全候補'] if str(x['候補番号'])==record['selected_candidate_id'])
  bound=work.境界(before['model_json'],after['model_json'])
  measured=sem.compare_effect(semantic,phases,bound,chosen,work);assert same(enc(measured),enc(saved_measure))
  def existing_save(name,value):
   name=prefix+('full-candidates.typed.json.xz' if name=='full-candidates' else name+'.json');r=REFS[str(D/name)]
   if name.endswith('.xz'):assert same(enc(pfile(name)),enc(value))
   else:assert js(exact(r))==json.loads(json.dumps(value,ensure_ascii=False))
   return r
  op=sem.project_current(bcur,semantic,work)
  prepared=sem.prepare_dossier(semantic,op,t['before_state'],len(initial['状態履歴'])-1,bcur.指紋,t['before_public'],existing_save,rid)
  orc=prepared['record'];assert json.loads(json.dumps(orc,ensure_ascii=False))==record
  preservation=prepared['dossier']['候補検査'][record['selected_candidate_id']]['保存条件']
  consistent=measured['実測目的効果'] is True and (preservation['保存値'] is None or measured['全相既充足保存'] is True) and not measured['UNKNOWN']
  language={'対象':chosen['対象'],'役割':semantic['学習役割'],'関係':semantic['全目標pool'],'前提':chosen['前提'],'選択理由':['支持済集合の固定候補生成順。学習policyではない'],'予測':chosen['照会全件'],'保存条件':preservation,'適用範囲':op['保存適用署名'][record['selected_candidate_id']],'由来参照':[t['comparison']['file'],orc['final_adoption_ref']],'予測実測比較':{'状態':'一致' if consistent else '未確認' if measured['実測目的効果'] is None else '不一致','全実測':measured,'根拠参照':[t['comparison']['file']]}}
  runtime_step=copy.deepcopy(t['step']);runtime_step['analysis']=analysis
  mem=final.日本語記憶へ(runtime_step,orc,t['before_public'],REFS[str(D/'transport'/(rid+'.intent.json'))],language)
  savedmem=packet(t['memory']);assert same(enc(mem),enc(savedmem))
  assert mem['HOLD']==[] and mem['成功認定'] is False and mem['追加学習'] is False
  progress=(type(analysis['levels_delta'])is int and analysis['levels_delta']>0) or analysis['state_after']=='WIN'
  terminal=chosen['作業']=='完成列提出' and chosen['対象'] is None and op['現在列の目標一致'] is True and preservation['由来']==sem.TERMINAL and preservation['保存値'] is None and bound['同一公開実行'] is True and bound['RESET非該当明示'] is True and progress
  if si<8:assert t['status']=='CONTINUE' and not progress and not measured['UNKNOWN'] and measured['実測目的効果'] is True and mem['継続可能'] is True
  else:assert terminal and t['status']=='LEVEL_SUCCESS' and measured['UNKNOWN'] is True and analysis['levels_delta']==1
  diagnostic=js(exact(t['sdk_diagnostics']))
  assert not(diagnostic['sdk_events'] or diagnostic['denials'] or diagnostic['exceptions'] or any(x.get('write_error') for x in diagnostic['sdk_io']))
  for r in diagnostic['opaque_streams']:assert Path(r['path']).stat().st_size==r['bytes']
  reports.append({'index':si,'request_id':rid,'status':t['status'],'Query':len(links),'all_candidates':len(semantic['全作用候補']['全候補']),'selected_operation':chosen['作業'],'action':record['action'],'before_public':t['before_public'],'after_public':t['step']['public_response'],'before_state':t['before_state'],'after_query_state':t['state'],'response_phases':len(phases),'goal_effect':measured['実測目的効果'],'preservation':measured['全相既充足保存'],'preservation_origin':preservation['由来'],'old_scope_UNKNOWN':measured['UNKNOWN'],'HOLD':mem['HOLD'],'public_progress':analysis['levels_delta'],'memory':t['memory'],'measured':t['comparison'],'final_adoption':orc['final_adoption_ref'],'selected_queries':enc(chosen['照会全件'])})
 assert ordinal==126 and totalphases==150 and len(c['states'])==11
 assert c['states'][-1]['sha256']==c['states'][-2]['sha256']
 standard(c['states'][-1])
 assert c['current_public']==c['trajectory'][-1]['before_public'] and c['current_public']!=c['trajectory'][-1]['step']['public_response']
 assert c['step']==c['trajectory'][-1]['step'] and c['result']==c['trajectory'][-1]
 for p,i in IDENT.items():assert ident(Path(p))==i
 for r in contract['source_pins']+contract['core_and_family_pins']:exact(r,8*M)
 CHECKS.update(all126_native_raw_external_support_and_perstep_origin=True,all9_current_reprojections_complete_candidates_adoptions_and_dispatch=True,all150_public_response_phases_effects_and_memory=True,all11_normal_states_only_query_counters_378_to504=True,prior_pilot_closure_and_actual_loop_exit=True,terminal_submission_scope_and_unknown_preserved=True)
 result={'schema':'column-live-loop-independent-audit-v1','status':'PASS','errors':[],'nonce':N,'completion':cref,'actual_tools':toolref,'verified':CHECKS,'counts':{'Action':9,'Query':126,'Teach':0,'response_phases':150,'final_response_phases':118,'public_levels_before':0,'public_levels_after':1,'auditor_native_calls':0},'steps':reports,'states':c['states'],'current_public_semantics':{'meaning':'last step before-current; not final public observation','reported_current_public':c['current_public'],'actual_final_public':c['step']['public_response'],'source_reason':'public_ref update occurs only after CONTINUE, terminal finish precedes update','data_missing':False},'perception_exception_checks':trace_checks,'references':list(REFS.values()),'limitations':['Same run public level0 to1 is one observed level success, not all8 levels/game completion or unseen transfer.','No SDK/HDS/Action by auditor; fixed perception/replay/verifier reused.','All original traces retained; independent perception compares exception type and args while retaining producer traceback text, whose caller location differs.','Opaque SDK streams sizes checked only, bodies and game source not opened.','Original failed owner2505 and prior auditor failures remain separately preserved.'],'elapsed_seconds':time.monotonic()-START}
 r=out('summary_v1.json',result);signal.alarm(0);print(json.dumps({'status':'PASS','report':r,'counts':result['counts']}))
try:main()
except BaseException:
 signal.alarm(0);r=out('failure_v1.json',{'status':'FAIL','cursor':CURSOR,'checks':CHECKS,'traceback':traceback.format_exc()});print(json.dumps({'status':'FAIL','failure':r}));raise
