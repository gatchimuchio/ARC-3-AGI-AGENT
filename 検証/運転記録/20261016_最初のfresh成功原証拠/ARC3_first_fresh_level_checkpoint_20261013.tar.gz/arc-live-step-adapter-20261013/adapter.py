"""One-step transport only. No solver, policy, environment factory, or live CLI.

The caller supplies an independently reviewed final-adoption verifier. A test
verifier is not a live authorization mechanism. All actual execution stays gated.
"""
import ast
import base64
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
import fcntl
import uuid
from contextlib import contextmanager

BASE = Path('/workspace/scratch/a94ff513b3af')
BOUNDARY = BASE/'arc-recovery-main-20261013/repository/接続/ARC3境界.py'
CAPTURE = BASE/'arc-official-fresh-all25-20261013/prep/fresh_all25_v1.py'
PINS = {BOUNDARY:'ed95bb80f2326827c3f1237537a3df33203af8cac7881e46fd8b4d17e439d358',
        CAPTURE:'52904ce9357a933c2f53daf0cd23b5672dfdb30aef50844f89daa8b56a824516'}
def raw_json(value):
    return (json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
def digest(data):return hashlib.sha256(data).hexdigest()
def read_pin(path):
    data=path.read_bytes()
    if digest(data)!=PINS[path]:raise ValueError('reused source changed')
    return data
def load_boundary():
    name='_arc_live_reused_boundary'
    if name not in sys.modules:
        spec=importlib.util.spec_from_file_location(name,BOUNDARY)
        module=importlib.util.module_from_spec(spec)
        sys.modules[name]=module
        exec(compile(read_pin(BOUNDARY),str(BOUNDARY),'exec'),module.__dict__)
    return sys.modules[name]
def capture_public(obs,np,nonce):
    # Compile only the exact pinned pure capture functions; do not import the
    # initial-reset harness, its main, resource changes, SDK, or environment.
    tree=ast.parse(read_pin(CAPTURE),filename=str(CAPTURE))
    names={'sha','json_bytes','typed','preserve_observation','verify_packet'}
    nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
    if {n.name for n in nodes}!=names:raise ValueError('capture function coverage')
    ns={'hashlib':hashlib,'json':json,'base64':base64,'NONCE':nonce,
        'OWNER':{'packet':None,'frames':[]}}
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(CAPTURE),'exec'),ns)
    packet=ns['preserve_observation'](obs,np)
    data=ns['json_bytes'](packet)
    ns['verify_packet'](data,obs,np)
    return data

class Refusal(Exception):pass
class OutcomeUnknown(Exception):
    def __init__(self,record,response=None):
        super().__init__('step outcome or durable evidence unknown; never retry')
        self.record=record;self.response=response

class Journal:
    def __init__(self,root,cap=16<<20,budget_root=None):
        self.root=Path(root);self.root.mkdir(parents=True,exist_ok=True)
        self.cap=cap;self.budget_root=Path(budget_root or self.root)
        if not self.root.resolve().is_relative_to(self.budget_root.resolve()):raise Refusal('journal outside budget')
    def usage(self):return sum(p.stat().st_size for p in self.budget_root.rglob('*') if p.is_file())
    @contextmanager
    def lock(self):
        with (self.root/'owner.lock').open('a+b') as f:
            fcntl.flock(f,fcntl.LOCK_EX)
            try:yield
            finally:fcntl.flock(f,fcntl.LOCK_UN)
    def save(self,name,value,raw=False):
        if Path(name).name!=name:raise Refusal('unsafe journal path')
        data=value if raw else raw_json(value)
        if self.usage()+len(data)>self.cap:raise OSError('journal capacity')
        p=self.root/name
        with p.open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
        d=os.open(self.root,os.O_RDONLY)
        try:os.fsync(d)
        finally:os.close(d)
        if p.read_bytes()!=data:raise OSError('readback mismatch')
        return {'path':str(p),'bytes':len(data),'sha256':digest(data)}

def load_evidence(ref,roots):
    if set(ref)!={'path','bytes','sha256'}:raise Refusal('reference shape')
    p=Path(ref['path']).resolve()
    if not any(p.is_relative_to(Path(r).resolve()) for r in roots):raise Refusal('reference outside allowlist')
    if type(ref['bytes'])is not int or not 0<=ref['bytes']<=1<<20:raise Refusal('reference size')
    with p.open('rb') as f:data=f.read((1<<20)+1)
    if len(data)!=ref['bytes'] or digest(data)!=ref['sha256']:raise Refusal('reference mismatch')
    return json.loads(data)

def phases(before,after,action):
    def delta(a,b):
        if len(a)!=len(b) or any(len(x)!=len(y) for x,y in zip(a,b)):return {'status':'incomparable','cells':None}
        return {'status':'observed','cells':[[x,y,u,v] for y,(r,s) in enumerate(zip(a,b)) for x,(u,v) in enumerate(zip(r,s)) if u!=v]}
    holds=[]
    if not before.実行識別子 or before.実行識別子!=after.実行識別子 or before.ゲーム識別子!=after.ゲーム識別子:holds.append('execution boundary mismatch')
    if after.観測通番<=before.観測通番:holds.append('observation order')
    if action==0 or after.全初期化 or after.完了レベル数<before.完了レベル数:holds.append('reset boundary')
    if not after.盤面列:holds.append('empty response frames')
    return {'selected_actions':1,'response_phases':len(after.盤面列),
            'first_response_delta':None if holds else delta(before.最新盤面,after.盤面列[0]),
            'phase_deltas':[] if holds else [{'from':i,'to':i+1,**delta(a,b)} for i,(a,b) in enumerate(zip(after.盤面列,after.盤面列[1:]))],
            'state_before':before.状態,'state_after':after.状態,
            'available_before':before.作用可能番号,'available_after':after.作用可能番号,
            'completed_before':before.完了レベル数,'completed_after':after.完了レベル数,
            'levels_delta':after.完了レベル数-before.完了レベル数,
            'win_levels_before':before.全レベル数,'win_levels_after':after.全レベル数,
            'failure_observed':after.状態=='GAME_OVER','completion_phase':'unidentified',
            'hidden_delta':'unobserved','reward':'unobserved','causal_claim':False,'HOLD':holds}

class OneStepTransport:
    def __init__(self,journal,*,verifier,evidence_roots,np,resource_check):
        if not callable(verifier):raise Refusal('independent final-adoption verifier required')
        self.journal=journal;self.verifier=verifier;self.roots=evidence_roots
        self.np=np;self.resource_check=resource_check;self.boundary=load_boundary()
    def _verify(self,record,current,version):
        required={'schema','request_id','observation_fingerprint','hds_state_version','candidate_set_ref','support_refs','rejection_refs','final_adoption_ref','selected_candidate_id','action'}
        if set(record)!=required or record['schema']!='verified-final-adoption-v1':raise Refusal('adoption schema')
        if type(version) not in (str,int) or type(record['hds_state_version']) is not type(version):raise Refusal('state version type')
        if not re.fullmatch('[a-f0-9]{32}',record['request_id']):raise Refusal('request identity')
        if record['observation_fingerprint']!=current.指紋 or record['hds_state_version']!=version:raise Refusal('stale observation or HDS version')
        if current.状態!='NOT_FINISHED':raise Refusal('not an active ordinary-action state')
        if not record['support_refs']:raise Refusal('no support evidence')
        evidence={'candidates':load_evidence(record['candidate_set_ref'],self.roots),
                  'supports':[load_evidence(r,self.roots) for r in record['support_refs']],
                  'rejections':{k:load_evidence(v,self.roots) for k,v in record['rejection_refs'].items()},
                  'adoption':load_evidence(record['final_adoption_ref'],self.roots)}
        candidates=evidence['candidates']
        if not isinstance(candidates,list) or not candidates:raise Refusal('candidate coverage')
        ids=[x['candidate_id'] for x in candidates]
        if len(ids)!=len(set(ids)):raise Refusal('duplicate candidate')
        chosen=record['selected_candidate_id']
        if chosen not in ids or set(record['rejection_refs'])!=set(ids)-{chosen}:raise Refusal('missing unexecuted/rejection evidence')
        selected=next(x for x in candidates if x['candidate_id']==chosen)
        if any(x.get('execution_permission')is not False for x in candidates):raise Refusal('candidate permission bypass')
        if selected['action']!=record['action']:raise Refusal('action/candidate mismatch')
        a=record['action']
        if set(a)!={'number','arguments'} or type(a['number'])is not int or a['number'] not in current.作用可能番号 or a['number']==0:raise Refusal('illegal ordinary action')
        if a['number']==6:
            if set(a['arguments'])!={'x','y'} or any(type(v)is not int or not 0<=v<=63 for v in a['arguments'].values()):raise Refusal('click arguments')
        elif a['arguments']!={}:raise Refusal('simple arguments')
        attestation=self.verifier(record,evidence,current,version)
        expected={'verified':True,'record_sha256':digest(raw_json(record)),
                  'observation_fingerprint':current.指紋,'hds_state_version':version}
        if attestation!=expected:raise Refusal('independent verification rejected or unbound')
        return evidence,attestation
    def run(self,env,game_action,record,*,observe_current,hds_version):
        try:
            return self._run(env,game_action,record,observe_current=observe_current,hds_version=hds_version)
        except OutcomeUnknown:
            raise
        except BaseException as exc:
            record={'status':'refused-before-step','exception_type':type(exc).__name__,
                    'step_may_have_executed':False,'automatic_retry':False}
            try:self.journal.save('refusal-'+uuid.uuid4().hex+'.json',record)
            except BaseException:record['failure_record_persisted']=False
            if isinstance(exc,Refusal):raise
            raise OutcomeUnknown(record) from None
    def _run(self,env,game_action,record,*,observe_current,hds_version):
        # One shared journal per environment execution. The caller owns that
        # environment exclusively; bypass calls cannot be made safe here.
        record=json.loads(raw_json(record))
        with self.journal.lock():
            self.resource_check()
            obs,sequence=observe_current();current=self.boundary.観測する(obs,観測通番=sequence)
            evidence,attestation=self._verify(record,current,hds_version())
            rid=record['request_id'];claim='consumed-'+current.指紋+'.json'
            if (self.journal.root/claim).exists() or (self.journal.root/(rid+'.intent.json')).exists():raise Refusal('repeated observation/request')
            before=self.journal.save(rid+'.before.json',capture_public(obs,self.np,rid),raw=True)
            # An exclusive durable claim survives interruption; never remove it.
            self.journal.save(claim,{'request_id':rid,'observation':current.指紋})
            intent={'status':'intent','adoption':record,'all_evidence':evidence,'attestation':attestation,'before':before,'actor':'agent','HDS_learning':False}
            self.journal.save(rid+'.intent.json',intent)
            sent=False;response=None;phase='recheck'
            try:
                self.resource_check()
                latest,seq=observe_current()
                latest=self.boundary.観測する(latest,観測通番=seq)
                if latest.指紋!=current.指紋 or hds_version()!=record['hds_state_version']:raise Refusal('stale at dispatch')
                evidence2,attestation2=self._verify(record,latest,hds_version())
                if evidence2!=evidence or attestation2!=attestation:raise Refusal('evidence changed at dispatch')
                self.journal.save(rid+'.dispatch.json',{'status':'dispatch-intent','action':record['action'],'automatic_retry':False})
                a=record['action'];decision=self.boundary.HDS確定作用(current.指紋,a['number'],record['final_adoption_ref']['sha256'],判定='確定',引数=a['arguments'])
                phase='step';sent=True
                response=self.boundary.作用を排出する(current,decision,game_action,env)
                if response is None:raise OutcomeUnknown({'reason':'None response'})
                phase='persist-response'
                payload=capture_public(response,self.np,rid)
                saved=self.journal.save(rid+'.response.json',payload,raw=True)
                # No response analysis occurs before complete durable capture.
                phase='analyse'
                after=self.boundary.観測する(response,観測通番=sequence+1)
                analysis=phases(current,after,a['number'])
                echoed=response.action_input
                echo_id=echoed.get('id') if isinstance(echoed,dict) else getattr(echoed,'id',None)
                echo_data=echoed.get('data') if isinstance(echoed,dict) else getattr(echoed,'data',None)
                echo_id=getattr(echo_id,'value',echo_id)
                if isinstance(echo_id,str) and echo_id.startswith('ACTION') and echo_id[6:].isdigit():echo_id=int(echo_id[6:])
                if echo_id!=a['number'] or (echo_data or {})!=a['arguments']:analysis['HOLD'].append('public action echo mismatch')
                result={'status':'recorded','action':a,'public_response':saved,'observation_fingerprint':after.指紋,
                        'analysis':analysis,'runtime_memory_kind':'raw experience','additional_learning':False,
                        'unexecuted_candidate_ids':list(record['rejection_refs']),'all_candidate_evidence':record['candidate_set_ref']}
                self.journal.save(rid+'.result.json',result)
                return result
            except BaseException as exc:
                failure={'status':'unknown' if sent else 'refused-before-step','phase':phase,'exception_type':type(exc).__name__,
                         'step_may_have_executed':sent,'automatic_retry':False,'request_id':rid,'failure_record_persisted':False}
                try:
                    failure['failure_record_persisted']=True
                    self.journal.save(rid+'.failure.json',failure)
                except BaseException:failure['failure_record_persisted']=False
                raise OutcomeUnknown(failure,response) from None
