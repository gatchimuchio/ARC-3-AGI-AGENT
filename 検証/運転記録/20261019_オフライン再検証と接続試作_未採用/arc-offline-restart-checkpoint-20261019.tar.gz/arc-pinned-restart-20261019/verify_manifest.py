"""Read-only local closure verification; no native imports."""
import hashlib
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'dependency_manifest.json').read_text())
checked=[]
for group in ('delivery','inputs'):
    for item in manifest[group]:
        p=ROOT/item['path'] if group=='delivery' else Path(item['path'])
        raw=p.read_bytes()
        if len(raw)!=item['bytes'] or hashlib.sha256(raw).hexdigest()!=item['sha256']:
            raise SystemExit('FAIL '+str(p))
        checked.append(str(p))
size=sum(p.stat().st_size for p in ROOT.rglob('*') if p.is_file())
if size>96*1048576:raise SystemExit('FAIL 96MiB')
print(json.dumps({'status':'PASS','verified_files':len(checked),'directory_bytes':size,'native_executed':False}))
