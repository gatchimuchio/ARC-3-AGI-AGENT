"""Pure mocks only; never import HDS/SDK or execute native methods."""
from copy import deepcopy
from dataclasses import dataclass, field
import hashlib
import importlib
import json
import os
from pathlib import Path
import sys
import tempfile
import threading
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT/'source'), str(ROOT/'dependencies')]
m = importlib.import_module('目標相対再始動_v1')

@dataclass
class Input:
    内容: object
    対象系境界: str
    主体: object = None
    対象: object = None
    目的: object = None
    文脈: dict = field(default_factory=dict)

@dataclass
class Output:
    状態: str
    内容: dict
    追跡情報: dict

class Actions:
    RESET = 0
    ACTION1 = 1
    ACTION2 = 2
    ACTION3 = 3
    ACTION4 = 4
    ACTION5 = 5
    ACTION6 = 6
    ACTION7 = 7


def reply(number=1):
    return Output('出力', {'予測群': [{'結果経路': ('必要行動ID',), '予測値': number, '原理参照': 'fixture原理', '条件値群': ('完成列提出',)}],
        '競合群': [], '係争中原理群': [], '追加観測要求群': [], '識別不能群': [], '断定保留理由群': [],
        '学習成立状態': '適用外', '現在状態版': 0, '有効原理群': []}, {'fixture': True})


def observation(**kw):
    out = dict(game_id='provenance-only', state='NOT_FINISHED', levels_completed=0, win_levels=1,
               available_actions=[1, 2], frame=[[[0, 1], [0, 0]]], full_reset=False, guid='fixture')
    out.update(kw)
    return out

class Machine:
    def __init__(self, output=None, error=None):
        self.calls = []
        self.output = reply() if output is None else output
        self.error = error
        self.hook = None
    def 照会する(self, inp):
        self.calls.append(deepcopy(inp))
        if self.hook:
            self.hook(inp)
        if self.error:
            raise self.error
        return self.output

class Environment:
    def __init__(self, after=None, error=None):
        self.calls = []
        self.after = observation() if after is None else after
        self.error = error
    def step(self, action, *, data, reasoning):
        self.calls.append(deepcopy((action, data, reasoning)))
        if self.error:
            raise self.error
        return deepcopy(self.after)

class Sink:
    def __init__(self, fail_at=None, corrupt=False):
        self.calls = []
        self.fail_at = fail_at
        self.corrupt = corrupt
        self.errors = []
        self.pending = None
    def 保存する(self, name, value):
        self.calls.append(deepcopy(value))
        self.pending = value
        if len(self.calls) == self.fail_at:
            error = OSError('injected save failure')
            self.errors.append(error)
            raise error
        raw = m.バイト列(value)
        self.pending = None
        return {'path': name, 'bytes': len(raw), 'sha256': 'bad' if self.corrupt else hashlib.sha256(raw).hexdigest()}

FAILURES = []

class Contracts(unittest.TestCase):
    def make(self, *, output=None, after=None, error=None, sink=None):
        self.machine = Machine(output, error)
        self.env = Environment(after)
        self.sink = sink or Sink()
        self.conn = m.直列接続(系=self.machine, 入力型=Input, 作用型=Actions, 環境=self.env, 保存=self.sink, 試験専用=True)
        return self.conn
    def run_step(self, obs=None, **kw):
        return self.conn.一手(observation() if obs is None else obs, 解答作業=kw.get('operation', '完成列提出'), 来歴=kw.get('origin', {'game_id': 'teacher-provenance', 'teacher': 'fixture only'}))
    def held(self, obs=None, **kw):
        with self.assertRaises(BaseException):
            self.run_step(obs, **kw)
        self.assertTrue(self.conn.保留中)
        counts = (len(self.machine.calls), len(self.env.calls), len(self.sink.calls))
        with self.assertRaises(m.保留):
            self.run_step()
        self.assertEqual(counts, (len(self.machine.calls), len(self.env.calls), len(self.sink.calls)))
        FAILURES.append({'test': self.id(), 'calls': counts, 'records': deepcopy(self.conn.記録),
                         'receipts': deepcopy(self.conn.受領群), 'errors': [str(e) for e in self.conn.失敗群]})
    def test_success_binding(self):
        self.make()
        out = self.run_step()
        self.assertIs(self.conn.返値原本, self.machine.output)
        self.assertEqual(len(self.env.calls), 1)
        self.assertEqual(out['結線']['作用']['作用番号'], self.machine.output.内容['予測群'][0]['予測値'])
        self.assertEqual(self.env.calls[0][2]['HDS根拠参照'], out['結線']['返値証拠']['sha256'])
        self.assertEqual(len(out['全候補判定']), 2)
        self.assertEqual(len(self.sink.calls), 5)
    def test_success_is_one_shot(self):
        self.make(); self.run_step()
        counts = (len(self.machine.calls), len(self.env.calls), len(self.sink.calls))
        with self.assertRaises(m.保留): self.run_step()
        self.assertEqual(counts, (len(self.machine.calls), len(self.env.calls), len(self.sink.calls)))
    def test_input_exact_existing_contract(self):
        self.make(); self.run_step()
        self.assertEqual(self.machine.calls[0], Input({'解答作業': '完成列提出'}, '公開列図式:観測された解答作業と行動ID'))
    def test_identity_permutation_is_only_routing_test(self):
        inputs=[]
        for gid in ('a', 'b'):
            self.make(after=observation(game_id=gid, guid=gid)); self.run_step(observation(game_id=gid, guid=gid), origin={'game_id': gid, 'filename': gid})
            inputs.append(self.machine.calls[0])
        self.assertEqual(*inputs)
    def test_features_no_ids(self):
        features=m.公開特徴(m.観測する(observation(), 観測通番=1))
        self.assertNotIn('ゲーム識別子', features)
        self.assertNotIn('観測指紋', features)
        self.assertEqual(features['盤面フレーム列'], observation()['frame'])
        self.assertTrue(features['対象群'])
    def test_all_coordinate_candidates_preserved(self):
        self.make(output=reply(6)); self.held(observation(available_actions=[6,1]))
        self.assertEqual(len(self.conn.記録[-1]['全候補']),4097)
        self.assertEqual(len(self.conn.記録[-1]['全候補判定']),4097)
        self.assertEqual(self.env.calls, [])
    def test_absent_action(self): self.make(output=reply(3)); self.held()
    def test_no_candidates(self): self.make(); self.held(observation(available_actions=[])); self.assertEqual(self.machine.calls, [])
    def test_win_no_query(self): self.make(); self.held(observation(state='WIN')); self.assertEqual(self.machine.calls, [])
    def test_unknown_operation(self): self.make(); self.held(operation='arbitrary game id'); self.assertEqual(self.machine.calls, [])
    def test_malformed_observation(self): self.make(); self.held(observation(frame=[])); self.assertEqual(self.machine.calls, [])
    def test_hds_hold(self):
        r=reply(); r.状態='断定保留'; self.make(output=r); self.held()
    def test_hds_conflict(self):
        r=reply(); r.内容['予測群'].append(dict(r.内容['予測群'][0], 予測値=2)); self.make(output=r); self.held()
    def test_hds_missing_support(self):
        r=reply(); r.内容['予測群'][0]['原理参照']=''; self.make(output=r); self.held()
    def test_hds_bool_not_integer(self): self.make(output=reply(True)); self.held()
    def test_hds_missing_required_field(self):
        r=reply(); del r.内容['競合群']; self.make(output=r); self.held()
    def test_hds_blockers(self):
        for field in ('競合群','係争中原理群','追加観測要求群','識別不能群','断定保留理由群'):
            with self.subTest(field=field):
                r=reply(); r.内容[field]=['blocked']; self.make(output=r); self.held(); self.assertEqual(self.env.calls, [])
    def test_query_exception(self):
        err=RuntimeError('query failure'); self.make(error=err); self.held(); self.assertIs(self.conn.失敗群[0],err)
    def test_mutated_input(self):
        self.make(); self.machine.hook=lambda inp: inp.内容.update(解答作業='wrong'); self.held()
    def test_save_fail_each_boundary(self):
        for ordinal in range(1,6):
            with self.subTest(ordinal=ordinal):
                self.make(sink=Sink(fail_at=ordinal)); self.held()
                self.assertEqual(len(self.sink.calls), ordinal)
                self.assertEqual(len(self.env.calls), 0 if ordinal <=3 else 1)
                self.assertIsNotNone(self.sink.pending)
    def test_bad_receipt(self): self.make(sink=Sink(corrupt=True)); self.held(); self.assertEqual(self.machine.calls, [])
    def test_action_exception(self):
        self.make(); err=TimeoutError('action uncertain'); self.env.error=err; self.held(); self.assertIs(self.conn.失敗群[0],err)
    def test_malformed_after_preserved(self):
        self.make(after={'state':'bad'}); self.held(); self.assertEqual(self.conn.記録[-1]['後応答原票'], {'state':'bad'})
    def test_status_only_change(self):
        self.make(after=observation(state='GAME_OVER',available_actions=[])); out=self.run_step()
        self.assertEqual(out['差分']['最新盤面変化セル'],[])
        self.assertEqual(out['差分']['状態遷移'], ['NOT_FINISHED','GAME_OVER'])
        self.assertEqual(out['差分']['作用可能番号遷移'],[[1,2],[]])
        self.assertTrue(out['公開結果']['失敗'])
        self.assertIn('不明',out['差分']['隠れ差分'])
    def test_all_frames_reward_level(self):
        frames=[[[0]],[[1]]]
        self.make(after=observation(frame=frames, levels_completed=1, state='WIN',reward=2)); out=self.run_step()
        self.assertEqual(out['差分']['盤面フレーム列'],frames)
        self.assertEqual(out['差分']['完了レベル増分'],1)
        self.assertEqual(out['公開結果']['reward'],2)
    def test_observation_sequence(self):
        self.make(); out=self.run_step(); self.assertEqual(out['後観測']['観測通番'],out['前観測']['観測通番']+1)
        self.assertNotEqual(out['後観測']['指紋'],out['前観測']['指紋'])
    def test_reentrant_latches_without_followon(self):
        self.make()
        def hook(inp):
            try:self.run_step()
            except m.保留:pass
        self.machine.hook=hook; self.held()
        self.assertEqual(len(self.sink.calls),1)
        self.assertEqual(self.env.calls,[])
    def test_reentry_during_persistence_no_query(self):
        class ReenterSink(Sink):
            def 保存する(sink, name, value):
                receipt=super().保存する(name,value)
                if len(sink.calls)==1:
                    try:self.run_step()
                    except m.保留:pass
                return receipt
        self.make(sink=ReenterSink()); self.held()
        self.assertEqual(self.machine.calls,[])
        self.assertEqual(self.env.calls,[])
        self.assertEqual(len(self.conn.受領群),1)
    def test_output_mutation_cannot_promote_hold(self):
        class MutateSink(Sink):
            def 保存する(sink,name,value):
                receipt=super().保存する(name,value)
                if len(sink.calls)==2:self.machine.output.状態='出力'
                return receipt
        output=reply();output.状態='断定保留'
        self.make(output=output,sink=MutateSink());self.held()
        self.assertEqual(self.sink.calls[1]['照会返値']['状態'],'断定保留')
        self.assertEqual(self.env.calls,[])
    def test_failed_provenance_copy_releases_lock_and_holds(self):
        class BadCopy:
            def __deepcopy__(obj,memo):raise ValueError('provenance deepcopy failure')
        self.make();self.held(origin=BadCopy())
        self.assertFalse(self.conn.lock.locked())
        self.assertEqual(len(self.conn.失敗群),1)
        self.assertEqual(self.sink.calls,[])
    def test_input_boundary_mutation(self):
        self.make()
        self.machine.hook=lambda inp:setattr(inp,'対象系境界','other')
        self.held();self.assertEqual(self.env.calls,[])
    def test_input_factory_reentry_prevents_query(self):
        self.make()
        def factory(*args):
            try:self.run_step()
            except m.保留:pass
            return Input(*args)
        self.conn.入力型=factory
        self.held();self.assertEqual(self.machine.calls,[])
    def test_bad_input_factory(self):
        self.make();self.conn.入力型=lambda *a:Input({'wrong':1},'wrong')
        self.held();self.assertEqual(self.machine.calls,[])
    def test_action_reentry_retains_return_and_blocks_saves(self):
        self.make()
        class ReenterEnvironment:
            def step(env,*a,**kw):
                self.env.calls.append((a,kw))
                try:self.run_step()
                except m.保留:pass
                return observation(reward=5)
        self.conn.環境=ReenterEnvironment()
        self.held()
        self.assertEqual(self.conn.作用返値原本['reward'],5)
        self.assertEqual(self.conn.記録[-1]['後応答原票']['reward'],5)
        self.assertEqual(len(self.sink.calls),3)
    def test_before_public_extras_retained(self):
        self.make();out=self.run_step(observation(reward=3))
        self.assertEqual(out['前応答原票']['reward'],3)
    def test_wrong_thread(self):
        self.make(); errors=[]
        def run():
            try:self.run_step()
            except BaseException as e:errors.append(e)
        t=threading.Thread(target=run);t.start();t.join()
        self.assertTrue(errors); self.assertEqual(self.machine.calls,[]); self.assertTrue(self.conn.保留中)
    def test_duplicate_owner_rejected(self):
        self.make()
        with self.assertRaises(m.保留):m.直列接続(系=self.machine,入力型=Input,作用型=Actions,環境=self.env,保存=self.sink,試験専用=True)
    def test_native_disabled(self):
        with self.assertRaises(m.保留):m.native起動()
        with self.assertRaises(m.保留):m.直列接続(系=Machine(),入力型=Input,作用型=Actions,環境=Environment(),保存=Sink())
    def test_import_closure(self):
        self.assertFalse(any(x.startswith(('hds学習系統','arc_agi','arcengine')) for x in sys.modules))

class Persistence(unittest.TestCase):
    def test_verified_receipt(self):
        with tempfile.TemporaryDirectory() as d:
            s=m.証拠保存(d);r=s.保存する('one.json',{'full':[1,2]})
            self.assertEqual(Path(r['path']).read_bytes(),m.バイト列({'full':[1,2]}))
            self.assertEqual(r['事後資源']['総量bytes'],r['bytes'])
            self.assertIsNone(s.pending)
    def test_exclusive_retains_existing(self):
        with tempfile.TemporaryDirectory() as d:
            s=m.証拠保存(d);s.保存する('one.json',1)
            with self.assertRaises(FileExistsError):s.保存する('one.json',2)
            self.assertEqual((Path(d)/'one.json').read_text(),'1')
            self.assertEqual(s.pending['値'],2)
            with self.assertRaises(m.保留):s.保存する('two.json',3)
    def test_disk_cap(self):
        with tempfile.TemporaryDirectory() as d:
            s=m.証拠保存(d,上限=10,障害予約=2)
            with self.assertRaises(MemoryError):s.保存する('one.json','0123456789')
            self.assertEqual(list(Path(d).iterdir()),[])
    def test_symlink(self):
        with tempfile.TemporaryDirectory() as d:
            (Path(d)/'bad').symlink_to('/tmp')
            with self.assertRaises(ValueError):m.証拠保存(d).保存する('one.json',1)
    def test_bad_name(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(ValueError):m.証拠保存(d).保存する('../bad',1)
    def test_real_writer_connection(self):
        with tempfile.TemporaryDirectory() as d:
            c=m.直列接続(系=Machine(),入力型=Input,作用型=Actions,環境=Environment(),保存=m.証拠保存(d),試験専用=True)
            c.一手(observation(),解答作業='完成列提出',来歴={'fixture':True})
            self.assertEqual(len(list(Path(d).iterdir())),5)

if __name__ == '__main__':
    if len(sys.argv)!=2:raise SystemExit('Usage: test_connection.py NEW_RESULT_DIRECTORY')
    dest=Path(sys.argv.pop());dest.mkdir(parents=True,exist_ok=False)
    with (dest/'tests.log').open('x') as log:
        result=unittest.TextTestRunner(stream=log,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__]))
    report={'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'status':'PASS' if result.wasSuccessful() else 'FAIL',
            'scope':'pure mock contracts only; no learning/transfer/native claim', 'failure_cases_retained':len(FAILURES)}
    (dest/'summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    (dest/'failure_evidence.json').write_text(json.dumps(FAILURES,ensure_ascii=False,indent=2))
    print(json.dumps(report));raise SystemExit(not result.wasSuccessful())
