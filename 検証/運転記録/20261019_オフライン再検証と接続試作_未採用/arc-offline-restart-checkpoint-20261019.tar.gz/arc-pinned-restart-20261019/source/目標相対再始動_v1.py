"""未採用・純粋注入試験専用。HDS/SDK/旧wrapperをimportしない。

この接続は学習器・目標知覚器ではない。既存の解答作業→必要行動ID
という外部契約の結線のみを検証する。native起動口は常に閉鎖する。
"""
from copy import deepcopy
from dataclasses import asdict
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import threading

from ARC3境界 import 観測する, HDS観測入力, HDS確定作用, 作用を排出する
from 図式観測 import 成分群

採用済み = False
作用境界 = '公開列図式:観測された解答作業と行動ID'
_所有組 = []  # Strong references: one owner per injected state/environment/writer.
_所有権lock = threading.Lock()

作業語彙 = ('完成列提出', '選択記号を空欄へ割当', '在庫記号を選択')


class 保留(RuntimeError):
    pass


def native起動(*args, **kwargs):
    raise 保留('未採用: native binding・codec・適用性・資源pilot未検証')


def バイト列(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode()


def 公開全候補(obs):
    """ACTION6は公式境界の全64x64。画面内座標だけに切り詰めない。"""
    numbers = list(obs.作用可能番号)
    if obs.状態 in ('NOT_PLAYED', 'GAME_OVER') and 0 not in numbers:
        numbers.append(0)
    if obs.状態 == 'WIN':
        return []
    result = []
    for number in numbers:
        if number == 6:
            result.extend({'作用番号': 6, '引数': {'x': x, 'y': y}}
                          for y in range(64) for x in range(64))
        else:
            result.append({'作用番号': number, '引数': {}})
    return result


def 公開特徴(obs):
    value = HDS観測入力(obs)
    # Fingerprint, ordinal and identity exist only in evidence, never solution inputs.
    for key in ('ゲーム識別子', '観測指紋', '観測通番'):
        del value[key]
    value['対象群'] = [
        {'役割': '可視連結成分', '位置': list(c['位置']),
         '色': obs.最新盤面[c['位置'][1]][c['位置'][0]],
         '点群': [list(p) for p in sorted(c['点群'])]}
        for c in 成分群(obs.最新盤面)] if obs.最新盤面 else []
    value['隠れ状態'] = '不明: 公開観測のみ'
    return value


def 全差分(before, after, number):
    value = HDS観測入力(after, before, number)
    value['作用可能番号遷移'] = [list(before.作用可能番号), list(after.作用可能番号)]
    value['全レベル数遷移'] = [before.全レベル数, after.全レベル数]
    value['実行識別子遷移'] = [before.実行識別子, after.実行識別子]
    value['隠れ差分'] = '不明: 可視変化なしでも無作用と断定しない'
    value['因果判定'] = '未確定: 時間的先行のみ'
    return value


class 証拠保存:
    """この新接続専用のexclusive writer。native状態保存ではない。

    rootは既存の信頼された単一所有ディレクトリ。外部の同時改変に対する
    sandboxではない。全配下bytesを前後計上し、未完了bytesは削除しない。
    """
    def __init__(self, root, *, 上限=96*1048576, 障害予約=262144):
        self.root = Path(root)
        self.上限 = 上限
        self.障害予約 = 障害予約
        self.pending = None
        self.receipts = []
        self.errors = []
        self.owner = threading.get_ident()
        self.lock = threading.Lock()
        if not self.root.is_dir() or self.root.is_symlink():
            raise ValueError('既存の非symlink所有rootが必要')

    def 資源確認(self, extra=0, failure=False):
        if type(extra) is not int or extra < 0:
            raise ValueError('追加bytes不正')
        entries = list(self.root.rglob('*'))
        if self.root.is_symlink() or any(p.is_symlink() for p in entries):
            raise ValueError('symlink禁止')
        used = sum(p.stat().st_size for p in entries if p.is_file())
        limit = self.上限 if failure else self.上限-self.障害予約
        if used+extra > limit:
            raise MemoryError('offline総量上限')
        free = shutil.disk_usage(self.root).free
        if free < extra+self.障害予約:
            raise MemoryError('物理空き容量不足')
        return {'総量bytes': used, '追加bytes': extra, '上限bytes': limit,
                '空きbytes': free, '最大RSS_KiB': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                'AS上限bytes': list(resource.getrlimit(resource.RLIMIT_AS))}

    def 保存する(self, name, value, *, 障害=False):
        if threading.get_ident() != self.owner or not self.lock.acquire(False):
            raise 保留('保存所有者または再入違反')
        try:
            if self.errors:
                raise 保留('保存失敗後の再実行禁止')
            if type(name) is not str or Path(name).name != name or name in ('.', '..', ''):
                raise ValueError('保存名不正')
            raw = バイト列(value)
            self.pending = {'名前': name, '値': value, 'bytes': raw}
            before = self.資源確認(len(raw), 障害)
            p = self.root/name
            fd = os.open(p, os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW, 0o600)
            try:
                with os.fdopen(fd, 'wb') as f:
                    if f.write(raw) != len(raw):
                        raise OSError('short write')
                    f.flush()
                    os.fsync(f.fileno())
            finally:
                pass
            d = os.open(self.root, os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
            try:
                os.fsync(d)
            finally:
                os.close(d)
            if p.read_bytes() != raw:
                raise OSError('全量readback不一致')
            after = self.資源確認(0, 障害)
            receipt = {'path': str(p), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
                       '事前資源': before, '事後資源': after}
            self.receipts.append(receipt)
            self.pending = None
            return deepcopy(receipt)
        except BaseException as error:
            self.errors.append(error)
            raise
        finally:
            self.lock.release()


class 直列接続:
    """Injected mock contracts only. No production launcher, native save or Teach.

    callbacks: input factory follows 外部入力; machine follows 照会する/外部出力;
    GameAction/environment follow the existing public boundary. Constructor is
    not a trust/security gate: native adapters are absent and prohibited here.
    """
    def __init__(self, *, 系, 入力型, 作用型, 環境, 保存, 試験専用=False):
        if 試験専用 is not True:
            raise 保留('純粋注入試験以外は未採用')
        with _所有権lock:
            if any(系 is m or 環境 is e or 保存 is s for m, e, s in _所有組):
                raise 保留('同一状態・環境・保存の二重所有')
            _所有組.append((系, 環境, 保存))
        self.系, self.入力型, self.作用型, self.環境, self.保存 = 系, 入力型, 作用型, 環境, 保存
        self.owner = threading.get_ident()
        self.lock = threading.Lock()
        self.保留中 = False
        self.通番 = 0
        self.記録 = []
        self.受領群 = []
        self.失敗群 = []
        self.二次失敗群 = []
        self.返値原本 = None
        self.作用返値原本 = None

    def _継続確認(self):
        if self.保留中:
            raise 保留('外側HOLD latch')

    def _保存(self, record):
        self._継続確認()
        raw = バイト列(record)
        receipt = self.保存.保存する(f'{len(self.受領群):04d}.json', deepcopy(record))
        if receipt.get('bytes') != len(raw) or receipt.get('sha256') != hashlib.sha256(raw).hexdigest():
            raise 保留('保存受領と原票不一致')
        self.受領群.append(deepcopy(receipt))
        self._継続確認()
        return receipt

    def 一手(self, 生観測, *, 解答作業, 来歴):
        # A terminal HOLD is sticky. No subsequent observe/query/save/action calls.
        if self.保留中:
            raise 保留('外側HOLD latch')
        if threading.get_ident() != self.owner or not self.lock.acquire(False):
            self.保留中 = True
            raise 保留('同一状態の直列所有違反')
        record = None
        try:
            record = {'段階': '観測前'}
            self.記録.append(record)
            record.update({'種別': '純粋注入試験', '採用済み': False, '来歴': deepcopy(来歴),
                           '教師': '未実行', '学習': '未測定', '因果判定': '未確定'})
            if 解答作業 not in 作業語彙:
                raise 保留('既存作業語彙外')
            record['作業適用性'] = 'fixture仮定のみ: native適用証明なし'
            record['前応答原票'] = deepcopy(生観測)
            before = 観測する(生観測, 観測通番=self.通番)
            self.通番 += 1
            record['前観測'] = asdict(before)
            record['公開特徴'] = 公開特徴(before)
            candidates = 公開全候補(before)
            record['全候補'] = candidates
            record['予測差分'] = '不明: 必要行動ID契約は環境deltaを予測しない'
            record['目標条件'] = '未確定: この結線は目標知覚を実装しない'
            record['関係'] = []
            record['段階'] = '照会前'
            self._保存(record)
            if not candidates:
                raise 保留('合法候補なし')
            # Exact existing family query schema. Provenance never enters it.
            self._継続確認()
            inp = self.入力型({'解答作業': 解答作業}, 作用境界)
            self._継続確認()
            expected = deepcopy(inp.内容)
            expected_boundary = inp.対象系境界
            if expected != {'解答作業': 解答作業} or expected_boundary != 作用境界:
                raise 保留('外部入力factory契約不一致')
            self._継続確認()
            result = self.系.照会する(inp)
            self.返値原本 = result
            self._継続確認()
            if inp.内容 != expected or inp.対象系境界 != expected_boundary:
                raise 保留('照会入力変異')
            record['照会入力'] = {'内容': expected, '対象系境界': 作用境界}
            frozen_result = deepcopy({'状態': result.状態, '内容': result.内容, '追跡情報': result.追跡情報})
            record['照会返値'] = deepcopy(frozen_result)
            record['段階'] = '照会後'
            receipt = self._保存(record)
            content = frozen_result['内容']
            blockers = ('競合群', '係争中原理群', '追加観測要求群', '識別不能群', '断定保留理由群')
            if frozen_result['状態'] != '出力' or any(k not in content or content[k] for k in blockers):
                raise 保留('HDS返値が保留または契約欠損')
            predictions = content.get('予測群')
            if not isinstance(predictions, (list, tuple)):
                raise 保留('予測群欠損')
            relevant = [p for p in predictions if tuple(p.get('結果経路', ())) == ('必要行動ID',)]
            if not relevant or any(type(p.get('予測値')) is not int or not 0 <= p['予測値'] <= 7
                                   or not isinstance(p.get('原理参照'), str) or not p['原理参照'].strip()
                                   for p in relevant):
                raise 保留('必要行動IDの型または支持欠損')
            values = {p['予測値'] for p in relevant}
            if len(values) != 1:
                raise 保留('必要行動ID競合')
            number = next(iter(values))
            # Classify every candidate, retaining negative and ambiguous entries.
            record['全候補判定'] = [dict(c, 判定='対応' if c['作用番号'] == number else '行動ID不一致')
                                     for c in candidates]
            matches = [c for c in candidates if c['作用番号'] == number]
            if len(matches) != 1:
                raise 保留('返値と全候補が一対一でない: 座標/合法性未確定')
            candidate = matches[0]
            # No caller-supplied 確定 flag accepted. Bind actual returned value,
            # exact persisted output and this monotonic observation fingerprint.
            decision = HDS確定作用(before.指紋, number, receipt['sha256'], '確定', candidate['引数'])
            record['結線'] = {'作用': asdict(decision), '予測': deepcopy(relevant),
                              '返値証拠': receipt, '注意': 'mock結果。native証明ではない'}
            record['段階'] = '作用前'
            self._保存(record)
            self._継続確認()
            raw_after = 作用を排出する(before, decision, self.作用型, self.環境)
            self.作用返値原本 = raw_after
            record['段階'] = '作用応答受領'
            # Retain malformed responses too; do not synthesize an after observation.
            record['後応答原票'] = deepcopy(raw_after)
            self._継続確認()
            self._保存(record)
            after = 観測する(raw_after, 観測通番=self.通番)
            self.通番 += 1
            record['後観測'] = asdict(after)
            record['差分'] = 全差分(before, after, number)
            record['公開結果'] = {'成功': after.状態 == 'WIN', '失敗': after.状態 == 'GAME_OVER',
                                 'reward': raw_after.get('reward', '公開応答に未提供') if isinstance(raw_after, dict) else '公開応答契約未確定'}
            record['段階'] = '観測完了'
            self._保存(record)
            # This bounded unit is one action only. No automatic next step or recovery.
            self.保留中 = True
            return deepcopy(record)
        except BaseException as error:
            self.保留中 = True
            self.失敗群.append(error)
            if record is not None:
                record['障害'] = {'型': type(error).__name__, '理由': str(error), '状態': 'HOLD'}
            # No callbacks after failure. Exact primary/pending/receipts remain
            # in memory; the offline test controller persists failure evidence.
            raise
        finally:
            self.lock.release()
