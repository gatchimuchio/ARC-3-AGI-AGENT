# Independent mock-connection review

## Verdict before corrections

BLOCKED even for the advertised fail-closed mock contract. The original 37 tests pass independently, but three additional pure probes reproduce boundary failures. No native learning, restore, SDK or live actions were executed. Adoption must remain disabled.

1. HIGH: persistence-triggered reentry can latch HOLD and still allow a subsequent query. `_保存` checks the latch before calling the sink, but not after. The initial save callback reenters `一手`, catches the resulting HOLD, and returns a valid receipt. The outer path calls the machine once after HOLD before stopping at the next save. This contradicts the no-follow-on-call contract. Preserve the completed receipt, then check HOLD after every injected callback and before invoking the next callback, including input construction.
2. HIGH: decision validation mixes persisted and live outputs. The output snapshot is saved as `断定保留`, a save callback changes the original object's state to `出力`, and line 231 validates that live state while reading prediction content from the old snapshot. One action is executed with a receipt whose actual output says HOLD. Validate status/content/trace consistently from the detached returned-output snapshot and reject mutations as appropriate. The receipt hash alone is not proof of a confirmed decision.
3. MEDIUM: provenance deepcopy is outside the acquired lock's try/finally. A deepcopy exception leaves the lock locked, HOLD false and no primary exception recorded. Initialize a minimal failure record and enter try/finally before any fallible setup. The primary exception must survive; release lock and latch HOLD.

Evidence: `probes.py`, `probes.json`, `reviewed_source_before_fixes.py`, `reviewed_manifest_before_fixes.json`. The original 37-test rerun and its 27 negative/subtest records are under `run01/`. The new 47-file manifest verifier passed. The review read the required AGENTS, three Owner originals, hierarchy, current state and original restart validation report before reviewing implementation.

## Other reviewed boundaries

- Candidate enumeration retains all 4096 ACTION6 coordinates plus other legal actions; it does not prune. Candidate classification here is action-number matching, not exhaustive goal/effect/preservation reasoning. That distinction is explicit in README.
- Game IDs, filenames, hashes and provenance are retained in evidence, excluded from the operation-only machine input. The identity-permutation fixture establishes routing separation only. Caller-selected operation remains a fixture assumption and is not learned scene interpretation.
- All available frames and status, legality, level, reset and run-identity changes are retained. Hidden delta is explicitly unknown and unchanged pixels are not asserted to be no-op.
- Writer uses exclusive create, fsync, full readback and byte/hash receipts. Primary persistence exceptions and pending bytes remain in memory where serialization reached that stage. Durable emergency failure capture, native codec behavior and production resource limits remain unproven and explicitly gated. Trusted callback/directory limitations must remain visible.
- No teacher invocation, native Teach, principle acquisition or transfer is demonstrated. Fixed-family priors are appropriately separated in README. Historical counters and ability claims remain unremeasured.

## Relationship to genuine learning reconnection

This is a limited infrastructure experiment, useful only insofar as its corrected observation/evidence/action-binding contracts can be reused in the actual existing semantic route. It does not materially establish the requested cross-game learned operations: it queries only an externally supplied operation and deliberately cannot bind ACTION6. Existing `candidate_query_v5.semantic_entry`, candidate goalset and preservation semantics already provide structural coordinate reasoning. This limitation is in the new fixture's scope, not evidence of absent HDS capability. Do not extend this operation-only harness into a parallel solver. The next meaningful work is an independently pinned binding of the existing semantic/candidate/preservation path, not new grammar or policy, and remains separately scoped with native execution disabled until authorization and gates.

## Resource and evidence discipline

Both supplied tests and additional probes ran with `ulimit -v 524288` and `PYTHONDONTWRITEBYTECODE=1`, Python `-B`. Additional probes peak RSS: 16000 KiB. At initial rerun, harness tree was 2853233 bytes and review tree 1391666 bytes, far below 96 MiB; generated review evidence is separate. No source, existing evidence, core, authority, current state or Git content was modified. Corrections were requested from the implementation owner, not applied by reviewer.
