import sys, importlib.util, json, resource
from pathlib import Path
p=Path('/workspace/scratch/a94ff513b3af/arc-pinned-restart-20261019/tests/test_connection.py')
spec=importlib.util.spec_from_file_location('fixture_review',p);t=importlib.util.module_from_spec(spec);sys.modules[spec.name]=t;spec.loader.exec_module(t)
m=t.m
results={}
class ReenterSink(t.Sink):
 def 保存する(self,name,value):
  receipt=super().保存する(name,value)
  if len(self.calls)==1:
   try:c.一手(t.observation(),解答作業='完成列提出',来歴={})
   except m.保留:pass
  return receipt
machine=t.Machine();env=t.Environment();sink=ReenterSink();c=m.直列接続(系=machine,入力型=t.Input,作用型=t.Actions,環境=env,保存=sink,試験専用=True)
try:c.一手(t.observation(),解答作業='完成列提出',来歴={})
except Exception as e:results['reentry_during_first_save']={'exception':str(e),'query_calls_after_hold':len(machine.calls),'action_calls':len(env.calls),'saves':len(sink.calls),'hold':c.保留中}
class ChangeStatusSink(t.Sink):
 def 保存する(self,name,value):
  receipt=super().保存する(name,value)
  if len(self.calls)==2:machine.output.状態='出力'
  return receipt
r=t.reply();r.状態='断定保留';machine=t.Machine(r);env=t.Environment();sink=ChangeStatusSink();c=m.直列接続(系=machine,入力型=t.Input,作用型=t.Actions,環境=env,保存=sink,試験専用=True)
try:
 record=c.一手(t.observation(),解答作業='完成列提出',来歴={})
 status_error=None
except Exception as e:status_error=str(e)
results['status_changed_during_save']={'persisted_output_state':sink.calls[1]['照会返値']['状態'],'action_calls':len(env.calls),'error':status_error}
class BadCopy:
 def __deepcopy__(self,memo):raise ValueError('provenance deepcopy failure')
machine=t.Machine();env=t.Environment();sink=t.Sink();c=m.直列接続(系=machine,入力型=t.Input,作用型=t.Actions,環境=env,保存=sink,試験専用=True)
try:c.一手(t.observation(),解答作業='完成列提出',来歴=BadCopy())
except Exception as e:results['record_setup_failure']={'exception':str(e),'hold':c.保留中,'lock_locked':c.lock.locked(),'failure_count':len(c.失敗群)}
results['peak_rss_KiB']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
print(json.dumps(results,ensure_ascii=False,indent=2))
