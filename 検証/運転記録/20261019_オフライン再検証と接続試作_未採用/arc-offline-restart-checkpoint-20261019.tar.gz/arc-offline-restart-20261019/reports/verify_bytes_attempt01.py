import hashlib,json,pathlib,resource
resource.setrlimit(resource.RLIMIT_AS,(512*1048576,512*1048576))
r=pathlib.Path(__file__).resolve().parent
recovery=r.parent/'arc-preservation-recovery-20261019'
x=json.loads((recovery/'final_verified_tree.json').read_text())['structuredContent'];tree=json.loads(x['content']);lookup={v['path']:v for v in tree['tree']}
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def blob(p):
 b=p.read_bytes();return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
checks=[]
for base in (r/'extracted').iterdir():
 manifest=json.loads((base/'delivery_manifest.json').read_text())
 for item in manifest['files']:
  p=base/item['path'];assert p.stat().st_size==item['bytes'] and digest(p)==item['sha256'],str(p)
  checks.append({'path':str(p.relative_to(r)),'sha256':digest(p),'bytes':p.stat().st_size})
current=[]
base=r/'extracted/arc-restart-baseline-20261016'
for p in (base/'frozen').rglob('*'):
 if p.is_file():
  key=str(p.relative_to(base/'frozen')); assert blob(p)==lookup[key]['sha'],key
  current.append(key)
for p in (recovery/'main').rglob('*'):
 if p.is_file():
  key=str(p.relative_to(recovery/'main'));assert blob(p)==lookup[key]['sha'],key
  current.append(key)
for p in (recovery/'authority').glob('*.md'):
 matches=[v for k,v in lookup.items() if k.endswith('/'+p.name) and v.get('sha')==blob(p)]
 assert matches,p; current.append(matches[0]['path'])
report={'status':'PASS','manifest_files_verified':len(checks),'checks':checks,'current_tree_sha':tree['sha'],'current_tree_comparison':current,'current_tree_comparison_count':len(current),'tree_provenance':'Saved parent verified tree, not a new network head lookup','directory_bytes':sum(p.stat().st_size for p in r.rglob('*') if p.is_file()),'disk_cap_bytes':96*1048576}
assert report['directory_bytes']<report['disk_cap_bytes']
(r/'reports/byte_verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in report.items() if k not in ('checks','current_tree_comparison')}))
