# Offline restart validation, 2026-10-19

## Result

- Exact Library baseline archive: 140636 bytes, SHA-256 59f62454f7428d55f903d7cd9c0a4d24ca1c5a9ef663aaa05e2e742142cf35d0.
- Exact Library save-capture archive: 50880 bytes, SHA-256 f267792fe608d43e713755cb0201d13800e16dd4b22efacf53d16291e5dd24bd.
- Original baseline runner: 38 tests, zero failures/errors; 12 tests deliberately reproduce weaknesses. PASS_WITH_OBSERVED_WEAKNESSES.
- Original capture runner: 63 tests, zero failures/errors (the same 38 plus 25 capture tests). PASS_NOT_ADOPTED. These are 63 distinct cases, not 101 distinct cases.
- Serialized envelope only: 183 experiences, 16 principles, paired query/learning-decision counters 6647. Native restore was not run. No learning or ability improvement established; historical 1/183 remains unremeasured.
- All 83 files listed in the two delivery manifests still match byte lengths and SHA-256 after testing. Originals and historical failed-run evidence were preserved.
- Fourteen frozen core files and three current authority/state files match Git blob identities in the parent's saved verified tree 40deea6280da5dbd1cecba3772904781d8bf0f89. This is a comparison to that saved tree, not independent verification of current remote HEAD.
- Three Owner reference originals were reread and hashed. They are reference inputs, not assumed repository paths.
- Address space limited to 512 MiB. Capture peak RSS: 106520 KiB. Working tree was 6914231 bytes before this report, below 96 MiB. No SDK extraction, imports, native HDS import, native restore, Query, Teach, Action, live wrapper execution, Git write, or core edit.

## Reproduce without overwriting evidence

From arc-offline-restart-20261019, choose a NEW result leaf on each run:

    ulimit -v 524288
    PYTHONDONTWRITEBYTECODE=1 python -B extracted/arc-restart-baseline-20261016/verify_baseline.py
    PYTHONDONTWRITEBYTECODE=1 python -B extracted/arc-restart-baseline-20261016/tests/test_pure_save_boundaries.py --result-subdir NEW_LEAF
    PYTHONDONTWRITEBYTECODE=1 python -B extracted/arc-save-capture-repair-20261016/tests/test_capture.py --run NEW_LEAF
    python -B verify_bytes.py

Exact rerun results are under each extracted package's test_results/independent_restart_20261019 or evidence/independent_restart_20261019. Summary stdout and byte/envelope reports are under reports/.

## Concrete new connection path, not a historical recovery

Create a newly named, isolated connection such as 接続/目標相対再始動_v1, with adoption disabled. This is a proposed next implementation unit, not code implemented or adopted here. Freeze its own source/dependency manifest and its explicit call graph. Do not revive historical paths or claim equivalence to fresh043.

Available building blocks inspected:

1. source/ARC3境界.py is a self-contained stdlib boundary: 観測する validates public frames, legal actions, status, completed-level count and monotonic observation identity; HDS観測入力 retains full frames and distinguishes visible deltas from status transitions; 作用を排出する rejects stale, illegal and unconfirmed decisions. It does NOT itself prove that a caller's '確定' claim came from native HDS. The new runner must bind that claim to the exact native returned decision and evidence reference.
2. source/図式観測.py provides pure connected-component observation. It contains no learner or action selector.
3. source/列図式規則.py exposes existing restricted-family vocabulary and exhaustive assignment reasoning with injected HDS support. Its 4-pixel symbols, 6-pixel frame spacing, 10-pixel containers, finite/repeating-column grammar are FIXED PRIOR assumptions, not learned universal rules. Its native import was not executed. Reuse only within verified applicability, with unsupported inputs HOLD. It is not coverage of all25games.
4. source/resource_guard_v1.py supplies a pinned example of exclusive-create, fsync, full-readback and full pre/post resource accounting. Its literal old path and multi-GiB reserves do not fit the 96MiB offline fixture budget. Do not silently lower production thresholds or execute it as a relocated live writer. Specify and verify the new connection's real workload budget first; retain complete accounting and checks.
5. save_capture_not_adopted.py is a tested caller-side candidate, not an adopted runtime. Its known matching own-method frames can retain primary exceptions, pending descriptors and completed receipts. For a new binding, rerun its contract tests against the EXACT new methods, plus the outer HOLD/no-follow-on-call latch. Do not assume that passing against historical AST methods certifies a new writer or native codec.

A minimal launchable new runner should have explicit injected observation, native-machine and persistence interfaces; one serial decision/state owner; no historical wrapper imports, global path rewrites, monkey patches or evaluator access. Freeze each interface and fail closed before native execution if any required dependency is unavailable.

## Public teacher and causal gates

- Read authorized public observations/teacher material from the 25-game/183-level inventory, keeping source IDs only in provenance indexes. Runtime decisions receive goal-relative object/role/relation/state/action predicates; exclude IDs, filenames, hashes and replay sequences from solution-selection inputs.
- Save before observation, all available actions/candidates, target/role/relation, goal predicate, preconditions, predicted delta, action, complete after observation, actual visible/status/legal-action/level changes, reward/success/failure when publicly exposed, and uncertainty. Unchanged pixels do not prove no effect. Unavailable hidden delta is explicitly unknown; do not open hidden internals.
- A teacher answer is evidence for a hypothesis, not proof of a universal operation rule. Test necessity of prerequisites and failure boundaries with counterexamples, contrasting cases and fresh-instance reproduction. Preserve incorrect predictions, failed branches, HOLD and timeout/resource failures. No heuristic pruning, top-k, beam or skipped candidate checks.
- Trace every purported learned rule to actual frozen-HDS teach input, native judgement, supporting/contradicting experiences, applicability, state/principle delta and later query. Separate fixed grammar/prior from HDS-learned content. Query counters and fixture counts are not capability.
- Before transfer claims, require same-condition previous/current/delta and applicable-family regression, including all prior successes. Demonstrate reuse under changed surface identity and another eligible level/game without label-based routing. An identity-permutation fixture can test routing independence, but is not transfer performance.

## What blocks what

Historical-only blockers: absent fresh043 exact source/evidence and absent 358669-byte goalset_preparation_preservation_analysis_v1.json (SHA a86fb6da4582d5e8db24032cef2fa8f1a661fe55ca48ca2e8643a9ef5faffd85) prevent exact old-run reproduction/adopted-binding certification. They do not prohibit a separately named connection with independently pinned inputs and validation. A new measurement remains new evidence, never a replacement original.

Actual next-execution gates: no newly implemented/pinned connection exists yet; native codec/restore/save roundtrip and failure semantics remain untested; source-to-public-teacher provenance and runtime feature separation must be audited; exact HDS decision-to-action binding and public SDK contract must be tested; workload-specific resources and no-follow-on-call HOLD latch must be validated. Current work scope explicitly excludes native execution. The immediate next safe unit is implementation and pure mocked-contract validation of that new connection, followed by a separately scoped bounded native restore/Query/Teach pilot once these gates pass. Do not wait forever for historical bytes and do not bypass safety gates because history is missing.

## Audit-script failure retained

The first byte-audit attempt incorrectly required all three local Owner reference originals to have same-name repository entries; the 20261011 reference had no such entry. This was a validation-assumption error, not source corruption. Its runner is retained as reports/verify_bytes_attempt01.py. A mistaken attempt to run that archived runner from its relocated directory failed path resolution; its stderr is retained as reports/attempt01_relocated_not_run.txt. The corrected audit separately hashes reference inputs and requires tree equality only for files with established repository paths. No source, fixture, historical result or authority was changed to make the audit pass.
