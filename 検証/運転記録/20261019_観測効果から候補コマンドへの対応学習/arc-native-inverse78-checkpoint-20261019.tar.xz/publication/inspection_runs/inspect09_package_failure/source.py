import pathlib,json,hashlib,resource
resource.setrlimit(resource.RLIMIT_AS,(256*1024**2,)*2)
B=pathlib.Path('/workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019/publication_native_inverse');F=json.loads((B/'failed_package_record.json').read_bytes());p=pathlib.Path(F['retained_path']);h=hashlib.sha256()
with p.open('rb') as f:
 for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
assert p.stat().st_size==F['bytes']==2875902 and h.hexdigest()==F['sha256'];print('PARTIAL_BYTES_SHA_VERIFIED',F['bytes'],h.hexdigest())
for p in sorted((B/'captures/08_package').iterdir()):
 if p.is_file():
  raw=p.read_bytes();assert len(raw)<18000;print('FAILED_CAPTURE',p.relative_to(B),len(raw),hashlib.sha256(raw).hexdigest());print(raw.decode())
f=json.loads((B/F['manifest']).read_bytes());print('FAILED_MANIFEST_KEYS',list(f));print('FAILED_MANIFEST_NONFILES',{k:v for k,v in f.items() if k not in ['members','files','entries']});print('FAILED_MANIFEST_LIST_SHAPES',{k:len(v) for k,v in f.items() if isinstance(v,list)})
print('AVAILABLE_CAPTURES',[p.name for p in (B/'captures').iterdir()])
for p in B.glob('*count*'):
 if p.is_file() and p.stat().st_size<5000:print('COUNT_METADATA',p.name,p.read_text())
