import pathlib,json,resource,collections
resource.setrlimit(resource.RLIMIT_AS,(256*1024**2,256*1024**2))
B=pathlib.Path('/workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019/publication_native_inverse')
m=json.loads((B/'payload_manifest.json').read_bytes())
seen=set()
for x in m['files']:
 p=pathlib.Path(x['source']); a=x['archive_path']
 if x['sha256'] in seen: continue
 seen.add(x['sha256'])
 if p.suffix=='.json':
  with p.open() as f:d=json.load(f)
  shape={k:(list(v.keys())[:20] if isinstance(v,dict) else ['list',len(v), list(v[0].keys()) if v and isinstance(v[0],dict) else str(v[0])[:60] if v else None] if isinstance(v,list) else v) for k,v in d.items()} if isinstance(d,dict) else ['list',len(d),list(d[0].keys()) if d and isinstance(d[0],dict) else None]
  print(a,x['bytes'],'JSON',json.dumps(shape,ensure_ascii=False)[:2200])
 elif p.suffix not in ('.py','.sh','.md','.log','.txt'):print(a,x['bytes'],'BINARY_HEAD',repr(p.open('rb').read(96)))
print('UNIQUE',len(seen),'TOTAL',len(m['files']))
print('TEXT_SIZES',dict(collections.Counter({ext:sum(x['bytes'] for x in m['files'] if pathlib.Path(x['source']).suffix==ext) for ext in ['.py','.sh','.md','.log','.txt']})))
