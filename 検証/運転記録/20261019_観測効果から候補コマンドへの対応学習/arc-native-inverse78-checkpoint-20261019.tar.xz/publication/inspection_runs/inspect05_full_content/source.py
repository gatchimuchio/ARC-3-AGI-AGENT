"""Independent preservation inspection. Standard-library parsing only, no archived imports, calls or external references."""
import ast,collections,gc,hashlib,json,pathlib,re,resource,struct
resource.setrlimit(resource.RLIMIT_AS,(256*1024**2,)*2)
W=pathlib.Path('/workspace/scratch/a94ff513b3af');B=W/'arc-preservation-recovery-20261019/publication_native_inverse';M=json.loads((B/'payload_manifest.json').read_bytes());allowed={x['archive_path']:x for x in M['files']};root='arc-native-inverse-20261019/'
report={'manifest_sha256':hashlib.sha256((B/'payload_manifest.json').read_bytes()).hexdigest(),'file_count':len(allowed),'payload_bytes':sum(x['bytes'] for x in allowed.values()),'native_calls':0,'external_reference_reads':0,'AS_bytes':256*1024**2}
assert report['manifest_sha256']=='8a44e12135d131127fcd61064479714b913e7b6e2004ea2dc5703cd60f29001f'
def read(a):
 assert a in allowed,a
 p=W/a;assert not p.is_symlink();r=p.read_bytes();assert len(r)==allowed[a]['bytes'] and hashlib.sha256(r).hexdigest()==allowed[a]['sha256'];return r
def load(a):return json.loads(read(a))
def dec(x):
 if isinstance(x,list):return [dec(v) for v in x]
 if isinstance(x,dict):
  if set(x)=={'__辞書__'}:return {dec(k):dec(v) for k,v in x['__辞書__']}
  if set(x)=={'__組__'}:return tuple(dec(v) for v in x['__組__'])
  return {k:dec(v) for k,v in x.items()}
 return x
def plain(x):return json.loads(json.dumps(x,ensure_ascii=False))
patterns={
 'credential':re.compile(r'(?:-----BEGIN [A-Z ]*PRIVATE KEY-----|\b(?:sk-[A-Za-z0-9_-]{24,}|gh[pousr]_[A-Za-z0-9]{20,}|AKIA[A-Z0-9]{16})\b|(?i:Bearer)\s+[A-Za-z0-9_\-\.]{24,}|(?i:password|api_key|access_token|client_secret)\s*[=:]\s*[\"\'][^\"\']{8,}[\"\'])'),
 'email':re.compile(r'(?<![\w.])[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}(?![\w.])'),
 'personal_record':re.compile(r'(?i:\b(?:social.security|passport.number|date.of.birth|credit.card|home.address|phone.number|medical.record)\b)|(?:社会保障番号|旅券番号|生年月日|自宅住所|電話番号)'),
 'theory_marker':re.compile(r'(?i:\b(?:manuscript|axiom|theorem|foundational.theory)\b)|(?:公理|原稿|理論本文|理論原本|基礎理論)')}
alerts={k:{} for k in patterns};nstrings=0;nscalars=0;long_literals=[];schemas=collections.Counter();types=collections.Counter()
def textscan(s,a):
 global nstrings
 nstrings+=1
 for k,pat in patterns.items():
  for match in pat.finditer(s):
   key=(a,match.group(0));alerts[k][key]=s[max(0,match.start()-70):match.end()+100].replace('\n',' ')
def walk(v,a):
 global nscalars
 if isinstance(v,dict):
  for k,x in v.items():textscan(k,a);walk(x,a)
  if '__データ型__' in v:types[str(v['__データ型__'])]+=1
 elif isinstance(v,(list,tuple)):
  for x in v:walk(x,a)
 elif isinstance(v,str):textscan(v,a)
 else:nscalars+=1
seen=set();files_by_class=collections.Counter();all_framed={};reserve_stats=[]
for a,x in allowed.items():
 raw=read(a);ext=pathlib.Path(a).suffix
 if ext=='.reserve':
  if raw.startswith(b'{'):
   v=json.loads(raw);walk(v,a);files_by_class['whole_typed_state']+=1
   assert set(v)=={'__辞書__'};decoded=dec(v);schemas.update(decoded.keys());del decoded,v
   reserve_stats.append({'name':pathlib.Path(a).name,'kind':'whole_json_state','used':len(raw),'zero_tail':0})
  else:
   offset=0;frames=[]
   while offset+8<=len(raw) and raw[offset:offset+8]!=b'\0'*8:
    nh=struct.unpack('>Q',raw[offset:offset+8])[0];assert 0<nh<=256;h=json.loads(raw[offset+8:offset+8+nh]);start=offset+8+nh;end=start+h['bytes'];assert end<=len(raw);b=raw[start:end];assert hashlib.sha256(b).hexdigest()==h['sha256'];assert len(b)==h['bytes'];textscan(h['name'],a)
    try:v=json.loads(b);walk(v,a)
    except (json.JSONDecodeError,UnicodeDecodeError):textscan(b.decode('utf-8'),a)
    frames.append((h,b,offset));offset=end
   assert not any(raw[offset:]);all_framed[pathlib.Path(a).name]=frames;files_by_class['framed_or_zero_reserve']+=1;reserve_stats.append({'name':pathlib.Path(a).name,'kind':'framed_or_zero','frames':len(frames),'used':offset,'zero_tail':len(raw)-offset})
 elif ext=='.json':
  v=json.loads(raw);walk(v,a);files_by_class['json']+=1;del v
 elif ext in ('.py','.md','.sh','.log','.txt'):
  s=raw.decode('utf-8');textscan(s,a);files_by_class['source' if ext=='.py' else 'own_text']+=1
  if ext=='.py':
   tree=ast.parse(s)
   for node in ast.walk(tree):
    if isinstance(node,ast.Constant) and isinstance(node.value,str):
     textscan(node.value,a)
     if len(node.value)>600 and x['sha256'] not in seen:long_literals.append({'file':a,'line':node.lineno,'characters':len(node.value),'kind':'task code-generation or scoped implementation literal','sha256':hashlib.sha256(node.value.encode()).hexdigest()})
   del tree
  seen.add(x['sha256'])
 else:raise AssertionError(('unhandled content kind',a))
 del raw;gc.collect()
report['coverage']={'files_by_class':dict(files_by_class),'strings_and_keys_scanned':nstrings,'nonstring_scalars_scanned':nscalars,'typed_record_kinds':dict(types),'whole_state_top_fields':dict(schemas),'large_own_source_literals':long_literals}
report['screening_candidates']={k:[{'file':a,'match':term,'context':ctx} for (a,term),ctx in v.items()] for k,v in alerts.items()}
report['reserves']=reserve_stats
frames=all_framed['evidence.reserve'];assert len(frames)==243;F={h['name']:(b,o) for h,b,o in frames};assert len(F)==243
cfg=load(root+'proposed_config.json');plan=cfg['plan'];assert len(plan)==78 and [r['method'] for r in plan]==['照会する']*36+['処理する']*6+['照会する']*36
assert plan[:36]==plan[42:];outputs=[];last=-1;maxin=maxout=0
for i,r in enumerate(plan,1):
 p=f'{i:02d}.{r["method"]}';ab,ao=F[p+'.input'];bb,bo=F[p+'.output'];zb,zo=F[p+'.input_after'];assert last<ao<bo<zo;last=zo;assert ab==zb;assert dec(json.loads(ab))=={'__データ型__':'外部入力','値':r['input']};v=dec(json.loads(bb));assert v['__データ型__']=='外部出力';outputs.append(v['値']);maxin=max(maxin,len(ab));maxout=max(maxout,len(bb))
assert maxin<=8192 and maxout==51373<=73728
names=['normal_state','before_state']+[f'teach_{i:02d}_state' for i in range(1,7)]+['post_state'];baseline=dec(load(root+'run01/normal_state.reserve'));assert hashlib.sha256(read(root+'run01/normal_state.reserve')).hexdigest()=='328e31bb89c106f04a73cd12fa2ec6ec0a3ea446f9012d8c7b24a283b4a034b1';previous=baseline;state_rows=[]
for ix,name in enumerate(names):
 a=root+'run01/'+name+'.reserve';current=dec(load(a));assert set(current)==set(baseline)
 for old in (baseline,previous):
  for k,v in old['台帳'].items():assert current['台帳'][k][:len(v)]==v
  for k,v in old['原理履歴'].items():assert current['原理履歴'][k][:len(v)]==v
  assert current['状態履歴'][:len(old['状態履歴'])]==old['状態履歴']
 assert all(current[k]==baseline[k] for k in baseline if k not in ('台帳','原理履歴','状態履歴','識別子状態'))
 if name in ('before_state','post_state'):
  assert all(current[k]==previous[k] for k in previous if k!='識別子状態');expected=dict(previous['識別子状態']);expected['照会']+=36;expected['学習判定']+=36;assert current['識別子状態']==expected
 snap=dec(json.loads(F['snapshot.'+name][0]));assert snap['receipt']['bytes']==allowed[a]['bytes'] and snap['receipt']['sha256']==allowed[a]['sha256'];assert snap['ledger_slices']=={k:[len(previous['台帳'].get(k,())),len(v)] for k,v in current['台帳'].items()};assert snap['principle_history_slices']=={k:[len(previous['原理履歴'].get(k,())),len(v)] for k,v in current['原理履歴'].items()};assert snap['state_history_slice']==[len(previous['状態履歴']),len(current['状態履歴'])]
 state_rows.append({'name':name,'bytes':allowed[a]['bytes'],'experiences':len(current['台帳']['観測台帳']),'principles':len(current['台帳']['原理台帳']),'counters':current['識別子状態']});previous=current
final=current;delta={'old_prefixes_equal':True,'ledger_appends':{k:v[len(baseline['台帳'].get(k,())):] for k,v in final['台帳'].items()},'principle_history_appends':{k:v[len(baseline['原理履歴'].get(k,())):] for k,v in final['原理履歴'].items()},'state_history_appends':final['状態履歴'][len(baseline['状態履歴']):]};assert plain(delta)==load(root+'native_full_delta.json')
assert state_rows[0]['experiences']==210 and state_rows[0]['principles']==29 and state_rows[-1]['experiences']==216 and state_rows[-1]['principles']==31
pr=[p['値'] for p in delta['ledger_appends']['原理台帳']];obs=[x['値'] for x in delta['ledger_appends']['観測台帳']];source='要求する可視効果族';target='観測された作用番号候補';boundary=plan[0]['input']['対象系境界'];assert len(pr)==2
assert {(p['条件経路群'][0][0],p['結果経路'][0]) for p in pr}=={(source,target),(target,source)}
for p in pr:
 assert p['関係型']=='決定的対応関係' and p['版']==1 and p['対象系境界']==boundary and p['根拠参照群']==tuple(f'経験-{i:06d}' for i in range(211,214));assert not p['反証参照群'] and not p['除外反証参照群'];assert len(p['対応値表'])==2;assert final['状態履歴'][-1][p['系譜識別子']]==p['原理識別子']
 for o in obs:
  table={json.loads(k[0]):v for k,v in p['対応値表']};expect=o['原入力'][p['結果経路'][0]];actual=table[o['原入力'][p['条件経路群'][0][0]]];assert type(actual)is type(expect) and actual==expect
for i,o in enumerate(obs):assert o['原入力']==plan[36+i]['input']['内容'] and o['経験識別子']==f'経験-{211+i:06d}'
keys=('予測群','競合群','追加観測要求群','識別不能群','係争中原理群','断定保留理由群','学習成立状態');diagnostics=[];rawsame=[]
for i in range(36):
 a,z=outputs[i],outputs[i+42];rawsame.append(F[f'{i+1:02d}.照会する.output'][0]==F[f'{i+43:02d}.照会する.output'][0])
 if i<4:
  assert a['状態']=='出力' and a['内容']['学習成立状態']=='適用外' and a['内容']['予測群']==[];pred=z['内容']['予測群'];assert len(pred)==1;pred=pred[0];q=plan[i]['input']['内容'];field=next(iter(q));out=target if field==source else source;expected=next(o['原入力'][out] for o in obs if o['原入力'][field]==q[field]);assert type(pred['予測値'])is type(expected) and pred['予測値']==expected and tuple(pred['結果経路'])==(out,);diagnostics.append({'input':q,'prediction':pred['予測値'],'principle':pred['原理参照']})
 else:assert a['状態']==z['状態'] and all(a['内容'][k]==z['内容'][k] for k in keys);assert z['内容']['有効原理群'][:len(a['内容']['有効原理群'])]==a['内容']['有効原理群']
assert not any(rawsame[4:]);judgments=[x['内容']['学習成立状態'] for x in outputs[36:42]];assert judgments==['接続途上','接続途上','成立確認','接続途上','接続途上','接続途上']
completed=[json.loads(b) for h,b,o in all_framed['metadata_logs.reserve'] if h['name']=='completed'];assert len(completed)==1;completed=completed[0];assert completed['native_calls_entered']==completed['native_calls_returned']==completed['fully_persisted_calls']==78 and completed['entered_methods']==[r['method'] for r in plan] and completed['unprocessed_suffix']['exact_remaining_calls']==0
assert not all_framed['worker_failure.reserve'] and not all_framed['worker_emergency.reserve'] and not all_framed['failure_state.reserve'];sf=all_framed['supervisor_failure.reserve'];assert len(sf)==1 and json.loads(sf[0][1])==load(root+'native_supervisor.json') and json.loads(sf[0][1])['status']=='PASS'
report['native_raw_crosscheck']={'calls':78,'sequence':[36,6,36],'frames':243,'snapshots':state_rows,'old_prefixes_equal':True,'query_only_exact_counters':True,'complete_delta_equal':True,'directed_mappings':2,'versions':[1,1],'supports':[211,212,213],'new_predictions':diagnostics,'old32_relevant_equal':True,'old32_raw_equal':rawsame[4:],'teacher_judgments':judgments,'max_reply_bytes':maxout,'evidence_used_bytes':next(s['used'] for s in reserve_stats if s['name']=='evidence.reserve'),'baseline_external_body_not_opened':True}
del baseline,previous,current,final,delta,pr,obs,outputs,all_framed,F,frames;gc.collect()
T='arc-inverse-operator-teachers-20261019/';rows=load(T+'run01/all631_effect_truth.json');assert len(rows)==631;counts=collections.Counter();groups={};controls=[];scopes=[];fields=collections.Counter();phasecount=0;paired=0
stablekeys=['参照','参照矩形','対象矩形','方向','器具矩形','小器具矩形群','装置画素','大きさ','背景色','色見本'];palette='可視パレット既存色への器具色変更・参照対象姿勢配置保存';wide='固定広域幾何の器具色コピーによる可視対象変更・領域外保存'
for i,r in enumerate(rows):
 fields.update(r.keys());phasecount+=len(r['all_phase_checks']);s,a=r['before_scene'],r['after_scene'];effects=[];deltas={};checks={}
 assert r['hidden_state']=='unknown' and r['necessary_unique_or_fresh_sufficient'] is False and r['action_permission'] is False
 if s is not None and a is not None:
  deltas={k:{'before':s[k],'after':a[k]} for k in s if s[k]!=a[k]};stable=all(s[k]==a[k] for k in stablekeys);p=s['器具色']!=a['器具色'] and a['器具色'] in {v['色'] for v in s['色見本']} and s['対象']==a['対象'] and stable;dx,dy=s['方向'];grid=[[s['器具色'] if dx*(2*x-9)+dy*(2*y-9)>=0 else s['対象'][y][x] for x in range(10)] for y in range(10)];w=s['対象']!=a['対象'] and grid==a['対象'] and stable and s['器具色']==a['器具色'];checks={'structural_roles_preserved':stable,'palette_tool_copy_effect':p,'wide_geometry_target_value_effect':w,'wide_predicted_target':grid,'target_changed':s['対象']!=a['対象'],'tool_changed':s['器具色']!=a['器具色'],'stable_role_keys':stablekeys}
  if p:effects.append(palette)
  if w:effects.append(wide)
 assert effects==r['observed_effect_families'] and deltas==r['all_parsed_field_deltas'] and checks==r['descriptor_checks'];assert r['observed_action_id']==(r['actual_public_action'].get('id') if isinstance(r['actual_public_action'],dict) else None)
 if not effects:counts['other']+=1
 for effect in effects:counts[effect]+=1;groups.setdefault((r['pair'][0],effect),[]).append((i,r))
 if r['public_reset_flag']:controls.append({'index':i,'pair':r['pair'],'kind':'reset','effects':effects,'all_deltas':deltas})
 if (r['classifier_role_provenance_only'] or {}).get('役割')=='未対応':controls.append({'index':i,'pair':r['pair'],'kind':'unsupported click','effects':effects,'all_deltas':deltas,'whole_visible_endpoint_equal':r['visible_endpoint_equal']})
 if effects:
  assert r['before_status']=='NOT_FINISHED' and r['scope_error'] is None and r['observed_action_id'] in r['availability_before'] and s is not None;scopes.append({'pair':r['pair'],'before_normal_available_command_scope':True,'reset_flag_recorded_not_filter':r['public_reset_flag'],'identity_change_recorded_not_filter':r['public_identity_changed']})
  if wide in effects:assert r['paired_target_measurement']['selector']['status']=='PAIRED_VISIBLE_TARGET_ENDPOINT';paired+=1
assert dict(counts)=={'other':443,palette:98,wide:90};assert controls==load(T+'run02/all26_reset_unsupported_controls.json') and len(controls)==26 and all(not c['effects'] for c in controls);assert scopes==load(T+'run02/all188_pre_action_scope.json') and len(scopes)==188
cohorts=load(T+'run01/cohorts.json');assert len(cohorts)==len(groups)==6;teachers=[]
for c in cohorts:
 group=groups[c['recording_provenance'],c['desired_observable_effect_family']];assert c['all_members']==[{'pair':r['pair'],'all631_index':i} for i,r in group];outcomes={}
 for j,(i,r) in enumerate(group):outcomes.setdefault(str(r['observed_action_id']),[]).append(j)
 assert outcomes==c['all_distinct_action_outcomes'] and len(outcomes)==1 and c['conflicting_actions'] is False;command=int(next(iter(outcomes)));teachers.append({**c['proposed_query'],'内容':{**c['proposed_query']['内容'],target:command}})
assert teachers==load(T+'run01/teachers.proposal.runtime.json') and teachers==[x['input'] for x in plan[36:42]]
report['measurement_raw_crosscheck']={'rows':631,'fields_each_row':dict(fields),'full_nested_scalar_scan':True,'all_phase_checks':phasecount,'descriptor_counts':dict(counts),'all_deltas_and_descriptor_checks_equal':True,'cohorts':6,'scope_rows':188,'paired_target_receipts':paired,'controls_within_corpus':26,'reset_controls':sum(c['kind']=='reset' for c in controls),'unsupported_controls':sum(c['kind']=='unsupported click' for c in controls),'all_teacher_payloads_equal':True,'external_raw_phase_refs_not_followed':True}
report['peak_rss_KiB']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
out=B/'inspection_runs/inspect05_full_content/results.json';out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False,indent=2));print('ALL_CONTENT_AND_RAW_EVIDENCE_CHECKS_PASS')
