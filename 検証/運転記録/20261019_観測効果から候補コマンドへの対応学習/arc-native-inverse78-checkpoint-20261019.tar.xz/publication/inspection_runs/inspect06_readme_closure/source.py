import pathlib,json,hashlib,resource
resource.setrlimit(resource.RLIMIT_AS,(256*1024**2,)*2)
B=pathlib.Path('/workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019/publication_native_inverse');W=B.parents[1]
p=B/'README.md';raw=p.read_bytes();assert len(raw)==7910 and hashlib.sha256(raw).hexdigest()=='f083d91b9ed34bcafd1d0b18fd1d14a2a3544b9aa172caef11ef207a3ff3d549';print('PUBLISHER_README_SHA256',hashlib.sha256(raw).hexdigest());print(raw.decode())
m=json.loads((B/'payload_manifest.json').read_bytes());root='arc-native-inverse-20261019/';f=json.loads((W/(root+'freeze_manifest.json')).read_bytes());am={x['archive_path']:x for x in m['files']};
for a,x in f['files'].items():assert root+a in am and x['bytes']==am[root+a]['bytes'] and x['sha256']==am[root+a]['sha256']
extra=sorted(a for a in am if a.startswith(root) and a[len(root):] not in f['files']);print('NATIVE_FREEZE_ENTRIES',len(f['files']),'PAYLOAD_NATIVE_EXTRAS',extra);print('FREEZE_OMISSIONS',f['omissions'])
print('INSPECTOR_FILE_BYTES_BEFORE_THIS_STDOUT_CLOSE',sum(p.stat().st_size for p in (B/'inspection_runs').rglob('*') if p.is_file()))
