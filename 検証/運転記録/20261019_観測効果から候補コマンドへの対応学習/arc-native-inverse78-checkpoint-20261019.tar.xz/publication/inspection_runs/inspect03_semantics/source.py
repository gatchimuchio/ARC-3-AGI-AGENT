import pathlib,json,resource,ast,hashlib,collections,re
resource.setrlimit(resource.RLIMIT_AS,(256*1024**2,256*1024**2))
B=pathlib.Path('/workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019/publication_native_inverse');m=json.loads((B/'payload_manifest.json').read_bytes()); seen=set();special=['arc-native-inverse-20261019/audit01/source.py','arc-native-inverse-20261019/bounded_store.py','arc-inverse-launch-review-20261019/final_execution_audit/audit.py','arc-inverse-operator-teachers-20261019/run01/source.py']
for x in m['files']:
 p=pathlib.Path(x['source']);a=x['archive_path'];raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()==x['sha256'];assert len(raw)==x['bytes'];assert not p.is_symlink();assert a.split('/')[0] in m['closed_roots'];assert str(p)==str(pathlib.Path('/workspace/scratch/a94ff513b3af')/a)
 if x['sha256'] in seen:continue
 seen.add(x['sha256'])
 if p.suffix=='.md' or a in special:print('\nFILE',a,'\n'+raw.decode())
 elif p.suffix=='.py':
  t=ast.parse(raw);strings=[n.value for n in ast.walk(t) if isinstance(n,ast.Constant) and isinstance(n.value,str)];imports=[ast.unparse(n) for n in ast.walk(t) if isinstance(n,(ast.Import,ast.ImportFrom))];functions=[n.name for n in ast.walk(t) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))]
  print('AST',a,'imports',imports,'functions',functions,'strings',len(strings),'long_strings',[(len(s),s[:160]) for s in strings if len(s)>600])
 elif p.suffix in ('.log','.txt','.sh') and raw:print('OWN_LOG_OR_SHELL',a,'\n'+raw.decode())
print('ALL230_CONTENT_DIGEST_AND_SIZE_VERIFIED')
