import hashlib,json,pathlib,resource,sys
resource.setrlimit(resource.RLIMIT_AS,(256*1024**2,256*1024**2))
W=pathlib.Path('/workspace/scratch/a94ff513b3af')
R=W/'arc-preservation-recovery-20261019'; B=R/'publication_native_inverse'
p=B/'payload_manifest.json'; raw=p.read_bytes(); m=json.loads(raw)
print('MANIFEST_SHA',hashlib.sha256(raw).hexdigest(),'SIZE',len(raw))
print('MANIFEST_TYPE',type(m).__name__)
print(json.dumps(m,ensure_ascii=False,indent=2))
for p in [R/'authority'/x for x in ['Owner指示書原文_20261009.md','Owner追加指示原文_20261010T1907.md','Owner追加指示原文_20261011T1904.md']]+[R/'main/AGENTS.md',R/'main/運用/権限順序.md',R/'main/制御/現在状態.json']:
 raw=p.read_bytes(); raw.decode('utf-8');print('AUTHORITY_REREAD',str(p.relative_to(R)),len(raw),hashlib.sha256(raw).hexdigest())
print('PROCEDURE_NOTE initial authority-only cat was read before this persisted inspection run; full authority files reread here without changing them.')
