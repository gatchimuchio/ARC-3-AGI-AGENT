"""Read-only additive README/failure-record review. No payload execution or packaging."""
import pathlib,json,hashlib,difflib,resource
resource.setrlimit(resource.RLIMIT_AS,(256*1024**2,)*2)
R=pathlib.Path('/workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019');B=R/'publication_native_inverse'
for a in ['authority/Owner指示書原文_20261009.md','authority/Owner追加指示原文_20261010T1907.md','authority/Owner追加指示原文_20261011T1904.md','main/AGENTS.md','main/運用/権限順序.md','main/制御/現在状態.json']:
 raw=(R/a).read_bytes();print('AUTHORITY',a,hashlib.sha256(raw).hexdigest());print(raw.decode())
old=(B/'before_README_gzip.md').read_bytes();new=(B/'README.md').read_bytes();assert hashlib.sha256(old).hexdigest()=='f083d91b9ed34bcafd1d0b18fd1d14a2a3544b9aa172caef11ef207a3ff3d549';assert len(new)==8680 and hashlib.sha256(new).hexdigest()=='c7ba7ee307cae5c9c3972471e5d5825350418e1523a1446a60c5c376cf4e12ca';print('EXACT_README_DIFF');print(''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='before_README_gzip.md',tofile='README.md')))
for p in sorted(B.rglob('*')):
 if not p.is_file():continue
 if p.name=='failed_package_record.json' or p.name.startswith('resource_ledger_v2') or ('captures08' in p.parts and p.suffix in ['.py','.sh','.log','.txt','.json']):
  raw=p.read_bytes();assert len(raw)<20000;print('REVIEW_SOURCE',p.relative_to(B),'BYTES',len(raw),'SHA256',hashlib.sha256(raw).hexdigest());print(raw.decode())
print('MANIFEST_UNCHANGED',hashlib.sha256((B/'payload_manifest.json').read_bytes()).hexdigest());print('ADMISSION_UNCHANGED',hashlib.sha256((B/'payload_admission.json').read_bytes()).hexdigest());print('SEAL_UNCHANGED',hashlib.sha256((B/'inspection_manifest.json').read_bytes()).hexdigest())
