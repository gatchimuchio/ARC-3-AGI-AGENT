"""Seal private content-admission evidence; never execute or restore archived payload."""
import pathlib,json,hashlib,resource
resource.setrlimit(resource.RLIMIT_AS,(256*1024**2,)*2)
B=pathlib.Path('/workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019/publication_native_inverse');I=B/'inspection_runs';S=I/'inspect07_seal';sha=lambda b:hashlib.sha256(b).hexdigest()
M=json.loads((B/'payload_manifest.json').read_bytes());assert sha((B/'payload_manifest.json').read_bytes())=='8a44e12135d131127fcd61064479714b913e7b6e2004ea2dc5703cd60f29001f';assert sha((B/'README.md').read_bytes())=='f083d91b9ed34bcafd1d0b18fd1d14a2a3544b9aa172caef11ef207a3ff3d549'
for x in M['files']:
 p=pathlib.Path(x['source']);assert not p.is_symlink() and p.stat().st_size==x['bytes'];h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 assert h.hexdigest()==x['sha256']
for p in I.glob('inspect0[1-6]*/exit.txt'):assert p.read_text()=='0\n'
R=json.loads((I/'inspect05_full_content/results.json').read_bytes());assert all(not x for x in R['screening_candidates'].values());assert R['file_count']==230 and R['payload_bytes']==107001988
admission={
 'schema':'inverse78-private-payload-admission-v1','verdict':'PASS_PRIVATE_LOSSLESS_PRESERVATION_ONLY','payload_manifest_sha256':R['manifest_sha256'],'files':230,'bytes':107001988,'README_sha256':sha((B/'README.md').read_bytes()),
 'coverage':'All 230 bytestrings rehashed and content-parsed. All 75 Python sources parsed as AST and all string literals scanned; own Markdown/log/shell text reviewed. All 45 JSON files recursively traversed, all nine typed whole states decoded, all length-prefixed frames verified and all unused reserve tails checked zero. Complete 631-row scene/delta/phase/measurement structures scanned; effect descriptors, exact parsed deltas, cohort members, teacher inputs and controls independently recomputed. No archived code imported or executed.',
 'screening':'No credential, personal-record or original HDS manuscript content detected. Implementation/resource-proof code, scoped measurement contracts and learned records are legitimate task-derived preservation content. Lexical screening is combined with document/source/structured-content review; it is not a claim of universal secret-detection completeness.',
 'raw_checks':{'calls':78,'sequence':'36 Query / 6 Teach / 36 identical Query','frames':243,'whole_states':9,'experiences':[210,216],'principle_records':[29,31],'directed_mapping_versions':[1,1],'stored_supports':[211,212,213],'new_typed_predictions_matched':4,'old_relevant_projections_equal':32,'old_raw_replies_different':32,'corpus_partition':[98,90,443],'controls_inside_631':26},
 'retention':'All five closed roots admitted without derived exclusions. Failed template01 and closed_plan01 filename-guess evidence, earlier prepare proposals, corrected closed_plan02 and every native preparation/pure/execution/audit source/log remain retained. Native freeze90 entries plus manifest self and three closure02 terminal receipts are all in payload.',
 'README_review':'Claims and limitations consistent with payload raw evidence. Older external freeze totals and prior 1/183 fresh clear remain attributed historical context, not newly independently verified here. Archive/Library verification described in future workflow remains publisher responsibility.',
 'not_authorized':['public writing or publication','runtime wrapper adoption','native restore, Query, Teach or Action','fresh applicability or unseen-value transfer claims'],
 'limitations':['Effect vocabulary, geometry, roles and desired-goal selection remain priors; six cohorts are correlated historical records.','Bare offline checked_endpoint missing-flag limitation is unresolved.','Logical storage bounds do not guarantee physical ENOSPC durability.','External FileRefs, old archives, SDK/game bodies, opaque SDK stderr and active TURN were not opened or copied.'],
 'resource':{'AS_bytes':268435456,'peak_inspector_RSS_KiB':R['peak_rss_KiB'],'combined_publisher_inspector_limit_bytes':536870912,'output_limit_bytes':307200},
 'evidence':'inspection_runs/inspect05_full_content/results.json',
 'procedure_note':'Initial authority-only cat was an unpersisted read before inspection runs; all six authorities were then reread in persisted inspect01. All payload inspection runs have saved source and stdout/stderr/exit before their outputs were read. No inspection execution failure occurred.'}
(B/'payload_admission.json').write_text(json.dumps(admission,ensure_ascii=False,separators=(',',':'))+'\n')
terminal=[str((S/n).relative_to(B)) for n in ('stdout.log','stderr.log','exit.txt')];entries={}
for p in sorted(I.rglob('*')):
 if p.is_file() and str(p.relative_to(B)) not in terminal:entries[str(p.relative_to(B))]={'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
p=B/'payload_admission.json';entries[p.name]={'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
seal={'schema':'inverse78-inspection-seal-v1','status':'PRIVATE_CONTENT_ADMISSION_COMPLETE','payload_manifest_sha256':R['manifest_sha256'],'files':entries,'final_terminal_receipts_outside_self_hash':terminal,'self_exclusion':'inspection_manifest.json cannot hash itself; publisher must bind its hash and final terminal receipt hashes after successful run.','no_failures_discarded':True}
p=B/'inspection_manifest.json';p.write_text(json.dumps(seal,ensure_ascii=False,separators=(',',':'))+'\n');total=sum(p.stat().st_size for p in I.rglob('*') if p.is_file())+(B/'payload_admission.json').stat().st_size+p.stat().st_size;assert total+1024<=307200,(total,307200)
print(json.dumps({'verdict':admission['verdict'],'payload_admission_sha256':sha((B/'payload_admission.json').read_bytes()),'inspection_manifest_sha256':sha(p.read_bytes()),'sealed_files':len(entries),'output_bytes_before_final_receipts':total,'terminal_receipts':terminal},separators=(',',':')))
