#!/bin/bash
p=/workspace/scratch/a94ff513b3af/arc-preservation-recovery-20261019/publication_native_inverse/inspection_runs/inspect07_seal
ulimit -v 262144
python "$p/source.py" > "$p/stdout.log" 2> "$p/stderr.log"
s=$?
printf '%s\n' "$s" > "$p/exit.txt"
exit "$s"
