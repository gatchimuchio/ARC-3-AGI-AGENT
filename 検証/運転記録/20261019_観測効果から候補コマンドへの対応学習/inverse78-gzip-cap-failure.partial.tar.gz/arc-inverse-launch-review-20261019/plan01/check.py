import pathlib,json,hashlib,resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
P=pathlib.Path;c=json.loads(P('arc-native-inverse-20261019/proposed_config.json').read_bytes());closed=json.loads(P('arc-inverse-bound-review-20261019/closed_plan02/proposed_plan.json').read_bytes());assert c['plan']==closed['plan']
teachers=json.loads(P('arc-inverse-operator-teachers-20261019/run01/teachers.proposal.runtime.json').read_bytes());assert [r['input'] for r in c['plan'][36:42]]==teachers
base=P('arc-native-copy-20261019/run01/post_state.reserve');assert base.stat().st_size==6324220 and hashlib.sha256(base.read_bytes()).hexdigest()=='328e31bb89c106f04a73cd12fa2ec6ec0a3ea446f9012d8c7b24a283b4a034b1'
assert c['reply_cap_bytes']==73728
assert 78*73728+156*8192+10*16384+244*264==7256992
print('Exact closed plan, original six teachers, accepted baseline and evidence-envelope formula verified; zero native calls.')
