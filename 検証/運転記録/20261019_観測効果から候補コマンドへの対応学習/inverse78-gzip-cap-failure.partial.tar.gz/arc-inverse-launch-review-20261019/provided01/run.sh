#!/bin/bash
set -e
cd arc-inverse-launch-review-20261019/provided01
ulimit -v 524288
for f in test*.py; do PYTHONDONTWRITEBYTECODE=1 python "$f"; done
