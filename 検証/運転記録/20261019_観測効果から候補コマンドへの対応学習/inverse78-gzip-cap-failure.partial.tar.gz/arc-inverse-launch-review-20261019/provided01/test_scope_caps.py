"""Pure strict-input and record-limit probes: bootstrap deliberately unavailable."""
import ast,pathlib,sys,json,copy,unittest,resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2);sys.dont_write_bytecode=True
R=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(R));import launcher
PLAN=json.loads((R.parent.parent/'arc-inverse-bound-review-20261019/prepare02/proposed_plan.json').read_bytes())['plan']
class Reached(Exception):pass
class Store:
 def __init__(self):self.rows=[]
 def prepare_emergency(self,b):return b
 def append(self,*a):self.rows.append(a)
 def raw_emergency(self,*a):pass
class Tests(unittest.TestCase):
 def setUp(self):
  self.config={'plan':copy.deepcopy(PLAN),'pins':{},'state_upper_bound_bytes':6877589};self.s=Store();self.reached=False
  def stop():self.reached=True;raise Reached('pure stop before native import')
  launcher.load_native=stop
 def valid(self):
  with self.assertRaises(Reached):launcher.worker(self.s,self.config)
  self.assertTrue(self.reached)
 def invalid(self):
  with self.assertRaises(launcher.HOLD):launcher.worker(self.s,self.config)
  self.assertFalse(self.reached)
 def test_exact78_validators_pass(self):self.valid()
 def test_bool_is_not_command(self):self.config['plan'][36]['input']['内容']['観測された作用番号候補']=True;self.invalid()
 def test_command_unknown(self):self.config['plan'][36]['input']['内容']['観測された作用番号候補']=7;self.invalid()
 def test_command_string(self):self.config['plan'][36]['input']['内容']['観測された作用番号候補']='6';self.invalid()
 def test_unknown_effect(self):self.config['plan'][36]['input']['内容']['要求する可視効果族']='unknown';self.invalid()
 def test_effect_wrongtype(self):self.config['plan'][36]['input']['内容']['要求する可視効果族']=6;self.invalid()
 def test_overlong_atom(self):self.config['plan'][36]['input']['内容']['要求する可視効果族']='x'*257;self.invalid()
 def test_missing_effect(self):del self.config['plan'][36]['input']['内容']['要求する可視効果族'];self.invalid()
 def test_extra_content(self):self.config['plan'][36]['input']['内容']['extra']=1;self.invalid()
 def test_missing_role(self):del self.config['plan'][36]['input']['主体'];self.invalid()
 def test_extra_constructor(self):self.config['plan'][36]['input']['extra']=1;self.invalid()
 def test_context_wrongtype(self):self.config['plan'][36]['input']['文脈']=[];self.invalid()
 def test_role_notnull(self):self.config['plan'][36]['input']['対象']='x';self.invalid()
 def test_wrong_boundary(self):self.config['plan'][36]['input']['対象系境界']='COPY';self.invalid()
 def test_contradictory_pair_not_filtered(self):self.config['plan'][36]['input']['内容']['観測された作用番号候補']=5;self.valid()
 def test_mismatched_batches(self):self.config['plan'][42]['input']['内容']['要求する可視効果族']='x';self.invalid()
 def test_reverse_wrongtype_paired(self):
  for i in (2,44):self.config['plan'][i]['input']['内容']['観測された作用番号候補']=False
  self.invalid()
 def test_forward_query_wrongkey_paired(self):
  for i in (0,42):self.config['plan'][i]['input']['内容']={'観測された作用番号候補':6}
  self.invalid()
class Caps(unittest.TestCase):
 def setUp(self):
  tree=ast.parse((R/'launcher.py').read_text());w=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='worker');t=next(n for n in w.body if isinstance(n,ast.Try));f=next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='persist');self.s=Store();ns=dict(vars(launcher),store=self.s);exec(compile(ast.fix_missing_locations(ast.Module(body=[f],type_ignores=[])),'pure_persist','exec'),ns);self.persist=ns['persist']
 def test_proved66679(self):self.persist('01.照会する.output',b'x'*66679)
 def test_exact72k(self):self.persist('01.照会する.output',b'x'*73728)
 def test_over72k(self):
  with self.assertRaises(launcher.HOLD):self.persist('01.照会する.output',b'x'*73729)
  self.assertEqual(self.s.rows,[])
 def test_256byte_atom_bound_in_source(self):self.assertIn('len(json_bytes(v))>256',(R/'launcher.py').read_text())
if __name__=='__main__':unittest.main(verbosity=2)
