#!/bin/bash
set -e
for f in arc-inverse-launch-review-20261019/test*.py; do python "$f"; done
