#!/bin/bash
cd /workspace/scratch/a94ff513b3af/arc-native-inverse-20261019/pure01
PYTHONDONTWRITEBYTECODE=1 python -m unittest test_guard test_import_attributes test_scope_caps -v > stdout.log 2> stderr.log
s=$?; printf '%s\n' "$s" > exit_status.txt
exit "$s"
