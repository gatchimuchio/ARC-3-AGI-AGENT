"""Minimal inverse78 preparation; no native imports, allocation or calls."""
from pathlib import Path
import json,hashlib,resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
R=Path(__file__).resolve().parent.parent;B=R.parent;OLD=B/'arc-native-copy-20261019'
for n in ('binding.py','gate_metadata.py','source_allowlist.py','guard.py','bounded_store.py','read_run.py','test_guard.py','test_import_attributes.py'):(R/n).write_bytes((OLD/n).read_bytes())
s=(OLD/'launcher.py').read_text();changes=[('QCOUNT=32','QCOUNT=36'),("STATE=ROOT.parent/'arc-native-identity-20261019/run01/post_state.reserve'","STATE=ROOT.parent/'arc-native-copy-20261019/run01/post_state.reserve'"),('if i<2 or QCOUNT<=i<QCOUNT+TCOUNT or QCOUNT+TCOUNT<=i<QCOUNT+TCOUNT+2:','if i<4 or QCOUNT<=i<QCOUNT+TCOUNT or QCOUNT+TCOUNT<=i<QCOUNT+TCOUNT+4:'),('exact70/6/64 plan','exact78/6/72 plan'),("!=210:raise HOLD('nominal","!=216:raise HOLD('nominal"),('(65536 if name.endswith','(73728 if name.endswith')]
for a,b in changes:assert a in s,a;s=s.replace(a,b)
a=s.index("    prefix='公開パレット");z=s.index('  def persist(',a)
s=s[:a]+'''    prefix='公開役割拘束・観測された効果族から支持された作用番号候補'
    if p['対象系境界']!=prefix:raise HOLD('inverse measurement boundary')
    effect='要求する可視効果族';command='観測された作用番号候補'
    effects=('可視パレット既存色への器具色変更・参照対象姿勢配置保存','固定広域幾何の器具色コピーによる可視対象変更・領域外保存')
    if method=='処理する':keys={effect,command}
    else:keys={effect} if i% (QCOUNT+TCOUNT)<2 else {command}
    if set(p['内容'])!=keys:raise HOLD('inverse measurement keys')
    if effect in p['内容'] and (type(p['内容'][effect])is not str or p['内容'][effect] not in effects):raise HOLD('inverse effect scope')
    if command in p['内容'] and (type(p['内容'][command])is not int or p['内容'][command] not in (5,6)):raise HOLD('inverse command scope')
    if any(len(json_bytes(v))>256 for v in p['内容'].values()):raise HOLD('inverse atom byte bound')
'''+s[z:]
(R/'launcher.py').write_text(s)
(R/'derivative_changes.json').write_text(json.dumps({'origin':str(OLD/'launcher.py'),'origin_sha256':hashlib.sha256((OLD/'launcher.py').read_bytes()).hexdigest(),'replacements':changes,'scope_block':'strict supported effect string and int5/6,256B JSON atom bound; neither mapping nor predicted answer imposed on teachers','exact_copies':{n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in ('binding.py','bounded_store.py','gate_metadata.py','source_allowlist.py','guard.py','read_run.py')}},ensure_ascii=False,indent=2)+'\n')
print('Prepared inverse78 derivative only; no native calls.')
