"""Freeze proposed inverse78 config, never allocate/import native."""
import pathlib,json,hashlib,shutil,resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
R=pathlib.Path(__file__).resolve().parent.parent;B=R.parent;P=B/'arc-inverse-bound-review-20261019/closed_plan02'
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pins=json.loads((P/'source_pins.json').read_bytes())
for p,h in pins.items():assert H(pathlib.Path(p))==h,p
paths=[R/n for n in ('launcher.py','guard.py','bounded_store.py','binding.py','gate_metadata.py','source_allowlist.py','read_run.py','README.md')]+[P/n for n in ('teachers.runtime.json','queries.runtime.json','proposed_plan.json','source_pins.json')]+[B/'arc-inverse-bound-review-20261019/verdict.json',B/'arc-inverse-bound-review-20261019/README.md',B/'arc-native-copy-20261019/proposed_config.json']
for p in paths:pins[str(p)]=H(p)
plan=json.loads((P/'proposed_plan.json').read_bytes())['plan'];old=json.loads((B/'arc-native-copy-20261019/proposed_config.json').read_bytes())
assert len(plan)==78 and plan[:36]==plan[42:]
assert plan[4:36]==old['plan'][:32]
retained=old['retained_directories']+[str(B/n) for n in ('arc-native-copy-20261019','arc-inverse-operator-teachers-20261019','arc-inverse-operator-review-20261019','arc-inverse-bound-review-20261019','arc-inverse-launch-review-20261019')]
assert len(set(retained))==len(retained)
measured={p:sum(f.stat().st_size for f in pathlib.Path(p).rglob('*') if f.is_file()) for p in retained}
assert sum(measured.values())+96*1024**2<672*1024**2
config={'explicit_parent_admission':False,'state_upper_bound_bytes':6877589,'reply_upper_bound_bytes':66679,'reply_cap_bytes':73728,'scope':'two fixed observed effect descriptors to historically supported candidate command family, plus reverse diagnostics; no action authority','plan':plan,'pins':pins,'resource':{'AS_MiB':512,'directory_MiB':96,'fixed_reservations_MiB':92,'cpu_seconds':120,'wall_seconds':240,'aggregate_proposed_MiB':672,'free_floor_bytes':1024**3},'evidence_upper_bound_bytes':7256992,'evidence_reserved_bytes':8*1024**2,'source_bytes':6324220,'baseline_counter':6822,'baseline_experiences':210,'baseline_principle_versions':29,'regression_scope':'all32previous COPY query inputs; no full prior-success regression','retained_directories':retained,'retained_bytes_at_preparation':measured,'new_runtime_allocation':False,'current_fresh_action_permission':False,'input_contract':{'new_json_atom_cap':256,'effect_type':'str; exact two fixed descriptors','command_type':'int5or6; bool rejected'}}
(R/'proposed_config.json').write_text(json.dumps(config,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'config_sha256':H(R/'proposed_config.json'),'pins':len(pins),'retained_bytes':sum(measured.values()),'projected_plus96MiB':sum(measured.values())+96*1024**2,'aggregate_cap':672*1024**2,'free_bytes':shutil.disk_usage(R).free,'native_calls':0}))
