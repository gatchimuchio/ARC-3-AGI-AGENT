#!/bin/bash
cd /workspace/scratch/a94ff513b3af
PYTHONDONTWRITEBYTECODE=1 python arc-native-inverse-20261019/config01/source.py > arc-native-inverse-20261019/config01/stdout.log 2> arc-native-inverse-20261019/config01/stderr.log
s=$?; printf '%s\n' "$s" > arc-native-inverse-20261019/config01/exit_status.txt
exit "$s"
