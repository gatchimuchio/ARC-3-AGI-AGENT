"""Read-only output validation and bounded report generation; zero native calls."""
import pathlib,json,hashlib,sys,resource,shutil
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2);sys.dont_write_bytecode=True
R=pathlib.Path(__file__).resolve().parent.parent;B=R.parent;sys.path.insert(0,str(R));from read_run import records
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,x):(R/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
c=json.loads((R/'proposed_config.json').read_bytes());a=json.loads((R/'result_audit.json').read_bytes())
for p,h in c['pins'].items():assert H(pathlib.Path(p))==h
old=json.loads((B/'arc-native-copy-20261019/freeze_manifest.json').read_bytes())
for p,m in old['files'].items():
 f=B/'arc-native-copy-20261019'/p;assert f.stat().st_size==m['bytes'] and H(f)==m['sha256']
idx={}
for p in sorted((R/'run01').glob('*.reserve')):
 size=p.stat().st_size
 if p.stem in ('normal_state','before_state','post_state') or p.stem.startswith('teach_'):used=size;kind='full native JSON state'
 elif p.stem=='failure_state':used=0;kind='unused state reservation';assert not any(p.read_bytes())
 elif p.stem=='worker_emergency':
  raw=p.read_bytes();used=len(raw.rstrip(b'\0'));kind='prewritten emergency fallback (unused)'
 else:
  rr=records(p);used=sum(8+len(json.dumps(m,ensure_ascii=False,separators=(',',':')).encode())+len(b) for m,b in rr);kind='framed evidence/log';assert not any(p.read_bytes()[used:])
 idx[p.name]={'bytes':size,'valid_prefix_bytes':used,'kind':kind,'sha256':H(p)}
write('reserve_prefix_index.json',idx)
assert a['full_state_max_bytes']<=c['state_upper_bound_bytes'] and a['max_reply_bytes']<=c['reply_upper_bound_bytes']
assert idx['evidence.reserve']['valid_prefix_bytes']<=c['evidence_upper_bound_bytes']
assert a['entered_returned_persisted']['fully_persisted_calls']==78
retained={p:sum(f.stat().st_size for f in pathlib.Path(p).rglob('*') if f.is_file()) for p in c['retained_directories']}
unit=sum(f.stat().st_size for f in R.rglob('*') if f.is_file());assert unit+2*1024**2<96*1024**2;assert sum(retained.values())+96*1024**2<672*1024**2
report={'status':'PRODUCER_PASS_INDEPENDENT_REVIEW_PENDING','native_calls':78,'complete_evidence_frames':243,'full_snapshots':9,'state_slots':10,'evidence_used_bytes':idx['evidence.reserve']['valid_prefix_bytes'],'full_state_max_bytes':a['full_state_max_bytes'],'state_bound_bytes':c['state_upper_bound_bytes'],'max_reply_bytes':a['max_reply_bytes'],'reply_bound_bytes':c['reply_upper_bound_bytes'],'peak_child_rss_kib':a['entered_returned_persisted']['peak_rss_KiB'],'wall_seconds':a['supervisor']['wall_seconds'],'cpu_seconds':'not separately measured;120s cap enforced','unit_bytes_before_final_report':unit,'retained_bytes':retained,'aggregate_with_full96MiBunit':sum(retained.values())+96*1024**2,'aggregate_cap_bytes':672*1024**2,'previous_copy_frozen_files_unchanged':len(old['files']),'all39pins_unchanged':True,'free_bytes_after':shutil.disk_usage(R).free,'native_truncation_limitation':'known-writer logical bounds; no physical ENOSPC persistence guarantee','baseline_sha256':c['pins'][str(B/'arc-native-copy-20261019/run01/post_state.reserve')],'post_state_sha256':H(R/'run01/post_state.reserve')}
write('resource_validation.json',report)
print(json.dumps(report,ensure_ascii=False))
