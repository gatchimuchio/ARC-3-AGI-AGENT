#!/bin/bash
cd /workspace/scratch/a94ff513b3af
PYTHONDONTWRITEBYTECODE=1 python arc-native-inverse-20261019/closure02/source.py > arc-native-inverse-20261019/closure02/stdout.log 2> arc-native-inverse-20261019/closure02/stderr.log
s=$?; printf "%s\n" "$s" > arc-native-inverse-20261019/closure02/exit_status.txt
exit "$s"
