"""Read-only native wire/evidence audit. No HDS imports or native calls."""
import pathlib,json,hashlib,resource,sys,collections
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2);sys.dont_write_bytecode=True
R=pathlib.Path(__file__).resolve().parent.parent;B=R.parent;sys.path.insert(0,str(R));from read_run import records

def dec(x):
 if isinstance(x,list):return [dec(v) for v in x]
 if isinstance(x,dict):
  if '__辞書__' in x:return {dec(k):dec(v) for k,v in x['__辞書__']}
  if '__組__' in x:return tuple(dec(v) for v in x['__組__'])
  return {k:dec(v) for k,v in x.items()}
 return x
def write(n,x):(R/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def read(p):return dec(json.loads(p.read_bytes()))
config=json.loads((R/'proposed_config.json').read_bytes());frames=records(R/'run01/evidence.reserve');data={m['name']:readbytes for m,readbytes in frames};outputs=[]
for i,row in enumerate(config['plan'],1):
 key=f'{i:02d}.'+row['method'];before=data[key+'.input'];after=data[key+'.input_after'];assert before==after
 inp=dec(json.loads(before));assert inp['値']==row['input'];out=dec(json.loads(data[key+'.output']));outputs.append(out['値'])
assert len(outputs)==78 and len(frames)==243
baseline=read(B/'arc-native-copy-20261019/run01/post_state.reserve');last=baseline;snapshots=[]
for name in ['normal_state','before_state']+[f'teach_{i:02d}_state' for i in range(1,7)]+['post_state']:
 p=R/'run01'/f'{name}.reserve';cur=read(p)
 for old in (baseline,last):
  for k,v in old['台帳'].items():assert cur['台帳'][k][:len(v)]==v
  for k,v in old['原理履歴'].items():assert cur['原理履歴'][k][:len(v)]==v
  assert cur['状態履歴'][:len(old['状態履歴'])]==old['状態履歴']
 snapshots.append({'name':name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'counts':{k:len(v) for k,v in cur['台帳'].items()},'counters':cur['識別子状態'],'state_history_count':len(cur['状態履歴'])});last=cur
final=last
for before_name,after_name in [('normal_state','before_state'),('teach_06_state','post_state')]:
 a=read(R/'run01'/f'{before_name}.reserve');z=read(R/'run01'/f'{after_name}.reserve')
 for k in a:
  if k!='識別子状態':assert a[k]==z[k]
 expected=dict(a['識別子状態']);expected['照会']+=36;expected['学習判定']+=36;assert expected==z['識別子状態']
new={k:v[len(baseline['台帳'].get(k,[])):] for k,v in final['台帳'].items()}
principles=[p['値'] for p in new['原理台帳']];ids=set(final['状態履歴'][-1].values());active_new=[p for p in principles if p['原理識別子'] in ids]
keys=('状態','予測群','競合群','追加観測要求群','識別不能群','係争中原理群','断定保留理由群','学習成立状態')
def relevant(o):return {k:o['状態'] if k=='状態' else o['内容'].get(k) for k in keys}
comparisons=[]
for i in range(36):
 a=outputs[i];z=outputs[42+i];q=config['plan'][i]['input'];expected=None;target=[]
 if i<4:
  field=next(iter(q['内容']));value=q['内容'][field];result_field='観測された作用番号候補' if field=='要求する可視効果族' else '要求する可視効果族'
  matches={json.dumps(t['input']['内容'][result_field],ensure_ascii=False) for t in config['plan'][36:42] if t['input']['内容'][field]==value}
  assert len(matches)==1;expected=json.loads(next(iter(matches)))
  target=[p for p in z['内容'].get('予測群',[]) if tuple(p['結果経路'])==(result_field,)]
 comparisons.append({'query_index':i,'input':q,'before':a,'after':z,'raw_reply_equal':a==z,'relevant_projection_equal':relevant(a)==relevant(z),'mapping_expected_value':expected,'mapping_prediction_values':[p['予測値'] for p in target],'mapping_exact_prediction_match':len(target)==1 and type(target[0]['予測値'])is type(expected) and target[0]['予測値']==expected if i<4 else None,'kind':('forward_effect_to_candidate' if i<2 else 'reverse_candidate_to_effect' if i<4 else 'prior32_smoke')})
logs=records(R/'run01/metadata_logs.reserve');completed=[json.loads(b) for m,b in logs if m['name']=='completed'];assert len(completed)==1
out={'status':'PRODUCER_AUDIT_NATIVE_COMPLETE_INDEPENDENT_REVIEW_PENDING','native_calls':78,'entered_returned_persisted':completed[0],'snapshots':snapshots,'old_prefixes_equal':True,'query_only_state_equal_except_exact_counters':True,'teacher_outputs':outputs[36:42],'teacher_judgments':[x['内容'].get('学習成立状態') for x in outputs[36:42]],'new_principle_versions':principles,'new_active_principles':active_new,'query_comparisons':comparisons,'old_smoke_relevant_equal':all(c['relevant_projection_equal'] for c in comparisons[4:]),'old_smoke_raw_equal':all(c['raw_reply_equal'] for c in comparisons[4:]),'mapping_diagnostics_exact':all(c['mapping_exact_prediction_match'] for c in comparisons[:4]),'delta_counts':{k:len(v) for k,v in new.items()},'final_counters':final['識別子状態'],'state_growth':snapshots[-1]['bytes']-snapshots[0]['bytes'],'max_reply_bytes':max(len(b) for m,b in frames if m['name'].endswith('.output')),'evidence_frames':len(frames),'full_state_max_bytes':max(s['bytes'] for s in snapshots),'supervisor':json.loads((R/'native_supervisor.json').read_bytes())}
write('result_audit.json',out);write('native_full_delta.json',{'ledger_appends':new,'principle_history_appends':{k:v[len(baseline['原理履歴'].get(k,[])):] for k,v in final['原理履歴'].items()},'state_history_appends':final['状態履歴'][len(baseline['状態履歴']):],'old_prefixes_equal':True})
print(json.dumps({k:out[k] for k in ('native_calls','teacher_judgments','old_prefixes_equal','old_smoke_relevant_equal','old_smoke_raw_equal','mapping_diagnostics_exact','delta_counts','final_counters','state_growth','max_reply_bytes','evidence_frames','full_state_max_bytes')},ensure_ascii=False))
