"""Freeze prepared unit only; no native calls."""
import pathlib,json,hashlib,resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
R=pathlib.Path(__file__).resolve().parent.parent;B=R.parent
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
c=json.loads((R/'proposed_config.json').read_bytes());assert H(R/'proposed_config.json')=='3fb280095367f6583cd88da35a1c05fef3ca3a4d7a6d504837ccc8adcfe72cc1'
for p,h in c['pins'].items():assert H(pathlib.Path(p))==h,p
review=B/'arc-inverse-launch-review-20261019/reviewed_manifest.json';assert H(review)=='442399a1e54a5d3252f5cfa761a43a480dfedd4fb40a4c00b7d58dc6cd2a7dc4'
retained={p:sum(f.stat().st_size for f in pathlib.Path(p).rglob('*') if f.is_file()) for p in c['retained_directories']}
assert sum(retained.values())+96*1024**2<672*1024**2
files={str(p.relative_to(R)):{'bytes':p.stat().st_size,'sha256':H(p)} for p in sorted(R.rglob('*')) if p.is_file() and p.name!='preparation_manifest.json' and not(p.parent.name=='closure01' and p.name in ('stdout.log','stderr.log','exit_status.txt'))}
x={'status':'INVERSE78_PREPARATION_COMPLETE_REVIEW_PASS_NO_NATIVE_ADMISSION','root':str(R),'paths_relative_to':'root','native_calls':0,'reservations_allocated':False,'config_sha256':H(R/'proposed_config.json'),'review_manifest_sha256':H(review),'files':files,'omissions':['self preparation_manifest.json','closure01 stdout/stderr/exit_status created by closure; retained separately'],'retained_measured_bytes':retained,'projected_with_full96MiB':sum(retained.values())+96*1024**2,'aggregate_proposed_bytes':672*1024**2}
(R/'preparation_manifest.json').write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'manifest_sha256':H(R/'preparation_manifest.json'),'files':len(files),'projected_bytes':x['projected_with_full96MiB']}))
