#!/bin/bash
cd /workspace/scratch/a94ff513b3af
PYTHONDONTWRITEBYTECODE=1 python arc-native-inverse-20261019/execution01/source.py > arc-native-inverse-20261019/execution01/stdout.log 2> arc-native-inverse-20261019/execution01/stderr.log
s=$?; printf '%s\n' "$s" > arc-native-inverse-20261019/execution01/exit_status.txt
exit "$s"
