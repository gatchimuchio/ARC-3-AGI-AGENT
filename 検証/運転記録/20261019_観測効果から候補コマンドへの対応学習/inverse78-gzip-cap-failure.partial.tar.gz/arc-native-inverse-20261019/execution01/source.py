"""Single parent-admitted inverse78 run; explicit confined manifest roots."""
import pathlib,json,hashlib,shutil,sys,resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2);sys.dont_write_bytecode=True
R=pathlib.Path(__file__).resolve().parent.parent;B=R.parent
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
EXPECTED='3fb280095367f6583cd88da35a1c05fef3ca3a4d7a6d504837ccc8adcfe72cc1'
raw=(R/'proposed_config.json').read_bytes();assert H(R/'proposed_config.json')==EXPECTED
assert H(R/'preparation_manifest.json')=='6dd8d96c7f7b5ae4156ba8301c2c343d33ec31885384a991bbdf352ec2f64e27'
assert H(R/'execution01/reviewed_manifest.json')=='442399a1e54a5d3252f5cfa761a43a480dfedd4fb40a4c00b7d58dc6cd2a7dc4'
c=json.loads(raw);assert c['explicit_parent_admission'] is False
for p,h in c['pins'].items():assert H(pathlib.Path(p))==h,p
for manifest,root in [(R/'preparation_manifest.json',R),(B/'arc-native-copy-20261019/freeze_manifest.json',B/'arc-native-copy-20261019'),(R/'execution01/reviewed_manifest.json',B)]:
 root=root.resolve();assert root in (R.resolve(),B.resolve(),(B/'arc-native-copy-20261019').resolve())
 for p,m in json.loads(manifest.read_bytes())['files'].items():
  rel=pathlib.Path(p);assert not rel.is_absolute() and '..' not in rel.parts
  f=(root/rel).resolve();assert f.is_relative_to(root)
  assert f.stat().st_size==m['bytes'] and H(f)==m['sha256'],p
baseline=B/'arc-native-copy-20261019/run01/post_state.reserve'
assert baseline.stat().st_size==6324220 and H(baseline)=='328e31bb89c106f04a73cd12fa2ec6ec0a3ea446f9012d8c7b24a283b4a034b1'
assert not (R/'run01').exists()
retained={p:sum(f.stat().st_size for f in pathlib.Path(p).rglob('*') if f.is_file()) for p in c['retained_directories']}
prep=sum(f.stat().st_size for f in R.rglob('*') if f.is_file())
assert prep+92*1024**2+3*1024**2<96*1024**2
assert sum(retained.values())+96*1024**2<672*1024**2
assert shutil.disk_usage(R).free>=1024**3+92*1024**2
admission={'authority':'Explicit parent one-run inverse78 admission 2026-10-19T04:31UTC','config_sha256':EXPECTED,'calls':78,'sequence':'36Query/6processing/36Query','resource':c['resource'],'actual_retained_bytes':retained,'actual_preparation_bytes':prep,'free_bytes_before':shutil.disk_usage(R).free,'scope':c['scope'],'automatic_retry':False,'current_action_permission':False}
(R/'execution_admission.json').write_text(json.dumps(admission,ensure_ascii=False,indent=2)+'\n')
c['explicit_parent_admission']=True;sys.path.insert(0,str(R));import launcher
result=launcher.execute(c)
(R/'native_supervisor.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
assert (R/'proposed_config.json').read_bytes()==raw
print(json.dumps(result,ensure_ascii=False));raise SystemExit(0 if result['status']=='PASS' else 2)
