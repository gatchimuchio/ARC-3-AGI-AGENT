import ast,collections,hashlib,itertools,json,pathlib,resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
R=pathlib.Path(__file__).resolve().parent;B=R.parent.parent;P=R.parent/'closed_plan02';C=B/'arc-native-query-20261019/frozen/HDS/学習系統/v0.4.2/hds学習系統';S=B/'arc-native-copy-20261019/run01/post_state.reserve'
def dec(x):
 if isinstance(x,list):return list(map(dec,x))
 if isinstance(x,dict):
  if '__辞書__' in x:return {dec(k):dec(v)for k,v in x['__辞書__']}
  if '__組__' in x:return tuple(map(dec,x['__組__']))
  return {k:dec(v)for k,v in x.items()}
 return x
def enc(x):
 if isinstance(x,dict):return {'__辞書__':[[enc(k),enc(v)]for k,v in x.items()]}
 if isinstance(x,tuple):return {'__組__':list(map(enc,x))}
 if isinstance(x,list):return list(map(enc,x))
 return x
def size(x):return len(json.dumps(x,ensure_ascii=False,indent=2).encode())
assert hashlib.sha256(S.read_bytes()).hexdigest()=='328e31bb89c106f04a73cd12fa2ec6ec0a3ea446f9012d8c7b24a283b4a034b1'
assert hashlib.sha256((B/'arc-native-copy-20261019/freeze_manifest.json').read_bytes()).hexdigest()=='c09e8cb66f5d300413e86469da359aa052a8900de2650b8a580dacbec817df64'
assert hashlib.sha256((B/'arc-copy-launch-review-20261019/final_execution_audit/verified_evidence_manifest.json').read_bytes()).hexdigest()=='a792cf00dd66221935ed86eee02eec7755173c09bcd2b9feeefd493b76fba7a7'
prior_pins=json.loads((B/'arc-native-copy-20261019/proposed_config.json').read_bytes())['pins']
for path in C.glob('*.py'):assert prior_pins[str(path)]==hashlib.sha256(path.read_bytes()).hexdigest()
raw=json.loads(S.read_bytes());s=dec(raw);ts=json.loads((P/'teachers.runtime.json').read_bytes());qs=json.loads((P/'queries.runtime.json').read_bytes());plan=json.loads((P/'proposed_plan.json').read_bytes())['plan']
fields={n.name:[f.target.id for f in n.body if isinstance(f,ast.AnnAssign)]for n in ast.parse((C/'型.py').read_text()).body if isinstance(n,ast.ClassDef)and any(isinstance(d,ast.Call)and isinstance(d.func,ast.Name)and d.func.id=='dataclass'for d in n.decorator_list)}
counts=collections.Counter()
def walk(x):
 if isinstance(x,dict):
  if '__データ型__' in x:
   n=x['__データ型__'];assert list(x['値'])==fields[n];counts[n]+=1
  for v in x.values():walk(v)
 elif isinstance(x,list):
  for v in x:walk(v)
walk(raw)
assert len(ts)==6 and len(qs)==36 and len(plan)==78
assert plan==[{'method':'照会する','input':q}for q in qs]+[{'method':'処理する','input':t}for t in ts]+[{'method':'照会する','input':q}for q in qs]
old=json.loads((B/'arc-native-copy-20261019/proposed_config.json').read_bytes())['plan'][:32];assert qs[4:]==[x['input']for x in old]
w=json.loads((B/'arc-inverse-operator-teachers-20261019/run01/teachers.proposal.runtime.json').read_bytes());assert ts==w
b=ts[0]['対象系境界'];assert all(t['対象系境界']==b for t in ts)
assert all(e['値']['対象系境界']!=b for e in s['台帳']['観測台帳'])
assert all(p['値']['対象系境界']!=b for ps in s['原理履歴'].values()for p in ps)
for t in ts+qs:
 assert set(t)=={'内容','対象系境界','主体','対象','目的','文脈'}
 assert all(t[k]is None for k in ('主体','対象','目的'))and type(t['文脈'])is dict and t['文脈']=={}
 assert type(t['内容'])is dict and all(type(k)is str and not k.startswith('@HDS:')for k in t['内容'])
 assert all(type(v)in(str,bool,int)for v in t['内容'].values())
for t in ts:
 assert set(t['内容'])=={'要求する可視効果族','観測された作用番号候補'}
 assert type(t['内容']['要求する可視効果族'])is str and type(t['内容']['観測された作用番号候補'])is int
for q in qs[:2]:assert set(q['内容'])=={'要求する可視効果族'}and type(q['内容']['要求する可視効果族'])is str
for q in qs[2:4]:assert set(q['内容'])=={'観測された作用番号候補'}and type(q['内容']['観測された作用番号候補'])is int
paths=sorted(ts[0]['内容']);previous={};versions=collections.Counter();cand=adopt=changed=0;prefix=[]
for n in range(1,7):
 now=[]
 for source,result in itertools.permutations(paths):
  table={};conflicts=[]
  for t in ts[:n]:
   a=t['内容'][source];z=t['内容'][result];assert a!=z
   k=json.dumps(a,ensure_ascii=False,separators=(',',':'));v=json.dumps(z,ensure_ascii=False,separators=(',',':'))
   if k in table and table[k]!=v:conflicts.append((k,v))
   table[k]=v
  assert not conflicts
  key=(b,'決定的対応関係',((source,),),(result,))
  if n>=3 and len(table)>=2:
   cand+=1
   if previous.get(key)!=table:adopt+=1;versions[key]+=1;previous[key]=table;now.append(key)
 changed+=bool(now);prefix.append({'teacher':n,'adoptions':len(now)})
assert(cand,adopt,changed,len(versions))==(8,2,1,2)
active=[next(p['値']for p in reversed(s['原理履歴'][k])if p['値']['原理識別子']==v)for k,v in s['状態履歴'][-1].items()]
assert len(active)==22 and all(p['状態']['値']=='適用範囲付き暫定原理'and p['採用状態']['値']=='有効'for p in active)
g=collections.Counter((p['対象系境界'],p['結果経路'])for p in active)
for boundary,rel,conds,result in versions:g[(boundary,result)]+=1
assert max(g.values())==1
assert max(collections.Counter([p['対象系境界']for p in active]+[k[0]for k in versions]).values())==2
widths={'input_wire':max(size({'__データ型__':'外部入力','値':{k:enc(v)for k,v in t.items()}})for t in ts+qs),'atom_json':max(size(v)for t in ts+qs for v in t['内容'].values()),'double_encoded_atom_json':max(size(json.dumps(v,ensure_ascii=False))for t in ts+qs for v in t['内容'].values()),'path_json':max(size(k)for t in ts+qs for k in t['内容']),'boundary_json':max(size(t['対象系境界'])for t in ts+qs),'new_lineage_json':max(size(repr(k))for k in versions)}
assert widths['input_wire']<8192 and widths['double_encoded_atom_json']<=256 and widths['path_json']<=128 and widths['boundary_json']<=256 and widths['new_lineage_json']<=1024
out={'status':'STATIC_INPUT_BRANCH_PASS_COPY_BASELINE_AUDIT_VERIFIED','native_calls':0,'old_dataclass_counts':dict(counts),'all_existing_fields_and_order_match':True,'all32_prior_queries_preserved':True,'teachers_equal_qualified_witness':True,'new_lineage_versions':[{'lineage':repr(k),'versions':v}for k,v in versions.items()],'candidate_events':cand,'adoptions':adopt,'changed_calls':changed,'prefix':prefix,'input_widths':widths,'counters_before':s['識別子状態'],'source_pins':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in C.glob('*.py')},'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(R/'audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out,ensure_ascii=False,indent=2))
