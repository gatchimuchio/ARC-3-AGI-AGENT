import hashlib,json,pathlib,resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
R=pathlib.Path(__file__).resolve().parent;B=R.parent.parent
S=B/'arc-native-copy-20261019/run01/post_state.reserve';A=B/'arc-copy-launch-review-20261019/final_execution_audit/MANIFEST.json'
assert hashlib.sha256(S.read_bytes()).hexdigest()=='328e31bb89c106f04a73cd12fa2ec6ec0a3ea446f9012d8c7b24a283b4a034b1'
assert hashlib.sha256(A.read_bytes()).hexdigest()=='a792cf00dd66221935ed86eee02eec7755173c09bcd2b9feeefd493b76fba7a7'
for n in ('teachers.runtime.json','queries.runtime.json'):(R/n).write_bytes((R.parent/'prepare02'/n).read_bytes())
plan=json.loads((R.parent/'prepare02/proposed_plan.json').read_bytes());plan['baseline_status']='INDEPENDENT_COPY_AUDIT_PASSED';plan['baseline_sha256']=hashlib.sha256(S.read_bytes()).hexdigest();plan['baseline_path']=str(S);plan['baseline_audit_manifest_sha256']=hashlib.sha256(A.read_bytes()).hexdigest()
(R/'proposed_plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n')
paths=[S,A,B/'arc-native-copy-20261019/freeze_manifest.json',B/'arc-inverse-operator-review-20261019/MANIFEST.json',B/'arc-inverse-operator-review-20261019/README.md',B/'arc-inverse-operator-teachers-20261019/MANIFEST.json',B/'arc-inverse-operator-teachers-20261019/run01/teachers.proposal.runtime.json',B/'arc-inverse-operator-teachers-20261019/README.md',R.parent/'proof01/static_bound.py',R.parent/'proof01/state_proof.json',R.parent/'reply01/reply_bound.py',R.parent/'reply01/reply_proposal.json']+list((B/'arc-native-query-20261019/frozen/HDS/学習系統/v0.4.2/hds学習系統').glob('*.py'))
(R/'source_pins.json').write_text(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in paths},indent=2)+'\n')
print('Frozen exact78-call plan; independent COPY baseline audit confirmed; no native admission.')
