# Inverse effect-to-command: closed pure resource proof

## Result and exact final inputs

BOUNDED PASS for the frozen78-call plan's static state/input/reply/evidence bounds. No native execution admission, allocation, HDS import/call, SDK, Action, Git or publication occurred. Authority was reread; HDS v0.4.2 remains fixed, strategy null and automatic transition false.

FINAL INPUT DIRECTORY: closed_plan02. Earlier prepare01/prepare02 and failed closed_plan01 remain history, not the final metadata. Six teachers,36 queries per side:2 distinct effect→command queries,2 command→effect diagnostics requested by the parent, and all32 exact previous queries. Exact sequence36 Query +6 Teach +36 identical Query =78 calls. closed_plan02/proposed_plan.json keeps native_execution_authorized=false.

- teachers.runtime.json SHA2560b0c386ea2555a4c672efd1a8bb9eeaa106234a2f0a826dad18dfb58b8f7acfb
- queries.runtime.json SHA2567e4d098189d0f3396617cc81df0504202fd2f9447f415e8222855fd6f5d3ccd5
- proposed_plan.json SHA25630123d927f148d732edac92a57a167e1a81a31c35cb2dd00f46cdd835a234d73

Semantic review manifest58613fa62e5bccf9a40302df89d05bda3bcc5dd0b1efc66481f2315e2b3063bd and its README are pinned in closed_plan02/source_pins.json. Teacher payload objects equal the six qualified historical cohort payloads exactly. This proof does not re-review all631 underlying witnesses or convert candidate-command association into execution permission.

## Actual baseline closure

COPY poststate arc-native-copy-20261019/run01/post_state.reserve is6,324,220bytes, SHA256328e31bb89c106f04a73cd12fa2ec6ec0a3ea446f9012d8c7b24a283b4a034b1:210 experiences,29 principle versions,22 current active lineages, paired Query counters6822. Producer freeze c09e8cb66f5d300413e86469da359aa052a8900de2650b8a580dacbec817df64 and independent COPY audit manifest a792cf00dd66221935ed86eee02eec7755173c09bcd2b9feeefd493b76fba7a7 verified. Baseline is external read-only, not another unbudgeted copy.

check02/audit.py independently verifies all existing dataclass fields and order against frozen source, all12 source hashes against COPY's executed configuration, exact constructor keys, null metadata, strict empty dictionary context, complete old query preservation, and boundary absence from all old observations and principle-history versions. All7 persisted top-level fields are covered. No restore-default expansion is omitted.

## Branch closure, including inverse collisions

The6 teachers contain exactly2 distinct pairs: one Japanese effect-description string→integer6, another→integer5. Strings and integers are strictly typed, never bool or interchangeable. Both directions are collision-free on every prefix. They are 決定的対応関係, NOT 同値関係: string descriptors are not equal to command integers. Two inferred leaves produce4 observations after the2 metadata observations are included.

Both directed candidates become eligible at prefixes3–6 (support>=3 and2 distinct condition values):8 candidate events. Tables already contain both pairs at prefix3, so only2 initial adoptions,2 new lineages and1 changed state snapshot occur. All later teachers/candidate evidence remain recorded; identical tables do not add versions or refresh original principle support references. Support tuples<=6, doubts5, candidate/adoption/update references2, history snapshots22 old+2 new lineages.

New-boundary absence excludes old-principle audit mutation. Every new observed pair agrees with both directed tables, so no refutation/quarantine occurs. No isolated parent or excluded-support continuation exists; no specialization/reopening or residual-capacity branch is reached. This is a closed-data proof, not a caller rule that rejects contradictions. A different/colliding future teacher invalidates this proof and must not be silently filtered to preserve it.

Query counters increase at most72, to6894. Other counters remain inside six-digit/32-byte identifier padding. All new ledgers, duplicated principle-history records, state snapshots and caught-failure prefix states are included.

## Full native-state upper bound

Proof01 reuses the corrected explicit native-wire record shapes and separately checks4 observation entries. It changes only appropriate atom widths and expected snapshot count, without global cardinality replacement. ensure_ascii=False/indent2 dataclass, enum, tuple and dictionary shapes and real field names are retained. Record roots are padded to depth12, plus128bytes per record and32KiB structural/counter slack.

Effect atom JSON width is86bytes; double-encoded table-key width90bytes. Old64-byte atom padding would be insufficient. The new proof explicitly pads all table/raw/observation value atoms to256bytes. Paths<=128, boundaries<=256, new lineage<=1024, IDs/timestamps32 and static diagnostic strings512 dominate the closed inputs. Largest observed input wire563bytes, path JSON62bytes, boundary JSON152bytes, new lineage JSON192bytes.

6,324,220 baseline
+6*58,027 base records
+8*9,242 candidate records
+2*44,125 adoption records (including duplicated full principles)
+1 padded full state snapshot
+32,768 structural slack
=6,877,589bytes <8,388,608bytes.

All saved old state remains untouched; only append-only records and counters change. Partial failures cannot exceed these event totals. This does not guarantee native RAM sufficiency, successful persistence or arbitrary failure survivability.

## External replies and evidence

All22 old active summaries remain in output, with2 padded new summaries (24 maximum). Every (boundary,result path) group is singleton; at most2 principles match a boundary. New reverse rules have distinct result paths. Thus no conflict or global ambiguity group and no isolated-principle output can arise for this frozen sequence. The envelope still allows2 predictions and2 requests simultaneously,6 HOLD reasons and the union of Teach/Query trace keys. Reverse command queries can return the complete86-byte effect string; it is included.

Reply upper66,679bytes EXCEEDS the old64KiB allowance. Required new per-reply allowance is72KiB=73,728bytes. Do not carry forward64KiB metadata.

78*73,728 reply bytes +156*8,192 input/postinput bytes +10*16,384 snapshot-index bytes +244*(256+8) framing =7,256,992bytes <8MiB. This preserves an8MiB evidence file and unchanged8MiB RLIMIT_FSIZE. No extra full-state delta copy or unbounded trace is budgeted. Final caller review must retain/enforce these frame/index limits and exact record counts.

Proposed96MiB new unit:10 single-use8MiB states (normal,before,6 teacher,post,failure)=80MiB;8MiB evidence;four disjoint1MiB metadata/failure/emergency/supervisor regions;remaining4MiB for all preparation/code/input/report/partial-write bytes. Actual existing aggregate bytes, previous failed attempts in the unit and free-space floor must be measured before admission. No slot reuse/deletion, no hidden baseline copy, no automatic resumption from UNKNOWN frontier.

## Reproduction and limits

All work is pure under512MiB AS, below96MiB review output. Source/stdout/stderr/exit files are retained in separate leaves. template01 failed a source-token-count assertion before numerical work; template02 corrected the asserted seven explicit atom replacements. closed_plan01 failed on a guessed manifest filename before copying inputs; closed_plan02 uses and verifies the actual verified_evidence_manifest.json. No failed artifacts were overwritten. proof01, reply01, check01/check02 and closed_plan02 succeeded. prepare01's74-call proposal remains superseded by requested78-call prepare02.

Final caller/binding/resource/failure admission and explicit parent execution permission remain separate. Native outcomes must remain raw and include negative/HOLD/error outcomes. Forward effect→command association identifies supported candidate command families only, not fresh-state sufficiency, unique command, target authority, legal coordinates or Action permission. TURN is a later sequential unit and must use the actual independently accepted post-inverse state, never assume this same baseline for actual adoption.
