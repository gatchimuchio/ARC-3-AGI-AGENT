import hashlib,pathlib
R=pathlib.Path(__file__).resolve().parent;B=R.parent.parent
p=B/'arc-copy-pilot-plan-20261019/static_bound.py';s=p.read_text()
assert hashlib.sha256(p.read_bytes()).hexdigest()=='f25c630e501f064654a9905cf6a4291d4b3f64b57f2ad53d0afe9fc0cd96333a'
head=s[:s.index('s=dec(json.loads(STATE.read_bytes()))')]
head=head.replace('BASE=ROOT.parent','BASE=ROOT.parent.parent')
old="STATE=BASE/'arc-native-identity-20261019/run01/post_state.reserve'";assert head.count(old)==1
head=head.replace(old,"STATE=BASE/'arc-native-copy-20261019/run01/post_state.reserve'")
head=head.replace("TEACH=ROOT/'teachers.runtime.json'","TEACH=ROOT.parent/'prepare02/teachers.runtime.json'")
facts='''s=dec(json.loads(STATE.read_bytes()));ts=json.loads(TEACH.read_bytes());b=ts[0]['対象系境界']
assert len(ts)==6 and len(s['台帳']['観測台帳'])==210 and len(s['台帳']['原理台帳'])==29
assert s['識別子状態']['照会']==s['識別子状態']['学習判定']==6822
assert len(s['状態履歴'][-1])==22
assert all(e['値']['対象系境界']!=b for e in s['台帳']['観測台帳'])
assert all(p['値']['対象系境界']!=b for ps in s['原理履歴'].values() for p in ps)
assert all(t['対象系境界']==b and set(t['内容'])=={'要求する可視効果族','観測された作用番号候補'} for t in ts)
assert all(type(t['内容']['要求する可視効果族'])is str and type(t['内容']['観測された作用番号候補'])is int for t in ts)
assert all(t['主体'] is t['対象'] is t['目的'] is None and type(t['文脈'])is dict and t['文脈']=={} for t in ts)
rows=[(t['内容']['要求する可視効果族'],t['内容']['観測された作用番号候補']) for t in ts]
assert len(set(rows))==2 and all(a!=z for a,z in rows)
tables={};candidate_events=adoptions=changed_calls=0;prefix=[]
for n in range(1,7):
 new=0;count=0
 for direction in (0,1):
  table={}
  for a,z in rows[:n]:
   if direction:a,z=z,a
   assert a not in table or table[a]==z
   table[a]=z
  if n>=3 and len(table)>=2:
   candidate_events+=1;count+=1
   if tables.get(direction)!=table:adoptions+=1;new+=1;tables[direction]=table
 changed_calls+=bool(new);prefix.append({'prefix':n,'candidates':count,'adoptions':new})
assert (candidate_events,adoptions,changed_calls)==(8,2,1)
literalmax=max(len(n.value.encode()) for p in CORE.glob('*.py') for n in ast.walk(ast.parse(p.read_text())) if isinstance(n,ast.Constant) and isinstance(n.value,str))
escaped_literalmax=max(len(json.dumps(n.value,ensure_ascii=False).encode())-2 for p in CORE.glob('*.py') for n in ast.walk(ast.parse(p.read_text())) if isinstance(n,ast.Constant) and isinstance(n.value,str))
assert escaped_literalmax<=512
assert all(len(json.dumps(json.dumps(v,ensure_ascii=False),ensure_ascii=False).encode())<=256 for t in ts for v in t['内容'].values())
'''
shape=s[s.index("R='R'*32;"):s.index('# No conflicting old boundary')]
assert shape.count('len(snapshot)==22')==1;shape=shape.replace('len(snapshot)==22','len(snapshot)==24')
# Only string atom widths, not cardinalities, are changed. Keep4 observations.
assert shape.count("'V'*64")==7
shape=shape.replace("'V'*64","'V'*256")
assert shape.count('encode())<=64')==1;shape=shape.replace('encode())<=64','encode())<=256')
assert 'for _ in range(4)' in shape
end='''assert len(ex['値']['観測群']['__組__'])==4
base=envelopes['experience']+envelopes['cognitive']+5*envelopes['doubt']+envelopes['learning']+envelopes['feedback']
candidate=envelopes['inference']+envelopes['evidence']+envelopes['judgement']
adoption=2*envelopes['principle']+envelopes['provisional']+envelopes['update']
state_bound=STATE.stat().st_size+6*base+candidate_events*candidate+adoptions*adoption+changed_calls*envelopes['state_history_snapshot']+32768
assert state_bound<8388608
result={'status':'STATIC_PROPOSED_NO_EXECUTION_ADMISSION','baseline_bytes':STATE.stat().st_size,'baseline_sha256':hashlib.sha256(STATE.read_bytes()).hexdigest(),'teacher_sha256':hashlib.sha256(TEACH.read_bytes()).hexdigest(),'prefix':prefix,'candidate_events':candidate_events,'adoptions':adoptions,'changed_calls':changed_calls,'envelopes':envelopes,'base_per_teacher':base,'candidate_per_event':candidate,'adoption_per_event':adoption,'state_upper_bound_bytes':state_bound,'state_slot_bytes':8388608,'atom_padding':256,'native_calls':0}
(ROOT/'state_proof.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\\n');print(json.dumps(result,ensure_ascii=False,indent=2))
'''
(R/'static_bound.py').write_text(head+facts+shape+end)
print('Template prepared only; no baseline read or numerical proof executed.')
