"""Static closed-data serialization envelopes. No native imports or execution.
These are upper-bound witnesses, not replacement persistence or learning.
"""
import ast, hashlib, json, pathlib, resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
ROOT=pathlib.Path(__file__).resolve().parent
BASE=ROOT.parent.parent
CORE=BASE/'arc-native-query-20261019/frozen/HDS/学習系統/v0.4.2/hds学習系統'
STATE=BASE/'arc-native-copy-20261019/run01/post_state.reserve'
TEACH=ROOT.parent/'prepare02/teachers.runtime.json'
def dec(x):
 if isinstance(x,list):return [dec(v) for v in x]
 if isinstance(x,dict):
  if '__辞書__' in x:return {dec(k):dec(v) for k,v in x['__辞書__']}
  if '__組__' in x:return tuple(dec(v) for v in x['__組__'])
  return {k:dec(v) for k,v in x.items()}
 return x
# Mirrors wire shape for size bounding only. Never used to persist native state.
def enc(x):
 if isinstance(x,tuple):return {'__組__':[enc(v) for v in x]}
 if isinstance(x,list):return [enc(v) for v in x]
 if isinstance(x,dict):return {'__辞書__':[[enc(k),enc(v)] for k,v in x.items()]}
 return x
def dat(name,**fields):return {'__データ型__':name,'値':{k:enc(v) for k,v in fields.items()}}
def size_at_depth(x,depth=12):
 s=json.dumps(x,ensure_ascii=False,indent=2)
 # Native record root is shallower than depth12. Add12*2 spaces to EVERY line.
 return len(s.encode())+len(s.splitlines())*depth*2+128
s=dec(json.loads(STATE.read_bytes()));ts=json.loads(TEACH.read_bytes());b=ts[0]['対象系境界']
assert len(ts)==6 and len(s['台帳']['観測台帳'])==210 and len(s['台帳']['原理台帳'])==29
assert s['識別子状態']['照会']==s['識別子状態']['学習判定']==6822
assert len(s['状態履歴'][-1])==22
assert all(e['値']['対象系境界']!=b for e in s['台帳']['観測台帳'])
assert all(p['値']['対象系境界']!=b for ps in s['原理履歴'].values() for p in ps)
assert all(t['対象系境界']==b and set(t['内容'])=={'要求する可視効果族','観測された作用番号候補'} for t in ts)
assert all(type(t['内容']['要求する可視効果族'])is str and type(t['内容']['観測された作用番号候補'])is int for t in ts)
assert all(t['主体'] is t['対象'] is t['目的'] is None and type(t['文脈'])is dict and t['文脈']=={} for t in ts)
rows=[(t['内容']['要求する可視効果族'],t['内容']['観測された作用番号候補']) for t in ts]
assert len(set(rows))==2 and all(a!=z for a,z in rows)
tables={};candidate_events=adoptions=changed_calls=0;prefix=[]
for n in range(1,7):
 new=0;count=0
 for direction in (0,1):
  table={}
  for a,z in rows[:n]:
   if direction:a,z=z,a
   assert a not in table or table[a]==z
   table[a]=z
  if n>=3 and len(table)>=2:
   candidate_events+=1;count+=1
   if tables.get(direction)!=table:adoptions+=1;new+=1;tables[direction]=table
 changed_calls+=bool(new);prefix.append({'prefix':n,'candidates':count,'adoptions':new})
assert (candidate_events,adoptions,changed_calls)==(8,2,1)
literalmax=max(len(n.value.encode()) for p in CORE.glob('*.py') for n in ast.walk(ast.parse(p.read_text())) if isinstance(n,ast.Constant) and isinstance(n.value,str))
escaped_literalmax=max(len(json.dumps(n.value,ensure_ascii=False).encode())-2 for p in CORE.glob('*.py') for n in ast.walk(ast.parse(p.read_text())) if isinstance(n,ast.Constant) and isinstance(n.value,str))
assert escaped_literalmax<=512
assert all(len(json.dumps(json.dumps(v,ensure_ascii=False),ensure_ascii=False).encode())<=256 for t in ts for v in t['内容'].values())
R='R'*32; T='T'*32; TEXT='X'*512; PATH=('P'*128,); REFS=(R,)*6
# Existing snapshot (15 lineages) plus the sole new lineage, length bounded1024.
snapshot=dict(s['状態履歴'][-1]);snapshot.update({str(i)+'L'*1023:R for i in range(2)})
assert len(snapshot)==24 and all(len(k.encode())<=1024 and len(v.encode())<=32 for k,v in snapshot.items())
# Scalar public input/path byte lengths and native fixed strings are bounded by
# these witnesses. New principle table max4; envelope uses6 and64-byte atoms.
assert len(b.encode())<=256
assert all(len(k.encode())<=128 for t in ts for k in t['内容'])
assert all(len(json.dumps(v,ensure_ascii=False).encode())<=256 for t in ts for v in t['内容'].values())
P=dict(原理識別子=R,対象系境界='B'*256,系譜識別子='L'*1024,版=999999,状態='X'*64,関係型='X'*64,条件経路群=(PATH,),結果経路=PATH,対応表=tuple(((('V'*256),),'V'*256) for _ in range(6)),対応値表=tuple(((('V'*256),),'V'*256) for _ in range(6)),根拠参照群=REFS,反証参照群=(),適用範囲={'確認範囲':TEXT,'条件数':2,'条件種類数':6},再開放条件=(TEXT,)*3,時点=T,親原理参照=None,改訂理由=None,除外反証参照群=(),解決理由=None,解決主体=None,採用状態='X'*64)
# Use exact enum wire representation after scalar enc (not an underestimate).
p=dat('原理記録',**P)
for field,typ in [('状態','原理状態'),('採用状態','採用状態')]:p['値'][field]={'__列挙__':typ,'値':'X'*64}
learning=dat('学習過程記録',学習識別子=R,学習前状態版=999999,学習後状態版=999999,経験参照=R,懐疑参照群=(R,)*5,推論候補参照群=(R,R),採用原理参照群=(R,R),再開放原理参照群=(),学習成立状態='X'*64,時点=T,係争化原理参照群=(),状態変化理由群=(TEXT,),対象系境界='B'*256,主体参照=None,対象期間=(T,T),学習前状態スナップショット=snapshot,保持記憶参照群=REFS,更新記録参照群=(R,R),観測限界=(TEXT,)*2,観測限界参照群=())
learning['値']['学習成立状態']={'__列挙__':'学習成立状態','値':'X'*64}
doubt=dat('懐疑記録',懐疑識別子=R,経験参照=R,焦点=TEXT,作用内容=TEXT,参照経験群=REFS,時点=T,対象経路群=(PATH,)*4,要求操作群=(TEXT,)*3,発火根拠=TEXT)
# Exact dictionary shapes from _記憶する, candidate loop, _採用する,
# and execution completion. Names, wrappers, tuple widths are preserved.
other_records={
 'cognitive':dict(経験参照=R,対象系境界='B'*256,観測経路群=(PATH,)*4,主体=None,対象=None,目的=None,暫定性=TEXT,時点=T),
 'inference':dict(候補参照=R,経験参照群=REFS,懐疑参照群=(R,)*5,関係型=TEXT,条件経路群=(PATH,),結果経路=PATH,生成条件={'作用':TEXT,'因果断定':False},時点=T),
 'evidence':dict(候補参照=R,判定=TEXT,理由=TEXT,支持参照群=REFS,反証参照群=(),時点=T),
 'judgement':dict(候補参照=R,採否=TEXT,判定=TEXT,時点=T),
 'provisional':dict(対象参照=R,対象型=TEXT,対象系境界='B'*256,暫定性状態=TEXT,再開放条件=(TEXT,)*3,時点=T),
 'update':dict(更新識別子=R,種別=TEXT,原理参照=R,系譜='L'*1024,旧版=999999,新版=999999,親原理参照=None,時点=T),
 'feedback':dict(種別=TEXT,経験参照=R,学習参照=R,状態版=999999,時点=T),
}
ex=dat('経験記録',経験識別子=R,対象系境界='B'*256,原入力={'P'*128:'V'*256,'Q'*128:'V'*256},観測群=(),主体=None,対象=None,目的=None,時点=T)
ex['値']['観測群']={'__組__':[dat('観測事実',経路=PATH,値='V'*256,値型='X'*64,推論対象=False) for _ in range(4)]}
envelopes={'principle':size_at_depth(p),'learning':size_at_depth(learning),'doubt':size_at_depth(doubt),'experience':size_at_depth(ex),'state_history_snapshot':size_at_depth(enc(snapshot))}
envelopes.update({k:size_at_depth(enc(v)) for k,v in other_records.items()})
assert max(envelopes.values())<=32768,envelopes
assert len(ex['値']['観測群']['__組__'])==4
base=envelopes['experience']+envelopes['cognitive']+5*envelopes['doubt']+envelopes['learning']+envelopes['feedback']
candidate=envelopes['inference']+envelopes['evidence']+envelopes['judgement']
adoption=2*envelopes['principle']+envelopes['provisional']+envelopes['update']
state_bound=STATE.stat().st_size+6*base+candidate_events*candidate+adoptions*adoption+changed_calls*envelopes['state_history_snapshot']+32768
assert state_bound<8388608
result={'status':'STATIC_PROPOSED_NO_EXECUTION_ADMISSION','baseline_bytes':STATE.stat().st_size,'baseline_sha256':hashlib.sha256(STATE.read_bytes()).hexdigest(),'teacher_sha256':hashlib.sha256(TEACH.read_bytes()).hexdigest(),'prefix':prefix,'candidate_events':candidate_events,'adoptions':adoptions,'changed_calls':changed_calls,'envelopes':envelopes,'base_per_teacher':base,'candidate_per_event':candidate,'adoption_per_event':adoption,'state_upper_bound_bytes':state_bound,'state_slot_bytes':8388608,'atom_padding':256,'native_calls':0}
(ROOT/'state_proof.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2))
