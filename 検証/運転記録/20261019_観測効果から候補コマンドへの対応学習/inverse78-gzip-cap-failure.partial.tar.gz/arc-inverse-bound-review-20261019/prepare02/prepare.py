import hashlib,json,pathlib,resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
R=pathlib.Path(__file__).resolve().parent;B=R.parent.parent
T=B/'arc-inverse-operator-teachers-20261019/run01/teachers.proposal.runtime.json';Q=B/'arc-inverse-operator-teachers-20261019/run01/queries.proposal.runtime.json';O=B/'arc-copy-pilot-plan-20261019/queries.runtime.json'
ts=json.loads(T.read_bytes());candidate_queries=json.loads(Q.read_bytes());old=json.loads(O.read_bytes());distinct=[]
for q in candidate_queries:
 if q not in distinct:distinct.append(q)
assert len(ts)==6 and len(distinct)==2 and len(old)==32
assert len({t['対象系境界'] for t in ts})==1
for t in ts:
 assert set(t['内容'])=={'要求する可視効果族','観測された作用番号候補'}
 assert type(t['内容']['要求する可視効果族'])is str
 assert type(t['内容']['観測された作用番号候補'])is int
 assert t['内容']['観測された作用番号候補'] in (5,6)
rows=[tuple(t['内容'].values()) for t in ts];prefix=[];tables={};candidate_count=adoptions=changed=0
for n in range(1,7):
 new=0;count=0
 for direction in (0,1):
  pairs=[(a,z) if direction==0 else(z,a) for a,z in rows[:n]];table={};conflicts=[]
  for a,z in pairs:
   if a in table and table[a]!=z:conflicts.append((a,z))
   table[a]=z
  assert not conflicts
  if n>=3 and len(table)>=2:
   count+=1;candidate_count+=1
   if tables.get(direction)!=table:tables[direction]=table;new+=1;adoptions+=1
 changed+=bool(new);prefix.append({'prefix':n,'candidate_count':count,'adoptions':new})
assert (candidate_count,adoptions,changed)==(8,2,1)
reverse=[]
for t in ts:
 q=dict(t);q['内容']={'観測された作用番号候補':t['内容']['観測された作用番号候補']}
 if q not in reverse:reverse.append(q)
assert len(reverse)==2
queries=distinct+reverse+old;plan=[{'method':'照会する','input':q}for q in queries]+[{'method':'処理する','input':t}for t in ts]+[{'method':'照会する','input':q}for q in queries]
assert len(plan)==78
for name,x in [('teachers.runtime.json',ts),('queries.runtime.json',queries),('proposed_plan.json',{'native_execution_authorized':False,'baseline_status':'WAIT_FOR_CLOSED_COPY_POSTSTATE','plan':plan})]:
 (R/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
result={'status':'PURE_FEASIBILITY_BASELINE_PENDING','native_calls':0,'teachers':6,'new_distinct_forward_queries':2,'reverse_diagnostic_queries':2,'prior_queries':32,'queries_each_side':36,'planned_calls':78,'candidate_events':candidate_count,'adoptions':adoptions,'changed_calls':changed,'relation':'deterministic mapping in both directions, not identity','prefix':prefix,'max_atom_json_bytes':max(len(json.dumps(v,ensure_ascii=False).encode())for t in ts for v in t['内容'].values()),'source_pins':{str(p.relative_to(B)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (T,Q,O,B/'arc-inverse-operator-review-20261019/MANIFEST.json')}}
(R/'feasibility.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2))
