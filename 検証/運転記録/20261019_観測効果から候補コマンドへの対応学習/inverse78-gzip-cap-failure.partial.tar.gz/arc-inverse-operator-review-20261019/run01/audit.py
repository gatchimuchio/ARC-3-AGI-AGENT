import pathlib,json,gzip,hashlib,collections,resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
P=pathlib.Path;R=P('arc-inverse-operator-teachers-20261019');h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert h(R/'MANIFEST.json')=='ac1f48d65c4c70da6c2233c3f0b8dfd2a3aa2238113783718bcf2831522359c6'
for f in json.loads((R/'MANIFEST.json').read_bytes())['files']:
 p=R/f['path'];assert p.stat().st_size==f['bytes'] and h(p)==f['sha256']
for f in json.loads((R/'run02/input_pins.json').read_bytes()):assert h(P(f['path']))==f['sha256']
rows=json.loads((R/'run01/all631_effect_truth.json').read_bytes());assert len(rows)==631
I=P('arc-widepaint-witness-inventory-20261019/run02')
pairs=[json.loads(l) for l in gzip.open(I/'all_action_pairs.jsonl.gz','rt')];assert len(pairs)==631
needed={(r['pair'][0],r['pair'][1]) for r in rows};endkeys={(r['pair'][0],r['pair'][2],r['endpoint_phase']) for r in rows};before={};ends={}
for line in gzip.open(I/'all_phases.jsonl.gz','rt'):
 p=json.loads(line);k=(p['source'],p['row']);k3=(*k,p['phase'])
 if k in needed:before[k]=p
 if k3 in endkeys:ends[k3]=p
stablekeys=['参照','参照矩形','対象矩形','方向','器具矩形','小器具矩形群','装置画素','大きさ','背景色','色見本']
def effect(s,a):
 if s is None or a is None:return []
 stable=all(s[k]==a[k] for k in stablekeys);o=[]
 if stable and s['対象']==a['対象'] and s['器具色']!=a['器具色'] and a['器具色'] in [p['色'] for p in s['色見本']]:o.append('可視パレット既存色への器具色変更・参照対象姿勢配置保存')
 dx,dy=s['方向'];grid=[[s['器具色'] if dx*(2*x-9)+dy*(2*y-9)>=0 else s['対象'][y][x] for x in range(10)] for y in range(10)]
 if stable and s['器具色']==a['器具色'] and s['対象']!=a['対象'] and grid==a['対象']:o.append('固定広域幾何の器具色コピーによる可視対象変更・領域外保存')
 return o
counts=collections.Counter();groups={};controls=[]
for r,p in zip(rows,pairs):
 pair=[p['before']['source'],p['before']['row'],p['after']['row']];assert r['pair']==pair
 b=before[tuple(pair[:2])];a=ends.get((pair[0],pair[2],r['endpoint_phase']))
 assert r['before_scene']==b['scene'] and r['after_scene']==(a['scene'] if a else None)
 assert r['endpoint_phase']==p['last_interpretable_old_problem_phase']
 assert r['actual_public_action']==p['actual_public_action'] and r['scope_error']==p['scope_error']
 assert r['public_reset_flag']==p['reset'] and r['public_identity_changed']==p['public_identity_changed']
 e=effect(r['before_scene'],r['after_scene']);assert e==r['observed_effect_families']
 if not e:counts['unmatched']+=1
 for v in e:
  counts[v]+=1;groups.setdefault((pair[0],v),collections.Counter())[r['observed_action_id']]+=1
  assert r['before_status']=='NOT_FINISHED' and r['scope_error'] is None and r['observed_action_id'] in r['availability_before']
  if v.startswith('固定'):assert r['paired_target_measurement']['selector']['status']=='PAIRED_VISIBLE_TARGET_ENDPOINT'
 if p['reset'] or (p['role_fixed_prior'] or {}).get('役割')=='未対応':controls.append((pair,e))
assert counts['unmatched']==443 and len(groups)==6 and len(controls)==26 and all(not e for _,e in controls)
assert all(len(v)==1 for v in groups.values())
cs=json.loads((R/'run01/cohorts.json').read_bytes())
for c in cs:
 key=(c['recording_provenance'],c['desired_observable_effect_family']);assert {str(k):v for k,v in groups[key].items()}=={k:len(v) for k,v in c['all_distinct_action_outcomes'].items()}
 assert [m['pair'] for m in c['all_members']]==[r['pair'] for r in rows if r['pair'][0]==key[0] and key[1] in r['observed_effect_families']]
print(json.dumps({'verdict':'QUALIFIED_OFFLINE_ASSOCIATION_PASS','all_rows':len(rows),'counts':dict(counts),'cohorts':len(groups),'controls':len(controls),'action_labels_used_by_effect':False,'all_input_manifest_pins':True,'native_calls':0},ensure_ascii=False,indent=2))
