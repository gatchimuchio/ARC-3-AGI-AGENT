import pathlib,json,collections,resource,hashlib,ast
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
R=pathlib.Path(__file__).resolve().parent;B=R.parents[1];P=R.parent/'run01';rows=json.loads((P/'all631_effect_truth.json').read_text());counts=collections.Counter();controls=[];scope=[]
# Independent arithmetic; no membership import or action classifier.
def effects(s,a):
 if s is None or a is None:return []
 stable=all(s[k]==a[k] for k in ['参照','参照矩形','対象矩形','方向','器具矩形','小器具矩形群','装置画素','大きさ','背景色','色見本'])
 out=[]
 if stable and s['対象']==a['対象'] and s['器具色']!=a['器具色'] and any(p['色']==a['器具色'] for p in s['色見本']):out.append('可視パレット既存色への器具色変更・参照対象姿勢配置保存')
 dx,dy=s['方向'];pred=[[s['器具色'] if dx*(2*x-9)+dy*(2*y-9)>=0 else s['対象'][y][x] for x in range(10)] for y in range(10)]
 if stable and s['器具色']==a['器具色'] and s['対象']!=a['対象'] and pred==a['対象']:out.append('固定広域幾何の器具色コピーによる可視対象変更・領域外保存')
 return out
for i,r in enumerate(rows):
 actual=effects(r['before_scene'],r['after_scene']);assert actual==r['observed_effect_families']
 counts['all_rows']+=1
 if r['public_reset_flag']:controls.append({'index':i,'pair':r['pair'],'kind':'reset','effects':actual,'all_deltas':r['all_parsed_field_deltas']})
 if (r['classifier_role_provenance_only'] or {}).get('役割')=='未対応':controls.append({'index':i,'pair':r['pair'],'kind':'unsupported click','effects':actual,'all_deltas':r['all_parsed_field_deltas'],'whole_visible_endpoint_equal':r['visible_endpoint_equal']})
 if not actual:counts['unmatched_retained']+=1
 if actual:
  prereq=r['before_status']=='NOT_FINISHED' and r['scope_error'] is None and r['observed_action_id'] in r['availability_before'] and r['before_scene'] is not None
  assert prereq
  if actual[0].startswith('固定'):assert r['paired_target_measurement']['selector']['status']=='PAIRED_VISIBLE_TARGET_ENDPOINT';counts['paired_target_matches']+=1
  scope.append({'pair':r['pair'],'before_normal_available_command_scope':prereq,'reset_flag_recorded_not_filter':r['public_reset_flag'],'identity_change_recorded_not_filter':r['public_identity_changed']})
# Explicitly demonstrate descriptor interface cannot read IDs/labels: it accepts only scenes.
assert effects.__code__.co_argcount==2
for q in json.loads((P/'queries.proposal.runtime.json').read_text()):assert set(q['内容'])=={'要求する可視効果族'}
summary={'all631_descriptor_recomputed':True,'effect_function_inputs':['before_scene','after_scene'],'action_id_classifier_progress_not_inputs':True,'counts':dict(counts),'reset_controls':sum(c['kind']=='reset' for c in controls),'unsupported_controls':sum(c['kind']=='unsupported click' for c in controls),'controls_matching_effect':sum(bool(c['effects']) for c in controls),'all188_before_scope_pass':len(scope)==188,'native_calls':0}
for n,o in [('summary.json',summary),('all26_reset_unsupported_controls.json',controls),('all188_pre_action_scope.json',scope)]: (R/n).write_text(json.dumps(o,ensure_ascii=False,indent=2))
inputs=[B/'arc-widepaint-witness-inventory-20261019/run02/all_phases.jsonl.gz',B/'arc-widepaint-witness-inventory-20261019/run02/all_action_pairs.jsonl.gz',B/'arc-goal6-action-bridge-20261019/origins/関係.py',B/'arc-goal6-action-bridge-20261019/origins/知覚.py',B/'arc-widepaint-operation-teachers-20261019/target_observer_v2/run02/all115_endpoint_results.json',B/'arc-widepaint-operation-teachers-20261019/copy6_qualified_v2/MANIFEST.json']
(R/'input_pins.json').write_text(json.dumps([{'path':str(p.relative_to(B)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in inputs],ensure_ascii=False,indent=2));print(json.dumps(summary,ensure_ascii=False,indent=2))
