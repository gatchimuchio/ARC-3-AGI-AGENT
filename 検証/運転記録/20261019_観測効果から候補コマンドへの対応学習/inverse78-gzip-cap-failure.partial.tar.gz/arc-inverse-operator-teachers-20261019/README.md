# Inverse observable-effect → supported action-number proposal

## Finding
Across all631 public action contexts, effect descriptors computed without ActionID, classifier role or progress identify:

-98 palette/tool-color-change effects, all with observed Action6 (recording supports29,17,52).
-90 informative wide-geometry target-change effects, all with observed Action5 (supports18,18,54).
-443 other, unchanged, unknown or rival cases, all retained.

Grouping by (recording provenance, observed effect descriptor) yields six cohorts with no conflicting ActionID outcomes. The six exact proposed teacher payloads total1954 UTF-8 bytes; matched queries total1726 bytes. Source and recording identities stay outside runtime content. No native calls, execution admission or existing COPY6 changes occurred.

This is an inverse association to a supported candidate command, not a necessary/unique action or a proof of fresh-state sufficiency. It does not authorize execution. Neither perfect historical association nor HDS reproduction of it can substitute for current applicability, target authority, observation-model scope and response gates.

## Effect definitions independent of ActionID
Both effects require observed reference pixels/rectangle, target rectangle, direction, main tool rectangle, optional-handle rectangles, relative device pixels, target size, background and palette roles to be preserved at the measured endpoint.

Palette effect additionally requires: tool color actually changes; the resulting tool color equals one of the BEFORE visible palette values; target pixels remain unchanged. Its descriptor never consults click coordinates, classifier role, action number, score or public success. This admits98 informative observations. Three already-equal palette clicks remain in the full inventory but cannot identify a color-change operation and therefore do not instantiate this descriptor.

Wide-target effect additionally requires: target pixels actually change; before and endpoint tool colors agree; the entire measured endpoint grid equals the BEFORE wide-geometry hypothesis (BEFORE tool color inside, BEFORE target color outside). This uses the existing fixed geometric formula, not an after-fitted mask. Its descriptor never consults action number or classifier role. The90 matches have independently verified paired visible-target endpoints. Twelve unchanged wide-paint outcomes remain in the inventory but cannot identify the target-change operation.

The descriptor selects an observed effect, not a favorable progress label. Matching or failing the effect definition is not an applicability exclusion for the corpus: every pair and every outcome is stored. No game/level/version/answer condition selects a solution.

## Complete controls and negative evidence
All3 reset pairs and23 unsupported clicks are evaluated by the same descriptor before their command labels are inspected. None matches either effect. No reset was removed from the primary matching test, and no reset flag or after-state label is used as an exclusion to obtain the six cohorts. `run02/all26_reset_unsupported_controls.json` retains their exact parsed deltas and references. Unsupported controls can change other visible pixels; they are not called universal no-ops.

All631 rows are stored in `run01/all631_effect_truth.json`, including complete before/after scenes when measured, all parsed-field deltas, whole-visible-endpoint equality, actual actions, phase/binding records, status, availability, progress, reset/identity flags and hidden unknown. All443 nonmatching contexts remain available for counterexample/rival review. No nonmatching action is taught as an anti-action label: absence of this observed effect does not prove the action cannot produce it under other prerequisites.

All188 matching rows have a known before scene, running before status, valid public action argument scope and an available observed command. These are checked after descriptor derivation as independently visible BEFORE prerequisites. They were not used to drop conflicting outcomes. Matching reset and identity-change flags are recorded rather than silently treated as filtering authority.

## Runtime meaning of the proposed query
Input `要求する可視効果族` is a desired program/goal feature, selected from a current goal-relative condition. It is not a claim that an unexecuted future effect has already occurred. Output `観測された作用番号候補` is a supported command-family candidate. The proposed namespace explicitly states observed effect-to-candidate-action association.

For palette preparation, a planner could request the palette-color-change family only after identifying the needed color as a currently visible palette role distinct from the current tool color. An HDS Action6 candidate is still incomplete: all legal coordinate candidates must remain, and current unique target/color roles, exact witnessed local offset, argument bounds and availability must bind a specific candidate. The separate qualified COPY relation predicts the corresponding tool-color result. The action-number association does not choose a coordinate or permit assuming an entire rectangle is equivalent.

For a proposed wide paint, the current frame must have independently known tool color/direction and target/reference roles, supported device grammar, the applicable wide geometry model, at least one predicted target change, and preservation/repair reasoning tied to the current goal. An HDS Action5 candidate must remain available with exact empty arguments. Learned goal6 supports only its explicit wide context; global/small goal relation remains HOLD. Target change is not itself progress or action permission.

No planner, action dispatcher, coordinate selector or external permission bit is implemented here. The proposal can replace an unsupported guessed ActionID with a learned candidate association only after separate native admission and exact structural candidate binding. It cannot turn that association into fresh causal certainty or authority.

## Measurement contract and offline-only scope
Target endpoints refer to the new role-specific paired observation: contiguous old-reference prefix, terminal two independently measured same-before target rectangles, equal visible target grids, no old-reference reentry, with unknown tool fields preserved. No predicted output is used to select the endpoint. Full native/SDK code and game internals are not accessed.

IMPORTANT: the existing `checked_endpoint` derivative is an offline function for an already verified inventory pair, not a runtime-safe packet wrapper. Its current `.get` checks alone do not reject missing scope flags or independently authenticate identities. Required caller schema includes `scope_error` (explicit null or error), `reset` (strict bool), `public_identity_changed` (strict bool), explicit before/after statuses, availability lists and actual public action; the pinned inventory producer derives these from complete raw metadata with stable identity/reset checks. A caller must verify those fields and the exact pair/source joins before using the result. Missing flags, absent/nonempty identity verification, or unverified packet provenance are HOLD outside this audited corpus. Independent reviewer probes showing missing flags pass the bare helper are preserved externally and remain a live-wrapper blocker. This proposal consumes only the fully pinned verified corpus; it makes no live-wrapper approval claim.

## Validation, pins and limits
run01 preserves exact derivation source, stdout/stderr and exit0. run02 independently recomputes all631 descriptors from only `(before_scene,after_scene)` using equivalent explicit geometry arithmetic and verifies all188 before-scope conditions. It confirms all90 target-effect pairs have paired target measurements. All6 input-source pins are recorded. The COPY6 manifest is pinned to establish its unchanged identity, not to grant execution permission.

All data are historical public records; the new grouping is a new analysis, not independent evidence collection. Historical learned COPY/MASK/TURN state closure remains unresolved. Any future native pilot requires semantic review, support-dependence accounting, size/growth proof and explicit execution authority. Address-space limit512MiB; disk budget96MiB. No original authorities, parser, state, core or Git objects were modified.
