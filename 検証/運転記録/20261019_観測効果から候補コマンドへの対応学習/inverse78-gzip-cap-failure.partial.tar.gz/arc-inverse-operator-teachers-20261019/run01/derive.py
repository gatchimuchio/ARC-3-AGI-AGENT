import resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
import pathlib,json,gzip,collections,hashlib,sys
R=pathlib.Path(__file__).resolve().parent;B=R.parents[1];I=B/'arc-widepaint-witness-inventory-20261019/run02';sys.path.insert(0,str(I));from bridge import P,sig
phases={};last={}
for line in gzip.open(I/'all_phases.jsonl.gz','rt'):
 p=json.loads(line);phases[(p['source'],p['row'],p['phase'])]=p;last[(p['source'],p['row'])]=p
endpoint_contracts={tuple(p['pair']):p for p in json.loads((B/'arc-widepaint-operation-teachers-20261019/target_observer_v2/run02/all115_endpoint_results.json').read_text())}
allrows=[];cohorts={};counts=collections.Counter()
for line in gzip.open(I/'all_action_pairs.jsonl.gz','rt'):
 p=json.loads(line);pair=[p['before']['source'],p['before']['row'],p['after']['row']];b=last[tuple(pair[:2])];ep=phases.get((pair[0],pair[2],p['last_interpretable_old_problem_phase']));s=b['scene'];a=ep['scene'] if ep else None
 # Describe effects without consulting actual ActionID, classifier role or progress.
 effects=[];checks={};deltas={};unknown=[]
 if s is None or a is None:unknown.append('before or old-bound endpoint full role observation unavailable')
 else:
  deltas={k:{'before':s[k],'after':a[k]} for k in s if s[k]!=a[k]}
  stable_keys=['参照','参照矩形','対象矩形','方向','器具矩形','小器具矩形群','装置画素','大きさ','背景色','色見本']
  stable=all(s[k]==a[k] for k in stable_keys)
  palette=s['器具色']!=a['器具色'] and a['器具色'] in {v['色'] for v in s['色見本']} and s['対象']==a['対象'] and stable
  pred=[[s['器具色'] if P['membership'](s['方向'],x,y,10,'広域塗布') else s['対象'][y][x] for x in range(10)] for y in range(10)]
  wide=s['対象']!=a['対象'] and pred==a['対象'] and stable and s['器具色']==a['器具色']
  checks={'structural_roles_preserved':stable,'palette_tool_copy_effect':palette,'wide_geometry_target_value_effect':wide,'wide_predicted_target':pred,'target_changed':s['対象']!=a['対象'],'tool_changed':s['器具色']!=a['器具色'],'stable_role_keys':stable_keys}
  if palette:effects.append('可視パレット既存色への器具色変更・参照対象姿勢配置保存')
  if wide:effects.append('固定広域幾何の器具色コピーによる可視対象変更・領域外保存')
 # Label extraction happens only after independent descriptor calculation.
 action=p['actual_public_action'];label=action.get('id') if isinstance(action,dict) else None
 row={'pair':pair,'before_ref':p['before'],'after_ref':p['after'],'before_frame_sha256':b['frame_sha256'],'endpoint_frame_sha256':ep['frame_sha256'] if ep else None,'endpoint_phase':ep['phase'] if ep else None,'observed_effect_families':effects,'descriptor_checks':checks,'all_parsed_field_deltas':deltas,'unknowns':unknown,'actual_public_action':action,'observed_action_id':label,'classifier_role_provenance_only':p['role_fixed_prior'],'before_status':p['before_status'],'after_status':p['after_status'],'availability_before':p['availability_before'],'availability_after':p['availability_after'],'scope_error':p['scope_error'],'public_reset_flag':p['reset'],'public_identity_changed':p['public_identity_changed'],'public_progress':p['score_increased'],'visible_endpoint_equal':p['visible_endpoint_equal'],'all_phase_checks':[{k:v for k,v in z.items() if k!='mask_all100_attributions'} for z in p['all_phase_checks']],'paired_target_measurement':endpoint_contracts.get(tuple(pair)),'before_scene':s,'after_scene':a,'hidden_state':'unknown','necessary_unique_or_fresh_sufficient':False,'action_permission':False}
 allrows.append(row);counts['all_pairs']+=1;counts['descriptor_match_count:'+str(len(effects))]+=1
 for effect in effects:
  key=sig([pair[0],effect]);g=cohorts.setdefault(key,{'recording_provenance':pair[0],'desired_observable_effect_family':effect,'all_members':[],'all_distinct_action_outcomes':{}});idx=len(g['all_members']);g['all_members'].append({'pair':pair,'all631_index':len(allrows)-1});g['all_distinct_action_outcomes'].setdefault(str(label),[]).append(idx);counts['effect:'+effect]+=1
cs=list(cohorts.values());teachers=[];queries=[]
for c in cs:
 c['conflicting_actions']=len(c['all_distinct_action_outcomes'])>1;c['proposed_query']={'内容':{'要求する可視効果族':c['desired_observable_effect_family']},'対象系境界':'公開役割拘束・観測された効果族から支持された作用番号候補','主体':None,'対象':None,'目的':None,'文脈':{}};queries.append(c['proposed_query'])
 for action,inds in c['all_distinct_action_outcomes'].items():teachers.append({**c['proposed_query'],'内容':{**c['proposed_query']['内容'],'観測された作用番号候補':int(action)}})
summary={'counts':dict(counts),'cohorts':len(cs),'conflicting_cohorts':sum(c['conflicting_actions'] for c in cs),'all_outcomes':{c['desired_observable_effect_family']+':recording'+str(c['recording_provenance']):{a:len(ii) for a,ii in c['all_distinct_action_outcomes'].items()} for c in cs},'teacher_bytes':len(sig(teachers).encode()),'query_bytes':len(sig(queries).encode()),'native_calls':0}
for n,o in [('all631_effect_truth.json',allrows),('cohorts.json',cs),('summary.json',summary)]: (R/n).write_text(json.dumps(o,ensure_ascii=False,indent=2))
for n,o in [('teachers.proposal.runtime.json',teachers),('queries.proposal.runtime.json',queries)]: (R/n).write_text(sig(o))
print(json.dumps(summary,ensure_ascii=False,indent=2))
