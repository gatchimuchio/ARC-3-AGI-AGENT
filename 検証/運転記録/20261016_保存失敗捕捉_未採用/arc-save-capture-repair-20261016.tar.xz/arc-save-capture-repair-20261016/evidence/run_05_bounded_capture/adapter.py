"""NOT_ADOPTED: own-connection exception capture, with no native imports.

The caller supplies exact, pinned, AST-extracted save/standard function objects.
Successful calls delegate unchanged. On failure only the exact matching own
method frame is inspected; no unrelated, SDK, native or evaluator locals are read.
No runtime binding, release, recovery, retry or subsequent operation is installed.
"""
import hashlib
import json
import os
from pathlib import Path
import stat


def exception_descriptor(error):
    return {"type": type(error).__name__, "message": str(error)}


def pending_descriptor(pending):
    # Original objects remain held by Capture; never invoke a native codec here.
    if pending is None:
        return None
    if type(pending) is not dict:
        return {"descriptor_type": type(pending).__name__}
    return {k: pending[k] for k in ("name", "standard") if k in pending}


def file_observation(path, max_bytes=32 * 1048576):
    """Read existing owned output only; never rewrite/remove partial bytes.

    No-follow final path and regular-file identity check; this is not a complete
    race-free directory confinement guarantee. Only the pinned own frame's p is
    eligible. Failures of this observation are retained without hiding primary.
    """
    p = Path(path)
    fd = os.open(p, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode):
            raise ValueError("capture output must be a regular file")
        if before.st_size > max_bytes:
            raise MemoryError("capture observation byte bound")
        digest = hashlib.sha256()
        count = 0
        while True:
            chunk = os.read(fd, 65536)
            if not chunk:
                break
            count += len(chunk)
            if count > max_bytes:
                raise MemoryError("capture observation grew past byte bound")
            digest.update(chunk)
        after = os.fstat(fd)
        fields = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
        if fields(before) != fields(after) or count != before.st_size:
            raise ValueError("capture output changed during read")
        return {"path": str(p), "bytes": count, "sha256": digest.hexdigest()}
    finally:
        os.close(fd)


class Capture:
    """Retained exact references, not a second quota/accounting ledger."""
    def __init__(self, operation, attempted, previous_pending, pending, error):
        self.operation = operation
        self.attempted = attempted
        self.previous_pending = previous_pending
        self.pending = pending
        self.error = error
        self.method_primary = None
        self.completed_result = None
        self.existing_file = None
        self.frame_matched = False
        self.secondary_errors = []
        self.receipt = None
        self.timer_stopped = False
        self.initial_timer_stopped = False
        self.capture_budget_seconds = None

    def metadata(self):
        completed = self.completed_result
        if self.operation == "standard" and completed is not None:
            completed = completed[0]  # Never serialize the complete state value.
        return {
            "schema": "outside-hds-save-failure-capture-not-adopted-v1",
            "status": "failed_held", "adopted": False,
            "operation": self.operation,
            "attempted_descriptor": pending_descriptor(self.attempted),
            "previous_pending_descriptor": pending_descriptor(self.previous_pending),
            "pending_at_failure_descriptor": pending_descriptor(self.pending),
            "exception": exception_descriptor(self.error),
            "method_primary": None if self.method_primary is None else exception_descriptor(self.method_primary),
            "matched_own_method_frame": self.frame_matched,
            "completed_result": completed,
            "existing_output": self.existing_file,
            "save_compute_timer_stopped_before_capture": self.initial_timer_stopped,
            "timer_stopped_at_metadata_observation": self.timer_stopped,
            "capture_budget_seconds_at_entry": self.capture_budget_seconds,
            "timer_note": "Diagnostic is written during the existing failure budget; final stop is observed by caller after unwind.",
            "secondary_errors": [exception_descriptor(e) for e in self.secondary_errors],
            "payload_objects": "Exact objects held in memory; existing output bytes left in place. No native codec called.",
        }


class SaveCapture:
    """Caller-side prototype only. Does not monkey-patch owner or any module."""
    def __init__(self, owner, save_function, standard_function, failure_sink):
        # These exact function identities must come from a verified own-source
        # allowlist. This constructor is not a launcher or an authority check.
        if owner.save.__func__ is not save_function or owner.standard.__func__ is not standard_function:
            raise ValueError("exact own-method binding required")
        self.owner = owner
        self.functions = {"save": save_function, "standard": standard_function}
        self.failure_sink = failure_sink
        self.captures = []
        self.capture_errors = []

    def save(self, name, value, category="evidence", codec=True):
        return self._invoke("save", {"name": name, "value": value}, (name, value),
                            {"category": category, "codec": codec})

    def standard(self, label):
        return self._invoke("standard", {"name": label}, (label,), {})

    def _invoke(self, operation, attempted, args, kwargs):
        owner = self.owner
        function = self.functions[operation]
        previous_pending = owner.pending
        try:
            return function(owner, *args, **kwargs)
        except BaseException as error:
            capture = None
            try:
                owner.clock.stop()
                capture = Capture(operation, attempted, previous_pending, owner.pending, error)
                self.captures.append(capture)
                capture.timer_stopped = True
                capture.initial_timer_stopped = True
                if not any(e is error for e in owner.exceptions):
                    owner.exceptions.append(error)
                known_path = None
                tb = error.__traceback__
                while tb is not None:
                    frame = tb.tb_frame
                    if frame.f_code is function.__code__:
                        local = frame.f_locals
                        if local.get("self") is owner:
                            capture.frame_matched = True
                            capture.method_primary = local.get("primary")
                            if owner.pending is None and capture.method_primary is None:
                                if operation == "save" and "result" in local:
                                    capture.completed_result = local["result"]
                                elif operation == "standard" and "r" in local and "value" in local:
                                    capture.completed_result = (local["r"], local["value"])
                            if "p" in local:
                                known_path = local["p"]
                            break
                    tb = tb.tb_next
                del tb, frame
                # Use the recovered connection's EXISTING aggregate failure120
                # budget. Never reset, extend, or borrow from compute/save time.
                capture.capture_budget_seconds = owner.clock.remaining["failure"]
                owner.clock.enter("failure")
                capture.timer_stopped = False
                if known_path is not None:
                    try:
                        capture.existing_file = file_observation(known_path)
                    except BaseException as secondary:
                        capture.secondary_errors.append(secondary)
                        if isinstance(secondary, TimeoutError):
                            raise
                # Re-enter the SAME aggregate budget, accounting elapsed time.
                # An alarm already consumed by observation must not free the sink
                # from the remaining deadline or grant a fresh120 seconds.
                owner.clock.enter("failure")
                # Existing Run.pending is never replaced/cleared. The supplied
                # exclusive sink enforces original failure byte quotas as well.
                raw = json.dumps(capture.metadata(), ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode()
                capture.receipt = self.failure_sink(raw)
            except BaseException as secondary:
                self._secondary(capture, secondary)
            finally:
                try:
                    owner.clock.stop()
                    if capture is not None:
                        capture.timer_stopped = True
                except BaseException as secondary:
                    self._secondary(capture, secondary)
            raise

    def _secondary(self, capture, error):
        # Best effort under allocation failure; preserving the original raised
        # exception takes precedence over failure of the capture bookkeeping.
        try:
            (capture.secondary_errors if capture is not None else self.capture_errors).append(error)
        except BaseException:
            pass
