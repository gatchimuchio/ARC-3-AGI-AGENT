#!/usr/bin/env python3
"""Stdlib inert fixtures only. No native/SDK module or live wrapper execution."""
import argparse
import ast
import copy
from contextlib import ExitStack
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import resource
import shutil
import sys
import traceback
import types
import unittest
from unittest.mock import patch

BASE = Path(__file__).resolve().parents[1]
WORK = BASE.parent
FROZEN = BASE / "inputs/baseline"
RECOVERED = BASE / "inputs/diagnostic"
MIB = 1048576


def load_own(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


# Only stdlib fixture/test scaffolding and the new adapter are module-loaded.
# Frozen production modules are never imported; their allowlisted AST is used.
fixture = load_own("frozen_test_fixtures", FROZEN / "tests/test_pure_save_boundaries.py")
fixture.OUT = BASE / "evidence" / "fixtures"
adapter = load_own("outside_capture", BASE / "source/save_capture_not_adopted.py")


def precheck():
    entries = list(BASE.rglob("*"))
    if BASE.is_symlink() or any(p.is_symlink() for p in entries):
        raise ValueError("owned work scope symlink")
    size = sum(p.stat().st_size for p in entries if p.is_file())
    if size > 16 * MIB or shutil.disk_usage(BASE).free < 1024 * MIB:
        raise MemoryError("work16MiB/disk1GiB bound")
    return size


def compile_historical(namespace):
    """Apply only the exact archived Storage transformer/loop to base methods."""
    path = RECOVERED / "suffix_harness_disabled_v1.py"
    data = path.read_bytes()
    if hashlib.sha256(data).hexdigest() != "73f3e70d8cc453985c531b87d5562fb8f4510c6c8952a0cf91de90e587c92163":
        raise ValueError("suffix source pin")
    tree = ast.parse(data)
    base = ast.parse((FROZEN / "source/column_work_harness_v3.py").read_bytes())
    old = next(n for n in base.body if isinstance(n, ast.ClassDef) and n.name == "Run")
    body = [copy.deepcopy(n) for n in old.body if isinstance(n, ast.FunctionDef) and n.name in {"encoded", "save", "standard"}]
    storage = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "Storage")
    loop = next(n for n in tree.body if isinstance(n, ast.For) and isinstance(n.target, ast.Name) and n.target.id == "n")
    transform = {"ast": ast, "body": body}
    exec(compile(ast.fix_missing_locations(ast.Module(body=[storage, loop], type_ignores=[])), str(path), "exec"), transform)
    historical_run = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "Run")
    packet = next(n for n in historical_run.body if isinstance(n, ast.FunctionDef) and n.name == "check_packet_budget")
    body.append(copy.deepcopy(packet))
    cls = ast.ClassDef(name="Run", bases=[], keywords=[], body=body, decorator_list=[])
    guard = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "guard")
    exec(compile(ast.fix_missing_locations(ast.Module(body=[cls, guard], type_ignores=[])), str(path), "exec"), namespace)
    return {n.name: hashlib.sha256(ast.dump(n, include_attributes=False).encode()).hexdigest() for n in body}


class CaptureTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        fixture.PureSaveTests.setUpClass()

    def setUp(self):
        self.fx = fixture.PureSaveTests("test_resource_success_and_duplicate")
        self.fx.setUp()
        self.addCleanup(self.fx.doCleanups)
        self.fx.r["ROOT"] = self.fx.h["ROOT"]
        (self.fx.h["ROOT"] / "evidence").mkdir(exist_ok=True)
        self.fx.h.update(scope=types.SimpleNamespace(guard=self.fx.r["guard"]), OWNER=None)
        self.digests = compile_historical(self.fx.h)
        self.run = self.fx.runner()
        self.run.clock.remaining = {"compute": 7200., "save": 3600., "failure": 120.}
        self.run.start_usage = self.fx.r["guard"]()["used"]
        self.fx.h["OWNER"] = self.run
        self.events = []
        self.sink_calls = 0
        self.sink_names = []
        self.failname = "capture-0001.json"
        self.notes = {}
        self.baseguard = self.fx.h["guard"]
        def guard(category=None, extra=0):
            self.events.append(["guard", category, extra])
            return self.baseguard(category, extra)
        self.fx.h["guard"] = guard
        self.boundary = adapter.SaveCapture(self.run, self.run.save.__func__, self.run.standard.__func__, self.sink)

    def sink(self, raw):
        self.sink_calls += 1
        self.sink_names.append(self.failname)
        # Keep the existing incremental failure4MiB AND scope limits. The exact
        # resource writer then retains its own original pre/post full guards.
        self.fx.h["guard"]("failure", len(raw))
        return self.fx.r["save"]("failure", self.failname, raw)

    def path(self, name="one", standard=False):
        suffix = ".standard.json" if standard else ".json.xz"
        return self.fx.h["ROOT"] / "evidence" / self.run.gate["nonce"] / (name + suffix)

    def record(self, capture):
        self.notes.update(capture=capture.metadata(), diagnostic_receipt=capture.receipt,
                          events=self.events, signal_timer=self.fx.signals.timer,
                          exception_count=len(self.run.exceptions))
        if capture.existing_file is not None:
            p = Path(capture.existing_file["path"])
            if p.stat().st_size <= 4096:
                self.notes["existing_bytes_hex"] = p.read_bytes().hex()
        if capture.receipt is not None:
            self.notes["diagnostic_json"] = json.loads(Path(capture.receipt["path"]).read_bytes())

    def traced(self, callback):
        order = []
        rglob, opened, sync = Path.rglob, Path.open, os.fsync
        enter, stop = self.run.clock.enter, self.run.clock.stop
        def scanned(path, pattern):
            order.append(["full_scan", path.name, pattern])
            return rglob(path, pattern)
        def open_file(path, mode="r", *args, **kwargs):
            order.append(["open", mode])
            return opened(path, mode, *args, **kwargs)
        def fsync(fd):
            order.append(["fsync"])
            return sync(fd)
        def entering(mode):
            order.append(["clock_enter", mode])
            return enter(mode)
        def stopping():
            order.append(["clock_stop"])
            return stop()
        with ExitStack() as stack:
            for target, name, replacement in [(Path, "rglob", scanned), (Path, "open", open_file),
                    (os, "fsync", fsync), (self.run.clock, "enter", entering), (self.run.clock, "stop", stopping)]:
                stack.enter_context(patch.object(target, name, replacement))
            result = callback()
        return result, order

    def assert_failed(self, callback, error_type):
        try:
            callback()
        except error_type as error:
            capture = self.boundary.captures[-1]
            self.assertIs(capture.error, error)
            self.assertTrue(capture.frame_matched)
            self.assertTrue(capture.timer_stopped)
            self.assertIsNone(self.run.clock.mode)
            self.assertEqual(self.fx.signals.timer, 0)
            self.assertEqual(sum(e is error for e in self.run.exceptions), 1)
            self.assertIsNotNone(capture.receipt)
            self.record(capture)
            return capture
        self.fail("expected original exception")

    def test_normal_save_bytes_hash_order_full_scans_unchanged(self):
        value = {"状態": "断定保留", "候補": [False, True, None], "先": 1, "後": 2}
        previous, previous_order = self.traced(lambda: self.run.save("previous", value, codec=False))
        before_events = list(self.events)
        self.events.clear()
        current, current_order = self.traced(lambda: self.boundary.save("current", value, codec=False))
        self.assertEqual(previous_order, current_order)
        self.assertEqual([e[1] for e in current_order if e[0] == "full_scan"], ["source", "evidence", "failure"])
        self.assertEqual(before_events, self.events)
        self.assertEqual(len(self.events), 1)
        self.assertEqual(Path(previous["file"]["path"]).read_bytes(), Path(current["file"]["path"]).read_bytes())
        self.assertEqual(previous["file"]["sha256"], current["file"]["sha256"])
        self.assertEqual(previous["rawsha256"], current["rawsha256"])
        self.assertEqual(self.run.clock.mode, "compute")
        self.assertEqual(self.sink_calls, 0)
        self.assertEqual(self.boundary.captures, [])
        self.assertEqual(value["状態"], "断定保留")
        self.notes.update(previous=previous, current=current, events=self.events,
                          previous_order=previous_order, current_order=current_order, inherited_save_ast=self.digests)

    def test_normal_standard_bytes_hash_order_full_scans_unchanged(self):
        (a, av), before_order = self.traced(lambda: self.run.standard("previous"))
        events = list(self.events)
        self.events.clear()
        (b, bv), after_order = self.traced(lambda: self.boundary.standard("current"))
        self.assertEqual(before_order, after_order)
        self.assertEqual([e[1] for e in after_order if e[0] == "full_scan"], ["source", "evidence", "failure"])
        self.assertEqual(events, self.events)
        self.assertEqual(len(events), 1)
        self.assertEqual(Path(a["path"]).read_bytes(), Path(b["path"]).read_bytes())
        self.assertEqual(a["sha256"], b["sha256"])
        self.assertTrue(self.fx.h["eq"](av, bv))
        self.assertEqual(self.sink_calls, 0)
        self.notes.update(previous=a, current=b, events=events, previous_order=before_order, current_order=after_order)

    def test_pretry_save_deadline_preserves_new_and_old_pending(self):
        old = {"name": "earlier", "value": {"keep": True}}
        value = {"状態": "断定保留", "candidate": False}
        self.run.pending = old
        self.run.clock.remaining["save"] = 0
        c = self.assert_failed(lambda: self.boundary.save("one", value), TimeoutError)
        self.assertIs(c.previous_pending, old)
        self.assertIs(c.pending, self.run.pending)
        self.assertIs(c.pending["value"], value)
        self.assertIsNone(c.completed_result)
        self.assertFalse(self.path().exists())

    def test_pretry_standard_deadline_preserves_old_pending_and_label(self):
        old = {"name": "earlier", "value": {"keep": True}}
        self.run.pending = old
        self.run.clock.remaining["save"] = 0
        c = self.assert_failed(lambda: self.boundary.standard("one"), TimeoutError)
        self.assertIs(c.pending, old)
        self.assertIs(c.previous_pending, old)
        self.assertEqual(c.attempted, {"name": "one"})
        self.assertFalse(self.path(standard=True).exists())

    def test_pretry_standard_mkdir_stops_timer(self):
        old = {"name": "earlier", "value": 13}
        self.run.pending = old
        original = Path.mkdir
        def fail(path, *args, **kwargs):
            if path == self.path(standard=True).parent:
                raise OSError("injected pretry mkdir failure")
            return original(path, *args, **kwargs)
        with patch.object(Path, "mkdir", fail):
            c = self.assert_failed(lambda: self.boundary.standard("one"), OSError)
        self.assertIs(c.pending, old)
        self.assertIsNone(c.completed_result)
        self.assertFalse(self.path(standard=True).exists())

    def test_postcommit_save_reentry_retains_completed_fileref(self):
        value = {"状態": "断定保留", "answer": None}
        self.run.clock.remaining["compute"] = 0
        c = self.assert_failed(lambda: self.boundary.save("one", value), TimeoutError)
        self.assertEqual(c.completed_result["file"], c.existing_file)
        self.assertIs(c.attempted["value"], value)
        self.assertIsNone(self.run.pending)
        self.assertGreater(self.run.trace_bytes, 0)

    def test_postcommit_standard_reentry_retains_completed_fileref(self):
        self.run.clock.remaining["compute"] = 0
        c = self.assert_failed(lambda: self.boundary.standard("one"), TimeoutError)
        self.assertEqual(c.completed_result[0], c.existing_file)
        self.assertIs(c.completed_result[0], self.run.state_refs[-1])
        self.assertIsNone(self.run.pending)

    def test_partial_short_write_preserved_and_primary_identity(self):
        with self.fx.short_writes(self.path()):
            c = self.assert_failed(lambda: self.boundary.save("one", {"x": 7}), OSError)
        self.assertIs(c.method_primary, c.error)
        self.assertIs(c.pending, self.run.pending)
        self.assertIsNone(c.completed_result)
        self.assertGreater(c.existing_file["bytes"], 0)
        self.assertEqual(hashlib.sha256(self.path().read_bytes()).hexdigest(), c.existing_file["sha256"])

    def test_secondary_capture_name_collision_never_overwrites(self):
        target = self.fx.h["ROOT"] / "failure" / self.failname
        before = b"earlier failure evidence; must remain exact"
        target.write_bytes(before)
        self.run.clock.remaining["save"] = 0
        with self.assertRaises(TimeoutError) as caught:
            self.boundary.save("one", {"x": 1})
        c = self.boundary.captures[-1]
        self.assertIs(c.error, caught.exception)
        self.assertIsNone(c.receipt)
        self.assertTrue(any(isinstance(e, FileExistsError) for e in c.secondary_errors))
        self.assertEqual(target.read_bytes(), before)
        self.record(c)
        self.notes["earlier_evidence_hex"] = before.hex()

    def test_earlier_failure_captures_are_not_overwritten(self):
        self.run.clock.remaining["save"] = 0
        a = self.assert_failed(lambda: self.boundary.save("first", {"n": 1}), TimeoutError)
        first = Path(a.receipt["path"]).read_bytes()
        self.failname = "capture-0002.json"
        b = self.assert_failed(lambda: self.boundary.save("second", {"n": 2}), TimeoutError)
        self.assertEqual(len(self.boundary.captures), 2)
        self.assertIsNot(a, b)
        self.assertEqual(Path(a.receipt["path"]).read_bytes(), first)
        self.assertEqual(a.pending["name"], "first")
        self.assertEqual(b.pending["name"], "second")

    def test_same_hold_control_after_failure_no_followon_operation(self):
        actions = []
        self.run.clock.remaining["save"] = 0
        try:
            self.boundary.save("one", {"状態": "断定保留"})
            actions.append("forbidden-follow-on")
        except TimeoutError:
            state = "failed_held"
        self.assertEqual(actions, [])
        self.assertEqual(state, "failed_held")
        self.record(self.boundary.captures[-1])

    def test_unrelated_inner_frame_result_is_never_adopted(self):
        foreign_result = {"file": {"path": "UNRELATED_SECRET", "bytes": 999, "sha256": "fake"}}
        def unrelated(value):
            result = foreign_result
            r = foreign_result
            p = Path("UNRELATED_SECRET")
            raise LookupError("unrelated fixture fault")
        self.run.encoded = unrelated
        c = self.assert_failed(lambda: self.boundary.save("one", {}), LookupError)
        self.assertIsNone(c.completed_result)
        self.assertIsNone(c.existing_file)
        self.assertNotIn("UNRELATED_SECRET", json.dumps(c.metadata()))

    def test_binding_identity_rejects_unrelated_function(self):
        def save(*args, **kwargs):
            raise AssertionError("must never execute")
        with self.assertRaisesRegex(ValueError, "exact own-method"):
            adapter.SaveCapture(self.run, save, self.run.standard.__func__, self.sink)

    def test_original_full_guard_detects_external_add_resize_delete(self):
        path = self.fx.h["ROOT"] / "evidence" / "external"
        sizes = []
        for data in [b"a", b"abcd", None]:
            if data is None:
                path.unlink()
            else:
                path.write_bytes(data)
            sizes.append(self.fx.h["guard"]()["used"]["evidence"])
        self.assertEqual(sizes, [1, 4, 0])
        self.notes.update(full_scan_sizes=sizes)

    def test_failure_sink_cannot_bypass_original_incremental_quota(self):
        self.run.start_usage["failure"] = -4 * MIB
        self.run.clock.remaining["save"] = 0
        with self.assertRaises(TimeoutError) as caught:
            self.boundary.save("one", {})
        c = self.boundary.captures[-1]
        self.assertIs(c.error, caught.exception)
        self.assertIsNone(c.receipt)
        self.assertTrue(any(isinstance(e, MemoryError) for e in c.secondary_errors))
        self.assertFalse((self.fx.h["ROOT"] / "failure" / self.failname).exists())
        self.record(c)

    def test_fifo_duplicate_output_observation_does_not_block(self):
        path = self.path()
        path.parent.mkdir(parents=True)
        os.mkfifo(path)
        c = self.assert_failed(lambda: self.boundary.save("one", {}), FileExistsError)
        self.assertIsNone(c.existing_file)
        self.assertTrue(any("regular file" in str(e) for e in c.secondary_errors))
        path.unlink()  # Owned FIFO fixture only; no evidence bytes existed.

    def test_oversized_observation_is_bounded_without_removing_bytes(self):
        path = self.path()
        path.parent.mkdir(parents=True)
        path.write_bytes(b"existing")
        with self.fx.fake_sizes({path: 33 * MIB}):
            with self.assertRaises(MemoryError):
                # Test the descriptor limit directly with bounded fstat injection.
                fd_stat = os.fstat
                def synthetic(fd):
                    original = fd_stat(fd)
                    values = list(original); values[6] = 33 * MIB
                    return os.stat_result(values)
                with patch.object(os, "fstat", synthetic):
                    adapter.file_observation(path)
        self.assertEqual(path.read_bytes(), b"existing")

    def test_capture_allocation_failure_preserves_original_and_stops_timer(self):
        primary = OSError("primary mkdir")
        original = Path.mkdir
        def mkdir(path, *args, **kwargs):
            if path == self.path(standard=True).parent:
                raise primary
            return original(path, *args, **kwargs)
        with patch.object(Path, "mkdir", mkdir), patch.object(adapter, "Capture", side_effect=MemoryError("capture allocation")):
            with self.assertRaises(OSError) as caught:
                self.boundary.standard("one")
        self.assertIs(caught.exception, primary)
        self.assertIsNone(self.run.clock.mode)
        self.assertEqual(self.fx.signals.timer, 0)
        self.assertTrue(any(isinstance(e, MemoryError) for e in self.boundary.capture_errors))
        self.notes.update(primary_identity_preserved=True, timer_stopped=True, capture_error="allocation fixture")

    def test_capture_append_failure_cannot_replace_primary(self):
        class RejectAppend(list):
            def append(self, value):
                raise MemoryError("capture append")
        self.boundary.captures = RejectAppend()
        self.run.clock.remaining["save"] = 0
        with self.assertRaisesRegex(TimeoutError, "save exhausted"):
            self.boundary.save("one", {})
        self.assertIsNone(self.run.clock.mode)
        self.assertEqual(self.fx.signals.timer, 0)
        self.assertEqual(self.sink_calls, 0)

    def test_exception_append_failure_cannot_replace_primary(self):
        class RejectAppend(list):
            def append(self, value):
                raise MemoryError("exception append")
        self.run.exceptions = RejectAppend()
        self.run.clock.remaining["save"] = 0
        with self.assertRaisesRegex(TimeoutError, "save exhausted"):
            self.boundary.save("one", {})
        self.assertIsNone(self.run.clock.mode)
        c = self.boundary.captures[-1]
        self.assertTrue(any(isinstance(e, MemoryError) for e in c.secondary_errors))
        self.record(c)

    def test_failure_budget_exhaustion_keeps_completed_reference(self):
        self.run.clock.remaining["compute"] = 0
        self.run.clock.remaining["failure"] = 0
        with self.assertRaisesRegex(TimeoutError, "compute exhausted"):
            self.boundary.save("one", {})
        c = self.boundary.captures[-1]
        self.assertIsNotNone(c.completed_result)
        self.assertIsNone(c.receipt)
        self.assertEqual(self.sink_calls, 0)
        self.assertTrue(any("failure exhausted" in str(e) for e in c.secondary_errors))
        self.assertIsNone(self.run.clock.mode)
        self.record(c)

    def test_elapsed_failure_time_cannot_be_reset_for_sink(self):
        def slow_observation(path):
            self.fx.now = 121.0
            return {"path": str(path), "bytes": 0, "sha256": "fixture"}
        self.run.clock.remaining["compute"] = 0
        with patch.object(adapter, "file_observation", slow_observation):
            with self.assertRaisesRegex(TimeoutError, "compute exhausted"):
                self.boundary.save("one", {})
        c = self.boundary.captures[-1]
        self.assertEqual(self.sink_calls, 0)
        self.assertLessEqual(self.run.clock.remaining["failure"], 0)
        self.assertIsNone(self.run.clock.mode)
        self.record(c)

    def test_failure_clock_stop_error_never_claims_final_stop(self):
        self.run.clock.remaining["save"] = 0
        original = self.run.clock.stop
        calls = 0
        def stop():
            nonlocal calls
            calls += 1
            if calls >= 5:
                raise OSError("injected final timer-stop failure")
            return original()
        with patch.object(self.run.clock, "stop", stop):
            with self.assertRaises(TimeoutError):
                self.boundary.save("one", {})
        c = self.boundary.captures[-1]
        self.assertFalse(c.timer_stopped)
        self.assertTrue(any("timer-stop failure" in str(e) for e in c.secondary_errors))
        self.assertIsNone(c.error.__cause__)
        original()  # Fixture cleanup, not a claim that the adapter stopped it.
        self.record(c)

    def test_sink_partial_output_is_retained_but_not_claimed_durable(self):
        target = self.fx.h["ROOT"] / "failure" / self.failname
        self.run.clock.remaining["save"] = 0
        with self.fx.short_writes(target):
            with self.assertRaises(TimeoutError):
                self.boundary.save("one", {})
        c = self.boundary.captures[-1]
        self.assertIsNone(c.receipt)
        self.assertTrue(target.is_file())
        self.assertGreater(target.stat().st_size, 0)
        self.assertTrue(any("full readback" in str(e) for e in c.secondary_errors))
        self.record(c)
        self.notes["unreceipted_sink_bytes_hex"] = target.read_bytes().hex()
        self.notes["unreceipted_sink_sha256"] = hashlib.sha256(target.read_bytes()).hexdigest()


class Recorded(unittest.TextTestResult):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.records = []

    def stopTest(self, test):
        self.records.append({"test": test.id(), "notes": getattr(test, "notes", {})})
        super().stopTest(test)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", required=True)
    args = parser.parse_args()
    if Path(args.run).name != args.run or args.run in (".", ".."):
        raise ValueError("new leaf run name")
    resource.setrlimit(resource.RLIMIT_AS, (512 * MIB, 512 * MIB))
    precheck()
    out = BASE / "evidence" / args.run
    out.mkdir(exist_ok=False)
    fixture.OUT.mkdir(exist_ok=True)
    log = io.StringIO()
    suite = unittest.TestSuite([
        unittest.defaultTestLoader.loadTestsFromTestCase(fixture.PureSaveTests),
        unittest.defaultTestLoader.loadTestsFromTestCase(CaptureTests),
    ])
    result = unittest.TextTestRunner(stream=log, verbosity=2, resultclass=Recorded).run(suite)
    report = {"status": "PASS_NOT_ADOPTED" if result.wasSuccessful() else "FAIL_NOT_ADOPTED",
              "tests": result.testsRun, "failures": len(result.failures), "errors": len(result.errors),
              "baseline_weaknesses_retained": 12, "records": result.records,
              "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "adapter_sha256": hashlib.sha256((BASE / "source/save_capture_not_adopted.py").read_bytes()).hexdigest(),
              "frozen_ast": fixture.AST_EVIDENCE,
              "AS_bytes": resource.getrlimit(resource.RLIMIT_AS),
              "maxrss_kib": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
              "work_bytes_before_report": precheck(),
              "native_HDS": 0, "restore": 0, "Query": 0, "Teach": 0, "SDK": 0, "Action": 0,
              "live_wrapper_execution": 0, "Git": 0}
    with (out / "results.json").open("x") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    with (out / "test.log").open("x") as f:
        f.write(log.getvalue())
    precheck()
    print(json.dumps({k: report[k] for k in ("status", "tests", "failures", "errors", "maxrss_kib")}))
    if not result.wasSuccessful():
        print(log.getvalue())
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    raise SystemExit(main())
