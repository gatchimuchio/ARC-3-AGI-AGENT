"""Disabled saved-observation suffix native harness source. All public native entries refuse.
Existing all27 capture/codec/standard save and semantic entry are exact AST reused.
No SDK, GameAction, Teach, reset, or environment access exists in this harness.
"""
import ast,base64,copy,hashlib,importlib.util,json,lzma,os,resource,shutil,signal,sys,time,traceback,types
from pathlib import Path
from copy import deepcopy
B=Path('/workspace/scratch/a94ff513b3af');ROOT=B/'arc-column-live-loop-20261013';D=ROOT/'source/goalset_connection/diagnostic';MIB=1<<20
RUNTIME_AUTHORIZED=False
FIRST_ORIGINAL_ORDINAL=59
LAST_ORIGINAL_ORDINAL=117
SUFFIX_QUERY_BOUND=2567
BASELINE_COUNTER=5880
PINS=json.loads((D/'pins_v1.json').read_text())
PINS['state']={'path': '/workspace/scratch/a94ff513b3af/arc-column-live-loop-20261013/evidence/793242337c714081b4f642f1e0db3663/failure_latest.standard.json', 'bytes': 5355957, 'sha256': '90bd34cfeb8e5cfdda28760af8e7ce1f113ecd6362dac5c0936c98819a1cf3fb'}
PINS['closure']={'path': '/workspace/scratch/a94ff513b3af/arc-column-live-loop-20261013/source/goalset_connection/diagnostic/prefix_closure_v1.py', 'bytes': 6262, 'sha256': 'd7087293102f28047d994feee5b36a94111416bb1def8ea6bed3d4259a4ea9f0'}
PINS['resume_refs']={'path': '/workspace/scratch/a94ff513b3af/arc-column-live-loop-20261013/source/goalset_connection/diagnostic/resume_refs_v1.json', 'bytes': 1887, 'sha256': 'c4d4e964a95f7a21ad91c4d121ae1ce8155cda3d7d853179087184f2751906b7'}

def native_permission():
 raise PermissionError('SOURCE/PURE ONLY: saved59 suffix native Query gate not issued')
def load_pure(name,key):
 r=PINS[key];p=Path(r['path']);b=p.read_bytes()
 if p.is_symlink() or len(b)!=r['bytes'] or hashlib.sha256(b).hexdigest()!=r['sha256']:raise ValueError('source pin')
 m=types.ModuleType(name);m.__file__=str(p);sys.modules[name]=m;exec(compile(b,str(p),'exec'),m.__dict__);return m
scope=load_pure('diagnostic_resource_guard','guard')
# Deliberately excludes old all27 imports/preflight/restore and all game code.
t=ast.parse(Path(PINS['base']['path']).read_bytes())
if hashlib.sha256(Path(PINS['base']['path']).read_bytes()).hexdigest()!=PINS['base']['sha256']:raise ValueError('base exact pin')
names={'eq','jb','sha','identity','ref','fsyncdir','readref','capture_call','snapshot_value','frame_hash','Clock'}
nodes=[copy.deepcopy(n) for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in names]
old=next(n for n in t.body if isinstance(n,ast.ClassDef) and n.name=='Run')
methods={'__init__','encoded','save','standard','markers'}
body=[copy.deepcopy(n) for n in old.body if isinstance(n,ast.FunctionDef) and n.name in methods]
if {n.name for n in nodes}!=names or {n.name for n in body}!=methods:raise ValueError('base AST closure')
# Only output namespace/cap changes. Capture, codec, write/CRC/readback and normal
# native persistence body remain inherited. Source versions are never overwritten.
class Storage(ast.NodeTransformer):
 def visit_Constant(self,n):
  if n.value=='state_trace':return ast.copy_location(ast.Constant('evidence'),n)
  return n
for n in body:
 Storage().visit(n)
 if n.name=='save':
  for sub in ast.walk(n):
   if isinstance(sub,ast.Compare) and isinstance(sub.left,ast.BinOp) and isinstance(sub.left.left,ast.Attribute) and sub.left.left.attr=='trace_bytes':
    sub.comparators[0]=ast.parse('800*MIB',mode='eval').body
  # Insert a cap check immediately after lzma.compress, before any write.
  tr=next(x for x in n.body if isinstance(x,ast.Try))
  at=next(i for i,x in enumerate(tr.body) if isinstance(x,ast.Assign) and any(isinstance(z,ast.Name) and z.id=='blob' for z in x.targets))
  tr.body[at+1:at+1]=ast.parse('self.check_packet_budget(name,category,len(blob))').body
nodes.append(ast.ClassDef(name='BaseRun',bases=[],keywords=[],body=body,decorator_list=[]))
exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),PINS['base']['path'],'exec'),globals())
q=Path(PINS['query']['path']).read_bytes()
if len(q)!=PINS['query']['bytes'] or hashlib.sha256(q).hexdigest()!=PINS['query']['sha256']:raise ValueError('query source pin')
t=ast.parse(q);nodes=[copy.deepcopy(n) for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='semantic_entry']
if len(nodes)!=1:raise ValueError('semantic AST closure')
exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),PINS['query']['path'],'exec'),globals())
OWNER=None

def guard(category=None,extra=0):
 result=scope.guard(category,extra)
 if OWNER is not None and OWNER.start_usage is not None:
  now=result['used']
  for k,cap in [('evidence',800*MIB),('failure',4*MIB)]:
   if now[k]-OWNER.start_usage[k]+(extra if category==k else 0)>cap:raise MemoryError('incremental '+k+' budget')
 return result

def candidate_code_set(candidate):
 out=set()
 def walk(code):
  if isinstance(code,types.CodeType):
   out.add(code)
   for c in code.co_consts:walk(c)
 walk(candidate.全作用候補を構成する.__code__);walk(candidate.legacy.全作用候補を構成する.__code__)
 return out

def current_origin(base,external,codes,action_boundary,preserve_boundaries):
 origin=deepcopy(base)
 if origin.get('live採否可能')is not False:raise ValueError('diagnostic origin must remain false')
 origin.update({'候補番号':None,'用途':'目標pool','境界':external.対象系境界})
 f=sys._getframe()
 try:
  while f:
   if f.f_code in codes and isinstance(f.f_locals.get('c'),dict):
    c=f.f_locals['c']
    if type(c.get('候補番号'))is not int:raise ValueError('candidate origin type')
    origin['候補番号']=c['候補番号'];origin['用途']='作用対応' if external.対象系境界==action_boundary else '保存' if external.対象系境界 in preserve_boundaries else '候補効果';break
   f=f.f_back
 finally:del f
 if external.対象系境界 not in ('公開列図式:記号外形と展開役割','公開列図式:有限全列または生産的反復の目標長一致と提出受理') and origin['候補番号'] is None:raise ValueError('candidate origin missing')
 return origin

def validate_dependency_pins(pins):
 """Read-only exact closure. The one known public corpus is data, not code.
 Corpus classification changes only a resource verifier cap, never a solution.
 sha() is the inherited64KiB streaming hasher; no corpus read_bytes allocation.
 """
 verified=[]
 for r in pins:
  if type(r)is not dict or set(r)!={'path','bytes','sha256'}:raise ValueError('dependency FileRef schema')
  p=Path(r['path']);cap=128*MIB if eq(r,PINS['raw']) else 8*MIB
  if type(r['bytes'])is not int or r['bytes']<0 or r['bytes']>cap or p.is_symlink() or p.stat().st_size!=r['bytes'] or sha(p)!=r['sha256']:raise ValueError('dependency exact streamed reference')
  verified.append({'ref':r,'cap':cap,'streamed':True})
 return verified

def actual_native_dependency_pins():
 """Pinned legacy literal manifest; parses source, never imports HDS."""
 tree=ast.parse(readref(PINS['base'],8*MIB))
 rows=[n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='DEPENDENCIES' for x in n.targets)]
 if len(rows)!=1:raise ValueError('base dependency literal closure')
 pins=ast.literal_eval(rows[0].value)
 if type(pins)is not list or len(pins)!=20:raise ValueError('base all20 native/family pins')
 validate_dependency_pins(pins)
 core=B/'arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2'
 expected={str(p) for p in core.rglob('*.py')}
 pinned={r['path'] for r in pins if Path(r['path']).is_relative_to(core) and r['path'].endswith('.py')}
 if expected!=pinned or len(pinned)!=12:raise ValueError('all12 core Python source coverage')
 return pins

def expected_state(initial,count,enc,dec):
 if type(count)is not int or not 0<=count<=2567:raise ValueError('strict query count')
 expected=dec(enc(initial))
 for k in ('照会','学習判定'):expected['識別子状態'][k]=expected['識別子状態'].get(k,0)+count
 return expected

class Run(BaseRun):
 def __init__(self):
  super().__init__();self.clock.remaining={'compute':7200.0,'save':3600.0,'failure':120.0};self.start_usage=None;self.frame_results=[];self.frame_budget=0;self.frame_calls=0;self.items=[];self.origin=None;self.initial=None;self.input_closures=[];self.completed_queries=0
 def preflight(self,*args,**kwargs):native_permission()
 def execute(self,*args,**kwargs):native_permission()
 def allow_frame(self,n):
  if type(n)is not int or not 4<=n<=58 or len(self.calls)+n>2567:raise MemoryError('strict frame/full query bound')
  self.frame_budget=n
 def check_packet_budget(self,name,category,size):
  if category=='failure':cap=4*MIB
  elif name=='failure_component_current_metadata':cap=2*MIB
  elif name.startswith('failure_component_'):cap=16*MIB
  elif name.endswith('_intent'):cap=16*1024
  elif name.endswith('_reply'):cap=112*1024
  elif name.endswith('_result'):cap=512*1024
  elif name.endswith('_input'):cap=32*1024
  else:cap=32*MIB
  if size>cap:raise MemoryError('individual complete packet cap: '+name)
 @property
 def owner(self):return self
 def 照会する(self,external):
  native_permission()
  return self._query_after_admission(external)
 def _query_after_admission(self,external):
  native_permission()
  if self.frame_calls>=self.frame_budget or len(self.calls)>=2567:raise MemoryError('full enumeration cap')
  i=len(self.calls);origin=current_origin(self.origin,external,self.candidate_codes,self.candidate.作用境界,{self.candidate.legacy.保存境界,self.candidate.common.PRESERVE_BOUNDARY})
  origin['復元状態参照']=PINS['state'];origin['直前Query通番']=i-1
  self.current={'ordinal':i,'frame':self.frame_ordinal,'method':'照会する','input':external,'origin':origin,'before':self.markers(),'capture':{}}
  intent=self.save('api_%06d_intent'%i,self.current)
  answer=capture_call(self.machine,'照会する',external,self.current['capture']);self.completed_queries+=1
  self.current['after']=self.markers()
  reply=self.save('api_%06d_reply'%i,self.current)
  self.calls.append({'ordinal':i,'frame':self.frame_ordinal,'method':'照会する','intent':intent,'reply':reply});self.frame_calls+=1
  expected=expected_state(self.initial,len(self.calls),self.enc,self.dec)
  if not eq(self.enc(expected),self.enc(snapshot_value(self.machine))):raise ValueError('per-query complete native state differs beyond paired counters')
  self.current=None;return answer
 def ask(self,boundary,facts):
  r=self.照会する(self.native.外部入力(deepcopy(facts),boundary));return {'状態':r.状態,'内容':r.内容,'追跡情報':r.追跡情報,'実照会保存参照':deepcopy(self.calls[-1])}
 def _initialize_after_admission(self,catalog_module):
  native_permission()
  closure=load_pure('saved_diagnostic_latest_closure','closure').verify()
  if closure['runtime_authorized']is not False or closure['closed_state']!=PINS['state']:raise ValueError('exact5880 failed-prefix closure')
  global OWNER
  if OWNER is not None:raise RuntimeError('single serial diagnostic instance')
  OWNER=self;self.start_usage=scope.guard()['used'];all_items=catalog_module.catalog()
  self.items=all_items[59:]
  if [x['ordinal']for x in self.items]!=list(range(59,118)) or sum(x['bound']for x in self.items)!=2567:raise ValueError('exact whole suffix59/bound2567')
  self.prefix_closure=closure
  self._prepare_native_bindings()
  self.input_closures=[]
  # Exact input source/identity closure, including all core/family bytes.
  for r in list(PINS.values())+self.dependency_pins+list(closure['references'].values()):
   p=Path(r['path'])
   if p.is_symlink() or p.stat().st_size!=r['bytes'] or sha(p)!=r['sha256']:raise ValueError('input closure ref')
   self.input_closures.append({'ref':r,'identity':identity(p)})
  self.candidate=load_pure('saved_diagnostic_candidate','candidate');self.candidate_codes=candidate_code_set(self.candidate)
  self.machine=self.native.HDS学習系統.読み込む(PINS['state']['path'])
  first,self.initial=self.standard('restored_before')
  if first['bytes']!=PINS['state']['bytes'] or first['sha256']!=PINS['state']['sha256']:raise ValueError('exact standard restore')
  return closure
 def _prepare_native_bindings(self):
  native_permission()
  pack=json.loads(readref(PINS['pack'],MIB));self.material_pins=pack['source_pins']
  self.verified_material_pins=validate_dependency_pins(self.material_pins)
  self.native_dependency_pins=actual_native_dependency_pins()
  self.dependency_pins=self.material_pins+self.native_dependency_pins
  core=B/'arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2';familyroot=B/'arc-current-family-source-20261013'
  sys.dont_write_bytecode=True;sys.path.insert(0,str(core));sys.path.insert(0,str(familyroot))
  import hds学習系統 as native
  import hds学習系統.永続化 as persistence
  from 接続 import 列図式規則 as family
  if Path(native.__file__).resolve()!=core/'hds学習系統/__init__.py' or Path(family.__file__).resolve()!=Path(PINS['family']['path']):raise ValueError('native/family import identity')
  self.native=native;self.enc=persistence._符号化;self.dec=persistence._復号;self.family=family
 def _execute_after_admission(self):
  native_permission()
  for item in self.items:
   i=item['ordinal']
   self.frame_ordinal=i;self.frame_calls=0;self.frame_budget=0;self.origin=deepcopy(item['origin'])
   self.save('frame_%03d_input'%i,{k:v for k,v in item.items() if k not in ('frame','scene','selection','expected_pool')})
   # Only current pixels/public availability/state flow into solver. Labels and
   # expected teacher pools are evidence joins and never solution inputs.
   result=semantic_entry(self.family,self.candidate,item['frame'],item['actions'],self,self.ask,item['public_state'])
   if result.get('API数上界')!=item['bound'] or self.frame_calls>item['bound']:raise ValueError('current structural bound differs')
   result['actual_API_count']=self.frame_calls;result['phase_scope']={'診断のみ':True,'live採否可能':False,'相':item['origin']['相'],'全相数':item['origin']['全相数'],'末相':True}
   self.frame_results.append(self.save('frame_%03d_result'%i,{'ordinal':i,'origin':self.origin,'result':result}))
  last,final=self.standard('after_all_queries')
  if not eq(self.enc(expected_state(self.initial,len(self.calls),self.enc,self.dec)),self.enc(final)):raise ValueError('final complete state equality')
  if last['bytes']!=5355957:raise ValueError('same-digit standard size differs')
  for x in self.input_closures:
   r=x['ref'];p=Path(r['path'])
   if identity(p)!=x['identity'] or p.stat().st_size!=r['bytes'] or sha(p)!=r['sha256']:raise ValueError('final input identity/hash changed')
  reclosed=load_pure('saved59_recheck_prefix_closure','closure').verify()
  if not eq(reclosed,self.prefix_closure):raise ValueError('prefix closure changed during suffix')
  complete={'schema':'saved59-suffix-candidate-diagnostic-completion-v1','status':'complete','errors':[],'nonce':self.gate['nonce'],'input_closures':self.input_closures,'frames':self.frame_results,'frame_count':59,'processed_original_ordinals':list(range(59,118)),'prefix_failure_closure':self.prefix_closure,'all118_complete_claim':False,'all118_integration_requires_independent_audit':True,'api_calls':self.calls,'states':self.state_refs,'Teach':0,'Query':len(self.calls),'Action':0,'SDK':0,'unprocessed_suffix':[],'diagnostic_origin_live_adoption':False,'next_fresh_baseline':last,'final_paired_counter':5880+len(self.calls),'full_state_only_paired_counters':True}
  receipt=self.save('completion',complete,codec=False);self.complete=True;return receipt
 def preserve_failure_components(self):
  """No aggregate duplicate. All failures stay visible; no cleanup/replay."""
  native_permission()
  self.clock.stop();self.clock.remaining['save']=120.0
  pending=self.pending;current=self.current
  manifest={'status':'failed_held','errors':self.errors,'returned_capture_calls':self.completed_queries,'durably_receipted_Query':len(self.calls),'saved_frames':self.frame_results,'unprocessed_suffix':list(range(59+len(self.frame_results),118)),'components':{},'state':None,'live採否可能':False}
  # Retain references before any save updates self.pending. No deep-copy heap.
  manifest['pending_name']=pending.get('name') if isinstance(pending,dict) else None
  manifest['pending_is_current']=isinstance(pending,dict) and pending.get('value') is current
  if current is not None:
   metadata={k:v for k,v in current.items() if k not in ('input','capture')}
   metadata['capture_metadata']={k:v for k,v in current.get('capture',{}).items() if k not in ('raw','return')}
   try:manifest['current_metadata']=self.save('failure_component_current_metadata',metadata)
   except BaseException as e:manifest['current_metadata']={'unsaved':True,'type':type(e).__name__,'message':str(e)}
  if isinstance(pending,dict) and 'value' in pending and pending['value'] is not current:
   try:manifest['pending_value']=self.save('failure_component_pending_value',pending['value'])
   except BaseException as e:manifest['pending_value']={'unsaved':True,'type':type(e).__name__,'message':str(e)}
  self.held_failure_pending=pending;self.held_failure_current=current
  if current is not None:
   # Each object is encoded independently. Failed components remain in current.
   parts={'input':current.get('input'),'raw':current.get('capture',{}).get('raw'),'external_return':current.get('capture',{}).get('return')}
   for name,value in parts.items():
    try:manifest['components'][name]=self.save('failure_component_'+name,value)
    except BaseException as e:manifest['components'][name]={'unsaved':True,'type':type(e).__name__,'message':str(e)}
  try:
   state_ref,state_value=self.standard('failure_latest');manifest['state']=state_ref
   manifest['actual_identifiers_from_saved_normal']=state_value['識別子状態']
   manifest['actual_Query_delta_from_5880']=state_value['識別子状態']['照会']-5880
  except BaseException as e:manifest['state']={'unsaved':True,'type':type(e).__name__,'message':str(e)}
  return self.save('failure_manifest',manifest,'failure',codec=False)

def main(*args,**kwargs):native_permission()
if __name__=='__main__':main()
