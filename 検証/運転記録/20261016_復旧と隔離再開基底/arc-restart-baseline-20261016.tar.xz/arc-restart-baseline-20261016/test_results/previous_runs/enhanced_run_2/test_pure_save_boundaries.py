#!/usr/bin/env python3
"""Exact-AST, stdlib-only observations of frozen save boundaries. No live launcher.

Run: python -B tests/test_pure_save_boundaries.py
Only selected pure definitions are compiled, never either source module. Every
filesystem mutation is in this script's own TemporaryDirectory under test_results.
Production thresholds are unchanged. Large-file accounting uses labelled stat
injection; disk/RAM and clocks are deterministic test doubles. Native HDS, SDK,
Action, network, Git and live Run/run/preflight/execute are never executed.
"""
import ast
import builtins
import hashlib
import io
import json
import lzma
import os
from pathlib import Path
import resource
import shutil
import signal
import statistics
import sys
import tempfile
import time
import traceback
import types
import unittest
from unittest.mock import patch

BASE = Path(__file__).resolve().parents[1]
OUT = BASE / "test_results"
MIB = 1048576
PINS = {
    "resource_guard_v1.py": "d221c24e808fb66b686b6a030c54f89fb92a30ce8ffc23a3f5de9f9200009038",
    "column_work_harness_v3.py": "f0d73f35a9516eda585b134ae54be9815b36d6164786b9f8a0966c3983640007",
}
AST_EVIDENCE = {}
PROTECTED = "protected_boundary"
WEAKNESS = "observed_weakness"
BEHAVIOR = "observed_behavior"


def baseline_precheck():
    if BASE.is_symlink() or OUT.is_symlink():
        raise RuntimeError("test scope symlink")
    entries = list(BASE.rglob("*"))
    if any(p.is_symlink() for p in entries):
        raise RuntimeError("baseline scope symlink")
    n = sum(p.stat().st_size for p in entries if p.is_file())
    if n > 32 * MIB:
        raise MemoryError("baseline combined32MiB")
    if shutil.disk_usage(BASE).free < 1024 * MIB:
        raise MemoryError("physical disk floor1GiB")
    return n


def extract(filename, functions, classes):
    p = BASE / "source" / filename
    data = p.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    if digest != PINS[filename]:
        raise ValueError("source pin mismatch: " + filename)
    tree = ast.parse(data, filename=str(p))
    picked = []
    manifest = []
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name in functions:
            picked.append(node)
            manifest.append((node.name, node))
        elif isinstance(node, ast.ClassDef) and node.name in classes:
            methods = classes[node.name]
            if methods is None:
                picked.append(node)
                manifest.append((node.name, node))
            else:
                body = [n for n in node.body if isinstance(n, ast.FunctionDef) and n.name in methods]
                if {n.name for n in body} != set(methods):
                    raise ValueError("missing selected method")
                cls = ast.ClassDef(name=node.name, bases=[], keywords=[], body=body, decorator_list=[])
                picked.append(ast.copy_location(cls, node))
                manifest.extend((node.name + "." + n.name, n) for n in body)
    got_functions = {n.name for n in picked if isinstance(n, ast.FunctionDef)}
    if got_functions != set(functions):
        raise ValueError("missing selected function")
    if {n.name for n in picked if isinstance(n, ast.ClassDef)} != set(classes):
        raise ValueError("missing selected class")
    selected = ast.fix_missing_locations(ast.Module(body=picked, type_ignores=[]))
    if any(isinstance(n, (ast.Import, ast.ImportFrom)) for n in ast.walk(selected)):
        raise ValueError("import in selected AST")
    AST_EVIDENCE[filename] = {
        "source": "source/" + filename,
        "source_bytes": len(data),
        "source_sha256": digest,
        "selected": [{"name": name, "first_line": n.lineno, "last_line": n.end_lineno,
                      "ast_sha256": hashlib.sha256(ast.dump(n, include_attributes=False).encode()).hexdigest()}
                     for name, n in manifest],
        "whole_module_executed": False,
    }
    return compile(selected, str(p), "exec")


def case(kind):
    def decorate(fn):
        fn.boundary_kind = kind
        return fn
    return decorate


class FakeSignals:
    SIGALRM = signal.SIGALRM
    ITIMER_REAL = signal.ITIMER_REAL
    SIGXFSZ = signal.SIGXFSZ

    def __init__(self):
        self.handlers = {}
        self.timer = 0

    def signal(self, sig, handler):
        old = self.handlers.get(sig)
        self.handlers[sig] = handler
        return old

    def setitimer(self, which, value):
        old = self.timer
        self.timer = value
        return (old, 0)


class ShortWriter:
    def __init__(self, handle, missing=1, lying=False):
        self.handle, self.missing, self.lying = handle, missing, lying

    def __enter__(self):
        self.handle.__enter__()
        return self

    def __exit__(self, *args):
        return self.handle.__exit__(*args)

    def __getattr__(self, name):
        return getattr(self.handle, name)

    def write(self, data):
        if self.lying:
            self.handle.write(data)
            return len(data) - self.missing
        return self.handle.write(data[:-self.missing])


class PureSaveTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.r_code = extract("resource_guard_v1.py", {"guard", "fsyncdir", "save"}, {})
        cls.h_code = extract("column_work_harness_v3.py",
                             {"eq", "jb", "sha", "ref", "fsyncdir", "guard", "snapshot_value"},
                             {"Clock": None, "Run": {"encoded", "save", "standard"}})

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix=".save-fixtures-", dir=OUT)
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name)
        self.notes = {}
        self.mem = 6656 * MIB
        self.disk = 20 * 1024 * MIB
        self.now = 0.0
        self.signals = FakeSignals()
        self.r = self.namespace(self.base / "resource")
        self.r.update(M=MIB, CAPS={"source": 16 * MIB, "evidence": 2000 * MIB, "failure": 32 * MIB})
        self.h = self.namespace(self.base / "harness")
        exec(self.r_code, self.r)
        exec(self.h_code, self.h)
        for namespace, categories in [(self.r, ("source", "evidence", "failure")),
                                      (self.h, ("source", "state_trace", "failure"))]:
            for category in categories:
                (namespace["ROOT"] / category).mkdir(parents=True)
        original_read_text = Path.read_text

        def read_text(path, *args, **kwargs):
            if str(path) == "/proc/meminfo":
                return "MemAvailable: %d kB\n" % (self.mem // 1024)
            return original_read_text(path, *args, **kwargs)

        self.reader_patch = patch.object(Path, "read_text", read_text)
        self.reader_patch.start()
        self.addCleanup(self.reader_patch.stop)

    def namespace(self, root):
        def local_open(path, *args, **kwargs):
            if str(path) == "/proc/meminfo":
                return io.StringIO("MemAvailable: %d kB\n" % (self.mem // 1024))
            return builtins.open(path, *args, **kwargs)

        return {"__builtins__": builtins.__dict__, "__name__": "pinned_pure_test",
                "Path": Path, "B": self.base, "ROOT": root, "MIB": MIB,
                "os": os, "resource": resource, "hashlib": hashlib, "json": json, "lzma": lzma,
                "signal": self.signals, "time": types.SimpleNamespace(monotonic=lambda: self.now),
                "open": local_open,
                "shutil": types.SimpleNamespace(disk_usage=lambda _: types.SimpleNamespace(free=self.disk))}

    def runner(self):
        run = self.h["Run"]()
        run.clock = self.h["Clock"]()
        run.enc = lambda x: x
        run.dec = lambda x: x
        run.pending = None
        run.exceptions = []
        run.trace_bytes = 0
        run.state_refs = []
        run.gate = {"nonce": "0" * 32}
        engine = types.SimpleNamespace(
            最小支持数=1, 最大条件数=2,
            識別子=types.SimpleNamespace(状態を書き出す=lambda: {"経験": 0}),
            台帳=types.SimpleNamespace(全取得=lambda: {"経験": []}),
            状態=types.SimpleNamespace(履歴=lambda: []), _原理履歴={})
        machine = types.SimpleNamespace(エンジン=engine)
        machine.保存する = lambda p: Path(p).write_bytes(json.dumps(
            self.h["snapshot_value"](machine), ensure_ascii=False, indent=2).encode())
        run.machine = machine
        return run

    def journal_path(self, run, name="one"):
        return self.h["ROOT"] / "state_trace" / run.gate["nonce"] / (name + ".json.xz")

    def evidence(self, path, run=None):
        data = Path(path).read_bytes() if Path(path).exists() else None
        self.notes.update(file_present=data is not None,
                          bytes=None if data is None else len(data),
                          sha256=None if data is None else hashlib.sha256(data).hexdigest(),
                          prefix_hex=None if data is None else data[:32].hex(),
                          full_hex=None if data is None or len(data) > 4096 else data.hex())
        if run is not None:
            self.notes.update(pending_present=run.pending is not None,
                              exception_types=[type(e).__name__ for e in run.exceptions],
                              clock_mode=run.clock.mode, trace_bytes=run.trace_bytes)

    def fake_sizes(self, mapping):
        original = Path.stat

        def stat(path, *args, **kwargs):
            real = original(path, *args, **kwargs)
            if path not in mapping:
                return real
            values = list(real)
            values[6] = mapping[path]
            return os.stat_result(values)

        return patch.object(Path, "stat", stat)

    def short_writes(self, path, lying=False):
        original = Path.open

        def opened(p, mode="r", *args, **kwargs):
            f = original(p, mode, *args, **kwargs)
            return ShortWriter(f, lying=lying) if p == path and mode == "xb" else f

        return patch.object(Path, "open", opened)

    @case(PROTECTED)
    def test_eq_full_types_and_dictionary_order(self):
        """Frozen equality rejects bool/int, list/tuple and dictionary order drift."""
        eq = self.h["eq"]
        self.assertFalse(eq(True, 1))
        self.assertFalse(eq([1], (1,)))
        self.assertFalse(eq({"a": 1, "b": 2}, {"b": 2, "a": 1}))
        self.assertTrue(eq({"a": [True, 1]}, {"a": [True, 1]}))

    @case(PROTECTED)
    def test_encoded_roundtrip_rejects_order_drift(self):
        run = self.runner()
        self.assertEqual(run.encoded({"a": 1}), b'{"a":1}')
        run.dec = lambda x: dict(reversed(list(x.items())))
        with self.assertRaisesRegex(ValueError, "full types/order"):
            run.encoded({"a": 1, "b": 2})

    @case(PROTECTED)
    def test_resource_success_and_duplicate(self):
        data = b"saved exact bytes\x00"
        result = self.r["save"]("evidence", "one.bin", data)
        p = Path(result["path"])
        self.assertEqual(p.read_bytes(), data)
        self.assertEqual(result["sha256"], hashlib.sha256(data).hexdigest())
        with self.assertRaises(FileExistsError):
            self.r["save"]("evidence", "one.bin", b"replacement")
        self.assertEqual(p.read_bytes(), data)
        self.evidence(p)

    @case(PROTECTED)
    def test_resource_namespace_rejects_traversal(self):
        with self.assertRaisesRegex(ValueError, "namespace"):
            self.r["save"]("evidence", "../outside", b"x")
        with self.assertRaisesRegex(ValueError, "namespace"):
            self.r["save"]("unknown", "one", b"x")

    @case(PROTECTED)
    def test_resource_short_write_detected_by_readback(self):
        p = self.r["ROOT"] / "evidence" / "partial.bin"
        with self.short_writes(p):
            with self.assertRaisesRegex(OSError, "full readback"):
                self.r["save"]("evidence", p.name, b"abcde")
        self.assertEqual(p.read_bytes(), b"abcd")
        self.evidence(p)

    @case(WEAKNESS)
    def test_resource_write_return_not_checked(self):
        """A deliberately lying short count is ignored when full bytes exist."""
        p = self.r["ROOT"] / "evidence" / "lying.bin"
        with self.short_writes(p, lying=True):
            self.r["save"]("evidence", p.name, b"abcde")
        self.assertEqual(p.read_bytes(), b"abcde")
        self.evidence(p)

    @case(PROTECTED)
    def test_resource_readback_failure_keeps_file(self):
        p = self.r["ROOT"] / "evidence" / "readback.bin"
        original = Path.read_bytes
        with patch.object(Path, "read_bytes", lambda q: b"wrong" if q == p else original(q)):
            with self.assertRaisesRegex(OSError, "full readback"):
                self.r["save"]("evidence", p.name, b"abcde")
        self.assertEqual(p.read_bytes(), b"abcde")
        self.evidence(p)

    @case(PROTECTED)
    def test_resource_rescans_external_add_resize_delete(self):
        guard = self.r["guard"]
        p = self.r["ROOT"] / "evidence" / "external"
        self.assertEqual(guard()["used"]["evidence"], 0)
        p.write_bytes(b"abc")
        self.assertEqual(guard()["used"]["evidence"], 3)
        p.write_bytes(b"abcdefg")
        self.assertEqual(guard()["used"]["evidence"], 7)
        p.unlink()
        self.assertEqual(guard()["used"]["evidence"], 0)
        self.notes["observed_used_sequence"] = [0, 3, 7, 0]

    @case(PROTECTED)
    def test_resource_exact_category_and_total_caps(self):
        paths = {k: self.r["ROOT"] / k / "accounted" for k in self.r["CAPS"]}
        for p in paths.values():
            p.write_bytes(b"x")
        sizes = {paths[k]: v for k, v in self.r["CAPS"].items()}
        with self.fake_sizes(sizes):
            result = self.r["guard"]()
            self.assertEqual(sum(result["used"].values()), 2048 * MIB)
            with self.assertRaisesRegex(MemoryError, "category source"):
                self.r["guard"]("source", 1)
            with self.assertRaisesRegex(MemoryError, "loop2048"):
                self.r["guard"](None, 1)
        self.notes["accounting"] = "Actual full scans; stat sizes synthetic at original 16/2000/32MiB and 2048MiB thresholds"

    @case(PROTECTED)
    def test_resource_extra_and_disk_ram_exact_boundaries(self):
        guard = self.r["guard"]
        for invalid in (-1, True, 1.0):
            with self.assertRaises(ValueError):
                guard(extra=invalid)
        self.disk = 4756 * MIB + 17
        guard("evidence", 17)
        self.disk -= 1
        with self.assertRaisesRegex(MemoryError, "physical1GiB"):
            guard("evidence", 17)
        self.disk = 20 * 1024 * MIB
        self.mem = 6656 * MIB
        guard()
        self.mem -= 1024
        with self.assertRaisesRegex(MemoryError, "RAM"):
            guard()
        self.notes.update(disk_exact=4756 * MIB + 17, disk_rejects_minus_bytes=1,
                          ram_exact=6656 * MIB, ram_rejects_minus_bytes=1024)

    @case(PROTECTED)
    def test_resource_nested_symlink_added_between_guards(self):
        original = self.r["guard"]
        calls = []
        target = self.base / "target"
        target.write_bytes(b"target")
        link = self.r["ROOT"] / "evidence" / "nested-link"

        def guard(*args):
            calls.append(args)
            if len(calls) == 2:
                link.symlink_to(target)
            return original(*args)

        self.r["guard"] = guard
        with self.assertRaisesRegex(ValueError, "file symlink"):
            self.r["save"]("evidence", "one", b"ok")
        self.assertEqual(len(calls), 2)
        self.evidence(self.r["ROOT"] / "evidence" / "one")
        self.notes["guard_calls"] = 2

    @case(PROTECTED)
    def test_resource_postwrite_external_cap_increase_detected(self):
        original = self.r["guard"]
        external = self.r["ROOT"] / "source" / "external"
        external.write_bytes(b"x")
        sizes = {external: 1}
        calls = []

        def guard(*args):
            calls.append(args)
            if len(calls) == 2:
                sizes[external] = 16 * MIB + 1
            return original(*args)

        self.r["guard"] = guard
        with self.fake_sizes(sizes):
            with self.assertRaisesRegex(MemoryError, "category source"):
                self.r["save"]("evidence", "one", b"ok")
        self.evidence(self.r["ROOT"] / "evidence" / "one")
        self.notes["guard_calls"] = len(calls)

    @case(PROTECTED)
    def test_harness_save_success_and_duplicate_preserves_pending(self):
        run = self.runner()
        value = {"state": [True, 1, "日本語"]}
        result = run.save("one", value)
        p = self.journal_path(run)
        self.assertEqual(lzma.decompress(p.read_bytes()), self.h["jb"](value))
        self.assertEqual(result["file"], self.h["ref"](p))
        self.assertIsNone(run.pending)
        self.assertEqual(run.clock.mode, "compute")
        old = p.read_bytes()
        with self.assertRaises(FileExistsError):
            run.save("one", {"replacement": True})
        self.assertEqual(p.read_bytes(), old)
        self.assertEqual(run.pending, {"name": "one", "value": {"replacement": True}})
        self.assertEqual(len(run.exceptions), 1)
        self.evidence(p, run)

    @case(PROTECTED)
    def test_harness_short_write_preserves_partial_and_pending(self):
        run = self.runner()
        p = self.journal_path(run)
        with self.short_writes(p):
            with self.assertRaisesRegex(OSError, "short write"):
                run.save("one", {"data": 1})
        self.assertIsNotNone(run.pending)
        self.assertEqual(len(run.exceptions), 1)
        self.assertEqual(run.trace_bytes, 0)
        self.evidence(p, run)

    @case(PROTECTED)
    def test_harness_readback_failure_preserves_file_and_pending(self):
        run = self.runner()
        p = self.journal_path(run)
        original = Path.read_bytes
        with patch.object(Path, "read_bytes", lambda q: original(q) + b"junk" if q == p else original(q)):
            with self.assertRaisesRegex(ValueError, "CRC64/EOF/bytes"):
                run.save("one", {"data": 1})
        self.assertIsNotNone(run.pending)
        self.assertEqual(len(run.exceptions), 1)
        self.assertEqual(run.trace_bytes, 0)
        self.evidence(p, run)

    @case(PROTECTED)
    def test_harness_fsync_failure_preserves_file_and_pending(self):
        run = self.runner()
        p = self.journal_path(run)
        os_proxy = types.SimpleNamespace(**{k: getattr(os, k) for k in ("open", "close", "O_RDONLY")})
        os_proxy.fsync = lambda _: (_ for _ in ()).throw(OSError("injected fsync failure"))
        self.h["os"] = os_proxy
        with self.assertRaisesRegex(OSError, "fsync failure"):
            run.save("one", {"data": 1})
        self.assertIsNotNone(run.pending)
        self.assertEqual(len(run.exceptions), 1)
        self.evidence(p, run)

    @case(PROTECTED)
    def test_harness_raw_16mib_and_trace_24mib_exact_boundaries(self):
        run = self.runner()
        value = "x" * (16 * MIB - 2)
        raw = self.h["jb"](value)
        self.assertEqual(len(raw), 16 * MIB)
        blob = lzma.compress(raw, preset=0, check=lzma.CHECK_CRC64)
        run.trace_bytes = 24 * MIB - len(blob)
        result = run.save("exact", value, codec=False)
        self.assertEqual(result["rawbytes"], 16 * MIB)
        self.assertEqual(run.trace_bytes, 24 * MIB)
        with self.assertRaisesRegex(MemoryError, "raw16MiB"):
            run.save("raw_over", value + "x", codec=False)
        run.trace_bytes = 24 * MIB - len(blob) + 1
        with self.assertRaisesRegex(MemoryError, "trace24MiB"):
            run.save("trace_over", value, codec=False)
        self.assertFalse(self.journal_path(run, "raw_over").exists())
        self.assertFalse(self.journal_path(run, "trace_over").exists())
        self.notes.update(raw_exact_bytes=16 * MIB, compressed_fixture_bytes=len(blob),
                          trace_accounting_synthetic=True, pending_failure_name=run.pending["name"])

    @case(PROTECTED)
    def test_harness_rescans_external_add_resize_delete(self):
        guard = self.h["guard"]
        p = self.h["ROOT"] / "state_trace" / "external"
        self.assertEqual(guard()["used"]["state_trace"], 0)
        p.write_bytes(b"abc")
        self.assertEqual(guard()["used"]["state_trace"], 3)
        p.write_bytes(b"abcdefg")
        self.assertEqual(guard()["used"]["state_trace"], 7)
        p.unlink()
        self.assertEqual(guard()["used"]["state_trace"], 0)
        self.notes["observed_used_sequence"] = [0, 3, 7, 0]

    @case(PROTECTED)
    def test_harness_requested_caps_total_disk_ram_boundaries(self):
        caps = {"source": 4 * MIB, "state_trace": 48 * MIB, "failure": 12 * MIB}
        paths = {k: self.h["ROOT"] / k / "accounted" for k in caps}
        for p in paths.values():
            p.write_bytes(b"x")
        with self.fake_sizes({paths[k]: v for k, v in caps.items()}):
            self.assertEqual(sum(self.h["guard"]()["used"].values()), 64 * MIB)
            for category in caps:
                self.h["guard"](category, 0)
                with self.assertRaisesRegex(MemoryError, "local category cap"):
                    self.h["guard"](category, 1)
            with self.assertRaisesRegex(MemoryError, "64MiB"):
                self.h["guard"](None, 1)
        self.disk = 2116 * MIB
        self.h["guard"]()
        self.disk -= 1
        with self.assertRaisesRegex(MemoryError, "disk1GiB"):
            self.h["guard"]()
        self.disk = 20 * 1024 * MIB
        self.mem = 6656 * MIB
        self.h["guard"]()
        self.mem -= 1024
        with self.assertRaisesRegex(MemoryError, "retained4.5GiB"):
            self.h["guard"]()
        self.notes.update(accounting="stat sizes synthetic at original 4/48/12MiB and64MiB thresholds",
                          disk_exact=2116 * MIB, ram_exact=6656 * MIB)

    @case(WEAKNESS)
    def test_harness_unrequested_category_over_cap_accepted(self):
        p = self.h["ROOT"] / "source" / "accounted"
        p.write_bytes(b"x")
        with self.fake_sizes({p: 4 * MIB + 1}):
            self.h["guard"]()
            self.h["guard"]("state_trace", 1)
            with self.assertRaises(MemoryError):
                self.h["guard"]("source", 0)
        self.notes["gap"] = "Full scan observes over-cap source, but only requested category is enforced."

    @case(WEAKNESS)
    def test_harness_negative_extra_is_not_rejected(self):
        self.h["guard"]("state_trace", -1)
        self.notes["gap"] = "Unlike resource_guard, harness guard does not validate nonnegative integer extra."

    @case(WEAKNESS)
    def test_harness_disk_reservation_omits_extra(self):
        self.disk = 2116 * MIB
        self.h["guard"]("state_trace", 1)
        self.notes["gap"] = "At disk threshold, prospective extra=1 still accepted; threshold excludes extra."

    @case(WEAKNESS)
    def test_harness_nested_symlink_guard_and_save_follow(self):
        run = self.runner()
        target = self.base / "owned-outside-category"
        target.mkdir()
        link = self.h["ROOT"] / "state_trace" / run.gate["nonce"]
        self.h["guard"]()
        link.symlink_to(target, target_is_directory=True)
        self.h["guard"]()
        run.save("one", {"safe_fixture": True})
        self.assertTrue((target / "one.json.xz").is_file())
        self.evidence(target / "one.json.xz", run)
        self.notes["gap"] = "A nested directory symlink is followed into an owned temporary sibling outside the category."

    @case(WEAKNESS)
    def test_harness_no_postwrite_guard_external_change(self):
        run = self.runner()
        external = self.h["ROOT"] / "source" / "external"
        external.write_bytes(b"x")
        sizes = {external: 1}
        guard = self.h["guard"]
        calls = []
        fsyncdir = self.h["fsyncdir"]

        def counted(*args):
            calls.append(args)
            return guard(*args)

        def after_write(path):
            fsyncdir(path)
            sizes[external] = 64 * MIB + 1

        self.h["guard"] = counted
        self.h["fsyncdir"] = after_write
        with self.fake_sizes(sizes):
            run.save("one", {"data": 1})
            self.assertEqual(len(calls), 1)
            with self.assertRaisesRegex(MemoryError, "64MiB"):
                guard()
        self.evidence(self.journal_path(run), run)
        self.notes["guard_calls_during_save"] = len(calls)

    @case(WEAKNESS)
    def test_harness_name_not_locally_validated(self):
        run = self.runner()
        result = run.save("../owned-escape", {"safe_fixture": True})
        p = self.h["ROOT"] / "state_trace" / "owned-escape.json.xz"
        self.assertTrue(p.is_file())
        self.assertEqual(Path(result["file"]["path"]).resolve(), p.resolve())
        self.notes["gap"] = "Run.save relies on trusted caller names; ../ is not rejected locally."

    @case(PROTECTED)
    def test_clock_exact_exhaustion_and_accumulation(self):
        clock = self.h["Clock"]()
        clock.enter("save")
        self.now = 119.5
        clock.stop()
        self.assertEqual(clock.remaining["save"], 0.5)
        clock.enter("save")
        self.assertEqual(self.signals.timer, 0.5)
        self.now = 120.0
        clock.stop()
        self.assertEqual(clock.remaining["save"], 0)
        with self.assertRaisesRegex(TimeoutError, "save exhausted"):
            clock.enter("save")
        self.assertEqual(self.signals.timer, 0)
        self.assertIsNone(clock.mode)
        clock.enter("compute")
        with self.assertRaisesRegex(TimeoutError, "aggregate deadline"):
            clock.expire()
        self.notes["clock"] = "Deterministic fake monotonic/signal; exact aggregate arithmetic, no wall-clock SIGALRM certification."

    @case(WEAKNESS)
    def test_save_clock_enter_before_try_retains_pending_untracked(self):
        run = self.runner()
        run.clock.remaining["save"] = 0
        with self.assertRaisesRegex(TimeoutError, "save exhausted"):
            run.save("one", {"data": 1})
        self.assertEqual(run.pending, {"name": "one", "value": {"data": 1}})
        self.assertEqual(run.exceptions, [])
        self.assertFalse(self.journal_path(run).exists())
        self.evidence(self.journal_path(run), run)

    @case(WEAKNESS)
    def test_save_compute_reentry_timeout_after_durable_success(self):
        run = self.runner()
        run.clock.remaining["compute"] = 0
        with self.assertRaisesRegex(TimeoutError, "compute exhausted"):
            run.save("one", {"data": 1})
        self.assertTrue(self.journal_path(run).is_file())
        self.assertIsNone(run.pending)
        self.assertEqual(run.exceptions, [])
        self.assertGreater(run.trace_bytes, 0)
        self.evidence(self.journal_path(run), run)

    @case(PROTECTED)
    def test_save_deadline_inside_try_preserves_pending(self):
        run = self.runner()
        self.h["fsyncdir"] = lambda _: run.clock.expire()
        with self.assertRaisesRegex(TimeoutError, "save aggregate"):
            run.save("one", {"data": 1})
        self.assertIsNotNone(run.pending)
        self.assertEqual(len(run.exceptions), 1)
        self.assertIsNone(run.clock.mode)
        self.evidence(self.journal_path(run), run)

    @case(PROTECTED)
    def test_standard_inert_machine_success_duplicate(self):
        run = self.runner()
        limits = resource.getrlimit(resource.RLIMIT_FSIZE)
        result, value = run.standard("one")
        p = Path(result["path"])
        self.assertEqual(resource.getrlimit(resource.RLIMIT_FSIZE), limits)
        self.assertEqual(value, self.h["snapshot_value"](run.machine))
        old = p.read_bytes()
        self.assertEqual(run.state_refs, [result])
        with self.assertRaises(FileExistsError):
            run.standard("one")
        self.assertEqual(p.read_bytes(), old)
        self.assertEqual(run.pending, {"standard": str(p)})
        self.assertEqual(len(run.exceptions), 1)
        self.evidence(p, run)

    @case(PROTECTED)
    def test_standard_fake_machine_failure_preserves_partial(self):
        run = self.runner()
        limits = resource.getrlimit(resource.RLIMIT_FSIZE)

        def fail(p):
            Path(p).write_bytes(b"{")
            raise OSError("inert machine interrupted")

        run.machine.保存する = fail
        with self.assertRaisesRegex(OSError, "interrupted"):
            run.standard("one")
        p = Path(run.pending["standard"])
        self.assertEqual(p.read_bytes(), b"{")
        self.assertEqual(resource.getrlimit(resource.RLIMIT_FSIZE), limits)
        self.assertEqual(len(run.exceptions), 1)
        self.assertEqual(run.state_refs, [])
        self.evidence(p, run)

    @case(PROTECTED)
    def test_standard_identity_replacement_rejected(self):
        run = self.runner()
        original = run.machine.保存する

        def replace(p):
            other = p.with_name("owned-replacement")
            original(other)
            other.replace(p)

        run.machine.保存する = replace
        with self.assertRaisesRegex(ValueError, "reserved standard identity"):
            run.standard("one")
        self.assertIsNotNone(run.pending)
        self.evidence(Path(run.pending["standard"]), run)

    @case(PROTECTED)
    def test_standard_readback_mismatch_retains_pending(self):
        run = self.runner()
        run.machine.保存する = lambda p: Path(p).write_bytes(b"{}")
        with self.assertRaisesRegex(ValueError, "full live standard"):
            run.standard("one")
        self.assertEqual(len(run.exceptions), 1)
        self.evidence(Path(run.pending["standard"]), run)

    @case(PROTECTED)
    def test_standard_reserved_size_exact_8mib_boundary(self):
        run = self.runner()
        original = os.fstat
        size = [8 * MIB]
        calls = []

        def fstat(fd):
            st = original(fd)
            calls.append(st.st_size)
            if len(calls) % 2 == 0:
                values = list(st)
                values[6] = size[0]
                return os.stat_result(values)
            return st

        with patch.object(os, "fstat", fstat):
            run.standard("exact")
            size[0] += 1
            with self.assertRaisesRegex(ValueError, "reserved standard identity"):
                run.standard("over")
        self.notes["accounting"] = "Synthetic final fstat size; real fixture is tiny. 8MiB accepted, 8MiB+1 rejected."

    @case(WEAKNESS)
    def test_standard_clock_enter_before_pending_and_try(self):
        run = self.runner()
        prior = {"previous": "must retain"}
        run.pending = prior
        run.clock.remaining["save"] = 0
        with self.assertRaisesRegex(TimeoutError, "save exhausted"):
            run.standard("one")
        self.assertIs(run.pending, prior)
        self.assertEqual(run.exceptions, [])
        self.notes.update(pending_is_previous=True, exception_types=[], clock_mode=run.clock.mode)

    @case(WEAKNESS)
    def test_standard_mkdir_before_try_leaves_save_clock_active(self):
        run = self.runner()
        prior = {"previous": "must retain"}
        run.pending = prior
        folder = self.h["ROOT"] / "state_trace" / run.gate["nonce"]
        original = Path.mkdir

        def mkdir(path, *args, **kwargs):
            if path == folder:
                raise OSError("injected mkdir failure")
            return original(path, *args, **kwargs)

        with patch.object(Path, "mkdir", mkdir):
            with self.assertRaisesRegex(OSError, "mkdir failure"):
                run.standard("one")
        self.assertIs(run.pending, prior)
        self.assertEqual(run.exceptions, [])
        self.assertEqual(run.clock.mode, "save")
        self.assertEqual(self.signals.timer, 120)
        self.notes.update(pending_is_previous=True, exception_types=[], clock_mode=run.clock.mode,
                          timer_seconds=self.signals.timer)

    @case(WEAKNESS)
    def test_standard_compute_reentry_timeout_after_durable_success(self):
        run = self.runner()
        run.clock.remaining["compute"] = 0
        with self.assertRaisesRegex(TimeoutError, "compute exhausted"):
            run.standard("one")
        self.assertEqual(len(run.state_refs), 1)
        self.assertIsNone(run.pending)
        self.assertEqual(run.exceptions, [])
        self.evidence(Path(run.state_refs[0]["path"]), run)

    @case(BEHAVIOR)
    def test_pending_nested_failure_save_requires_outer_restoration(self):
        """No live run() invoked: observe Run.save replacement, then explicit caller restore."""
        run = self.runner()
        p = self.journal_path(run)
        with self.short_writes(p):
            with self.assertRaises(OSError):
                run.save("one", {"original": True})
        original_pending = run.pending
        saved_failure = run.save("failure", {"pending_descriptor": original_pending["name"]},
                                 category="failure", codec=False)
        self.assertIsNone(run.pending)
        run.pending = original_pending
        self.assertEqual(run.pending["value"], {"original": True})
        self.assertEqual(len(run.exceptions), 1)
        self.notes.update(original_pending_after_explicit_caller_restore=run.pending,
                          saved_failure_bytes=saved_failure["file"]["bytes"],
                          limitation="Outer live run() failure loop not executed or certified.")
        self.evidence(p, run)


class RecordedResult(unittest.TextTestResult):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.records = []

    def startTest(self, test):
        test._started = time.perf_counter()
        super().startTest(test)

    def record(self, test, status, err=None):
        method = getattr(test, test._testMethodName)
        item = {"id": test._testMethodName, "status": status,
                "kind": getattr(method, "boundary_kind", "unclassified"),
                "seconds": round(time.perf_counter() - test._started, 6),
                "description": method.__doc__, "observed": getattr(test, "notes", {})}
        if err:
            item["exception"] = "".join(traceback.format_exception(*err))
        self.records.append(item)

    def addSuccess(self, test):
        self.record(test, "PASS")
        super().addSuccess(test)

    def addFailure(self, test, err):
        self.record(test, "FAIL", err)
        super().addFailure(test, err)

    def addError(self, test, err):
        if hasattr(test, "_testMethodName"):
            self.record(test, "ERROR", err)
        super().addError(test, err)


def timings():
    """Separate small-fixture timings; no performance extrapolation."""
    with tempfile.TemporaryDirectory(prefix=".timing-fixtures-", dir=OUT) as tmp:
        root = Path(tmp)
        categories = ("source", "state_trace", "failure")
        for category in categories:
            (root / category).mkdir()
        for i in range(48):
            (root / categories[i % 3] / ("%03d.bin" % i)).write_bytes(bytes([i]) * 256)
        payload = json.dumps({"fixture": [{"i": i, "text": "ordinary fixture"} for i in range(128)]},
                             separators=(",", ":")).encode()
        file_path = root / "sync"
        file_path.write_bytes(b"x" * 4096)
        fd = os.open(file_path, os.O_RDONLY)
        dfd = os.open(root, os.O_RDONLY)
        results = {}
        try:
            actions = {
                "full_tree_scan": lambda: {k: sum(p.stat().st_size for p in (root / k).rglob("*") if p.is_file()) for k in categories},
                "lzma_preset0_crc64": lambda: lzma.compress(payload, preset=0, check=lzma.CHECK_CRC64),
                "file_fsync": lambda: os.fsync(fd),
                "directory_fsync": lambda: os.fsync(dfd),
            }
            for name, action in actions.items():
                values = []
                for _ in range(11):
                    start = time.perf_counter_ns()
                    action()
                    values.append(time.perf_counter_ns() - start)
                results[name] = {"samples_ns": values, "median_ns": statistics.median(values),
                                 "min_ns": min(values), "max_ns": max(values)}
        finally:
            os.close(fd)
            os.close(dfd)
        return {"fixture_files": 48, "fixture_bytes": 48 * 256,
                "compression_input_bytes": len(payload),
                "compression_output_bytes": len(lzma.compress(payload, preset=0, check=lzma.CHECK_CRC64)),
                "results": results,
                "limitations": "Small warm fixtures only. No 3520-save workload, scaling claim, power-loss durability proof or native run."}


def main():
    sys.dont_write_bytecode = True
    soft, hard = resource.getrlimit(resource.RLIMIT_AS)
    limit = 512 * MIB
    if hard != resource.RLIM_INFINITY:
        limit = min(limit, hard)
    if soft != resource.RLIM_INFINITY:
        limit = min(limit, soft)
    resource.setrlimit(resource.RLIMIT_AS, (limit, limit))
    before = baseline_precheck()
    OUT.mkdir(exist_ok=True)
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(PureSaveTests)
    log = io.StringIO()
    result = unittest.TextTestRunner(stream=log, verbosity=2, resultclass=RecordedResult).run(suite)
    timing = timings() if result.wasSuccessful() else {"not_run": "test assertion failure"}
    after = baseline_precheck()
    report = {
        "schema": "arc-pinned-pure-save-boundaries-v1",
        "status": "PASS_WITH_OBSERVED_WEAKNESSES" if result.wasSuccessful() else "FAIL",
        "meaning": "PASS certifies assertions about frozen behavior, including explicitly labelled weaknesses; it does not certify a safe live launcher.",
        "python": sys.version.split()[0],
        "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "as_limit_bytes": resource.getrlimit(resource.RLIMIT_AS),
        "process_maxrss_kib_linux": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        "baseline_bytes_before": before, "baseline_bytes_before_report": after,
        "sources": AST_EVIDENCE, "tests_run": result.testsRun,
        "failed_assertions": len(result.failures), "test_errors": len(result.errors),
        "cases": result.records, "timings": timing,
        "scope": {
            "native_HDS_imports": 0, "SDK_imports": 0, "Actions": 0, "live_launcher_runs": 0,
            "source_or_core_modifications": 0, "network_calls": 0, "Git_calls": 0,
            "guard_scans": "Original full-scan AST; no cache, shortcut, pruning or altered function bodies",
            "injections": "Globals use owned temporary roots, mocked disk/MemAvailable and deterministic Clock signals/time. Exact large cap cases use labelled stat/fstat accounting. Standard uses only inert fake machine and identity JSON codec.",
            "failure_evidence": "Expected failure file bytes/prefix/hash and pending/exception state retained in cases before own temporary fixtures are removed.",
        },
        "not_certified": [
            "Native codec behavior or actual HDS machine persistence", "Top-level run failure infinite hold loop",
            "Real SDK/Action or end-to-end learning", "Actual resource exhaustion or host RAM capacity",
            "Real asynchronous signal timing or power-loss durability", "Race-free/atomic filesystem namespace enforcement",
            "3520-write workload timing or large-state scaling", "Restored absolute paths or live launcher readiness",
        ],
    }
    raw = (json.dumps(report, ensure_ascii=False, indent=2) + "\n").encode()
    logdata = log.getvalue().encode()
    if len(raw) + len(logdata) > MIB:
        raise MemoryError("report size cap")
    (OUT / "pure_save_boundaries.json").write_bytes(raw)
    (OUT / "pure_save_boundaries.log").write_bytes(logdata)
    generated = sum(p.stat().st_size for folder in (BASE / "tests", OUT) for p in folder.rglob("*") if p.is_file())
    if generated > 2 * MIB:
        raise MemoryError("tests+results2MiB")
    baseline_precheck()
    print(json.dumps({"status": report["status"], "tests_run": result.testsRun,
                      "weakness_cases": sum(c["kind"] == WEAKNESS for c in result.records),
                      "failed_assertions": len(result.failures), "test_errors": len(result.errors),
                      "generated_bytes": generated, "result": "test_results/pure_save_boundaries.json"}))
    if not result.wasSuccessful():
        print(log.getvalue())
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    raise SystemExit(main())
