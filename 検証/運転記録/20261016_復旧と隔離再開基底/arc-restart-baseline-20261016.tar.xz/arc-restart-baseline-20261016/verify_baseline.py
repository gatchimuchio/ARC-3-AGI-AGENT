#!/usr/bin/env python3
"""Read-only hash, syntax and state-envelope verification; never loads HDS."""
import ast
import hashlib
import json
from pathlib import Path
import resource
import shutil
import sys

HERE = Path(__file__).resolve().parent


def main():
    resource.setrlimit(resource.RLIMIT_AS, (512 * 1048576, 512 * 1048576))
    pins = json.loads((HERE / "pins.json").read_text())
    checks = []
    for pin in pins["files"]:
        path = HERE / pin["destination"]
        if path.is_symlink():
            raise ValueError("Unexpected symlink")
        raw = path.read_bytes()
        assert len(raw) == pin["bytes"], pin["destination"]
        assert hashlib.sha256(raw).hexdigest() == pin["sha256"], pin["destination"]
        if path.suffix == ".py":
            ast.parse(raw, filename=str(path))
        checks.append(pin["destination"])
    raw = (HERE / "state/after_all_queries.standard.json").read_bytes()
    state = json.loads(raw)
    # Inspect only the existing serialized envelope. No native deserializer.
    top = dict(state["__辞書__"])
    identifiers = dict(top["識別子状態"]["__辞書__"])
    ledger_lengths = {key: len(value["__組__"]) for key, value in top["台帳"]["__辞書__"]}
    assert identifiers["経験"] == ledger_lengths["観測台帳"] == 183
    assert identifiers["原理"] == ledger_lengths["原理台帳"] == 16
    assert identifiers["照会"] == identifiers["学習判定"] == 6647
    entries = list(HERE.rglob("*"))
    assert not any(path.is_symlink() for path in entries)
    directory_bytes = sum(path.stat().st_size for path in entries if path.is_file())
    assert directory_bytes <= 32 * 1048576
    disk_free = shutil.disk_usage(HERE).free
    assert disk_free >= 1024 * 1048576
    assert not any(name == "hds学習系統" or name.startswith("hds学習系統.") for name in sys.modules)
    report = {
        "schema": "arc3-isolated-baseline-verification-v1",
        "status": "PASS_BYTES_SYNTAX_AND_SERIALIZED_ENVELOPE_ONLY",
        "verified_file_count": len(checks),
        "frozen_python_file_count": sum(x.startswith("frozen/") and x.endswith(".py") for x in checks),
        "source_python_file_count": sum(x.startswith("source/") and x.endswith(".py") for x in checks),
        "state_bytes": len(raw),
        "state_sha256": hashlib.sha256(raw).hexdigest(),
        "serialized_identifiers": identifiers,
        "serialized_ledger_lengths": ledger_lengths,
        "serialized_state_history_length": len(top["状態履歴"]["__組__"]),
        "directory_bytes": directory_bytes,
        "minimum_free_disk_satisfied": disk_free >= 1024 * 1048576,
        "AS_limit_bytes": resource.getrlimit(resource.RLIMIT_AS)[0],
        "native_HDS_imports": 0,
        "native_state_restore": "NOT_RUN",
        "Query": 0, "Teach": 0, "SDK": 0, "Action": 0,
        "meaning": "183 serialized learning experiences and 16 principles; not 183 solved levels.",
        "old_absolute_paths_recreated": False,
        "original_source_modified": False,
        "capability_improvement_claim": False,
    }
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
