#!/usr/bin/env python3
"""Materialize only pinned bytes. Does not import or execute restored code."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import tarfile

HERE = Path(__file__).resolve().parent
CAP = 32 * 1048576
FLOOR = 1024 * 1048576


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(65536), b""):
            h.update(block)
    return h.hexdigest()


def used_bytes():
    entries = list(HERE.rglob("*"))
    if any(p.is_symlink() for p in entries):
        raise ValueError("Unexpected symlink in isolated baseline")
    return sum(p.stat().st_size for p in entries if p.is_file())


def resource_guard(extra=0):
    if used_bytes() + extra > CAP:
        raise MemoryError("Isolated baseline 32 MiB cap")
    if shutil.disk_usage(HERE).free - extra < FLOOR:
        raise MemoryError("Physical free disk 1 GiB floor")


def checked_write(path, data):
    if path.is_symlink():
        raise ValueError("Destination is a symlink")
    for ancestor in path.parents:
        if ancestor == HERE:
            break
        if ancestor.is_symlink():
            raise ValueError("Destination ancestor is a symlink")
    if path.exists():
        if path.read_bytes() != data:
            raise ValueError("Existing destination differs; no overwrite")
        return
    resource_guard(len(data))
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        if stream.write(data) != len(data):
            raise OSError("Short restore write")
        stream.flush()
        os.fsync(stream.fileno())
    if path.read_bytes() != data:
        raise OSError("Restore readback mismatch")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--recovery-root", type=Path,
                        default=HERE.parent / "arc-preservation-recovery-20261016")
    args = parser.parse_args()
    resource.setrlimit(resource.RLIMIT_AS, (512 * 1048576, 512 * 1048576))
    pins = json.loads((HERE / "pins.json").read_text())
    resource_guard()
    receipts = []
    for archive in pins["archives"]:
        path = args.recovery_root / "archives" / archive["archive"]
        if path.is_symlink() or path.stat().st_size != archive["bytes"] or digest(path) != archive["sha256"]:
            raise ValueError("Archive identity mismatch: " + archive["archive"])
        selected = {x["member"]: x for x in pins["files"] if x["archive"] == archive["archive"]}
        seen = set()
        # Streaming avoids unpacking an archive or touching unselected payloads.
        with tarfile.open(path, "r|*") as stream:
            for member in stream:
                if member.name not in selected:
                    continue
                row = selected[member.name]
                if member.name in seen or not member.isfile() or member.size != row["bytes"]:
                    raise ValueError("Invalid/duplicate selected archive member")
                seen.add(member.name)
                resource_guard(row["bytes"] if not (HERE / row["destination"]).exists() else 0)
                data = stream.extractfile(member).read(row["bytes"] + 1)
                if len(data) != row["bytes"] or hashlib.sha256(data).hexdigest() != row["sha256"]:
                    raise ValueError("Selected member identity mismatch")
                destination = Path(row["destination"])
                if destination.is_absolute() or ".." in destination.parts:
                    raise ValueError("Destination outside isolated baseline")
                checked_write(HERE / destination, data)
                receipts.append({"destination": str(destination), "bytes": len(data),
                                 "sha256": row["sha256"], "status": "HASH_AND_READBACK_MATCH"})
        if seen != set(selected):
            raise FileNotFoundError("Pinned archive members absent")
    receipt = {"schema": "arc3-isolated-restoration-receipt-v1",
               "verified_files": sorted(receipts, key=lambda x: x["destination"]),
               "payload_bytes": sum(x["bytes"] for x in receipts),
               "native_HDS_imports": 0, "native_restores": 0, "Query": 0,
               "Teach": 0, "SDK": 0, "Action": 0, "source_execution": False}
    checked_write(HERE / "restoration_receipt.json",
                  (json.dumps(receipt, ensure_ascii=False, indent=2) + "\n").encode())
    resource_guard()
    print(json.dumps({"verified_files": len(receipts), "payload_bytes": receipt["payload_bytes"],
                      "directory_bytes": used_bytes(), "status": "PINNED_BYTES_ONLY"}))


if __name__ == "__main__":
    main()
