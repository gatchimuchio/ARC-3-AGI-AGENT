# Frozen pure save-boundary tests

Run from this baseline directory:

```sh
python -B tests/test_pure_save_boundaries.py --result-subdir verification_1
```

This command verifies the two whole-source SHA-256 pins before compiling an
explicit AST allowlist. It does **not** import either source module. It loads only:

- `resource_guard_v1.py`: `guard`, `fsyncdir`, `save`
- `column_work_harness_v3.py`: `eq`, `jb`, `sha`, `ref`, `fsyncdir`, `guard`,
  `Clock`, `snapshot_value`, `Run.encoded`, `Run.save`, `Run.standard`

No native HDS, SDK, Action, top-level `run`, `preflight`, `execute`, Git, network,
or live launcher runs. The machine and codec in standard-save tests are inert
stdlib-only fixtures. No frozen source, recovered archive, state or core is edited.

## Meaning of the result

The observed execution completed **38 cases, 0 failed assertions, 0 test errors**.
Twelve cases intentionally assert reproducible weaknesses. The status is therefore
`PASS_WITH_OBSERVED_WEAKNESSES`, **not** a claim that the source is safe to launch,
not an improvement in learned ability, and not an end-to-end runtime pass.

Protected behavior exercised includes full byte readback, duplicate destination
preservation, short-write detection, filesystem-sync failures, strict JSON order
and type comparison, repeated full accounting scans after external file
add/resize/delete, original cap/disk/RAM thresholds, exact deadline arithmetic,
and preservation of partial files/pending state on failures inside the try block.

## Reproduced weaknesses (source unchanged)

1. Harness `guard` accepts a nested symlink. `Run.save` follows a nonce-directory
   symlink to an owned fixture outside the category. The resource guard rejects
   such a symlink on its postwrite scan.
2. Harness `Run.save` calls its guard once and has no postwrite guard. An external
   accounting increase past the total limit during sync is not caught before
   success; a subsequent explicit full guard call rejects it.
3. Harness `guard` enforces only the requested category cap. A different category
   can already exceed its cap while both `guard()` and a different category call
   succeed below the total cap.
4. Harness `guard` accepts negative `extra`; its disk threshold also omits
   prospective `extra` bytes.
5. Harness `Run.save` has no local filename namespace validation. A trusted-caller
   assumption is required; a `../` name escapes the nonce subdirectory in the
   owned test fixture. No production destination was touched.
6. Resource `save` ignores a short reported write count when the complete bytes
   actually landed. Actual partial writes are rejected by full readback.
7. Save deadline exhaustion in `Clock.enter`, before the save try block, bypasses
   that method's exception list; `Run.save` retains its new pending value, while
   `Run.standard` retains the previous pending value.
8. `Run.standard` mkdir failure, also before its try block, leaves the fake save
   clock active, keeps the previous pending value, and records no method exception.
9. For both save methods, exhausted compute time on the final re-entry raises
   after durable output and clearing pending. It is not recorded by the method's
   exception handler; standard's state reference was already appended.

The top-level live failure path was not run. One case shows why a caller must
restore the original pending object after writing a secondary failure journal.
That case explicitly performs a test-side restore and does not certify live `run`.

## Bounded fixtures and evidence

- The process sets both `RLIMIT_AS` limits to at most 512 MiB.
- Full baseline scans enforce the 32 MiB combined cap and actual free-disk floor
  of 1 GiB before tests and before/after report writes.
- Only `tests/` and `test_results/` are written. Test fixtures are owned temporary
  directories underneath `test_results/` and are cleaned by `TemporaryDirectory`.
- Production threshold constants remain unchanged. Large cap tests use explicitly
  labelled synthetic stat/fstat sizes, not giant or sparse fixture files.
- The exact raw-journal 16 MiB limit is exercised with a compressible in-memory
  value; the persisted fixture is tiny. The 24 MiB aggregate counter is synthetic.
- Disk/RAM conditions and clock signal/time values are deterministic test doubles.
- The JSON report retains expected-failure file bytes (full hex up to 4096 bytes),
  hashes, pending/exception states and each assertion outcome before cleanup.
  The `bytes` field means content length in bytes; `full_hex` contains the bytes.
- Whole-source and selected-definition AST digests appear in the report.
- Source+results are far below the 2 MiB generated-file cap.

## Timing and limitations

`pure_save_boundaries.json` measures a full 48-file / 12,288-byte fixture scan,
LZMA preset-0/CRC64 compression (4511-byte input), file fsync and directory fsync
separately, with 11 samples each. These are small, warm filesystem measurements,
not 3520-save estimates. Very small fsync times do not prove physical media
durability on this filesystem.

Not certified: native codec or actual HDS persistence, real asynchronous signals,
host exhaustion behavior, power-loss durability, atomic/race-free namespaces,
live launcher path relocation, large-state scaling, or learning ability.

Reports: `test_results/pure_save_boundaries.json` and
`test_results/pure_save_boundaries.log`.

The full-hex-enhanced second run and its exact runner bytes are also preserved in
`test_results/previous_runs/enhanced_run_2/`. A new run must use a new leaf name for
`--result-subdir`; the script refuses to overwrite any existing report. The initial
run report/log were overwritten before preservation was requested; its observed
exit/status/counts and hashes, and that provenance limitation, are recorded in
`test_results/initial_run_provenance_limit.json`. No missing report is reconstructed.
