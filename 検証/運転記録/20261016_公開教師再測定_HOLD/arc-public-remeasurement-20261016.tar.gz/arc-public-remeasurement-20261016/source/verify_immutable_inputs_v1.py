import hashlib,json
from pathlib import Path
from remeasure_v1 import D,R,save
checks=[]
def verify(p,n,expected,group):
 b=p.read_bytes();actual=hashlib.sha256(b).hexdigest();checks.append({'group':group,'path':str(p.relative_to(R)),'bytes':len(b),'expected_bytes':n,'sha256':actual,'expected_sha256':expected,'unchanged':len(b)==n and actual==expected})
for r in json.loads((R/'authority_recovery_verification.json').read_bytes()):verify(Path(r['path']),r['bytes'],r['sha256'],'authority')
for r in json.loads((R/'main_recovery_verification.json').read_bytes())['files']:verify(R/'main'/r['path'],r['bytes'],r['sha256'],'recovered_main')
for r in json.loads((R/'own_source_recovery_verification.json').read_bytes())['files']:verify(Path(r['recovered_path']),r['bytes'],r['sha256'],'recovered_own_source')
for r in json.loads((R/'recovered_archive_identities.json').read_bytes())['files']:
 if Path(r['file']).name in('ARC3_目標相対操作学習_20261013_v2.tar.gz','ARC3_goalset4_learning_checkpoint_20261013.tar.gz','preparation_preservation_learning_checkpoint.tar.gz','saved118_diagnostic_v2_delivery.tar.xz'):verify(Path(r['file']),r['bytes'],r['sha256'],'source_archive')
missing=json.loads((D/'inputs/historical_teacher_pack.json').read_bytes())['analysis'];report={'status':'PASS'if all(r['unchanged']for r in checks)and not Path(missing['path']).exists()else'HOLD','all_original_bytes_unchanged':all(r['unchanged']for r in checks),'checks':checks,'historical_missing_path_exists':Path(missing['path']).exists(),'historical_missing_file':missing,'scope':'Recovered authority/main/own-source and four used archives. No core import, native restoration, Teach, Query, SDK, Action or original write was performed.'}
print(save('evidence/immutable_inputs_verification_v1.json',report))
assert report['status']=='PASS'
