"""NEW offline public pixel remeasurement. No historical evidence replacement.
Only stdlib and pinned existing pure AST functions; no native HDS, SDK or Action.
"""
import ast, collections, copy, datetime, hashlib, itertools, json, lzma
import os, pathlib, resource, signal, sys, tarfile, time, traceback
D=pathlib.Path(__file__).resolve().parent.parent
R=D.parent/'arc-preservation-recovery-20261016'
M=1<<20
CAP=24*M
RAW_ARCHIVE='ARC3_目標相対操作学習_20261013_v2.tar.gz'
RAW_MEMBER='arc-column-teacher-recovery-20261013/public-recording-v2.jsonl'
RAW_BYTES=67880086
RAW_SHA='e26ff1df251af042911126a067c08ee25973b01d3389269472eed6859a4383f2'
POOL_KEYS=('状態','候補数','全数確認した相異なる割当数','候補','不採用理由集計','実行許可')
def sha(b):return hashlib.sha256(b).hexdigest()
def jb(v):return (json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
def eq(a,b):return jb(a)==jb(b)
def require(c,s):
 if not c:raise ValueError(s)
def guard(extra=0):
 n=sum(p.stat().st_size for p in D.rglob('*')if p.is_file())
 require(n+extra<=CAP,'24MiB work-directory budget')
 require(os.statvfs(D).f_bavail*os.statvfs(D).f_frsize-extra>=1<<30,'1GiB disk floor')
 return n
def save(name,value):
 b=jb(value);guard(len(b));p=D/name
 with p.open('xb')as f:f.write(b)
 return {'path':name,'bytes':len(b),'sha256':sha(b)}
def untag(x):
 if isinstance(x,list):return[untag(v)for v in x]
 if isinstance(x,dict):
  if set(x)=={'__辞書__'}:return{untag(k):untag(v)for k,v in x['__辞書__']}
  if set(x)=={'__組__'}:return tuple(untag(v)for v in x['__組__'])
  if set(x)in({'__データ型__','値'},{'__列挙__','値'}):return untag(x['値'])
  return{k:untag(v)for k,v in x.items()}
 return x
def packet(p):
 z=lzma.LZMADecompressor(memlimit=128*M);b=z.decompress(p.read_bytes(),max_length=16*M+1)
 require(z.eof and not z.unused_data and z.check==lzma.CHECK_CRC64 and len(b)<=16*M,'packet CRC EOF limit')
 return untag(json.loads(b))
def bind():
 manifest=json.loads((D/'evidence/input_manifest.json').read_bytes())
 for r in manifest:
  p=D/r['local'];require(not p.is_symlink(),'source symlink');b=p.read_bytes()
  require(len(b)==r['bytes']and sha(b)==r['sha256'],'input pin '+r['local'])
 family=(D/'inputs/family.py').read_bytes();common=(D/'inputs/common.py').read_bytes()
 ft=ast.parse(family);ct=ast.parse(common)
 names={'知覚不適用','記号を読む','容器外形を観測する','図式を観測する','選択を読む'}
 nodes=[copy.deepcopy(n)for n in ft.body if isinstance(n,(ast.ClassDef,ast.FunctionDef))and n.name in names]
 require(len(nodes)==5,'five pure perception definitions')
 ns={'Counter':collections.Counter,'deepcopy':copy.deepcopy,'itertools':itertools,'ast':ast,'read_pin':lambda r:family,'FAMILY':{'path':'pinned family.py'}}
 exec(compile(ast.Module(body=nodes,type_ignores=[]),'pinned family AST','exec'),ns)
 cnames={'exact','require','_bind_fixed','goalset_pool','slot_map','skeleton','token_key','goalset_base','hit','goalset_preconditions'}
 cnodes=[copy.deepcopy(n)for n in ct.body if isinstance(n,ast.FunctionDef)and n.name in cnames]
 require(len(cnodes)==len(cnames),'pure common definitions')
 # Existing constants only, no runtime semantic vocabulary is added.
 for n in ct.body:
  if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='CLASSES'for t in n.targets):ns['CLASSES']=ast.literal_eval(n.value)
 exec(compile(ast.Module(body=cnodes,type_ignores=[]),'pinned common AST','exec'),ns)
 ns['_FIXED']=ns['_bind_fixed']()
 imports=lambda tree:[ast.unparse(n)for n in tree.body if isinstance(n,(ast.Import,ast.ImportFrom))]
 report={'family_whole_module_imports':imports(ft),'common_whole_module_imports':imports(ct),'family_selected_definitions':sorted(names),'common_selected_definitions':sorted(cnames),'common_top_level_loads_excluded':['legacy=load_pure(...)','_FIXED=_bind_fixed()'],'enumeration':'Existing common._bind_fixed extracts existing full-permutation suffix; no candidate pruning.','executed_modules':['Python standard library'],'native_HDS_imports':0,'SDK_imports':0}
 return ns,manifest,report

def pixelbytes(frame):
 require(type(frame)is list and len(frame)==64 and all(type(r)is list and len(r)==64 for r in frame),'public frame must be64x64')
 require(all(type(v)is int and 0<=v<=15 for row in frame for v in row),'public pixel integer range0..15')
 return bytes(v for row in frame for v in row)
def known(v):return {'status':'known','value':v}
def unknown(reason):return {'status':'unknown','reason':reason}
def na(reason):return {'status':'not_applicable','reason':reason}
def value(v):return v.get('value')if v['status']=='known'else None

def observe(frame,ns):
 pixels=pixelbytes(frame);out={'pixel_sha256_uint8':sha(pixels)}
 try:
  scene=ns['図式を観測する'](frame);out['scene']=known(scene)
 except (ValueError,TypeError,KeyError,IndexError)as e:
  out['scene']=unknown({'type':type(e).__name__,'message':str(e)});out['selection']=unknown('scene unavailable');return out
 try:out['selection']=known(ns['選択を読む'](frame,scene))
 except (ValueError,TypeError,KeyError,IndexError)as e:out['selection']=unknown({'type':type(e).__name__,'message':str(e)})
 return out

def all_status(xs):
 if not xs:return unknown('empty response phase list')
 if any(x['status']=='not_applicable'for x in xs):return na('at least one phase outside applicable boundary')
 if any(x['status']!='known'for x in xs):return unknown('at least one phase unknown; no false coercion')
 require(all(type(x['value'])is bool for x in xs),'boolean phase values')
 return known(all(x['value']for x in xs))

def continuity(before,after):
 # Public metadata only; game identifiers are retained as provenance, never consulted.
 a=before.get('score',before.get('levels_completed'));b=after.get('score',after.get('levels_completed'))
 if type(a)is not int or type(b)is not int:return unknown('public completion count unavailable')
 if after.get('full_reset')is not False:return unknown('full_reset is not explicit false')
 if a!=b:return na('public completion count changed')
 if not before.get('guid')or before.get('guid')!=after.get('guid'):return unknown('public instance continuity unavailable')
 return known(True)

def measure_phase(before_obs,after_obs,targets,cont,ns):
 scene=value(after_obs['scene']);bs=value(before_obs['scene']);sel=after_obs['selection']
 if bs is None:return {'preservation':unknown('before scene unknown'),'filled_slots':[],'selection_display':unknown('before scene unknown'),'clicked_inventory_selection':unknown('before scene unknown'),'broken_slots':unknown('before scene unknown')}
 filled=[(k,t)for k,t in ns['slot_map'](bs).items()if t is not None]
 if scene is None:
  slots=[{'position':list(k),'before_token':t,'preserved':unknown('after scene unknown')}for k,t in filled]
  result={'preservation':unknown('after scene unknown'),'filled_slots':slots,'broken_slots':unknown('after scene unknown')}
 else:
  aft=ns['slot_map'](scene);slots=[{'position':list(k),'before_token':t,'after_token':aft.get(k),'after_position_present':k in aft,'preserved':known(k in aft and eq(aft[k],t))}for k,t in filled]
  result={'preservation':known(all(x['preserved']['value']for x in slots)),'filled_slots':slots,'broken_slots':known([x['position']for x in slots if not x['preserved']['value']]),'empty_preservation_support':not bool(filled)}
 result['selection_display']=known(value(sel)is not None)if sel['status']=='known'else unknown('after selection unknown')
 result['clicked_inventory_selection']=known(bool(targets)and eq(value(sel),targets[0]))if sel['status']=='known'and len(targets)<=1 else unknown('selection or clicked inventory ambiguous')
 # Raw pixel observations survive even if a public level transition makes the relation inapplicable.
 for key in ('preservation','selection_display','clicked_inventory_selection'):
  result['raw_'+key]=copy.deepcopy(result[key])
  if cont['status']!='known':result[key]=copy.deepcopy(cont)
 return result

def compare(actual,expected):
 if isinstance(actual,dict)and actual.get('status')in('known','unknown','not_applicable'):
  if actual['status']!='known':return {'status':actual['status'],'expected':expected,'actual':actual}
  actual=actual['value']
 if expected is None and actual is not None:return {'status':'unknown','reason':'historical null has no known scalar value','expected':expected,'actual':actual}
 return {'status':'match'if eq(actual,expected)else'mismatch','expected':expected,'actual':actual}

def compact_obs(obs,scenes):
 out=copy.deepcopy(obs)
 if obs['scene']['status']=='known':
  scene=value(obs['scene']);key=sha(jb(scene));scenes.setdefault(key,scene);out['scene']={'status':'known','scene_ref':key}
 return out

def main(run_name):
 started=time.monotonic();utc=datetime.datetime.now(datetime.timezone.utc).isoformat();resource.setrlimit(resource.RLIMIT_AS,(512*M,512*M));signal.alarm(600);guard()
 ns,manifest,imports=bind();pack=json.loads((D/'inputs/historical_teacher_pack.json').read_bytes());ls=json.loads((D/'inputs/historical_ls_analysis.json').read_bytes())
 require(len(pack['all117'])==117,'117 diagnostic records');cases={r['row']:r for r in pack['all117']};require(len(cases)==117,'117 distinct rows')
 pts={r:packet(D/('inputs/pt_case_%02d.json.xz'%r))for r in cases if cases[r]['source']=='PT'}
 lsrows={r['行']:r for r in ls['全行']};rows=[];scenes={};pools={};cache={};obs_cache={};checks=[]
 def check(label,actual,expected):
  c=compare(actual,expected);c['field']=label;checks.append(c);return c
 def obs(frame):
  b=pixelbytes(frame)
  if b not in obs_cache:obs_cache[b]=observe(frame,ns)
  return copy.deepcopy(obs_cache[b])
 def pool_for(scene):
  key=sha(jb(scene))
  if key not in pools:pools[key]=ns['goalset_pool'](scene,{False:'出力',True:'参照'})
  return key,pools[key]
 previous=None;previous_ref=None;h=hashlib.sha256();offset=0;linecount=0;totalphases=0
 with tarfile.open(R/'archives'/RAW_ARCHIVE,'r|gz')as tar:
  for member in tar:
   if member.name!=RAW_MEMBER:continue
   require(member.isfile()and member.size==RAW_BYTES,'raw member type/size')
   f=tar.extractfile(member)
   for index,line in enumerate(f):
    h.update(line);ref={'row':index,'offset':offset,'bytes':len(line),'sha256':sha(line)};offset+=len(line);linecount+=1
    # Every corpus byte is hashed. Only requested diagnostics and their immediate before rows are parsed.
    if index not in cases and index+1 not in cases:previous=None;previous_ref=None;continue
    data=json.loads(line)['data'];frames=data.get('frame');require(type(frames)is list and frames,'all response frames nonempty')
    ref['phases']=len(frames)
    if index in cases:
     guard();require(previous is not None and previous_ref['row']==index-1,'immediate previous row terminal frame, never older carry-forward')
     case=cases[index];m=case['measurement'];before=obs(previous['frame'][-1]);bs=value(before['scene']);require(bs is not None,'before scene parse')
     pkey,pool=pool_for(bs);slots=ns['slot_map'](bs);filled={k:t for k,t in slots.items()if t is not None};empty=[k for k,t in slots.items()if t is None]
     action=data.get('action_input');require(type(action)is dict,'row action_input');ad=action.get('data');pt=(ad.get('x'),ad.get('y'))if type(ad)is dict else(None,None)
     coord=all(type(v)is int and 0<=v<64 for v in pt);targets=[t for t in bs['在庫群']if coord and ns['hit'](t['位置'],pt)];targetslots=[{'位置':list(k),'記号':v}for k,v in slots.items()if coord and ns['hit'](k,pt)]
     target_kind='実在庫'if len(targets)==1 and not targetslots else '実空欄'if len(targetslots)==1 and targetslots[0]['記号']is None and not targets else '既記入枠'if len(targetslots)==1 and not targets else '在庫/枠外'if not targets and not targetslots else 'UNKNOWN'
     reasons=[]
     if pool['候補数']==0:reasons.append('before成立可能目標集合非空未成立')
     click=type(action.get('id'))is int and action['id']==6 and 6 in previous.get('available_actions',[])
     if not click:reasons.append('既学習クリック/available境界外')
     if not coord:reasons.append('before実クリック座標UNKNOWN')
     selectionknown=before['selection']['status']=='known';selected=value(before['selection'])
     if not selectionknown:reasons.append('before可視在庫選択UNKNOWN')
     purepre=None
     if pool['候補数']>0:
      so={'selection':selected}if selectionknown else{'selection_unknown':before['selection']}
      try:purepre=ns['goalset_preconditions'](bs,so,pool['候補'],action)
      except(ValueError,KeyError,TypeError)as e:purepre={'UNKNOWN':str(e)}
     prep=not reasons and bool(empty)and selectionknown and selected is None and len(targets)+len(targetslots)<=1
     repair=not reasons and bool(empty)and selectionknown and selected is not None and target_kind=='実空欄'
     broad=not reasons and bool(empty)and bool(filled)
     measured={'pool':pool['候補数'],'filled':len(filled),'empty':len(empty),'selection_known':selectionknown,'selected_before':selected,'action':action,'target_kind':target_kind,'target_inventory':targets,'target_slots':targetslots,'before_reasons':reasons,'prep_before':prep,'repair_before':repair,'broad_preservation_before':broad,'phases':len(frames)}
     fieldchecks={k:compare(v,m.get(k))for k,v in measured.items()}
     for k,c in fieldchecks.items():checks.append({'field':'pack.'+k,**c})
     check('pack.raw_row',ref,{'row':index,**pack['raw_rows_verified'][str(index)]})
     cont=continuity(previous,data);phases=[];local=[]
     for phase,frame in enumerate(frames):
      after=obs(frame);q=measure_phase(before,after,targets,cont,ns);totalphases+=1
      fields={'selection_per_phase':q['selection_display'],'clicked_inventory_selection_per_phase':q['clicked_inventory_selection'],'preservation_per_phase':q['preservation'],'visible_selection_all_phases':after['selection'],'broken_per_phase':q['broken_slots']}
      fc={}
      for k,v in fields.items():
       expected=m[k][phase]if phase<len(m[k])else{'missing_phase':phase};c=compare(v,expected);fc[k]=c;checks.append({'field':'pack.'+k,**c})
      phases.append({'phase':phase,'json_path':['data','frame',phase],'observation':compact_obs(after,scenes),'relations':q,'comparisons':fc})
     check('pack.after_phase_coverage',[len(m[k])for k in ('selection_per_phase','clicked_inventory_selection_per_phase','preservation_per_phase','visible_selection_all_phases','broken_per_phase')],[len(frames)]*5)
     sourcechecks=[]
     def sc(k,a,b):
      c=compare(a,b);sourcechecks.append({'field':k,**c});checks.append({'field':case['source']+'.'+k,**c})
     if case['source']=='PT':
      packet_=pts[index];en=packet_['全pool包絡'];o=packet_['教師候補観測'];saved_before=o['全前相'][-1]
      sc('before_raw_line',{k:previous_ref[k]for k in('offset','bytes','sha256')},en['raw_row']);sc('rows',[index-1,index],[en['before_row'],en['action_row']]);sc('before_phase',len(previous['frame'])-1,en['phase']);sc('before_pixel_sha',before['pixel_sha256_uint8'],en['frame_sha256_uint8']);sc('before_scene',bs,saved_before['scene']);sc('before_selection',before['selection'],saved_before.get('selection'));sc('action_input',action,o['公開Action'])
      for k in POOL_KEYS:sc('whole_pool.'+k,pool[k],en['goal_pool'][k])
      expectedphases=o['全後相'];sc('after_phase_count',len(phases),len(expectedphases))
      for i,q in enumerate(phases):
       if i>=len(expectedphases):continue
       old=expectedphases[i];ob=q['observation'];sc('after.phase',i,old['phase']);sc('after.pixel_sha',ob['pixel_sha256_uint8'],old['frame_sha256_uint8'])
       if 'scene'in old:sc('after.scene',scenes.get(ob['scene'].get('scene_ref')),old['scene']);sc('after.selection',ob['selection'],old.get('selection'))
       else:sc('after.unknown',ob['scene'].get('reason'),old.get('unknown'))
     else:
      oldbefore=lsrows[index-1];oldafter=lsrows[index];pb=oldbefore['全相'][-1]
      sc('before_raw_line',{k:previous_ref[k]for k in('offset','bytes','sha256')},{'offset':oldbefore['byte_offset'],'bytes':oldbefore['bytes'],'sha256':oldbefore['lineSHA256']});sc('after_raw_line',{k:ref[k]for k in('offset','bytes','sha256')},{'offset':oldafter['byte_offset'],'bytes':oldafter['bytes'],'sha256':oldafter['lineSHA256']});sc('before_phase',len(previous['frame'])-1,pb['相']);sc('before_pixel_sha',before['pixel_sha256_uint8'],pb['画素SHA256']);oldscene=ls['全場面候補集合'][m['all_pool_reference']['before_scene_key']];sc('before_scene',bs,oldscene['場面']);sc('before_selection',before['selection'],pb['測定'].get('在庫選択'));sc('action_input',action,oldafter['公開metadata']['action_input'])
      if oldscene.get('候補集合')is not None:
       for k in POOL_KEYS:sc('whole_pool.'+k,pool[k],oldscene['候補集合'][k])
      else:sc('whole_pool_missing',unknown('LS saved scene has no pool; new full enumeration retained'),None)
      expectedphases=oldafter['全相'];sc('after_phase_count',len(phases),len(expectedphases))
      for i,q in enumerate(phases):
       if i>=len(expectedphases):continue
       old=expectedphases[i];ob=q['observation'];sc('after.phase',i,old['相']);sc('after.pixel_sha',ob['pixel_sha256_uint8'],old['画素SHA256']);om=old['測定']
       if '場面参照'in om:sc('after.scene',scenes.get(ob['scene'].get('scene_ref')),ls['全場面候補集合'][om['場面参照']]['場面']);sc('after.selection',ob['selection'],om.get('在庫選択'))
       else:sc('after.unknown',ob['scene'].get('reason',{}).get('message'),om.get('UNKNOWN'))
     rows.append({'source':case['source'],'row':index,'before_row':previous_ref,'action_row':ref,'before_observation':compact_obs(before,scenes),'before_measurement':measured,'whole_pool_ref':pkey,'existing_common_preconditions':purepre,'public_continuity':cont,'all_after_phases':phases,'pack_before_comparisons':fieldchecks,'source_comparisons':sourcechecks})
     print(json.dumps({'row':index,'phases':len(frames),'rows_done':len(rows)},ensure_ascii=False),flush=True)
    previous={'frame':[frames[-1]],**{k:v for k,v in data.items()if k!='frame'}};previous_ref=ref
    # Preserve previous full phase count separately; frame stores terminal only to bound memory.
    previous['frame_count']=len(frames)
   break
 require(offset==RAW_BYTES and h.hexdigest()==RAW_SHA,'entire streamed raw corpus SHA/size')
 require(len(rows)==len(cases),'all diagnostic rows completed')
 # Historic phase numbers refer to complete prior response count, not retained single terminal frame.
 # Readback assertions below use before_row.phases for coverage; pixel selection always terminal.
 field_counts={}
 for c in checks:field_counts.setdefault(c['field'],collections.Counter())[c['status']]+=1
 teaching=[];by={(r['source'],r['row']):r for r in rows}
 for i,t in enumerate(pack['teachers']):
  r=by[t['source'],t['row']];preparation=t['boundary']==pack['preparation_boundary'];key='clicked_inventory_selection'if preparation else'preservation';result=all_status([p['relations'][key]for p in r['all_after_phases']]);expected=next(iter(t['expected_output'].values()));co=compare(result,expected)
  eligibility=r['before_measurement']['prep_before']if preparation else r['before_measurement']['broad_preservation_before']and r['existing_common_preconditions']is not None and r['existing_common_preconditions'].get('保存操作区分')is not None
  teaching.append({'projection_ordinal':i,'source':t['source'],'row':t['row'],'relation':'preparation'if preparation else'preservation','eligible_before':eligibility,'phase_count':len(r['all_after_phases']),'outcome':result,'comparison':co})
 summary={'diagnostics':len(rows),'after_phases':totalphases,'before_terminal_frames':len(rows),'teaching_projections':len(teaching),'distinct_teaching_source_actions':len({(r['source'],r['row'])for r in teaching}),'teaching':dict(collections.Counter(r['comparison']['status']for r in teaching)),'field_totals':dict(collections.Counter(c['status']for c in checks)),'fields':{k:dict(v)for k,v in sorted(field_counts.items())},'phase_observation_status':dict(collections.Counter(p['observation']['scene']['status']for r in rows for p in r['all_after_phases']))}
 mismatches=[{'field':c['field'],'expected':c.get('expected'),'actual':c.get('actual')}for c in checks if c['status']=='mismatch']
 status='HOLD'if mismatches or any(t['comparison']['status']!='match'or not t['eligible_before']for t in teaching)else'REMEASUREMENT_COMPLETE_WITH_EXPLICIT_UNKNOWNS'
 result={'schema':'public-prepsave-remeasurement-20261016-v1','status':status,'new_evidence':True,'historical_analysis_recovered':False,'missing_historical_analysis':pack['analysis'],'raw_source':{'archive':RAW_ARCHIVE,'member':RAW_MEMBER,'bytes':offset,'sha256':h.hexdigest(),'lines':linecount,'materialized':False},'input_manifest':manifest,'import_graph':imports,'summary':summary,'all117':rows,'scene_table':scenes,'whole_pool_table':pools,'teaching50':teaching,'mismatches':mismatches,'limitations':['New offline remeasurement, never the missing historical analysis or its byte identity.','No HDS restoration, Teach, Query, SDK, Action, live world execution or capability claim.','Game identifiers are provenance only and never enter perception, enumeration or relation functions.','Every selected response phase retained; unknown and non-applicable remain distinct from false.','Preparation20 and preservation30 are correlated projections of35 historical source Actions, separate from117 diagnostics.','Raw visual preservation of zero filled slots is vacuous and carries no positive preservation support.','Fixed pixel grammar and full enumeration are existing bounded hypotheses, not new learned vocabulary.']}
 out=save('evidence/'+run_name+'.json',result)
 meta={'started_utc':utc,'elapsed_seconds':time.monotonic()-started,'maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'address_space_limit_bytes':512*M,'timeout_seconds':600,'workdir_cap_bytes':CAP,'disk_floor_bytes':1<<30,'output':out,'input_manifest_after':[]}
 for r in manifest:
  b=(D/r['local']).read_bytes();require(sha(b)==r['sha256'],'input changed');meta['input_manifest_after'].append({'path':r['local'],'sha256':sha(b)})
 save('evidence/'+run_name+'_run.json',meta);signal.alarm(0);print(json.dumps({'status':status,'summary':summary,'output':out},ensure_ascii=False),flush=True)
 return result
if __name__=='__main__':
 run=sys.argv[1]if len(sys.argv)>1 else'public_prepsave_remeasurement_20261016_v1'
 try:main(run)
 except BaseException:
  signal.alarm(0)
  save('evidence/'+run+'_failure.json',{'status':'HOLD','traceback':traceback.format_exc()});raise
