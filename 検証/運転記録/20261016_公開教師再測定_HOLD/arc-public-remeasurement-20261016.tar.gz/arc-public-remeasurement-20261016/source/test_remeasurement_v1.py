import copy,json,resource,signal,sys,unittest
from remeasure_v1 import D,bind,known,unknown,na,all_status,measure_phase,pixelbytes,observe,save
from consumer_contract_v1 import validate_row,inspect_for_offline_evidence,admit_to_runtime
resource.setrlimit(resource.RLIMIT_AS,(512<<20,512<<20));signal.alarm(600)
class Regression(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.ns,_,_=bind();cls.data=json.loads((D/'evidence/public_prepsave_remeasurement_20261016_v1.json').read_bytes());cls.contract=json.loads((D/'evidence/new_consumer_contract_v1.json').read_bytes())
 def test_complete_contract_retains_hold(self):
  r=inspect_for_offline_evidence(D/'evidence/public_prepsave_remeasurement_20261016_v1.json',D/'evidence/new_consumer_contract_v1.json');self.assertEqual(r['status'],'HOLD');self.assertFalse(r['runtime_admission'])
 def test_omitted_middle_phase_rejected(self):
  r=copy.deepcopy(self.data['all117'][0]);r['all_after_phases'].pop(1)
  with self.assertRaisesRegex(ValueError,'omitted'):validate_row(r,self.contract['rows'][0])
 def test_duplicate_phase_rejected(self):
  r=copy.deepcopy(self.data['all117'][0]);r['all_after_phases'][1]['phase']=0
  with self.assertRaisesRegex(ValueError,'duplicate'):validate_row(r,self.contract['rows'][0])
 def test_reordered_phase_rejected(self):
  r=copy.deepcopy(self.data['all117'][0]);r['all_after_phases'][0],r['all_after_phases'][1]=r['all_after_phases'][1],r['all_after_phases'][0]
  with self.assertRaisesRegex(ValueError,'reordered'):validate_row(r,self.contract['rows'][0])
 def test_omitted_filled_slot_rejected(self):
  i=next(i for i,r in enumerate(self.data['all117'])if r['before_measurement']['filled']);r=copy.deepcopy(self.data['all117'][i]);r['all_after_phases'][0]['relations']['filled_slots'].pop()
  with self.assertRaisesRegex(ValueError,'filled'):validate_row(r,self.contract['rows'][i])
 def test_duplicate_filled_slot_rejected(self):
  i=next(i for i,r in enumerate(self.data['all117'])if r['before_measurement']['filled']>1);r=copy.deepcopy(self.data['all117'][i]);slots=r['all_after_phases'][0]['relations']['filled_slots'];slots[1]=copy.deepcopy(slots[0])
  with self.assertRaisesRegex(ValueError,'duplicated'):validate_row(r,self.contract['rows'][i])
 def test_malformed_pixel_frame_rejected(self):
  with self.assertRaises(ValueError):pixelbytes([[0]])
 def test_boolean_pixel_rejected(self):
  f=[[0]*64 for _ in range(64)];f[0][0]=True
  with self.assertRaises(ValueError):pixelbytes(f)
 def test_ambiguous_background_unknown(self):
  f=[[0]*32+[1]*32 for _ in range(64)];o=observe(f,self.ns);self.assertEqual(o['scene']['status'],'unknown')
 def test_ambiguous_selection_raises(self):
  f=[[0]*64 for _ in range(64)];items=[]
  for x,c in((10,2),(20,3)):
   for y in range(9,15):
    for xx in range(x-1,x+5):f[y][xx]=4 if y in(9,14)or xx in(x-1,x+4)else c
   items.append({'位置':[x,10],'記号':{'色':c,'中空':False}})
  with self.assertRaisesRegex(ValueError,'複数候補'):self.ns['選択を読む'](f,{'在庫群':items,'背景色':0})
 def test_unknown_never_false(self):self.assertEqual(all_status([known(False),unknown('ambiguous')])['status'],'unknown')
 def test_nonapplicable_distinct(self):self.assertEqual(all_status([known(False),na('transition')])['status'],'not_applicable')
 def test_empty_phases_unknown(self):self.assertEqual(all_status([])['status'],'unknown')
 def test_middle_failure_retained(self):self.assertEqual(all_status([known(True),known(False),known(True)]),known(False))
 def test_every_filled_slot_measured(self):
  scene={'目標列':[2],'容器群':[{'色':3,'位置':[1,1],'起点':True,'枠群':[{'位置':[4,4],'記号':{'色':2,'中空':False}}]}],'在庫群':[]};after=copy.deepcopy(scene);after['容器群'][0]['枠群'][0]['記号']={'色':1,'中空':False}
  q=measure_phase({'scene':known(scene),'selection':known(None)},{'scene':known(after),'selection':known(None)},[],known(True),self.ns);self.assertEqual(q['preservation'],known(False));self.assertEqual(q['broken_slots'],known([[4,4]]))
 def test_runtime_admission_refused(self):
  with self.assertRaisesRegex(ValueError,'HOLD'):admit_to_runtime(self.data)
 def test_game_identifier_never_in_perception(self):
  # Pure functions accept only pixels/scene; metadata labels are outside their signature.
  import inspect
  self.assertEqual(list(inspect.signature(self.ns['図式を観測する']).parameters),['frame'])
if __name__=='__main__':
 suite=unittest.defaultTestLoader.loadTestsFromTestCase(Regression);result=unittest.TextTestRunner(verbosity=2).run(suite)
 report={'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'successful':result.wasSuccessful(),'details':[{'test':str(t),'traceback':s}for t,s in result.failures+result.errors]}
 print(save('evidence/regression_v1.json',report));sys.exit(not result.wasSuccessful())
