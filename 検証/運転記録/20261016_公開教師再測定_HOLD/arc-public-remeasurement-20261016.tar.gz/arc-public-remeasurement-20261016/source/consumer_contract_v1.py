"""NEW offline diagnostic consumer. Does not repair or bypass historical catalog gates."""
import hashlib,json
from pathlib import Path

def require(x,message):
 if not x:raise ValueError(message)
def canonical(v):return(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
def digest(b):return hashlib.sha256(b).hexdigest()
def validate_row(row,pin):
 require(row['source']==pin['source']and row['row']==pin['row'],'row identity')
 require(row['before_row']==pin['before_row']and row['action_row']==pin['action_row'],'raw row join')
 phases=row['all_after_phases']
 require(len(phases)==pin['after_phase_count'],'omitted or extra response phase')
 require([p['phase']for p in phases]==list(range(pin['after_phase_count'])),'duplicate or reordered response phase')
 require([p['observation']['pixel_sha256_uint8']for p in phases]==pin['all_phase_pixel_sha256'],'all phase pixel pins')
 filled=row['before_measurement']['filled']
 for p in phases:
  slots=p['relations']['filled_slots']
  require(len(slots)==filled,'omitted before-filled slot')
  require([[x['position'],x['before_token']]for x in slots]==pin['before_filled_slots'],'omitted, duplicated, or reordered before-filled identity')
  for key in('selection_display','clicked_inventory_selection','preservation'):
   q=p['relations'][key];require(q['status']in('known','unknown','not_applicable'),'three-way observation status')
   if q['status']=='known':require(type(q['value'])is bool,'no boolean coercion')
   else:require('value'not in q,'unknown/non-applicable cannot carry false value')
 return True

def inspect_for_offline_evidence(path,contract_path):
 c=json.loads(Path(contract_path).read_bytes());b=Path(path).read_bytes()
 require(len(b)==c['artifact']['bytes']and digest(b)==c['artifact']['sha256'],'new artifact integrity')
 v=json.loads(b);require(v['schema']==c['schema'],'new schema')
 require(v['historical_analysis_recovered']is False,'must not claim historical recovery')
 require(v['raw_source']['sha256']==c['raw_corpus_sha256'],'whole-corpus provenance')
 require(len(v['all117'])==len(c['rows']),'all diagnostics')
 for r,p in zip(v['all117'],c['rows']):validate_row(r,p)
 require(sum(len(r['all_after_phases'])for r in v['all117'])==c['total_after_phases'],'phase total')
 require(len(v['teaching50'])==c['teaching_projection_count'],'separate teaching projections')
 return {'status':v['status'],'bounded_verification':v['bounded_verification'],'unresolved':v['unresolved'],'runtime_admission':False,'diagnostics':len(v['all117']),'after_phases':c['total_after_phases']}

def admit_to_runtime(*args,**kwargs):
 raise ValueError('HOLD: offline remeasurement contract does not authorize native restore, learning, Query, SDK or Action')
