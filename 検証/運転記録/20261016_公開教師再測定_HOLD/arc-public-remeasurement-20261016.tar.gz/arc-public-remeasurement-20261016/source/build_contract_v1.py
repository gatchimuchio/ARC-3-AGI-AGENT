import json,hashlib
from pathlib import Path
from remeasure_v1 import save,D,jb
p=D/'evidence/public_prepsave_remeasurement_20261016_v1.json';b=p.read_bytes();v=json.loads(b)
rows=[]
for r in v['all117']:
 scene=v['scene_table'][r['before_observation']['scene']['scene_ref']]
 filled=[[s['位置'],s['記号']]for box in scene['容器群']for s in box['枠群']if s['記号']is not None]
 rows.append({'source':r['source'],'row':r['row'],'before_row':r['before_row'],'action_row':r['action_row'],'after_phase_count':len(r['all_after_phases']),'all_phase_pixel_sha256':[x['observation']['pixel_sha256_uint8']for x in r['all_after_phases']],'before_filled_slots':filled})
c={'contract':'new-offline-evidence-only-v1','schema':v['schema'],'artifact':{'path':str(p.relative_to(D)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()},'raw_corpus_sha256':v['raw_source']['sha256'],'rows':rows,'total_after_phases':sum(x['after_phase_count']for x in rows),'teaching_projection_count':len(v['teaching50']),'overall_status':'HOLD','runtime_admission':False,'historical_catalog_change':False,'historical_missing_file_restored':False,'limitations':v['unresolved']}
print(save('evidence/new_consumer_contract_v1.json',c))
