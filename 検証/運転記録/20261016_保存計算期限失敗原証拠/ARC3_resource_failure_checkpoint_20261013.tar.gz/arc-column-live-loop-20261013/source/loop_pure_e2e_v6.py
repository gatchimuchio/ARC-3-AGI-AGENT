PINS={'adapter': 'f18d9d33191749a5c6e731f58f534936a73b6e9162c1363fc5424c92e80e09d7', 'final': '1a6b5987886f8ae2a2fb85695455698d58797ceb9ef7635bdcaf7715d3a9238d', 'semantics': '1b3f23bfe847cc452fdd9367700686e325025ad9a74194c168ad5d9ba4f076cb', 'entry': '7e92d5c73d3b3b002c2e2dcb09b526950d9c2c1caf881838ce38f8cbd48b7aba', 'work': '8427b6cf7498613c548e6ac883ebfe800ffa6c43b25ded7488d45facdb9f34be', 'family': 'd303b314446d22c604008d590636cccf6e1d140fbd365f22ff018b55d97de399', 'codec': '8aa431b3012424fd8347c5b3d93a5fbf2218d35020836f5d40abb427f9d6da0d'}
"""Synthetic end-to-end evidence seam. No SDK or HDS import/API.
Uses real pure semantic entry/candidate enumeration, dossier writer, final
verifier, transport and public capture. Only perception/native replies/env
are synthetic. Every case and its files remain immutable.
"""
import resource
resource.setrlimit(resource.RLIMIT_AS,(512<<20,512<<20))
import ast,copy,dataclasses,enum,hashlib,importlib.util,itertools,json,lzma,os,signal,sys,traceback
from pathlib import Path
from collections import Counter
from types import SimpleNamespace
B=Path('/workspace/scratch/a94ff513b3af')
S=B/'arc-column-live-loop-20261013'
sys.path.insert(0,str(S/'source'))
import loop_guard_v1 as guard
guard.guard()
signal.signal(signal.SIGALRM,lambda *a:(_ for _ in ()).throw(TimeoutError('pilot fake120')))
signal.alarm(120)
def load(name,path,pin):
    raw=path.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=pin:raise ValueError('source pin '+name)
    m=importlib.util.module_from_spec(importlib.util.spec_from_file_location(name,path))
    sys.modules[name]=m;exec(compile(raw,str(path),'exec'),m.__dict__);return m
sys.path.insert(0,str(B/'arc-live-step-adapter-20261013'))
adapter=load('adapter',B/'arc-live-step-adapter-20261013/adapter.py',PINS['adapter'])
final=load('pilot_final',B/'arc-live-step-adapter-20261013/final_adoption_v4.py',PINS['final'])
sem=load('pilot_semantics',B/'arc-column-live-pilot-20261013/source/pilot_semantics_v3.py',PINS['semantics'])
query=load('pilot_fake_entry',B/'arc-column-candidate-query-20261013/source/candidate_query_v5.py',PINS['entry'])
candidate=load('pilot_fake_candidates',Path(query.MANIFEST['candidate']['path']),query.MANIFEST['candidate']['sha256'])
work=load('pilot_work',B/'arc-column-goal-work-measurement-20261013/source/column_goal_work_v2.py',PINS['work'])
import numpy as np
@dataclasses.dataclass
class Input:
    内容:dict
    対象系境界:str
@dataclasses.dataclass
class Reply:
    状態:str
    内容:dict
    追跡情報:dict
family_path=B/'arc-current-family-source-20261013/接続/列図式規則.py'
raw=family_path.read_bytes()
if hashlib.sha256(raw).hexdigest()!=PINS['family']:raise ValueError('family pin')
tree=ast.parse(raw)
names={'列を生成する','一致する','照会','内容候補を構成する'}
nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names or isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id in ('役割境界','目標境界') for x in n.targets)]
ns={'deepcopy':copy.deepcopy,'Counter':Counter,'itertools':itertools,'外部入力':Input}
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(family_path),'exec'),ns)
codecpath=B/'arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2/hds学習系統/永続化.py'
raw=codecpath.read_bytes()
if hashlib.sha256(raw).hexdigest()!=PINS['codec']:raise ValueError('codec pin')
cn={'Any':object,'Enum':enum.Enum,'is_dataclass':dataclasses.is_dataclass,'fields':dataclasses.fields}
nodes=[n for n in ast.parse(raw).body if isinstance(n,ast.FunctionDef) and n.name=='_符号化']
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(codecpath),'exec'),cn)
encode=cn['_符号化']
def plain(x):return final.復号(encode(x))
def js(x):return json.dumps(x,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()

# Actual immutable codec functions only; no HDS engine or restore.
cn['_型表']=lambda:{'Input':Input,'Reply':Reply}
nodes=[n for n in ast.parse(codecpath.read_bytes()).body if isinstance(n,ast.FunctionDef) and n.name=='_復号']
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(codecpath),'exec'),cn)
decode=cn['_復号']
loop=load('loop_tested',S/'source/loop_live_v4.py','db3e694936146623bd720cc9f44bcb1383a08e1567c610541e571adc6535fe5f')
CASES=[];EXCEPTIONS=[]
class Observation:
    model_fields={k:None for k in ('game_id','state','levels_completed','win_levels','action_input','guid','full_reset','available_actions')}
    def __init__(self,marker=0,levels=0):
        self.game_id='synthetic';self.state='NOT_FINISHED';self.levels_completed=levels;self.win_levels=2
        self.action_input={'id':0,'data':{}};self.guid='same-synthetic-instance';self.full_reset=False;self.available_actions=[5,6]
        self.frame=[np.zeros((64,64),dtype=np.int8)];self.frame[0][0,0]=marker
    def model_dump(self,**kw):return {k:copy.deepcopy(getattr(self,k)) for k in self.model_fields}
SCENE={'背景色':0,'目標列':[2,3],'容器群':[{'色':1,'位置':[0,0],'起点':True,'枠群':[{'位置':[3,3],'記号':None},{'位置':[9,3],'記号':None}]}],'在庫群':[{'位置':[3,20],'記号':{'色':2,'中空':False}},{'位置':[11,20],'記号':{'色':3,'中空':False}}]}
class Actions:ACTION5='ACTION5';ACTION6='ACTION6'
class NotApplicable(ValueError):pass
class Clock:
    def enter(self,*a):pass
class SyntheticFactory:
    def __init__(self,run,mode):
        self.run=run;self.mode=mode;self.np=np;self.GameAction=Actions;self.current=Observation()
        self.sequence=0;self.step_attempted=0;self.step_returned=0;self.make_attempted=0
        self.armed_request=None;self.consumed_requests=[];self.scenes={0:copy.deepcopy(SCENE)};self.selections={0:None}
    def prepare(self):pass
    def initialize(self,target,metadata):
        self.make_attempted+=1;assert self.make_attempted==1
        self.initial_ref=self.run.save('initial-public.json',adapter.capture_public(self.current,np,'synthetic'),raw=True)
        return self.current
    def diagnostics(self):return {'sdk_events':[],'denials':['synthetic denial'] if self.mode=='diagnostic' and self.step_attempted else [],'exceptions':[],'sdk_io':[]}
    def observe_current(self):return self.current,self.sequence
    arm_step=loop.FreshRuntime.arm_step
    def step(self,action,data,reasoning):
        assert self.armed_request and self.armed_request not in self.consumed_requests
        self.consumed_requests.append(self.armed_request);self.armed_request=None;self.step_attempted+=1
        scene=copy.deepcopy(self.scenes[self.sequence]);sel=copy.deepcopy(self.selections[self.sequence])
        number=5 if action=='ACTION5' else 6
        levels=self.current.levels_completed
        if number==5:
            levels+=1
            if self.mode in ('twolevels','notapp','win'):
                scene=copy.deepcopy(SCENE);sel=None
                scene['目標列']=[3,2]
        else:
            xy=(data['x'],data['y']);inventory=[x for x in scene['在庫群'] if (x['位置'][0]+2,x['位置'][1]+2)==xy]
            slots=[x for x in scene['容器群'][0]['枠群'] if (x['位置'][0]+2,x['位置'][1]+2)==xy]
            if inventory:sel=copy.deepcopy(inventory[0])
            elif slots and sel is not None:
                slots[0]['記号']=copy.deepcopy(sel['記号']);scene['在庫群']=[x for x in scene['在庫群'] if x['位置']!=sel['位置']];sel=None
            else:raise AssertionError('synthetic unclassified action')
        self.sequence+=1;self.step_returned+=1;self.current=Observation(self.sequence,levels)
        if (self.mode=='twolevels' and levels==2) or (self.mode=='win' and levels==1):self.current.state='WIN'
        self.current.action_input={'id':number,'data':copy.deepcopy(data)}
        self.scenes[self.sequence]=scene;self.selections[self.sequence]=sel
        return self.current
def make_state():
    specifications=[
      ('role',ns['役割境界'],'記号は中空','列展開役割',[(False,'出力'),(True,'参照')]),
      ('action',candidate.作用境界,'解答作業','必要行動ID',[('在庫記号を選択',6),('選択記号を空欄へ割当',6),('完成列提出',5)]),
      ('accept',candidate.目標境界,'終端条件に応じた列が一致','提出が受理された',[(False,False),(True,True)]),
      ('prep',candidate.準備境界,candidate.準備入力,candidate.準備結果,[(False,False),(True,True)]),
      ('repair',candidate.修復境界,candidate.修復入力,candidate.修復結果,[(False,False),(True,True)]),
      ('preserve',candidate.保存境界,candidate.保存入力,candidate.保存結果,[(x,True) for x in candidate.保存区分])]
    state={'形式版':3,'識別子状態':{'照会':378,'学習判定':378},'状態履歴':[{},{}],'原理履歴':{},'台帳':{'観測台帳':[]}};lookup={}
    for pid,b,x,y,pairs in specifications:
        ids=[]
        for i,(a,z) in enumerate(pairs):
            eid=pid+str(i);ids.append(eid);state['台帳']['観測台帳'].append({'経験識別子':eid,'対象系境界':b,'原入力':{x:a,y:z}})
        p={'原理識別子':pid,'対象系境界':b,'結果経路':[y],'条件経路群':[[x]],'版':1,'採用状態':'有効','根拠参照群':ids,'反証参照群':[],'適用範囲':{'fixture':True}}
        state['状態履歴'][-1][pid]=pid;state['原理履歴'][pid]=[p];lookup[b]=(p,x,y,pairs)
    return state,lookup
class TestRun(loop.Run):
    def __init__(self,name,mode):
        super().__init__();self.mode=mode;self.clock=Clock();self.enc=encode;self.dec=decode
        self.folder=S/'evidence'/name;guard.guard('evidence',16<<20);self.folder.mkdir(parents=True,exist_ok=False);guard.fsyncdir(self.folder.parent)
        self.failure_folder=self.folder;self.transport_directory=self.folder/'transport'
        self.journal=adapter.Journal(self.transport_directory,cap=464<<20,budget_root=S/'evidence')
        self.machine,self.lookup=make_state();self.native=SimpleNamespace(外部入力=Input,外部出力=Reply,HDS学習系統=SimpleNamespace(読み込む=lambda path:self.machine))
        self.factory=SyntheticFactory(self,mode);self.target='synthetic';self.metadata={};self.nonce='f'*32
        self.family=SimpleNamespace(**{k:ns[k] for k in names},役割境界=ns['役割境界'],知覚不適用=NotApplicable,
           図式を観測する=self.scene,
           選択を読む=lambda frame,scene:copy.deepcopy(self.factory.selections[int(frame[0][0])]))
        self.query=query;self.candidate=candidate;self.work=work;self.adapter=adapter;self.final=final;self.boundary=adapter.load_boundary()
        self.gate={'stop_on_level_success':mode not in ('twolevels','notapp','win'),'limits':{'Action':32 if mode!='cap' else 2,'max_queries':4096}}
        self.baseline_raw=json.dumps(encode(self.machine),ensure_ascii=False,indent=2).encode()
        br=self.save_raw('baseline.standard.json',self.baseline_raw);self.gate['closed_baseline']={'state':br}
    def scene(self,frame):
        if self.mode=='notapp' and self.factory.current.levels_completed:raise NotApplicable('synthetic new level not applicable')
        return copy.deepcopy(self.factory.scenes[int(frame[0][0])])
    def version(self):return 1
    def standard(self,label):
        r=self.save_raw(label+'.standard.json',json.dumps(encode(self.machine),ensure_ascii=False,indent=2).encode())
        self.states.append(r);return r,copy.deepcopy(self.machine)
    def 照会する(self,value):
        assert self.bound is not None and len(self.calls)-self.step_call_start<self.bound
        i=len(self.calls);inp=dataclasses.asdict(value);p,x,y,pairs=self.lookup[value.対象系境界];a=value.内容[x]
        matches=[z for k,z in pairs if sem.exact(k,a)];assert len(matches)==1;z=matches[0]
        raw={'現在状態版':1,'学習過程':{'学習前状態版':1,'学習後状態版':1},'追跡情報':{'対象系境界':value.対象系境界,'照会参照':'q'+str(i)},'予測群':[{'原理参照':p['原理識別子'],'結果経路':[y],'予測値':z,'条件値群':[a]}],
             '有効原理群':[v[0] for v in self.machine['原理履歴'].values()],**{n:[] for n in final.不確実項目}}
        ret=Reply('出力',{k:copy.deepcopy(v) for k,v in raw.items() if k not in ('追跡情報','学習過程')},raw['追跡情報'])
        if self.mode=='hold' and self.step_index==2 and value.対象系境界==candidate.準備境界:
            raw['断定保留理由群']=['synthetic HOLD'];ret.状態='断定保留';ret.内容['断定保留理由群']=['synthetic HOLD']
        record={'ordinal':i,'frame':self.step_index,'method':'照会する','input':inp,'origin':copy.deepcopy(self.origin),'before':{'counter':378+i},'capture':{}}
        intent=self.packet('query_%04d_intent'%i,record)
        record['capture']={'raw':[raw],'return':dataclasses.asdict(ret)};record['after']={'counter':379+i}
        rp=self.packet('query_%04d_reply'%i,record);link={'ordinal':i,'frame':self.step_index,'method':'照会する','intent':intent,'reply':rp}
        replay=dict(copy.deepcopy(record),reference=link)
        self.calls.append(link);self.replay_records.append(replay);self.all_replay_records.append(replay)
        for k in ('照会','学習判定'):self.machine['識別子状態'][k]+=1
        return ret
    def step_cycle(self,observation,current):
        # Actual step_cycle; only native/environment values above are synthetic.
        result=super().step_cycle(observation,current)
        if self.step_index:
            old=[r for r in self.all_replay_records if r['frame']==0]
            try:loop.current_replay(old,self.origin,self.step_index)
            except ValueError as e:EXCEPTIONS.append(e)
            else:raise AssertionError('old-step query accepted')
        return result
    def finish(self,status,result):
        self.name_prefix=''
        last,value=self.standard('normal_final')
        expected=copy.deepcopy(self.initial)
        for k in ('照会','学習判定'):expected['識別子状態'][k]+=len(self.calls)
        assert sem.exact(encode(expected),encode(value))
        return {'status':status,'result':result,'trajectory':self.trajectory,'states':self.states,'calls':self.calls,'all_replay_records':self.all_replay_records,'final':last,'Action':self.factory.step_attempted,'make':self.factory.make_attempted,'current_public':self.public_ref,'before_current_public':self.before_current_public,'final_public_response':self.final_public_response}
for mode in ('success','hold','cap','diagnostic','twolevels','notapp','win'):
    try:
        run=TestRun('pure-loop-v6-'+mode,mode);out=run.execute()
        expected={'success':('LEVEL_SUCCESS',5),'hold':('HOLD',2),'cap':('RESOURCE_HOLD',2),'diagnostic':('HOLD',1),'twolevels':('WIN',10),'notapp':('HOLD',5),'win':('WIN',5)}[mode]
        assert (out['status'],out['Action'])==expected and out['make']==1
        requests=[x['request_id'] for x in out['trajectory'] if 'request_id' in x]
        assert len(requests)==len(set(requests))==out['Action']
        steps=[x for x in out['trajectory'] if 'step' in x]
        for prev,nxt in zip(steps,steps[1:]):assert nxt['before_state']==prev['state'] and nxt['before_public']==prev['step']['public_response']
        assert len(list(run.transport_directory.glob('consumed-*')))==out['Action']
        assert out['current_public']==steps[-1]['step']['public_response']==out['final_public_response']
        if mode!='notapp':assert out['before_current_public']==steps[-1]['before_public']
        if mode=='twolevels':assert sum(x['status']=='LEVEL_SUCCESS' for x in out['trajectory'])==2
        if mode=='notapp':assert out['trajectory'][-1]['reason']=='current structural/goal/role interpretation incomplete'
        CASES.append({'mode':mode,'status':'PASS','full':out})
    except BaseException as e:
        EXCEPTIONS.append(e);CASES.append({'mode':mode,'status':'FAIL','traceback':traceback.format_exc()});break
# Direct terminal negative boundaries, using the same pure outcome as runtime.
if all(x['status']=='PASS' for x in CASES):
    memory={'HOLD':[],'継続可能':True};measure={'UNKNOWN':True,'実測目的効果':True,'全相既充足保存':None}
    chosen={'作業':'完成列提出','対象':None};pres={'由来':sem.TERMINAL,'保存値':None};projected={'現在列の目標一致':True}
    boundary={'同一公開実行':True,'RESET非該当明示':True};analysis={'levels_delta':1,'state_after':'NOT_FINISHED','failure_observed':False}
    assert loop.outcome(memory,measure,chosen,pres,projected,boundary,analysis)=='LEVEL_SUCCESS'
    for field in ('unfilled','not_submit','identity_unknown','reset','no_progress'):
        c,p,b,a=copy.deepcopy(chosen),copy.deepcopy(projected),copy.deepcopy(boundary),copy.deepcopy(analysis)
        if field=='unfilled':p['現在列の目標一致']=False
        elif field=='not_submit':c['作業']='在庫記号を選択'
        elif field=='identity_unknown':b['同一公開実行']=None
        elif field=='reset':b['RESET非該当明示']=False
        else:a['levels_delta']=0
        assert loop.outcome(memory,measure,c,pres,p,b,a)=='HOLD'
        CASES.append({'mode':field,'status':'PASS','input':[memory,measure,c,pres,p,b,a]})
# Actual factory arm/step functions with a synthetic context and response only.
if all(x['status']=='PASS' for x in CASES):
    import contextlib
    f=loop.FreshRuntime('f'*32,S/'evidence',lambda *a:None)
    f.sdk_phase=lambda label:contextlib.nullcontext()
    f.env=SimpleNamespace(step=lambda action,**kwargs:{'public':'synthetic'})
    f.arm_step('a'*32,0);f.step('fake',{},None)
    try:f.step('fake',{},None)
    except PermissionError as e:EXCEPTIONS.append(e)
    else:raise AssertionError('second Action without fresh permit')
    assert f.step_attempted==f.step_returned==f.sequence==1
    f.step_attempted=32
    try:f.arm_step('b'*32,1)
    except PermissionError as e:EXCEPTIONS.append(e)
    else:raise AssertionError('total cap allowed')
    CASES.append({'mode':'actual_factory_single_permit_and_total_cap','status':'PASS','consumed':f.consumed_requests})
    for mode in ('unknown_effect','wrong_effect'):
        m={'UNKNOWN':mode=='unknown_effect','実測目的効果':None if mode=='unknown_effect' else False,'全相既充足保存':None}
        a={'levels_delta':0,'state_after':'NOT_FINISHED','failure_observed':False}
        assert loop.outcome({'HOLD':[],'継続可能':True},m,{'作業':'在庫記号を選択','対象':{}},{'由来':'保存対象なし','保存値':None},{'現在列の目標一致':False},{'同一公開実行':True,'RESET非該当明示':True},a)=='HOLD'
        CASES.append({'mode':mode,'status':'PASS','measured':m})
if all(x['status']=='PASS' for x in CASES):
    rejected=[]
    for bad in (None,0,1,'false',[]):
        try:loop.continuation_status({'status':'CONTINUE'},bad)
        except ValueError as e:EXCEPTIONS.append(e);rejected.append(bad)
        else:raise AssertionError('nonbool policy allowed')
    CASES.append({'mode':'strict_bool_stop_policy','status':'PASS','rejected':rejected})
out={'schema':'column-live-loop-pure-v1','status':'PASS' if len(CASES)==16 and all(x['status']=='PASS' for x in CASES) else 'FAIL','cases':CASES,'SDK':0,'HDS':0,'limits':['Actual coordinator execute/step_cycle/replay/dossier/final verifier/shared transport are used.','Synthetic perception, environment, native answers and standard state writer. Real SDK/native lifecycle is not executed.']}
raw=js(encode(out));blob=lzma.compress(raw,check=lzma.CHECK_CRC64,preset=0);r=guard.save('evidence','pure_loop_v6.typed.json.xz',blob)
back=lzma.decompress(Path(r['path']).read_bytes());assert back==raw
print(json.dumps({'status':out['status'],'cases':len(CASES),'report':r,'rawbytes':len(raw),'rawsha256':hashlib.sha256(raw).hexdigest(),'failures':[x for x in CASES if x['status']=='FAIL']},ensure_ascii=False),flush=True)
if out['status']!='PASS':raise AssertionError('pure loop saved failure')
