"""One fresh instance, full current queries per step, at most 64 serial Actions.
Real invocation requires an exact, separately approved root gate. Import is
stdlib-only. HDS core and SDK are loaded only after the complete gate preflight.
"""
import ast,copy,dataclasses,hashlib,importlib.util,json,lzma,os,resource,signal,sys,time,traceback,types,uuid
from pathlib import Path
import loop_guard_v2 as guard
from loop_fresh_factory_v2 import FreshRuntime,read,ref,jsonbytes
sys.path.insert(0,str(Path('/workspace/scratch/a94ff513b3af/arc-column-live-pilot-20261013/source')))
import pilot_semantics_v3 as semantics
B=guard.B;ROOT=guard.ROOT;M=1048576
OWNER=None
def same(a,b):return semantics.exact(a,b)
def module(name,r):
    raw=read(r,8*M);sp=importlib.util.spec_from_file_location(name,r['path'])
    m=importlib.util.module_from_spec(sp);sys.modules[name]=m;exec(compile(raw,r['path'],'exec'),m.__dict__);return m
def rawpacket(p):
    blob=read(p['file'],16*M);z=lzma.LZMADecompressor(memlimit=128*M);raw=z.decompress(blob,max_length=16*M+1)
    if not z.eof or z.unused_data or z.check!=lzma.CHECK_CRC64 or len(raw)!=p['rawbytes'] or hashlib.sha256(raw).hexdigest()!=p['rawsha256']:raise ValueError('PacketRef full CRC64/EOF/raw')
    return raw
def read_typed_file(r):
    z=lzma.LZMADecompressor(memlimit=128*M);raw=z.decompress(read(r,16*M),max_length=16*M+1)
    if not z.eof or z.unused_data or z.check!=lzma.CHECK_CRC64 or len(raw)>16*M:raise ValueError('typed file CRC64/EOF/cap')
    return raw

def replay_from_packet(link,decode):
    record=decode(json.loads(rawpacket(link['reply'])))
    record['input']=dataclasses.asdict(record['input'])
    record['capture']['return']=dataclasses.asdict(record['capture']['return'])
    record['reference']=copy.deepcopy(link)
    return record

def closure(g):
    b=g['closed_baseline'];state=read(b['state'],8*M)
    completion=json.loads(read(b['completion'],M));audit=json.loads(read(b['audit'],8*M))
    tools=json.loads(read(b['actual_tools'],M))
    if completion.get('schema')!='column-live-loop-completion-v1' or completion.get('status')!='LEVEL_SUCCESS' or completion.get('errors')!=[]:raise ValueError('closed pilot completion')
    if completion['nonce']!='d7bbc7465f691c7bb7bb6e5a76089762' or completion['states'][-1]!=b['state'] or completion['Teach']!=0:raise ValueError('latest serial pilot state binding')
    if audit.get('schema')!='column-live-loop-independent-audit-v1' or audit.get('status')!='PASS' or audit.get('errors')!=[] or audit.get('nonce')!=completion['nonce']:raise ValueError('independent pilot PASS')
    required=('all126_native_raw_external_support_and_perstep_origin','all9_current_reprojections_complete_candidates_adoptions_and_dispatch','all150_public_response_phases_effects_and_memory','all11_normal_states_only_query_counters_378_to504','prior_pilot_closure_and_actual_loop_exit','terminal_submission_scope_and_unknown_preserved')
    if any(audit.get('verified',{}).get(k)is not True for k in required):raise ValueError('pilot independent full checks')
    if audit['completion']!=b['completion'] or audit['actual_tools']!=b['actual_tools'] or audit['states']!=completion['states']:raise ValueError('pilot closure exact joins')
    exits=[x for x in tools['polls'] if x.get('exit_code')==0]
    if len(exits)!=1 or tools.get('actual_exit')!=0:raise ValueError('pilot actual exit')
    objects=[]
    for line in exits[0].get('output','').splitlines():
        try:objects.append(json.loads(line))
        except ValueError:pass
    if not any(type(x)is dict and x.get('receipt')==b['completion'] and x.get('status')=='complete' for x in objects):raise ValueError('pilot exit receipt join')
    if g.get('latest_closed_loop_root_adopted')is not True:raise PermissionError('latest pilot root adoption missing')
    return state

def current_replay(queries,origin,step_index):
    if not queries:raise ValueError('no current queries')
    for q in queries:
        if q['frame']!=step_index or not same(q['origin'],origin):raise ValueError('prior-step reply/origin reuse')
    return queries

def continuation_status(result,stop_on_level_success):
    if type(stop_on_level_success)is not bool:raise ValueError('strict bool level stop policy')
    status=result['status']
    if status=='LEVEL_SUCCESS':
        if result['step']['analysis'].get('state_after')=='WIN':return 'WIN'
        return 'LEVEL_SUCCESS' if stop_on_level_success else 'CONTINUE'
    return status

def sdk_problem(d):
    return bool(d['sdk_events'] or d['denials'] or d['exceptions'] or any(x.get('write_error') for x in d['sdk_io']))

def outcome(memory,measured,chosen,preservation,projected,boundary,analysis):
    progress=(type(analysis.get('levels_delta'))is int and analysis['levels_delta']>0) or analysis.get('state_after')=='WIN'
    terminal=(chosen['作業']=='完成列提出' and chosen['対象'] is None and projected['現在列の目標一致'] is True
        and preservation['由来']==semantics.TERMINAL and preservation['保存値'] is None
        and boundary.get('同一公開実行')is True and boundary.get('RESET非該当明示')is True and progress)
    if memory['HOLD'] or analysis.get('failure_observed')is not False:return 'HOLD'
    if terminal:return 'LEVEL_SUCCESS'
    if progress or measured['UNKNOWN'] or measured['実測目的効果']is not True:return 'HOLD'
    if preservation['保存値'] is not None and measured['全相既充足保存']is not True:return 'HOLD'
    return 'CONTINUE' if memory['継続可能'] is True else 'HOLD'

class Run:
    def __init__(self):
        self.calls=[];self.replay_records=[];self.refs=[];self.states=[];self.errors=[];self.pending=None
        self.factory=None;self.machine=None;self.complete=False;self.step_result=None;self.current=None;self.failing=False
        self.name_prefix="";self.step_index=0;self.trajectory=[];self.all_replay_records=[];self.step_call_start=0
    def save_raw(self,name,data):
        name=self.name_prefix+name
        if Path(name).name!=name or len(data)>16*M:raise ValueError('bounded evidence filename')
        self.clock.enter('failure_save' if self.failing else 'save');self.pending={'name':name,'raw':data}
        try:
            category='failure' if self.failing else 'evidence'
            guard.guard(category,len(data));p=(self.failure_folder if self.failing else self.folder)/name
            with p.open('xb') as f:
                if f.write(data)!=len(data):raise OSError('short write')
                f.flush();os.fsync(f.fileno())
            guard.fsyncdir(p.parent)
            if p.read_bytes()!=data:raise OSError('exact evidence readback')
            r=ref(p);self.refs.append(r);self.pending=None;return r
        finally:self.clock.enter('failure_save' if self.failing else 'compute')
    def save(self,name,value,raw=False):
        return self.save_raw(name,value if raw else jsonbytes(value))
    def packet(self,name,value):
        raw=jsonbytes(self.enc(value))
        if len(raw)>16*M:raise MemoryError('complete typed raw16MiB')
        blob=lzma.compress(raw,preset=0,check=lzma.CHECK_CRC64);r=self.save_raw(name+'.typed.json.xz',blob)
        p={'file':r,'rawbytes':len(raw),'rawsha256':hashlib.sha256(raw).hexdigest()}
        if rawpacket(p)!=raw:raise ValueError('full typed packet readback')
        if not same(self.enc(self.dec(json.loads(raw))),self.enc(value)):raise ValueError('typed value/order roundtrip')
        return p
    def standard(self,label):
        self.clock.enter('failure_save' if self.failing else 'save');p=(self.failure_folder if self.failing else self.folder)/(self.name_prefix+label+'.standard.json');self.pending={'standard':str(p)}
        try:
            guard.guard('failure' if self.failing else 'evidence',8*M)
            fd=os.open(p,os.O_CREAT|os.O_EXCL|os.O_WRONLY|os.O_NOFOLLOW,0o600);before=os.fstat(fd);os.close(fd)
            old=resource.getrlimit(resource.RLIMIT_FSIZE)
            try:resource.setrlimit(resource.RLIMIT_FSIZE,(8*M,old[1]));self.machine.保存する(p)
            finally:resource.setrlimit(resource.RLIMIT_FSIZE,old)
            fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
            try:
                after=os.fstat(fd)
                if (before.st_dev,before.st_ino)!=(after.st_dev,after.st_ino) or after.st_size>8*M:raise ValueError('normal state inode/cap')
                os.fsync(fd)
            finally:os.close(fd)
            guard.fsyncdir(p.parent);raw=p.read_bytes();value=self.dec(json.loads(raw))
            if json.dumps(self.enc(value),ensure_ascii=False,indent=2).encode()!=raw:raise ValueError('normal standard exact bytes')
            if not same(self.enc(value),self.enc(self.query.snapshot_value(self.machine))):raise ValueError('normal standard complete live snapshot')
            r=ref(p);self.refs.append(r);self.states.append(r);self.pending=None;return r,value
        finally:self.clock.enter('failure_save' if self.failing else 'compute')
    def markers(self):
        e=self.machine.エンジン
        return {'identifiers':e.識別子.状態を書き出す(),'ledger_lengths':{k:len(v) for k,v in e.台帳.全取得().items()},
          'principle_history_lengths':{k:len(v) for k,v in e._原理履歴.items()},'state_history_length':len(e.状態.履歴())}
    def version(self):return len(self.machine.エンジン.状態.履歴())-1
    def allow_frame(self,n):
        if type(n)is not int or n<4 or n>self.gate['limits']['max_queries']:raise MemoryError('complete enumeration cannot fit query gate')
        if len(self.calls)+n>self.gate['limits']['max_queries']:raise MemoryError('total Query resource cap')
        self.bound=n
    @property
    def owner(self):return self
    def 照会する(self,external):
        if self.bound is None or len(self.calls)-self.step_call_start>=self.bound:raise MemoryError('all-candidate query bound')
        i=len(self.calls);origin=copy.deepcopy(self.origin)
        self.current={'ordinal':i,'frame':self.step_index,'method':'照会する','input':external,'origin':origin,'before':self.markers(),'capture':{}}
        intent=self.packet('query_%04d_intent'%i,self.current)
        answer=self.query.capture_call(self.machine,'照会する',external,self.current['capture'])
        self.current['after']=self.markers()
        reply=self.packet('query_%04d_reply'%i,self.current)
        link={'ordinal':i,'frame':self.step_index,'method':'照会する','intent':intent,'reply':reply};self.calls.append(link)
        replay=copy.deepcopy(self.current);replay['input']=dataclasses.asdict(external)
        replay['capture']['return']=dataclasses.asdict(answer);replay['reference']=copy.deepcopy(link)
        self.replay_records.append(replay);self.all_replay_records.append(replay)
        # The complete state is immutable except paired query counters.
        expected=self.dec(self.enc(self.initial))
        for k in ('照会','学習判定'):expected['識別子状態'][k]=expected['識別子状態'].get(k,0)+len(self.calls)
        if not same(self.enc(expected),self.enc(self.query.snapshot_value(self.machine))):raise ValueError('per-query full state/ledger/history changed')
        self.current=None;return answer
    def ask(self,boundary,facts):
        answer=self.照会する(self.native.外部入力(copy.deepcopy(facts),boundary))
        return {'状態':answer.状態,'内容':answer.内容,'追跡情報':answer.追跡情報,'実照会保存参照':copy.deepcopy(self.calls[-1])}
    def preflight(self,path,pin):
        raw=Path(path).read_bytes()
        if hashlib.sha256(raw).hexdigest()!=pin or len(raw)>65536:raise ValueError('exact pilot root gate')
        g=json.loads(raw);self.gate=g
        if g['schema']!='column-live-loop-release-v1' or g['enabled']is not True:raise PermissionError('root live release')
        if type(g.get('stop_on_level_success'))is not bool:raise PermissionError('strict bool level stop policy')
        if g['limits']!={'AS':1<<30,'compute':900,'save':600,'failure_save':120,'Action':64,'Teach':0,'max_queries':4096}:raise PermissionError('fixed finite live limits')
        soft,hard=resource.getrlimit(resource.RLIMIT_AS)
        if not 0<soft<=1<<30 or not 0<hard<=1<<30:raise PermissionError('AS required before all imports')
        if time.time()>g['admission_deadline_epoch']:raise PermissionError('expired admission')
        self.nonce=g['nonce']
        if type(self.nonce)is not str or len(self.nonce)!=32 or any(x not in '0123456789abcdef' for x in self.nonce):raise ValueError('nonce')
        if read(g['source'])!=Path(__file__).read_bytes():raise ValueError('actual coordinator source')
        contract=json.loads(read(g['contract'],M))
        for r in contract['source_pins']:read(r,8*M)
        for r in contract['core_and_family_pins']:read(r,8*M)
        self.contract=contract;guard.guard()
        import shutil
        if shutil.disk_usage(B).free<(2516+1024)*M:raise MemoryError('latest globalfuture2516MiB plus physical1GiB')
        self.baseline_raw=closure(g)
        (ROOT/'evidence').mkdir(exist_ok=True);guard.fsyncdir(ROOT)
        self.folder=ROOT/'evidence'/self.nonce
        self.folder.mkdir(exist_ok=False);guard.fsyncdir(self.folder.parent)
        (ROOT/'failure').mkdir(exist_ok=True);self.failure_folder=ROOT/'failure'/self.nonce
        self.failure_folder.mkdir(exist_ok=False);guard.fsyncdir(self.failure_folder.parent)
        # All directories used by ordinary evidence writes and transport must
        # pre-exist before installing the inherited SDK audit hook.
        self.transport_directory=self.folder/'transport';self.transport_directory.mkdir();guard.fsyncdir(self.folder)
        self.query=module('pilot_current_query',contract['query_entry'])
        self.clock=self.query.Clock();self.clock.remaining={'compute':900.0,'save':600.0};self.clock.enter('compute')
        self.candidate=module('pilot_candidates',contract['candidate'])
        self.work=module('pilot_goal_work',contract['goal_work'])
        sys.path.insert(0,str(B/'arc-live-step-adapter-20261013'))
        self.adapter=module('adapter',contract['transport'])
        self.final=module('pilot_final_adoption',contract['final_adoption'])
        self.boundary=self.adapter.load_boundary()
        sys.dont_write_bytecode=True
        core=B/'arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2'
        familyroot=B/'arc-current-family-source-20261013'
        sys.path.insert(0,str(core));sys.path.insert(0,str(familyroot))
        import hds学習系統 as native
        import hds学習系統.永続化 as persistence
        from 接続 import 列図式規則 as family
        if Path(native.__file__).resolve()!=core/'hds学習系統/__init__.py' or Path(family.__file__).resolve()!=familyroot/'接続/列図式規則.py':raise ValueError('actual import source identities')
        self.native=native;self.enc=persistence._符号化;self.dec=persistence._復号;self.family=family
        self.bound=None
        # Target is joined from a prior public structural applicability report.
        # Its identifier routes SDK.make only and never enters semantic input.
        applicability=json.loads(read(g['structural_applicability'],M))
        oldpublic=json.loads(read(applicability['元観測'],8*M))
        if applicability['照合状態']!='固定知覚に適合':raise ValueError('prior structural applicability')
        metadata=json.loads(read(g['metadata'],M))
        target=oldpublic['model_json']['game_id']
        if metadata['game_id']!=target:raise ValueError('structural public metadata target join')
        audit=json.loads(read(g['bundle_audit'],M))
        if audit.get('status')!='PASS' or audit.get('errors') or audit['schema']!='official-bundles-independent-audit-v1':raise ValueError('opaque bundle independent audit')
        targets=[x for x in audit['all_targets'] if x['game_id']==target]
        if len(targets)!=1 or targets[0]['metadata']!=g['metadata']:raise ValueError('opaque bundle metadata selection')
        if g['opaque_bundle_files']!=[x['source'] for x in audit['all_targets']]:raise ValueError('all25 opaque bundle source joins')
        for r in g['opaque_bundle_files']:
            read(r,2*M) # Exact bytes hash only; never decode/display/AST.
        self.target=target;self.metadata=metadata
        self.factory=FreshRuntime(self.nonce,self.folder/'sdk-runtime',self.save)
        # Journal.__init__ mkdir uses exist_ok=True, still emits an audit event.
        # Construct it BEFORE factory installs the inherited no-mkdir hook.
        run=self
        class GuardedJournal(self.adapter.Journal):
            def save(self,name,value,raw=False):
                data=value if raw else run.adapter.raw_json(value)
                guard.guard('evidence',len(data))
                return super().save(name,value,raw=raw)
        self.journal=GuardedJournal(self.transport_directory,cap=976*M,budget_root=ROOT/'evidence')
    def execute(self):
        self.factory.prepare()
        observation=self.factory.initialize(self.target,self.metadata)
        self.public_ref=self.factory.initial_ref
        self.before_current_public=self.public_ref;self.final_public_response=None
        self.machine=self.native.HDS学習系統.読み込む(self.gate['closed_baseline']['state']['path'])
        first,self.initial=self.standard('restored_before_current_queries')
        if Path(first['path']).read_bytes()!=self.baseline_raw:raise ValueError('latest closed pilot normal restore bytes')
        self.step_before_state=first
        initial_diagnostics=self.factory.diagnostics();self.save('initial_sdk_diagnostics.json',initial_diagnostics)
        if sdk_problem(initial_diagnostics):return self.finish('HOLD',{'reason':'initial SDK diagnostics'})
        for index in range(self.gate['limits']['Action']):
            self.before_current_public=self.public_ref
            self.step_index=index;self.step_nonce=uuid.uuid4().hex;self.name_prefix='step_%02d_%s_'%(index,self.step_nonce)
            self.step_call_start=len(self.calls);self.replay_records=[];self.bound=None
            current=self.boundary.観測する(observation,観測通番=index)
            actual,sequence=self.factory.observe_current()
            if sequence!=index or self.boundary.観測する(actual,観測通番=sequence).指紋!=current.指紋:raise ValueError('same-owner full response/current identity')
            if index and current.指紋!=self.trajectory[-1]['step']['observation_fingerprint']:raise ValueError('previous full response/current fingerprint chain')
            try:guard.guard('evidence',64*M);guard.guard('failure',16*M)
            except MemoryError:
                return self.finish('RESOURCE_HOLD',{'reason':'next full step evidence reservation','unprocessed_current_public':self.public_ref,'unprocessed_current_fingerprint':current.指紋})
            result=self.step_cycle(observation,current)
            diagnostics=self.factory.diagnostics();result['sdk_diagnostics']=self.save('step_sdk_diagnostics.json',diagnostics)
            if sdk_problem(diagnostics):result['status']='HOLD';result['sdk_HOLD']='fatal SDK diagnostic before next Action'
            self.trajectory.append(result);self.packet('step_outcome',result)
            # Preserve the complete response as current even at terminal/HOLD.
            # Its latest frame is selected only by the existing boundary API.
            if 'step' in result:
                observation=self.factory.current;self.public_ref=result['step']['public_response']
                self.final_public_response=self.public_ref
            self.step_before_state=result['state']
            next_status=continuation_status(result,self.gate['stop_on_level_success'])
            if next_status!='CONTINUE':return self.finish(next_status,result)
        return self.finish('RESOURCE_HOLD',{'reason':'finite total Action cap64 reached','unprocessed_current_public':self.public_ref,'next_current_not_queried':True})
    def step_cycle(self,observation,current):
        self.origin={'観測指紋':current.指紋,'公開観測参照':self.public_ref,'復元状態参照':self.step_before_state,
                     '観測通番':self.step_index,'相':len(current.盤面列)-1,'全相数':len(current.盤面列),'live採否可能':True}
        semantic=self.query.semantic_entry(self.family,self.candidate,current.最新盤面,list(current.作用可能番号),self,self.ask,current.状態)
        self.semantic=semantic;self.packet('current_complete_semantic',semantic)
        afterquery,queryvalue=self.standard('after_current_queries');self.after_query_ref=afterquery
        if semantic.get('適用性')!='固定知覚適合' or semantic.get('全作用候補')is None:
            return {'status':'HOLD','reason':'current structural/goal/role interpretation incomplete','state':afterquery}
        # All native replies for this exact current frame were durably saved.
        # Replay is pure: no second HDS call, no new support, no old-frame reply.
        def replay(actual):
            return semantics.replay_current(actual,self.family,self.candidate,self.query.semantic_entry,current_replay(self.replay_records,self.origin,self.step_index),
                  dataclasses.asdict,self.native.外部出力,semantic)
        def project(actual):
            return self.final.復号(self.enc(semantics.project_current(actual,replay(actual),self.work)))
        projected=semantics.project_current(current,replay(current),self.work)
        def dsave(name,value):
            if name=='full-candidates':return self.packet(name,value)['file']
            return self.save(name+'.json',value)
        prepared=semantics.prepare_dossier(semantic,projected,self.step_before_state,
                      self.version(),current.指紋,self.public_ref,dsave,self.step_nonce)
        self.prepared=prepared
        if prepared['status']=='HOLD':return {'status':'HOLD','prepared':prepared,'state':afterquery}
        record=prepared['record'];store=self.final.固定証拠(self.refs+[self.step_before_state],[ROOT,self.step_before_state['path'].rsplit('/',1)[0]])
        verifier=self.final.最終採否検査(store,self.step_before_state,record['final_adoption_ref'],project)
        transport=self.adapter.OneStepTransport(self.journal,verifier=verifier,evidence_roots=[self.folder],
                           np=self.factory.np,resource_check=guard.guard)
        guard.guard('evidence',64*M);guard.guard('failure',16*M)
        self.factory.arm_step(self.step_nonce,self.step_index)
        self.step_result=transport.run(self.factory,self.factory.GameAction,record,
                   observe_current=self.factory.observe_current,hds_version=self.version)
        read(self.step_result['public_response'],16*M);self.refs.append(self.step_result['public_response'])
        response=self.factory.current
        after=self.boundary.観測する(response,観測通番=self.factory.sequence)
        phases=[]
        for i,frame in enumerate(after.盤面列):
            p={'phase':i,'scene':None,'selection':None,'public_response_ref':self.step_result['public_response'],'JSONpath':['frames',i]}
            try:
                p['scene']=self.family.図式を観測する(frame)
                try:p['selection']=self.family.選択を読む(frame,p['scene'])
                except (ValueError,KeyError,TypeError) as e:p['selection_unknown']={'type':type(e).__name__,'args':e.args,'traceback':traceback.format_exc()}
            except (self.family.知覚不適用,ValueError,KeyError,TypeError) as e:p['perception_error']={'type':type(e).__name__,'args':e.args,'traceback':traceback.format_exc()}
            phases.append(p)
        beforemeta=observation.model_dump(exclude={'frame'},mode='json');aftermeta=response.model_dump(exclude={'frame'},mode='json')
        boundary=self.work.境界(beforemeta,aftermeta)
        chosen=next(c for c in semantic['全作用候補']['全候補'] if str(c['候補番号'])==record['selected_candidate_id'])
        measured=semantics.compare_effect(semantic,phases,boundary,chosen,self.work);measuredref=self.packet('all_response_goal_effects',measured)
        preservation=prepared['dossier']['候補検査'][record['selected_candidate_id']]['保存条件']
        expected_preservation=preservation['保存値']
        consistent=measured['実測目的効果'] is True and (expected_preservation is None or measured['全相既充足保存'] is True) and not measured['UNKNOWN']
        language={'対象':chosen['対象'],'役割':semantic['学習役割'],'関係':semantic['全目標pool'],
          '前提':chosen['前提'],'選択理由':['支持済集合の固定候補生成順。学習policyではない'],
          '予測':chosen['照会全件'],'保存条件':preservation,'適用範囲':projected['保存適用署名'][record['selected_candidate_id']],
          '由来参照':[measuredref['file'],record['final_adoption_ref']],
          '予測実測比較':{'状態':'一致' if consistent else '未確認' if measured['実測目的効果'] is None else '不一致',
                           '全実測':measured,'根拠参照':[measuredref['file']]}}
        intent=ref(self.transport_directory/(self.step_nonce+'.intent.json'))
        memory=self.final.日本語記憶へ(self.step_result,record,self.public_ref,intent,language)
        self.memory_ref=self.packet('Japanese_RuntimeMemory',memory)
        status=outcome(memory,measured,chosen,preservation,projected,boundary,self.step_result['analysis'])
        return {'status':status,'memory':self.memory_ref,'comparison':measuredref,'state':afterquery,'step':self.step_result,'before_state':self.step_before_state,'before_public':self.public_ref,'request_id':self.step_nonce}
    def finish(self,status,result):
        self.name_prefix=''
        last,value=self.standard('normal_final')
        expected=self.dec(self.enc(self.initial))
        for k in ('照会','学習判定'):expected['識別子状態'][k]=expected['識別子状態'].get(k,0)+len(self.calls)
        if not same(self.enc(expected),self.enc(value)):raise ValueError('final complete knowledge/ledger/history closure')
        for pinned in self.contract['source_pins']+self.contract['core_and_family_pins']:read(pinned,8*M)
        for name in ('state','audit','actual_tools','completion'):read(self.gate['closed_baseline'][name],8*M)
        diagnostics=self.factory.diagnostics();dr=self.save('sdk_diagnostics.json',diagnostics)
        io_failure=any(x.get('write_error') for x in diagnostics['sdk_io'])
        if diagnostics['sdk_events'] or diagnostics['denials'] or diagnostics['exceptions'] or io_failure:status='HOLD'
        result={'schema':'column-live-loop-completion-v1','nonce':self.nonce,'status':status,'errors':[],
          'baseline':self.gate['closed_baseline'],'states':self.states,'calls':self.calls,'current_public':self.public_ref,'before_current_public':self.before_current_public,'final_public_response':self.final_public_response,'stop_on_level_success':self.gate['stop_on_level_success'],
          'Action_attempted':self.factory.step_attempted,'Action_returned':self.factory.step_returned,'Query':len(self.calls),'Teach':0,
          'result':result,'step':self.step_result,'trajectory':self.trajectory,'sdk_diagnostics':dr,'all_saved_refs':copy.deepcopy(self.refs),
          'hidden':'未観測','reward':'未観測','new_independent_support':0,'next_step':'この有限runは停止。追加教示・追加runは別承認'}
        r=self.save('completion.json',result);self.complete=True;return r
    def failure(self,e):
        # Capture originals before any recovery writer mutates pending/current.
        origin_pending=self.pending;origin_current=self.current;durable_refs=copy.deepcopy(self.refs)
        self.errors.append({'type':type(e).__name__,'args':e.args,'traceback':traceback.format_exc()})
        components={};recovery_errors=[]
        def attempt(name,fn):
            try:components[name]=fn()
            except BaseException as secondary:
                item={'component':name,'type':type(secondary).__name__,'args':secondary.args,'traceback':traceback.format_exc()}
                recovery_errors.append(item);self.errors.append(item)
        attempt('trace',lambda:self.packet('failure_original_trace',self.errors))
        if isinstance(origin_pending,dict) and type(origin_pending.get('raw')) is bytes:
            attempt('pending_bytes',lambda:self.save_raw('failure_original_pending.bytes',origin_pending['raw']))
            pending_description={k:v for k,v in origin_pending.items() if k!='raw'}
            pending_description['raw_file']=components.get('pending_bytes')
        else:pending_description=origin_pending
        attempt('current_query',lambda:self.packet('failure_current_query',origin_current))
        if self.factory is not None:
            attempt('diagnostics',lambda:self.packet('failure_diagnostics',self.factory.diagnostics()))
            if self.factory.current is not None:
                attempt('public',lambda:self.save('failure_current_public.json',self.factory.public_bytes(self.factory.current),raw=True))
        if self.machine is not None:attempt('normal_state',lambda:self.standard('failure_normal_state')[0])
        # Only this single unfinished/prepared component may lack an exact typed
        # packet. Do not repeat the entire run's replies or trajectories.
        attempt('prepared',lambda:self.packet('failure_last_prepared',getattr(self,'prepared',None)))
        def refs_for_replay():
            links=[]
            for record in self.all_replay_records:
                link=record['reference'];reconstructed=replay_from_packet(link,self.dec)
                if not same(self.enc(reconstructed),self.enc(record)):raise ValueError('failure replay full type/order/value')
                links.append(link)
            return links
        attempt('all_replay_records',refs_for_replay)
        def refs_for_trajectory():
            files=[r for r in durable_refs if Path(r['path']).name.endswith('_step_outcome.typed.json.xz')]
            if len(files)!=len(self.trajectory):raise ValueError('failure trajectory reference count')
            for r,value in zip(files,self.trajectory):
                if not same(self.enc(self.dec(json.loads(read_typed_file(r)))),self.enc(value)):raise ValueError('failure trajectory full equality')
            return files
        attempt('trajectory',refs_for_trajectory)
        def semantic_ref():
            value=getattr(self,'semantic',None)
            if value is None:return None
            files=[r for r in durable_refs if Path(r['path']).name.endswith('_current_complete_semantic.typed.json.xz')]
            if not files or not same(self.enc(self.dec(json.loads(read_typed_file(files[-1])))),self.enc(value)):raise ValueError('failure semantic full equality')
            return files[-1]
        attempt('semantic',semantic_ref)
        def verify_all_references():
            # Keep original ordered refs and verify every nested exact FileRef,
            # including transport/dossier/standard refs outside that list.
            found=[]
            def walk(value):
                if type(value)is dict:
                    if set(('path','bytes','sha256'))<=set(value):
                        read(value,16*M);found.append(copy.deepcopy(value));return
                    for v in value.values():walk(v)
                elif type(value)in (list,tuple):
                    for v in value:walk(v)
            walk(durable_refs);walk(self.calls);walk(self.states);walk(self.trajectory)
            walk(getattr(self,'prepared',None));walk(getattr(self,'semantic',None));walk(self.step_result);walk(components)
            return found
        attempt('verified_all_references',verify_all_references)
        manifest_ref=self.packet('failure_reference_manifest',{'schema':'column-live-loop-failure-references-v1','nonce':self.nonce,
            'errors':self.errors,'recovery_errors':recovery_errors,'durable_refs_in_original_order':durable_refs,
            'components':components,'pending_description':pending_description,'calls':self.calls,'states':self.states,
            'last_step':self.step_result,'unprocessed':{'step_index':self.step_index,'current_query_ordinal':None if origin_current is None else origin_current['ordinal'],
                'remaining_candidate_queries':'not completed; no fabricated suffix','next_Action':'not dispatched unless a transport intent says otherwise'},
            'automatic_retry':False,'complete_recovery':not recovery_errors})
        if not recovery_errors:self.failure_closed_ref=manifest_ref
        return manifest_ref

def main(path,pin):
    global OWNER
    if OWNER is not None:raise RuntimeError('one owner, no rerun')
    OWNER=Run()
    try:
        OWNER.preflight(path,pin);result=OWNER.execute();OWNER.clock.stop()
        print(json.dumps({'status':'complete','receipt':result,'Action':OWNER.factory.step_attempted}),flush=True)
        return result
    except BaseException as e:
        try:
            OWNER.failing=True
            if hasattr(OWNER,'clock'):OWNER.clock.stop();OWNER.clock.remaining['failure_save']=120;OWNER.clock.enter('failure_save')
            if hasattr(OWNER,'enc'):OWNER.failure(e)
            else:guard.save('failure','preflight_'+str(time.time_ns())+'.json',jsonbytes({'type':type(e).__name__,'args':e.args,'traceback':traceback.format_exc()}))
        except BaseException as second:
            OWNER.errors.append({'secondary_type':type(second).__name__,'secondary_traceback':traceback.format_exc()})
        finally:
            if hasattr(OWNER,'clock'):OWNER.clock.stop()
        if getattr(OWNER,'failure_closed_ref',None) is not None:
            print(json.dumps({'status':'failed_closed','failure_manifest':OWNER.failure_closed_ref,'automatic_retry':False},ensure_ascii=False),flush=True)
            raise
        print(json.dumps({'status':'failed_held','errors':OWNER.errors,'automatic_retry':False},ensure_ascii=False),flush=True)
        while True:time.sleep(3600)
if __name__=='__main__':main(sys.argv[1],sys.argv[2])
