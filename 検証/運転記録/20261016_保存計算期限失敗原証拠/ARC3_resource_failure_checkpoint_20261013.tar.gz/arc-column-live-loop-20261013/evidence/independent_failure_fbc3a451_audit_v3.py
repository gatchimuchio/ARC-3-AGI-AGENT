import resource
resource.setrlimit(resource.RLIMIT_AS,(512<<20,512<<20))
import sys,json,lzma,hashlib,base64,copy,dataclasses,signal,traceback
from pathlib import Path
B=Path('/workspace/scratch/a94ff513b3af');L=B/'arc-column-live-loop-20261013';N='fbc3a4515a9efd5ed222dcc317e472fa';D=L/'evidence'/N;F=L/'failure'/N
sys.path[:0]=[str(L/'source'),str(B/'arc-recovery-main-20261013/repository/HDS/学習系統/v0.4.2')]
import loop_guard_v1 as guard
from hds学習系統.永続化 import _符号化 as enc,_復号 as dec
def sha(b):return hashlib.sha256(b).hexdigest()
def js(b):return json.loads(b)
def same(a,b):
 if type(a)is not type(b):return False
 if type(a)is dict:return list(a)==list(b) and all(same(a[k],b[k]) for k in a)
 if type(a)in(list,tuple):return len(a)==len(b) and all(same(x,y) for x,y in zip(a,b))
 return a==b
inventory={}; refs={}; decoded_count=0
def read(p):
 p=Path(p);s=p.stat();b=p.read_bytes();assert (p.stat().st_dev,p.stat().st_ino,p.stat().st_size,p.stat().st_mtime_ns,p.stat().st_ctime_ns)==(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
 inventory[str(p)]={'path':str(p),'bytes':len(b),'sha256':sha(b)}
 return b
def exact(r):
 key=r['path']
 if 'sdk-runtime' in Path(key).parts:
  assert Path(key).stat().st_size==r['bytes'];return
 if key not in inventory:read(key)
 assert inventory[key]=={k:r[k] for k in ('path','bytes','sha256')}
 refs[key]=inventory[key]
def unzip(b):
 z=lzma.LZMADecompressor(memlimit=128<<20);raw=z.decompress(b,max_length=(16<<20)+1)
 assert z.eof and not z.unused_data and z.check==lzma.CHECK_CRC64 and len(raw)<=16<<20
 return raw
def typed(b):
 global decoded_count
 raw=unzip(b);tag=js(raw);v=dec(tag);assert same(enc(v),tag);decoded_count+=1
 return v,raw
def walk(x):
 if dataclasses.is_dataclass(x):
  for f in dataclasses.fields(x):walk(getattr(x,f.name))
 elif type(x)is dict:
  if {'path','bytes','sha256'}<=x.keys() and type(x['path'])is str:exact(x)
  if {'file','rawbytes','rawsha256'}<=x.keys():
   exact(x['file']);raw=unzip(Path(x['file']['path']).read_bytes());assert len(raw)==x['rawbytes'] and sha(raw)==x['rawsha256']
  for v in x.values():walk(v)
 elif type(x)in(list,tuple):
  for v in x:walk(v)
def public(v):
 if 'frames' not in v or 'model_json' not in v:return
 assert v['frame_count']==len(v['frames'])
 for i,f in enumerate(v['frames']):
  b=base64.b64decode(f['base64'],validate=True)
  assert f['ordinal']==i and len(b)==f['bytes'] and sha(b)==f['sha256']
  assert f['dtype']=='|i1' and f['shape']==[64,64] and len(b)==4096 and f['order']=='C'
def main():
 signal.signal(signal.SIGALRM,lambda *a:(_ for _ in ()).throw(TimeoutError('audit300')))
 signal.alarm(300);guard.guard('evidence',2<<20)
 toolpath=L/'evidence/actual_live_loop_tools_fbc3a451_v1.json';tools=js(read(toolpath))
 assert sha(Path(toolpath).read_bytes())=='a23d7e08187cd1d7ba14fa3cecfbd1508336454880664260221f0a7a472b8b57'
 assert tools['actual_exit'] is None and tools['owner_session']==71555
 failed=js(tools['polls'][-1]['output']);assert failed['status']=='failed_held'
 assert failed['errors'][0]['type']=='TimeoutError' and failed['errors'][0]['args']==['column save aggregate deadline']
 assert failed['errors'][1]['secondary_type']=='MemoryError' and 'complete typed raw16MiB' in failed['errors'][1]['secondary_traceback']
 intents={};replies={};steps=[];states=[];publics=[];opaque=[];rawreplytotal=0
 # Only public evidence and ordinary capture files. Never open SDK opaque streams or source bodies.
 for folder in (D,F):
  for p in sorted(folder.rglob('*')):
   if not p.is_file():continue
   if 'sdk-runtime' in p.parts:
    opaque.append({'path':str(p),'bytes':p.stat().st_size,'read':False});continue
   b=read(p);v=None
   if p.name.endswith('.typed.json.xz') or p.name.endswith('_failure_original_pending.bytes'):
    v,raw=typed(b)
    if '_query_' in p.name or p.name.endswith('_failure_original_pending.bytes'):
     if p.name.endswith('_intent.typed.json.xz'):intents[v['ordinal']]=(p,v)
     else:replies[v['ordinal']]=(p,v);rawreplytotal+=len(raw)
    if p.name.endswith('_step_outcome.typed.json.xz'):steps.append((p,v))
   elif p.name.endswith('.standard.json'):
    tag=js(b);v=dec(tag);assert same(enc(v),tag);states.append((p,v))
   elif p.suffix=='.json':
    v=js(b);public(v)
    if type(v)is dict and 'frames' in v and 'model_json'in v:publics.append((p,v))
   if v is not None:walk(v)
 assert len(intents)==len(replies)==643 and list(sorted(intents))==list(range(643))
 assert len(steps)==29 and len(states)==31
 initial=next(v for p,v in states if p.name=='restored_before_current_queries.standard.json')
 assert initial['識別子状態']['照会']==initial['識別子状態']['学習判定']==504
 state_report=[]
 for p,v in states:
  n=v['識別子状態']['照会']-504;expected=copy.deepcopy(initial)
  for k in ('照会','学習判定'):expected['識別子状態'][k]+=n
  assert same(enc(v),enc(expected))
  state_report.append({'ref':inventory[str(p)],'completed_native_queries':n})
 for i in range(643):
  ip,a=intents[i];rp,b=replies[i]
  for k in ('ordinal','frame','method','input','origin','before'):assert same(enc(a[k]),enc(b[k]))
  assert b['method']=='照会する' and b['capture']['raw'] and 'return' in b['capture']
  before=copy.deepcopy(b['before']);after=b['after']
  assert before['identifiers']['照会']==before['identifiers']['学習判定']==504+i
  for k in ('照会','学習判定'):before['identifiers'][k]+=1
  assert same(before,after)
  assert b['origin']['観測通番']==b['frame']
  assert b['origin']['live採否可能'] is True
 pendingpath,pending=replies[642]
 assert pendingpath.parent==F and pending['frame']==29 and pending['after']['identifiers']['照会']==1147
 assert not list(D.glob('*query_0642_reply*'))
 last=None;step_report=[]
 for ordinal,(p,s) in enumerate(steps):
  assert int(p.name.split('_')[1])==ordinal
  if last:
   assert s['before_state']==last['state'] and s['before_public']==last['step']['public_response']
  calls=[b for _,b in replies.values() if b['frame']==ordinal]
  assert calls
  assert all(b['origin']['公開観測参照']==s['before_public'] and b['origin']['復元状態参照']==s['before_state'] for b in calls)
  assert s['step']['status']=='recorded'
  response=js(Path(s['step']['public_response']['path']).read_bytes());public(response)
  a=s['step']['analysis']
  assert a['response_phases']==len(response['frames']) and a['completed_after']==response['model_json']['levels_completed']
  step_report.append({'ordinal':ordinal,'outcome':inventory[str(p)],'status':s['status'],'queries':len(calls),'request_id':s['request_id'],'action':s['step']['action'],'phases':a['response_phases'],'levels_before':a['completed_before'],'levels_after':a['completed_after'],'before_public':s['before_public'],'response':s['step']['public_response'],'state':s['state'],'memory':s['memory'],'comparison':s['comparison']})
  last=s
 assert all(v['origin']['公開観測参照']==last['step']['public_response'] for _,v in replies.values() if v['frame']==29)
 assert len(list((D/'transport').glob('*.response.json')))==29
 assert not (D/'completion.json').exists() and not list(F.glob('*failure_full_owner_evidence*'))
 failstate=next((p,v) for p,v in states if p.parent==F)
 assert failstate[1]['識別子状態']['照会']==1147
 fp=next((p,v) for p,v in publics if p.parent==F)
 lastpublic=js(Path(last['step']['public_response']['path']).read_bytes())
 # failure recapture's JSON formatting differs; verify complete public value equality.
 assert fp[1]['nonce']==N and lastpublic['nonce']==last['request_id']
 assert {k:v for k,v in fp[1].items() if k!='nonce'}=={k:v for k,v in lastpublic.items() if k!='nonce'}
 report={'schema':'column-live-loop-resource-failure-independent-audit-v1','status':'SAVED_PREFIX_VERIFIED_RUN_FAILED_HELD','nonce':N,'native_success':False,'native_actual_exit':None,'owner_session':71555,
 'errors_original':failed['errors'],'actual_tools':inventory[str(toolpath)],
 'verified':{'all_saved_typed_packets_CRC_EOF_type_order':True,'all_encountered_exact_refs':True,'all31_normal_states_only_two_counters':True,'643_intent_reply_pairs_including_recovered_pending':True,'29_durable_step_public_state_query_chains':True,'public_frames_complete_bytes':True},
 'counts':{'durable_steps':29,'action_response_files':29,'native_queries':643,'ordinary_replies':642,'recovered_reply':1,'intents':643,'normal_states':31,'typed_packets':decoded_count,'reply_raw_bytes_including_pending':rawreplytotal,'response_phases':sum(s['phases'] for s in step_report),'last_counter':1147},
 'steps':step_report,'states':state_report,'recovered_pending_reply':inventory[str(pendingpath)],'failure_public':inventory[str(fp[0])],'failure_normal_state':inventory[str(failstate[0])],
 'unfinished_suffix':{'current_step':29,'query_ordinal_saved_in_pending':642,'full_current_semantic_saved':False,'current_candidate_enumeration_completed':False,'current_final_adoption_or_Action_saved':False,'remaining_queries_candidates':'unknown; do not infer absent candidates or rejection','steps30_31':'not processed under cap32','further_game_levels':'unprocessed/unknown'},
 'RAM_only_or_unproven_durable':['full failure envelope rejected at raw16MiB','original exception objects and traceback frames','in-progress semantic/candidate locals and pending full enumeration','whole live-owner aliases; latest diagnostic aggregation is not serialized as failure envelope, but step28 durable diagnostics precede no further make/Action'],
 'limits':['Run is incomplete resource failure. Partial public level progress is not run success.','Existing individual memory/effect/candidate/support files are preserved and decoded; this bounded failure audit does not repeat every semantic inference or native call.','Source guarantees owner reference retention; independent reader did not inspect live process heap.','Opaque SDK files stat only, no game source or opaque text read.'],
 'inventory':list(inventory.values()),'all_exact_refs':list(refs.values()),'opaque_stat_only':opaque}
 signal.alarm(0)
 raw=(json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode();assert len(raw)<2<<20
 ref=guard.save('evidence','independent_failure_fbc3a451_summary_v1.json',raw)
 print(json.dumps({'status':report['status'],'report':ref,'counts':report['counts']},ensure_ascii=False),flush=True)
if __name__=='__main__':
 try:main()
 except BaseException:
  signal.alarm(0);raw=traceback.format_exc().encode();print(raw.decode(),flush=True)
  guard.save('failure','independent_failure_fbc3a451_audit_error_v3.txt',raw);raise
