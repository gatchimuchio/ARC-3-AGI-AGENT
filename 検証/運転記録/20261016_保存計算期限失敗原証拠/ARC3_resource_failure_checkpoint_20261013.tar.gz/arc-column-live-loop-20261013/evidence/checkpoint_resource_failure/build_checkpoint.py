import os,sys,json,hashlib,tarfile,gzip,resource,shutil,time,lzma
from pathlib import Path
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
ROOT=Path('/workspace/scratch/a94ff513b3af'); L=ROOT/'arc-column-live-loop-20261013'; OUT=L/'evidence/checkpoint_resource_failure'; M=1024**2
FAILED='fbc3a4515a9efd5ed222dcc317e472fa'; ACTIVE='13666f5950be6c8e93a2510e91b951ed'
selected=set(); expected={}
def add(p):
 p=Path(p);p=p if p.is_absolute() else ROOT/p
 assert ACTIVE not in str(p) and not any(x in p.parts for x in ['sdk-runtime','HDS','.git','arc-sdk-venv','environment_files']) and p.suffix!='.opaque',str(p)
 assert p.is_file() and not p.is_symlink(),str(p)
 selected.add(p)
def tree(p):
 for base,dirs,files in os.walk(p):
  dirs[:]=[x for x in dirs if x not in ['sdk-runtime','__pycache__'] and ACTIVE not in x]
  for n in files:
   if not n.endswith(('.opaque','.pyc')):add(Path(base)/n)
def refs(x):
 if isinstance(x,dict):
  if set(['path','bytes','sha256'])<=set(x):yield x
  for v in x.values():yield from refs(v)
 elif isinstance(x,list):
  for v in x:yield from refs(v)
def sha(p):
 h=hashlib.sha256();n=0
 with open(p,'rb') as f:
  while b:=f.read(1024*1024):h.update(b);n+=len(b)
 return n,h.hexdigest()
for p in (ROOT/'arc-recovery-authority-20261013').glob('Owner*.md'):add(p)
for n in ['AGENTS.md','運用/権限順序.md','制御/現在状態.json']:add(ROOT/'arc-recovery-main-20261013/repository'/n)
for cat in ['evidence','failure']:tree(L/cat/FAILED)
for p in (L/'source').iterdir():
 if p.is_file() and ACTIVE not in p.name and not p.name.startswith('root_loop_release_'):add(p)
add(L/'source'/('root_loop_release_'+FAILED+'.json'))
for n in ['independent_failure_fbc3a451_summary_v1.json','independent_failure_fbc3a451_actual_tools_v1.json','actual_live_loop_tools_fbc3a451_v1.json','failed_owner_71555_actual_exit_v1.json','failure_preparation_actual_tools_v1.json','failed_prefix_closure_pure_v1.json','continuation_preparation_actual_tools_v1.json']:
 add(L/'evidence'/n)
for p in (L/'evidence').glob('independent_failure_fbc3a451_audit_v*.py'):add(p)
for p in (L/'failure').glob('independent_failure_fbc3a451_audit_error_v*.txt'):add(p)
for p in (L/'evidence').glob('pure_failure_v*.typed.json.xz'):add(p)
for cat in ['evidence','failure']:
 for p in (L/cat).glob('pure-failure-v*'):tree(p)
for v in [3,5]:
 d=json.loads((L/f'source/loop_contract_v{v}.json').read_text())
 for r in d['source_pins']+d['core_and_family_pins']:
  p=Path(r['path'])
  if 'HDS' not in p.parts:add(p);expected[p]=(r['bytes'],r['sha256'])
# Source dependencies are plain connection-layer files, never imported or executed.
audit=json.loads((L/'evidence/independent_failure_fbc3a451_summary_v1.json').read_text())
for r in audit['inventory']:
 p=Path(r['path']);add(p);expected[p]=(r['bytes'],r['sha256'])
for n,size,digest in [
 ('evidence/independent_failure_fbc3a451_summary_v1.json',1207611,'af1bfac89d4ae5a55dd20b0c6580b1e0a0d5036170d2bdd053096b3b72372a84'),
 ('evidence/independent_failure_fbc3a451_actual_tools_v1.json',4934,'3b06accb4163c5ba70db6778e8e3017ac6c6a303fd17ea8a5294e64a79d0a3ce'),
 ('evidence/actual_live_loop_tools_fbc3a451_v1.json',16361,'a23d7e08187cd1d7ba14fa3cecfbd1508336454880664260221f0a7a472b8b57'),
 ('evidence/failed_owner_71555_actual_exit_v1.json',719,'c41ee856af362070f18fe656ac0fbb36557f17f022891838631eb8d16d9de6bd'),
 ('source/loop_live_v10.py',35621,'6b8f63ed1ee60174f1886f4303e5c5377c9e89c120be03f724b35630662a0ccb'),
 ('source/loop_contract_v5.json',31304,'725851181d85d2fe5b0e54b93b10b81734e396893b53dacca235111396a10a87')]:expected[L/n]=(size,digest)
add(OUT/'build_checkpoint.py');add(OUT/'報告書.md')
mem=dict((s.split(':')[0],int(s.split()[1])*1024) for s in Path('/proc/meminfo').read_text().splitlines() if s.startswith('MemAvailable:'))['MemAvailable']
free=shutil.disk_usage(ROOT).free
assert free>= (2516+1024+32)*M and mem>=(5632+2048)*M,(free,mem)
rows=[]
for p in sorted(selected):
 n,h=sha(p)
 if p in expected:assert (n,h)==expected[p],str(p)
 rows.append({'path':str(p.relative_to(ROOT)),'bytes':n,'sha256':h})
manifest={'schema':'ARC3-resource-failure-checkpoint-source-manifest-v1','failed_nonce':FAILED,'status':'RESOURCE_FAILED_CLOSED_EXIT130_NOT_SUCCESS','achieved_levels':{'before':1,'after':1,'total':183},'source_count':len(rows),'source_bytes':sum(r['bytes'] for r in rows),'files':rows,'excluded':['active run '+ACTIVE+' and its files','opaque SDK bytes','game implementation and HDS core bodies','prior first-success archive contents (referenced separately)'],'baseline_archive':{'path':'arc-column-live-loop-20261013/evidence/checkpoint_first_level/ARC3_first_fresh_level_checkpoint_20261013.tar.gz','sha256':'5a063272f5eb967c051fb54e0d896f4d774aa54990b97f93627aec0445290b0d','verification':'parent-supplied prior delivered reference; not reread or duplicated'},'resource_limits':{'checkpoint_bytes':32*M,'worker_AS_bytes':512*M,'L_scope_bytes':1024*M,'source_bytes':16*M,'evidence_bytes':976*M,'failure_bytes':32*M,'global_future_bytes':2516*M,'disk_floor_bytes':1024*M,'RAM_reserved_bytes':5632*M,'RAM_floor_bytes':2048*M},'resource_observation':{'disk_free_bytes':free,'RAM_available_bytes':mem}}
mp=OUT/'source_manifest.json';mp.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
allrows=rows+[{'path':str(mp.relative_to(ROOT)),'bytes':sha(mp)[0],'sha256':sha(mp)[1]}]
arc=OUT/'ARC3_resource_failure_checkpoint_20261013.tar.gz'
class LimitedWriter:
 def __init__(self,f):self.f=f
 def write(self,b):
  assert self.f.tell()+len(b)+sum(p.stat().st_size for p in OUT.iterdir() if p.is_file() and p!=arc)<32*M,'checkpoint cap'
  return self.f.write(b)
 def flush(self):return self.f.flush()
with open(arc,'wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=LimitedWriter(raw),compresslevel=6,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT) as tf:
   for r in allrows:
    p=ROOT/r['path'];ti=tf.gettarinfo(str(p),arcname=r['path']);ti.uid=ti.gid=0;ti.uname=ti.gname='';ti.mtime=0
    with open(p,'rb') as f:tf.addfile(ti,f)
  gz.flush()
 raw.flush();os.fsync(raw.fileno())
# Check every archived byte against current closed source bytes and the pre-archive digest.
seen=[];source_bytes=0;index={r['path']:r for r in allrows}
with tarfile.open(arc,mode='r|gz') as tf:
 for ti in tf:
  assert ti.isfile() and ti.name in index and ti.name not in seen
  r=index[ti.name];assert ti.size==r['bytes'];h=hashlib.sha256();n=0
  with tf.extractfile(ti) as af,open(ROOT/ti.name,'rb') as sf:
   while b:=af.read(M):
    assert b==sf.read(len(b)),ti.name
    h.update(b);n+=len(b)
   assert sf.read(1)==b''
  assert (n,h.hexdigest())==(r['bytes'],r['sha256']),ti.name
  seen.append(ti.name);source_bytes+=n
assert set(seen)==set(index)
# Separate complete gzip read through true EOF forces trailer CRC32 and ISIZE verification.
uncompressed=0;tail=b''
with gzip.open(arc,'rb') as g:
 while b:=g.read(M):uncompressed+=len(b);tail=(tail+b)[-10240:]
 assert g.read(1)==b''
assert uncompressed%512==0 and tail[-1024:]==b'\0'*1024
for r in rows:assert sha(ROOT/r['path'])==(r['bytes'],r['sha256'])
size,h=sha(arc)
validation={'schema':'ARC3-resource-failure-checkpoint-validation-v1','status':'PASS','archive':{'path':str(arc),'bytes':size,'sha256':h},'manifest':{'path':str(mp),'bytes':sha(mp)[0],'sha256':sha(mp)[1]},'verified_members':len(seen),'verified_archived_source_bytes':source_bytes,'source_file_count':len(rows),'source_bytes':manifest['source_bytes'],'streaming_archive_and_readback':True,'all_member_paths_sizes_sha256':True,'all_source_byte_for_byte':True,'all_sources_rehashed_after_archive':True,'gzip_CRC32_ISIZE_and_true_EOF':True,'tar_end_markers':True,'uncompressed_tar_bytes':uncompressed,'pinned_refs_verified':len(expected),'active_run_files_included':0,'opaque_bodies_read':0,'SDK_HDS_Action_Teach_calls':0,'worker_peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,'limits':manifest['resource_limits'],'scope_note':'Archive integrity verification only; semantic run findings remain attributed to the included historical independent audit and final exit proof. No active-run outcome assertion.'}
vp=OUT/'full_validation.json';vp.write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n')
assert sum(p.stat().st_size for p in OUT.iterdir() if p.is_file())<32*M
for p in [OUT/'報告書.md',mp,arc,vp,OUT/'build_checkpoint.py']:
 n,h=sha(p);print(json.dumps({'path':str(p),'bytes':n,'sha256':h},ensure_ascii=False))
print(json.dumps({'members':len(seen),'source_bytes':manifest['source_bytes'],'checkpoint_total_bytes':sum(p.stat().st_size for p in OUT.iterdir() if p.is_file()),'peak_rss_bytes':validation['worker_peak_rss_bytes']},ensure_ascii=False))
