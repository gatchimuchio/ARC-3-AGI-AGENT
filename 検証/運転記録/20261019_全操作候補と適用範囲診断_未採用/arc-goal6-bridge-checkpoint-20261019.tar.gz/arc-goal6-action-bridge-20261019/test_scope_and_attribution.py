import resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
import pathlib,json,gzip,lzma,sys,hashlib,collections
from bridge import phase,candidate
R=pathlib.Path(__file__).resolve().parent;T=R.parent/'arc-teacher-contrasts-20261019';sys.path.insert(0,str(T));from inspect_state import decode
raw=json.loads((T/'witnesses/source0_row65.json').read_bytes())['data'];obs=phase(raw['frame'][0],raw['state'],raw['available_actions'])
probes=[]
cases=[([],{'id':5,'data':{}}),([5],{'id':5,'data':{'x':999}}),([5],{'id':5,'data':{'x':0,'y':0}}),([6],{'id':6,'data':{'x':64,'y':0}}),([6],{'id':6,'data':{'x':-1,'y':0}}),([6],{'id':6,'data':{'x':True,'y':0}}),([6],{'id':6,'data':{'x':0}}),([6],{'id':6,'data':{'x':0,'y':0,'game_id':'forbidden'}}),([5],{'id':True,'data':{}}),([5],{'id':5}),([5],{'id':5,'data':None}),([5],{'id':5,'data':{},'extra':1}),([5,5],{'id':5,'data':{}}),([True],{'id':1,'data':{}}),(None,{'id':5,'data':{}})]
for available,action in cases:
 result=candidate(action,{**obs,'available':available});assert result['goal6_query_proposal'] is None and result['execution_permission'] is False
 probes.append({'available':available,'action':action,'result':result})
# Repeated calls are pure: same outputs and observation remains unchanged.
frozen=json.dumps(obs,ensure_ascii=False,sort_keys=True);one=candidate({'id':5,'data':{}},obs);assert one==candidate({'id':5,'data':{}},obs);assert frozen==json.dumps(obs,ensure_ascii=False,sort_keys=True)
for name in ['all_phases.json']:
 assert (R/name).read_bytes()==(R/'pre_fix_v1'/name).read_bytes()
with gzip.open(R/'all_legal_candidates.jsonl.gz','rb') as a,gzip.open(R/'pre_fix_v1/all_legal_candidates.jsonl.gz','rb') as b:
 h=hashlib.sha256();lines=0
 for x,y in zip(a,b,strict=True):assert x==y;h.update(x);lines+=1
assert lines==459312
(R/'scope_regression_v2.json').write_text(json.dumps({'invalid_scope_probes':probes,'repeated_call_pure':True,'all112_phase_outputs_byte_equal':True,'all459312_candidate_records_byte_equal':True,'uncompressed_candidate_sha256':h.hexdigest()},ensure_ascii=False,indent=2))
p=decode(json.loads(lzma.decompress(next((T/'pinned').glob('*/producer/*')).read_bytes())));allrows=[];summary=[]
for c in p['cases']:
 before=c['before_phases'][-1]['observation'];counts=collections.Counter();pixels=[]
 for target in c['before_hypothesis']['targets']:
  x,y=target['target'];pre=before['対象'][y][x];tool=before['器具色'];identified=pre!=tool
  measurements=[]
  for ap in c['after_phases']:
   po=ap.get('observation');bound=po is not None and po['参照']==before['参照'] and po['対象矩形']==before['対象矩形']
   if not bound:label='unknown_phase' if po is None else 'new_problem_unbound'
   elif not identified:label='unidentifiable_prior_equals_tool'
   else:
    after=po['対象'][y][x];label='observed_change_to_tool' if after==tool else 'observed_prior_preserved' if after==pre else 'other_color_change'
   measurements.append({'phase':ap['ordinal'],'same_problem_binding':bound,'after_color':po['対象'][y][x] if bound else None,'identification':label})
  terminal_old=[z for z in measurements if z['phase'] in (13,14)];assert len(terminal_old)==2
  assert terminal_old[0]['identification']==terminal_old[1]['identification'];label=terminal_old[0]['identification'];counts[label]+=1
  pixels.append({'target':[x,y],'before':pre,'tool':tool,'precondition_observably_identifiable':identified,'mask_hypothesis':target['geometry_candidate'],'all_after_phases':measurements,'endpoint_class':label,'independent_support_unit':'one original Action, not this pixel or phase'})
 summary.append({'case':c['ordinal'],'selection':c['selection'],'counts_100_targets':dict(counts),'new_independent_actions':0,'case3_all_unidentifiable':c['ordinal']==3 and counts['unidentifiable_prior_equals_tool']==100})
 allrows.append({'case':c['ordinal'],'selection':c['selection'],'before_row_ref':c['before_row_ref'],'after_row_ref':c['after_row_ref'],'all100_target_attributions':pixels})
assert summary[3]['case3_all_unidentifiable']
(R/'all6_full_attribution_v2.json').write_text(json.dumps(allrows,ensure_ascii=False,indent=2));(R/'attribution_summary_v2.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));print(json.dumps(summary,ensure_ascii=False))
