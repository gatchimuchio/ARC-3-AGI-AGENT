"""PURE diagnostic bridge. No native HDS/SDK/imported launchers/action authorization."""
import ast,json,pathlib
from collections import Counter,deque
from typing import Any
ROOT=pathlib.Path(__file__).resolve().parent

def pure_dependencies():
 env={'Counter':Counter,'deque':deque,'Any':Any}
 groups=[('ARC3境界.py',('境界違反','_列','_整数','_盤面列')),('図式観測.py',('成分群',)),('知覚.py',('bbox','connected','read','classify')),('関係.py',('membership',))]
 for filename,names in groups:
  tree=ast.parse((ROOT/'origins'/filename).read_text());nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in names]
  assert tuple(n.name for n in nodes)==names
  exec(compile(ast.Module(body=nodes,type_ignores=[]),filename+'::pure','exec'),env)
 tree=ast.parse((ROOT/'origins/固定文法.py').read_text());literals={n.targets[0].id:ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign)}
 return env,literals

P,L=pure_dependencies()
def sig(x):return json.dumps(x,ensure_ascii=False,separators=(',',':'))
BOUNDARY='公開100対象・広域塗布・固定幾何上書き仮説の修復保全条件組と公開進捗'
def phase(frame,status,available):
 # Caller provenance is not accepted by this function. No identity selector.
 errors=[];scene=None;template=False;payload=None
 try:scene=P['read'](frame)
 except (ValueError,TypeError,KeyError,IndexError) as e:errors.append({'type':type(e).__name__,'message':str(e)})
 if scene is not None:
  candidates=L['配置文法'].get(sig([scene['方向'],bool(scene['小器具矩形群'])]),[])
  template=len(candidates)==1 and sig(candidates[0]['画素'])==sig(scene['装置画素'])
  repair=[];preserve=[];targets=[]
  for y in range(10):
   for x in range(10):
    goal=scene['参照'][y][x];current=scene['対象'][y][x];inside=P['membership'](scene['方向'],x,y,10,'広域塗布');predicted=scene['器具色'] if inside else current
    (preserve if goal==current else repair).append(predicted==goal)
    targets.append({'target':[x,y],'public_goal':goal,'before':current,'mask_hypothesis':inside,'predicted':predicted})
  payload={'内容':{'作用前の修復保全条件組':sig([all(repair),all(preserve)])},'対象系境界':BOUNDARY,'主体':None,'対象':None,'目的':None,'文脈':{}}
 else:targets=[]
 return {'status':status,'available':available,'scene':scene,'errors':errors,'exact_existing_device_template':template,'goal6_query_proposal':payload,'targets':targets,'execution_permission':False,'unresolved':['fixed Action5 role not independent mapping proof','COPY/MASK/TURN evidence not installed by goal6 endpoint learning','all-phase causal preservation unproved','public reference equality is hypothesis, not unique success condition']}

def legal_candidates(frame,available):
 # Exact exhaustive public64x64 candidate domain used by existing all_candidates.
 if type(available) is not list or len(set(available))!=len(available) or any(type(a)is not int or a<0 or a>7 for a in available):raise ValueError('unknown public action availability contract')
 for a in available:
  if a==6:
   for y in range(len(frame)):
    for x in range(len(frame[y])):yield {'id':6,'data':{'x':x,'y':y}}
  else:yield {'id':a,'data':{}}

def action_scope_error(action,observation):
 available=observation.get('available')
 if type(available) is not list or any(type(a)is not int or not 0<=a<=7 for a in available) or len(set(available))!=len(available):return 'malformed public availability'
 if type(action) is not dict or set(action)!={'id','data'}:return 'exact action id/data mapping required'
 if type(action['id']) is not int or action['id'] not in available:return 'action unavailable or invalid'
 data=action['data']
 if type(data) is not dict:return 'action arguments must be dictionary'
 if action['id']==6:
  if set(data)!={'x','y'} or any(type(data[k])is not int or not 0<=data[k]<64 for k in ('x','y')):return 'click requires exact bounded integer x/y'
 elif data:return 'non-click action takes no arguments'
 return None

def candidate(action,observation):
 error=action_scope_error(action,observation)
 if error is not None:return {'action':action,'role_hypothesis':{'役割':'未確認'},'goal6_query_proposal':None,'state':'HOLD','execution_permission':False,'reason':error}
 scene=observation['scene'];role={'役割':'未確認','番号':action['id']}
 if scene is not None:role=P['classify'](scene,action)
 query=observation['goal6_query_proposal'] if scene is not None and action['id']==5 and observation['exact_existing_device_template'] and observation['status']=='NOT_FINISHED' else None
 return {'action':action,'role_hypothesis':role,'goal6_query_proposal':query,'state':'HOLD','execution_permission':False,'reason':'diagnostic structural hypothesis only; causal action mapping/whole-response gate unresolved'}
