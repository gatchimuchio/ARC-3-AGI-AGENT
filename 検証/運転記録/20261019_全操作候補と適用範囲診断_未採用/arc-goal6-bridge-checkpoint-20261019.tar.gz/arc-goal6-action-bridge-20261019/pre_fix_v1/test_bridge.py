import resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
import json,gzip,pathlib,lzma,sys,hashlib,time,traceback
from bridge import phase,candidate,legal_candidates,sig
R=pathlib.Path(__file__).resolve().parent;T=R.parent/'arc-teacher-contrasts-20261019';sys.path.insert(0,str(T));from inspect_state import decode
packet=decode(json.loads(lzma.decompress(next((T/'pinned').glob('*/producer/*')).read_bytes())))
start=time.monotonic();count=0;phases=[];errors=[];counts={}
try:
 with gzip.open(R/'all_legal_candidates.jsonl.gz','wt',encoding='utf8') as out:
  for case in packet['cases']:
   si,b,a=case['selection']
   for side,row in [('before',b),('after',a)]:
    raw=json.loads((T/'witnesses'/f'source{si}_row{row}.json').read_bytes());data=raw['data']
    for index,frame in enumerate(data['frame']):
     o=phase(frame,data['state'],data['available_actions']);saved=case[side+'_phases'][index];pid=len(phases)
     assert (o['scene'] is None)==(saved['status']=='unknown')
     if o['scene'] is not None:assert sig(o['scene'])==sig(saved['observation'])
     if side=='before' and index==len(data['frame'])-1:
      assert json.loads(o['goal6_query_proposal']['内容']['作用前の修復保全条件組'])==list(case['query_input'].values())
     n=0;rolecounts={};proposals=0
     for action in legal_candidates(frame,data['available_actions']):
      result=candidate(action,o);assert result['execution_permission'] is False and result['state']=='HOLD';n+=1
      key=result['role_hypothesis']['役割'];rolecounts[key]=rolecounts.get(key,0)+1
      proposals+=result['goal6_query_proposal'] is not None
      out.write(json.dumps({'phase_ref':pid,**result},ensure_ascii=False,separators=(',',':'))+'\n')
     expected=sum(4096 if x==6 else 1 for x in data['available_actions']);assert n==expected
     phases.append({'phase_ref':pid,'case':case['ordinal'],'side':side,'source_index':si,'row':row,'phase':index,'raw_file':f'witnesses/source{si}_row{row}.json','raw_sha256':hashlib.sha256((T/'witnesses'/f'source{si}_row{row}.json').read_bytes()).hexdigest(),'raw_frame_sha256':hashlib.sha256(sig(frame).encode()).hexdigest(),'observation':o,'candidate_count':n,'role_counts':rolecounts,'query_proposal_count':proposals});count+=n
 assert len(phases)==112
 # Unknown/malformed/terminal cases are retained as HOLD; identity cannot enter API.
 f=packet['rows'][(0,65)]['data']['frame'][0];base=packet['rows'][(0,65)]['data'];o=phase(f,'WIN',base['available_actions']);assert candidate({'id':5,'data':{}},o)['goal6_query_proposal'] is None
 assert phase([[1]],'NOT_FINISHED',[5])['scene'] is None
 try:list(legal_candidates(f,[5,5]));raise AssertionError('duplicate available action accepted')
 except ValueError:pass
 result={'complete':True,'phases':112,'matched_historical_phase_interpretations':112,'measured':sum(p['observation']['scene'] is not None for p in phases),'unknown':sum(p['observation']['scene'] is None for p in phases),'legal_candidates':count,'all_HOLD':True,'execution_permissions':0,'query_proposals':sum(p['query_proposal_count'] for p in phases),'native_queries':0,'RSS_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'seconds':time.monotonic()-start}
except BaseException as e:
 result={'complete':False,'type':type(e).__name__,'error':str(e),'traceback':traceback.format_exc(),'phases_completed':len(phases),'candidates_completed':count};raise
finally:
 (R/'all_phases.json').write_text(json.dumps(phases,ensure_ascii=False,indent=2));(R/'test_result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result,ensure_ascii=False))
