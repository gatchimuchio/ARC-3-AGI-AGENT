# Public teacher targets, existing vocabulary first

## First recover historical states and source contracts

The existing own relation module declares COPY=`公開色対応:参照色と解答候補色`, MASK=`公開塗布:器具側幾何と可視上書き` (mode suffix), TURN=`公開器具:現在方向と方向作用`. Prediction code calls all three. Recover their actual learner/source contracts and public support/refutation joins before treating a serialized principle as transferable. Do not merge a separate historical state by editing native JSON; reuse verified teacher inputs through the actual frozen learning contract if adopted. No such historical learned-state closure is currently in this package.

## MASK: closest available next endpoint teacher

Existing X=`幾何領域候補に属する`; Y=`観測上この画素は器具色で上書き`. Six Action5 pairs already contain matching old-problem endpoints13/14 and explicit geometry. First inspect the historical training contract to decide whether Y meant endpoint color overwrite or continuous behavior; do not silently change boundary semantics.

Informative positive witness: pre-target color differs from current instrument color; pixel belongs to hypothesized half-plane; same bound target pixel at supported old-problem endpoint changes to instrument color. Informative negative: pre-color differs from instrument color and pixel lies outside mask; endpoint preserves pre-color. Retain inside-nochange/outside-change contradictions, prior-equal-tool pixels as unidentifiable, unknown phases, and new-problem terminal phases separately. All target coordinates/roles/relations and raw phases remain joined. At least both membership values must be witnessed; the frozen HDS minimum-support count is not a license to count correlated pixels/phases as independent actions. Cross-direction/color/device applicability needs new independent public action instances beyond duplicated views.

No new live observation is needed to inspect these6 endpoint contrasts, but no continuous-preservation claim follows. Smallest next offline unit is a full informative/ambiguous pixel attribution audit on these6 complete actions against the prior historical MASK contract. If the old contract is unavailable, keep proposed examples unadmitted rather than invent a replacement meaning.

## COPY: do not conflate two uses

Existing X=`候補色は参照役割色と一致`; Y=`候補色は結果役割色と一致`. Goal generation uses public reference-role color and expected target-role color; palette prediction reuses the same relation for selected-role color and resulting tool-role color. These are two causal applications, not automatically one equivalence proof.

For palette-to-tool: public before identifies a unique palette object and exact click-relative position; actual Action6 echo; every after phase and terminal tool color; unchanged reference/target/status/action availability except observed effects. Positive selected candidate and contrasting nonselected candidate colors must be joined to the same actual response without counting them as independent actions. Include unsupported click offsets, overlapping targets, no-change tool color and failed selections. At least an informative old-tool≠selected-color case and a different selected-color case are needed to distinguish copying from no-op/constant-color explanations. Generalizing every coordinate inside a rectangle requires explicit support or proved equivalence, not rectangle membership.

For reference-to-goal: a public completion/acceptance witness must establish the resulting target-role relation to the reference, including accepted partial-match alternatives. The6 endpoint-progress cases alone do not uniquely establish exact-reference equality as the necessary goal. Keep alternative acceptance explanations; do not teach guessed hidden target labels.

## TURN

Existing X=`現在方向と方向作用` serialized pair; Y=`後方向`. Before public device direction and exact Action1/2/3/4; after same-bound device direction, full tool shape/color/target deltas and availability. Retain failures/no-op/ambiguous rotations and changed-problem cases. To claim the complete existing8-direction×4-action table, all32 conditions need public witnesses, not extrapolation from one direction. A smaller admitted scope may cover only observed conditions and HOLD the remainder. At least contrasting actions or starting directions are necessary to distinguish a fixed ending orientation from an actual relative rotation; repeated identical view frames do not supply independent support.

## Action-role mapping and target permission

Current classify hardcodes action numbers to roles. Seek existing public-role/action teacher boundary before adding one. Needed witnesses compare actual Action5 effects with direction/selection/click effects under the same visible prerequisites. Establish that the action touches the intended target and does not create unsupported external changes. A legal action number is availability, not causal target permission. The goal6 tuple does not encode action identity, coordinates, target role or side effects, so cannot certify these facts.

## Device templates and intermediate phases

Existing12 templates are fixed visible relative pixel patterns. Reuse them as exact structural applicability hypotheses. Each accepted match must have observed relationship between tool role, direction, optional handle and target binding. Equal-size/largest-red ambiguity or multiple palette matches remains HOLD. Recover historical source joins for templates; do not treat matching pixels as proof of latent mechanic equality.

All77 unparsed phases remain in raw evidence. Determine whether they can be interpreted by existing public observation contracts without inventing roles. Their availability and packet-level status cannot be reinterpreted as per-frame status evidence. If exact roles remain unidentifiable, retain the limitation and keep whole-response action gate closed; endpoint teachers may still be scoped as endpoint only.

## Stopping condition

Stop before a fresh action when the current action-role mapping, prior applicability, target permission, or response-phase boundary cannot be established. Report the specific missing public comparison. This is a causal-evidence gap, not a reason to add heuristic pruning, replay lookup, or modify HDS.

### v2 exact attribution constraint

Observed endpoint changes-to-tool210, prior-preserved240, unidentifiable150 across600 cells; the independent unit remains six historical Actions, not450 informative pixels. Case3 contributes zero identifiable MASK targets (all100 prior=tool). Its apparent match cannot support the causal MASK. Any proposed MASK teacher must retain this observable precondition, full action provenance and correlated-view grouping; if existing native MASK contract cannot encode/justify that scope, do not feed its unqualified Boolean labels. Further comparison needs current≠tool targets both inside and outside the hypothesized mask, complete old-problem endpoint binding, and contrasting direction/color/device cases. Unknown intermediate phases remain unknown.
