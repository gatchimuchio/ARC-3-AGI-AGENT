import resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
import pathlib,json,gzip,hashlib,copy
B=pathlib.Path('/workspace/scratch/a94ff513b3af');R=B/'arc-goal6-action-bridge-20261019';O=B/'arc-goal6-bridge-review-20261019';T=B/'arc-teacher-contrasts-20261019'
n={'__file__':str(R/'bridge.py'),'__name__':'probe'};exec(compile((R/'bridge.py').read_bytes(),'bridge_v3','exec'),n)
f=json.loads((T/'witnesses/source0_row65.json').read_bytes())['data']['frame'][0];o=n['phase'](f,'NOT_FINISHED',[1,2,3,4,5,6]);out={}
probes=json.loads((R/'scope_regression_v2.json').read_bytes())['invalid_scope_probes']
for p in probes:
 r=n['candidate'](p['action'],{**o,'available':p['available']});assert r==p['result'] and r['goal6_query_proposal'] is None and r['state']=='HOLD'
out['scope_probes_recomputed']=len(probes)
# Actual-frame second plausible instrument probe.
f2=copy.deepcopy(f)
for y in range(50,53):
 for x in range(50,53):f2[y][x]=12 if (x,y)==(51,51) else 2
p=n['phase'](f2,'NOT_FINISHED',[5]);r=n['candidate']({'id':5,'data':{}},p);assert p['scene'] is None and r['goal6_query_proposal'] is None;out['multiple_plausible_actual_frame']={'observation':p,'candidate':r}
# Copy exact existing instrument pixels to a disjoint empty region, preserving equal red-component size.
s=o['scene'];x,y,X,Y=s['器具矩形'];dx=48-x;dy=48-y;f3=copy.deepcopy(f)
assert X+dx<=64 and Y+dy<63
for yy in range(y,Y):
 for xx in range(x,X):f3[yy+dy][xx+dx]=f[yy][xx]
p=n['phase'](f3,'NOT_FINISHED',[5]);r=n['candidate']({'id':5,'data':{}},p);assert p['scene'] is None and r['goal6_query_proposal'] is None;out['equal_size_actual_frame']={'copied_box':[x,y,X,Y],'destination':[48,48,X+dx,Y+dy],'observation':p,'candidate':r}
for name in ['bridge.py','test_bridge.py','MANIFEST.json']:assert (O/'prefix'/name).read_bytes()==(R/'pre_fix_v1'/name).read_bytes()
assert (R/'all_phases.json').read_bytes()==(R/'pre_fix_v1/all_phases.json').read_bytes()
with gzip.open(R/'all_legal_candidates.jsonl.gz','rb') as a,gzip.open(R/'pre_fix_v1/all_legal_candidates.jsonl.gz','rb') as b:
 count=0;h=hashlib.sha256()
 for x,y in zip(a,b,strict=True):assert x==y;h.update(x);count+=1
assert count==459312;out['pre_fix_sources_preserved']=True;out['phase_bytes_unchanged']=True;out['candidate_records_unchanged']=count;out['candidate_uncompressed_sha256']=h.hexdigest()
(O/'additional_probes_v3.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps(out,ensure_ascii=False,indent=2))
