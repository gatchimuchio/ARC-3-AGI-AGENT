import resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
import pathlib,json,gzip,hashlib,collections,tarfile
B=pathlib.Path('/workspace/scratch/a94ff513b3af');R=B/'arc-goal6-action-bridge-20261019';O=B/'arc-goal6-bridge-review-20261019';T=B/'arc-teacher-contrasts-20261019'
def rd(p):return json.loads(p.read_bytes())
def sha(b):return hashlib.sha256(b).hexdigest()
manifest=rd(R/'MANIFEST.json')
for ref in manifest['files']:
 b=(R/ref['path']).read_bytes();assert len(b)==ref['bytes'] and sha(b)==ref['sha256']
# Original archived own-source byte identity.
seen=[]
with tarfile.open(B/'arc-preservation-recovery-20261019/archives/goal6-checkpoint.tar.gz','r|gz') as t:
 for m in t:
  name=pathlib.Path(m.name).name;p=R/'origins'/name
  if p.exists() and '/repository/接続/' in m.name:
   b=t.extractfile(m).read()
   if b==p.read_bytes():seen.append(name)
ns={'__file__':str(R/'bridge.py'),'__name__':'review_pure_bridge'};exec(compile((R/'bridge.py').read_bytes(),'review_pure_bridge','exec'),ns)
phases=rd(R/'all_phases.json');counts=collections.Counter();proposals=collections.Counter();roles=collections.defaultdict(collections.Counter);total=0
# Each exact legal candidate appears exactly once and in the declared enumeration order, not only counts.
with gzip.open(R/'all_legal_candidates.jsonl.gz','rt') as f:
 for p in phases:
  raw=(T/p['raw_file']).read_bytes();assert sha(raw)==p['raw_sha256'];data=json.loads(raw)['data'];frame=data['frame'][p['phase']]
  assert sha(ns['sig'](frame).encode())==p['raw_frame_sha256']
  obs=ns['phase'](frame,data['state'],data['available_actions']);assert obs==p['observation']
  for a in ns['legal_candidates'](frame,data['available_actions']):
   record=json.loads(next(f));assert record=={'phase_ref':p['phase_ref'],**ns['candidate'](a,obs)}
   assert record['state']=='HOLD' and record['execution_permission'] is False
   counts[p['phase_ref']]+=1;proposals[p['phase_ref']]+=record['goal6_query_proposal'] is not None;roles[p['phase_ref']][record['role_hypothesis']['役割']]+=1;total+=1
  assert counts[p['phase_ref']]==p['candidate_count']==4101 and proposals[p['phase_ref']]==p['query_proposal_count'] and roles[p['phase_ref']]==p['role_counts']
 assert f.read()==''
assert total==112*4101==459312
# Independently derive the endpoint tests and retain per-cell informative/ambiguous attribution.
checks=rd(R/'mask_endpoint_checks.json');pixels=[];endpoint=[]
for ci in range(6):
 before=[p for p in phases if p['case']==ci and p['side']=='before'][-1]['observation']['scene'];aft=[p for p in phases if p['case']==ci and p['side']=='after'];actual=[]
 for p in aft:
  obs=p['observation']['scene']
  if obs is None:continue
  same=all(before[k]==obs[k] for k in ('参照','参照矩形','対象矩形'))
  pred=[[before['器具色'] if ns['P']['membership'](before['方向'],x,y,10,'広域塗布') else before['対象'][y][x] for x in range(10)] for y in range(10)]
  actual.append({'phase':p['phase'],'same_reference_target_rect':same,'target_matches_fixed_overwrite':obs['対象']==pred if same else None,'direction_unchanged':obs['方向']==before['方向'],'tool_color_unchanged':obs['器具色']==before['器具色']})
  if p['phase']==14:
   c=collections.Counter()
   for y in range(10):
    for x in range(10):
     old=before['対象'][y][x];new=obs['対象'][y][x];tool=before['器具色'];inside=ns['P']['membership'](before['方向'],x,y,10,'広域塗布')
     label=('prior_equal_tool_unidentifiable' if old==tool else 'informative_inside_change' if inside and new==tool else 'informative_outside_preserved' if not inside and new==old else 'contradiction');c[label]+=1
     pixels.append({'case':ci,'phase':14,'x':x,'y':y,'old':old,'new':new,'tool':tool,'membership_hypothesis':inside,'attribution':label})
   endpoint.append({'case':ci,'counts':dict(c),'independent_action_count':1})
 assert actual==checks[ci]['known_after_phase_checks'];assert sum(p['observation']['scene'] is None for p in aft)==11
# Probe API scope: no SDK or native operation. Preserve positive/negative behavior exactly.
f=json.loads((T/'witnesses/source0_row65.json').read_bytes())['data']['frame'][0];base=ns['phase'](f,'NOT_FINISHED',[1,2,3,4,5,6]);probes=[]
for name,available,action in [('unavailable_action5',[],{'id':5,'data':{}}),('malformed_action5_arguments',[5],{'id':5,'data':{'x':999}})]:
 ob=ns['phase'](f,'NOT_FINISHED',available);res=ns['candidate'](action,ob);probes.append({'name':name,'available':available,'action':action,'result':res})
# Frame parser biggest-component selection has no tie rejection; record source evidence, do not invent a role certification.
report={'manifest_files':len(manifest['files']),'archived_origins_verified':sorted(set(seen)),'phase_records':len(phases),'candidate_records_exactly_recomputed':total,'all_HOLD':True,'query_proposals':sum(proposals.values()),'endpoint_attributions':endpoint,'probes':probes,'native_calls':0,'SDK_calls':0,'Action_calls':0,'max_RSS_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(O/'pixel_attribution.json').write_text(json.dumps(pixels,ensure_ascii=False,indent=2));(O/'review_result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2))
