# Independent Goal6 diagnostic bridge review

## Verdict

Bounded PASS for this historical pure diagnostic corpus and endpoint comparison. BLOCK reuse as an action-authorizing gate or an availability/argument-validating query gate. No native learning or Action admission follows. The teacher plan's next offline attribution audit is legitimate, with the sharper limits below.

Owner instructions, AGENTS, hierarchy and current-state constraints were reread. HDS v0.4.2 remains unchanged. This review performed zero native/HDS/SDK/Action/Git calls. Only this separate review directory was written; original bridge sources were untouched. Exact pre-review bridge.py, test_bridge.py and MANIFEST.json are preserved under prefix/. The review ran with AS512MiB, peakRSS23,588KiB, far below96MiB output.

## Verified evidence

`review.py` and `review_result.json` retain checks. All19 manifest entries matched. All10 origins files were byte-joined to their archived own-source copies. Recomputed each112 phase record from its pinned raw frame and compared every one of459,312 decompressed candidate records to exhaustive legal enumeration in exact order. No aggregate-only replacement, missing candidates, duplicate candidates or pruned coordinate branches were found. Arithmetic:112×(5+64×64)=459,312. All records have state HOLD and execution_permission false. Exactly21 phase-local query proposals, not executed queries.

All6 mask endpoint checks independently reproduced: old-bound phases13/14 match the fixed overwrite hypothesis; early phases0/1 differ in5 cases; case3 matches early too; positive cases4/5 phase15 changes reference binding. Eleven after phases per case are unknown. Packet status/availability are shared metadata, not newly observed per-frame authority. The historical diagnostic frames do not authorize current-environment actions.

## Exact scope blockers before reuse

The bridge's candidate() does not validate its action against observation.available or validate action arguments. Preserved probes show it produces a Goal6 query proposal for (1) Action5 while available=[] and (2) Action5 with data={x:999}. Both still HOLD with permission false, so no authorization leak or flaw in the stored exhaustive historical enumeration was found. Nevertheless, an integration must not rely on this function as a fail-closed query applicability gate. Before reuse, enforce exact available-action membership and canonical argument contracts, with negative tests retained. No fix was applied here.

The inherited parser sorts red components by size and uses the largest without a competing-role ambiguity rejection. This is an unsupported structural role-selection assumption, explicitly admitted in README. Exact device-template matching can constrain inputs but does not establish unique causal instrument identity. Preserve all competing interpretations or reject ambiguity before any future causal-role/permission use. The current output labels it role_hypothesis and retains HOLD; that is acceptable only for diagnosis. Unknown phases have no certified role and no candidate query proposal.

pure_dependencies() reads origin files without enforcing hashes inside that function. This review verified manifest/archive pins before executing selected pure AST declarations. A future invocation must repeat a source-pin admission rather than assume this audit covers later edits. This is not native-module equivalence: only selected declarations were executed.

No game/level/hash/replay identifier selects a result in phase(), legal_candidates(), or candidate(). Structural constants, the Action-number→role mapping, fixed mask formula and12 templates are priors, not independently learned by Goal6. COPY/MASK/TURN are declared historical HDS relation interfaces whose installed-state and public-support closures remain unverified; they must not be described as newly learned or absent everywhere. The four missing historical closures remain a recovery task.

## Smallest useful next evidence

The full600-cell endpoint attribution has now been retained in `pixel_attribution.json`, including every ambiguous cell and all six actions:

- case0:50 informative inside changes,50 informative outside-preserved
- case1:55 inside changes,45 outside-preserved
- case2:40 inside changes,50 outside-preserved,10 prior-equal-tool ambiguous
- case3:100 prior-equal-tool ambiguous, zero informative overwrite evidence
- case4:50 inside changes,50 outside-preserved
- case5:15 inside changes,45 outside-preserved,40 prior-equal-tool ambiguous

Totals:210 informative inside changes,240 informative outside-preserved,150 unidentifiable, zero endpoint contradictions. These are600 correlated cell views of six historical actions, not600 independent experiments. Only five actions have any identifying pixels; case3 cannot distinguish overwrite from no-op. Every action remains retained. Duplicate endpoint phases13/14 do not increase independent support.

Practical next step: recover the historical MASK teacher/source contract and exact native state/support closure; compare its Y meaning against these full attributions. If Y is endpoint color equality, prior-equal-tool cells require explicit ambiguous treatment and outside unchanged pixels do not prove absence of a physical write. If Y claims actual overwrite or continuous preservation, these views do not establish that stronger latent mechanism. Do not silently change the old boundary or label ambiguous cells false to fit a truth table. Keep proposed examples unadmitted while that meaning is unresolved.

No new live intervention is required to finish this offline attribution/contract comparison. New independent public interventions are required to distinguish remaining alternative mechanics, establish action-role mapping, extend direction/color/device scope, demonstrate click-coordinate equivalence, or support continuous-response/transfer claims. Select contrasts because they discriminate hypotheses, retain failures/unknowns, and obtain separate action admission. Goal6 endpoint correspondence supplies none of these permissions.

The initial review-run assertion compared raw Python tuples with JSON lists and failed; its exact pre-fix runner is retained in prefix/review_initial.py. The successful runner compares the same canonical JSON projection used by the bridge artifact. This was a review harness correction, not a change to producer evidence or bridge behavior.
