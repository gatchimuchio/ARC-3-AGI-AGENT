"""Observe each actual visual-solver action; never choose or authorize one."""
from __future__ import annotations
from collections import Counter
import importlib
import json
import os
from pathlib import Path
_API = None

def _api():
    global _API
    if _API is None:
        _API = importlib.import_module("ARC3視覚HDS接続候補")
    return _API

def _mode():
    value = os.environ.get("ARC3_VISUAL_HDS_MODE", "shadow")
    if value not in {"off", "shadow"}:
        raise ValueError("Only off/shadow are validated; hints are not supported.")
    return value

def _runtime(session):
    value = getattr(session, "_arc3_visual_hds_runtime", None)
    if value is None:
        value = {"mode": _mode(), "counts": Counter(), "bridge": None,
                 "bridge_init_attempted": False, "last_adapter_error": None}
        session._arc3_visual_hds_runtime = value
    return value

def _frame(state, grid):
    raw_state = state.raw.state
    state_name = getattr(raw_state, "name", str(raw_state))
    return _api().PublicFrame(
        board=tuple(tuple(int(cell) for cell in row) for row in grid),
        state=state_name,
        levels_completed=int(state.levels_completed),
        available_actions=tuple(int(value) for value in state.available_actions),
    )

def _current_grid(state):
    data = state.frame.data
    rows = data.tolist() if hasattr(data, "tolist") else data
    return tuple(tuple(int(cell) for cell in row) for row in rows)

def _action(action):
    name = getattr(action.id, "name", "")
    if name == "RESET":
        return _api().PublicAction(0)
    if not name.startswith("ACTION") or not name[6:].isdigit():
        raise ValueError("Unknown public action name")
    number = int(name[6:])
    if number == 6:
        return _api().PublicAction(number, x=action.data.get("x"), y=action.data.get("y"))
    return _api().PublicAction(number)

def _bridge(runtime):
    if not runtime["bridge_init_attempted"]:
        runtime["bridge_init_attempted"] = True
        runtime["bridge"] = _api().VisualHDSBridge(
            update_budget=int(os.environ["ARC3_VISUAL_HDS_UPDATE_BUDGET"]),
            query_budget=int(os.environ["ARC3_VISUAL_HDS_QUERY_BUDGET"]),
            hds_seconds_budget=float(os.environ["ARC3_VISUAL_HDS_SECONDS_BUDGET"]),
        )
    return runtime["bridge"]

def _write_stats(session, runtime):
    try:
        bridge = runtime["bridge"]
        result = {
            "schema": "arc3-visual-hds-shadow-telemetry.v1",
            "mode": runtime["mode"],
            "authorization": False,
            "continue_visual_solver": True,
            "model_context_modified": False,
            "counts": dict(sorted(runtime["counts"].items())),
            "last_adapter_error": runtime["last_adapter_error"],
            "hds": bridge.stats if bridge is not None else None,
            "prior": bridge.prior_report if bridge is not None else None,
            "raw_ids_boards_coordinates_or_action_sequences_persisted": False,
        }
        path = Path(session.state_path).with_suffix(".visual-hds.json")
        temporary = path.with_suffix(path.suffix + ".tmp")
        temporary.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        os.replace(temporary, path)
    except Exception as exc:
        runtime["counts"]["telemetry_write_errors"] += 1
        runtime["last_adapter_error"] = type(exc).__name__

def before_action(session, action, *, public_grid, automatic=False):
    runtime = _runtime(session)
    runtime["counts"]["actual_action_calls_seen"] += 1
    if runtime["mode"] == "off":
        return None
    if automatic or getattr(action.id, "name", "") == "RESET":
        runtime["counts"]["skipped_automatic_actions"] += int(bool(automatic))
        runtime["counts"]["skipped_RESET_actions"] += int(getattr(action.id, "name", "") == "RESET")
        return None
    try:
        step = int(session.action_count)
        before = _frame(session.game.current_state, public_grid)
        candidate = _action(action)
        bridge = _bridge(runtime)
        if bridge is None:
            runtime["counts"]["unavailable_bridge"] += 1
            return None
        result = bridge.query(before, candidate)
        runtime["counts"]["query_status:" + str(result.get("bridge_status", "missing"))] += 1
        runtime["counts"]["query_native:" + str(result.get("native_status", "missing"))] += 1
        runtime["counts"]["queries_with_relevant_predictions"] += int(bool(result.get("relevant_prediction_count")))
        if int(session.action_count) != step or _frame(session.game.current_state, _current_grid(session.game.current_state)) != before:
            runtime["counts"]["public_state_changed_during_HDS_query"] += 1
            return None
        return {"before": before, "action": candidate, "step": step, "query": result}
    except Exception as exc:
        runtime["counts"]["before_adapter_errors"] += 1
        runtime["last_adapter_error"] = type(exc).__name__
        return None

def after_action(session, action, captured, new_state, *, public_grid, automatic=False):
    runtime = _runtime(session)
    if captured is None:
        _write_stats(session, runtime)
        return
    try:
        if automatic or getattr(action.id, "name", "") == "RESET":
            raise ValueError("A skipped lifecycle action unexpectedly has a captured query")
        if int(session.action_count) != captured["step"] + 1:
            runtime["counts"]["public_action_step_mismatch"] += 1
            return
        # Explicit new_state preserves the fatal response even if current_state later resets.
        after = _frame(new_state, public_grid)
        outcome = _api()._observed_outcome(captured["before"], after)
        runtime["counts"]["public_outcome:" + outcome] += 1
        runtime["counts"]["public_responses_observed"] += 1
        supported = _api().render_hint(captured["query"], max_chars=1200)
        if supported:
            runtime["counts"]["queries_with_supported_nonconflicting_context"] += 1
            payload = json.loads(supported.split("\n", 1)[1])
            values = {row["value"] for row in payload["predictions"]}
            if len(values) == 1:
                runtime["counts"]["supported_unique_predictions_observed"] += 1
                runtime["counts"]["supported_unique_prediction_matches"] += int(outcome in values)
            else:
                runtime["counts"]["supported_multiple_prediction_values"] += 1
        result = runtime["bridge"].update(captured["before"], captured["action"], after)
        runtime["counts"]["update_status:" + str(result.get("bridge_status", "missing"))] += 1
        runtime["counts"]["update_native:" + str(result.get("native_status", "missing"))] += 1
    except Exception as exc:
        runtime["counts"]["after_adapter_errors"] += 1
        runtime["last_adapter_error"] = type(exc).__name__
    finally:
        _write_stats(session, runtime)
